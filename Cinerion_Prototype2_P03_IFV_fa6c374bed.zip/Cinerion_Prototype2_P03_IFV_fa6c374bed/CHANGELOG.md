# Cinerion implementation changelog

> **CONFIDENTIAL — PROJECT INTERNAL**  
> Copyright © 2026 IR. All rights reserved.

## Unreleased — the package carries the lab's data — 2026-09-19

### Added

- `npm run lab:export` snapshots every record in the lab (`lab-snapshot/`, git-ignored);
  `npm run package:release` puts it in the zip, and the installer loads it into the new PC's
  empty database and checks every table's row count. Never loaded over existing data;
  `npm run lab:import` does it by hand. Passwords and keys are never packed.
- `npm run lab:check` has a twelfth check: telemetry is actually being stored.

### Fixed

- Simulated telemetry had been refused since 2026-09-17: the enrolment declared a channel the
  source never publishes. It now declares the catalogue's four channels, and a lab enrolled the
  old way is repaired on the next install or `lab:up` by rotating the stand-in's certificate.
- The realm's users get the same IDs on every install, so records survive a move between PCs.

## Unreleased — release package and one-command install — 2026-09-19

### Added

- `install.cmd` / `install.ps1` (Windows) and `install.sh` (Linux, macOS, WSL): check the tools
  (the Windows one offers to install missing ones with winget), wake Docker, check the ports,
  write secrets, start the lab and run its health check. Safe to re-run; stops before changing
  anything if it finds lab data without a secrets file (the upgrade trap).
- `INSTALL.md`, a rewritten `README.md`, and `infrastructure/keycloak/README.md`.
- `npm run package:release` builds `Cinerion_Prototype2_P03_IFV_<commit>.zip` from the committed
  tree with `BUILD_INFO.txt` and a SHA-256 manifest, and re-verifies every checksum after
  unpacking.

### Fixed — all found by installing the package from scratch

- Keycloak refused the controlled realm on every fresh install (a `_note` field, and a
  505-character description in a 255-character column). The one working lab was a container
  restart away from the same failure. `npm run policy` now refuses both shapes.
- `bootstrap-local` wrote 5 of the 7 secrets the lab needs.
- `npm run package:release` needed `zip`; four npm scripts could not run on Windows at all.
- Every installer re-run reported a false enrolment FAIL for the stand-in controller.
- The Windows installer log missed the lab's own output.

## Unreleased — layout you can see, comments you can read — 2026-09-18

### Fixed

- The Security screen's title squeezed to one letter per line by a fifteen-role pill that
  would not shrink (reported by the owner with a screenshot). Fixed at the root in
  `PageIntro`, `SectionHeading` and `StatusPill`; roles are now chips, and Keycloak's own
  `default-roles-cinerion` is disclosed as granting nothing instead of counted as a role.
- The "another role owns this act" notice running off the right edge of the screen.
- The Resources capacity bar's red over-commitment segment, which had never been visible:
  it was drawn past the end of a clipped track.
- `io:attack` crashing inside its own restore on a transient Windows file lock and leaving
  the pin map mutated. All attack suites now write through `scripts/lib/write-settled.mjs`.

### Added

- `npm run layout:portal` — every rendered screen laid out in the local Chrome (headless,
  throwaway profile, no new dependency, no network) at 1180, 1440 and 1920 px: 183 layouts.
  Refuses content past the window, squeezed text and sideways scrolling, after a positive
  control that carries both of the screenshot's bugs.
- `npm run layout:attack` — 7 attacks, 0 holes, each putting one of today's bugs back.
- `CINERION_RENDER_SNAPSHOT_DIR` for the render harness, and a render scenario signed in with
  the lab identity's real fifteen roles.
- `io:attack` in both pipelines; a Chrome/Edge check in `scripts/doctor.sh`.
- A plain one- or two-line header comment on the 267 source files that opened with none.

## Unreleased — AI authority prohibition and portal egress — 2026-09-17

### Added

- `npm run ai:prohibition` (`scripts/check-ai-authority-prohibition.mjs`), enforcing
  CH1-AI-FR-0002, `access.json`'s `Approve or command via AI — None — Not applicable —
  Explicitly prohibited`, CH1-PMG-AIU-0005 and CH1-SWA-ADR-0010 over the deployable tree:
  no AI client dependency, service host, model identifier, credential, actor kind, role,
  realm identity or architecture component. The rule is read FROM the baseline, so the gate
  refuses rather than continues if the controlled documents stop stating it.
  All seven matcher classes are fired against buffers that DO contain what they refuse
  before any conclusion is drawn, because a gate searching for absence cannot otherwise
  tell a clean tree from a broken search.
- `npm run ai:attack` — 25 attacks, 0 holes, two of which blind the gate's own matchers.
- `npm run portal:egress` (`scripts/check-portal-egress.mjs`), the portal half of
  CH1-OPS-FR-0001, which `scripts/check-offline-workflow.sh` never covered: the CSP's
  non-`connect-src` directives, the controlled compose model's `EXPO_PUBLIC_*` values, and
  every absolute origin in the exported bundle. `https://auth.expo.io` — Expo's hosted auth
  proxy, the one live public service in the bundle — is not merely allowlisted; the two
  independent reasons it is unreachable are asserted.
- `npm run portal:egress:attack` — 18 attacks, 0 holes.
- Both gates in `scripts/verify.sh` and `scripts/verify.ps1` (item 19), and both bound in
  `traceability/verification-map.json`: CH1-VVT-TC-0066 moves from `partially_automated` to
  `automated`, and CH1-VVT-TC-0080 gains a second binding.

### Changed

- CH1-VVT-TC-0065 is recorded as **not executable while the prohibition holds** rather than
  as deferred pending effort: it presupposes AI output, and producing any would mean
  building what CH1-VVT-TC-0066 forbids. Conflict 37 records the underlying reconciliation.

### Removed

- `apps/operator-portal/.claude/settings.json`, `apps/operator-portal/AGENTS.md` and
  `.claude/settings.local.json` — coding-agent and editor tooling, two of which
  `MANIFEST.sha256` shows were packaged inside a controlled confidential release. Now
  git-ignored and excluded from `scripts/package-release.sh`, with the exclusion itself
  checked.

## Unreleased setup hardening — 2026-08-06

### Added

- Cross-platform workstation doctors for WSL2, Node.js, .NET 10, C++20, Git,
  Docker Compose, and Docker Engine reachability.
- A precise Ubuntu 26.04 and Docker Desktop WSL repair runbook.

### Changed

- Strict verification now rejects a broken partial `.NET` launcher and a
  Docker CLI without Compose/engine access with actionable diagnostics.
- Local startup now differentiates missing WSL integration, a missing Compose
  plug-in, and a stopped Docker engine.

## 0.1.0-prototype.1 — 2026-08-06

First executable checkpoint derived from `CH1 / Cinerion / P03 / IFV`.

### Added

- Frozen, checksum-verified copy of the controlled P03/IFV source baseline.
- Modular .NET Control Core with guarded commands, audit, quality, API, and
  simulator repository boundaries.
- Complete controlled API catalogue with 54 operations and explicit fail-closed
  responses for capabilities not authorised in Prototype 1.
- PostgreSQL foundation schema with project-scoped relationships, forced row
  security, immutable evidence records, and quality/rework constraints.
- Expo/React Native operator portal with six operational workspaces and eight
  statically exported routes.
- EdgeLink protocol-provider boundary with simulator implementation and
  fail-closed industrial-adapter gates.
- Portable C++ controller state machine, Arduino framed transport codec,
  ESP32-S3 safe-boot integration skeleton, and Siemens S7-1200 G2 source
  structure.
- Docker Compose laboratory topology, Keycloak realm, mutual-TLS MQTT policy,
  CI workflow, traceability, policy checks, and reproducible local scripts.
- Executable command, audit, quality, rework, firmware, and transport tests.

### Authority limitations

This release authorises simulation and controlled extra-low-voltage Prototype 1
work only. It does not authorise hazardous output energisation, production use,
certification, customer delivery, or publication of the confidential backbone.
