## Controlled change

- Change record / decision reference:
- Requirements affected:
- Security or safety impact:
- Migration / rollback impact:

## Evidence

- [ ] `./scripts/verify.sh --strict` passes
- [ ] Requirement implementation map updated
- [ ] Tests cover success, rejection, restart, replay, and failure paths as applicable
- [ ] No credentials, private keys, controlled documents, or confidential evidence are included
- [ ] Physical-effect changes remain within the authorised prototype gate

## Reviewer notes

Independent technical review is deferred until after Prototype 1 under `P03/IFV`. Changes affecting hazardous hardware, safety functions, credential trust, cryptography, production release, or external publication must not be merged as operational authority without the applicable later gate.
