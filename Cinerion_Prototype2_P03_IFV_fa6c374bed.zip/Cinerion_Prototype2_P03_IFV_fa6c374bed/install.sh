#!/usr/bin/env sh
# Cinerion installer for Linux, macOS and WSL. One command from an unzipped folder to a
# running lab:
#
#   sh install.sh               install and start
#   sh install.sh --check-only  check the machine and stop; change nothing
#   sh install.sh --no-browser  don't try to open the portal at the end
#
# It checks the tools, writes local secrets (topping up, never overwriting), builds and
# starts the whole lab, runs the lab's own health check, and tells you where to sign in.
# Safe to run again; re-running is also how you start the lab next time.
#
# It won't sudo anything on your behalf. If a tool is missing it says exactly what to
# install and stops. The internet is needed once, for images and packages on the first
# install; after that everything runs offline. No AI service is involved anywhere.

set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$root"

check_only=false
open_browser=true
for arg in "$@"; do
  case "$arg" in
    --check-only) check_only=true ;;
    --no-browser) open_browser=false ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

step() { printf '\n== %s\n' "$*"; }
good() { printf '   ok    %s\n' "$*"; }
warn() { printf '   warn  %s\n' "$*"; }
die()  { printf '\n   FAIL  %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

printf '\nCinerion - Prototype 2 lab installer\nFolder: %s\n' "$root"

step '1/5  Checking the tools this needs'
missing=""
if have docker && docker compose version >/dev/null 2>&1; then good "Docker with Compose v2"; else warn "Docker with Compose v2 is missing"; missing="$missing docker"; fi
if have node; then
  node_major=$(node -p 'process.versions.node.split(".")[0]')
  node_minor=$(node -p 'process.versions.node.split(".")[1]')
  if [ "$node_major" -gt 22 ] || { [ "$node_major" -eq 22 ] && [ "$node_minor" -ge 13 ]; }; then
    good "Node.js $(node --version)"
  else
    warn "Node.js $(node --version) is too old; 22.13 or newer is needed"; missing="$missing node"
  fi
else
  warn "Node.js is missing"; missing="$missing node"
fi
for tool in curl openssl git; do
  if have "$tool"; then good "$tool"; else warn "$tool is missing"; missing="$missing $tool"; fi
done

if [ -n "$missing" ]; then
  echo
  echo "   Missing:$missing"
  echo "   Debian/Ubuntu:  sudo apt install curl openssl git   and Docker from https://docs.docker.com/engine/install/"
  echo "                   Node.js 22.13+ from https://nodejs.org or your package manager (nvm works too)"
  echo "   macOS:          brew install node git   and Docker Desktop"
  die "Install the missing tools and run this again. INSTALL.md has the details."
fi

step '2/5  Making sure the Docker engine is running'
docker info >/dev/null 2>&1 || die "Docker is installed but the engine isn't reachable. Start it (Docker Desktop, or: sudo systemctl start docker) and run this again."
good "Docker engine is running"

step '3/5  Checking the ports the lab uses (5080, 8081, 8180, 5085)'
for port in 5080 8081 8180 5085; do
  if docker ps --format '{{.Names}} {{.Ports}}' | grep -E "^cinerion-" | grep -q ":$port->"; then
    good "port $port is already the lab's own"
  elif (have ss && ss -ltn 2>/dev/null | grep -q "[:.]$port ") || (have lsof && lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1); then
    die "Port $port is in use by something else. Free it and run this again."
  else
    good "port $port is free"
  fi
done

if [ "$check_only" = true ]; then
  echo
  good "This machine is ready. Run: sh install.sh"
  exit 0
fi

step '4/5  Local secrets (generated here, never leave this machine)'
# The upgrade trap: a newer version unzipped into a NEW folder has no secrets file, but the
# old lab's data volumes were created with the OLD secrets. Fresh ones would lock the database
# and identity provider out of their own data, so stop and say what to do instead.
project=${COMPOSE_PROJECT_NAME:-cinerion}
if [ ! -f infrastructure/.env.local ] && \
   docker volume ls --format '{{.Name}}' | grep -qxE "${project}_cinerion-(postgres|identity-db)"; then
  echo "   FAIL  This machine already has Cinerion lab data, but this folder has no secrets file."
  echo "         The data was created with the secrets from the folder you installed from before."
  echo "         Copy infrastructure/.env.local from that folder into this one, then run this again."
  echo "         (To throw the old data away instead, see INSTALL.md section 4, \"Starting over\".)"
  die "Stopped before changing anything, so nothing is locked out."
fi
sh scripts/bootstrap-local.sh

step '5/5  Building and starting the lab (first time: 10-20 minutes, later: about 1)'
sh scripts/lab-up.sh || die "Starting the lab failed. See the messages above and INSTALL.md > Troubleshooting."
sh scripts/check-lab.sh || die "The lab started but its health check failed. See the FAIL lines above."

cat <<'EOF'

Cinerion is running.

  Portal         http://localhost:8081
  Sign in as     ch1-portal-demo      (everyday roles)
             or  ch1-portal-security  (cybersecurity roles)
  Password       CINERION_PORTAL_DEMO_PASSWORD in infrastructure/.env.local
                 (show it:  grep CINERION_PORTAL_DEMO_PASSWORD infrastructure/.env.local)

  API health     http://localhost:5080/api/v1/system/health
  Identity       http://localhost:8180/realms/cinerion
  Stop the lab   npm run lab:down        (your data is kept)
  Start again    sh install.sh

  Everything is simulated. No real machine is connected or can be driven from here.
EOF

if [ "$open_browser" = true ]; then
  if have xdg-open; then xdg-open http://localhost:8081 >/dev/null 2>&1 || true
  elif have open; then open http://localhost:8081 >/dev/null 2>&1 || true
  fi
fi
