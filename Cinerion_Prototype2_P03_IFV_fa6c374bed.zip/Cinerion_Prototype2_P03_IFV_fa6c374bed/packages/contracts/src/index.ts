// Shared contract types: IDs, timestamps, hashes and the envelope shapes both sides agree on.

export const CH1_SCHEMA_VERSION = '1.0.0' as const;

export type Uuid = `${string}-${string}-${string}-${string}-${string}`;
export type IsoTimestamp = string;
export type Sha256 = string;

export type DataQuality = 'Good' | 'Uncertain' | 'Bad' | 'Unknown';
export type Freshness = 'Live' | 'Stale' | 'Disconnected' | 'Simulated' | 'Maintenance' | 'Unknown';
export type TimeQuality = 'Trusted' | 'Qualified' | 'Degraded' | 'Unknown';

export interface MessageEnvelope<TPayload> {
  schemaVersion: typeof CH1_SCHEMA_VERSION;
  messageType: string;
  messageId: Uuid;
  correlationId: Uuid;
  causationId?: Uuid;
  sourceId: string;
  destinationId: string;
  projectId: Uuid;
  siteId?: Uuid;
  cellId?: Uuid;
  assetId?: Uuid;
  sequence: number;
  occurredAt: IsoTimestamp;
  expiresAt?: IsoTimestamp;
  timeQuality: TimeQuality;
  payload: TPayload;
}

export type CommandState =
  | 'AwaitingCredential'
  | 'AwaitingButton'
  | 'Committed'
  | 'Executing'
  | 'Completed'
  | 'Cancelled'
  | 'Rejected'
  | 'FaultLatched';

export interface PrepareCommandRequest {
  commandType: string;
  projectId: Uuid;
  siteId: Uuid;
  cellId: Uuid;
  assetId: Uuid;
  workOrderId: Uuid;
  partId: Uuid;
  procedureRevision: string;
  configurationRevision: string;
  expectedStateHash: Sha256;
  sequence: number;
  expiresAt: IsoTimestamp;
  parameters: Readonly<Record<string, string | number | boolean>>;
}

export interface CommandTransaction extends PrepareCommandRequest {
  commandId: Uuid;
  correlationId: Uuid;
  requesterId: Uuid;
  idempotencyKey: string;
  state: CommandState;
  preparedAt: IsoTimestamp;
  credentialProofId?: Uuid;
  localCommitId?: Uuid;
  terminalReason?: string;
  version: number;
}

export interface CredentialPresenceProof {
  proofId: Uuid;
  confirmationId: Uuid;
  commandId: Uuid;
  cellId: Uuid;
  controllerId: string;
  credentialId: Uuid;
  userId: Uuid;
  authenticatorClass: 'SmartCard' | 'FidoSecurityKey' | 'CryptographicNfc';
  challengeHash: Sha256;
  userVerification: boolean;
  verifiedAt: IsoTimestamp;
  expiresAt: IsoTimestamp;
}

export interface LocalCommitEvidence {
  localCommitId: Uuid;
  confirmationId: Uuid;
  commandId: Uuid;
  cellId: Uuid;
  controllerId: string;
  observedLocally: true;
  previousButtonState: false;
  currentButtonState: true;
  observedAt: IsoTimestamp;
  interlockSnapshotHash: Sha256;
  controllerBootId: Uuid;
}

export interface TelemetrySample {
  sampleId: Uuid;
  projectId: Uuid;
  cellId: Uuid;
  deviceId: string;
  channelId: string;
  value: number;
  unit: string;
  quality: DataQuality;
  freshness: Freshness;
  sampledAt: IsoTimestamp;
  receivedAt: IsoTimestamp;
  timeQuality: TimeQuality;
}

export interface DeviceCapabilityManifest {
  schemaVersion: typeof CH1_SCHEMA_VERSION;
  deviceId: string;
  deviceType: 'Esp32CellController' | 'ArduinoIoNode' | 'SiemensS71200G2' | 'Instrument' | 'Simulator';
  firmwareVersion: string;
  configurationRevision: string;
  supportedCommands: readonly string[];
  telemetryChannels: readonly {
    channelId: string;
    unit: string;
    writable: false;
  }[];
  protocolEndpoints: readonly {
    protocol: 'MQTT5' | 'OPCUA' | 'MODBUS_TCP' | 'MODBUS_RTU' | 'SERIAL' | 'CAN' | 'SIMULATOR';
    profileVersion: string;
  }[];
  securityProfile: string;
}

export interface ApiError {
  type: string;
  title: string;
  status: number;
  code: string;
  detail: string;
  correlationId: Uuid;
  fieldErrors?: Readonly<Record<string, readonly string[]>>;
}

export interface AuditEventContract {
  eventId: Uuid;
  sequence: number;
  eventType: string;
  actorId: string;
  actorKind: 'Human' | 'Service' | 'Device' | 'System';
  projectId: Uuid;
  objectType: string;
  objectId: string;
  correlationId: Uuid;
  occurredAt: IsoTimestamp;
  timeQuality: TimeQuality;
  decision: string;
  reasonCode: string;
  payloadHash: Sha256;
  previousHash: Sha256;
  eventHash: Sha256;
}

