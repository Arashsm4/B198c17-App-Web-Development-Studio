// Checks the contracts package still lines up with the controlled catalogue.

import { readFileSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(here, '..');
const repoRoot = resolve(packageRoot, '../..');
const catalogue = JSON.parse(
  readFileSync(resolve(repoRoot, 'docs/baseline/P03_IFV/data/api_endpoints.json'), 'utf8'),
);
const openapi = readFileSync(resolve(packageRoot, 'openapi/openapi.generated.yaml'), 'utf8');

for (const [method, path] of catalogue) {
  if (!openapi.includes(`  ${path}:`) || !openapi.includes(`    ${method.toLowerCase()}:`)) {
    throw new Error(`OpenAPI catalogue is missing ${method} ${path}`);
  }
}

for (const file of readdirSync(resolve(packageRoot, 'schemas'))) {
  const schema = JSON.parse(readFileSync(resolve(packageRoot, 'schemas', file), 'utf8'));
  if (schema.$schema !== 'https://json-schema.org/draft/2020-12/schema') {
    throw new Error(`${file} does not use JSON Schema 2020-12`);
  }
  if (schema.additionalProperties !== false) {
    throw new Error(`${file} must fail closed on unknown top-level fields`);
  }
}

console.log(`Validated ${catalogue.length} API operations and all JSON schemas.`);

