// Generates the OpenAPI file from the controlled catalogue, so the docs can't wander off from
// the API.

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../../..');
const catalogue = JSON.parse(
  readFileSync(resolve(root, 'docs/baseline/P03_IFV/data/api_endpoints.json'), 'utf8'),
);

const yamlString = (value) => JSON.stringify(String(value));
const operationIds = new Set();
const paths = new Map();

for (const [method, path, summary, authority, securityControl] of catalogue) {
  const operationId = `${method.toLowerCase()}_${path}`
    .replaceAll(/\{([^}]+)\}/g, 'by_$1')
    .replaceAll(/[^a-zA-Z0-9]+/g, '_')
    .replaceAll(/^_|_$/g, '');
  if (operationIds.has(operationId)) throw new Error(`Duplicate operationId ${operationId}`);
  operationIds.add(operationId);
  const body = [
    `    ${method.toLowerCase()}:`,
    `      operationId: ${operationId}`,
    `      summary: ${yamlString(summary)}`,
    `      tags: [${yamlString(path.split('/')[3] ?? 'system')}]`,
    `      x-ch1-authority: ${yamlString(authority)}`,
    `      x-ch1-security-control: ${yamlString(securityControl)}`,
    '      responses:',
    '        "200":',
    '          description: Successful controlled operation',
    '        "201":',
    '          description: Controlled resource created',
    '        "400":',
    '          $ref: "#/components/responses/Problem"',
    '        "401":',
    '          $ref: "#/components/responses/Problem"',
    '        "403":',
    '          $ref: "#/components/responses/Problem"',
    '        "409":',
    '          $ref: "#/components/responses/Problem"',
  ];
  const existing = paths.get(path) ?? [];
  existing.push(...body);
  paths.set(path, existing);
}

const lines = [
  'openapi: 3.1.0',
  'info:',
  '  title: Cinerion Control Core API',
  '  version: 1.0.0-p03.1',
  '  description: >-',
  '    CONFIDENTIAL CH1 contract. Physical-effect operations prepare semantic',
  '    intent only and cannot emulate LOCAL COMMIT or bypass local interlocks.',
  'servers:',
  '  - url: http://localhost:5080',
  '    description: Simulation-only local development',
  'security:',
  '  - oidc: []',
  'paths:',
];

for (const path of [...paths.keys()].sort()) {
  lines.push(`  ${path}:`, ...paths.get(path));
}

lines.push(
  'components:',
  '  securitySchemes:',
  '    oidc:',
  '      type: openIdConnect',
  '      openIdConnectUrl: "{oidcAuthority}/.well-known/openid-configuration"',
  '    deviceMtls:',
  '      type: mutualTLS',
  '  responses:',
  '    Problem:',
  '      description: Controlled error response',
  '      content:',
  '        application/problem+json:',
  '          schema:',
  '            $ref: "#/components/schemas/Problem"',
  '  schemas:',
  '    Problem:',
  '      type: object',
  '      additionalProperties: false',
  '      required: [type, title, status, code, detail, correlationId]',
  '      properties:',
  '        type: { type: string }',
  '        title: { type: string }',
  '        status: { type: integer, minimum: 400, maximum: 599 }',
  '        code: { type: string }',
  '        detail: { type: string }',
  '        correlationId: { type: string, format: uuid }',
  '',
);

mkdirSync(resolve(here, '../openapi'), { recursive: true });
writeFileSync(resolve(here, '../openapi/openapi.generated.yaml'), lines.join('\n'));
console.log(`Generated OpenAPI catalogue with ${catalogue.length} operations.`);
