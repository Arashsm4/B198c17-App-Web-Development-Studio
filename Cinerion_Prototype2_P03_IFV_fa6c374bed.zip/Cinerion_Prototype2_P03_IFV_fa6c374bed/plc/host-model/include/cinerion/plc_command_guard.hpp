// The PLC command guard as a C++ model, so the SCL logic can be tested without a real S7-1200.

#pragma once

// A host-executable model of the S7-1200 G2 function blocks.
//
// plc/s7-1200-g2/01_Blocks/*.scl is the controlled source and stays authoritative. It
// cannot be executed here: PLCSIM needs TIA Portal, a CPU firmware version and an order
// code, all of which are procurement gates. The consequence was that the eleven scenarios
// in tests/PLCSIM_SCENARIOS.md were a table of intentions — "results remain not executed"
// — and the command handshake CH1-AUT-FDS-0001 specifies had never been run at all.
//
// This is a faithful translation of that SCL: the same state numbers, the same reason
// codes, the same order of evaluation, scan by scan. It exists so the scenarios execute
// and so a change to the guard has to survive them.
//
// It is a second implementation, so it can drift from the first. That is what
// scripts/check-plc-model.mjs is for: it reads both files and fails when a reason code,
// a state value or a scenario exists in one and not the other. A model nobody reconciled
// with the controlled source would be worse than no model, because it would look like
// evidence about the PLC while being evidence about itself.

#include <cstdint>

namespace cinerion::plc {

/// FB_CH1_CommandGuard states. The values are the SCL's, not a re-numbering.
enum State : std::uint8_t {
    kIdle = 0,
    kPrepared = 10,
    kCommitted = 20,
    kExecuting = 30,
    kComplete = 40,
    kFaultLatched = 90,
};

/// Reason codes, exactly as the SCL emits them.
enum Reason : std::uint16_t {
    kNone = 0,
    kPreparedOk = 10,
    kLocallyCommitted = 20,
    kControllerRestarted = 110,
    kPrepareExpired = 120,
    kCancelled = 130,
    kExecutionFinished = 140,
    kCompletionAcknowledged = 141,
    kStateInvalid = 201,
    kSchemaUnsupported = 202,
    kReplayOrDuplicate = 203,
    kExpired = 204,
    kRevisionMismatch = 205,
    kExpectedStateMismatch = 206,
    kPreliminaryPermissiveInvalid = 207,
    kNotPrepared = 301,
    kCommandBindingMismatch = 302,
    kBootBindingMismatch = 303,
    kCommitExpired = 304,
    kFinalPermissiveInvalid = 305,
    kMaterialStateChanged = 306,
    kExecutionPermissiveLost = 310,
    kProcedureFaultLatched = 320,
    kLocalRecoveryAccepted = 330,
};

/// UDT_CH1_Permissives. Readiness inputs for a controlled sequence, never a safety-rated
/// protective function: the standard CPU is not credited as a safety controller.
struct Permissives {
    bool controller_online{false};
    bool start_enable{false};
    bool stop_circuit_healthy{false};
    bool guard_healthy{false};
    bool actuator_home{false};
    bool fault_cause_active{false};

    [[nodiscard]] bool all_valid() const noexcept {
        return controller_online && start_enable && stop_circuit_healthy && guard_healthy &&
               actuator_home && !fault_cause_active;
    }
};

/// UDT_CH1_Command, reduced to the fields the guard actually evaluates.
struct Command {
    std::uint8_t schema_major{1};
    std::uint64_t command_id_hi{0};
    std::uint64_t command_id_lo{0};
    std::uint64_t sequence_number{0};
    std::uint32_t expected_state_hash32{0};
    std::uint32_t configuration_revision{0};
    std::uint64_t controller_boot_id{0};
    std::uint64_t expires_at_monotonic_ms{0};
    bool prepare_request{false};
    bool cancel_request{false};
};

/// The inputs sampled each scan.
struct GuardInputs {
    bool enable{true};
    std::uint64_t now_monotonic_ms{0};
    std::uint32_t current_configuration_revision{0};
    std::uint32_t current_state_hash32{0};
    std::uint64_t current_controller_boot_id{0};
    Command command{};
    Permissives permissives{};
    /// Originates at the designated local cell controller after its cryptographic
    /// credential proof and a physical button edge. Never mapped to an HMI or a general
    /// register write.
    bool local_commit_request{false};
    std::uint64_t local_commit_command_id_hi{0};
    std::uint64_t local_commit_command_id_lo{0};
    std::uint64_t local_commit_controller_boot_id{0};
    /// Reported by FB_CH1_Procedure. The guard needs it to leave the committed state.
    bool procedure_complete{false};
    bool procedure_running{false};
    /// Also reported by FB_CH1_Procedure. Without it the guard cannot tell a procedure
    /// that finished from one that latched a fault.
    bool procedure_fault_latched{false};
    /// CH1-AUT-FDS-0001's state diagram leaves Complete on "acknowledge completion /
    /// new order".
    bool completion_acknowledged{false};
};

struct GuardOutputs {
    std::uint8_t state{kIdle};
    bool prepared_ack{false};
    bool local_commit_ack{false};
    bool execute_permit{false};
    bool rejected{false};
    std::uint16_t reason_code{kNone};
    std::uint64_t ack_sequence_number{0};
    std::uint64_t ack_command_id_hi{0};
    std::uint64_t ack_command_id_lo{0};
};

/// FB_CH1_CommandGuard, one scan per call.
class CommandGuard {
  public:
    GuardOutputs scan(const GuardInputs& inputs) noexcept;

    [[nodiscard]] const GuardOutputs& outputs() const noexcept { return outputs_; }

  private:
    GuardOutputs outputs_{};
    std::uint64_t last_sequence_number_{0};
    std::uint64_t prepared_command_id_hi_{0};
    std::uint64_t prepared_command_id_lo_{0};
    std::uint64_t prepared_expires_at_{0};
    std::uint64_t prepared_boot_id_{0};
    // R_TRIG instances: an edge, not a level. A held input must never re-arm anything.
    bool prepare_previous_{false};
    bool commit_previous_{false};
    bool cancel_previous_{false};
};

// ------------------------------------------------------------------ FB_CH1_Procedure

enum ProcedureFault : std::uint16_t {
    kNoFault = 0,
    kWatchdogStopOrPermissiveLost = 901,
    kInvalidStep = 999,
};

struct ProcedureInputs {
    bool execute_permit{false};
    bool stop_request{false};
    bool watchdog_healthy{true};
    Permissives permissives{};
    std::uint32_t step_timeout_ms{10'000};
    std::uint32_t scan_interval_ms{100};
    /// A new reset edge from local authority. CH1-AUT-FDS-0001 requires recovery to
    /// verify the cause removed, local authority, a reset edge and reconciled state, and
    /// a reset never commands motion.
    bool local_reset_request{false};
};

struct ProcedureOutputs {
    std::uint8_t step{0};
    bool running{false};
    bool complete{false};
    bool fault_latched{false};
    std::uint16_t fault_code{kNoFault};
    bool actuator_enable{false};
};

class Procedure {
  public:
    ProcedureOutputs scan(const ProcedureInputs& inputs) noexcept;

    [[nodiscard]] const ProcedureOutputs& outputs() const noexcept { return outputs_; }

  private:
    ProcedureOutputs outputs_{};
    std::uint32_t step_timer_ms_{0};
    bool reset_previous_{false};
};

}  // namespace cinerion::plc
