// Host version of the PLC guard. Same rules as the SCL, much easier to poke at.

#include "cinerion/plc_command_guard.hpp"

namespace cinerion::plc {
namespace {

/// R_TRIG. A rising edge, never a level: a held input must not re-arm anything, which is
/// the same rule the firmware's confirmation button obeys.
bool rising(bool current, bool& previous) noexcept {
    const bool edge = current && !previous;
    previous = current;
    return edge;
}

}  // namespace

GuardOutputs CommandGuard::scan(const GuardInputs& in) noexcept {
    const bool prepare_edge = rising(in.command.prepare_request, prepare_previous_);
    const bool commit_edge = rising(in.local_commit_request, commit_previous_);
    const bool cancel_edge = rising(in.command.cancel_request, cancel_previous_);

    // Pulsed outputs are cleared every scan, exactly as the SCL clears them at the top.
    outputs_.prepared_ack = false;
    outputs_.local_commit_ack = false;
    outputs_.rejected = false;
    outputs_.reason_code = kNone;

    if (!in.enable) {
        outputs_.state = kIdle;
        outputs_.execute_permit = false;
        return outputs_;
    }

    // Any controller boot identity change cancels uncommitted preparation.
    if (outputs_.state == kPrepared && in.current_controller_boot_id != prepared_boot_id_) {
        outputs_.state = kIdle;
        outputs_.execute_permit = false;
        outputs_.reason_code = kControllerRestarted;
    }

    // Timeout never causes execution or automatic continuation.
    if (outputs_.state == kPrepared && in.now_monotonic_ms >= prepared_expires_at_) {
        outputs_.state = kIdle;
        outputs_.execute_permit = false;
        outputs_.reason_code = kPrepareExpired;
    }

    if (cancel_edge && outputs_.state == kPrepared) {
        outputs_.state = kIdle;
        outputs_.execute_permit = false;
        outputs_.reason_code = kCancelled;
    }

    // CH1-AUT-FDS-0001's state diagram: Complete --acknowledge completion / new order-->
    // Idle. Before the prepare edge, so that "new order" is judged from Idle.
    if (outputs_.state == kComplete && (in.completion_acknowledged || prepare_edge)) {
        outputs_.state = kIdle;
        outputs_.execute_permit = false;
        outputs_.reason_code = kCompletionAcknowledged;
    }

    if (prepare_edge) {
        if (outputs_.state != kIdle) {
            outputs_.rejected = true;
            outputs_.reason_code = kStateInvalid;
        } else if (in.command.schema_major != 1) {
            outputs_.rejected = true;
            outputs_.reason_code = kSchemaUnsupported;
        } else if (in.command.sequence_number <= last_sequence_number_) {
            outputs_.rejected = true;
            outputs_.reason_code = kReplayOrDuplicate;
        } else if (in.command.expires_at_monotonic_ms <= in.now_monotonic_ms) {
            outputs_.rejected = true;
            outputs_.reason_code = kExpired;
        } else if (in.command.configuration_revision != in.current_configuration_revision) {
            outputs_.rejected = true;
            outputs_.reason_code = kRevisionMismatch;
        } else if (in.command.expected_state_hash32 != in.current_state_hash32) {
            outputs_.rejected = true;
            outputs_.reason_code = kExpectedStateMismatch;
        } else if (!in.permissives.all_valid()) {
            outputs_.rejected = true;
            outputs_.reason_code = kPreliminaryPermissiveInvalid;
        } else {
            prepared_command_id_hi_ = in.command.command_id_hi;
            prepared_command_id_lo_ = in.command.command_id_lo;
            prepared_expires_at_ = in.command.expires_at_monotonic_ms;
            prepared_boot_id_ = in.command.controller_boot_id;
            last_sequence_number_ = in.command.sequence_number;
            outputs_.ack_sequence_number = in.command.sequence_number;
            outputs_.ack_command_id_hi = in.command.command_id_hi;
            outputs_.ack_command_id_lo = in.command.command_id_lo;
            outputs_.state = kPrepared;
            outputs_.prepared_ack = true;
            outputs_.reason_code = kPreparedOk;
        }
    }

    if (commit_edge) {
        if (outputs_.state != kPrepared) {
            outputs_.rejected = true;
            outputs_.reason_code = kNotPrepared;
        } else if (in.local_commit_command_id_hi != prepared_command_id_hi_ ||
                   in.local_commit_command_id_lo != prepared_command_id_lo_) {
            outputs_.rejected = true;
            outputs_.reason_code = kCommandBindingMismatch;
        } else if (in.local_commit_controller_boot_id != prepared_boot_id_) {
            outputs_.rejected = true;
            outputs_.reason_code = kBootBindingMismatch;
        } else if (in.now_monotonic_ms >= prepared_expires_at_) {
            outputs_.state = kIdle;
            outputs_.rejected = true;
            outputs_.reason_code = kCommitExpired;
        } else if (!in.permissives.all_valid()) {
            outputs_.state = kIdle;
            outputs_.rejected = true;
            outputs_.reason_code = kFinalPermissiveInvalid;
        } else if (in.command.expected_state_hash32 != in.current_state_hash32) {
            outputs_.state = kIdle;
            outputs_.rejected = true;
            outputs_.reason_code = kMaterialStateChanged;
        } else {
            outputs_.state = kCommitted;
            outputs_.local_commit_ack = true;
            outputs_.reason_code = kLocallyCommitted;
        }
    }

    // The committed state is not terminal, and it must not be. The controlled source had
    // no path out of it: once committed, ExecutePermit stayed true for as long as the CPU
    // ran, because nothing assigned Executing, Complete or Idle again. A permit that
    // never clears is a standing authorisation to move, which is the one thing this whole
    // handshake exists to prevent.
    if (outputs_.state == kCommitted && in.procedure_running) {
        outputs_.state = kExecuting;
    }

    // CH1-AUT-FDS-0001's state diagram: Executing --critical fault--> FaultLatched. From
    // ANY state and BEFORE the permissive branch, which is defect 74: the procedure
    // latches on permissive loss, so both were true in one scan and the permissive branch
    // pre-empted this one.
    if (in.procedure_fault_latched && outputs_.state != kFaultLatched) {
        outputs_.state = kFaultLatched;
        outputs_.reason_code = kProcedureFaultLatched;
    }

    if (outputs_.state == kFaultLatched && !in.procedure_fault_latched) {
        outputs_.state = kIdle;
        outputs_.reason_code = kLocalRecoveryAccepted;
    }

    // A permissive lost mid-execution withdraws the permit immediately. This still fires
    // when the permissives go invalid WITHOUT the procedure latching - before a step has
    // started, where FB_CH1_Procedure's own guard is `if (step > 0)`.
    if ((outputs_.state == kCommitted || outputs_.state == kExecuting) &&
        !in.permissives.all_valid()) {
        outputs_.state = kIdle;
        outputs_.reason_code = kExecutionPermissiveLost;
    }

    // CH1-AUT-FDS-0001's state diagram: Executing --critical fault--> FaultLatched. From
    // ANY state and BEFORE the permissive branch, which is defect 74: the procedure
    // latches on permissive loss, so both were true in one scan and the permissive branch
    // pre-empted this one.

    // A permissive lost mid-execution withdraws the permit immediately. This still fires
    // when the permissives go invalid WITHOUT the procedure latching - before a step has
    // started, where FB_CH1_Procedure's own guard is `if (step > 0)`.


    if (outputs_.state == kExecuting && in.procedure_complete) {
        outputs_.state = kComplete;
        outputs_.reason_code = kExecutionFinished;
    }

    outputs_.execute_permit = (outputs_.state == kCommitted) || (outputs_.state == kExecuting);
    return outputs_;
}

// ------------------------------------------------------------------ FB_CH1_Procedure

ProcedureOutputs Procedure::scan(const ProcedureInputs& in) noexcept {
    const bool reset_edge = rising(in.local_reset_request, reset_previous_);
    outputs_.complete = false;

    if (!in.watchdog_healthy || in.stop_request || !in.permissives.all_valid()) {
        outputs_.actuator_enable = false;
        outputs_.running = false;
        if (outputs_.step > 0) {
            outputs_.fault_latched = true;
            outputs_.fault_code = kWatchdogStopOrPermissiveLost;
        }
    }

    if (outputs_.fault_latched) {
        outputs_.actuator_enable = false;
        outputs_.running = false;

        // Controlled recovery. The controlled source latched the fault and provided no
        // way to clear it, so a single watchdog dip left the block permanently dead with
        // no path back — and CH1-AUT-FDS-0001 requires recovery to verify the cause
        // removed, local authority, a reset edge and reconciled state.
        //
        // All four conditions are required here, and a reset never commands motion: it
        // returns the block to step 0 with the actuator off, where an execute permit
        // would still have to arrive through the whole handshake again.
        const bool cause_removed =
            in.watchdog_healthy && !in.stop_request && in.permissives.all_valid();
        if (reset_edge && cause_removed) {
            outputs_.fault_latched = false;
            outputs_.fault_code = kNoFault;
            outputs_.step = 0;
            step_timer_ms_ = 0;
        }

        return outputs_;
    }

    switch (outputs_.step) {
        case 0:
            outputs_.actuator_enable = false;
            outputs_.running = false;
            if (in.execute_permit && in.permissives.all_valid() && in.watchdog_healthy) {
                outputs_.step = 10;
                outputs_.running = true;
                step_timer_ms_ = 0;
            }
            break;

        case 10:
            outputs_.actuator_enable = true;
            outputs_.running = true;
            step_timer_ms_ += in.scan_interval_ms;
            if (step_timer_ms_ >= in.step_timeout_ms) {
                outputs_.actuator_enable = false;
                step_timer_ms_ = 0;
                outputs_.step = 20;
            }
            break;

        case 20:
            outputs_.actuator_enable = false;
            outputs_.running = false;
            outputs_.complete = true;
            outputs_.step = 0;
            break;

        default:
            outputs_.actuator_enable = false;
            outputs_.running = false;
            outputs_.fault_latched = true;
            outputs_.fault_code = kInvalidStep;
            break;
    }

    return outputs_;
}

}  // namespace cinerion::plc
