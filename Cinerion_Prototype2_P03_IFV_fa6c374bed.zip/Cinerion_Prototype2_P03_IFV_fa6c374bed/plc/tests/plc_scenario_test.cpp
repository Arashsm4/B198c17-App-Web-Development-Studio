// The PLCSIM scenarios, executed.
//
// plc/s7-1200-g2/tests/PLCSIM_SCENARIOS.md listed eleven controlled scenarios and said
// their results "remain not executed until a controlled TIA Portal/PLCSIM environment
// records them". That environment is a procurement gate, so the command handshake
// CH1-AUT-FDS-0001 specifies had never been run at all — not once, in any form.
//
// This runs every one of them against the host model in plc/host-model, which is a
// faithful translation of the controlled SCL. It does not replace PLCSIM: the eventual
// evidence still needs the CPU, the TIA version and the block hashes. What it does is
// stop the logic from being unexercised in the meantime, and it means a change to the
// guard has to survive the scenarios before anyone can compile it.
//
// scripts/check-plc-model.mjs reconciles this file, the model and the SCL, so a scenario
// cannot be quietly dropped and a reason code cannot exist in one and not the others.

#include "cinerion/plc_command_guard.hpp"

#include <cstdio>
#include <string_view>

namespace {

using namespace cinerion::plc;

int failures = 0;

void check(bool condition, std::string_view what) {
    std::printf("%s  %.*s\n", condition ? "PASS" : "FAIL", static_cast<int>(what.size()), what.data());
    if (!condition) ++failures;
}

constexpr std::uint32_t kRevision = 0x0001'0001;
constexpr std::uint32_t kStateHash = 0xABCD'1234;
constexpr std::uint64_t kBootId = 0x5555'0000'0000'0001ULL;

Permissives good() {
    return {.controller_online = true,
            .start_enable = true,
            .stop_circuit_healthy = true,
            .guard_healthy = true,
            .actuator_home = true,
            .fault_cause_active = false};
}

GuardInputs base(std::uint64_t now = 1000) {
    GuardInputs in{};
    in.enable = true;
    in.now_monotonic_ms = now;
    in.current_configuration_revision = kRevision;
    in.current_state_hash32 = kStateHash;
    in.current_controller_boot_id = kBootId;
    in.permissives = good();
    in.command.schema_major = 1;
    in.command.command_id_hi = 0xAAAA;
    in.command.command_id_lo = 0xBBBB;
    in.command.sequence_number = 1;
    in.command.expected_state_hash32 = kStateHash;
    in.command.configuration_revision = kRevision;
    in.command.controller_boot_id = kBootId;
    in.command.expires_at_monotonic_ms = now + 30'000;
    return in;
}

/// Drives one prepare edge: the SCL is edge-triggered, so a request must go low and high.
GuardOutputs prepare(CommandGuard& guard, GuardInputs in) {
    in.command.prepare_request = false;
    guard.scan(in);
    in.command.prepare_request = true;
    return guard.scan(in);
}

GuardOutputs commit(CommandGuard& guard, GuardInputs in) {
    in.local_commit_request = false;
    guard.scan(in);
    in.local_commit_request = true;
    in.local_commit_command_id_hi = in.command.command_id_hi;
    in.local_commit_command_id_lo = in.command.command_id_lo;
    in.local_commit_controller_boot_id = in.command.controller_boot_id;
    return guard.scan(in);
}

// --------------------------------------------------------------------- scenarios

void scenario_valid_semantic_prepare() {
    CommandGuard guard;
    const auto out = prepare(guard, base());
    check(out.state == kPrepared && out.prepared_ack && out.reason_code == kPreparedOk,
          "valid semantic prepare: state 10, prepared acknowledgement");
    check(!out.execute_permit,
          "valid semantic prepare: NO execution output — preparation is not authorisation");
}

void scenario_direct_register_or_start_attempt() {
    // There is no input on this block that starts a procedure. The only route to an
    // execute permit is prepare, then a local commit bound to the prepared command and
    // the boot identity. Setting everything else true must change nothing.
    CommandGuard guard;
    auto in = base();
    in.procedure_running = true;
    in.procedure_complete = true;
    in.local_commit_request = true;
    in.local_commit_command_id_hi = in.command.command_id_hi;
    in.local_commit_command_id_lo = in.command.command_id_lo;
    in.local_commit_controller_boot_id = kBootId;
    const auto out = guard.scan(in);

    check(!out.execute_permit && out.state == kIdle,
          "direct start attempt: no transition to execution without a prepare");
    check(out.rejected && out.reason_code == kNotPrepared,
          "direct start attempt: the commit is refused as NOT_PREPARED");
}

void scenario_duplicate_sequence() {
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);
    // Return to Idle so the repeat is judged on its sequence, not on the state.
    in.command.cancel_request = false;
    guard.scan(in);
    in.command.cancel_request = true;
    guard.scan(in);

    const auto out = prepare(guard, in);
    check(out.rejected && out.reason_code == kReplayOrDuplicate,
          "duplicate sequence: reject 203, no output");
    check(!out.execute_permit, "duplicate sequence: no execute permit");
}

void scenario_expired_prepare() {
    CommandGuard guard;
    auto in = base();
    in.command.expires_at_monotonic_ms = in.now_monotonic_ms;  // not greater than now
    const auto out = prepare(guard, in);
    check(out.rejected && out.reason_code == kExpired, "expired prepare: reject 204");
}

void scenario_revision_mismatch() {
    CommandGuard guard;
    auto in = base();
    in.command.configuration_revision = kRevision + 1;
    const auto out = prepare(guard, in);
    check(out.rejected && out.reason_code == kRevisionMismatch, "revision mismatch: reject 205");
}

void scenario_controller_reboot() {
    CommandGuard guard;
    auto in = base();
    check(prepare(guard, in).state == kPrepared, "controller reboot: prepared first");

    in.current_controller_boot_id = kBootId + 1;
    const auto out = guard.scan(in);
    check(out.state == kIdle && out.reason_code == kControllerRestarted,
          "controller reboot: cancelled to state 0, no restart");
    check(!out.execute_permit, "controller reboot: no execute permit survives");
}

void scenario_wrong_commit_binding() {
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);

    in.local_commit_request = false;
    guard.scan(in);
    in.local_commit_request = true;
    in.local_commit_command_id_hi = 0xDEAD;  // a different command
    in.local_commit_command_id_lo = in.command.command_id_lo;
    in.local_commit_controller_boot_id = kBootId;
    const auto out = guard.scan(in);

    check(out.rejected && out.reason_code == kCommandBindingMismatch,
          "wrong commit binding: reject 302");
    check(!out.execute_permit, "wrong commit binding: no execute permit");
}

void scenario_permissive_changes_at_commit() {
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);

    in.permissives.guard_healthy = false;  // guard dropped after prepare, before commit
    const auto out = commit(guard, in);

    check(out.rejected && out.reason_code == kFinalPermissiveInvalid,
          "permissive lost at commit: reject 305");
    check(out.state == kIdle && !out.execute_permit,
          "permissive lost at commit: cancelled, outputs off");
}

void scenario_communication_loss() {
    // Enable is the gateway session. Losing it must not queue a start, and restoring it
    // must not resume: the prepared state is gone and the whole handshake starts again.
    CommandGuard guard;
    auto in = base();
    check(prepare(guard, in).state == kPrepared, "communication loss: prepared first");

    in.enable = false;
    const auto lost = guard.scan(in);
    check(lost.state == kIdle && !lost.execute_permit, "communication loss: no queued start");

    in.enable = true;
    const auto restored = guard.scan(in);
    check(restored.state == kIdle && !restored.execute_permit,
          "communication loss: no automatic continuation after recovery");
}

void scenario_watchdog_failure() {
    Procedure procedure;
    ProcedureInputs in{};
    in.execute_permit = true;
    in.permissives = good();
    in.watchdog_healthy = true;
    procedure.scan(in);  // step 0 -> 10
    const auto running = procedure.scan(in);
    check(running.actuator_enable && running.step == 10, "watchdog failure: actuator on first");

    in.watchdog_healthy = false;
    const auto faulted = procedure.scan(in);
    check(!faulted.actuator_enable, "watchdog failure: actuator output off");
    check(faulted.fault_latched && faulted.fault_code == kWatchdogStopOrPermissiveLost,
          "watchdog failure: fault latched 901");

    // The controlled source could never leave this state: nothing cleared FaultLatched
    // and no reset input existed, so one watchdog dip disabled the block permanently.
    in.watchdog_healthy = true;
    const auto still = procedure.scan(in);
    check(still.fault_latched && !still.actuator_enable,
          "watchdog recovery: the cause returning is not enough on its own");

    in.local_reset_request = false;
    procedure.scan(in);
    in.local_reset_request = true;
    const auto reset = procedure.scan(in);
    check(!reset.fault_latched && reset.step == 0 && !reset.actuator_enable,
          "watchdog recovery: a local reset edge with the cause removed clears the latch");
    check(!reset.actuator_enable, "watchdog recovery: a reset never commands motion");
}

void scenario_acknowledge_only_traffic() {
    // A broker or OPC acknowledgement arriving without a LOCAL COMMIT. Prepare succeeds,
    // and nothing else may.
    CommandGuard guard;
    auto in = base();
    const auto prepared = prepare(guard, in);
    check(prepared.state == kPrepared, "acknowledge-only traffic: preparation stands");

    for (int scan = 0; scan < 20; ++scan) {
        const auto out = guard.scan(in);
        if (out.execute_permit) {
            check(false, "acknowledge-only traffic: an execute permit appeared without a commit");
            return;
        }
    }
    check(true, "acknowledge-only traffic: no physical execution without LOCAL COMMIT");
}

// Two scenarios the table did not contain, added because writing the model showed the
// controlled source could not satisfy them.

void scenario_execute_permit_is_not_permanent() {
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);
    const auto committed = commit(guard, in);
    check(committed.state == kCommitted && committed.execute_permit,
          "committed: the execute permit is granted");

    in.local_commit_request = false;
    in.procedure_running = true;
    const auto executing = guard.scan(in);
    check(executing.state == kExecuting && executing.execute_permit,
          "executing: the permit holds while the procedure runs");

    in.procedure_running = false;
    in.procedure_complete = true;
    const auto finished = guard.scan(in);
    // CH1-AUT-FDS-0001's state diagram: Executing --procedure passes--> Complete. The
    // guard used to go straight to Idle, so state 40 - which its State output has always
    // documented - was unreachable, and the completion nothing acknowledged.
    check(finished.state == kComplete && !finished.execute_permit,
          "completion: the execute permit CLEARS and the guard reaches Complete");
    check(finished.reason_code == kExecutionFinished, "completion: reported as 140");

    // And Complete is not terminal. Complete --acknowledge completion / new order--> Idle.
    in.procedure_complete = false;
    const auto still_complete = guard.scan(in);
    check(still_complete.state == kComplete && !still_complete.execute_permit,
          "completion: the guard stays in Complete until it is acknowledged");

    in.completion_acknowledged = true;
    const auto acknowledged = guard.scan(in);
    check(acknowledged.state == kIdle && !acknowledged.execute_permit,
          "acknowledge completion: the guard returns to Idle with no permit");
    check(acknowledged.reason_code == kCompletionAcknowledged,
          "acknowledge completion: reported as 141");

    // A SECOND procedure runs on the same CPU cycle set, through the whole handshake,
    // with the replay bound intact.
    in.completion_acknowledged = false;
    in.command.sequence_number = 1;
    in.command.prepare_request = true;
    const auto replayed = guard.scan(in);
    check(replayed.rejected && replayed.reason_code == kReplayOrDuplicate,
          "second order: the sequence already executed is still refused");
    in.command.prepare_request = false;
    guard.scan(in);
    in.command.sequence_number = 9;
    in.command.prepare_request = true;
    const auto second = guard.scan(in);
    check(second.state == kPrepared && second.prepared_ack,
          "second order: a new sequence is prepared on the same boot");
}

void scenario_new_order_leaves_complete() {
    // The other half of the label: "acknowledge completion / NEW ORDER". A valid PREPARE
    // arriving while the guard is Complete returns it to Idle and is then judged there,
    // rather than being refused 201 for a state the guard had no way to leave.
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);
    commit(guard, in);
    in.local_commit_request = false;
    in.procedure_running = true;
    guard.scan(in);
    in.procedure_running = false;
    in.procedure_complete = true;
    check(guard.scan(in).state == kComplete, "new order: the guard is Complete first");

    in.procedure_complete = false;
    in.command.prepare_request = false;
    guard.scan(in);
    in.command.sequence_number = 7;
    in.command.prepare_request = true;
    const auto out = guard.scan(in);
    check(out.state == kPrepared && out.prepared_ack && !out.rejected,
          "new order: the next PREPARE is accepted from Complete rather than refused 201");
    check(!out.execute_permit, "new order: preparation is still not authorisation");
}

void scenario_procedure_fault_latches_the_guard() {
    // CH1-AUT-FDS-0001's state diagram: Executing --critical fault--> FaultLatched. The
    // guard used to return to Idle only when the PERMISSIVES went invalid. A procedure
    // that latched its own fault while they were still valid - a step timeout, a
    // plausibility fault - left the guard in state 20 or 30 with ExecutePermit TRUE and
    // no event able to clear it: a standing authorisation to move.
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);
    commit(guard, in);
    in.local_commit_request = false;
    in.procedure_running = true;
    check(guard.scan(in).execute_permit, "procedure fault: the permit is held while running");

    in.procedure_running = false;
    in.procedure_fault_latched = true;
    const auto latched = guard.scan(in);
    check(latched.state == kFaultLatched && !latched.execute_permit,
          "procedure fault: the guard latches and withdraws the permit");
    check(latched.reason_code == kProcedureFaultLatched, "procedure fault: reported as 320");

    // A new order is refused while the fault stands, even with every permissive valid.
    in.command.prepare_request = false;
    guard.scan(in);
    in.command.sequence_number = 11;
    in.command.prepare_request = true;
    const auto refused = guard.scan(in);
    check(refused.rejected && refused.reason_code == kStateInvalid,
          "procedure fault: a new preparation is refused while the fault stands");
    check(!refused.execute_permit, "procedure fault: and no permit is granted");

    // Only the procedure's own controlled recovery - reset edge, cause removed,
    // permissives valid - clears it.
    in.command.prepare_request = false;
    in.procedure_fault_latched = false;
    const auto recovered = guard.scan(in);
    check(recovered.state == kIdle && !recovered.execute_permit,
          "procedure fault: the guard returns to Idle once the procedure clears its latch");
    check(recovered.reason_code == kLocalRecoveryAccepted, "procedure fault: reported as 330");
}

void scenario_permissive_lost_during_execution() {
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);
    commit(guard, in);
    in.local_commit_request = false;
    in.procedure_running = true;
    guard.scan(in);

    in.permissives.stop_circuit_healthy = false;
    const auto out = guard.scan(in);
    check(!out.execute_permit && out.state == kIdle,
          "permissive lost during execution: the permit is withdrawn immediately");
    check(out.reason_code == kExecutionPermissiveLost,
          "permissive lost during execution: reported as 310");
}


void scenario_permissive_loss_and_procedure_fault_in_one_scan() {
    // Defect 74, which was defect 69 re-entering through its own fix.
    //
    // FB_CH1_Procedure latches its own fault when a permissive is lost while Step > 0, so
    // in the real system BOTH of the guard's branches are true in the same scan. The
    // permissive branch ran first, sent the guard to state 0, and the fault branch could
    // then never fire because it only fired from 20 or 30 — so the guard sat at Idle with
    // the procedure latched. From Idle a fresh PREPARE is accepted the moment the
    // permissives return, commits to state 20, and grants an ExecutePermit that no
    // ProcedureRunning will ever follow.
    //
    // Every scenario before this one set exactly one of the two, which is why eleven
    // scenarios and a reconciliation gate all agreed the fix was sound.
    CommandGuard guard;
    auto in = base();
    prepare(guard, in);
    commit(guard, in);
    in.local_commit_request = false;
    in.procedure_running = true;
    check(guard.scan(in).execute_permit, "one scan: the permit is held while running");

    // Both at once, exactly as the CPU would see them.
    in.procedure_running = false;
    in.permissives.stop_circuit_healthy = false;
    in.procedure_fault_latched = true;
    const auto out = guard.scan(in);

    check(out.state == kFaultLatched,
          "one scan: a permissive lost AND a latched procedure leaves the guard LATCHED, not Idle");
    check(out.reason_code == kProcedureFaultLatched,
          "one scan: reported as 320, the stronger of the two conditions");
    check(!out.execute_permit, "one scan: and no permit");

    // The permissives come back while the procedure is still latched — which is the moment
    // the old ordering became dangerous rather than merely wrong.
    in.permissives = good();
    in.command.prepare_request = false;
    guard.scan(in);
    in.command.sequence_number = 21;
    in.command.prepare_request = true;
    const auto refused = guard.scan(in);
    check(refused.rejected && refused.reason_code == kStateInvalid,
          "one scan: with the permissives back and the procedure still latched, a new "
          "preparation is refused");
    check(!refused.execute_permit,
          "one scan: and no permit is granted against a cell that cannot execute");

    // Only the procedure's own controlled recovery clears it.
    in.command.prepare_request = false;
    in.procedure_fault_latched = false;
    const auto recovered = guard.scan(in);
    check(recovered.state == kIdle && recovered.reason_code == kLocalRecoveryAccepted,
          "one scan: the guard returns to Idle only when the procedure clears its own latch");
}

}  // namespace

int main() {
    scenario_valid_semantic_prepare();
    scenario_direct_register_or_start_attempt();
    scenario_duplicate_sequence();
    scenario_expired_prepare();
    scenario_revision_mismatch();
    scenario_controller_reboot();
    scenario_wrong_commit_binding();
    scenario_permissive_changes_at_commit();
    scenario_communication_loss();
    scenario_watchdog_failure();
    scenario_acknowledge_only_traffic();
    scenario_execute_permit_is_not_permanent();
    scenario_permissive_lost_during_execution();
    scenario_new_order_leaves_complete();
    scenario_procedure_fault_latches_the_guard();
    scenario_permissive_loss_and_procedure_fault_in_one_scan();

    if (failures == 0) {
        std::printf("\nPLC command handshake: every controlled scenario executed.\n");
        // Announced only after every assertion above has held. PLCSIM evidence against
        // the real CPU is still required and is still outstanding.
        std::printf("VERIFICATION-CASE CH1-VVT-TC-0011 CH1-VVT-TC-0016 CH1-VVT-TC-0017\n");
        return 0;
    }

    std::printf("\n%d check(s) failed.\n", failures);
    return 1;
}
