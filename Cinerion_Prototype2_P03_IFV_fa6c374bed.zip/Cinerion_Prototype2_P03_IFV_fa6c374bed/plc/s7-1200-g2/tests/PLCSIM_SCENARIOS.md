# PLCSIM controlled scenarios

These scenarios allocate the P03 verification cases.

**They are executed.** `plc/host-model/` is a faithful translation of the controlled SCL
in `01_Blocks/` — the same state numbers, the same reason codes, the same order of
evaluation — and `plc/tests/plc_scenario_test.cpp` runs every scenario below against it as
part of `./scripts/verify.sh` step `[9/13]`. `scripts/check-plc-model.mjs` (`npm run plc`)
fails when a reason code, a state or a scenario exists in the model and not in the SCL, or
the reverse.

That is not PLCSIM evidence and does not claim to be. **Results against the real CPU
remain not executed** until a controlled TIA Portal/PLCSIM environment records them, with
the evidence listed at the foot of this file. What has changed is that the logic is no
longer unexercised in the meantime: running these scenarios found two defects in the
controlled source, both recorded in the progress document as 37 and 38.

The last four rows come from reconciling this block against the CONTROLLED state diagram,
`docs/baseline/P03_IFV/assets/cell-state-machine.svg`, which `npm run cell:map` now parses
as a transition table rather than treating as a picture. Two of them are transitions the
diagram requires and the guard did not have: `Executing --procedure passes--> Complete`
followed by `Complete --acknowledge completion / new order--> Idle`, and
`Executing --critical fault--> FaultLatched`. The block documented states 40 and 90 on its
`State` output and assigned neither.

| Scenario | Stimulus | Expected result | Requirement/test |
|---|---|---|---|
| Valid semantic prepare | New sequence, correct schema/revision/state, valid preliminary permissives | State 10, prepared acknowledgement, no execution output | CH1-VVT-TC-0011 |
| Direct register/start attempt | Write any non-handshake tag or set procedure input without commit | No transition to execution; protected/absent write path | CH1-VVT-TC-0010, 0014 |
| Duplicate sequence | Repeat the accepted sequence | Reject 203; no output | CH1-VVT-TC-0015 |
| Expired prepare | Expiry not greater than monotonic time | Reject 204 | CH1-VVT-TC-0015 |
| Revision mismatch | Command revision differs from loaded configuration | Reject 205 | CH1-VVT-TC-0015 |
| Controller reboot | Change boot ID while state 10 | Cancel to state 0; no restart | CH1-VVT-TC-0018 |
| Wrong commit binding | Commit ID differs from prepared ID | Reject 302 | CH1-VVT-TC-0013 |
| Permissive changes at commit | Drop guard after prepare and before commit | Cancel; reject 305; outputs off | CH1-VVT-TC-0017 |
| Communication loss | Remove EdgeLink session during prepare/execution | No queued start or automatic continuation | CH1-VVT-TC-0025 |
| Watchdog failure | Drop watchdog while procedure step active | Actuator output off; fault latched | CH1-SAF-FR-0004 |
| Acknowledge-only traffic | Deliver broker/OPC acknowledgement without LOCAL COMMIT | No physical execution | CH1-COM-FR-0006 |
| Execute permit is not permanent | Run a procedure to completion | State 40; permit clears; then Idle only on acknowledgement 141 | CH1-VVT-TC-0011, 0012 |
| Permissive lost during execution | Drop the stop circuit while the procedure runs | Permit withdrawn immediately; reject 310 | CH1-VVT-TC-0017 |
| New order leaves Complete | Deliver a valid PREPARE while the guard is in state 40 | Returns to Idle and the preparation is judged there, not refused 201 | CH1-VVT-TC-0011 |
| Procedure fault latches the guard | Procedure latches its own fault with every permissive still valid | State 90; permit withdrawn; reject 320; a new preparation refused 201; Idle only on 330 | CH1-SAF-FR-0004, CH1-VVT-TC-0019 |
| Permissive loss and procedure fault in one scan | Drop the stop circuit while the procedure latches its own fault in the same scan | State 90, not 0; reject 320; a new preparation refused 201 even with the permissives back; Idle only on 330 | CH1-SAF-FR-0004, CH1-VVT-TC-0019 |

Evidence must include PLC type/order code or PLCSIM version, TIA version, block
hashes, watch table, input timeline, outputs, reason codes, screenshots/export,
operator, date, and independent witness when the later gate requires it.

