# Siemens S7-1200 G2 reference project

Target class: SIMATIC S7-1200 G2 CPU 1212C, programmed with STEP 7 Basic in
TIA Portal. The exact order code, AC/DC power variant, relay/transistor outputs,
OPC UA runtime licence, and any serial communication board/module remain
procurement gates.

This folder contains textual SCL sources and PLCSIM acceptance scenarios so the
logic remains reviewable outside a proprietary archive. A future controlled TIA
Portal archive must be exported with block comparison and checksum evidence.

The standard CPU is not credited as a safety controller. E-stop, guarding, and
other required safety functions remain independently designed and safety-rated.
The PLC accepts a versioned semantic handshake; the portal has no raw-register
write path.

## Import order

1. `00_Types/UDT_CH1_Command.scl`
2. `00_Types/UDT_CH1_Permissives.scl`
3. `01_Blocks/FB_CH1_CommandGuard.scl`
4. `01_Blocks/FB_CH1_Procedure.scl`
5. Create instance DBs and map the interface through controlled symbolic tags.

The sources are pre-hardware review material. Compilation and PLCSIM execution
must be recorded after the precise TIA Portal and CPU firmware versions are
selected.

