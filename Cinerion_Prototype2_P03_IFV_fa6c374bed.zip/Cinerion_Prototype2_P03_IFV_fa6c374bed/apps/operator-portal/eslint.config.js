// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require("eslint-config-expo/flat");
const globals = require("globals");

module.exports = defineConfig([
  expoConfig,
  {
    ignores: ["dist/*"],
  },
  {
    // The render harness is Node, not part of the app bundle. It is never imported by
    // src/ and Metro never sees it: it exists to load src/ into a DOM and read back what
    // the screens render. Declaring its environment here is what stops `Buffer` and
    // `process` reading as undefined globals; nothing about the portal's own lint rules
    // is relaxed by it.
    files: ["harness/**/*.mjs"],
    languageOptions: {
      globals: globals.node,
      sourceType: "module",
    },
  },
]);
