/**
 * The two vocabularies CH1-UXD-DSG-0001 requires to stay apart.
 *
 * "Contextual messages show author/service origin, object scope, priority, delivery
 * and acknowledgement, but use different iconography and verbs so users cannot
 * mistake `read` for `alarm acknowledged` or `fault cleared`."
 *
 * The API already keeps the two apart — a message receipt reports `kind: "Read"` and
 * `ch1.message_acknowledgements.acknowledgement_kind` is CHECK-constrained to that one
 * value — but a client is free to relabel what it renders. Holding both vocabularies
 * in one module, and proving below that they collide nowhere, is what stops the
 * separation from depending on each screen author remembering it.
 *
 * Iconography is carried by shape and letterform rather than colour or an emoji-prone
 * glyph: an alarm mark has square corners and a heavy border, a message mark is a
 * borderless pill. CH1-UXD-DSG-0001 requires status to survive without colour.
 */

export type SemanticKind = 'alarm' | 'message';
export type SemanticShape = 'square' | 'pill';

export interface SemanticVocabulary {
  readonly kind: SemanticKind;
  /** Letterform shown inside the mark. Never shared with the other vocabulary. */
  readonly mark: string;
  readonly shape: SemanticShape;
  readonly noun: string;
  /** Imperative shown on the control that records the act. */
  readonly actionVerb: string;
  /** Past tense shown once it has been recorded. */
  readonly recordedVerb: string;
  /** Stated next to the control, because what it does *not* do is the requirement. */
  readonly disclaimer: string;
}

/**
 * Acknowledging an alarm records that an operator saw it. It does not clear the
 * cause: `Alarm.Acknowledge` carries `CauseClear`, `ClearedAt`, `Priority` and
 * `ActivatedAt` through untouched, and the audit reason code for the event is
 * ACKNOWLEDGEMENT_DOES_NOT_CLEAR_CAUSE.
 */
export const AlarmSemantics = {
  kind: 'alarm',
  mark: 'ALM',
  shape: 'square',
  noun: 'Alarm',
  actionVerb: 'ACKNOWLEDGE ALARM',
  recordedVerb: 'ACKNOWLEDGED',
  disclaimer:
    'Acknowledging records that you saw this alarm. It does not clear the cause, satisfy an interlock or confirm a physical action.',
} as const satisfies SemanticVocabulary;

/**
 * A message receipt records that a recipient read it. `MessageAcknowledgement.Kind`
 * is the single value "Read", so the recorded verb here is the server's word rather
 * than a client relabelling of it.
 */
export const MessageSemantics = {
  kind: 'message',
  mark: 'MSG',
  shape: 'pill',
  noun: 'Message',
  actionVerb: 'MARK AS READ',
  recordedVerb: 'READ',
  disclaimer:
    'Marking a message read records receipt only. It acknowledges no alarm, clears no fault, satisfies no interlock and confirms no command.',
} as const satisfies SemanticVocabulary;

/**
 * Resolves to the string when the two differ and to a mismatch marker when they do
 * not, so an assignment of the string fails to compile. `[A] extends [B]` is wrapped
 * to stop a union distributing and reporting a partial overlap as a difference.
 */
type Distinct<A extends string, B extends string> = [A] extends [B]
  ? { readonly COLLIDES_WITH_THE_OTHER_VOCABULARY: B }
  : A;

/**
 * Compile-time proof that no alarm word is also a message word. `npm run check:portal`
 * fails if a future edit makes any pair equal, which is the point: CH1-UXD-DSG-0001
 * is not satisfied by intent, and a reviewer should not have to notice the collision.
 */
export const vocabularySeparation: readonly [
  Distinct<typeof AlarmSemantics.mark, typeof MessageSemantics.mark>,
  Distinct<typeof AlarmSemantics.actionVerb, typeof MessageSemantics.actionVerb>,
  Distinct<typeof AlarmSemantics.recordedVerb, typeof MessageSemantics.recordedVerb>,
  Distinct<typeof AlarmSemantics.shape, typeof MessageSemantics.shape>,
] = [
  AlarmSemantics.mark,
  AlarmSemantics.actionVerb,
  AlarmSemantics.recordedVerb,
  AlarmSemantics.shape,
];

/**
 * Alarm priority as CH1-AUT-FDS-0001 numbers it: 1 is the most urgent. Rendered as a
 * word as well as a number so the ranking does not depend on the reader knowing the
 * scale, and never as colour alone.
 */
export const AlarmPriorityLabel: Record<number, string> = {
  1: 'P1 CRITICAL',
  2: 'P2 HIGH',
  3: 'P3 MEDIUM',
  4: 'P4 LOW',
  5: 'P5 ADVISORY',
};

export function describeAlarmPriority(priority: number): string {
  return AlarmPriorityLabel[priority] ?? `P${priority}`;
}
