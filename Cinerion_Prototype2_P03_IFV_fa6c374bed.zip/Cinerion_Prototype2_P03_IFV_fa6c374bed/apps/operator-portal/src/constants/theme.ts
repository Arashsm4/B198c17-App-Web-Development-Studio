// Colours, spacing, corners and fonts. Change a value here and every screen changes its
// outfit.

import { Platform } from 'react-native';

export const Palette = {
  canvas: '#07121F',
  canvasRaised: '#0A1828',
  panel: '#0D1D2E',
  panelRaised: '#11263A',
  panelSoft: '#0B2030',
  line: '#1D3145',
  lineStrong: '#2C465D',
  ink: '#F1F7FB',
  inkSoft: '#A8BCCB',
  inkMuted: '#6F8799',
  teal: '#35D7C4',
  tealSoft: '#133D40',
  cyan: '#68CFF6',
  blue: '#4D8DFF',
  green: '#6FDAA6',
  greenSoft: '#12392D',
  amber: '#F4BC5E',
  amberSoft: '#402E18',
  red: '#F17478',
  redSoft: '#402125',
  violet: '#B09BF7',
  white: '#FFFFFF',
} as const;

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  huge: 48,
} as const;

export const Radius = {
  sm: 8,
  md: 12,
  lg: 18,
  pill: 999,
} as const;

export const Type = {
  sans: Platform.select({
    web: 'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    default: 'System',
  }),
  mono: Platform.select({
    web: '"SFMono-Regular", Consolas, "Liberation Mono", monospace',
    default: 'monospace',
  }),
} as const;

export const ContentMaxWidth = 1520;
export const SidebarWidth = 250;

