/**
 * Tone applied to a status indicator. Tone is always paired with explicit words in
 * the interface, never used as the sole carrier of meaning (CH1-MON-FR-0003).
 */
export type StatusTone = 'good' | 'warning' | 'danger' | 'info' | 'neutral';
