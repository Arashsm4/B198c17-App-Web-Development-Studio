// Lets TypeScript import .css files without a fuss.

declare module '*.css';
