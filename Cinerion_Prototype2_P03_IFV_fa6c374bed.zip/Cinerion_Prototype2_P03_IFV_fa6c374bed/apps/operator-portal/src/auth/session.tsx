// Sign-in, silent renewal and sign-out over OIDC. The portal only reads the token for display;
// Control Core checks it for real on every request.

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren,
} from 'react';
import { Platform } from 'react-native';
import * as AuthSession from 'expo-auth-session';
import { router } from 'expo-router';

import { identityConfigured, onUnauthenticated, portalConfig } from '@/api/client';
import type { PortalTokenClaims } from '@/api/contracts';

/**
 * Where the single-use PKCE artefacts live while the browser is away at the identity
 * provider.
 *
 * This is deliberately not a relaxation of the memory-only token rule below. A code
 * verifier and a request state are not credentials: the verifier is worthless without
 * the matching authorisation code, both are consumed once, and RFC 7636 requires the
 * client to still hold the verifier when the redirect comes back. `sessionStorage` is
 * scoped to this origin and this tab and is gone when the tab closes. Without this the
 * authorisation code returns to a freshly loaded page that has nothing to match it
 * against, and sign-in cannot complete at all.
 */
const PENDING_AUTHORIZATION_KEY = 'cinerion.oidc.pending-authorization';

interface PendingAuthorization {
  readonly state: string;
  readonly codeVerifier: string;
}

function sessionStore(): Storage | undefined {
  if (Platform.OS !== 'web' || typeof window === 'undefined') return undefined;
  try {
    return window.sessionStorage;
  } catch {
    // Storage can be denied outright by policy; treated as absent, not as an error.
    return undefined;
  }
}

function rememberPendingAuthorization(pending: PendingAuthorization): void {
  try {
    sessionStore()?.setItem(PENDING_AUTHORIZATION_KEY, JSON.stringify(pending));
  } catch {
    // A refusal to store surfaces later as an unresumable redirect, which is reported.
  }
}

/** Reads the pending authorisation and removes it, so it can only be redeemed once. */
function takePendingAuthorization(): PendingAuthorization | undefined {
  const store = sessionStore();
  if (!store) return undefined;
  try {
    const raw = store.getItem(PENDING_AUTHORIZATION_KEY);
    store.removeItem(PENDING_AUTHORIZATION_KEY);
    if (!raw) return undefined;
    const parsed = JSON.parse(raw) as Partial<PendingAuthorization>;
    return typeof parsed.state === 'string' && typeof parsed.codeVerifier === 'string'
      ? { state: parsed.state, codeVerifier: parsed.codeVerifier }
      : undefined;
  } catch {
    return undefined;
  }
}

interface ReturnedAuthorization {
  readonly code?: string;
  readonly state?: string;
  readonly error?: string;
  readonly errorDescription?: string;
}

/** What the identity provider put in the URL when it sent the browser back. */
function readReturnedAuthorization(): ReturnedAuthorization | undefined {
  if (Platform.OS !== 'web' || typeof window === 'undefined') return undefined;
  const params = new URLSearchParams(window.location.search);
  const code = params.get('code') ?? undefined;
  const error = params.get('error') ?? undefined;
  if (code === undefined && error === undefined) return undefined;
  return {
    code,
    state: params.get('state') ?? undefined,
    error,
    errorDescription: params.get('error_description') ?? undefined,
  };
}

/**
 * Removes the authorisation response from the address bar once it has been dealt with,
 * so a reload cannot replay a spent code and the code does not linger in history.
 *
 * Done through the router rather than `history.replaceState`, because the router keeps
 * the URL in sync with its own navigation state and simply puts the query back. The
 * redirect already returned the browser to the origin, so replacing the route with it
 * changes nothing on screen and only drops the spent parameters.
 */
function clearReturnedAuthorization(): void {
  if (Platform.OS !== 'web' || typeof window === 'undefined') return;
  try {
    router.replace('/');
  } catch {
    window.history.replaceState(null, '', window.location.pathname);
  }
}

interface RedirectReturn {
  readonly returned: ReturnedAuthorization;
  readonly pending: PendingAuthorization | undefined;
}

/**
 * Reads the authorisation response and the stored request, once per page load.
 *
 * Held at module scope rather than in a hook because that is the actual lifetime of
 * the thing: an authorisation response belongs to one page load, and both halves are
 * consumed on reading so neither can be redeemed twice. A React state initialiser
 * would be re-invoked under StrictMode in development, and the second call would find
 * the storage already emptied and wrongly report that the tab never started sign-in.
 */
let redirectReturnOfThisLoad: RedirectReturn | undefined;
let redirectReturnRead = false;

function consumeRedirectReturn(): RedirectReturn | undefined {
  if (redirectReturnRead) return redirectReturnOfThisLoad;
  redirectReturnRead = true;

  const returned = readReturnedAuthorization();
  if (!returned) return undefined;

  // The stored request is consumed here, so it can never be redeemed twice. The
  // address bar is cleaned separately, in an effect: the router rewrites the URL from
  // its own state while it mounts, so a scrub done now would simply be put back.
  const pending = takePendingAuthorization();
  redirectReturnOfThisLoad = { returned, pending };
  return redirectReturnOfThisLoad;
}

/**
 * Decodes the JWT payload for display and scoping only.
 *
 * This is deliberately not a verification. The portal cannot and must not decide
 * what a token authorises; Control Core revalidates the signature, issuer, audience
 * and expiry and re-evaluates project, cell and role scope on every request. These
 * claims only tell the interface which cells to ask about and whom to name.
 */
export function readTokenClaims(accessToken: string): PortalTokenClaims | undefined {
  const segments = accessToken.split('.');
  if (segments.length < 2) return undefined;
  try {
    const padded = segments[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = globalThis.atob(padded.padEnd(padded.length + ((4 - (padded.length % 4)) % 4), '='));
    return JSON.parse(json) as PortalTokenClaims;
  } catch {
    return undefined;
  }
}

/** Cell assignments come from the identity, not from a discovery endpoint. */
export function assignedCells(claims: PortalTokenClaims | undefined): readonly string[] {
  const raw = claims?.ch1_cell;
  if (raw === undefined) return [];
  // A multivalued attribute arrives as an array; a single assignment may arrive as
  // a bare string, so both shapes are normalised here.
  return typeof raw === 'string' ? [raw] : [...raw];
}

/**
 * How long the session has left, and whether anything is being done about it.
 *
 * `expiresAt` is the access token's own `exp` claim, in milliseconds. It is a fact about
 * the credential this tab is holding and is shown as such; it is NOT a claim about the
 * session at FortressGate, which outlives any one access token and whose end only the
 * provider can state.
 */
export interface SessionLifetime {
  readonly expiresAt: number | undefined;
  readonly refreshing: boolean;
  /** True once a refresh token has been held, so the interface can say renewal is possible. */
  readonly renewable: boolean;
}

export interface SessionState {
  readonly status:
    | 'unconfigured'
    | 'signed-out'
    | 'signing-in'
    | 'signed-in'
    /**
     * The session ENDED. Distinct from signed-out, which is a tab that never had one
     * or deliberately dropped it: `ended` is a session that was live and is not any
     * more, because the token expired and could not be renewed. The two read
     * identically to a component and differ entirely to an operator, who needs to know
     * whether work in progress was lost.
     */
    | 'ended'
    | 'error';
  readonly accessToken: string | undefined;
  readonly claims: PortalTokenClaims | undefined;
  readonly error: string | undefined;
  readonly lifetime: SessionLifetime;
  readonly signIn: () => void;
  readonly signOut: () => void;
}

const SessionContext = createContext<SessionState | undefined>(undefined);

export function useSession(): SessionState {
  const value = useContext(SessionContext);
  if (!value) throw new Error('useSession must be used inside SessionProvider.');
  return value;
}

/**
 * How close to expiry a token is renewed, in milliseconds.
 *
 * The realm declares no `accessTokenLifespan`, so Keycloak's default of five minutes
 * applies and the window is short. Renewing forty-five seconds early leaves room for a
 * slow round trip and for clock skew between this workstation and the provider, without
 * renewing so eagerly that an idle tab keeps a session alive it is not using — the
 * provider's own idle timeout still governs that, and this only ever ASKS.
 */
const RENEW_BEFORE_EXPIRY_MS = 45_000;

/** The soonest a renewal may be attempted again after one has just run. */
const MINIMUM_RENEWAL_INTERVAL_MS = 5_000;

export function SessionProvider({ children }: PropsWithChildren) {
  const discovery = AuthSession.useAutoDiscovery(portalConfig.oidcIssuer);
  const [accessToken, setAccessToken] = useState<string | undefined>(undefined);
  const [exchangeError, setExchangeError] = useState<string | undefined>(undefined);
  const [dismissedError, setDismissedError] = useState(false);
  /**
   * Why the session ended, when it did. Set only by a renewal that genuinely failed,
   * never by a request being refused: a 401 is the trigger to TRY, not a verdict.
   */
  const [endedReason, setEndedReason] = useState<string | undefined>(undefined);
  const [refreshing, setRefreshing] = useState(false);
  /**
   * Whether a refresh token is held, as state rather than as a read of the ref.
   *
   * The ref is the value used to renew and must not be read while rendering — a ref
   * carries no guarantee of being the value this render was produced from. This mirror
   * is set at the two moments the ref changes and is the only one the interface reads.
   */
  const [renewable, setRenewable] = useState(false);

  /**
   * The refresh token, held in memory exactly as the access token is.
   *
   * This is not a relaxation of the memory-only rule and is the same trade it already
   * made: a closed tab still ends the session, a reload still requires signing in, and
   * a cross-site scripting defect still finds no durable credential in any store. What
   * it buys is the thing that was missing — an operator part-way through a controlled
   * form no longer loses the session after five minutes for no visible reason.
   *
   * A ref rather than state, because nothing renders from it and a stale closure over
   * the value would renew with a token that has already been spent. Keycloak rotates
   * the refresh token on every use, so using an old one invalidates the whole chain.
   */
  const refreshToken = useRef<string | undefined>(undefined);
  /** Single-flight guard. A screen polling at 1 Hz can produce several 401s at once. */
  const renewalInFlight = useRef<Promise<boolean> | undefined>(undefined);
  const lastRenewalAt = useRef(0);
  /**
   * Whether this page load's authorisation code has already been presented.
   *
   * The exchange used to be guarded by "there is no access token yet", which was true
   * exactly once until the session could END. The moment a failed renewal cleared the
   * token, that effect ran again and re-presented an authorisation code the provider
   * had already spent — so an ended session would have reported `invalid_grant` from
   * the code exchange instead of saying the session ended, and on a provider that
   * tolerated the replay it would have silently resurrected a session that was over.
   * The code is redeemed once per page load, which is what single-use means.
   */
  const authorizationRedeemed = useRef(false);

  const redirectUri = useMemo(() => AuthSession.makeRedirectUri(), []);

  /**
   * Takes what the provider issued and makes it this tab's session.
   *
   * One place, because there are two ways in — a redirect that returns a code, and the
   * popup path native uses — and a refresh token kept by one and dropped by the other
   * would produce a session that renews on some workstations and not on others.
   */
  const acceptTokens = useCallback((tokens: AuthSession.TokenResponse) => {
    setAccessToken(tokens.accessToken);
    refreshToken.current = tokens.refreshToken ?? refreshToken.current;
    setRenewable(refreshToken.current !== undefined);
    setExchangeError(undefined);
    setEndedReason(undefined);
  }, []);

  const [request, response, promptAsync] = AuthSession.useAuthRequest(
    {
      clientId: portalConfig.oidcClientId,
      redirectUri,
      // openid yields sub and, on an interactive authentication, auth_time. Step-up
      // recency depends on auth_time, so the scope must not be narrowed.
      scopes: ['openid', 'profile'],
      usePKCE: true,
      responseType: AuthSession.ResponseType.Code,
    },
    discovery ?? null,
  );

  // The provider's own refusal is derived from the authorization response rather
  // than copied into state, so the effect below performs only the asynchronous code
  // exchange and never sets state synchronously while rendering.
  const authorizationError =
    response?.type === 'error' ? (response.error?.message ?? 'Authentication failed.') : undefined;

  /**
   * The authorisation response this page load came back with, if any, paired with the
   * request the tab stored before it left. Read once and held, so the outcome can be
   * derived during render exactly as the popup path's refusal above is, rather than
   * pushed into state from inside an effect.
   */
  const [redirectReturn] = useState(consumeRedirectReturn);

  /**
   * Why a returned authorisation cannot be exchanged, if it cannot.
   *
   * The state comparison is the CSRF check and is never skipped: a response whose
   * state does not match what this tab stored is refused rather than exchanged. Every
   * outcome here is reported, because the failure this replaced was silent — the code
   * came back to a page with no verifier to match it, was discarded, and the operator
   * was returned to the sign-in prompt with nothing said.
   */
  const redirectRefusal = useMemo(() => {
    if (!redirectReturn) return undefined;
    const { returned, pending } = redirectReturn;
    if (returned.error !== undefined) {
      return returned.errorDescription
        ? `${returned.error}: ${returned.errorDescription}`
        : returned.error;
    }
    if (!pending) {
      return 'The sign-in response arrived but this tab has no record of starting it. Start sign-in again from this tab.';
    }
    if (returned.state !== pending.state) {
      return 'The sign-in response did not match the request this tab started. It was refused.';
    }
    return undefined;
  }, [redirectReturn]);

  /**
   * Takes the spent authorisation response out of the address bar.
   *
   * Runs as a parent effect, so it happens after the router has finished writing its
   * own initial URL and is not undone by it. Without this the redeemed code stays in
   * the address bar and in history, and a plain page refresh would present it again —
   * to a tab whose stored request has already been consumed, which would report a
   * mismatch the operator did nothing to cause.
   */
  useEffect(() => {
    if (!redirectReturn) return;
    clearReturnedAuthorization();
  }, [redirectReturn]);

  // Completes a sign-in that came back as a full page load rather than through a
  // popup. Only the exchange happens here; every refusal was decided above.
  useEffect(() => {
    if (!discovery || !redirectReturn || redirectRefusal !== undefined) return;
    if (authorizationRedeemed.current) return;
    const { returned, pending } = redirectReturn;
    if (returned.code === undefined || !pending) return;
    authorizationRedeemed.current = true;

    let cancelled = false;
    AuthSession.exchangeCodeAsync(
      {
        clientId: portalConfig.oidcClientId,
        code: returned.code,
        redirectUri,
        extraParams: { code_verifier: pending.codeVerifier },
      },
      discovery,
    )
      .then((tokens) => {
        if (cancelled) return;
        acceptTokens(tokens);
      })
      .catch((cause: unknown) => {
        if (cancelled) return;
        setExchangeError(cause instanceof Error ? cause.message : 'Token exchange failed.');
      });

    return () => {
      cancelled = true;
    };
  }, [discovery, redirectReturn, redirectRefusal, redirectUri, acceptTokens]);

  useEffect(() => {
    if (!discovery || !request || response?.type !== 'success') return;

    let cancelled = false;
    AuthSession.exchangeCodeAsync(
      {
        clientId: portalConfig.oidcClientId,
        code: response.params.code,
        redirectUri,
        extraParams: request.codeVerifier ? { code_verifier: request.codeVerifier } : undefined,
      },
      discovery,
    )
      .then((tokens) => {
        if (cancelled) return;
        acceptTokens(tokens);
      })
      .catch((cause: unknown) => {
        if (cancelled) return;
        setExchangeError(cause instanceof Error ? cause.message : 'Token exchange failed.');
      });

    return () => {
      cancelled = true;
    };
  }, [response, discovery, request, redirectUri, acceptTokens]);


  /**
   * Renews the access token while the session at FortressGate is still alive.
   *
   * Returns whether this tab now holds a usable token. Three properties are deliberate.
   *
   * It is SINGLE-FLIGHT. Every screen polls once a second and several reads can be in
   * flight together, so an expired token produces a burst of refusals; without the
   * guard each would start its own renewal, and because Keycloak rotates the refresh
   * token on use, the second would present one the first had already spent and end a
   * session that was perfectly healthy.
   *
   * It FAILS CLOSED and says so. A refresh that the provider refuses means the session
   * really has ended — the idle timeout passed, an administrator revoked it, the user
   * signed out elsewhere — and the honest answer is to say the session ended rather
   * than to keep a dead token and let every screen read HTTP_401 beside a header that
   * claims AUTHENTICATED. That combination is the defect this replaces.
   *
   * It never RE-AUTHENTICATES by itself. Sending the browser back to the provider
   * unasked would discard whatever the operator had typed into a controlled form. The
   * interface states that the session ended and the operator chooses when to sign in
   * again.
   */
  const renew = useCallback(async (): Promise<boolean> => {
    if (renewalInFlight.current !== undefined) return renewalInFlight.current;
    const token = refreshToken.current;
    if (!discovery || token === undefined) return false;
    if (Date.now() - lastRenewalAt.current < MINIMUM_RENEWAL_INTERVAL_MS) return false;

    const attempt = (async () => {
      lastRenewalAt.current = Date.now();
      setRefreshing(true);
      try {
        const renewed = await AuthSession.refreshAsync(
          { clientId: portalConfig.oidcClientId, refreshToken: token },
          discovery,
        );
        if (!renewed.accessToken) throw new Error('The provider returned no access token.');
        acceptTokens(renewed);
        return true;
      } catch (cause) {
        // The refresh token is dropped whatever went wrong. Keycloak may have rotated
        // it and then failed, in which case the held value is already spent, and
        // retrying with a spent token is how one failed renewal becomes a loop.
        refreshToken.current = undefined;
        setRenewable(false);
        setAccessToken(undefined);
        setEndedReason(
          cause instanceof Error
            ? `The session could not be renewed: ${cause.message}`
            : 'The session could not be renewed.',
        );
        return false;
      } finally {
        setRefreshing(false);
        renewalInFlight.current = undefined;
      }
    })();

    renewalInFlight.current = attempt;
    return attempt;
  }, [discovery, acceptTokens]);

  const claims = useMemo(
    () => (accessToken ? readTokenClaims(accessToken) : undefined),
    [accessToken],
  );

  /** The token's own expiry, in milliseconds, or undefined when it does not state one. */
  const expiresAt = useMemo(
    () => (claims?.exp === undefined ? undefined : claims.exp * 1000),
    [claims],
  );

  /**
   * Renews before the token expires, rather than after a screen has been refused.
   *
   * This is the ordinary path and the 401 subscription below is the backstop. Scheduling
   * from the token's own `exp` means the renewal happens while the current token is
   * still valid, so nothing in flight is refused and no screen ever shows an error the
   * operator did not cause. A token already inside the window is renewed immediately,
   * which is what a tab left on a locked workstation comes back to.
   */
  useEffect(() => {
    if (expiresAt === undefined || accessToken === undefined) return;
    const delay = Math.max(0, expiresAt - Date.now() - RENEW_BEFORE_EXPIRY_MS);
    const timer = setTimeout(() => {
      void renew();
    }, delay);
    return () => clearTimeout(timer);
  }, [expiresAt, accessToken, renew]);

  /**
   * The backstop: the service refused this session's token.
   *
   * A clock that is wrong, a token revoked early, a provider that shortened the
   * lifespan — any of these produces a refusal before the scheduled renewal. The
   * refusal is not treated as a verdict: it triggers one renewal attempt, and only
   * that attempt's failure ends the session.
   */
  useEffect(() => {
    if (accessToken === undefined) return;
    return onUnauthenticated(() => {
      void renew();
    });
  }, [accessToken, renew]);

  // Tokens are held in memory only. They are never written to localStorage or any
  // other persistent store, so a cross-site scripting defect cannot exfiltrate a
  // durable credential and a closed tab ends the session. The cost is that a page
  // reload requires signing in again, which is the safer trade for an operations
  // console with command authority.
  //
  // On the web the browser is sent to the provider in this tab rather than in a popup.
  // expo-auth-session prefers a popup, but an operator workstation with popups blocked
  // then has no way to sign in at all, and the failure is invisible: the popup call
  // rejects into a promise nobody reads. A same-tab redirect is the ordinary OIDC web
  // flow, works everywhere, and costs nothing here because the token was never going
  // to survive a reload anyway. Native keeps the system-browser session, which is the
  // right primitive there and has no popup to block.
  const signIn = useCallback(() => {
    setExchangeError(undefined);
    setEndedReason(undefined);
    setDismissedError(true);

    if (Platform.OS !== 'web') {
      promptAsync().catch((cause: unknown) => {
        setExchangeError(cause instanceof Error ? cause.message : 'Sign-in could not be started.');
      });
      return;
    }

    if (!request || !discovery) {
      setExchangeError('The identity provider details are still loading. Try again in a moment.');
      return;
    }

    // The URL is built first: it is what populates the request's code verifier and
    // state, and both must be stored before this tab is navigated away.
    request
      .makeAuthUrlAsync(discovery)
      .then((url) => {
        if (!request.state || !request.codeVerifier) {
          setExchangeError('The sign-in request could not be prepared with proof of possession.');
          return;
        }
        rememberPendingAuthorization({
          state: request.state,
          codeVerifier: request.codeVerifier,
        });
        window.location.assign(url);
      })
      .catch((cause: unknown) => {
        setExchangeError(cause instanceof Error ? cause.message : 'Sign-in could not be started.');
      });
  }, [promptAsync, request, discovery]);

  const signOut = useCallback(() => {
    setAccessToken(undefined);
    // Dropped along with the access token: a tab that has been signed out must not be
    // able to renew itself back into a session.
    refreshToken.current = undefined;
    setRenewable(false);
    setExchangeError(undefined);
    // Deliberately NOT 'ended'. The operator asked for this, and a screen that reported
    // an expired session after a requested sign-out would be describing the wrong event.
    setEndedReason(undefined);
    setDismissedError(true);
  }, []);

  // A redirect refusal is dismissed on the next sign-in attempt, exactly as the popup
  // path's refusal is, so a stale message cannot outlive the attempt that produced it.
  const error =
    exchangeError ?? (dismissedError ? undefined : (redirectRefusal ?? authorizationError));

  // A returned code that has not been refused is an exchange in flight. Saying so
  // keeps the sign-in prompt from reappearing for the moment the exchange takes.
  const exchangingRedirect =
    redirectReturn !== undefined && redirectRefusal === undefined && accessToken === undefined;

  // A renewal in flight is still a live session: the current token has not been
  // discarded and screens go on reading with it. Only a renewal that FAILED ends one.
  const status: SessionState['status'] = !identityConfigured
    ? 'unconfigured'
    : accessToken
      ? 'signed-in'
      : endedReason !== undefined
        ? 'ended'
        : error
          ? 'error'
          : exchangingRedirect || response?.type === 'success'
            ? 'signing-in'
            : 'signed-out';

  const lifetime = useMemo<SessionLifetime>(
    () => ({ expiresAt, refreshing, renewable }),
    [expiresAt, refreshing, renewable],
  );

  const value = useMemo<SessionState>(
    () => ({
      status,
      accessToken,
      claims,
      // The ended reason is the operator-facing message for that state, and takes
      // precedence over a stale sign-in refusal from before the session existed.
      error: status === 'ended' ? endedReason : error,
      lifetime,
      signIn,
      signOut,
    }),
    [status, accessToken, claims, error, endedReason, lifetime, signIn, signOut],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}
