// Step-up for the risky stuff: prove it's still you, for this one purpose, right now.

import { useCallback, useState } from 'react';
import { Platform } from 'react-native';

import { apiPost } from '@/api/client';
import type { PasskeyGrant, PasskeyOptions, StepUpGrant } from '@/api/contracts';

/**
 * Purposes a step-up grant can be bound to. Mirrors StepUpPurpose in the domain: a
 * grant proves a recent authentication for *one* action, so proving it for a
 * reservation cannot authorise a release.
 */
export const StepUpPurpose = {
  PartRelease: 'PartRelease',
  NcrDisposition: 'NcrDisposition',
  WorkOrderRelease: 'WorkOrderRelease',
  RoleAssignment: 'RoleAssignment',
  CredentialAdministration: 'CredentialAdministration',
  DeviceTrust: 'DeviceTrust',
  ResourceAllocation: 'ResourceAllocation',
  ConfigurationPromotion: 'ConfigurationPromotion',
  PhysicalCommandPreparation: 'PhysicalCommandPreparation',
} as const;

export type StepUpPurposeName = (typeof StepUpPurpose)[keyof typeof StepUpPurpose];

/**
 * How a step-up is obtained.
 *
 * `Reauthenticate` asks Control Core to issue a grant from the strength the identity
 * provider already attested. `Passkey` performs a WebAuthn assertion, which is the
 * only route to phishing-resistant strength — the platform verifies the assertion
 * itself and raises the grant on that evidence, never on a client's say-so.
 */
export type StepUpMethod = 'Reauthenticate' | 'Passkey';

export interface StepUpState {
  readonly request: (purpose: StepUpPurposeName, method: StepUpMethod) => Promise<StepUpGrant | undefined>;
  readonly pending: boolean;
  readonly error: unknown;
  readonly grant: StepUpGrant | undefined;
  readonly clear: () => void;
}

/**
 * True when this browser can perform a WebAuthn assertion at all.
 *
 * Checked so the interface can say why the phishing-resistant route is unavailable
 * rather than offering a control that fails on press. CH1-UXD-DSG-0001 asks
 * authentication to guide users toward passkeys and explain step-up without exposing
 * policy internals; "your browser has no authenticator" is the honest explanation, and
 * it exposes nothing about the policy.
 */
export function passkeysAvailable(): boolean {
  return (
    Platform.OS === 'web' &&
    typeof globalThis !== 'undefined' &&
    typeof (globalThis as { PublicKeyCredential?: unknown }).PublicKeyCredential !== 'undefined' &&
    typeof navigator !== 'undefined' &&
    navigator.credentials !== undefined
  );
}

function base64UrlToBytes(value: string): Uint8Array {
  const padded = value.replace(/-/g, '+').replace(/_/g, '/');
  const binary = globalThis.atob(padded.padEnd(padded.length + ((4 - (padded.length % 4)) % 4), '='));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function bytesToBase64Url(buffer: ArrayBuffer): string {
  let binary = '';
  for (const byte of new Uint8Array(buffer)) binary += String.fromCharCode(byte);
  return globalThis.btoa(binary).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
}

/**
 * Obtains a single-use, purpose-bound step-up grant.
 *
 * The grant is held only for as long as it takes to issue the one request that
 * redeems it, and is never persisted: a grant that survived a reload would be a stored
 * elevation, which is exactly what makes step-up different from an ordinary session.
 */
export function useStepUp(accessToken: string | undefined): StepUpState {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<unknown>(undefined);
  const [grant, setGrant] = useState<StepUpGrant | undefined>(undefined);

  const request = useCallback(
    async (purpose: StepUpPurposeName, method: StepUpMethod): Promise<StepUpGrant | undefined> => {
      setPending(true);
      setError(undefined);
      try {
        const issued =
          method === 'Passkey'
            ? await assertPasskey(purpose, accessToken)
            : await apiPost<StepUpGrant>('/api/v1/auth/step-up', accessToken, { purpose });
        setGrant(issued);
        return issued;
      } catch (cause) {
        setError(cause);
        setGrant(undefined);
        return undefined;
      } finally {
        setPending(false);
      }
    },
    [accessToken],
  );

  const clear = useCallback(() => {
    setGrant(undefined);
    setError(undefined);
  }, []);

  return { request, pending, error, grant, clear };
}

/**
 * Runs the WebAuthn ceremony and exchanges the assertion for a grant.
 *
 * Every value the authenticator is given comes from the challenge Control Core issued.
 * The portal chooses no relying-party identifier and no origin — the server fixes both
 * from configuration and refuses a caller that tries to name its own, because a client
 * that could choose its origin could obtain an assertion for a site it controls, which
 * is precisely the phishing this credential class exists to prevent.
 */
async function assertPasskey(
  purpose: StepUpPurposeName,
  accessToken: string | undefined,
): Promise<PasskeyGrant> {
  if (!passkeysAvailable()) {
    throw new Error('This browser cannot perform a passkey assertion.');
  }

  const options = await apiPost<PasskeyOptions>('/api/v1/auth/passkey/options', accessToken, {
    purpose,
  });

  const assertion = (await navigator.credentials.get({
    publicKey: {
      challenge: base64UrlToBytes(options.challenge) as unknown as BufferSource,
      rpId: options.rpId,
      timeout: options.timeoutMilliseconds,
      userVerification: options.userVerification as UserVerificationRequirement,
      allowCredentials: options.allowCredentials.map((credential) => ({
        type: 'public-key' as const,
        id: base64UrlToBytes(credential.id) as unknown as BufferSource,
      })),
    },
  })) as PublicKeyCredential | null;

  if (!assertion) {
    throw new Error('The authenticator returned no assertion.');
  }

  const response = assertion.response as AuthenticatorAssertionResponse;
  return apiPost<PasskeyGrant>('/api/v1/auth/passkey/verify', accessToken, {
    challengeId: options.challengeId,
    credentialId: bytesToBase64Url(assertion.rawId),
    authenticatorData: bytesToBase64Url(response.authenticatorData),
    clientDataJson: bytesToBase64Url(response.clientDataJSON),
    signature: bytesToBase64Url(response.signature),
  });
}
