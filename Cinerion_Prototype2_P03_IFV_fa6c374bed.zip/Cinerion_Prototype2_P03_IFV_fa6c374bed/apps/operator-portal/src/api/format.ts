/**
 * How values returned by Control Core are rendered.
 *
 * Server timestamps are the record's own and are shown as issued, in UTC. They are
 * deliberately not converted to the browser's local zone: the audit chain, the
 * controller and every other operator see UTC, and a screen that quietly reinterpreted
 * a time would make two people reading the same record disagree about when it happened.
 */

/** `2026-08-09T00:50:13.482+00:00` → `2026-08-09 00:50:13Z`. */
export function instant(iso: string | null | undefined): string {
  if (!iso) return '—';
  const parsed = Date.parse(iso);
  if (Number.isNaN(parsed)) return iso;
  return `${new Date(parsed).toISOString().slice(0, 19).replace('T', ' ')}Z`;
}

/** `2026-08-09T00:50:13Z` → `00:50:13Z`, for a column where the date is a constant. */
export function timeOfDay(iso: string | null | undefined): string {
  if (!iso) return '—';
  const parsed = Date.parse(iso);
  if (Number.isNaN(parsed)) return iso;
  return `${new Date(parsed).toISOString().slice(11, 19)}Z`;
}

/**
 * How long ago, in the coarsest unit that is still honest. `now` comes from a clock
 * held in state, so an undefined one means the first tick has not arrived and the age
 * is genuinely not known yet.
 */
export function since(iso: string | null | undefined, now: number | undefined): string {
  if (!iso || now === undefined) return '—';
  const parsed = Date.parse(iso);
  if (Number.isNaN(parsed)) return iso;
  const seconds = Math.max(0, Math.round((now - parsed) / 1000));
  if (seconds < 60) return `${seconds} s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
  if (seconds < 86_400) return `${Math.floor(seconds / 3600)} h ago`;
  return `${Math.floor(seconds / 86_400)} d ago`;
}

/**
 * Trims a GUID for a dense column while keeping it selectable in full elsewhere. Only
 * ever used where the full identifier is available on the same screen.
 */
export function shortId(id: string | null | undefined): string {
  if (!id) return '—';
  return id.length > 13 ? `${id.slice(0, 8)}…${id.slice(-4)}` : id;
}
