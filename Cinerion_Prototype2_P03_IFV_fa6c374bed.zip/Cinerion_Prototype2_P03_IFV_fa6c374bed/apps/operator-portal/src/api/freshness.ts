// Decides when data stops being live and starts being stale. Old news gets labelled as old
// news.

import type { StatusTone } from '@/constants/status';
import type { DataQuality, Freshness } from './contracts';

/**
 * How old a successful read may be before the portal stops calling it current.
 * CH1-NFR-PER-0002 targets sub-1.5 s dashboard freshness, so a reading older than
 * this has missed several refresh cycles and must not be shown as live.
 */
export const STALE_AFTER_MS = 5_000;

export interface ObservedState<T> {
  readonly value: T | undefined;
  /** Server-declared freshness, downgraded by what the client actually observed. */
  readonly freshness: Freshness;
  readonly quality: DataQuality;
  readonly lastSuccessAt: number | undefined;
  readonly error: string | undefined;
}

/**
 * Resolves what the operator is actually entitled to believe.
 *
 * The server states the freshness of the reading it produced, but it cannot know
 * whether that reading ever arrived or how long ago. CH1-SWA-API-0001 requires
 * clients to display disconnected or stale state rather than assume continuity, so
 * client observation may only ever *downgrade* the server's claim, never raise it.
 */
export function resolveFreshness(
  declared: Freshness | undefined,
  lastSuccessAt: number | undefined,
  hasError: boolean,
  now: number,
): Freshness {
  if (lastSuccessAt === undefined) {
    return hasError ? 'Disconnected' : 'Unknown';
  }
  if (hasError) {
    return 'Disconnected';
  }
  if (now - lastSuccessAt > STALE_AFTER_MS) {
    return 'Stale';
  }
  return declared ?? 'Unknown';
}

/**
 * Text shown next to every freshness indicator. CH1-MON-FR-0003 requires live,
 * stale, disconnected, simulated, maintenance and unknown to be distinguishable
 * without relying on colour, so each state carries its own words and a distinct
 * leading glyph rather than only a tone.
 */
const freshnessPresentation: Record<Freshness, { label: string; glyph: string; tone: StatusTone }> = {
  Live: { label: 'LIVE', glyph: '●', tone: 'good' },
  Simulated: { label: 'SIMULATED', glyph: '◆', tone: 'info' },
  Stale: { label: 'STALE', glyph: '▲', tone: 'warning' },
  Disconnected: { label: 'DISCONNECTED', glyph: '✕', tone: 'danger' },
  Maintenance: { label: 'MAINTENANCE', glyph: '■', tone: 'warning' },
  Unknown: { label: 'UNKNOWN', glyph: '?', tone: 'neutral' },
};

export function describeFreshness(freshness: Freshness): { label: string; glyph: string; tone: StatusTone } {
  return freshnessPresentation[freshness] ?? freshnessPresentation.Unknown;
}

const qualityTone: Record<DataQuality, StatusTone> = {
  Good: 'good',
  Uncertain: 'warning',
  Bad: 'danger',
  Unknown: 'neutral',
};

export function describeQuality(quality: DataQuality): { label: string; tone: StatusTone } {
  return { label: quality.toUpperCase(), tone: qualityTone[quality] ?? 'neutral' };
}

/**
 * True when the portal is currently in touch with Control Core for this read.
 *
 * CH1-UXD-DSG-0001 requires a stale screen to disable consequential mutations and
 * offer reconciliation, so this is the gate on every control that writes. It asks
 * only about currency, not about measurement quality: a transactional list such as
 * alarms or reservations is read from the system of record and carries no per-reading
 * quality, so requiring one would disable a control that is perfectly safe to offer.
 */
export function isCurrentObservation(freshness: Freshness): boolean {
  return freshness === 'Live' || freshness === 'Simulated';
}

/**
 * True when the portal is still in touch, whatever the server said about the reading.
 *
 * For a response that declares no freshness of its own — a message thread, say, which
 * is a transactional read with nothing to be fresh about — {@link isCurrentObservation}
 * is the wrong question: the declared value is `Unknown`, so it answers false forever
 * and a control gated on it can never be used. This asks only what the client can
 * actually observe, which is whether the last poll reached the server.
 */
export function isLinkCurrent(freshness: Freshness): boolean {
  return freshness !== 'Stale' && freshness !== 'Disconnected';
}

/**
 * True only when a reading may be presented as a current, trustworthy value. Stricter
 * than {@link isCurrentObservation}: a sampled measurement also has to be of good
 * quality before anyone acts on the number itself.
 */
export function isActionable(freshness: Freshness, quality: DataQuality): boolean {
  return isCurrentObservation(freshness) && quality === 'Good';
}
