// Hook for one controlled write. Press the button twice and it still only goes once.

import { useCallback, useEffect, useRef, useState } from 'react';

import { apiDelete, apiPost, apiPut, type ControlledRequestOptions } from './client';

export interface ControlledAction<TResult> {
  /** Issues the operation. Resolves to the result, or undefined if it was refused. */
  readonly submit: (
    path: string,
    body?: unknown,
    options?: ControlledRequestOptions & { readonly method?: 'POST' | 'PUT' | 'DELETE' },
  ) => Promise<TResult | undefined>;
  readonly pending: boolean;
  /** The refusal itself, not a flattened string, so it can still be explained. */
  readonly error: unknown;
  readonly result: TResult | undefined;
  readonly reset: () => void;
}

/**
 * Performs one controlled mutation and reports what became of it.
 *
 * The hook deliberately holds no form state. CH1-UXD-DSG-0001 requires forms to
 * "preserve entered work on recoverable failure", and the reliable way to guarantee
 * that is for the code that issues the request to have no way of clearing the field:
 * the caller decides to clear, and only ever after a success it has seen.
 *
 * The refusal is kept as the original error rather than a message, because a caller
 * needs the distinction between a gate, a scope refusal and an unreachable service —
 * an operator who is told "refused" when the service is simply down will draw the
 * wrong conclusion about the plant.
 */
export function useControlledAction<TResult>(
  accessToken: string | undefined,
): ControlledAction<TResult> {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<unknown>(undefined);
  const [result, setResult] = useState<TResult | undefined>(undefined);
  const mounted = useRef(true);
  // Guards against a second submission while the first is in flight. Held in a ref
  // rather than read from `pending`, because state has not settled by the time a
  // double press arrives.
  const inFlight = useRef(false);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const submit = useCallback(
    async (
      path: string,
      body?: unknown,
      options?: ControlledRequestOptions & { readonly method?: 'POST' | 'PUT' | 'DELETE' },
    ): Promise<TResult | undefined> => {
      if (inFlight.current) return undefined;
      inFlight.current = true;
      setPending(true);
      setError(undefined);
      try {
        const next =
          options?.method === 'DELETE'
            ? await apiDelete<TResult>(path, accessToken, undefined, options)
            : options?.method === 'PUT'
              ? await apiPut<TResult>(path, accessToken, body, undefined, options)
              : await apiPost<TResult>(path, accessToken, body, undefined, options);
        if (mounted.current) {
          setResult(next);
          setError(undefined);
        }
        return next;
      } catch (cause) {
        if (mounted.current) {
          setError(cause);
          setResult(undefined);
        }
        return undefined;
      } finally {
        inFlight.current = false;
        if (mounted.current) setPending(false);
      }
    },
    [accessToken],
  );

  const reset = useCallback(() => {
    setError(undefined);
    setResult(undefined);
  }, []);

  return { submit, pending, error, result, reset };
}
