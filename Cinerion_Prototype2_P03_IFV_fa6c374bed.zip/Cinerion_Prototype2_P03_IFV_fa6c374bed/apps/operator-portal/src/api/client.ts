// The portal's one road to Control Core: where it lives, how to ask it things, and errors that
// say which way it went wrong.

import type { ApiError } from '@cinerion/contracts';

/**
 * Runtime configuration. Values arrive from EXPO_PUBLIC_* variables inlined at build
 * time. Nothing here is a secret: the API base URL, the OIDC issuer and the public
 * client identifier are all published values. There is no client secret because the
 * portal is a public client using authorization code with PKCE.
 */
export const portalConfig = {
  apiBaseUrl: process.env.EXPO_PUBLIC_CINERION_API_URL ?? 'http://localhost:5080',
  oidcIssuer: process.env.EXPO_PUBLIC_CINERION_OIDC_AUTHORITY ?? '',
  oidcClientId: process.env.EXPO_PUBLIC_CINERION_OIDC_CLIENT_ID ?? 'cinerion-operator-portal',
  /**
   * Where a SIMULATED cell controller can be asked to confirm a prepared command.
   *
   * Empty in any build that is not a laboratory, and the control that uses it does not
   * exist when it is empty - rather than existing and failing, which would leave an
   * operator wondering whether the cell was unreachable. It is a different SERVICE from
   * Control Core and is deliberately not derived from the API base URL: the portal has no
   * route to a controller-local operation and this must not look like one.
   */
  cellSimulatorUrl: process.env.EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL ?? '',
} as const;

/**
 * Identity is not configured unless an issuer was supplied. The portal reports this
 * as an explicit unavailable state rather than falling back to a guessed issuer or
 * to an unauthenticated mode, because either would misrepresent who is signed in.
 */
export const identityConfigured = portalConfig.oidcIssuer.length > 0;

/** A failed controlled operation, carrying the server's stable code and correlation id. */
export class CinerionApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    readonly correlationId: string | undefined,
    message: string,
  ) {
    super(message);
    this.name = 'CinerionApiError';
  }

  /** True when the caller is authenticated but not authorised for this object. */
  get isForbidden(): boolean {
    return this.status === 403;
  }

  /** True when the session is absent or no longer accepted. */
  get isUnauthenticated(): boolean {
    return this.status === 401;
  }

  /**
   * A controlled capability that exists in the P03 catalogue but is not enabled in
   * this build. Control Core answers 501 rather than a plausible-looking success,
   * and the portal reports exactly that instead of substituting sample data.
   */
  get isCapabilityGated(): boolean {
    return this.status === 501;
  }

  /**
   * The API answers 404 both for an object that does not exist and for one the
   * caller may not see, so that a probe cannot distinguish them. The portal must
   * therefore not claim which of the two occurred.
   */
  get isNotVisible(): boolean {
    return this.status === 404;
  }
}

/** Raised when the API could not be reached at all, as distinct from refusing. */
export class CinerionUnreachableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CinerionUnreachableError';
  }
}

function isApiError(value: unknown): value is ApiError {
  return typeof value === 'object' && value !== null && 'code' in value;
}

/**
 * Performs one authenticated read against the controlled API.
 *
 * The portal only ever issues domain reads and, later, PREPARE-class intents. It has
 * no route to credential proof or local commit; those are controller-local and the
 * repository policy check enforces their absence from this source tree.
 */
export async function apiFetch<T>(
  path: string,
  accessToken: string | undefined,
  signal?: AbortSignal,
): Promise<T> {
  return apiRequest<T>('GET', path, accessToken, undefined, signal);
}

/**
 * Controls a single mutation carries in addition to its body.
 *
 * A step-up grant and a version precondition are headers rather than body fields
 * because that is where the API puts them, and because both are properties of the
 * *request* rather than of the record: a grant authorises one attempt, and a version
 * says which state the caller believed it was acting on.
 */
export interface ControlledRequestOptions {
  /** Single-use grant identifier, sent as X-CH1-Step-Up. */
  readonly stepUpGrantId?: string;
  /** Entity version the caller read, sent as If-Match. */
  readonly ifMatchVersion?: number;
  /**
   * Caller-chosen key that makes one attempt safe to repeat, sent as Idempotency-Key.
   *
   * It belongs to the ATTEMPT, not to the content: a retry after a timeout must reuse the
   * same key so the server can answer with the record it already made, and a genuinely new
   * request must use a fresh one. Reusing a key for different content is refused with
   * IDEMPOTENCY_CONFLICT rather than silently overwriting, so a key is generated once when
   * a form is opened and held until that form succeeds.
   */
  readonly idempotencyKey?: string;
}

/**
 * Performs one controlled mutation. Restricted to operations that create evidence
 * or request a challenge; the portal has no route to credential proof or local
 * commit, and the repository policy check enforces their absence from this tree.
 */
export async function apiPost<T>(
  path: string,
  accessToken: string | undefined,
  body?: unknown,
  signal?: AbortSignal,
  options?: ControlledRequestOptions,
): Promise<T> {
  return apiRequest<T>('POST', path, accessToken, body, signal, options);
}

/**
 * Performs one controlled replacement.
 *
 * PUT is the method three controlled operations use and the portal had no way to issue:
 * `PUT /api/v1/users/{userId}/roles`, and the BOM and route authoring operations. The
 * catalogue gives it to no other verb, and this client still has no route to a
 * controller-local operation - `scripts/check-repository-policy.mjs` refuses
 * /credential-proofs and /local-commits anywhere in this tree, whatever the method.
 */
export async function apiPut<T>(
  path: string,
  accessToken: string | undefined,
  body?: unknown,
  signal?: AbortSignal,
  options?: ControlledRequestOptions,
): Promise<T> {
  return apiRequest<T>('PUT', path, accessToken, body, signal, options);
}

/**
 * Performs one controlled withdrawal — a reservation cancelled, not a record deleted.
 *
 * The only DELETE in the P03 catalogue that the portal issues is
 * DELETE /api/v1/reservations/{reservationId}, which keeps the cancelled row and
 * records who released the capacity and why. Nothing here removes stored evidence.
 */
export async function apiDelete<T>(
  path: string,
  accessToken: string | undefined,
  signal?: AbortSignal,
  options?: ControlledRequestOptions,
): Promise<T> {
  return apiRequest<T>('DELETE', path, accessToken, undefined, signal, options);
}

/**
 * Told when the service rejects this session's token, so the session can say so.
 *
 * The portal used to have no channel for this at all. An access token lives five
 * minutes by the realm's default, and when it expired every screen answered
 * `HTTP_401` while the header went on reporting SESSION: AUTHENTICATED — the state
 * the owner photographed. A read cannot mend a session and must not try, so what it
 * does instead is say that the service refused, and the one component that owns the
 * session decides what that means: refresh it silently, or state that it has ended.
 *
 * Deliberately a notification rather than a retry hook. A client that re-issued the
 * request itself would hide the refusal from the code that asked for it, and a refusal
 * this portal hides is a refusal an operator cannot act on.
 */
type UnauthenticatedListener = (path: string) => void;
const unauthenticatedListeners = new Set<UnauthenticatedListener>();

export function onUnauthenticated(listener: UnauthenticatedListener): () => void {
  unauthenticatedListeners.add(listener);
  return () => {
    unauthenticatedListeners.delete(listener);
  };
}

async function apiRequest<T>(
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  path: string,
  accessToken: string | undefined,
  body: unknown,
  signal?: AbortSignal,
  options?: ControlledRequestOptions,
): Promise<T> {
  const headers: Record<string, string> = {
    Accept: 'application/json',
    // Correlates the client request with the server audit record.
    'X-CH1-Correlation-Id': globalThis.crypto?.randomUUID?.() ?? `portal-${Date.now()}`,
  };
  if (accessToken) {
    headers.Authorization = `Bearer ${accessToken}`;
  }
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
  }
  if (options?.stepUpGrantId) {
    headers['X-CH1-Step-Up'] = options.stepUpGrantId;
  }
  if (options?.idempotencyKey) {
    headers['Idempotency-Key'] = options.idempotencyKey;
  }
  if (options?.ifMatchVersion !== undefined) {
    // Quoted as issued. Control Core accepts the bare number too, but sending the
    // ETag form keeps the portal honest about what it read.
    headers['If-Match'] = `"${options.ifMatchVersion}"`;
  }

  let response: Response;
  try {
    response = await fetch(`${portalConfig.apiBaseUrl}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal,
    });
  } catch (cause) {
    // A transport failure must surface as disconnected, never as stale-but-fine.
    throw new CinerionUnreachableError(
      cause instanceof Error ? cause.message : 'Control Core is unreachable.',
    );
  }

  if (response.ok) {
    return response.status === 204 ? (undefined as T) : ((await response.json()) as T);
  }

  let code = `HTTP_${response.status}`;
  let detail = response.statusText || 'The controlled operation was refused.';
  let correlationId: string | undefined;
  try {
    const problem: unknown = await response.json();
    if (isApiError(problem)) {
      code = problem.code ?? code;
      detail = problem.detail ?? detail;
      correlationId = problem.correlationId;
    }
  } catch {
    // A non-JSON error body is not itself an error; the status still stands.
  }
  if (response.status === 401) {
    // Announced after the body has been read, so a listener that reacts synchronously
    // cannot race the refusal this call is about to throw.
    for (const listener of unauthenticatedListeners) listener(path);
  }
  throw new CinerionApiError(response.status, code, correlationId, detail);
}
