// How a cell's permissives may be shown. "Not answered" never gets dressed up as "ready".

import type { CellState } from './contracts';

/**
 * What a cell's readiness envelope may be presented as.
 *
 * "Not permissive" and "nobody has been asked" are different facts, and CH1-MON-FR-0003
 * is precisely about keeping them apart in an operational view. The API distinguishes
 * them — `permissivesReported` says whether the controller answered its permissives *at
 * all* — and the domain resolves a cell whose controller has not answered as **not
 * permissive whatever the individual interlocks say**.
 *
 * That last part is load-bearing rather than fussy. Proto3 leaves an unset boolean
 * false, so a gateway that populates the interlocks and forgets the flag sends exactly
 * the dangerous message: six healthy-looking inputs and no statement that any of them
 * was read. A screen that counted those six would show a fully ready cell, in green, on
 * the strength of a default value.
 *
 * The rule lives here rather than on either screen so the two cannot disagree about it,
 * for the same reason `CellStateResolver` is the one place a cell is assembled
 * server-side.
 */
export const PERMISSIVES_NOT_ANSWERED = 'NOT ANSWERED';

/**
 * Why the count is withheld, in the words an operator needs. Deliberately says what
 * follows from it, not only that it happened: "unreported" is not a degraded reading of
 * the interlocks, it is the absence of any reading at all.
 */
export const PERMISSIVES_NOT_ANSWERED_EXPLANATION =
  'The controller has not reported its permissives, so this cell is not permissive whatever ' +
  'the individual inputs show. An unanswered permissive is treated as not satisfied, never as ' +
  'satisfied, because a report that was never made and one that came back healthy are ' +
  'indistinguishable in the wire format.';

export interface InterlockEntry {
  readonly label: string;
  readonly valid: boolean;
  readonly value: string;
}

/**
 * The six controlled interlocks, as the cell reported them.
 *
 * These are the raw inputs and stay raw: whether they may be *counted* is the separate
 * question {@link permissiveSummary} answers.
 */
export function interlockEntries(cell: CellState): readonly InterlockEntry[] {
  const i = cell.interlocks;
  return [
    { label: 'Controller online', valid: i.controllerOnline, value: i.controllerOnline ? 'Valid' : 'Not valid' },
    { label: 'Start enable', valid: i.startEnable, value: i.startEnable ? 'Valid' : 'Not valid' },
    { label: 'Stop circuit', valid: i.stopCircuitHealthy, value: i.stopCircuitHealthy ? 'Healthy' : 'Unhealthy' },
    { label: 'Guard input', valid: i.guardHealthy, value: i.guardHealthy ? 'Healthy' : 'Unhealthy' },
    { label: 'Actuator home', valid: i.actuatorHome, value: i.actuatorHome ? 'Confirmed' : 'Not confirmed' },
    { label: 'Fault cause', valid: !i.faultCauseActive, value: i.faultCauseActive ? 'ACTIVE' : 'Clear' },
  ];
}

/** True only when the controller actually answered. Never inferred from the interlocks. */
export function permissivesAnswered(cell: CellState | undefined): boolean {
  return cell?.permissivesReported === true;
}

/**
 * How the envelope reads. A cell nobody has answered for is never given a count, because
 * a count is a statement that the inputs were read.
 */
export function permissiveSummary(cell: CellState | undefined): string {
  if (!cell) return '—';
  if (!permissivesAnswered(cell)) return PERMISSIVES_NOT_ANSWERED;
  const entries = interlockEntries(cell);
  return `${entries.filter((entry) => entry.valid).length} / ${entries.length}`;
}

/**
 * The checks the controller declared it could not perform — 207
 * PRELIMINARY_PERMISSIVE_INVALID above all, which the OPC UA and Modbus profiles both
 * declare because a stand-in has no wired inputs to read. The reason is what an operator
 * needs, not the bare fact.
 */
export function deferredCheckSummary(cell: CellState | undefined): string | undefined {
  const codes = cell?.deferredCheckCodes ?? [];
  if (codes.length === 0) return undefined;
  return `Deferred checks: ${codes.join(', ')}`;
}
