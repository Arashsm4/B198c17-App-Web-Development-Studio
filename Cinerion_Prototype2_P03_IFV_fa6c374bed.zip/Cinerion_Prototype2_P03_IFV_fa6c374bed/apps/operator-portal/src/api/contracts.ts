// Every response shape the portal expects from Control Core. A gate checks these against what
// the service really sends, so no wishful typing.

import type { AuditEventContract, DataQuality, Freshness } from '@cinerion/contracts';

export type { DataQuality, Freshness };

/** GET /api/v1/system/health — the only anonymous operation. */
export interface SystemHealth {
  readonly status: string;
  readonly project: string;
  readonly namespace: string;
  readonly baseline: string;
  readonly version: string;
  readonly runtimeProfile: 'Simulation' | 'PrototypeElv' | 'Production';
  readonly dataFreshness: Freshness;
  readonly dataQuality: DataQuality;
  readonly simulation: boolean;
  readonly developmentIdentityEnabled: boolean;
  readonly safetyNotice: string;
  readonly time: string;
}

/**
 * GET /api/v1/projects — the stored governance record (table ch1.projects), not a
 * projection of the caller's token. An empty list means no project has been
 * established for this scope.
 */
export interface ProjectSummary {
  readonly projectId: string;
  readonly projectCode: string;
  readonly name: string;
  readonly baseline: string;
  readonly version: number;
  readonly createdAt: string;
}

/** GET /api/v1/sites/{siteId}/cells — cell state plus its registered name. */
export interface SiteCell extends CellState {
  readonly name: string | null;
}

/**
 * Local readiness permissives as reported by the controller. These are readiness
 * inputs for a controlled sequence, never a safety-rated protective function, and
 * the portal must not present them as one.
 */
export interface CellInterlocks {
  readonly controllerOnline: boolean;
  readonly startEnable: boolean;
  readonly stopCircuitHealthy: boolean;
  readonly guardHealthy: boolean;
  readonly actuatorHome: boolean;
  readonly faultCauseActive: boolean;
}

/** GET /api/v1/cells/{cellId}/state and GET /api/v1/sites/{siteId}/cells */
export interface CellState {
  readonly cellId: string;
  readonly siteId: string;
  readonly assetId: string;
  readonly controllerId: string;
  readonly state: string;
  readonly configurationRevision: string;
  readonly workOrderId: string;
  readonly partId: string;
  readonly interlocks: CellInterlocks;
  /**
   * Whether the controller answered its permissives AT ALL, which is a different fact
   * from answering "no". CH1-MON-FR-0003 is about keeping those apart: a cell whose
   * interlocks are false because a guard is open and a cell whose interlocks are false
   * because nobody has been asked look identical without this, and only one of them is
   * a machine fault.
   */
  readonly permissivesReported: boolean;
  /**
   * The checks the controller declared it could not perform - 207
   * PRELIMINARY_PERMISSIVE_INVALID above all, which the Modbus and OPC UA profiles both
   * declare because a stand-in has no wired inputs to read. This is the reason behind
   * permissivesReported being false, and an operator needs the reason rather than the
   * bare fact.
   */
  readonly deferredCheckCodes: readonly number[];
  readonly freshness: Freshness;
  readonly quality: DataQuality;
  readonly sourceTimestamp: string;
  readonly stateHash: string;
  /**
   * Where discussion of this cell lives. Derived from the object rather than
   * allocated, and additive: the P03 catalogue has no operation that issues a thread
   * identifier, so object pages carry it.
   */
  readonly contextThreadId: string;
}

export type PartStatus = 'InProcess' | 'Hold' | 'Accepted' | 'Released';
export type MeasurementResult = 'Pass' | 'Fail';

export interface QualityMeasurement {
  readonly measurementId: string;
  /**
   * The controlled test run this result was recorded against. CH1-MFG-FR-0002 requires
   * a part to resolve to its tests, and this is the link: a measurement with no run is
   * a number with no procedure behind it. The service has always sent it; the portal
   * did not read it until scripts/check-portal-contracts.mjs reported the field.
   */
  readonly testRunId: string;
  readonly characteristic: string;
  readonly value: number;
  readonly unit: string;
  readonly lowerLimit: number;
  readonly upperLimit: number;
  readonly mandatory: boolean;
  readonly sourceDeviceId: string;
  readonly calibrationRecordId: string;
  readonly supersedesMeasurementId: string | null;
  readonly calibrationValid: boolean;
  readonly measuredAt: string;
  readonly result: MeasurementResult;
}

export interface PartRecord {
  readonly projectId: string;
  readonly partId: string;
  readonly workOrderId: string;
  /** Identifier of the controlled revision that governed this part (CH1-MFG-FR-0002). */
  readonly revisionId: string;
  readonly serialNumber: string;
  readonly permanentIdentityUri: string;
  readonly operatorId: string;
  readonly status: PartStatus;
  readonly openNcrIds: readonly string[];
  readonly measurements: readonly QualityMeasurement[];
  readonly release: { readonly releaseId: string; readonly inspectorId: string; readonly releasedAt: string } | null;
}

/**
 * GET /api/v1/parts?serialNumber= — an owner-approved read, recorded in
 * traceability/owner-approved-operations.json for conflict 15.
 *
 * It resolves a controlled identity and nothing else: no history, and no scan event. The
 * evidence path stays POST /api/v1/parts/scan-events, bound to an enrolled Field
 * Companion device.
 */
export interface PartIdentity {
  readonly partId: string;
  readonly serialNumber: string;
  readonly permanentIdentityUri: string;
  readonly genealogy: string;
  readonly effect: string;
  readonly scanEventRecorded: boolean;
  readonly scanEventNote: string;
}

/** GET /api/v1/parts/{partId}/genealogy */
export interface PartGenealogy {
  readonly part: PartRecord;
  readonly provenance: string;
  readonly evidenceCompleteness: string;
  /**
   * Where discussion of this part lives. Derived from the object by Control Core rather
   * than allocated, exactly as the cell and alarm reads do it: the catalogue has no
   * operation that issues a thread identifier, so an object's own page carries the
   * derived value as an additive field.
   */
  readonly contextThreadId: string;
}

/** One measured channel value returned by GET /api/v1/telemetry. */
export interface TelemetrySample {
  readonly sampleId: string;
  readonly cellId: string;
  readonly deviceId: string;
  readonly channelId: string;
  readonly value: number;
  readonly unit: string;
  readonly quality: DataQuality;
  readonly freshness: Freshness;
  /** When the source observed the value. */
  readonly sampledAt: string;
  /** When Control Core stored it. Store-and-forward makes the two differ. */
  readonly receivedAt: string;
  readonly timeQuality: string;
}

/** One channel the controlled catalogue permits, with the limits that raise an alarm. */
export interface TelemetryChannel {
  readonly channelId: string;
  readonly unit: string;
  readonly lowerAlarmLimit: number;
  readonly upperAlarmLimit: number;
}

/** GET /api/v1/telemetry. The bounds actually applied travel with the rows. */
export interface TelemetryPage {
  readonly items: readonly TelemetrySample[];
  readonly count: number;
  /** A full page: there may be more inside the same window. */
  readonly truncated: boolean;
  readonly bounds: {
    readonly maximumRows: number;
    readonly defaultRows: number;
    readonly maximumWindowDays: number;
    readonly defaultWindowHours: number;
  };
  readonly channelAllowlist: {
    readonly version: string;
    readonly channels: readonly TelemetryChannel[];
  };
  readonly freshness: Freshness;
  readonly newestSampleAt: string | null;
}

/**
 * Alarm acknowledgement and alarm cause are separate state. Active and Acknowledged
 * both mean the cause is present; ReturnedUnacknowledged means the cause has gone but
 * the alarm latches until someone sees it. Only Cleared is terminal.
 */
export type AlarmState = 'Active' | 'Acknowledged' | 'ReturnedUnacknowledged' | 'Cleared';

/** One alarm as GET /api/v1/alarms projects it. */
export interface AlarmRecord {
  readonly alarmId: string;
  readonly cellId: string;
  readonly sourceId: string;
  readonly alarmCode: string;
  /** 1 is the most urgent. */
  readonly priority: number;
  readonly state: AlarmState;
  readonly activatedAt: string;
  readonly acknowledgedBy: string | null;
  readonly acknowledgedAt: string | null;
  readonly acknowledgementComment: string | null;
  /**
   * Whether the activation condition has been observed to have gone. Set by equipment
   * observation and never by an operator, which is why acknowledging cannot change it.
   */
  readonly causeClear: boolean;
  readonly clearedAt: string | null;
  readonly outstanding: boolean;
  readonly guidance: string;
  /** Where discussion of this alarm lives. Posting there acknowledges nothing. */
  readonly contextThreadId: string;
}

/** GET /api/v1/alarms. */
export interface AlarmPage {
  readonly items: readonly AlarmRecord[];
  readonly count: number;
  readonly nextCursor: string | null;
  /** As current as the telemetry that would clear these alarms. */
  readonly freshness: Freshness;
  readonly newestSampleAt: string | null;
  readonly asOf: string;
}

/** POST /api/v1/alarms/{alarmId}/acknowledgements. */
export interface AlarmAcknowledgement {
  readonly alarmId: string;
  readonly state: AlarmState;
  readonly acknowledgedBy: string;
  readonly acknowledgedAt: string;
  readonly acknowledgementComment: string;
  readonly causeClear: boolean;
  readonly clearedAt: string | null;
  readonly effect: string;
  /** The server's own statement of what did not happen. Rendered verbatim. */
  readonly controlSideEffect: string;
}

export type ContextObjectType =
  | 'Project'
  | 'Cell'
  | 'Asset'
  | 'Device'
  | 'Part'
  | 'WorkOrder'
  | 'Alarm'
  | 'Ncr'
  | 'Experiment';

export type MessagePriority = 'Routine' | 'Elevated' | 'Urgent';
export type ActorKind = 'Human' | 'Service' | 'Device' | 'System';

/**
 * A thread is derived from the controlled object it belongs to, never allocated: the
 * P03 catalogue contains no operation that creates one or hands out its identifier, so
 * object pages carry it as an additive optional field.
 */
export interface ContextThreadSummary {
  readonly threadId: string;
  readonly objectType: ContextObjectType;
  readonly objectId: string;
  readonly accessScope: {
    readonly roles: readonly string[];
    readonly actorIds: readonly string[];
  };
  readonly createdBy: string;
  readonly createdAt: string;
}

/**
 * One recipient's receipt. `kind` is the server's word and is always "Read" —
 * ch1.message_acknowledgements.acknowledgement_kind is CHECK-constrained to it — which
 * is why the portal renders the field rather than a label of its own.
 */
export interface ContextMessageReceipt {
  readonly recipientId: string;
  readonly acknowledgedAt: string;
  readonly kind: string;
}

export interface ContextMessage {
  readonly messageId: string;
  readonly threadId: string;
  readonly authorId: string;
  readonly authorKind: ActorKind;
  readonly priority: MessagePriority;
  readonly body: string;
  readonly createdAt: string;
  /** One honest value, `Published`: nothing pushes a message anywhere yet. */
  readonly deliveryState: string;
  readonly readBy: readonly ContextMessageReceipt[];
  readonly readCount: number;
  /** Always false, and CHECK-constrained to false in the schema. */
  readonly controlAuthority: boolean;
}

/** GET /api/v1/context-threads/{threadId}/messages. */
export interface ContextThreadPage {
  readonly thread: ContextThreadSummary;
  readonly items: readonly ContextMessage[];
  readonly count: number;
  readonly nextCursor: string | null;
  readonly bounds: {
    readonly maximumRows: number;
    readonly defaultRows: number;
    readonly maximumBodyLength: number;
  };
  readonly retention: {
    readonly message: string;
    readonly acknowledgement: string;
    readonly disposal: string;
    readonly standing: string;
  };
}

/** POST /api/v1/context-threads/{threadId}/messages. */
export interface PostedContextMessage {
  readonly thread: ContextThreadSummary;
  readonly message: ContextMessage;
}

/** POST /api/v1/context-messages/{messageId}/acknowledgements. */
export interface MessageReadReceipt {
  readonly messageAckId: string;
  readonly messageId: string;
  readonly recipientId: string;
  readonly acknowledgedAt: string;
  /** "Read". Never "Acknowledged" — CH1-UXD-DSG-0001 makes the word load-bearing. */
  readonly kind: string;
  readonly effect: string;
  readonly controlAuthority: boolean;
  /** The server's own statement of what did not happen. Rendered verbatim. */
  readonly controlSideEffect: string;
  readonly threadObject: { readonly type: ContextObjectType; readonly id: string };
}

/**
 * There is no `Reserved` state. Whether a resource is reserved depends on the interval
 * being asked about and is computed from its allocations; storing it would go stale the
 * moment a reservation started or ended.
 */
export type ResourceAvailabilityState = 'Available' | 'Maintenance' | 'Withdrawn';
export type AllocationStatus = 'Reserved' | 'Cancelled';

/** One reservation. Exactly one of workOrderId and experimentId is set. */
export interface ResourceAllocation {
  readonly allocationId: string;
  readonly resourceId: string;
  readonly workOrderId: string | null;
  readonly experimentId: string | null;
  readonly quantity: number;
  readonly startsAt: string;
  readonly endsAt: string;
  readonly status: AllocationStatus;
  readonly requestedBy: string;
  readonly version: number;
  readonly cancellationReason: string | null;
  readonly cancelledBy: string | null;
  readonly cancelledAt: string | null;
  /** A reservation holds capacity and starts nothing. Rendered verbatim. */
  readonly physicalEffect: string;
}

/**
 * An interval where committed capacity exceeds what the resource has. Reservations
 * refuse to over-commit, but capacity reduced administratively after the fact can
 * still leave an interval over-committed, and CH1-MGT-FR-0004 requires that state to
 * be exposed rather than merely prevented.
 */
export interface CapacityConflict {
  readonly from: string;
  readonly to: string;
  readonly committed: number;
  readonly capacity: number;
  readonly overCommittedBy: number;
}

export interface ResourceAvailability {
  readonly resourceId: string;
  readonly resourceType: string;
  readonly name: string;
  readonly capacity: number;
  readonly unit: string;
  readonly availabilityState: ResourceAvailabilityState;
  readonly acceptsReservations: boolean;
  /** The version a caller must echo in If-Match to reserve against this resource. */
  readonly version: number;
  readonly etag: string;
  readonly committedNow: number;
  readonly availableNow: number;
  readonly committedPeak: number;
  readonly peakAt: string;
  readonly availableAtPeak: number;
  readonly reservations: readonly ResourceAllocation[];
  readonly conflicts: readonly CapacityConflict[];
  readonly conflicted: boolean;
}

/** GET /api/v1/resources. */
export interface ResourcePage {
  readonly items: readonly ResourceAvailability[];
  readonly count: number;
  readonly nextCursor: string | null;
  readonly window: { readonly from: string; readonly to: string };
  readonly bounds: {
    readonly maximumRows: number;
    readonly defaultRows: number;
    readonly maximumWindowDays: number;
    readonly defaultWindowDays: number;
    readonly maximumReservationDays: number;
  };
  /** Read from the system of record at request time, so Live rather than Simulated. */
  readonly freshness: Freshness;
  readonly asOf: string;
}

/**
 * Authenticator strength, as Control Core ranks it. The portal never decides this —
 * it reads what the server granted, so a client cannot claim a class it did not reach.
 */
export type AuthenticationStrength =
  | 'SingleFactor'
  | 'Mfa'
  | 'StepUpPhishingResistant'
  | 'MutualTls';

/** POST /api/v1/auth/step-up, and the grant a verified passkey assertion returns. */
export interface StepUpGrant {
  readonly grantId: string;
  readonly purpose: string;
  readonly grantedStrength: AuthenticationStrength;
  readonly grantedAt: string;
  readonly expiresAt: string;
  /** Always true. A grant authorises one attempt at one action. */
  readonly singleUse: boolean;
}

/**
 * DELETE /api/v1/auth/sessions/{sessionId}.
 *
 * The session owner may end their own session with no step-up: someone who believes
 * their session is compromised must be able to end it immediately, and a step-up they
 * may be unable to complete would stand between them and doing so.
 */
export interface SessionRevocation {
  readonly sessionId: string;
  /** Always true in a success; a session that did not exist answers 400 instead. */
  readonly revoked: boolean;
  readonly ownSession: boolean;
  readonly subjectUsername: string | null;
  readonly revokedBy: string;
  readonly revokedAt: string;
  /** The server's own statement of why no anti-forgery token appears. Rendered verbatim. */
  readonly crossSiteRequestForgery: string;
}

/** POST /api/v1/auth/passkey/options. */
export interface PasskeyOptions {
  readonly challengeId: string;
  /** base64url. Passed to the authenticator, never interpreted here. */
  readonly challenge: string;
  readonly rpId: string;
  readonly origin: string;
  readonly purpose: string;
  readonly expiresAt: string;
  readonly timeoutMilliseconds: number;
  readonly userVerification: string;
  readonly allowCredentials: readonly {
    readonly type: string;
    readonly id: string;
    readonly label: string;
  }[];
  readonly singleUse: boolean;
}

/** POST /api/v1/auth/passkey/verify. */
export interface PasskeyGrant extends StepUpGrant {
  readonly credentialId: string;
  readonly label: string;
  readonly signCount: number;
  readonly effect: string;
  /** The server's own statement that it created no session. Rendered verbatim. */
  readonly sessionEffect: string;
}

export type CredentialKind = 'Passkey' | 'SecurityToken' | 'SmartCard' | 'Totp';
export type CredentialStatus = 'Active' | 'Suspended' | 'Revoked' | 'Expired';

/** An enrolled authenticator. Carries no secret, seed or private key. */
export interface CredentialSummary {
  readonly credentialId: string;
  readonly subjectId: string;
  readonly kind: CredentialKind;
  readonly label: string;
  readonly phishingResistant: boolean;
  readonly userVerification: string;
  readonly status: CredentialStatus;
  readonly serialNumber: string | null;
  readonly signCount: number;
  readonly enrolledBy: string;
  readonly enrolledAt: string;
  readonly lastUsedAt: string | null;
  readonly expiresAt: string | null;
  readonly revokedAt: string | null;
  readonly revokedBy: string | null;
  readonly revocationReason: string | null;
  readonly version: number;
  readonly platformTrustWithdrawn: boolean;
  /** False: the reader denylist lives in the cell controller, which is not enabled. */
  readonly readerDenylistUpdated: boolean;
}

/**
 * POST /api/v1/auth/totp/enrolments. The only disclosure of the shared secret; no
 * read operation returns it and it cannot be retrieved again.
 */
export interface TotpEnrolment {
  readonly credentialId: string;
  readonly subjectId: string;
  readonly kind: CredentialKind;
  readonly label: string;
  readonly sharedSecret: string;
  readonly otpauthUri: string;
  readonly algorithm: string;
  readonly digits: number;
  readonly periodSeconds: number;
  readonly driftStepsAccepted: number;
  /** Always false. A shared secret is not phishing resistant. */
  readonly phishingResistant: boolean;
  readonly disclosure: string;
  readonly assurance: string;
}

/** POST /api/v1/resources/{resourceId}/reservations. */
export interface ReservationReceipt extends ResourceAllocation {
  readonly physicalEffect: string;
}

export type RevisionLifecycleState = 'Draft' | 'Released' | 'Superseded' | 'Withdrawn';
export type WorkOrderStatus = 'Draft' | 'Released' | 'Complete' | 'Cancelled';

export interface BomLine {
  readonly componentCode: string;
  readonly quantity: number;
  readonly unit: string;
}

export interface RouteStep {
  readonly stepNumber: number;
  readonly operationCode: string;
  readonly description: string;
  readonly mandatoryInspection: boolean;
}

/**
 * One controlled revision, as GET /api/v1/products returns it.
 *
 * `sourceChecksum` is the revision's own content hash: CH1-MFG-FR-0003 requires a job
 * package to carry checksums, and this is the value a later reader reconciles against.
 * `version` is the optimistic concurrency token every write against the revision echoes.
 */
export interface ProductRevisionSummary {
  readonly revisionId: string;
  readonly productCode: string;
  readonly revisionCode: string;
  readonly lifecycleState: RevisionLifecycleState;
  readonly bom: readonly BomLine[];
  readonly route: readonly RouteStep[];
  readonly sourceChecksum: string;
  readonly releasedAt: string | null;
  readonly supersededAt: string | null;
  readonly version: number;
}

/**
 * GET /api/v1/products — products are projected from their revisions, because a product
 * exists in the controlled schema exactly when a revision of it does.
 */
export interface ProductGroup {
  readonly productCode: string;
  readonly revisions: readonly ProductRevisionSummary[];
}

/**
 * POST /api/v1/work-orders and POST /api/v1/work-orders/{workOrderId}/release.
 *
 * There is deliberately no read shape here, because the P03 catalogue contains no
 * operation that lists or fetches a work order. A client sees one only in the response
 * to a write it issued, or through the cell state that names the order loaded on that
 * cell. The work-order board is built from exactly those two sources and says so.
 */
export interface WorkOrderRecord {
  readonly workOrderId: string;
  readonly workOrderNumber: string;
  readonly revisionId: string;
  readonly cellId: string | null;
  readonly quantity: number;
  readonly status: WorkOrderStatus;
  readonly releasedBy: string | null;
  readonly releasedAt: string | null;
  readonly version: number;
}

/**
 * Claims the portal reads from the access token for navigation and scoping only.
 * They are never trusted for authorisation: Control Core revalidates the signed
 * token and re-evaluates project, cell and role scope on every request.
 *
 * @noCapturedResponse FortressGate issues these claims, not Control Core. There is no
 * Control Core operation that returns them, so there is no response to capture and
 * compare against — the reconciliation for this shape is the OIDC token itself, which
 * `scripts/check-repository-policy.mjs` already constrains (a realm that mapped
 * `ch1_auth_strength` fails the build). Every member is optional here because a token
 * that omits one is a real outcome the portal handles rather than a defect.
 */
export interface PortalTokenClaims {
  readonly sub?: string;
  readonly sid?: string;
  readonly preferred_username?: string;
  readonly ch1_project?: string;
  readonly ch1_cell?: readonly string[] | string;
  readonly roles?: readonly string[];
  readonly auth_time?: number;
  readonly exp?: number;
}

export type DeviceTrustState = 'Unknown' | 'Pending' | 'Trusted' | 'Revoked';

/**
 * GET /api/v1/devices/{deviceId} — the secret-free projection the catalogue requires.
 * There is no field for a private key, a seed or a topic credential, and there never
 * will be: CH1-CYB-CSRS-0001 keeps long-lived private keys non-exportable in the
 * device's own secure element, so material arriving here would mean that boundary had
 * already failed.
 */
export interface DeviceRecord {
  readonly deviceId: string;
  readonly cellId: string | null;
  readonly deviceType: string;
  readonly firmwareVersion: string;
  readonly configurationRevision: string;
  readonly certificateThumbprint: string | null;
  readonly trustState: DeviceTrustState;
  readonly trusted: boolean;
  readonly lastSeenAt: string | null;
  readonly revokedAt: string | null;
  readonly version: number;
  /**
   * "Reported" when the device has been heard from, "Unknown" when it has not. The
   * server states when it last heard from the device rather than asserting it is
   * online, because whether that reading is current is the reader's to judge.
   */
  readonly lastSeenQuality: 'Reported' | 'Unknown';
}

/**
 * The device as the revocation reports it.
 *
 * Deliberately its own shape rather than DeviceRecord with two fields added. The two
 * operations project the same entity differently: the read adds `lastSeenQuality`, the
 * revocation adds the revocation author, reason and capability manifest instead. Writing
 * this as an intersection with DeviceRecord declared `lastSeenQuality` on a response that
 * does not carry it — which is what scripts/check-portal-contracts.mjs caught, and the
 * reason it compares nested shapes rather than only the top level.
 */
export interface RevokedDeviceRecord {
  readonly deviceId: string;
  readonly cellId: string | null;
  readonly deviceType: string;
  readonly firmwareVersion: string;
  readonly configurationRevision: string;
  readonly certificateThumbprint: string | null;
  readonly trustState: DeviceTrustState;
  readonly trusted: boolean;
  readonly lastSeenAt: string | null;
  readonly revokedAt: string | null;
  /** Kept rather than cleared: a forgotten certificate could be presented elsewhere. */
  readonly revocationReason: string | null;
  readonly revokedBy: string | null;
  readonly version: number;
  readonly capabilityManifest: unknown | null;
}

/** POST /api/v1/devices/{deviceId}/revoke. */
export interface DeviceRevocation {
  readonly device: RevokedDeviceRecord;
  /**
   * The alarm the revocation raised. CH1-CYB-CSRS-0001 requires a trust-list change
   * to be visible as an alarm, and the guidance is the server's own words about what
   * to do next - rendered rather than reworded.
   */
  readonly alarm: {
    readonly alarmId: string;
    readonly alarmCode: string;
    readonly priority: number;
    readonly state: string;
    readonly guidance: string;
  } | null;
  readonly effect: {
    readonly platformTrustWithdrawn: boolean;
    readonly telemetryRefusedImmediately: boolean;
    readonly brokerTopicAclRevoked: boolean;
    readonly brokerTopicAclNote: string;
  };
}

/**
 * GET /api/v1/audit/events — the chain as the explorer reads it.
 *
 * Declared here rather than inside audit.tsx, and that move is the point: a response shape
 * declared on a screen typechecks perfectly and renders `undefined` at runtime exactly as
 * one declared here would, but `npm run contracts:portal` only reads this file — so a
 * shape on a screen was never compared against anything the service sent. The gate now
 * refuses a `useObserved<T>` whose T this file does not export.
 */
export interface AuditPage {
  readonly items: readonly AuditEventContract[];
  readonly count: number;
}

/** POST /api/v1/audit/chain-verifications — the tamper-detection answer. */
export interface ChainVerification {
  readonly verificationId: string;
  readonly valid: boolean;
  readonly checked: number;
  readonly failureAt: number | null;
  readonly verifiedAt: string;
  readonly verifiedBy: string;
}

/** One identity as FortressGate holds it. No credential field of any kind, by design. */
export interface DirectoryUser {
  readonly userId: string;
  readonly username: string;
  readonly displayName: string | null;
  readonly enabled: boolean;
  readonly projectId: string;
  readonly cellIds: readonly string[];
  readonly roles: readonly string[];
  readonly actorKind: string;
  readonly createdAt: string | null;
}

/** GET /api/v1/users — the project-scoped directory listing. */
export interface DirectoryPage {
  readonly items: readonly DirectoryUser[];
  readonly count: number;
  readonly nextCursor: string | null;
  readonly disclosure: string;
}

/**
 * GET /api/v1/calibrations — CH1-UX-SCR-0012.
 *
 * An owner-approved read, recorded in traceability/owner-approved-operations.json.
 * `expired` and `daysRemaining` are stated by Control Core rather than computed by a
 * screen: two screens subtracting dates for themselves is how two readers come to
 * disagree about whether an instrument was in calibration when a part was released.
 */
export interface CalibrationEntry {
  readonly calibrationId: string;
  readonly instrumentId: string;
  readonly certificateNumber: string;
  readonly calibratedAt: string;
  readonly validUntil: string;
  readonly status: string;
  readonly expired: boolean;
  readonly daysRemaining: number;
}

export interface CalibrationPage {
  readonly items: readonly CalibrationEntry[];
  readonly count: number;
  readonly asOf: string;
}

/**
 * GET /api/v1/parts/scan-events — CH1-UX-SCR-0015.
 *
 * There is deliberately no session-signature field. It is the proof the field device
 * authenticated with, and a register that handed it back would be handing back the means
 * to forge the next one.
 */
export interface ScanEventEntry {
  readonly scanEventId: string;
  readonly partId: string | null;
  readonly identifierKind: string;
  readonly identifierValue: string;
  readonly stationId: string;
  readonly deviceId: string;
  readonly scannedBy: string;
  readonly scannedAt: string;
  readonly receivedAt: string;
  readonly resolution: string;
  /** Present when this scan repeats one already recorded; it points at the first. */
  readonly duplicateOf: string | null;
}

export interface ScanEventPage {
  readonly items: readonly ScanEventEntry[];
  readonly count: number;
  readonly asOf: string;
}

/**
 * GET /api/v1/work-orders — CH1-UX-SCR-0006, recorded conflict 14.
 *
 * `releaseAuthority` travels on the response and is rendered: this read reports release
 * state and confers none.
 */
export interface WorkOrderBoardPage {
  readonly items: readonly WorkOrderRecord[];
  readonly count: number;
  readonly asOf: string;
  readonly releaseAuthority: string;
}

/**
 * GET /api/v1/experiments — CH1-UX-SCR-0020.
 *
 * `productionAuthority` is on every row and `isolationStatement` on the page, so a screen
 * cannot render an experiment as production work by omitting to say otherwise.
 */
export interface ExperimentSummary {
  readonly experimentId: string;
  readonly ownerId: string;
  readonly objective: string;
  readonly environment: string;
  readonly status: string;
  readonly createdAt: string;
  readonly version: number;
  readonly promotionRequested: boolean;
  readonly productionAuthority: boolean;
}

export interface ExperimentPage {
  readonly items: readonly ExperimentSummary[];
  readonly count: number;
  readonly asOf: string;
  readonly isolationStatement: string;
}

/** One recorded run, with the provenance CH1-RND-FR-0002 requires it to carry. */
export interface ExperimentRevisionRecord {
  readonly experimentRevisionId: string;
  readonly revisionNumber: number;
  readonly environment: string;
  readonly configurationReference: string;
  readonly configurationSha256: string;
  readonly modelReference: string;
  readonly inputReference: string;
  readonly inputSha256: string;
  readonly resultSummary: string;
  readonly resultSha256: string;
  readonly requestedBy: string;
  readonly executedBy: string;
  readonly startedAt: string;
  readonly finishedAt: string;
  readonly productionAuthority: boolean;
}

/**
 * GET /api/v1/experiments/{experimentId} — CH1-UX-SCR-0020 and CH1-UX-SCR-0021.
 *
 * `promotion` is null when none has been requested, rather than an object of empty
 * strings a review screen would render as a completed review.
 */
export interface ExperimentDetail {
  readonly experimentId: string;
  readonly ownerId: string;
  readonly objective: string;
  readonly environment: string;
  readonly status: string;
  readonly createdAt: string;
  readonly version: number;
  readonly productionAuthority: boolean;
  readonly promotion: {
    readonly changeRecord: string | null;
    readonly impactAnalysis: string | null;
    readonly verification: string | null;
    readonly requestedBy: string | null;
    readonly requestedAt: string | null;
  } | null;
  readonly revisions: readonly ExperimentRevisionRecord[];
  readonly revisionCount: number;
  readonly asOf: string;
  readonly promotionAuthority: string;
}

/**
 * A controller's answer to a prepared command, as the audit chain recorded it.
 *
 * Carried on the command read as a field DISTINCT from `state`, and shown that way. A
 * controller saying it received a command is evidence about delivery; the command
 * advances on a cryptographic credential proof and a physical button edge observed at
 * the cell. CH1-COM-PRO-0001 is explicit that "a QoS acknowledgement is never treated as
 * physical execution", and the same holds for a controller's own answer.
 */
export interface ControllerAcknowledgement {
  readonly eventId: string;
  readonly gatewayIdentity: string;
  readonly accepted: boolean;
  readonly decision: string;
  readonly recordedAt: string;
  readonly timeQuality: string;
  readonly eventHash: string;
}

/**
 * One immutable link into the audit chain: what happened, who caused it, what was
 * decided, and the hash that makes altering it detectable.
 *
 * The payload itself never crosses this boundary — only `payloadHash`. A command read is
 * project- and object-scoped; the audit endpoint is where a reader with audit authority
 * goes for content, and duplicating it here would widen a read authority both controlled
 * documents agree on.
 */
export interface AuditLink {
  readonly eventId: string;
  readonly sequence: number;
  readonly eventType: string;
  readonly actorId: string;
  readonly actorKind: string;
  readonly decision: string;
  readonly reasonCode: string;
  readonly occurredAt: string;
  readonly timeQuality: string;
  readonly payloadHash: string;
  readonly eventHash: string;
}

/** The semantic intent a preparation was bound to. */
export interface PrepareIntent {
  readonly commandType: string;
  readonly projectId: string;
  readonly siteId: string;
  readonly cellId: string;
  readonly assetId: string;
  readonly workOrderId: string;
  readonly partId: string;
  readonly procedureRevision: string;
  readonly configurationRevision: string;
  readonly expectedStateHash: string;
  readonly sequence: number;
  readonly expiresAt: string;
  readonly idempotencyKey: string;
}

/**
 * One guarded command transaction, with what the equipment answered and the evidence
 * for both.
 *
 * `physicalConfirmationRequired` and `remoteStartAvailable` are sent on every response
 * and are not decoration: a client reads the response, not the source, and the shape
 * must never let a reader infer that this application could start equipment.
 * `acknowledgementIsNotExecution` is there for the same reason.
 */
export interface CommandTransaction {
  readonly commandId: string;
  readonly confirmationId: string;
  readonly correlationId: string;
  readonly requesterId: string;
  readonly state: string;
  readonly intent: PrepareIntent;
  readonly preparedAt: string;
  readonly credentialProof: unknown | null;
  readonly localCommitId: string | null;
  readonly terminalReason: string | null;
  readonly version: number;
  readonly physicalConfirmationRequired: boolean;
  readonly remoteStartAvailable: boolean;
  readonly acknowledgements: readonly ControllerAcknowledgement[];
  readonly acknowledgementIsNotExecution: boolean;
  readonly auditLinks: readonly AuditLink[];
}
