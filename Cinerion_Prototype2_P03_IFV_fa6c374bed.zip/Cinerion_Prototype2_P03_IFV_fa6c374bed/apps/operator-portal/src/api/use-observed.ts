// Hook that keeps polling a read and remembers when it last worked. The heartbeat of every
// live screen.

import { useCallback, useEffect, useState } from 'react';

import { CinerionApiError, CinerionUnreachableError, apiFetch } from './client';
import type { DataQuality, Freshness } from './contracts';
import { resolveFreshness } from './freshness';

/** Refresh cadence. CH1-NFR-PER-0002 targets sub-1.5 s dashboard freshness. */
export const POLL_INTERVAL_MS = 1_000;

/**
 * The wall clock, advanced by a timer rather than read during render.
 *
 * A component that called `Date.now()` while rendering would produce a different
 * result each time React happened to re-render it, which is the impurity the same
 * concern in {@link useObserved} avoids. Returns undefined until the first tick, so a
 * caller shows "unknown" rather than an age computed against an epoch of zero.
 */
export function useWallClock(): number | undefined {
  const [now, setNow] = useState<number | undefined>(undefined);

  useEffect(() => {
    // Seeded out of the effect body for the same reason as in useObserved: no state
    // is touched during render or synchronously while the effect runs.
    const seed = setTimeout(() => setNow(Date.now()), 0);
    const timer = setInterval(() => setNow(Date.now()), POLL_INTERVAL_MS);
    return () => {
      clearTimeout(seed);
      clearInterval(timer);
    };
  }, []);

  return now;
}

export interface Observed<T> {
  readonly value: T | undefined;
  readonly freshness: Freshness;
  readonly quality: DataQuality;
  readonly error: string | undefined;
  /**
   * The refusal itself, kept alongside the message.
   *
   * A flattened string cannot be classified, so a caller that only had `error` had to
   * wrap it in a fresh Error and every refusal then rendered as "unexpected client
   * failure" — a scope refusal, a controlled gate and a genuine client fault all
   * reading alike. `explainFailure` needs the original to tell them apart.
   */
  readonly cause: unknown;
  readonly loading: boolean;
  readonly refresh: () => void;
}

interface Snapshot<T> {
  readonly value?: T;
  readonly error?: string;
  readonly cause?: unknown;
  readonly lastSuccessAt?: number;
}

function describeFailure(cause: unknown): string {
  if (cause instanceof CinerionApiError) return `${cause.code}: ${cause.message}`;
  if (cause instanceof CinerionUnreachableError) return cause.message;
  return 'Unexpected client failure.';
}

/**
 * Polls one controlled read and reports what the operator may believe about it.
 *
 * The last value is retained when a refresh fails so the screen does not blank out,
 * but freshness drops to Disconnected at the same moment. Showing the last known
 * reading is acceptable; showing it as current is not.
 *
 * The wall clock is held in state and advanced by the poll timer rather than read
 * during render, so a reading that simply stops arriving still transitions to Stale
 * on screen without the component reading an impure value while rendering.
 */
export function useObserved<T>(
  path: string | undefined,
  accessToken: string | undefined,
  declaredFreshness: (value: T) => Freshness = () => 'Unknown',
  declaredQuality: (value: T) => DataQuality = () => 'Unknown',
): Observed<T> {
  const enabled = path !== undefined && accessToken !== undefined;
  const [snapshot, setSnapshot] = useState<Snapshot<T>>({});
  const [observedAt, setObservedAt] = useState(0);
  const [tick, setTick] = useState(0);

  const refresh = useCallback(() => setTick((current) => current + 1), []);

  useEffect(() => {
    if (!enabled) return;

    let cancelled = false;
    const controller = new AbortController();

    apiFetch<T>(path, accessToken, controller.signal)
      .then((next) => {
        if (cancelled) return;
        const at = Date.now();
        setSnapshot({ value: next, lastSuccessAt: at, error: undefined, cause: undefined });
        setObservedAt(at);
      })
      .catch((cause: unknown) => {
        if (cancelled || controller.signal.aborted) return;
        setSnapshot((previous) => ({ ...previous, error: describeFailure(cause), cause }));
        setObservedAt(Date.now());
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [path, accessToken, enabled, tick]);

  useEffect(() => {
    if (!enabled) return;
    // Seeds the clock without touching state during render or synchronously in the
    // effect body, then keeps both the clock and the refetch on the same cadence.
    const seed = setTimeout(() => setObservedAt(Date.now()), 0);
    const timer = setInterval(() => {
      setObservedAt(Date.now());
      setTick((current) => current + 1);
    }, POLL_INTERVAL_MS);
    return () => {
      clearTimeout(seed);
      clearInterval(timer);
    };
  }, [enabled]);

  const value = enabled ? snapshot.value : undefined;
  const error = enabled ? snapshot.error : undefined;
  const freshness = resolveFreshness(
    value ? declaredFreshness(value) : undefined,
    enabled ? snapshot.lastSuccessAt : undefined,
    error !== undefined,
    observedAt,
  );

  return {
    value,
    freshness,
    quality: value && error === undefined ? declaredQuality(value) : 'Unknown',
    error,
    cause: enabled ? snapshot.cause : undefined,
    loading: enabled && value === undefined && error === undefined,
    refresh,
  };
}
