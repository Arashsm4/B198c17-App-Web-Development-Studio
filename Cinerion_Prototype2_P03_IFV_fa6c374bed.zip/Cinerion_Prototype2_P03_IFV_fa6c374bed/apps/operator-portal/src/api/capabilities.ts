/**
 * Which acts this portal offers, and which identity owns each one.
 *
 * The portal used to decide that ad hoc. Eight screens carried their own
 * `roles.includes('Engineer')` written where the control happened to be, so the same
 * authority was spelled differently in different places, a screen could quietly widen one
 * and nothing would notice, and an identity that held none of a screen's roles was shown
 * a blank panel rather than being told who to ask. This is the single place that decides
 * it, and `npm run capabilities` reconciles every line of it against the two controlled
 * sources: `docs/baseline/P03_IFV/data/api_endpoints.json` for the operation and the
 * authority PHRASE, and `traceability/controlled-authorities.json` for the roles that
 * phrase maps to.
 *
 * Three rules govern the whole file, and the gate enforces all three.
 *
 * **It never widens an authority.** `roles` here must be a subset of the roles the
 * authority register maps that phrase to. Narrowing is permitted and has to be explained;
 * widening is refused outright, because a portal that offers an act to a role the
 * controlled document does not name has made an authority decision nobody recorded.
 *
 * **It never pre-judges the server.** Holding the role means the control is OFFERED, not
 * that the act will succeed. Project scope, cell assignment, authentication strength,
 * equipment state, calibration validity and two-person rules are all evaluated by Control
 * Core on the request, and several of them cannot be known here at all. A control that
 * greyed itself out on a guess would be asserting a decision the portal did not make; a
 * refusal is shown verbatim instead. This is the same rule `ControlledActionForm`
 * documents, stated once for every act rather than once per form.
 *
 * **An act nobody here owns is NAMED, not hidden.** An operator who cannot do something
 * needs to know the act exists and who holds it, because the next step is to ask that
 * person. A blank panel tells them nothing and reads like a broken screen.
 *
 * Some authorities are not roles at all - a relationship to an object, an enrolled device,
 * the holder of a challenge. Those carry `subject` instead of `roles` and the register
 * says what the relationship is; the portal cannot evaluate any of them and must not
 * pretend to, so those acts are offered to any signed-in identity and refused by the
 * server if the relationship does not hold.
 */

// The guest list. Every role CinerionRoles knows about, in the order the register writes
// them. Anything a token carries that isn't on here is the identity provider talking to
// itself (Keycloak loves handing out `default-roles-cinerion`), not an authority.
export const ControlledRoleNames = [
  'Viewer',
  'Auditor',
  'Engineer',
  'AutomationEngineer',
  'Inspector',
  'LocalConfirmer',
  'MaintenanceEngineer',
  'OperationsCoordinator',
  'ProjectManager',
  'ConfigurationManager',
  'RDEngineer',
  'DocumentController',
  'CybersecurityAdministrator',
  'SystemAdministrator',
  'ProjectOwner',
  'DeviceController',
] as const;

/** A role name as `CinerionRoles` defines it and the realm grants it. */
export type ControlledRole = (typeof ControlledRoleNames)[number];

const controlledRoleSet: ReadonlySet<string> = new Set(ControlledRoleNames);

/** Yes if this role name is one of ours, no if it's the identity provider's own furniture. */
export function isControlledRole(role: string): role is ControlledRole {
  return controlledRoleSet.has(role);
}

/**
 * Sorts a token's roles into the ones that mean something here and the ones that don't.
 * The leftovers are kept, not binned - hiding them would be tidy and a little dishonest.
 */
export function splitRoles(roles: readonly string[] | undefined): {
  controlled: ControlledRole[];
  other: string[];
} {
  const held = new Set(roles ?? []);
  return {
    controlled: ControlledRoleNames.filter((role) => held.has(role)),
    other: [...held].filter((role) => !controlledRoleSet.has(role)).sort(),
  };
}

export interface ControlledAct {
  /** `METHOD /path`, exactly as `api_endpoints.json` writes it. */
  readonly operation: string;
  /** What the act is, in the words an operator would use. */
  readonly act: string;
  /** The authority column of `api_endpoints.json`, verbatim. Never paraphrased. */
  readonly authority: string;
  /**
   * The roles that plausibly own this act, a subset of what the authority register maps
   * the phrase to. Absent when the authority is not a role.
   */
  readonly roles?: readonly ControlledRole[];
  /** Why this authority is not a role, when it is not. Taken from the authority register. */
  readonly subject?: string;
  /**
   * The relationship half of an authority that has BOTH, such as "Session owner or
   * Identity Administrator" or "Reservation owner or Operations Coordinator".
   *
   * These were nearly modelled as pure relationships, and the gate refused it: declaring
   * no roles would have offered the act to every signed-in identity and silently dropped
   * the role half of a controlled authority. They are two authorities in one phrase. The
   * relationship half cannot be evaluated from a token — nothing here knows whose session
   * or whose reservation an object is — so the act IS offered to any signed-in identity
   * and the server decides; the roles are recorded because they are the other, reviewable
   * half of the same phrase.
   */
  readonly orRelationship?: string;
  /** Why this portal narrows the mapped roles, when it does. Required by the gate if it does. */
  readonly narrowedBecause?: string;
  /** The declared screen this act belongs on. */
  readonly screen: string;
}

/**
 * Every controlled WRITE the portal offers or could offer, keyed by a stable act name.
 *
 * Reads are deliberately absent. A read is authorised per object by Control Core and the
 * portal's honest behaviour for one it may not perform is to ask and show the refusal -
 * which it already does through `CapabilityNotice`. Offering or withholding a read on a
 * role guess would hide data from an identity the server would have served.
 */
export const ControlledActs = {
  // --- Authentication -----------------------------------------------------------
  //
  // These three are acts the portal performs and no role owns. They are in the register
  // because leaving them out would make the count of unaccounted operations read as a
  // gap, and because saying WHY an act has no role authority is the same discipline as
  // saying which role owns one.
  requestPasskeyChallenge: {
    operation: 'POST /api/v1/auth/passkey/options',
    act: 'Ask for a bound passkey authentication challenge',
    authority: 'Anonymous with rate limit',
    subject:
      'No identity at all. The operation is reachable before authentication and is bounded by rate limiting, not by a role.',
    screen: 'CH1-UX-SCR-0002',
  },
  verifyPasskeyAssertion: {
    operation: 'POST /api/v1/auth/passkey/verify',
    act: 'Present a passkey assertion',
    authority: 'Challenge holder',
    subject:
      'Whoever holds the single-use challenge this platform just issued. Holding it is the authority; no role grants or withholds it.',
    screen: 'CH1-UX-SCR-0002',
  },
  requestStepUp: {
    operation: 'POST /api/v1/auth/step-up',
    act: 'Raise authentication strength for one named purpose',
    authority: 'Authenticated user',
    subject:
      'Any identity with a valid session. A step-up grant authorises nothing by itself: it is purpose-bound, single-use and five minutes long, and the act it is spent on is authorised separately.',
    screen: 'CH1-UX-SCR-0002',
  },

  // --- Identity and credentials -------------------------------------------------
  assignRoles: {
    operation: 'PUT /api/v1/users/{userId}/roles',
    act: 'Change which controlled roles an identity holds',
    authority: 'System Administrator',
    roles: ['SystemAdministrator'],
    screen: 'CH1-UX-SCR-0013',
  },
  enrolTotp: {
    operation: 'POST /api/v1/auth/totp/enrolments',
    act: 'Begin TOTP enrolment',
    authority: 'Self or Identity Administrator',
    roles: ['SystemAdministrator'],
    orRelationship:
      'The "self" half: an identity acting on its own account. That is a relationship, not a role, so the act is offered to everyone and the server decides whose account it may touch.',
    screen: 'CH1-UX-SCR-0002',
  },
  registerCredential: {
    operation: 'POST /api/v1/credentials',
    act: 'Register a cryptographic physical credential',
    authority: 'Cybersecurity Administrator',
    roles: ['CybersecurityAdministrator'],
    screen: 'CH1-UX-SCR-0013',
  },
  revokeCredential: {
    operation: 'DELETE /api/v1/credentials/{credentialId}',
    act: 'Revoke a lost or compromised credential',
    authority: 'Cybersecurity Administrator',
    roles: ['CybersecurityAdministrator'],
    screen: 'CH1-UX-SCR-0013',
  },
  revokeSession: {
    operation: 'DELETE /api/v1/auth/sessions/{sessionId}',
    act: 'End a session everywhere',
    authority: 'Session owner or Identity Administrator',
    roles: ['SystemAdministrator'],
    orRelationship:
      'The "session owner" half: the identity whose session it is. Every identity may end its own session, so the act is offered to everyone and the server refuses one that is neither the owner nor an administrator.',
    screen: 'CH1-UX-SCR-0001',
  },

  // --- Devices ------------------------------------------------------------------
  enrolDevice: {
    operation: 'POST /api/v1/devices/{deviceId}/enrolment',
    act: 'Enrol a device or service identity',
    authority: 'Cybersecurity Administrator',
    roles: ['CybersecurityAdministrator'],
    screen: 'CH1-UX-SCR-0018',
  },
  revokeDevice: {
    operation: 'POST /api/v1/devices/{deviceId}/revoke',
    act: 'Revoke device trust and protocol access',
    authority: 'Cybersecurity Administrator',
    roles: ['CybersecurityAdministrator'],
    screen: 'CH1-UX-SCR-0018',
  },

  // --- Operations ---------------------------------------------------------------
  acknowledgeAlarm: {
    operation: 'POST /api/v1/alarms/{alarmId}/acknowledgements',
    act: 'Acknowledge an alarm without clearing its cause',
    authority: 'Assigned operator or Engineer',
    roles: ['Engineer', 'AutomationEngineer'],
    screen: 'CH1-UX-SCR-0005',
  },
  prepareCommand: {
    operation: 'POST /api/v1/commands/prepare',
    act: 'Prepare one semantic physical procedure',
    authority: 'Authorised Engineer or Project Manager',
    roles: ['Engineer', 'AutomationEngineer', 'ProjectManager'],
    screen: 'CH1-UX-SCR-0008',
  },
  cancelCommand: {
    operation: 'POST /api/v1/commands/{commandId}/cancel',
    act: 'Cancel a prepared command',
    authority: 'Requester or authorised Engineer',
    roles: ['Engineer', 'AutomationEngineer'],
    screen: 'CH1-UX-SCR-0008',
  },

  // --- Engineering and manufacturing --------------------------------------------
  createProject: {
    operation: 'POST /api/v1/projects',
    act: 'Create a controlled project workspace',
    authority: 'Project Manager',
    roles: ['ProjectManager'],
    screen: 'CH1-UX-SCR-0003',
  },
  createProductRevision: {
    operation: 'POST /api/v1/products/{productId}/revisions',
    act: 'Create a controlled product revision',
    authority: 'Engineer',
    roles: ['Engineer', 'AutomationEngineer'],
    screen: 'CH1-UX-SCR-0006',
  },
  createWorkOrder: {
    operation: 'POST /api/v1/work-orders',
    act: 'Create a work order against one released revision',
    authority: 'Project Manager',
    roles: ['ProjectManager'],
    screen: 'CH1-UX-SCR-0006',
  },
  releaseWorkOrder: {
    operation: 'POST /api/v1/work-orders/{workOrderId}/release',
    act: 'Release a work order for controlled execution',
    authority: 'Project Manager',
    roles: ['ProjectManager'],
    screen: 'CH1-UX-SCR-0006',
  },
  recordScanEvent: {
    operation: 'POST /api/v1/parts/scan-events',
    act: 'Record a QR or RFID part identification at a station',
    authority: 'Bound device or Field Companion',
    subject:
      'An enrolled device identity with a signed session. The portal acting as a Field Companion is the second half of that phrase; the server decides whether this session is one.',
    screen: 'CH1-UX-SCR-0015',
  },

  // --- Quality ------------------------------------------------------------------
  startTestRun: {
    operation: 'POST /api/v1/test-runs',
    act: 'Open an inspection run against a controlled procedure revision',
    authority: 'Inspector or Test Engineer',
    roles: ['Inspector'],
    screen: 'CH1-UX-SCR-0010',
  },
  /**
   * The HUMAN half of this authority. The other half is a machine and is not a portal act.
   *
   * "Bound instrument adapter or Test Engineer" names two very different callers, and both
   * are now implemented - but only one of them is a person at a screen. An enrolled
   * instrument authenticates by mutual TLS on Control Core's device listener and appends
   * its own readings directly; it never passes through here, holds no human role, and is
   * refused if it names an instrument other than itself.
   *
   * The register lists the Inspector because that is who this portal offers the act to. A
   * reader should not conclude from the role list that the adapter half went
   * unimplemented - see conflict 35.
   */
  recordMeasurement: {
    operation: 'POST /api/v1/test-runs/{testRunId}/measurements',
    act: 'Append a measurement and its evidence references',
    authority: 'Bound instrument adapter or Test Engineer',
    roles: ['Inspector'],
    screen: 'CH1-UX-SCR-0010',
  },
  raiseNcr: {
    operation: 'POST /api/v1/ncrs',
    act: 'Raise a nonconformance against a part or test',
    authority: 'Inspector or Engineer',
    roles: ['Inspector', 'Engineer', 'AutomationEngineer'],
    screen: 'CH1-UX-SCR-0011',
  },
  disposeNcr: {
    operation: 'POST /api/v1/ncrs/{ncrId}/dispositions',
    act: 'Record the controlled disposition of a nonconformance',
    authority: 'Inspector',
    roles: ['Inspector'],
    screen: 'CH1-UX-SCR-0011',
  },
  releasePart: {
    operation: 'POST /api/v1/release-records',
    act: 'Release an accepted physical part',
    authority: 'Inspector',
    roles: ['Inspector'],
    screen: 'CH1-UX-SCR-0011',
  },

  generateReport: {
    operation: 'POST /api/v1/reports',
    act: 'Generate a controlled report from named record identifiers',
    authority: 'Quality or Project role',
    roles: ['Inspector', 'ProjectManager'],
    screen: 'CH1-UX-SCR-0010',
  },

  // --- Resources ----------------------------------------------------------------
  reserveResource: {
    operation: 'POST /api/v1/resources/{resourceId}/reservations',
    act: 'Reserve a resource for a bounded interval',
    authority: 'Operations Coordinator or Project Manager',
    roles: ['OperationsCoordinator', 'ProjectManager'],
    screen: 'CH1-UX-SCR-0017',
  },
  releaseReservation: {
    operation: 'DELETE /api/v1/reservations/{reservationId}',
    act: 'Cancel a resource reservation',
    authority: 'Reservation owner or Operations Coordinator',
    roles: ['OperationsCoordinator'],
    orRelationship:
      'The "reservation owner" half: the identity that made the reservation. A relationship to the object, which no token states, so the act is offered to everyone and the server refuses one that is neither.',
    screen: 'CH1-UX-SCR-0017',
  },

  // --- Collaboration ------------------------------------------------------------
  postContextMessage: {
    operation: 'POST /api/v1/context-threads/{threadId}/messages',
    act: 'Add a contextual message, carrying no control authority',
    authority: 'Authorised participant',
    subject: 'A relationship to the collaboration object, checked per thread rather than per role.',
    screen: 'CH1-UX-SCR-0019',
  },
  acknowledgeMessage: {
    operation: 'POST /api/v1/context-messages/{messageId}/acknowledgements',
    act: 'Acknowledge receipt of a contextual message',
    authority: 'Assigned recipient',
    subject: 'The identity a message was addressed to. A relationship, checked per object.',
    screen: 'CH1-UX-SCR-0019',
  },

  // --- Research -----------------------------------------------------------------
  createExperiment: {
    operation: 'POST /api/v1/experiments',
    act: 'Create an isolated R&D experiment',
    authority: 'R&D Engineer',
    roles: ['RDEngineer'],
    screen: 'CH1-UX-SCR-0020',
  },
  runExperiment: {
    operation: 'POST /api/v1/experiments/{experimentId}/runs',
    act: 'Execute a bounded experiment run',
    authority: 'R&D Engineer',
    roles: ['RDEngineer'],
    screen: 'CH1-UX-SCR-0020',
  },
  requestPromotion: {
    operation: 'POST /api/v1/experiments/{experimentId}/promotion-requests',
    act: 'Request controlled promotion into implementation',
    authority: 'R&D Engineer or Engineer',
    roles: ['RDEngineer', 'Engineer', 'AutomationEngineer'],
    screen: 'CH1-UX-SCR-0021',
  },

  // --- Audit --------------------------------------------------------------------
  verifyAuditChain: {
    operation: 'POST /api/v1/audit/chain-verifications',
    act: 'Verify an audit-chain interval',
    authority: 'Auditor or Cybersecurity Administrator',
    roles: ['Auditor', 'CybersecurityAdministrator'],
    screen: 'CH1-UX-SCR-0014',
  },
} as const satisfies Record<string, ControlledAct>;

export type ActName = keyof typeof ControlledActs;

/**
 * One act, read back as the interface rather than as its own literal type.
 *
 * `as const satisfies` above is what makes the gate's job possible: it keeps every string
 * literal exactly as written, so a typo in an authority phrase is a compile error against
 * the controlled catalogue rather than a runtime surprise. The cost is that a lookup on
 * the const object has the union of thirty-one distinct literal types, and a field only
 * some of them carry cannot be read from the union at all. This is the one place that
 * widens it, so no caller has to.
 */
export function act(name: ActName): ControlledAct {
  return ControlledActs[name];
}

/**
 * Whether this identity plausibly owns an act.
 *
 * "Plausibly" is the whole contract. An act with no role authority is owned by anyone
 * signed in, because the relationship it really depends on is not visible from a token.
 * An act with roles is owned by an identity holding any one of them. Neither answer is a
 * prediction that the server will allow it.
 */
export function ownsAct(act: ControlledAct, roles: readonly string[] | undefined): boolean {
  if (act.roles === undefined || act.orRelationship !== undefined) return true;
  return act.roles.some((role) => (roles ?? []).includes(role));
}

/** The same question by act name, for a screen that names the act it is about to offer. */
export function owns(name: ActName, roles: readonly string[] | undefined): boolean {
  return ownsAct(act(name), roles);
}

/**
 * How an act that this identity does not own should be described.
 *
 * Returns the sentence a screen shows in place of the control. It names the act, names
 * the authority the controlled document declares, and says what this identity holds - so
 * an operator can see at a glance whether they are missing a role or looking at somebody
 * else's job.
 */
export function whoOwns(name: ActName, roles: readonly string[] | undefined): string {
  const subject = act(name);
  const held = (roles ?? []).length === 0 ? 'no controlled role' : (roles ?? []).join(', ');
  if (subject.roles === undefined || subject.orRelationship !== undefined) {
    return `${subject.act} is authorised as "${subject.authority}". ${subject.subject ?? subject.orRelationship ?? ''}`.trim();
  }
  return (
    `${subject.act} is authorised as "${subject.authority}", which this platform maps to ` +
    `${subject.roles.join(' or ')}. This identity holds ${held}.`
  );
}

/** Every act declared for one screen, in declaration order. */
export function actsForScreen(screen: string): readonly (ControlledAct & { readonly name: ActName })[] {
  return (Object.keys(ControlledActs) as ActName[])
    .map((name) => ({ ...act(name), name }))
    .filter((entry) => entry.screen === screen);
}
