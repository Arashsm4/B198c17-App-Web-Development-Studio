// Root layout: theme and session wrapped around every route. The front door of the portal.

import '@/global.css';

import { DarkTheme, Stack, ThemeProvider } from 'expo-router';
import { StatusBar } from 'expo-status-bar';

import { SessionProvider } from '@/auth/session';

const CinerionTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    primary: '#35D7C4',
    background: '#07121F',
    card: '#0A1828',
    border: '#1D3145',
    text: '#F1F7FB',
  },
};

export default function RootLayout() {
  return (
    <ThemeProvider value={CinerionTheme}>
      <SessionProvider>
        <StatusBar style="light" />
        <Stack screenOptions={{ headerShown: false, animation: 'fade' }} />
      </SessionProvider>
    </ThemeProvider>
  );
}
