// @screen none — implementation gates and the R&D summary. CH1-UX-SCR-0020 (R&D workbench)
//                and CH1-UX-SCR-0021 (promotion review) are NOT claimed: the P03 catalogue
//                has no read operation for experiments or runs, so neither can be built.

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import { AppShell, PageIntro } from '@/components/app-shell';
import { Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

const gates = [
  ['G0', 'Controlled baseline', 'SATISFIED', 'P03 sources frozen and checksummed', 'good'],
  ['G1', 'Architecture', 'SATISFIED', 'Boundaries, contracts, and threat allocation', 'good'],
  ['G2', 'Identity', 'FOUNDATION', 'Provider integration and ceremonies pending', 'info'],
  ['G3', 'Guarded physical control', 'SIMULATOR PASS', 'Negative state-model and firmware tests', 'good'],
  ['G4', 'Interoperability', 'GATED', 'Live MQTT / OPC UA / Modbus conformance', 'warning'],
  ['G5', 'Digital thread', 'FOUNDATION', 'Revision to part and audit links', 'info'],
  ['G6', 'Quality', 'FOUNDATION', 'Limits, hold, NCR, segregation', 'info'],
  ['G7', 'Verification', 'IN PROGRESS', 'CI and simulator active; HIL pending', 'warning'],
  ['G8', 'Factory acceptance', 'NOT EXECUTED', 'Requires controlled evidence', 'neutral'],
  ['G9', 'Release', 'NOT AUTHORISED', 'Independent acceptance and as-built', 'neutral'],
] as const;

export default function EngineeringScreen() {
  const { width } = useWindowDimensions();
  const compact = width < 1100;
  return (
    <AppShell active="engineering">
      <PageIntro
        eyebrow="Engineering / ResearchBench"
        title="Implementation gates and isolated R&D"
        description="Engineering progress is evidence-led. A feature is not complete because source exists: its requirement, implementation, security impact, test, documentation, and demonstration evidence must agree. R&D starts isolated and has no production authority."
        aside={<StatusPill label="PROTOTYPE 1" tone="info" />}
      />
      <View style={[styles.grid, compact && styles.stacked]}>
        <GateBoard />
        <ResearchBoundary />
      </View>
      <ModuleMap />
    </AppShell>
  );
}

function GateBoard() {
  return (
    <Panel style={styles.gatePanel}>
      <SectionHeading eyebrow="CH1-PMG-PEP-0001" title="Lifecycle gate board" action={<StatusPill label="4 FOUNDATIONS ACTIVE" tone="info" />} />
      <View style={styles.gateList}>
        {gates.map(([code, title, state, detail, tone]) => (
          <View key={code} style={styles.gateRow}>
            <View style={styles.gateCode}><Text style={styles.gateCodeText}>{code}</Text></View>
            <View style={styles.gateCopy}>
              <Text style={styles.gateTitle}>{title}</Text>
              <Text style={styles.gateDetail}>{detail}</Text>
            </View>
            <StatusPill label={state} tone={tone} />
          </View>
        ))}
      </View>
    </Panel>
  );
}

function ResearchBoundary() {
  const facts = [
    ['Default environment', 'Deterministic simulator'],
    ['Identity', 'CH1-RND scoped only'],
    ['Production route', 'Deny by default'],
    ['Equipment access', 'No real equipment'],
    ['Evidence', 'Config + code + inputs + environment'],
    ['Promotion', 'Change + impact + verification'],
  ];
  return (
    <Panel style={styles.researchPanel}>
      <SectionHeading eyebrow="ResearchBench" title="Experiment isolation" action={<StatusPill label="NO PRODUCTION AUTHORITY" tone="good" />} />
      <View style={styles.researchGraphic}>
        <View style={styles.labRing}>
          <View style={styles.labCore}><Text style={styles.labCoreCode}>R&D</Text><Text style={styles.labCoreText}>SIMULATOR</Text></View>
        </View>
        <View style={styles.denyLine}><Text style={styles.denyText}>DENY</Text></View>
        <View style={styles.productionBox}><Text style={styles.productionCode}>CONTROLLED</Text><Text style={styles.productionTitle}>Implementation baseline</Text></View>
      </View>
      <View style={styles.factList}>
        {facts.map(([label, value]) => <View key={label} style={styles.factRow}><Text style={styles.factLabel}>{label}</Text><Text style={styles.factValue}>{value}</Text></View>)}
      </View>
      <View style={styles.promotionBox}>
        <Text style={styles.promotionCode}>PROMOTION IS A GOVERNED TRANSITION</Text>
        <Text style={styles.promotionText}>An experiment cannot silently become configuration or command real equipment. Promotion creates a controlled change, impact assessment, review, and verification package.</Text>
      </View>
    </Panel>
  );
}

function ModuleMap() {
  const modules = [
    ['FG', 'FortressGate', 'Identity and policy context'], ['CG', 'CommandGuard', 'Semantic command authority'],
    ['CF', 'ConfirmGate', 'Local presence binding'], ['PF', 'ProtocolFabric', 'Replaceable adapters'],
    ['FF', 'ForgeFlow', 'Product and work definition'], ['TC', 'TraceCore', 'Part genealogy'],
    ['OI', 'OpenInspect', 'Test and NCR control'], ['AV', 'AssetVault', 'Device and calibration'],
    ['CB', 'ContextBridge', 'Object-linked communication'], ['RO', 'ResourceOrchestrator', 'Capacity and reservation'],
    ['RB', 'ResearchBench', 'Isolated experiments'], ['RF', 'ReportForge', 'Deterministic evidence reports'],
  ];
  return (
    <Panel>
      <SectionHeading eyebrow="Modular monolith / bounded domains" title="Cinerion platform map" />
      <View style={styles.moduleGrid}>
        {modules.map(([code, name, detail]) => (
          <View key={code} style={styles.moduleCard}>
            <View style={styles.moduleCode}><Text style={styles.moduleCodeText}>{code}</Text></View>
            <View><Text style={styles.moduleName}>{name}</Text><Text style={styles.moduleDetail}>{detail}</Text></View>
          </View>
        ))}
      </View>
    </Panel>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  gatePanel: { flex: 1.2, minWidth: 0 },
  researchPanel: { flex: 0.8, minWidth: 340 },
  gateList: { gap: 1 },
  gateRow: { minHeight: 58, flexDirection: 'row', alignItems: 'center', gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Palette.line },
  gateCode: { width: 34, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.panelRaised, borderWidth: 1, borderColor: Palette.lineStrong },
  gateCodeText: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '900' },
  gateCopy: { flex: 1, gap: 3 },
  gateTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  gateDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  researchGraphic: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginVertical: Spacing.xl },
  labRing: { width: 118, height: 118, borderRadius: 59, borderWidth: 1, borderColor: '#2D766F', alignItems: 'center', justifyContent: 'center', backgroundColor: '#0B252D' },
  labCore: { width: 84, height: 84, borderRadius: 42, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.tealSoft, gap: 3 },
  labCoreCode: { color: Palette.teal, fontFamily: Type.mono, fontSize: 20, fontWeight: '900' },
  labCoreText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, fontWeight: '800' },
  denyLine: { width: 70, height: 1, backgroundColor: Palette.red, alignItems: 'center', justifyContent: 'center' },
  denyText: { color: Palette.red, backgroundColor: Palette.panel, paddingHorizontal: 6, fontFamily: Type.mono, fontSize: 7, fontWeight: '900' },
  productionBox: { borderRadius: Radius.md, borderWidth: 1, borderColor: Palette.lineStrong, backgroundColor: Palette.canvasRaised, padding: Spacing.lg, gap: 5 },
  productionCode: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, fontWeight: '900' },
  productionTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 9, fontWeight: '800' },
  factList: { borderTopWidth: 1, borderTopColor: Palette.line },
  factRow: { minHeight: 39, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Palette.line },
  factLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  factValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 8, textAlign: 'right' },
  promotionBox: { marginTop: Spacing.lg, borderRadius: Radius.md, borderLeftWidth: 3, borderLeftColor: Palette.violet, backgroundColor: '#18182A', padding: Spacing.lg, gap: 6 },
  promotionCode: { color: Palette.violet, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  promotionText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  moduleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  moduleCard: { flex: 1, minWidth: 210, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, borderWidth: 1, borderColor: Palette.line, padding: Spacing.md, flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  moduleCode: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.panelRaised },
  moduleCodeText: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 9, fontWeight: '900' },
  moduleName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  moduleDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8, marginTop: 3 },
});

