// @screen CH1-UX-SCR-0015 — Mobile scan and evidence mode: scanned identity, history and acknowledgements

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { ScanEventEntry, ScanEventPage } from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useObserved } from '@/api/use-observed';
import { useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { KpiCard, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0015 — mobile scan and evidence mode.
 *
 * screens.json declares this for field roles: "Camera/NFC, photos, notes and
 * acknowledgements". What the platform can honestly show is the evidence half — what
 * enrolled field devices resolved, when, at which station, and whether the scan resolved
 * to a part at all.
 *
 * THIS SCREEN DOES NOT SCAN. A scan is POST /api/v1/parts/scan-events and requires a
 * signed session from an enrolled Field Companion device: the browser is not one, and a
 * scan control here would be a control certain to be refused. The screen says so rather
 * than offering it, which is recorded conflict 15.
 *
 * PHOTOS AND NOTES ARE NOT SHOWN, because nothing stores them. CH1-COM-IF-0015 puts an
 * evidence store behind a provider interface that is not enabled, so a gallery here would
 * be a gallery of nothing.
 */
export default function FieldScreen() {
  return (
    <AppShell active="field">
      <SessionGate>
        <FieldEvidence />
      </SessionGate>
    </AppShell>
  );
}

function resolution(entry: ScanEventEntry): { label: string; tone: StatusTone } {
  if (entry.duplicateOf !== null) return { label: 'RE-DELIVERED', tone: 'info' };
  if (entry.partId === null) return { label: 'NO PART RESOLVED', tone: 'warning' };
  return { label: entry.resolution.toUpperCase(), tone: 'good' };
}

function FieldEvidence() {
  const { width } = useWindowDimensions();
  const narrow = width < 1080;
  const session = useSession();
  const roles = session.claims?.roles ?? [];

  const canRead =
    roles.includes('Engineer') ||
    roles.includes('Inspector') ||
    roles.includes('MaintenanceEngineer') ||
    roles.includes('OperationsCoordinator');

  const scans = useObserved<ScanEventPage>(
    canRead ? '/api/v1/parts/scan-events' : undefined,
    session.accessToken,
  );

  const entries = scans.value?.items ?? [];
  const unresolved = entries.filter((entry) => entry.partId === null && entry.duplicateOf === null).length;
  const repeats = entries.filter((entry) => entry.duplicateOf !== null).length;
  const stations = new Set(entries.map((entry) => entry.stationId)).size;

  return (
    <>
      <PageIntro
        eyebrow="Field Companion / CH1-MFG-FR-0002"
        title="Field scan and evidence"
        description="A scan resolves a physical identity. It confers no authority: reading a tag has never started equipment, released a part or satisfied a permissive, and there is no field in this record that could express one."
        aside={<FreshnessTag freshness={scans.freshness} quality={scans.quality} />}
      />

      {!canRead ? (
        <Panel>
          <SectionHeading eyebrow="Withheld" title="The scan register is not shown to this identity" />
          <Text style={styles.blocked}>
            The scan register is read by the Engineer, the Inspector, the Maintenance Engineer and the
            Operations Coordinator. This session holds none of them. WITHHELD, not empty — an empty register
            would read as a project where nothing has been scanned.
          </Text>
        </Panel>
      ) : (
        <>
          <View style={[styles.kpis, narrow && styles.stacked]}>
            <KpiCard label="Scans recorded" value={`${entries.length}`} note="Newest first" tone="info" />
            <KpiCard
              label="Resolved to no part"
              value={`${unresolved}`}
              note="A tag the platform does not know"
              tone={unresolved === 0 ? 'good' : 'warning'}
            />
            <KpiCard
              label="Re-deliveries"
              value={`${repeats}`}
              note="Kept, pointing at the scan they repeat"
              tone="info"
            />
            <KpiCard label="Stations" value={`${stations}`} note="Distinct scan points" tone="info" />
          </View>

          <Panel style={styles.captureNotice}>
            <SectionHeading
              eyebrow="Capture"
              title="Scanning happens on an enrolled device, not here"
              action={<StatusPill label="NOT OFFERED" tone="neutral" />}
            />
            <Text style={styles.blocked}>
              Recording a scan requires a signed session from an enrolled Field Companion device, and this
              browser is not one. A scan control here would be a control certain to be refused, so it is not
              offered. Photos and notes are not shown either: CH1-COM-IF-0015 puts the evidence store behind a
              provider interface that is not enabled, and a gallery of nothing would suggest there was
              something to see.
            </Text>
          </Panel>

          <Panel>
            <SectionHeading
              eyebrow="GET /api/v1/parts/scan-events"
              title="What was scanned, and what it resolved to"
              action={<StatusPill label="READ ONLY" tone="info" />}
            />

            {scans.error !== undefined ? (
              <CapabilityNotice error={scans.cause ?? scans.error} context="GET /api/v1/parts/scan-events" />
            ) : entries.length === 0 ? (
              <Text style={styles.empty}>
                No scan has been recorded in this project. This identity may read the register, so this is an
                empty register rather than a withheld one.
              </Text>
            ) : (
              <View>
                {entries.map((entry) => {
                  const state = resolution(entry);
                  return (
                    <View key={entry.scanEventId} style={[styles.row, narrow && styles.rowStacked]}>
                      <View style={styles.identity}>
                        <Text style={styles.identifier}>{entry.identifierValue}</Text>
                        <Text style={styles.kind}>
                          {entry.identifierKind} · station {entry.stationId}
                        </Text>
                      </View>
                      <View style={styles.cell}>
                        <Text style={styles.cellLabel}>Part</Text>
                        <Text style={styles.cellValue}>
                          {entry.partId === null ? 'not resolved' : shortId(entry.partId)}
                        </Text>
                      </View>
                      <View style={styles.cell}>
                        <Text style={styles.cellLabel}>Scanned</Text>
                        <Text style={styles.cellValue}>{instant(entry.scannedAt)}</Text>
                      </View>
                      <View style={styles.cell}>
                        <Text style={styles.cellLabel}>Device</Text>
                        <Text style={styles.cellValue}>{entry.deviceId}</Text>
                      </View>
                      <StatusPill label={state.label} tone={state.tone} />
                    </View>
                  );
                })}
              </View>
            )}

            <Text style={styles.footnote}>
              A re-delivery is kept and points at the scan it repeats, rather than being dropped. A register
              that silently discarded them would be concealing that a field device sent the same reading
              twice, which is exactly what an evidence reviewer needs to see.
            </Text>
          </Panel>
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  kpis: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  captureNotice: { marginBottom: Spacing.md },
  row: {
    minHeight: 62,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Palette.line,
  },
  rowStacked: { flexDirection: 'column', alignItems: 'flex-start', paddingVertical: Spacing.md, gap: Spacing.sm },
  identity: { flex: 1.5, minWidth: 0, gap: 3 },
  identifier: { color: Palette.ink, fontFamily: Type.mono, fontSize: 10, fontWeight: '800' },
  kind: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  cell: { flex: 1, minWidth: 0, gap: 3 },
  cellLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  cellValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, paddingVertical: Spacing.lg, lineHeight: 14 },
  blocked: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 15, paddingTop: Spacing.sm },
  footnote: {
    marginTop: Spacing.lg,
    borderRadius: Radius.md,
    borderLeftWidth: 3,
    borderLeftColor: Palette.cyan,
    backgroundColor: Palette.canvasRaised,
    padding: Spacing.md,
    color: Palette.inkSoft,
    fontFamily: Type.sans,
    fontSize: 9,
    lineHeight: 14,
  },
});
