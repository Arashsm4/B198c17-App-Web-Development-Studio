// @screen CH1-UX-SCR-0014 — Audit-chain explorer: correlated events and verification

import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import type { AuditPage, ChainVerification } from '@/api/contracts';

import { apiPost } from '@/api/client';
import { useObserved } from '@/api/use-observed';
import { useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { ActionButton, KeyValue, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

export default function AuditScreen() {
  return (
    <AppShell active="audit">
      <SessionGate>
        <Audit />
      </SessionGate>
    </AppShell>
  );
}

function Audit() {
  const { width } = useWindowDimensions();
  const compact = width < 1080;
  const session = useSession();

  const events = useObserved<AuditPage>('/api/v1/audit/events', session.accessToken);

  // Verification is an explicit operator action rather than a poll: it is a
  // controlled, audited operation, so the portal must not issue it continuously.
  const [verification, setVerification] = useState<ChainVerification | undefined>(undefined);
  const [verifyError, setVerifyError] = useState<unknown>(undefined);
  const [verifying, setVerifying] = useState(false);

  const verify = useCallback(() => {
    setVerifying(true);
    setVerifyError(undefined);
    apiPost<ChainVerification>('/api/v1/audit/chain-verifications', session.accessToken)
      .then((result) => setVerification(result))
      .catch((cause: unknown) => {
        setVerification(undefined);
        setVerifyError(cause);
      })
      .finally(() => setVerifying(false));
  }, [session.accessToken]);

  const items = events.value?.items ?? [];
  const head = items.length > 0 ? items[items.length - 1] : undefined;

  return (
    <>
      <PageIntro
        eyebrow="TraceCore / Evidence Ledger"
        title="Tamper-evident audit chain"
        description="Security, command, configuration, quality and release events are recorded with actor context, correlation, time quality, a canonical payload hash and the preceding chain link. This checkpoint uses an in-memory append-only ledger; external immutable anchoring remains a later controlled gate."
        aside={<ChainStatus verification={verification} verifying={verifying} hasError={verifyError !== undefined} />}
      />

      {events.error ? <CapabilityNotice error={eventsFailure(events.error)} context="GET /api/v1/audit/events" /> : null}

      <View style={[styles.summaryGrid, compact && styles.stacked]}>
        <Panel style={styles.integrityPanel}>
          <SectionHeading
            eyebrow="On-demand verification"
            title="Ledger integrity"
            action={<ActionButton label={verifying ? 'VERIFYING…' : 'VERIFY CHAIN'} onPress={verify} kind="secondary" disabled={verifying} />}
          />

          {verifyError !== undefined ? (
            <CapabilityNotice error={verifyError} context="POST /api/v1/audit/chain-verifications" />
          ) : verification ? (
            <>
              <View style={styles.verificationGrid}>
                <Verified label="Chain continuity" value={verification.valid ? `${verification.checked} / ${verification.checked} links` : `Broken at ${verification.failureAt}`} ok={verification.valid} />
                <Verified label="Canonical hashes" value={verification.valid ? 'Recomputed and matched' : 'Mismatch detected'} ok={verification.valid} />
                <Verified label="Events checked" value={String(verification.checked)} ok={verification.valid} />
                <Verified label="Verified by" value={verification.verifiedBy} ok />
              </View>
              <Text style={styles.verifiedAt}>Verification {verification.verificationId} at {verification.verifiedAt}</Text>
            </>
          ) : (
            <Text style={styles.idle}>
              The chain has not been verified in this session. Integrity is not asserted until the
              server has recomputed it; nothing here claims a result that was not produced.
            </Text>
          )}

          <View style={styles.anchorBox}>
            <Text style={styles.anchorCode}>LATEST CHAIN HEAD</Text>
            <Text selectable style={styles.anchorHash}>
              {head ? `sha256:${head.eventHash}` : 'No events retrieved'}
            </Text>
            <Text style={styles.anchorText}>
              The verifier recomputes canonical event hashes server-side and validates each
              previous-hash pointer. Export signing and WORM anchoring are not claimed in Prototype 1.
            </Text>
          </View>
        </Panel>

        <Panel style={styles.contextPanel}>
          <SectionHeading eyebrow="Investigation context" title="Retrieved ledger" />
          <View style={styles.contextList}>
            <KeyValue label="Events retrieved" value={String(events.value?.count ?? 0)} mono />
            <KeyValue label="Latest sequence" value={head ? String(head.sequence) : '—'} mono />
            <KeyValue label="Latest correlation" value={head?.correlationId ?? '—'} mono />
            <KeyValue label="Project scope" value={head?.projectId ?? session.claims?.ch1_project ?? '—'} mono />
            <KeyValue label="Retention class" value="SECURITY / QUALITY — CONTROLLED" />
          </View>
          <View style={styles.freshnessRow}>
            <FreshnessTag freshness={events.freshness} />
          </View>
        </Panel>
      </View>

      <Panel>
        <SectionHeading
          eyebrow="Ordered evidence"
          title="Correlated event sequence"
          action={<Text style={styles.exportState}>EXPORT REQUIRES AUTHORISATION</Text>}
        />
        {items.length === 0 ? (
          <Text style={styles.idle}>
            {events.error ? 'No events could be retrieved.' : 'The ledger returned no events for this scope.'}
          </Text>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator>
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={[styles.headerCell, styles.seqCell]}>SEQ</Text>
                <Text style={[styles.headerCell, styles.timeCell]}>OCCURRED AT · TIME QUALITY</Text>
                <Text style={[styles.headerCell, styles.eventCell]}>EVENT</Text>
                <Text style={[styles.headerCell, styles.actorCell]}>ACTOR</Text>
                <Text style={[styles.headerCell, styles.resultCell]}>DECISION</Text>
                <Text style={[styles.headerCell, styles.hashCell]}>CHAIN LINK</Text>
              </View>
              {[...items].reverse().map((event) => (
                <View key={event.eventId} style={styles.tableRow}>
                  <Text style={[styles.cell, styles.seqCell]}>{String(event.sequence).padStart(3, '0')}</Text>
                  <View style={styles.timeCell}>
                    <Text style={styles.cell}>{event.occurredAt}</Text>
                    <Text style={styles.timeQuality}>{event.timeQuality}</Text>
                  </View>
                  <View style={styles.eventCell}>
                    <Text style={styles.eventName}>{event.eventType}</Text>
                    <Text style={styles.correlation}>{event.reasonCode}</Text>
                  </View>
                  <View style={styles.actorCell}>
                    <Text style={styles.cell}>{event.actorId}</Text>
                    <Text style={styles.timeQuality}>{event.actorKind}</Text>
                  </View>
                  <View style={styles.resultCell}>
                    <StatusPill
                      label={event.decision.toUpperCase()}
                      tone={event.decision === 'Allowed' ? 'good' : event.decision === 'Rejected' ? 'danger' : 'neutral'}
                    />
                  </View>
                  <Text selectable style={[styles.cell, styles.hashCell, styles.hash]}>
                    {event.eventHash.slice(0, 8)}…{event.eventHash.slice(-4)}
                  </Text>
                </View>
              ))}
            </View>
          </ScrollView>
        )}
        <View style={styles.boundaryNotice}>
          <Text style={styles.boundaryTitle}>EVIDENCE BOUNDARY</Text>
          <Text style={styles.boundaryText}>
            The portal presents evidence; it cannot edit, delete, resequence or mark an event as
            verified. Verification runs server-side against canonical records and is itself audited.
          </Text>
        </View>
      </Panel>
    </>
  );
}

/**
 * The chain status never claims validity from the presence of rows. It reports only
 * what a server-side verification returned, and says so when none has run.
 */
function ChainStatus({
  verification,
  verifying,
  hasError,
}: {
  verification: ChainVerification | undefined;
  verifying: boolean;
  hasError: boolean;
}) {
  if (verifying) return <StatusPill label="VERIFYING" tone="info" />;
  if (hasError) return <StatusPill label="VERIFICATION UNAVAILABLE" tone="warning" />;
  if (!verification) return <StatusPill label="NOT VERIFIED THIS SESSION" tone="neutral" />;
  return verification.valid
    ? <StatusPill label={`CHAIN VALID · ${verification.checked} LINKS`} tone="good" />
    : <StatusPill label={`CHAIN BROKEN AT ${verification.failureAt}`} tone="danger" />;
}

function Verified({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <View style={styles.verificationItem}>
      <Text style={styles.verificationLabel}>{label}</Text>
      <StatusPill label={value.toUpperCase()} tone={ok ? 'good' : 'danger'} />
    </View>
  );
}

/** The hook reports failures as text; rebuild a typed error for the shared notice. */
function eventsFailure(message: string): Error {
  return new Error(message);
}

const styles = StyleSheet.create({
  summaryGrid: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  integrityPanel: { flex: 1.3, minWidth: 0 },
  contextPanel: { flex: 0.7, minWidth: 300 },
  verificationGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  verificationItem: { flex: 1, minWidth: 150, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, borderWidth: 1, borderColor: Palette.line, padding: Spacing.md, gap: Spacing.sm },
  verificationLabel: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, fontWeight: '700' },
  verifiedAt: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, marginTop: Spacing.md },
  idle: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 16, marginTop: Spacing.sm },
  anchorBox: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.teal, backgroundColor: '#081A25', padding: Spacing.lg, gap: 7 },
  anchorCode: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.9 },
  anchorHash: { color: Palette.ink, fontFamily: Type.mono, fontSize: 11 },
  anchorText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  contextList: { gap: Spacing.lg },
  freshnessRow: { marginTop: Spacing.lg, paddingTop: Spacing.md, borderTopWidth: 1, borderTopColor: Palette.line },
  exportState: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  table: { minWidth: 900 },
  tableHeader: { flexDirection: 'row', gap: Spacing.sm, paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Palette.lineStrong },
  headerCell: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  tableRow: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Palette.line },
  cell: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  seqCell: { width: 46 },
  timeCell: { width: 210 },
  eventCell: { width: 230, minWidth: 0 },
  actorCell: { width: 170 },
  resultCell: { width: 120 },
  hashCell: { width: 130 },
  timeQuality: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, marginTop: 3 },
  eventName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  correlation: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, marginTop: 4 },
  hash: { color: Palette.violet },
  boundaryNotice: { marginTop: Spacing.lg, borderRadius: Radius.md, borderWidth: 1, borderColor: '#1B4D58', backgroundColor: '#0A222C', padding: Spacing.lg, gap: 5 },
  boundaryTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  boundaryText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});
