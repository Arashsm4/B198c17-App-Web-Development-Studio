// @screen CH1-UX-SCR-0007 — Part genealogy: identity and complete history

import { useState } from 'react';
import { useLocalSearchParams } from 'expo-router';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type {
  CellState,
  PartGenealogy,
  PartIdentity,
  PartStatus,
  QualityMeasurement,
} from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { ConnectedObjects, ObjectLink } from '@/components/object-link';
import { CapabilityNotice } from '@/components/capability';
import { apiFetch, CinerionApiError } from '@/api/client';
import {
  ActionButton,
  Divider,
  KeyValue,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import type { StatusTone } from '@/constants/status';
import { Palette, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0007 — part genealogy: identity and complete history.
 *
 * CH1-MFG-FR-0002 requires a part to resolve to its work order, revision, operations and
 * tests, and CH1-TRC-FR-0001 requires every controlled event to link back to the physical
 * part. This is the read side of that: one part, everything the platform holds about it,
 * and an explicit statement of what it does not hold.
 */
export default function GenealogyScreen() {
  return (
    <AppShell active="genealogy">
      <SessionGate>
        <Genealogy />
      </SessionGate>
    </AppShell>
  );
}

/**
  * RFC 4122 shape. The genealogy operation takes an identifier; a serial number is
  * resolved to one first, through the owner-approved read recorded for conflict 15.
  */
const PART_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function Genealogy() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();
  const cells = assignedCells(session.claims);
  const primaryCell = cells[0];

  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  // The part loaded on the assigned cell is the starting point, because it is the one
  // identifier this identity can obtain without a scanner. Anything else is typed.
  // The part a link asked for, when this screen was reached from one. The typed or
  // scanned choice still wins; the server still decides what this identity may read.
  const arrived = useLocalSearchParams<{ partId?: string }>();
  const [entered, setEntered] = useState('');
  const [selected, setSelected] = useState<string | undefined>(undefined);
  const [attempted, setAttempted] = useState(false);
  const [resolving, setResolving] = useState(false);
  const [resolvedFrom, setResolvedFrom] = useState<string | undefined>(undefined);
  const [lookupError, setLookupError] = useState<string | undefined>(undefined);
  const partId = selected ?? arrived.partId ?? cell.value?.partId;
  const typed = entered.trim();
  const entryInvalid = typed.length === 0;

  /**
   * Resolves whatever was typed to a part identifier.
   *
   * An identifier is used as it stands. Anything else is offered to
   * `GET /api/v1/parts?serialNumber=`, which resolves a controlled identity and records
   * no scan event — the evidence path stays `POST /api/v1/parts/scan-events` and stays
   * bound to an enrolled Field Companion device. A serial the caller may not reach
   * answers exactly as one that never existed, so this reports the same thing for both.
   */
  const open = async () => {
    setAttempted(true);
    setLookupError(undefined);
    if (typed.length === 0) return;
    if (PART_ID.test(typed)) {
      setResolvedFrom(undefined);
      setSelected(typed);
      return;
    }

    setResolving(true);
    try {
      const identity = await apiFetch<PartIdentity>(
        `/api/v1/parts?serialNumber=${encodeURIComponent(typed)}`,
        session.accessToken,
      );
      setResolvedFrom(identity.serialNumber);
      setSelected(identity.partId);
    } catch (error) {
      setResolvedFrom(undefined);
      setSelected(undefined);
      setLookupError(
        error instanceof CinerionApiError && error.status === 404
          ? 'No part in this project answers to that serial number. A serial you are not permitted to reach answers the same way.'
          : 'The serial number could not be resolved.',
      );
    } finally {
      setResolving(false);
    }
  };

  const genealogy = useObserved<PartGenealogy>(
    partId ? `/api/v1/parts/${partId}/genealogy` : undefined,
    session.accessToken,
  );

  const part = genealogy.value?.part;
  // A part that does not exist and one outside the caller's scope answer identically,
  // and both are an empty state rather than a fault. Classified from the refusal itself
  // rather than from a flattened message.
  const refusal = genealogy.cause ?? genealogy.error;
  const notFound = refusal instanceof CinerionApiError && refusal.status === 404;

  return (
    <>
      <PageIntro
        eyebrow="ForgeFlow / CH1-UX-SCR-0007"
        title="Part genealogy"
        description="One physical part, and everything the controlled record holds about it: the order and revision that governed it, who made it, every measurement taken against it, and whether it was released."
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Part"
          value={part ? part.serialNumber : partId ? '—' : 'None selected'}
          note={
            selected
              ? 'Identifier entered on this page'
              : cell.value
                ? 'The part loaded on the assigned cell'
                : 'No cell assignment in this identity'
          }
          tone={part ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Status"
          value={part ? part.status : '—'}
          note={part ? statusNote(part.status, part.openNcrIds.length) : 'Nothing retrieved'}
          tone={part ? statusTone(part.status) : 'neutral'}
        />
        <KpiCard
          label="Evidence"
          value={genealogy.value ? genealogy.value.evidenceCompleteness : '—'}
          note={genealogy.value ? genealogy.value.provenance : 'The store is named by the server, never assumed here'}
          tone={genealogy.value?.evidenceCompleteness === 'Released' ? 'good' : 'info'}
        />
      </View>

      <Panel>
        <SectionHeading eyebrow="Identity" title="Which part" />
        <Text style={styles.copy}>
          The genealogy operation takes a part <Text style={styles.strong}>identifier</Text>. A serial
          number printed on a label is resolved to one first, by
          <Text style={styles.strong}> GET /api/v1/parts?serialNumber=</Text> — a read that resolves the
          identity and nothing else.
        </Text>
        <Text style={styles.copy}>
          It is <Text style={styles.strong}>not</Text> the evidence path and does not record a scan.
          Recording one is <Text style={styles.strong}>POST /api/v1/parts/scan-events</Text>, which
          requires a signed session from an enrolled Field Companion device — a browser cannot originate
          one, and should not be able to.
        </Text>

        <View style={styles.lookup}>
          <View style={styles.lookupField}>
            <TextField
              label="Part identifier or serial number"
              value={entered}
              onChangeText={setEntered}
              placeholder="00000000-0000-4000-8000-000000000106"
              error={
                attempted && entryInvalid
                  ? 'Enter a part identifier or the serial number printed on the label.'
                  : lookupError
              }
              hint={
                resolvedFrom
                  ? `Resolved from serial ${resolvedFrom}; no scan event was recorded`
                  : cell.value
                    ? `Cell reports ${shortId(cell.value.partId)}`
                    : undefined
              }
            />
          </View>
          <ActionButton
            label={resolving ? 'RESOLVING' : 'OPEN'}
            disabled={resolving}
            onPress={() => {
              void open();
            }}
          />
          {selected ? (
            <ActionButton
              label="BACK TO THE CELL"
              kind="secondary"
              onPress={() => {
                setSelected(undefined);
                setEntered('');
                setAttempted(false);
                setResolvedFrom(undefined);
                setLookupError(undefined);
              }}
            />
          ) : null}
        </View>
      </Panel>

      {partId === undefined ? (
        <Panel>
          <Text style={styles.muted}>
            No part has been selected and no cell assignment in this identity names one.
          </Text>
        </Panel>
      ) : null}

      {notFound ? (
        <Panel>
          <SectionHeading eyebrow="Not found" title="No part answers to that identifier" />
          <Text style={styles.copy}>
            Either no such part exists, or it belongs to a project this identity is not scoped to. Those
            two answer identically on purpose: a reader who could tell them apart could map the parts of
            a project they cannot see.
          </Text>
        </Panel>
      ) : genealogy.error !== undefined ? (
        <CapabilityNotice
          error={genealogy.cause ?? genealogy.error}
          context={`GET /api/v1/parts/${partId}/genealogy`}
        />
      ) : null}

      {part ? (
        <>
          <View style={[styles.columns, narrow && styles.columnsStacked]}>
            <View style={styles.column}>
              <Panel>
                <SectionHeading eyebrow="Permanent identity" title={part.serialNumber} />
                <View style={styles.metaGrid}>
                  <KeyValue label="Identity URI" value={part.permanentIdentityUri} mono />
                  <KeyValue label="Part identifier" value={part.partId} mono />
                  <KeyValue label="Project" value={part.projectId} mono />
                </View>
                <Text style={styles.note}>
                  CH1-MFG-FR-0002 requires the identity to be permanent, so it is issued once and never
                  recomputed from anything that can change.
                </Text>
              </Panel>

              <Panel>
                <SectionHeading eyebrow="Origin" title="What governed this part" />
                <View style={styles.metaGrid}>
                  <KeyValue label="Work order" value={part.workOrderId} mono />
                  <KeyValue label="Revision" value={part.revisionId} mono />
                  <KeyValue label="Made by" value={part.operatorId} />
                </View>
                <Text style={styles.note}>
                  The revision is the controlled definition in force when the order was raised. The
                  catalogue has no work-order read operation, so the order is named by identifier rather
                  than expanded.
                </Text>
                {/*
                  The order the part came from, and the quality record it belongs to. Both
                  identifiers were already printed here; following one used to mean copying
                  a UUID into another screen's search box.
                */}
                <ConnectedObjects
                  items={[
                    { kind: 'workOrder', id: part.workOrderId, caption: 'order' },
                    { kind: 'testRun', id: part.partId, caption: 'inspection', extra: { partId: part.partId } },
                  ]}
                />
              </Panel>
            </View>

            <View style={styles.column}>
              <Panel>
                <SectionHeading eyebrow="Disposition" title="Hold and release" />
                <View style={styles.metaGrid}>
                  <KeyValue label="Status" value={part.status} />
                  <KeyValue label="Open nonconformities" value={String(part.openNcrIds.length)} />
                </View>
                {part.openNcrIds.length > 0 ? (
                  <View style={styles.ncrList}>
                    {/*
                      Each open nonconformity now reaches the screen that can dispose of
                      it. This is the end of the chain the owner described - alarm to
                      cell, cell to order, order to part, part to its nonconformities,
                      nonconformity to its disposition - and it was the last link still
                      rendered as text somebody had to copy.
                    */}
                    {part.openNcrIds.map((id) => (
                      <View key={id} style={styles.ncrRow}>
                        <Text style={styles.ncrLine}>OPEN NCR</Text>
                        <ObjectLink kind="ncr" id={id} extra={{ partId: part.partId }} />
                      </View>
                    ))}
                    <Text style={styles.note}>
                      A part with an open nonconformity is held. It is released only by a closing
                      disposition after a passing retest, and never by this screen.
                    </Text>
                  </View>
                ) : null}

                <Divider />

                {part.release ? (
                  <View style={styles.metaGrid}>
                    <KeyValue label="Release record" value={part.release.releaseId} mono />
                    <KeyValue label="Released by" value={part.release.inspectorId} />
                    <KeyValue label="Released at" value={instant(part.release.releasedAt)} />
                  </View>
                ) : (
                  <Text style={styles.note}>
                    Not released. Release is an Inspector action, independent of whoever performed the
                    work, and requires a phishing-resistant step-up redeemed for that one release.
                  </Text>
                )}
              </Panel>

              <Panel>
                <SectionHeading eyebrow="Provenance" title="Where this evidence came from" />
                {/* The server's own words. A fixed string here could misdescribe the
                    durability of controlled evidence. */}
                <Text style={styles.provenance}>{genealogy.value?.provenance}</Text>
                <Text style={styles.note}>
                  Evidence completeness: {genealogy.value?.evidenceCompleteness}. Reported by Control
                  Core, not computed here.
                </Text>
              </Panel>
            </View>
          </View>

          <SectionHeading eyebrow="History" title={`Measurements (${part.measurements.length})`} />
          {part.measurements.length === 0 ? (
            <Panel>
              <Text style={styles.muted}>
                No measurement has been recorded against this part. That is an empty history, not a
                missing one — nothing has been measured yet.
              </Text>
            </Panel>
          ) : (
            <Panel>
              {part.measurements.map((measurement, index) => (
                <MeasurementRow
                  key={measurement.measurementId}
                  measurement={measurement}
                  superseded={part.measurements.some(
                    (other) => other.supersedesMeasurementId === measurement.measurementId,
                  )}
                  first={index === 0}
                />
              ))}
            </Panel>
          )}
        </>
      ) : null}
    </>
  );
}

function MeasurementRow({
  measurement,
  superseded,
  first,
}: {
  measurement: QualityMeasurement;
  superseded: boolean;
  first: boolean;
}) {
  const inLimit = measurement.value >= measurement.lowerLimit && measurement.value <= measurement.upperLimit;

  return (
    <View style={styles.measurement}>
      {first ? null : <Divider />}
      <View style={styles.measurementHead}>
        <View style={styles.measurementIdentity}>
          <Text style={styles.measurementName}>{measurement.characteristic}</Text>
          <Text style={styles.measurementId}>{shortId(measurement.measurementId)}</Text>
        </View>
        {/* Result, limit position and supersession are all written out. Never colour alone. */}
        <View style={styles.measurementMarks}>
          <StatusPill
            label={measurement.result === 'Pass' ? 'PASS' : 'FAIL'}
            tone={measurement.result === 'Pass' ? 'good' : 'danger'}
          />
          {measurement.mandatory ? <StatusPill label="MANDATORY" tone="info" /> : null}
          {superseded ? <StatusPill label="SUPERSEDED" tone="neutral" /> : null}
        </View>
      </View>

      <Text style={styles.reading}>
        {measurement.value} {measurement.unit} against {measurement.lowerLimit}–{measurement.upperLimit}{' '}
        {measurement.unit} · {inLimit ? 'within limits' : 'OUTSIDE LIMITS'}
      </Text>

      <View style={styles.metaGrid}>
        <KeyValue label="Measured at" value={instant(measurement.measuredAt)} />
        {/* The controlled run the result belongs to. CH1-MFG-FR-0002 asks a part to
            resolve to its tests, and without this a reading has no procedure behind it. */}
        <KeyValue label="Test run" value={shortId(measurement.testRunId)} mono />
        <KeyValue label="Source device" value={measurement.sourceDeviceId} mono />
        <KeyValue label="Calibration record" value={shortId(measurement.calibrationRecordId)} mono />
        <KeyValue
          label="Calibration"
          value={measurement.calibrationValid ? 'Valid when measured' : 'Not valid'}
        />
      </View>

      {measurement.supersedesMeasurementId ? (
        <Text style={styles.supersedes}>
          Retest superseding {shortId(measurement.supersedesMeasurementId)}. The earlier result is kept:
          CH1-QMS-FR-0004 requires the failure and its rework to both remain readable.
        </Text>
      ) : null}
    </View>
  );
}

function statusTone(status: PartStatus): StatusTone {
  switch (status) {
    case 'Released':
      return 'good';
    case 'Accepted':
      return 'info';
    case 'Hold':
      return 'danger';
    default:
      return 'neutral';
  }
}

function statusNote(status: PartStatus, openNcrs: number): string {
  switch (status) {
    case 'Hold':
      return `Held by ${openNcrs} open nonconformity${openNcrs === 1 ? '' : 's'}`;
    case 'Accepted':
      return 'Accepted, and awaiting independent release';
    case 'Released':
      return 'Released by an independent Inspector';
    default:
      return 'In process; no mandatory result has failed';
  }
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.lg, marginBottom: Spacing.xl },
  columns: { flexDirection: 'row', gap: Spacing.xl, marginTop: Spacing.xl },
  columnsStacked: { flexDirection: 'column' },
  column: { flex: 1, minWidth: 0, gap: Spacing.lg },
  copy: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  strong: { color: Palette.ink, fontWeight: '800' },
  note: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  muted: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 11 },
  lookup: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.md, flexWrap: 'wrap', marginTop: Spacing.md },
  lookupField: { flex: 1, minWidth: 260 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  ncrRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  ncrList: { gap: 4, marginTop: Spacing.sm },
  ncrLine: { color: Palette.red, fontFamily: Type.mono, fontSize: 10, fontWeight: '700' },
  provenance: { color: Palette.ink, fontFamily: Type.mono, fontSize: 11, marginTop: 4 },
  measurement: { gap: Spacing.sm, paddingVertical: Spacing.sm },
  measurementHead: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: Spacing.md },
  measurementIdentity: { flex: 1, gap: 2 },
  measurementName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 13, fontWeight: '700' },
  measurementId: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
  measurementMarks: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  reading: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 11 },
  supersedes: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
});
