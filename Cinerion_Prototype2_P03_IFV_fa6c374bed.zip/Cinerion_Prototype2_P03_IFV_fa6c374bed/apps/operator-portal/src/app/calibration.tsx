// @screen CH1-UX-SCR-0012 — Instrument and calibration register: validity and certificates

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { CalibrationPage, CalibrationEntry } from '@/api/contracts';
import { instant } from '@/api/format';
import { useObserved } from '@/api/use-observed';
import { useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { KpiCard, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0012 — instrument and calibration register.
 *
 * screens.json declares this for the Inspector and Maintenance, showing "validity and
 * certificates". The subject is whether a measurement taken with an instrument is
 * admissible, which CH1-QMS-FR-0005 makes a question about the certificate rather than
 * about the instrument.
 *
 * WHETHER A CERTIFICATE IS STILL VALID IS NOT DECIDED HERE. The service states `expired`
 * and `daysRemaining` on every row, and this screen renders what it was told. Two screens
 * subtracting dates for themselves is how two readers come to disagree about whether an
 * instrument was in calibration on the day a part was released.
 *
 * The read is an owner-approved extension, recorded in
 * traceability/owner-approved-operations.json: the P03 catalogue writes calibration
 * records and reads none, so this screen could not be built at all before it.
 */
export default function CalibrationScreen() {
  return (
    <AppShell active="calibration">
      <SessionGate>
        <CalibrationRegister />
      </SessionGate>
    </AppShell>
  );
}

/** Ordered worst first: an expired certificate is the one an inspector must not miss. */
function severity(entry: CalibrationEntry): number {
  if (entry.expired) return 0;
  if (entry.daysRemaining <= 30) return 1;
  return 2;
}

function validity(entry: CalibrationEntry): { label: string; tone: StatusTone } {
  if (entry.expired) return { label: 'EXPIRED', tone: 'danger' };
  if (entry.daysRemaining <= 30) return { label: `${entry.daysRemaining} DAYS LEFT`, tone: 'warning' };
  return { label: 'IN CALIBRATION', tone: 'good' };
}

function CalibrationRegister() {
  const { width } = useWindowDimensions();
  const narrow = width < 1080;
  const session = useSession();
  const roles = session.claims?.roles ?? [];

  // The same three roles the service enforces. Withheld rather than offered and refused:
  // a register a caller may not read is not a register with no instruments in it.
  const canRead =
    roles.includes('Inspector') || roles.includes('MaintenanceEngineer') || roles.includes('Engineer');

  const register = useObserved<CalibrationPage>(
    canRead ? '/api/v1/calibrations' : undefined,
    session.accessToken,
  );

  const entries = [...(register.value?.items ?? [])].sort(
    (left, right) => severity(left) - severity(right) || left.instrumentId.localeCompare(right.instrumentId),
  );
  const expired = entries.filter((entry) => entry.expired).length;
  const expiring = entries.filter((entry) => !entry.expired && entry.daysRemaining <= 30).length;

  return (
    <>
      <PageIntro
        eyebrow="AssetVault / CH1-QMS-FR-0005"
        title="Instrument and calibration register"
        description="A measurement is admissible only if the instrument that produced it was in calibration when it did. Validity is stated by Control Core on every row, not computed here, so two readers cannot disagree about it."
        aside={<FreshnessTag freshness={register.freshness} quality={register.quality} />}
      />

      {!canRead ? (
        <Panel>
          <SectionHeading eyebrow="Withheld" title="The calibration register is not shown to this identity" />
          <Text style={styles.blocked}>
            access.json puts calibration validity with the Inspector and the Maintenance Engineer, and the
            Engineer reads it too. This session holds none of the three. The register is WITHHELD rather than
            empty, and this says which — an empty register would read as a project with no instruments in it.
          </Text>
        </Panel>
      ) : (
        <>
          <View style={[styles.kpis, narrow && styles.stacked]}>
            <KpiCard label="Certificates held" value={`${entries.length}`} note="In this project" tone="info" />
            <KpiCard
              label="Expired"
              value={`${expired}`}
              note={expired === 0 ? 'No instrument is out of calibration' : 'Measurements from these are not admissible'}
              tone={expired === 0 ? 'good' : 'danger'}
            />
            <KpiCard
              label="Expiring within 30 days"
              value={`${expiring}`}
              note="Recalibrate before the certificate lapses"
              tone={expiring === 0 ? 'good' : 'warning'}
            />
          </View>

          <Panel>
            <SectionHeading
              eyebrow="GET /api/v1/calibrations"
              title="Certificates and validity"
              action={<StatusPill label="READ ONLY" tone="info" />}
            />

            {register.error !== undefined ? (
              <CapabilityNotice error={register.cause ?? register.error} context="GET /api/v1/calibrations" />
            ) : entries.length === 0 ? (
              <Text style={styles.empty}>
                No calibration certificate is recorded in this project. That is an empty register, not a
                withheld one — this identity may read it.
              </Text>
            ) : (
              <View>
                {entries.map((entry) => {
                  const state = validity(entry);
                  return (
                    <View key={entry.calibrationId} style={[styles.row, narrow && styles.rowStacked]}>
                      <View style={styles.identity}>
                        <Text style={styles.instrument}>{entry.instrumentId}</Text>
                        <Text style={styles.certificate}>Certificate {entry.certificateNumber}</Text>
                      </View>
                      <View style={styles.dates}>
                        <Text style={styles.dateLabel}>Calibrated</Text>
                        <Text style={styles.dateValue}>{instant(entry.calibratedAt)}</Text>
                      </View>
                      <View style={styles.dates}>
                        <Text style={styles.dateLabel}>Valid until</Text>
                        <Text style={styles.dateValue}>{instant(entry.validUntil)}</Text>
                      </View>
                      <View style={styles.statusCell}>
                        <StatusPill label={entry.status.toUpperCase()} tone="neutral" />
                        <StatusPill label={state.label} tone={state.tone} />
                      </View>
                    </View>
                  );
                })}
              </View>
            )}

            <Text style={styles.footnote}>
              The register records the certificate, never its content. CH1-DOC-FR-0002&apos;s vault holds the
              document itself and is a declared future phase, so this screen shows what governs admissibility
              and does not offer the certificate to download.
            </Text>
          </Panel>
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  kpis: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  row: {
    minHeight: 62,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Palette.line,
  },
  rowStacked: { flexDirection: 'column', alignItems: 'flex-start', paddingVertical: Spacing.md, gap: Spacing.sm },
  identity: { flex: 1.4, minWidth: 0, gap: 3 },
  instrument: { color: Palette.ink, fontFamily: Type.mono, fontSize: 10, fontWeight: '800' },
  certificate: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  dates: { flex: 1, minWidth: 0, gap: 3 },
  dateLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  dateValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  statusCell: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, paddingVertical: Spacing.lg, lineHeight: 14 },
  blocked: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 15, paddingTop: Spacing.sm },
  footnote: {
    marginTop: Spacing.lg,
    borderRadius: Radius.md,
    borderLeftWidth: 3,
    borderLeftColor: Palette.cyan,
    backgroundColor: Palette.canvasRaised,
    padding: Spacing.md,
    color: Palette.inkSoft,
    fontFamily: Type.sans,
    fontSize: 9,
    lineHeight: 14,
  },
});
