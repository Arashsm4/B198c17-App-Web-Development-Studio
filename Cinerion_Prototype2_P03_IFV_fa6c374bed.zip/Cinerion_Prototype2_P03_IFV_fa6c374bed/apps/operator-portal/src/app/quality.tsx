// @screen CH1-UX-SCR-0010 — Inspection and FAT dashboard: steps, evidence, limits and result
// @screen CH1-UX-SCR-0011 — NCR, rework and retest: controlled disposition workflow

import { useLocalSearchParams } from 'expo-router';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type {
  CalibrationEntry,
  CalibrationPage,
  CellState,
  PartGenealogy,
  PartRecord,
  QualityMeasurement,
} from '@/api/contracts';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice, NotConnectedNotice } from '@/components/capability';
import { ActAuthority } from '@/components/act-authority';
import { ControlledActionForm } from '@/components/controlled-action-form';
import { ConnectedObjects } from '@/components/object-link';
import { Panel, SectionHeading, StatusPill } from '@/components/primitives';
import {
  DispositionNcr,
  RaiseNcr,
  RecordMeasurement,
  ReleasePart,
} from '@/components/quality-actions';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

export default function QualityScreen() {
  return (
    <AppShell active="quality">
      <SessionGate>
        <Quality />
      </SessionGate>
    </AppShell>
  );
}

function Quality() {
  const { width } = useWindowDimensions();
  const compact = width < 1120;
  const session = useSession();

  // The part under inspection is whichever part the assigned cell is working on.
  const primaryCell = assignedCells(session.claims)[0];
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );
  /**
   * The part a link asked about, when this screen was reached from one.
   *
   * A nonconformity link and a test-run link both carry the part they belong to, because
   * the quality loop is read through the PART: the controlled catalogue has no operation
   * that reads an NCR or a test run on its own, and `GET /parts/{partId}/genealogy` is
   * what carries the measurements, the open nonconformities and the release. So a link to
   * a nonconformity opens the part it is held against, which is the record the inspector
   * has to act on anyway.
   */
  const arrived = useLocalSearchParams<{ partId?: string; ncrId?: string; testRunId?: string }>();
  const partId = arrived.partId ?? cell.value?.partId;
  const genealogy = useObserved<PartGenealogy>(
    partId ? `/api/v1/parts/${partId}/genealogy` : undefined,
    session.accessToken,
  );

  const part = genealogy.value?.part;

  // The instrument calibrations this identity can see. A measurement must name the one its
  // instrument was covered by, and the server refuses an expired record — so the operator
  // picks from what exists rather than typing an identifier nothing would accept.
  const calibrations = useObserved<CalibrationPage>('/api/v1/calibrations', session.accessToken);

  return (
    <>
      <PageIntro
        eyebrow="OpenInspect / TraceCore"
        title="Inspection, NCR, and release"
        description="Measurements are evaluated against controlled limits and retain unit, source device, calibration context and time. A failed mandatory result holds the physical part until controlled disposition and a passing retest."
        aside={<PartStatusPill part={part} />}
      />

      {!primaryCell ? (
        <NotConnectedNotice detail="This identity carries no cell assignment, so no part is in scope." />
      ) : null}
      {genealogy.error ? (
        <CapabilityNotice error={new Error(genealogy.error)} context={`GET /api/v1/parts/${partId}/genealogy`} />
      ) : null}

      <PartIdentity part={part} genealogy={genealogy.value} freshness={genealogy.freshness} />

      {/*
        Controlled evidence, as a document. The three templates this build holds are all
        about a part - its genealogy, its test summary, its nonconformity register - so an
        inspector who wants one is already standing here.

        The operation is DETERMINISTIC and the description says so, because that is the
        property an operator needs and cannot see: the same inputs under the same template
        revision are the same report, and a second press answers with the document that
        already exists rather than producing another one covering the same records with a
        different checksum.
      */}
      <ActAuthority act="generateReport">
        <Panel>
          <SectionHeading
            eyebrow="ReportForge / CH1-DOC-FR-0001"
            title="Generate controlled evidence"
            action={<StatusPill label="DETERMINISTIC" tone="info" />}
          />
          <Text style={styles.reportNote}>
            A report is rendered from records this platform holds, named by identifier. Pressing
            this twice with the same inputs does not produce two documents: the same inputs under
            the same template revision resolve to the report that already exists.
          </Text>
          <ControlledActionForm
            label="GENERATE A REPORT"
            title="generate a controlled report"
            description="The template decides what is rendered and which records it needs. The server refuses a template this build does not hold and names the ones it does."
            accessToken={session.accessToken}
            endpoint="/api/v1/reports"
            fields={[
              {
                name: 'templateId',
                label: 'Template',
                initial: 'CH1-RPT-TPL-PART-GENEALOGY',
                choices: [
                  'CH1-RPT-TPL-PART-GENEALOGY',
                  'CH1-RPT-TPL-TEST-SUMMARY',
                  'CH1-RPT-TPL-NCR-REGISTER',
                ],
              },
              {
                name: 'reportType',
                label: 'Report type',
                initial: 'QualityEvidence',
                hint: 'How this document is classified in the register.',
              },
              {
                name: 'inputObjectIds',
                label: 'Record identifiers',
                initial: partId ?? '',
                hint: 'One per line. The part on this screen is offered as a starting point.',
                multiline: true,
                transform: (value: string) =>
                  value
                    .split(/\r?\n/)
                    .map((line) => line.trim())
                    .filter((line) => line.length > 0),
              },
            ]}
            extraBody={{ inputObjectType: 'Part' }}
            disabledReason={
              partId === undefined
                ? 'No part is in scope, so there is nothing to report on. The panel above says why.'
                : undefined
            }
            onDone={() => genealogy.refresh()}
          />
        </Panel>
      </ActAuthority>

      <View style={[styles.grid, compact && styles.stacked]}>
        <Measurements
          part={part}
          calibrations={calibrations.value?.items ?? []}
          accessToken={session.accessToken}
          onReconcile={genealogy.refresh}
        />
        <NcrPanel part={part} accessToken={session.accessToken} onReconcile={genealogy.refresh} />
      </View>

      <Genealogy part={part} />
    </>
  );
}

function PartStatusPill({ part }: { part: PartRecord | undefined }) {
  if (!part) return <StatusPill label="NO PART RETRIEVED" tone="neutral" />;
  const tone = part.status === 'Hold' ? 'warning' : part.status === 'Released' ? 'good' : 'info';
  return <StatusPill label={`PART ${part.status.toUpperCase()}`} tone={tone} />;
}

function PartIdentity({
  part,
  genealogy,
  freshness,
}: {
  part: PartRecord | undefined;
  genealogy: PartGenealogy | undefined;
  freshness: CellState['freshness'];
}) {
  return (
    <Panel style={styles.partPanel}>
      <View style={styles.partHeader}>
        <View>
          <Text style={styles.partEyebrow}>PERMANENT PHYSICAL IDENTITY</Text>
          <Text style={styles.partId} selectable>{part?.serialNumber ?? '—'}</Text>
          <Text style={styles.partProduct}>
            {part ? `Revision ${part.revisionId}` : 'No product revision retrieved'}
          </Text>
        </View>
        <View style={styles.partFacts}>
          <Fact label="Work order" value={part?.workOrderId ?? '—'} />
          <Fact label="Operator" value={part?.operatorId ?? '—'} />
          <Fact label="Evidence" value={genealogy?.evidenceCompleteness ?? '—'} />
          <PartStatusPill part={part} />
        </View>
      </View>
      <View style={styles.identityStrip}>
        {/* The permanent identity is the server's, not a string this screen builds. */}
        <Text style={styles.identityUri} selectable>
          {part?.permanentIdentityUri ?? 'No permanent identity retrieved'}
        </Text>
        <View style={styles.identityRight}>
          <FreshnessTag freshness={freshness} />
          <Text style={styles.identityNote}>QR/RFID resolves identity and state only — never authority.</Text>
        </View>
      </View>

      {/*
        Where this part came from and where its full history lives. The inspector looking
        at a held part usually wants one of exactly these three next: the order that
        authorised it, everything recorded against it, or the people arguing about it.
      */}
      <ConnectedObjects
        items={[
          { kind: 'part', id: part?.partId, caption: 'genealogy' },
          { kind: 'workOrder', id: part?.workOrderId, caption: 'order' },
          {
            kind: 'thread',
            id: genealogy?.contextThreadId,
            caption: 'discussion',
            extra: {
              objectType: 'Part',
              objectId: part?.partId,
              objectLabel: part?.serialNumber,
            },
          },
        ]}
      />
    </Panel>
  );
}

function Measurements({
  part,
  calibrations,
  accessToken,
  onReconcile,
}: {
  part: PartRecord | undefined;
  calibrations: readonly CalibrationEntry[];
  accessToken: string | undefined;
  onReconcile: () => void;
}) {
  const measurements = part?.measurements ?? [];
  const superseded = new Set(
    measurements.map((item) => item.supersedesMeasurementId).filter((id): id is string => id !== null),
  );

  return (
    <Panel style={styles.measurePanel}>
      <SectionHeading
        eyebrow="Controlled acceptance record"
        title="Measurements"
        action={<StatusPill label={`${measurements.length} RECORDED`} tone={measurements.length > 0 ? 'info' : 'neutral'} />}
      />
      {measurements.length === 0 ? (
        <Text style={styles.empty}>
          No measurements have been recorded against this part. An empty acceptance record is not a
          pass; release remains blocked until every mandatory characteristic has a passing result.
        </Text>
      ) : (
        <>
          <View style={styles.tableHeader}>
            <Text style={[styles.headerCell, styles.characteristicCell]}>CHARACTERISTIC</Text>
            <Text style={styles.headerCell}>VALUE</Text>
            <Text style={styles.headerCell}>ACCEPTANCE LIMIT</Text>
            <Text style={styles.headerCell}>RESULT</Text>
          </View>
          {measurements.map((item) => (
            <MeasurementRow key={item.measurementId} item={item} superseded={superseded.has(item.measurementId)} />
          ))}
        </>
      )}
      <RecordMeasurement
        part={part}
        calibrations={calibrations}
        accessToken={accessToken}
        onRecorded={onReconcile}
      />

      <View style={styles.calibrationNotice}>
        <Text style={styles.calibrationTitle}>CALIBRATION RULE ACTIVE</Text>
        <Text style={styles.calibrationText}>
          An instrument whose calibration is not valid is refused at record time, so it cannot
          contribute a controlled acceptance result. A deviation requires separate approval and stays
          visible in the evidence chain.
        </Text>
      </View>
    </Panel>
  );
}

function MeasurementRow({ item, superseded }: { item: QualityMeasurement; superseded: boolean }) {
  return (
    <View style={[styles.tableRow, superseded && styles.rowSuperseded]}>
      <View style={styles.characteristicCell}>
        <Text style={styles.characteristic}>
          {item.characteristic}
          {item.mandatory ? ' · MANDATORY' : ''}
        </Text>
        <Text style={styles.source}>
          {item.sourceDeviceId} · {item.calibrationValid ? 'calibration valid' : 'calibration NOT valid'} ·{' '}
          {item.measuredAt}
        </Text>
        {superseded ? <Text style={styles.supersededNote}>Superseded by a later retest</Text> : null}
      </View>
      <Text style={styles.value}>
        {item.value} {item.unit}
      </Text>
      <Text style={styles.limit}>
        {item.lowerLimit} — {item.upperLimit} {item.unit}
      </Text>
      <StatusPill label={item.result.toUpperCase()} tone={item.result === 'Pass' ? 'good' : 'danger'} />
    </View>
  );
}

function NcrPanel({
  part,
  accessToken,
  onReconcile,
}: {
  part: PartRecord | undefined;
  accessToken: string | undefined;
  onReconcile: () => void;
}) {
  const open = part?.openNcrIds ?? [];
  return (
    <Panel style={styles.ncrPanel}>
      <SectionHeading
        eyebrow="Nonconformance"
        title={open.length > 0 ? `${open.length} open` : 'No open NCR'}
        action={<StatusPill label={open.length > 0 ? 'OPEN' : 'NONE'} tone={open.length > 0 ? 'danger' : 'neutral'} />}
      />
      {open.length > 0 ? (
        <View style={styles.ncrList}>
          {open.map((id) => (
            <View key={id}>
              <Text style={styles.ncrId} selectable>
                {id}
              </Text>
              <DispositionNcr ncrId={id} accessToken={accessToken} onDisposed={onReconcile} />
            </View>
          ))}
        </View>
      ) : (
        <Text style={styles.empty}>
          No nonconformance is open against this part. Absence of an NCR is not acceptance.
        </Text>
      )}

      <RaiseNcr part={part} accessToken={accessToken} onRaised={onReconcile} />

      <View style={styles.releaseGate}>
        <Text style={styles.releaseGateCode}>RELEASE GATE</Text>
        <Text style={styles.releaseGateTitle}>
          {part?.release ? 'Released' : 'Independent acceptance not granted'}
        </Text>
        <Text style={styles.releaseGateText}>
          {part?.release
            ? `Released by ${part.release.inspectorId} at ${part.release.releasedAt}.`
            : 'Close every NCR, execute authorised rework, repeat the controlled test, obtain a passing mandatory result, then an independent Inspector releases. The person who performed the operation cannot release their own work.'}
        </Text>
        <ReleasePart part={part} accessToken={accessToken} onReleased={onReconcile} />
      </View>
    </Panel>
  );
}

/**
 * The digital thread as far as it has actually been retrieved. Each step reports the
 * evidence that exists, so an unreached step reads as pending rather than complete.
 */
function Genealogy({ part }: { part: PartRecord | undefined }) {
  const mandatory = (part?.measurements ?? []).filter((item) => item.mandatory);
  const current = new Map<string, QualityMeasurement>();
  for (const item of mandatory) current.set(item.characteristic, item);
  const allPass = current.size > 0 && [...current.values()].every((item) => item.result === 'Pass');

  const nodes: readonly { code: string; title: string; detail: string; state: 'done' | 'open' | 'failed' | 'blocked' }[] = [
    { code: '01', title: 'Revision pinned', detail: part?.revisionId ?? '—', state: part ? 'done' : 'blocked' },
    { code: '02', title: 'Work order', detail: part?.workOrderId ?? '—', state: part ? 'done' : 'blocked' },
    { code: '03', title: 'Part identity assigned', detail: part?.serialNumber ?? '—', state: part ? 'done' : 'blocked' },
    {
      code: '04',
      title: 'Measurements recorded',
      detail: `${part?.measurements.length ?? 0} recorded`,
      state: (part?.measurements.length ?? 0) > 0 ? 'done' : 'blocked',
    },
    {
      code: '05',
      title: 'Mandatory results',
      detail: current.size === 0 ? 'None recorded' : allPass ? 'All passing' : 'Failure present',
      state: current.size === 0 ? 'blocked' : allPass ? 'done' : 'failed',
    },
    {
      code: '06',
      title: 'NCR and rework',
      detail: (part?.openNcrIds.length ?? 0) > 0 ? `${part!.openNcrIds.length} open` : 'None open',
      state: (part?.openNcrIds.length ?? 0) > 0 ? 'open' : 'done',
    },
    {
      code: '07',
      title: 'Independent release',
      detail: part?.release ? part.release.inspectorId : 'Not released',
      state: part?.release ? 'done' : 'blocked',
    },
  ];

  const pill = { done: 'COMPLETE', open: 'OPEN', failed: 'FAILED', blocked: 'PENDING' } as const;
  const tone = { done: 'good', open: 'warning', failed: 'danger', blocked: 'neutral' } as const;

  return (
    <Panel style={styles.genealogyPanel}>
      <SectionHeading eyebrow="End-to-end digital thread" title="Part genealogy and acceptance path" />
      <View style={styles.genealogyFlow}>
        {nodes.map((node, index) => (
          <View key={node.code} style={styles.genealogyNode}>
            <View style={styles.nodeTop}>
              <View style={styles.nodeCode}>
                <Text style={styles.nodeCodeText}>{node.code}</Text>
              </View>
              <StatusPill label={pill[node.state]} tone={tone[node.state]} />
            </View>
            <Text style={styles.nodeTitle}>{node.title}</Text>
            <Text style={styles.nodeDetail} numberOfLines={1}>
              {node.detail}
            </Text>
            {index < nodes.length - 1 ? <Text style={styles.nodeArrow}>→</Text> : null}
          </View>
        ))}
      </View>
    </Panel>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.fact}>
      <Text style={styles.factLabel}>{label}</Text>
      <Text style={styles.factValue} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  partPanel: { marginBottom: Spacing.md, paddingBottom: 0, overflow: 'hidden' },
  partHeader: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.xl, paddingBottom: Spacing.xl },
  partEyebrow: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.9 },
  partId: { color: Palette.ink, fontFamily: Type.mono, fontSize: 16, fontWeight: '800', marginTop: 6 },
  reportNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  partProduct: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, marginTop: 5 },
  partFacts: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: Spacing.xl },
  fact: { gap: 3, maxWidth: 220 },
  factLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  factValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  identityStrip: { marginHorizontal: -Spacing.xl, paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, backgroundColor: '#081521', borderTopWidth: 1, borderTopColor: Palette.line, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: Spacing.sm },
  identityUri: { color: Palette.violet, fontFamily: Type.mono, fontSize: 9 },
  identityRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap' },
  identityNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  measurePanel: { flex: 1.35, minWidth: 0 },
  ncrPanel: { flex: 0.75, minWidth: 320 },
  tableHeader: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: Palette.lineStrong, paddingBottom: Spacing.sm },
  headerCell: { flex: 1, color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  characteristicCell: { flex: 1.35 },
  tableRow: { minHeight: 67, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: Palette.line, gap: Spacing.sm },
  rowSuperseded: { opacity: 0.55 },
  characteristic: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '700' },
  source: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, marginTop: 4 },
  supersededNote: { color: Palette.amber, fontFamily: Type.mono, fontSize: 7, marginTop: 3 },
  value: { flex: 1, color: Palette.ink, fontFamily: Type.mono, fontSize: 11, fontWeight: '800' },
  limit: { flex: 1, color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 16 },
  calibrationNotice: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.cyan, paddingLeft: Spacing.md, gap: 5 },
  calibrationTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '800' },
  calibrationText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  ncrList: { gap: 6 },
  ncrId: { color: Palette.ink, fontFamily: Type.mono, fontSize: 10 },
  releaseGate: { marginTop: Spacing.xl, borderRadius: Radius.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#6A343A', padding: Spacing.lg, gap: 6 },
  releaseGateCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  releaseGateTitle: { color: '#F2B3B5', fontFamily: Type.sans, fontSize: 11, fontWeight: '800' },
  releaseGateText: { color: '#C99699', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  genealogyPanel: { overflow: 'hidden' },
  genealogyFlow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  genealogyNode: { flex: 1, minWidth: 145, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, borderWidth: 1, borderColor: Palette.line, padding: Spacing.md, position: 'relative', gap: 6 },
  nodeTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6 },
  nodeCode: { width: 24, height: 24, borderRadius: 7, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.panelRaised },
  nodeCodeText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800' },
  nodeTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '700' },
  nodeDetail: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  nodeArrow: { position: 'absolute', right: -10, top: '50%', color: Palette.lineStrong, zIndex: 2 },
});
