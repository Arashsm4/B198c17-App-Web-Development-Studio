// @screen CH1-UX-SCR-0009 — Automatic procedure progress: read-only sequence and hold points

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type {
  CellState,
  PartGenealogy,
  ProductGroup,
  ProductRevisionSummary,
  QualityMeasurement,
  RouteStep,
} from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { Divider, KeyValue, KpiCard, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0009 — automatic procedure progress: read-only sequence and hold points.
 *
 * CH1-AUT-FDS-0001 puts sequence execution in the controller: committed procedures run
 * through named steps with entry action, steady action, exit condition, timeout, limits
 * and evidence, and a hold point removes or inhibits energy until a new preparation and
 * confirmation are obtained. The controlled sequence a part is being made to is the route
 * of the revision governing it, and a route step marked for mandatory inspection is a
 * hold point.
 *
 * There is deliberately no step pointer on this screen. **No controlled operation reports
 * which step a controller is executing** — `GET /api/v1/cells/{cellId}/state` reports the
 * cell's own state, not a position in a sequence, and the route comes from the revision
 * rather than from the controller running it. Drawing a highlighted "current step" would
 * therefore be a guess rendered as fact, on a screen a Local Confirmer would use to decide
 * whether a hold has been reached. So the sequence is shown, the hold points are marked,
 * the evidence the part actually carries is listed beside them, and the gap between the
 * two is stated rather than bridged.
 *
 * Every control is absent by design: this screen reads, and nothing here can start,
 * advance, skip or release a step.
 */
export default function ProcedureScreen() {
  return (
    <AppShell active="procedure">
      <SessionGate>
        <Procedure />
      </SessionGate>
    </AppShell>
  );
}

function Procedure() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();
  const primaryCell = assignedCells(session.claims)[0];

  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  // The part on the cell resolves to the revision that governs it, which is the only
  // controlled route to the sequence: cell state names a work order, and nothing in the
  // catalogue reads a work order back.
  const partId = cell.value?.partId;
  const genealogy = useObserved<PartGenealogy>(
    partId ? `/api/v1/parts/${partId}/genealogy` : undefined,
    session.accessToken,
  );
  const products = useObserved<readonly ProductGroup[]>('/api/v1/products', session.accessToken);

  const part = genealogy.value?.part;
  const revision = products.value
    ?.flatMap((group) => group.revisions)
    .find((item) => item.revisionId === part?.revisionId);

  // screens.json declares this screen for the Local Confirmer and the Inspector, but
  // api_endpoints.json gives the genealogy to "Engineer, Inspector or Auditor" — and
  // access.json agrees. A Local Confirmer holding neither of the other three therefore
  // receives 404 for the only read that resolves the governing revision, which was
  // confirmed against a running service rather than inferred. Naming that is the
  // difference between "the sequence is unavailable to you and here is why" and an
  // empty page that reads as "there is no procedure".
  const roles = session.claims?.roles ?? [];
  const canResolveRevision = ['Engineer', 'Inspector', 'Auditor'].some((role) => roles.includes(role));
  const localConfirmerOnly = roles.includes('LocalConfirmer') && !canResolveRevision;

  const route = [...(revision?.route ?? [])].sort((a, b) => a.stepNumber - b.stepNumber);
  const holdPoints = route.filter((step) => step.mandatoryInspection);
  const mandatory = (part?.measurements ?? []).filter((item) => item.mandatory);

  return (
    <>
      <PageIntro
        eyebrow="AutoCore / CH1-UX-SCR-0009"
        title="Automatic procedure progress"
        description="The controlled sequence the part on this cell is being made to, and the hold points inside it. Sequence execution belongs to the controller; this screen reads and can change nothing."
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />

      {primaryCell === undefined ? (
        <View style={styles.notice}>
          <Text style={styles.noticeCode}>NO CELL ASSIGNMENT</Text>
          <Text style={styles.noticeText}>
            This identity carries no ch1_cell scope, so there is no cell whose loaded procedure
            could be read. Cell assignment is granted by an administrator in the identity provider.
          </Text>
        </View>
      ) : null}

      {cell.error !== undefined ? (
        <CapabilityNotice error={cell.cause ?? cell.error} context="GET /api/v1/cells/{cellId}/state" />
      ) : null}

      {localConfirmerOnly ? (
        <View style={styles.notice}>
          <Text style={styles.noticeCode}>THE SEQUENCE CANNOT BE RESOLVED FOR THIS IDENTITY</Text>
          <Text style={styles.noticeText}>
            This screen is declared for the Local Confirmer and the Inspector, but the only
            controlled read that resolves which revision governs the part on this cell —{' '}
            <Text style={styles.mono}>GET /api/v1/parts/&#123;partId&#125;/genealogy</Text> — is given to
            the Engineer, Inspector or Auditor. A Local Confirmer holding none of those three is
            answered exactly as for a part that does not exist, so the sequence below is blank
            because it could not be read, not because there is none. Ask an Inspector, or hold one
            of those roles.
          </Text>
        </View>
      ) : genealogy.error !== undefined ? (
        <CapabilityNotice
          error={genealogy.cause ?? genealogy.error}
          context="GET /api/v1/parts/{partId}/genealogy"
        />
      ) : null}

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Cell state"
          value={cell.value?.state?.toUpperCase() ?? '—'}
          note="Reported by the cell, not a position in the sequence"
          tone={cell.value ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Controlled steps"
          value={revision ? String(route.length) : '—'}
          note={
            revision
              ? `Revision ${revision.revisionCode} of ${revision.productCode}`
              : 'The governing revision has not been resolved'
          }
          tone={revision ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Hold points"
          value={revision ? String(holdPoints.length) : '—'}
          note="Steps the route marks for mandatory inspection"
          tone={holdPoints.length > 0 ? 'warning' : 'neutral'}
        />
        <KpiCard
          label="Part disposition"
          value={part?.status?.toUpperCase() ?? '—'}
          note={
            part
              ? part.openNcrIds.length > 0
                ? `${part.openNcrIds.length} open nonconformity`
                : 'No open nonconformity'
              : 'No part loaded on this cell'
          }
          tone={part?.status === 'Hold' ? 'danger' : part ? 'info' : 'neutral'}
        />
      </View>

      <View style={[styles.grid, narrow && styles.stacked]}>
        <Sequence route={route} revision={revision} loading={products.loading || genealogy.loading} />
        <View style={styles.column}>
          <LoadedWork cell={cell.value} revision={revision} />
          <AcceptanceEvidence measurements={mandatory} />
        </View>
      </View>

      <Panel>
        <SectionHeading eyebrow="CH1-AUT-FDS-0001" title="What this screen cannot tell you" />
        <Text style={styles.body}>
          <Text style={styles.em}>Which step is executing.</Text> The P03 catalogue contains no
          operation that reports a controller&apos;s position in a sequence. The cell reports its own
          state and the part reports its evidence; neither is a step pointer, and this screen will
          not draw one from them.
        </Text>
        <Text style={styles.body}>
          <Text style={styles.em}>Whether a hold point has been reached.</Text> A hold point removes
          or inhibits configured energy at the controller and requires a fresh preparation and local
          confirmation before the procedure continues. That state lives in the controller, and the
          guarantee that a software loop cannot silently skip a mandatory hold or acceptance
          measurement is held there and in the quality workflow — not by anything rendered here.
        </Text>
        <Text style={styles.body}>
          <Text style={styles.em}>Which measurement belongs to which step.</Text> A measurement
          records a characteristic and its limits, and the controlled record does not associate it
          with a route step. The acceptance evidence is therefore listed beside the sequence rather
          than inside it.
        </Text>
        <Divider />
        <Text style={styles.footnote}>
          Interrupted execution never resumes automatically. Recovery requires the cause removed,
          local authority, a reset edge and reconciled work-order state, all of which happen at the
          cell.
        </Text>
      </Panel>
    </>
  );
}

function Sequence({
  route,
  revision,
  loading,
}: {
  route: readonly RouteStep[];
  revision: ProductRevisionSummary | undefined;
  loading: boolean;
}) {
  return (
    <Panel style={styles.wide}>
      <SectionHeading
        eyebrow={revision ? `${revision.productCode} · ${revision.revisionCode}` : 'Controlled route'}
        title="Sequence and hold points"
        action={
          <StatusPill
            label={revision ? revision.lifecycleState.toUpperCase() : 'UNRESOLVED'}
            tone={revision?.lifecycleState === 'Released' ? 'good' : revision ? 'warning' : 'neutral'}
          />
        }
      />

      {revision === undefined ? (
        <Text style={styles.muted}>
          {loading
            ? 'Resolving the revision that governs the part on this cell.'
            : 'No governing revision could be resolved. The sequence is read from the revision the ' +
              'part was made under, so without a part on the cell there is no controlled route to show.'}
        </Text>
      ) : route.length === 0 ? (
        <Text style={styles.muted}>
          This revision carries no route steps. That is an empty controlled sequence, not a missing
          one — no operations have been defined against it.
        </Text>
      ) : (
        <View style={styles.steps}>
          {route.map((step, index) => (
            <View key={step.stepNumber} style={styles.stepRow}>
              <View style={styles.rail}>
                <View style={[styles.dot, step.mandatoryInspection && styles.dotHold]} />
                {index < route.length - 1 ? <View style={styles.line} /> : null}
              </View>
              <View style={styles.stepCopy}>
                <View style={styles.stepHead}>
                  <Text style={styles.stepNumber}>{String(step.stepNumber).padStart(3, '0')}</Text>
                  <Text style={styles.stepCode}>{step.operationCode}</Text>
                  {step.mandatoryInspection ? <StatusPill label="HOLD POINT" tone="warning" /> : null}
                </View>
                <Text style={styles.stepDescription}>{step.description}</Text>
                {step.mandatoryInspection ? (
                  <Text style={styles.stepHold}>
                    Mandatory inspection. Configured energy is removed or inhibited here, and the
                    procedure continues only after a new preparation and local confirmation.
                  </Text>
                ) : null}
              </View>
            </View>
          ))}
        </View>
      )}

      {revision ? (
        <>
          <Divider />
          <View style={styles.metaGrid}>
            <KeyValue label="Revision" value={revision.revisionId} mono />
            <KeyValue label="Source checksum" value={shortId(revision.sourceChecksum)} mono />
            <KeyValue label="Released" value={revision.releasedAt ? instant(revision.releasedAt) : 'Not released'} />
          </View>
        </>
      ) : null}
    </Panel>
  );
}

function LoadedWork({
  cell,
  revision,
}: {
  cell: CellState | undefined;
  revision: ProductRevisionSummary | undefined;
}) {
  return (
    <Panel>
      <SectionHeading eyebrow="Loaded on the cell" title="What the controller reports" />
      <View style={styles.metaGrid}>
        <KeyValue label="Cell" value={cell?.cellId ?? '—'} mono />
        <KeyValue label="Work order" value={cell ? shortId(cell.workOrderId) : '—'} mono />
        <KeyValue label="Part" value={cell ? shortId(cell.partId) : '—'} mono />
        <KeyValue label="Configuration" value={cell?.configurationRevision ?? '—'} mono />
      </View>
      <Text style={styles.footnote}>
        The cell names the order and part loaded on it. The product revision above was resolved
        through the part, because the catalogue has no operation that reads a work order back.
        {revision === undefined
          ? ' Without that resolution the sequence cannot be shown, and is left blank rather than guessed.'
          : ''}
      </Text>
    </Panel>
  );
}

function AcceptanceEvidence({ measurements }: { measurements: readonly QualityMeasurement[] }) {
  const failed = measurements.filter((item) => item.result === 'Fail');
  return (
    <Panel>
      <SectionHeading
        eyebrow="Acceptance evidence"
        title={`Mandatory results (${measurements.length})`}
        action={
          <StatusPill
            label={failed.length > 0 ? `${failed.length} FAILED` : measurements.length > 0 ? 'ALL PASSED' : 'NONE'}
            tone={failed.length > 0 ? 'danger' : measurements.length > 0 ? 'good' : 'neutral'}
          />
        }
      />
      {measurements.length === 0 ? (
        <Text style={styles.muted}>
          No mandatory measurement has been recorded against this part. That is an empty acceptance
          record, not a satisfied one.
        </Text>
      ) : (
        measurements.map((item, index) => (
          <View key={item.measurementId}>
            {index === 0 ? null : <Divider />}
            <View style={styles.evidenceRow}>
              <Text style={styles.evidenceName}>{item.characteristic}</Text>
              <StatusPill
                label={item.result === 'Pass' ? 'PASS' : 'FAIL'}
                tone={item.result === 'Pass' ? 'good' : 'danger'}
              />
            </View>
            <Text style={styles.evidenceDetail}>
              {item.value} {item.unit} against {item.lowerLimit}–{item.upperLimit} {item.unit} · run{' '}
              {shortId(item.testRunId)} · {instant(item.measuredAt)}
            </Text>
            {item.supersedesMeasurementId ? (
              <Text style={styles.evidenceDetail}>
                Retest superseding {shortId(item.supersedesMeasurementId)}. The earlier result is kept.
              </Text>
            ) : null}
          </View>
        ))
      )}
    </Panel>
  );
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, marginBottom: Spacing.md },
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  column: { flex: 1, minWidth: 320, gap: Spacing.md },
  wide: { flex: 1.25, minWidth: 0 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl, paddingVertical: Spacing.md },
  muted: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17, paddingTop: Spacing.md },
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17, paddingTop: Spacing.md },
  em: { color: Palette.cyan, fontWeight: '800' },
  footnote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15, marginTop: Spacing.sm },
  steps: { paddingTop: Spacing.md },
  stepRow: { flexDirection: 'row', minHeight: 60 },
  rail: { width: 26, alignItems: 'center' },
  dot: { width: 12, height: 12, borderRadius: 6, borderWidth: 2, borderColor: Palette.lineStrong, backgroundColor: Palette.panel, zIndex: 2, marginTop: 3 },
  dotHold: { borderColor: Palette.amber, backgroundColor: Palette.amberSoft },
  line: { position: 'absolute', width: 1, backgroundColor: Palette.lineStrong, top: 15, bottom: -3 },
  stepCopy: { flex: 1, paddingLeft: Spacing.md, paddingBottom: Spacing.md, gap: 4 },
  stepHead: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flexWrap: 'wrap' },
  stepNumber: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 10, fontWeight: '800' },
  stepCode: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 11, fontWeight: '800' },
  stepDescription: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11 },
  stepHold: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15, backgroundColor: Palette.amberSoft, borderRadius: Radius.md, borderWidth: 1, borderColor: '#5F4521', padding: Spacing.sm, marginTop: 4 },
  evidenceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: Spacing.md, paddingTop: Spacing.md },
  evidenceName: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, fontWeight: '700', flexShrink: 1 },
  evidenceDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15, paddingTop: 4 },
  mono: { fontFamily: Type.mono, color: Palette.amber },
  notice: { marginBottom: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  noticeCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  noticeText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
});
