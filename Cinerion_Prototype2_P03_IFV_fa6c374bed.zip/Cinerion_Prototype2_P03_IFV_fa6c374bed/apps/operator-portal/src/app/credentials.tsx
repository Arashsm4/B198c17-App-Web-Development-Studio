// @screen CH1-UX-SCR-0002 — Credential management: passkey, TOTP, card and revocation

import { useState } from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { CredentialSummary, TotpEnrolment } from '@/api/contracts';
import { instant } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useSession } from '@/auth/session';
import { passkeysAvailable, StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice, NotConnectedNotice } from '@/components/capability';
import {
  ActionButton,
  Panel,
  SectionHeading,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { SessionGate } from '@/components/session-gate';
import { StepUpPrompt } from '@/components/step-up';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

export default function CredentialsScreen() {
  return (
    <AppShell active="credentials">
      <SessionGate>
        <Credentials />
      </SessionGate>
    </AppShell>
  );
}

function Credentials() {
  const { width } = useWindowDimensions();
  const compact = width < 1100;
  const session = useSession();

  return (
    <>
      <PageIntro
        eyebrow="CH1-UX-SCR-0002 / FortressGate"
        title="Your authenticators"
        description="What proves you are you, and how strongly. A security key or passkey is bound to this site and cannot be replayed anywhere else; a one-time password is a shared secret and is never accepted where phishing resistance is required. Nothing on this page ever shows a private key."
        aside={<StatusPill label={session.claims?.preferred_username ?? 'SIGNED IN'} tone="info" />}
      />

      <View style={[styles.grid, compact && styles.stacked]}>
        <PasskeyPanel accessToken={session.accessToken} />
        <TotpPanel accessToken={session.accessToken} />
      </View>

      <Panel style={styles.registerPanel}>
        <SectionHeading eyebrow="CH1-IAM-FR-0006" title="Registering a card or token for someone else" />
        <NotConnectedNotice detail="POST /api/v1/credentials registers a smart card or security token against another identity and is a Cybersecurity Administrator action requiring step-up. It is served, but this screen does not offer it: enrolment is a controlled ceremony that verifies the person first, and a self-service form would skip exactly the step that makes the credential attributable. It belongs on the security administration screen (CH1-UX-SCR-0013), which does not exist yet." />
      </Panel>
    </>
  );
}

/**
 * Enrols a passkey or security key.
 *
 * The key pair is generated inside the authenticator and never leaves it — the browser
 * hands over a public key and a handle, and that is all the platform stores.
 * CH1-CYB-IAM-0001 makes long-lived private keys non-exportable, so a private key
 * arriving here would mean that boundary had already failed; there is no field for one.
 */
function PasskeyPanel({ accessToken }: { accessToken: string | undefined }) {
  const stepUp = useStepUp(accessToken);
  const available = passkeysAvailable();

  return (
    <Panel style={styles.panel}>
      <SectionHeading
        eyebrow="Phishing resistant"
        title="Security key or passkey"
        action={<StatusPill label="STRONGEST" tone="good" />}
      />

      <Text style={styles.body}>
        A passkey signs over the address your browser actually reached, so an assertion captured by
        a look-alike site does not verify here. It is the only authenticator accepted for releasing
        a part, preparing a physical command or changing a role.
      </Text>

      {!available ? (
        <View style={styles.unavailable}>
          <Text style={styles.unavailableTitle}>NO AUTHENTICATOR IN THIS BROWSER</Text>
          <Text style={styles.unavailableText}>
            This browser exposes no WebAuthn authenticator, so a passkey cannot be used or enrolled
            from here. Open the portal in a browser with a platform authenticator or a security key
            available.
          </Text>
        </View>
      ) : null}

      {/*
        Enrolment itself is a Cybersecurity Administrator action: POST /api/v1/credentials
        binds a public key to a named identity after that person has been verified. Offering
        self-service enrolment here would let anyone who reached an authenticated session add
        an authenticator to their own account, which is the account-takeover path the
        controlled ceremony exists to close.
      */}
      <View style={styles.ceremony}>
        <Text style={styles.ceremonyTitle}>HOW YOU GET ONE</Text>
        <Text style={styles.ceremonyText}>
          A Cybersecurity Administrator verifies who you are and registers your key against your
          identity. Enrolment is not self-service, because a credential that anyone could add to
          their own account would prove nothing about who is holding it.
        </Text>
      </View>

      <View style={styles.tryBlock}>
        <Text style={styles.tryTitle}>CHECK YOUR KEY WORKS</Text>
        <Text style={styles.tryText}>
          This performs a real assertion and, if it verifies, holds a confirmation for one action
          which is then discarded. Nothing is changed.
        </Text>
        <StepUpPrompt
          action="Prove your security key"
          consequence="Control Core verifies the signature against the key registered to you. Nothing is created, changed or released."
          stepUp={stepUp}
          onGranted={(method: StepUpMethod) => {
            void stepUp.request(StepUpPurpose.CredentialAdministration, method);
          }}
          requirePhishingResistant
          disabled={!available}
        />
      </View>
    </Panel>
  );
}

/**
 * Enrols a one-time password.
 *
 * The seed is disclosed exactly once, in the response to the enrolment request, and no
 * read operation returns it afterwards. That is the control api_endpoints.json names,
 * so the screen states it before the operator starts rather than after they have lost it.
 */
function TotpPanel({ accessToken }: { accessToken: string | undefined }) {
  const [label, setLabel] = useState('Authenticator app');
  const stepUp = useStepUp(accessToken);
  const enrol = useControlledAction<TotpEnrolment>(accessToken);
  const [acknowledged, setAcknowledged] = useState(false);

  const begin = async (method: StepUpMethod) => {
    const grant = await stepUp.request(StepUpPurpose.CredentialAdministration, method);
    if (!grant) return;
    await enrol.submit('/api/v1/auth/totp/enrolments', { label }, { stepUpGrantId: grant.grantId });
    stepUp.clear();
  };

  return (
    <Panel style={styles.panel}>
      <SectionHeading
        eyebrow="Shared secret"
        title="One-time password"
        action={<StatusPill label="NOT PHISHING RESISTANT" tone="warning" />}
      />

      <Text style={styles.body}>
        A six-digit code from an authenticator application. Anyone who obtains the secret can
        produce codes, so it satisfies multi-factor step-up and is never accepted where a security
        key is required.
      </Text>

      {enrol.result === undefined ? (
        <>
          <TextField
            label="Name this authenticator"
            value={label}
            onChangeText={setLabel}
            hint="So you can tell it from another later."
            editable={!enrol.pending}
          />
          <View style={styles.warnBefore}>
            <Text style={styles.warnTitle}>▲ THE SECRET IS SHOWN ONCE</Text>
            <Text style={styles.warnText}>
              You will see it on the next screen and never again. Have your authenticator
              application open before you continue. If you lose it, the enrolment has to be revoked
              and replaced.
            </Text>
          </View>
          <StepUpPrompt
            action="Enrol a one-time password"
            consequence="A new shared secret is generated and shown to you once. Any existing one-time password enrolment must be revoked first."
            stepUp={stepUp}
            onGranted={(method) => void begin(method)}
            disabled={enrol.pending}
          />
        </>
      ) : (
        <SecretShownOnce enrolment={enrol.result} acknowledged={acknowledged} onAcknowledge={() => setAcknowledged(true)} />
      )}

      {enrol.error !== undefined ? (
        <CapabilityNotice error={enrol.error} context="POST /api/v1/auth/totp/enrolments" />
      ) : null}
    </Panel>
  );
}

/**
 * The one and only disclosure.
 *
 * The value is hidden again the moment the operator says they have stored it, and the
 * component keeps no copy afterwards. It is deliberately not selectable-by-default or
 * placed on the clipboard: CH1-UXD-DSG-0001 requires sensitive values to be masked and
 * clipboard use controlled.
 */
function SecretShownOnce({
  enrolment,
  acknowledged,
  onAcknowledge,
}: {
  enrolment: TotpEnrolment;
  acknowledged: boolean;
  onAcknowledge: () => void;
}) {
  if (acknowledged) {
    return (
      <View style={styles.storedBlock}>
        <Text style={styles.storedTitle}>ENROLLED</Text>
        <Text style={styles.storedText}>
          {enrolment.label} · {enrolment.digits} digits every {enrolment.periodSeconds} seconds ·{' '}
          {enrolment.algorithm}
        </Text>
        <Text style={styles.storedNote}>
          The secret is gone from this screen and cannot be shown again. {enrolment.assurance}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.secretBlock}>
      <Text style={styles.secretTitle}>▲ COPY THIS NOW — IT WILL NOT BE SHOWN AGAIN</Text>
      <Text style={styles.secretValue} selectable>
        {enrolment.sharedSecret}
      </Text>
      <Text style={styles.secretUri} selectable>
        {enrolment.otpauthUri}
      </Text>
      <Text style={styles.secretNote}>{enrolment.disclosure}</Text>
      <View style={styles.secretActions}>
        <ActionButton label="I HAVE STORED IT — HIDE" onPress={onAcknowledge} />
      </View>
    </View>
  );
}

/** Kept for the security administration screen, which will list credentials. */
export function credentialTone(credential: CredentialSummary): StatusTone {
  if (credential.status === 'Revoked') return 'danger';
  if (credential.status !== 'Active') return 'warning';
  return credential.phishingResistant ? 'good' : 'info';
}

/** Shown wherever a credential's provenance matters. */
export function describeCredential(credential: CredentialSummary): string {
  return `${credential.kind} · enrolled ${instant(credential.enrolledAt)} by ${credential.enrolledBy}`;
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  panel: { flex: 1, minWidth: 0, gap: Spacing.md },
  registerPanel: { marginTop: Spacing.md },
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  unavailable: { borderRadius: Radius.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', padding: Spacing.md, gap: 5 },
  unavailableTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  unavailableText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  ceremony: { borderLeftWidth: 3, borderLeftColor: Palette.cyan, paddingLeft: Spacing.md, gap: 5 },
  ceremonyTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  ceremonyText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  tryBlock: { gap: Spacing.sm },
  tryTitle: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  tryText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  warnBefore: { borderRadius: Radius.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', padding: Spacing.md, gap: 5 },
  warnTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  warnText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  secretBlock: { borderRadius: Radius.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#714046', padding: Spacing.lg, gap: 8 },
  secretTitle: { color: Palette.red, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  secretValue: { color: Palette.ink, fontFamily: Type.mono, fontSize: 16, fontWeight: '800', letterSpacing: 1.5 },
  secretUri: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  secretNote: { color: '#D9A6A8', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  secretActions: { flexDirection: 'row', justifyContent: 'flex-end' },
  storedBlock: { borderRadius: Radius.md, backgroundColor: Palette.greenSoft, borderWidth: 1, borderColor: '#2A6349', padding: Spacing.md, gap: 5 },
  storedTitle: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  storedText: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10 },
  storedNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});
