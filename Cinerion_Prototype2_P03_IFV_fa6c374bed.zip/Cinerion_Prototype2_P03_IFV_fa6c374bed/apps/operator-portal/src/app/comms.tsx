// @screen CH1-UX-SCR-0022 — Control-board communication health: controller topology,
//                protocol state, latency, quality and diagnostics

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { CellState } from '@/api/contracts';
import { instant, since } from '@/api/format';
import { isCurrentObservation } from '@/api/freshness';
import { useObserved, useWallClock } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import {
  KeyValue,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
} from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing } from '@/constants/theme';

/**
 * The deferred checks a controller can declare, named rather than shown as bare numbers.
 *
 * These arrive from CH1-COM-IF-0003 as codes because that is what the controlled OPC UA
 * and Modbus profiles publish, and an operator cannot act on "207". The two this platform
 * actually sees are declared by both stand-in profiles: the real S7-1200 G2 reads
 * UDT_CH1_Permissives from wired inputs and a stand-in has none, so it says so rather than
 * reporting interlocks it never read.
 */
const DEFERRED_CHECKS: Readonly<Record<number, string>> = {
  206: 'Preliminary interlock snapshot unavailable',
  207: 'Preliminary permissive invalid — no wired inputs to read',
};

function describeDeferred(code: number): string {
  return DEFERRED_CHECKS[code] ?? `Controller-declared deferred check ${code}`;
}

/**
 * The three states a cell's permissives can be in, which is the whole point of this screen.
 *
 * CH1-MON-FR-0003 requires an operational view to keep them apart. Without
 * `permissivesReported` the second and third are indistinguishable — both render as
 * interlocks that are false — and they mean completely different things: one is a machine
 * that has told us it is not ready, the other is a machine nobody has asked.
 */
type PermissiveStanding = 'Answered and healthy' | 'Answered — not permissive' | 'Never answered';

function standingOf(cell: CellState | undefined): PermissiveStanding | undefined {
  if (!cell) {
    return undefined;
  }

  if (!cell.permissivesReported) {
    return 'Never answered';
  }

  const healthy =
    cell.interlocks.controllerOnline &&
    cell.interlocks.startEnable &&
    cell.interlocks.stopCircuitHealthy &&
    cell.interlocks.guardHealthy &&
    cell.interlocks.actuatorHome &&
    !cell.interlocks.faultCauseActive;

  return healthy ? 'Answered and healthy' : 'Answered — not permissive';
}

function standingTone(standing: PermissiveStanding | undefined): StatusTone {
  switch (standing) {
    case 'Answered and healthy':
      return 'good';
    case 'Answered — not permissive':
      return 'warning';
    case 'Never answered':
      return 'neutral';
    default:
      return 'neutral';
  }
}

export default function CommunicationHealthScreen() {
  const session = useSession();
  const { width } = useWindowDimensions();
  const compact = width < 980;
  const now = useWallClock();

  const cellId = assignedCells(session.claims)[0];
  const cell = useObserved<CellState>(
    cellId ? `/api/v1/cells/${cellId}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  const standing = standingOf(cell.value);
  const current = isCurrentObservation(cell.freshness);
  const deferred = cell.value?.deferredCheckCodes ?? [];

  return (
    <AppShell active="comms">
      <PageIntro
        eyebrow="CH1-UX-SCR-0022 / EDGELINK"
        title="Control-board communication health"
        description={
          'The link to the controller, and what it is able to tell us. A controller that ' +
          'has not answered its permissives is shown as not having answered, never as a ' +
          'controller reporting that nothing is permitted — those are different faults and ' +
          'only one of them is the machine.'
        }
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />

      <SessionGate>
        {!cellId ? (
          <Panel>
            <SectionHeading eyebrow="SCOPE" title="No assigned cell" />
            <Text style={styles.body}>
              This identity is not assigned to a cell, so there is no controller link to
              report on. Assignment is a property of the identity rather than of this page.
            </Text>
          </Panel>
        ) : (
          <>
            <View style={[styles.row, compact && styles.rowCompact]}>
              <KpiCard
                label="Permissives"
                value={standing ?? '—'}
                note={
                  standing === 'Never answered'
                    ? 'The controller declared it cannot read them'
                    : standing === 'Answered — not permissive'
                      ? 'The controller answered, and the answer is no'
                      : standing === 'Answered and healthy'
                        ? 'Read from the controller, not from the database'
                        : 'Awaiting a qualified reading'
                }
                tone={standingTone(standing)}
              />
              <KpiCard
                label="Link"
                value={current ? 'Current' : 'Stale'}
                note={
                  current
                    ? 'Inside the validity window a report stands for'
                    : 'No report inside the window — the cell reads as not permissive'
                }
                tone={current ? 'good' : 'warning'}
              />
              <KpiCard
                label="Quality"
                value={cell.value?.quality ?? '—'}
                note="As the gateway reported it, never upgraded here"
              />
              <KpiCard
                label="Freshness"
                value={cell.value?.freshness ?? '—'}
                note="A simulated controller never reads as Live"
              />
            </View>

            <View style={[styles.row, compact && styles.rowCompact]}>
              <Panel style={styles.grow}>
                <SectionHeading eyebrow="TOPOLOGY" title="What is on the other end" />
                <KeyValue label="Controller" value={cell.value?.controllerId ?? '—'} />
                <KeyValue label="Operating state" value={cell.value?.state ?? '—'} />
                <KeyValue
                  label="Configuration revision"
                  value={cell.value?.configurationRevision ?? '—'}
                />
                <KeyValue
                  label="Source time"
                  value={cell.value ? instant(cell.value.sourceTimestamp) : '—'}
                />
                <KeyValue
                  label="Last heard from"
                  value={cell.value ? since(cell.value.sourceTimestamp, now) : '—'}
                />
                <KeyValue label="State hash" value={cell.value?.stateHash?.slice(0, 16) ?? '—'} />
              </Panel>

              <Panel style={styles.grow}>
                <SectionHeading
                  eyebrow="CH1-MON-FR-0003"
                  title="Checks the controller could not perform"
                />
                {!cell.value ? (
                  <Text style={styles.body}>Awaiting a qualified reading.</Text>
                ) : deferred.length === 0 ? (
                  <Text style={styles.body}>
                    {cell.value.permissivesReported
                      ? 'None. The controller answered every check it was asked for.'
                      : 'The controller has not answered its permissives and declared no reason.'}
                  </Text>
                ) : (
                  <View style={styles.deferredList}>
                    {deferred.map((code) => (
                      <View key={code} style={styles.deferredRow}>
                        <StatusPill label={String(code)} tone="neutral" />
                        <Text style={styles.deferredText}>{describeDeferred(code)}</Text>
                      </View>
                    ))}
                  </View>
                )}

                <View style={styles.boundary}>
                  <Text style={styles.boundaryEyebrow}>WHY THIS IS NOT AN ALARM</Text>
                  <Text style={styles.boundaryText}>
                    A deferred check is the controller being honest about what it cannot
                    read, not a fault. The cell correctly resolves as not permissive while
                    any permissive is unanswered, so nothing can be commanded on the
                    strength of a reading nobody took.
                  </Text>
                </View>
              </Panel>
            </View>

            <Panel>
              <SectionHeading eyebrow="BOUNDARY" title="What this screen can and cannot show" />
              <Text style={styles.body}>
                Controller state reaches this platform over CH1-COM-IF-0003 and is held in
                memory for ten seconds, never written to the database — restoring an
                interlock from storage would present a stale permissive as a current one,
                which CH1-SAF-FR-0003 forbids. So a link that has gone quiet shows as stale
                within one window rather than continuing to show its last good answer.
              </Text>
              <Text style={styles.body}>
                Per-protocol latency and packet diagnostics are not shown, and the reason is
                that no controlled operation exposes them: the P03 catalogue answers cell
                state, not gateway transport counters. The link facts above are what the
                catalogue actually serves, and an invented latency figure would be worse
                than an absent one.
              </Text>
            </Panel>
          </>
        )}
      </SessionGate>
    </AppShell>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: Spacing.md, flexWrap: 'wrap' },
  rowCompact: { flexDirection: 'column' },
  grow: { flexGrow: 1, flexBasis: 320 },
  body: { color: Palette.inkMuted, lineHeight: 22, marginTop: Spacing.xs },
  deferredList: { gap: Spacing.sm, marginTop: Spacing.sm },
  deferredRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  deferredText: { color: Palette.ink, flexShrink: 1 },
  boundary: {
    marginTop: Spacing.md,
    padding: Spacing.md,
    borderRadius: Radius.md,
    borderLeftWidth: 3,
    borderLeftColor: Palette.teal,
    backgroundColor: Palette.panelRaised,
  },
  boundaryEyebrow: {
    color: Palette.teal,
    
    letterSpacing: 1.2,
    marginBottom: Spacing.xs,
  },
  boundaryText: { color: Palette.inkMuted, lineHeight: 22 },
});
