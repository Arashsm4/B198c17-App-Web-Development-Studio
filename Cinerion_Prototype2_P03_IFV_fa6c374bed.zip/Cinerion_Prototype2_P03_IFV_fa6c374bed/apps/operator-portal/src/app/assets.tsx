// @screen CH1-UX-SCR-0004 — Site and cell hierarchy: assets, devices and readiness

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { CellState } from '@/api/contracts';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { KeyValue, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

export default function AssetsScreen() {
  return (
    <AppShell active="assets">
      <SessionGate>
        <Assets />
      </SessionGate>
    </AppShell>
  );
}

function Assets() {
  const { width } = useWindowDimensions();
  const compact = width < 1120;
  const session = useSession();
  const primaryCell = assignedCells(session.claims)[0];
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  return (
    <>
      <PageIntro
        eyebrow="AssetVault / ProtocolFabric"
        title="Assets, devices, and communication"
        description="Every connected controller, I/O node, PLC and instrument exposes a versioned capability manifest. Protocol adapters translate semantic intent; no device is trusted from its IP address, MAC address or physical connection alone."
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />
      <View style={[styles.grid, compact && styles.stacked]}>
        <Topology />
        <ProtocolBoundary />
      </View>
      <DeviceInventory cell={cell.value} accessToken={session.accessToken} />
    </>
  );
}

function Topology() {
  return (
    <Panel style={styles.topologyPanel}>
      <SectionHeading eyebrow="CH1-COM-IF-0001…0025" title="Controlled topology" action={<StatusPill label="NO GENERAL ROUTING" tone="info" />} />
      <View style={styles.zoneStack}>
        <Zone code="UZ" title="User / application zone" detail="Expo universal client · OIDC session · no controller credential" tone={Palette.cyan} />
        <Conduit label="HTTPS / OIDC · object policy" />
        <Zone code="SD" title="Service / data zone" detail="Control Core · PostgreSQL · identity · audit · evidence" tone={Palette.teal} />
        <Conduit label="mTLS gRPC / versioned CH1 envelope" />
        <Zone code="GW" title="Gateway zone" detail="EdgeLink · protocol termination · duplicate suppression" tone={Palette.violet} />
        <Conduit label="MQTT 5 / OPC UA / allowlisted Modbus" />
        <Zone code="CD" title="Control / device zone" detail="ESP32-S3 · Arduino I/O · S7-1200 G2 / PLCSIM" tone={Palette.amber} />
      </View>
      <View style={styles.topologyFootnote}>
        <Text style={styles.topologyFootnoteCode}>DENY BY DEFAULT</Text>
        <Text style={styles.topologyFootnoteText}>Research identities, document-publication paths, and administration have distinct zones and cannot use the production command conduit.</Text>
      </View>
    </Panel>
  );
}

function Zone({ code, title, detail, tone }: { code: string; title: string; detail: string; tone: string }) {
  return (
    <View style={[styles.zone, { borderLeftColor: tone }]}>
      <View style={[styles.zoneCode, { backgroundColor: `${tone}20` }]}><Text style={[styles.zoneCodeText, { color: tone }]}>{code}</Text></View>
      <View style={styles.zoneCopy}><Text style={styles.zoneTitle}>{title}</Text><Text style={styles.zoneDetail}>{detail}</Text></View>
      <StatusPill label="CONTROLLED" tone="neutral" />
    </View>
  );
}

function Conduit({ label }: { label: string }) {
  return (
    <View style={styles.conduit}>
      <View style={styles.conduitLine} />
      <Text style={styles.conduitLabel}>{label}</Text>
      <View style={styles.conduitLine} />
    </View>
  );
}

function ProtocolBoundary() {
  const adapters = [
    ['SIM', 'Simulator', 'ENABLED', 'Executable conformance profile', 'good'],
    ['MQ', 'MQTT 5', 'GATED', 'mTLS certificate and topic ACL pending', 'warning'],
    ['OU', 'OPC UA', 'GATED', 'Trust list, SignAndEncrypt, PLC licence pending', 'warning'],
    ['MB', 'Modbus', 'GATED', 'Allowlisted semantic map and HIL pending', 'warning'],
    ['FT', 'Future transport', 'BOUNDARY', 'Stable provider interface; unchanged messages', 'info'],
  ] as const;
  return (
    <Panel style={styles.protocolPanel}>
      <SectionHeading eyebrow="Replaceable adapters" title="Protocol enablement" />
      <View style={styles.adapterList}>
        {adapters.map(([code, name, state, detail, tone]) => (
          <View key={code} style={styles.adapterRow}>
            <View style={styles.adapterCode}><Text style={styles.adapterCodeText}>{code}</Text></View>
            <View style={styles.adapterCopy}>
              <Text style={styles.adapterName}>{name}</Text>
              <Text style={styles.adapterDetail}>{detail}</Text>
            </View>
            <StatusPill label={state} tone={tone} />
          </View>
        ))}
      </View>
      <View style={styles.ruleBox}>
        <Text style={styles.ruleBoxCode}>COMMAND RELIABILITY RULE</Text>
        <Text style={styles.ruleBoxText}>Telemetry may use bounded store-and-forward. Commands never queue across expiry, reconnect, controller restart, revision change, or material state change.</Text>
      </View>
    </Panel>
  );
}

/**
 * The device register is a controlled capability that is not enabled in this
 * checkpoint. Rather than describing that in prose, the panel actually calls the
 * endpoint and reports the server's answer, so the day AssetVault is implemented
 * this panel starts working without being edited.
 *
 * The controller identity itself is real: it comes from the cell state the
 * controller published, not from a device register.
 */
function DeviceInventory({ cell, accessToken }: { cell: CellState | undefined; accessToken: string | undefined }) {
  const device = useObserved<unknown>(
    cell ? `/api/v1/devices/${cell.controllerId}` : undefined,
    accessToken,
  );

  return (
    <Panel>
      <SectionHeading
        eyebrow="Common capability model v1.0.0"
        title="Enrolled device inventory"
        action={<StatusPill label={device.error ? 'REGISTER UNAVAILABLE' : 'QUERYING'} tone="neutral" />}
      />

      {cell ? (
        <View style={styles.controllerBlock}>
          <Text style={styles.controllerEyebrow}>CONTROLLER REPORTED BY THE CELL</Text>
          <View style={styles.controllerFacts}>
            <KeyValue label="Controller" value={cell.controllerId} mono />
            <KeyValue label="Asset" value={cell.assetId} mono />
            <KeyValue label="Configuration revision" value={cell.configurationRevision} mono />
            <KeyValue label="Link state" value={cell.interlocks.controllerOnline ? 'Online' : 'Not online'} />
          </View>
        </View>
      ) : (
        <Text style={styles.emptyText}>No cell state retrieved, so no controller identity can be shown.</Text>
      )}

      {device.error ? (
        <CapabilityNotice
          error={new Error(device.error)}
          context={cell ? `GET /api/v1/devices/${cell.controllerId}` : 'GET /api/v1/devices/{deviceId}'}
        />
      ) : null}

      <View style={styles.manifestStrip}>
        <Text style={styles.manifestLabel}>MANIFEST FIELDS</Text>
        <Text style={styles.manifestText}>
          stable ID · device type · firmware · configuration revision · commands · telemetry channels ·
          endpoints · security profile
        </Text>
      </View>
    </Panel>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md, alignItems: 'stretch' },
  stacked: { flexDirection: 'column' },
  topologyPanel: { flex: 1.1, minWidth: 0 },
  protocolPanel: { flex: 0.9, minWidth: 330 },
  zoneStack: { gap: 6 },
  zone: { minHeight: 62, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, borderWidth: 1, borderColor: Palette.line, borderLeftWidth: 3, padding: Spacing.md, flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  zoneCode: { width: 32, height: 32, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  zoneCodeText: { fontFamily: Type.mono, fontSize: 9, fontWeight: '900' },
  zoneCopy: { flex: 1, gap: 3 },
  zoneTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  zoneDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 13 },
  conduit: { height: 24, flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.xl, gap: Spacing.sm },
  conduitLine: { flex: 1, height: 1, backgroundColor: Palette.lineStrong },
  conduitLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7 },
  topologyFootnote: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.red, paddingLeft: Spacing.md, gap: 5 },
  topologyFootnoteCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  topologyFootnoteText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  adapterList: { gap: 1 },
  adapterRow: { minHeight: 61, flexDirection: 'row', alignItems: 'center', gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Palette.line },
  adapterCode: { width: 32, height: 32, borderRadius: 9, backgroundColor: Palette.panelRaised, borderWidth: 1, borderColor: Palette.lineStrong, alignItems: 'center', justifyContent: 'center' },
  adapterCodeText: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  adapterCopy: { flex: 1, gap: 3 },
  adapterName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  adapterDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8, lineHeight: 12 },
  ruleBox: { marginTop: Spacing.lg, borderRadius: Radius.md, padding: Spacing.lg, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', gap: 6 },
  ruleBoxCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  ruleBoxText: { color: '#CBB48B', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  controllerBlock: { gap: Spacing.md, paddingBottom: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Palette.line },
  controllerEyebrow: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.9 },
  controllerFacts: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl },
  emptyText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 16 },
  manifestStrip: { marginTop: Spacing.lg, flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, padding: Spacing.md },
  manifestLabel: { color: Palette.violet, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  manifestText: { flex: 1, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8, lineHeight: 13 },
});

