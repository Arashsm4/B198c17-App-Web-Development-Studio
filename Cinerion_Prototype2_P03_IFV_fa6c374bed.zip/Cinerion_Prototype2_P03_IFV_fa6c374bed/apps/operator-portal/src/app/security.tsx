// @screen CH1-UX-SCR-0013 — Security administration: users, devices, certificates and policy

import { useState } from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { CredentialSummary, DirectoryPage } from '@/api/contracts';
import { instant } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved } from '@/api/use-observed';
import { useSession } from '@/auth/session';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { ActAuthority } from '@/components/act-authority';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice, NotConnectedNotice } from '@/components/capability';
import { Panel, SectionHeading, StatusPill, TextField } from '@/components/primitives';
import { RoleAssignmentPanel } from '@/components/role-assignment';
import { RoleChips } from '@/components/role-chips';
import { SessionGate } from '@/components/session-gate';
import { StepUpPrompt } from '@/components/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/** GET /api/v1/users. Identifiers, scope and lifecycle only — never a credential field. */
export default function SecurityScreen() {
  return (
    <AppShell active="security">
      <SessionGate>
        <Security />
      </SessionGate>
    </AppShell>
  );
}

function Security() {
  const { width } = useWindowDimensions();
  const compact = width < 1180;
  const session = useSession();
  const directory = useObserved<DirectoryPage>('/api/v1/users', session.accessToken);

  return (
    <>
      <PageIntro
        eyebrow="CH1-UX-SCR-0013 / FortressGate"
        title="Security administration"
        description="Who holds an identity in this project, and what authenticates them. Registering a credential is a controlled ceremony: it binds a public key to a person the administrator has verified, and it is the step that makes every later assertion attributable to someone."
        aside={<RoleChips roles={session.claims?.roles} />}
      />

      <View style={[styles.grid, compact && styles.stacked]}>
        <DirectoryPanel page={directory.value} cause={directory.cause} />
        <ActAuthority act="registerCredential">
          <RegisterPanel accessToken={session.accessToken} />
        </ActAuthority>
      </View>

      {/*
        Role assignment lives on this screen because screens.json puts "users" first in
        what CH1-UX-SCR-0013 is for, and because it is the act every other authority in
        this portal depends on. It is wrapped in ActAuthority rather than gated inline:
        an identity that does not hold SystemAdministrator is told the act exists and who
        holds it, which is what an operator needs in order to ask the right person.
      */}
      <ActAuthority act="assignRoles">
        <RoleAssignmentPanel
          directory={directory.value}
          accessToken={session.accessToken}
          onChanged={directory.refresh}
        />
      </ActAuthority>

      <ActAuthority act="revokeCredential">
        <RevokePanel accessToken={session.accessToken} />
      </ActAuthority>
    </>
  );
}

/**
 * The identities this project holds, as FortressGate reports them.
 *
 * There is no ch1.users table and there should not be one: the identity provider owns
 * identity, and duplicating it here would create a second system of record that could
 * disagree with the first. With no provider configured the operation refuses rather than
 * returning an empty list, because an empty list reads as "this project has no people"
 * — a fake-success answer to a security question — and the panel says so plainly.
 */
function DirectoryPanel({ page, cause }: { page: DirectoryPage | undefined; cause: unknown }) {
  return (
    <Panel style={styles.directoryPanel}>
      <SectionHeading
        eyebrow="CH1-IAM-FR-0008"
        title="Identities in this project"
        action={<StatusPill label={page ? `${page.count} LISTED` : 'NOT RETRIEVED'} tone={page ? 'info' : 'neutral'} />}
      />

      {cause !== undefined ? (
        <>
          <CapabilityNotice error={cause} context="GET /api/v1/users" />
          <Text style={styles.failClosed}>
            This is the fail-closed direction. A directory the platform cannot see is reported as
            unavailable, never as empty.
          </Text>
        </>
      ) : null}

      {page?.items.map((user) => (
        <View key={user.userId} style={styles.userRow}>
          <View style={styles.userCopy}>
            <Text style={styles.userName}>{user.displayName ?? user.username}</Text>
            <Text style={styles.userMeta}>
              {user.username} · {user.actorKind} · {user.cellIds.length} cell
              {user.cellIds.length === 1 ? '' : 's'}
            </Text>
            <Text style={styles.userRoles}>{user.roles.join(', ') || 'No roles granted'}</Text>
          </View>
          <StatusPill label={user.enabled ? 'ENABLED' : 'DISABLED'} tone={user.enabled ? 'good' : 'warning'} />
        </View>
      ))}

      {page ? <Text style={styles.disclosure}>{page.disclosure}</Text> : null}
    </Panel>
  );
}

/**
 * Registers an authenticator against a person the administrator has verified.
 *
 * The smart-card path is complete: the card generates its key pair in its own secure
 * element and the administrator transcribes the public key, so nothing here ever holds
 * private material. CH1-CYB-IAM-0001 forbids a cloneable UID from standing as proof,
 * which is why a serial number alone is refused by the domain.
 */
function RegisterPanel({ accessToken }: { accessToken: string | undefined }) {
  const [subjectId, setSubjectId] = useState('');
  const [label, setLabel] = useState('');
  const [publicKey, setPublicKey] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const register = useControlledAction<CredentialSummary>(accessToken);

  const incomplete =
    subjectId.trim().length === 0 ||
    label.trim().length === 0 ||
    publicKey.trim().length === 0 ||
    serialNumber.trim().length === 0;

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (incomplete) return;

    const grant = await stepUp.request(StepUpPurpose.CredentialAdministration, method);
    if (!grant) return;

    const registered = await register.submit(
      '/api/v1/credentials',
      {
        subjectId: subjectId.trim(),
        kind: 'SmartCard',
        label: label.trim(),
        publicKey: publicKey.trim(),
        serialNumber: serialNumber.trim(),
        userVerification: 'Required',
      },
      { stepUpGrantId: grant.grantId },
    );
    if (registered) {
      setAttempted(false);
      setPublicKey('');
      setSerialNumber('');
      stepUp.clear();
    }
  };

  return (
    <Panel style={styles.registerPanel}>
      <SectionHeading eyebrow="CH1-IAM-FR-0005 / CH1-IAM-FR-0006" title="Register a physical credential" />

      <Text style={styles.body}>
        Verify the person first. This binds the public half of the key pair held in their card to
        their identity; the private half never leaves the card and there is no field here for one.
      </Text>

      <TextField
        label="Identity this credential belongs to"
        value={subjectId}
        onChangeText={setSubjectId}
        hint="The identifier the directory reports, not a display name."
        error={attempted && subjectId.trim().length === 0 ? 'Name the identity.' : undefined}
        editable={!register.pending}
      />
      <TextField
        label="Label"
        value={label}
        onChangeText={setLabel}
        hint="So the holder can tell this card from another."
        error={attempted && label.trim().length === 0 ? 'A label is required.' : undefined}
        editable={!register.pending}
      />
      <TextField
        label="Card serial number"
        value={serialNumber}
        onChangeText={setSerialNumber}
        hint="As printed on the card."
        error={attempted && serialNumber.trim().length === 0 ? 'A serial number is required.' : undefined}
        editable={!register.pending}
      />
      <TextField
        label="Public key (base64url SubjectPublicKeyInfo)"
        value={publicKey}
        onChangeText={setPublicKey}
        multiline
        hint="Read from the card. A serial number alone is never accepted as proof of a person."
        error={attempted && publicKey.trim().length === 0 ? 'The card must present a public key.' : undefined}
        editable={!register.pending}
      />

      <StepUpPrompt
        action={`Register a card for ${subjectId.trim() || 'an identity'}`}
        consequence="The card can then be used for local presence at a cell. It grants no role and starts no equipment."
        stepUp={stepUp}
        onGranted={(method) => void submit(method)}
        disabled={register.pending}
      />

      {register.error !== undefined ? (
        <CapabilityNotice error={register.error} context="POST /api/v1/credentials" />
      ) : null}

      {register.result !== undefined ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptTitle}>REGISTERED</Text>
          <Text style={styles.receiptLine}>
            {register.result.kind} · {register.result.label} · {register.result.credentialId}
          </Text>
          <Text style={styles.receiptNote}>
            Enrolled by {register.result.enrolledBy} at {instant(register.result.enrolledAt)}.
          </Text>
        </View>
      ) : null}

      {/*
        A passkey cannot be registered from here. POST /api/v1/credentials accepts the
        COSE key a registration ceremony produces, but the P03 catalogue has no operation
        that issues a *registration* challenge - passkey/options is an assertion challenge
        and is bound to an already-enrolled credential. A challenge the portal generated
        for itself would not be server-issued, so the attestation it binds would prove
        nothing this platform checked. Reported rather than papered over.
      */}
      <NotConnectedNotice detail="Registering a passkey is not offered here. The catalogue has no operation that issues a registration challenge - POST /api/v1/auth/passkey/options issues an assertion challenge for a credential that already exists - and a challenge the portal invented for itself would bind an attestation nobody verified. Enrol a passkey out of band and register its COSE key through the API until a registration-options operation exists." />
    </Panel>
  );
}

/**
 * Withdraws a credential.
 *
 * The record is kept. CH1-IAM-FR-0006 requires the lifecycle to remain auditable without
 * deleting history, and a forgotten credential could otherwise be presented elsewhere
 * unnoticed.
 */
function RevokePanel({ accessToken }: { accessToken: string | undefined }) {
  const [credentialId, setCredentialId] = useState('');
  const [reason, setReason] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const revoke = useControlledAction<CredentialSummary>(accessToken);

  const incomplete = credentialId.trim().length === 0 || reason.trim().length === 0;

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (incomplete) return;

    const grant = await stepUp.request(StepUpPurpose.CredentialAdministration, method);
    if (!grant) return;

    const revoked = await revoke.submit(
      `/api/v1/credentials/${credentialId.trim()}?reason=${encodeURIComponent(reason.trim())}`,
      undefined,
      { method: 'DELETE', stepUpGrantId: grant.grantId },
    );
    if (revoked) {
      setAttempted(false);
      stepUp.clear();
    }
  };

  return (
    <Panel style={styles.revokePanel}>
      <SectionHeading eyebrow="CH1-IAM-FR-0006" title="Withdraw a credential" />

      <Text style={styles.body}>
        Revoking is immediate and is never undone: a lost token is revoked first and replaced
        afterwards, because reinstating one is a new decision rather than a repeat of the old one.
        The record and its public key are kept.
      </Text>

      <TextField
        label="Credential identifier"
        value={credentialId}
        onChangeText={setCredentialId}
        error={attempted && credentialId.trim().length === 0 ? 'Name the credential.' : undefined}
        editable={!revoke.pending}
      />
      <TextField
        label="Why is it being withdrawn"
        value={reason}
        onChangeText={setReason}
        multiline
        hint="Retained with your identity and the time, so the decision stays attributable."
        error={attempted && reason.trim().length === 0 ? 'A reason is required.' : undefined}
        editable={!revoke.pending}
      />

      <StepUpPrompt
        action="Withdraw this credential"
        consequence="The credential stops being accepted immediately. Its record, public key and history are retained."
        stepUp={stepUp}
        onGranted={(method) => void submit(method)}
        disabled={revoke.pending}
      />

      {revoke.error !== undefined ? (
        <CapabilityNotice error={revoke.error} context="DELETE /api/v1/credentials/{credentialId}" />
      ) : null}

      {revoke.result !== undefined ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptTitle}>WITHDRAWN</Text>
          <Text style={styles.receiptLine}>
            {revoke.result.kind} · {revoke.result.label} · by {revoke.result.revokedBy} at{' '}
            {instant(revoke.result.revokedAt)}
          </Text>
          <Text style={styles.receiptNote}>{revoke.result.revocationReason}</Text>
          {/*
            Rendered because it is the honest half. CH1-COM-IF-0004 puts the reader
            denylist in the cell controller, which is not enabled, so platform trust is
            withdrawn and the card is not yet stopped at every door.
          */}
          <Text style={styles.receiptScope}>
            Platform trust withdrawn: {String(revoke.result.platformTrustWithdrawn)} · reader
            denylist updated: {String(revoke.result.readerDenylistUpdated)}
          </Text>
        </View>
      ) : null}
    </Panel>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  directoryPanel: { flex: 0.9, minWidth: 320 },
  registerPanel: { flex: 1.1, minWidth: 0, gap: Spacing.md },
  revokePanel: { gap: Spacing.md },
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  failClosed: { marginTop: Spacing.sm, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  userRow: { minHeight: 58, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Palette.line },
  userCopy: { flex: 1, gap: 3 },
  userName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11, fontWeight: '800' },
  userMeta: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  userRoles: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9 },
  disclosure: { marginTop: Spacing.md, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  receipt: { borderRadius: Radius.md, backgroundColor: Palette.greenSoft, borderWidth: 1, borderColor: '#2A6349', padding: Spacing.md, gap: 4 },
  receiptTitle: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10 },
  receiptNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  receiptScope: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8 },
});
