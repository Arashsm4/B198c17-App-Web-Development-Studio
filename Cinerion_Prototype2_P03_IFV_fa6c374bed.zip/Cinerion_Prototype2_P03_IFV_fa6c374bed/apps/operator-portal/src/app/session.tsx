// @screen CH1-UX-SCR-0001 — FortressGate login and MFA: authentication, recovery and session state

import { useState } from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { router } from 'expo-router';

import { splitRoles } from '@/api/capabilities';
import { portalConfig } from '@/api/client';
import type { SessionRevocation, SystemHealth } from '@/api/contracts';
import { instant, since } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved, useWallClock } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import {
  ActionButton,
  Divider,
  KeyValue,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
} from '@/components/primitives';
import { SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0001 — FortressGate login and MFA: authentication, recovery and session state.
 *
 * The interesting thing about this screen is what it must not do. The portal never
 * handles a password, never decides what a token authorises, and never claims an
 * authenticator class the identity provider did not attest. So it states the session it
 * is holding, names where each fact came from, and offers the one controlled operation
 * the P03 catalogue gives it here: ending a session.
 *
 * That operation matters more than it reads. Clearing the token in this tab is not
 * signing out — the session at FortressGate is still live, and a fresh sign-in would
 * resume it without anybody re-authenticating. On a shared workstation those are very
 * different acts, so both are offered and the difference is written on the controls
 * themselves rather than left for an operator to discover.
 */
export default function SessionScreen() {
  return (
    <AppShell active="session">
      <SessionGate>
        <SessionDetail />
      </SessionGate>
    </AppShell>
  );
}

function SessionDetail() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();
  const now = useWallClock();
  const claims = session.claims;
  const health = useObserved<SystemHealth>('/api/v1/system/health', session.accessToken);

  // Count the roles that grant something here. Keycloak's own `default-roles-cinerion`
  // used to sneak into this number and make every operator look one role richer.
  const { controlled: roles, other: providerRoles } = splitRoles(claims?.roles);
  const cells = assignedCells(claims);
  const expiresAt = claims?.exp === undefined ? undefined : new Date(claims.exp * 1000).toISOString();
  const authenticatedAt =
    claims?.auth_time === undefined ? undefined : new Date(claims.auth_time * 1000).toISOString();
  const expired = claims?.exp !== undefined && now !== undefined && claims.exp * 1000 <= now;

  return (
    <>
      <PageIntro
        eyebrow="FortressGate / CH1-UX-SCR-0001"
        title="Session and authentication"
        description="What this browser is holding, what it proves, and what it does not. Every value below is read from the access token for display and scoping only — Control Core revalidates the signature and re-evaluates project, cell and role scope on every single request."
        aside={
          <StatusPill
            label={expired ? 'TOKEN EXPIRED' : session.status.toUpperCase()}
            tone={expired ? 'danger' : session.status === 'signed-in' ? 'good' : 'warning'}
          />
        }
      />

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Identity"
          value={claims?.preferred_username ?? '—'}
          note={claims?.sub ? `subject ${claims.sub}` : 'No subject claim in this token'}
          tone={claims?.preferred_username ? 'info' : 'warning'}
        />
        <KpiCard
          label="Roles carried"
          value={String(roles.length)}
          note={
            (roles.length > 0 ? roles.join(', ') : 'No controlled role in this token') +
            (providerRoles.length > 0 ? ` (plus ${providerRoles.join(', ')}, which grants nothing here)` : '')
          }
          tone={roles.length > 0 ? 'info' : 'warning'}
        />
        <KpiCard
          label="Cell scope"
          value={String(cells.length)}
          note={cells.length > 0 ? cells.join(', ') : 'No ch1_cell assignment'}
          tone={cells.length > 0 ? 'info' : 'warning'}
        />
        <KpiCard
          label="Token expires"
          value={expiresAt ? since(expiresAt, now) : '—'}
          note={expiresAt ? instant(expiresAt) : 'No expiry claim in this token'}
          tone={expired ? 'danger' : 'info'}
        />
      </View>

      <TokenLifetime />

      <View style={[styles.grid, narrow && styles.stacked]}>
        <Panel style={styles.wide}>
          <SectionHeading eyebrow="Access token" title="What this session claims" />
          <View style={styles.metaGrid}>
            <KeyValue label="Subject" value={claims?.sub ?? '—'} mono />
            <KeyValue label="Session (sid)" value={claims?.sid ?? '—'} mono />
            <KeyValue label="Project scope" value={String(claims?.ch1_project ?? '—')} mono />
            <KeyValue label="Authenticated at" value={authenticatedAt ? instant(authenticatedAt) : '—'} />
            <KeyValue label="Expires at" value={expiresAt ? instant(expiresAt) : '—'} />
            <KeyValue label="Issuer" value={portalConfig.oidcIssuer || 'Not configured'} mono />
          </View>

          <Divider />
          <Text style={styles.footnote}>
            These claims are decoded, never verified, here. The portal cannot and must not decide
            what a token authorises: a scope shown above is what the identity provider issued, and
            every request is still authorised on its merits by Control Core.
          </Text>
        </Panel>

        <AuthenticatorStrength health={health.value} />
      </View>

      <View style={[styles.grid, narrow && styles.stacked]}>
        <EndSession sessionId={claims?.sid} />
        <Recovery />
      </View>
    </>
  );
}

/**
 * How long this credential lasts, and what the portal does when it runs out.
 *
 * Worth a panel of its own because the previous behaviour was invisible and wrong. The
 * realm declares no `accessTokenLifespan`, so Keycloak's five-minute default applied;
 * the portal held no refresh token and had no reaction to a 401, so after five minutes
 * every screen read HTTP_401 while the header still said AUTHENTICATED. An operator had
 * no way to tell a broken service from an expired credential.
 *
 * Two facts are separated here that an interface is tempted to merge. The ACCESS TOKEN
 * is what this tab holds and its expiry is a fact it can read. The SESSION at
 * FortressGate is a different, longer-lived thing whose end only the provider can state
 * — so the panel reports the first as fact and the second as something it can only ask
 * about.
 */
function TokenLifetime() {
  const session = useSession();
  const now = useWallClock();
  const { expiresAt, refreshing, renewable } = session.lifetime;
  const remaining = expiresAt === undefined || now === undefined ? undefined : expiresAt - now;

  return (
    <Panel>
      <SectionHeading
        eyebrow="Credential lifetime"
        title="What happens when this token expires"
        action={
          <StatusPill
            label={refreshing ? 'RENEWING NOW' : renewable ? 'RENEWAL AVAILABLE' : 'NO RENEWAL HELD'}
            tone={refreshing ? 'info' : renewable ? 'good' : 'warning'}
          />
        }
      />

      <View style={styles.row}>
        <Text style={styles.rowLabel}>Time left on the access token</Text>
        <StatusPill
          label={
            remaining === undefined
              ? 'NOT STATED'
              : remaining <= 0
                ? 'EXPIRED'
                : `${Math.floor(remaining / 1000)} S`
          }
          tone={remaining === undefined ? 'neutral' : remaining <= 0 ? 'danger' : 'info'}
        />
      </View>
      <Text style={styles.rowDetail}>
        Read from the token&apos;s own <Text style={styles.mono}>exp</Text> claim. It is a fact about
        the credential this tab holds, not about the session at FortressGate, which outlives any one
        access token.
      </Text>

      <Divider />
      <View style={styles.row}>
        <Text style={styles.rowLabel}>Renewal, while the provider still accepts it</Text>
        <StatusPill label={renewable ? 'SILENT' : 'NOT POSSIBLE'} tone={renewable ? 'good' : 'warning'} />
      </View>
      <Text style={styles.rowDetail}>
        The token is renewed about forty-five seconds before it expires, so nothing in flight is
        refused and no screen shows an error nobody caused. A refusal from Control Core triggers one
        renewal as a backstop; only that attempt failing ends the session. The portal never sends the
        browser back to the provider by itself — that would discard whatever was typed into an open
        controlled form.
      </Text>

      <Divider />
      <View style={styles.row}>
        <Text style={styles.rowLabel}>Where the renewal credential is kept</Text>
        <StatusPill label="MEMORY ONLY" tone="info" />
      </View>
      <Text style={styles.rowDetail}>
        In memory, exactly as the access token is, and in no persistent store. Closing this tab still
        ends the session and a reload still requires signing in; a cross-site scripting defect still
        finds no durable credential to take.
      </Text>
    </Panel>
  );
}

/**
 * What can and cannot be said about how this person authenticated.
 */
function AuthenticatorStrength({ health }: { health: SystemHealth | undefined }) {
  return (
    <Panel style={styles.narrow}>
      <SectionHeading eyebrow="Authenticator strength" title="What the token can prove" />

      <View style={styles.row}>
        <Text style={styles.rowLabel}>Highest strength an OIDC session reaches</Text>
        <StatusPill label="MFA" tone="info" />
      </View>
      <Text style={styles.rowDetail}>
        CH1-CYB-IAM-0001 requires a step-up to be phishing resistant <Text style={styles.em}>and
        recent</Text>, and a token claim alone cannot establish recency. Control Core therefore caps
        the strength it derives from a token at Mfa, however this identity signed in.
      </Text>

      <Divider />
      <View style={styles.row}>
        <Text style={styles.rowLabel}>Which authenticators were actually used</Text>
        <StatusPill label="NOT REPORTED" tone="neutral" />
      </View>
      <Text style={styles.rowDetail}>
        The realm emits no <Text style={styles.mono}>amr</Text> or <Text style={styles.mono}>acr</Text>{' '}
        claim, so nothing here knows whether a second factor was presented. This screen says so
        rather than showing a padlock it cannot justify — and a hardcoded claim would be a stored
        permanent assertion of strength, which the repository policy gate refuses outright.
      </Text>

      <Divider />
      <View style={styles.row}>
        <Text style={styles.rowLabel}>Route to phishing-resistant strength</Text>
        <StatusPill label="PASSKEY ASSERTION" tone="good" />
      </View>
      <Text style={styles.rowDetail}>
        A verified passkey assertion, not a claim. It rests on a signature this platform checked
        against an enrolled key, needs no MFA session at all, and is what independent part release
        and command preparation actually require. Enrolment is on the authenticators screen.
      </Text>

      <View style={styles.actions}>
        <ActionButton
          label="YOUR AUTHENTICATORS"
          kind="secondary"
          onPress={() => router.push('/credentials')}
        />
      </View>

      {health?.developmentIdentityEnabled === true ? (
        <View style={styles.danger}>
          <Text style={styles.dangerCode}>DEVELOPMENT IDENTITY IS ENABLED</Text>
          <Text style={styles.dangerText}>
            This service is authorising requests from headers rather than a verified token. Nothing
            produced against it is controlled evidence, and the strengths described above are not
            being proven by anything.
          </Text>
        </View>
      ) : null}
    </Panel>
  );
}

/**
 * `DELETE /api/v1/auth/sessions/{sessionId}` — and the weaker local act beside it, so
 * the difference between the two is visible at the moment of choosing.
 */
function EndSession({ sessionId }: { sessionId: string | undefined }) {
  const session = useSession();
  const action = useControlledAction<SessionRevocation>(session.accessToken);
  const [confirming, setConfirming] = useState(false);

  const revoke = async () => {
    if (sessionId === undefined) return;
    const receipt = await action.submit(
      `/api/v1/auth/sessions/${encodeURIComponent(sessionId)}`,
      undefined,
      { method: 'DELETE' },
    );
    // The token in this tab is only dropped once the server has confirmed the session
    // is gone. Dropping it first would leave a live session nobody could see any more.
    if (receipt) session.signOut();
  };

  return (
    <Panel style={styles.wide}>
      <SectionHeading
        eyebrow="DELETE /api/v1/auth/sessions/{sessionId}"
        title="Ending this session"
        action={<StatusPill label="NO STEP-UP REQUIRED" tone="info" />}
      />
      <Text style={styles.body}>
        Ending the session at FortressGate is immediate and applies everywhere, not only in this
        browser. It deliberately requires no step-up: someone who believes their session is
        compromised must be able to end it at once, and a re-authentication they may be unable to
        complete would stand between them and doing so.
      </Text>

      {sessionId === undefined ? (
        <View style={styles.notice}>
          <Text style={styles.noticeCode}>NO SESSION IDENTIFIER IN THIS TOKEN</Text>
          <Text style={styles.noticeText}>
            The token carries no <Text style={styles.mono}>sid</Text> claim, so there is no session
            for the portal to name. Clearing the token here is still available below.
          </Text>
        </View>
      ) : null}

      {action.error !== undefined ? (
        <CapabilityNotice error={action.error} context="DELETE /api/v1/auth/sessions/{sessionId}" />
      ) : null}

      {action.result ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptCode}>SESSION ENDED AT THE IDENTITY PROVIDER</Text>
          <Text style={styles.receiptText}>
            {action.result.ownSession ? 'Your own session' : 'A session'}
            {action.result.subjectUsername ? ` (${action.result.subjectUsername})` : ''}, ended by{' '}
            {action.result.revokedBy} at {instant(action.result.revokedAt)}.
          </Text>
          <Text style={styles.receiptText}>{action.result.crossSiteRequestForgery}</Text>
        </View>
      ) : null}

      <View style={styles.actions}>
        {confirming ? (
          <>
            <ActionButton
              label={action.pending ? 'ENDING…' : 'CONFIRM — END EVERYWHERE'}
              kind="danger"
              onPress={revoke}
              disabled={action.pending || sessionId === undefined}
            />
            <ActionButton label="CANCEL" kind="secondary" onPress={() => setConfirming(false)} />
          </>
        ) : (
          <ActionButton
            label="END SESSION AT FORTRESSGATE"
            kind="danger"
            onPress={() => setConfirming(true)}
            disabled={sessionId === undefined}
          />
        )}
        <ActionButton label="CLEAR TOKEN IN THIS TAB ONLY" kind="secondary" onPress={session.signOut} />
      </View>

      <View style={styles.warn}>
        <Text style={styles.warnCode}>THE TWO CONTROLS ARE NOT THE SAME</Text>
        <Text style={styles.warnText}>
          Clearing the token discards what this tab is holding and nothing more. The session at
          FortressGate stays live, and signing in again resumes it without anybody re-authenticating
          — which on a shared workstation is the whole difference. Ending the session is the act
          that is recorded in the audit chain.
        </Text>
      </View>
    </Panel>
  );
}

/** Recovery belongs to FortressGate, and the portal must not appear to own it. */
function Recovery() {
  const session = useSession();
  return (
    <Panel style={styles.narrow}>
      <SectionHeading eyebrow="Recovery" title="Lost password or authenticator" />
      <Text style={styles.body}>
        The portal never handles a password. Recovery is performed at FortressGate&apos;s own sign-in
        page, which is where the credential is entered and where a reset is started; this
        application only ever receives a token that page produced.
      </Text>
      <Text style={styles.body}>
        A lost authenticator is a different act again. CH1-CYB-IAM-0001 makes the response revoke
        first and issue a replacement through a controlled ceremony — a Cybersecurity Administrator
        registers the replacement — so it is never a self-service reset, and this screen offers no
        control that would suggest otherwise.
      </Text>

      <View style={styles.actions}>
        <ActionButton label="OPEN FORTRESSGATE SIGN-IN" kind="secondary" onPress={session.signIn} />
      </View>

      <Text style={styles.footnote}>
        Identity provider: {portalConfig.oidcIssuer || 'not configured for this deployment'}
      </Text>
    </Panel>
  );
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, marginBottom: Spacing.md },
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  wide: { flex: 1.3, minWidth: 0 },
  narrow: { flex: 1, minWidth: 320 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl, paddingVertical: Spacing.md },
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17, paddingTop: Spacing.sm },
  footnote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15, marginTop: Spacing.md },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: Spacing.md, paddingTop: Spacing.md },
  rowLabel: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, fontWeight: '700', flexShrink: 1 },
  rowDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15, paddingTop: 4, paddingBottom: Spacing.sm },
  em: { color: Palette.inkSoft, fontWeight: '800' },
  mono: { fontFamily: Type.mono, color: Palette.cyan },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, paddingTop: Spacing.md },
  notice: { marginTop: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  noticeCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  noticeText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  warn: { marginTop: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  warnCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  warnText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  danger: { marginTop: Spacing.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#714046', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  dangerCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  dangerText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  receipt: { marginTop: Spacing.md, backgroundColor: Palette.greenSoft, borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: '#2C5A44', gap: 5 },
  receiptCode: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
});
