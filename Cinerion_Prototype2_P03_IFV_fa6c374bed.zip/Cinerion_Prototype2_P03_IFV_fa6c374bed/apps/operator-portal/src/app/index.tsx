// @screen CH1-UX-SCR-0016 — Cross-layer operations overview: correlated state with freshness

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { CellState, ProjectSummary } from '@/api/contracts';
import { isActionable } from '@/api/freshness';
import {
  PERMISSIVES_NOT_ANSWERED_EXPLANATION,
  deferredCheckSummary,
  interlockEntries,
  permissiveSummary,
  permissivesAnswered,
} from '@/api/permissives';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { ConnectedObjects } from '@/components/object-link';
import { KpiCard, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

export default function OperationsScreen() {
  return (
    <AppShell active="operations">
      <SessionGate>
        <Operations />
      </SessionGate>
    </AppShell>
  );
}

function Operations() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();

  // Cell assignments come from the identity, not from a discovery endpoint.
  // Control Core still re-evaluates the scope on every request.
  const cells = assignedCells(session.claims);
  const primaryCell = cells[0];

  const projects = useObserved<readonly ProjectSummary[]>('/api/v1/projects', session.accessToken);
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  return (
    <>
      <PageIntro
        eyebrow="OperationsView / cross-layer correlation"
        title="Operations overview"
        description="A qualified picture of the cells this identity is assigned to. Every value carries source time, freshness and quality; a reading that stops arriving is shown as stale or disconnected, never as current."
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />

      {cells.length === 0 ? <NoCellScope /> : null}
      {cell.error ? <ReadFailure detail={cell.error} /> : null}

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Assigned cells"
          value={String(cells.length)}
          note={cells.length === 0 ? 'No cell assignment in this identity' : 'From the authenticated identity scope'}
          tone={cells.length === 0 ? 'warning' : 'info'}
        />
        <KpiCard
          label="Permissives valid"
          value={permissiveSummary(cell.value)}
          note={
            cell.value && isActionable(cell.freshness, cell.quality)
              ? 'Readiness inputs, not a safety function'
              : 'Not current — do not act on this figure'
          }
          tone={permissiveTone(cell)}
        />
        <KpiCard
          label="Cell state"
          value={cell.value?.state?.toUpperCase() ?? '—'}
          note={cell.value ? `Configuration ${cell.value.configurationRevision}` : 'Awaiting a qualified reading'}
          tone={cell.value ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Project"
          value={projects.value?.[0]?.projectCode ?? '—'}
          note={
            projects.value?.[0]
              ? `${projects.value[0].name} · baseline ${projects.value[0].baseline}`
              : 'No project established for this scope'
          }
          tone={projects.error ? 'danger' : projects.value?.[0] ? 'info' : 'warning'}
        />
      </View>

      <View style={[styles.primaryGrid, narrow && styles.stacked]}>
        <CellReadiness cell={cell.value} freshness={cell.freshness} quality={cell.quality} />
        <CommandWatch />
      </View>
    </>
  );
}



function permissiveTone(cell: { value: CellState | undefined; freshness: string; quality: string }) {
  if (!cell.value) return 'neutral' as const;
  // Never good on the strength of the interlocks alone. A cell whose controller has not
  // answered is not a healthy cell with a caveat; it is a cell nothing is known about.
  if (!permissivesAnswered(cell.value)) return 'warning' as const;
  if (!isActionable(cell.freshness as never, cell.quality as never)) return 'warning' as const;
  const entries = interlockEntries(cell.value);
  return entries.every((item) => item.valid) ? ('good' as const) : ('warning' as const);
}



function CellReadiness({
  cell,
  freshness,
  quality,
}: {
  cell: CellState | undefined;
  freshness: CellState['freshness'];
  quality: CellState['quality'];
}) {
  const current = cell ? isActionable(freshness, quality) : false;
  return (
    <Panel style={styles.cellPanel}>
      <SectionHeading
        eyebrow={cell?.cellId ?? 'No assigned cell'}
        title="Local readiness envelope"
        action={<StatusPill label={cell?.state?.toUpperCase() ?? 'UNKNOWN'} tone={current ? 'good' : 'neutral'} />}
      />
      <View style={styles.cellMeta}>
        <Meta label="Configuration" value={cell?.configurationRevision ?? '—'} mono />
        <Meta label="Controller" value={cell?.controllerId ?? '—'} mono />
        <Meta label="Source time" value={cell?.sourceTimestamp ?? '—'} mono />
      </View>
      <View style={styles.freshnessRow}>
        <FreshnessTag
          freshness={freshness}
          quality={quality}
          detail={cell ? `state hash ${cell.stateHash.slice(0, 8)}…` : undefined}
        />
      </View>

      {/*
        CH1-UX-SCR-0016 is the declared CROSS-LAYER screen, and until now it correlated
        the layers by printing their identifiers next to each other. Every one of these
        was already on the page as inert text; what changes is that a reader can now
        follow the cell to the controller that runs it, to the order it is working, to
        the part it is making, and to the thread where the departments talk about it.
      */}
      <ConnectedObjects
        items={[
          { kind: 'device', id: cell?.controllerId, caption: 'controller' },
          { kind: 'workOrder', id: cell?.workOrderId, caption: 'work order' },
          { kind: 'part', id: cell?.partId, caption: 'part' },
          {
            kind: 'thread',
            id: cell?.contextThreadId,
            caption: 'discussion',
            extra: { objectType: 'Cell', objectId: cell?.cellId, objectLabel: cell?.cellId },
          },
        ]}
      />

      {cell && !permissivesAnswered(cell) ? (
        <View style={styles.unansweredNotice}>
          <Text style={styles.unansweredCode}>PERMISSIVES NOT ANSWERED</Text>
          <Text style={styles.unansweredText}>{PERMISSIVES_NOT_ANSWERED_EXPLANATION}</Text>
          {deferredCheckSummary(cell) ? (
            <Text style={styles.unansweredCodes}>{deferredCheckSummary(cell)}</Text>
          ) : null}
        </View>
      ) : null}

      {cell ? (
        <View style={styles.interlockGrid}>
          {interlockEntries(cell).map((item) => (
            <View key={item.label} style={[styles.interlock, !item.valid && styles.interlockInvalid]}>
              <View style={[styles.checkMark, !item.valid && styles.checkMarkInvalid]}>
                <Text style={[styles.checkText, !item.valid && styles.checkTextInvalid]}>
                  {item.valid ? '✓' : '✕'}
                </Text>
              </View>
              <View style={styles.interlockCopy}>
                <Text style={styles.interlockLabel}>{item.label}</Text>
                <Text style={[styles.interlockValue, !item.valid && styles.interlockValueInvalid]}>{item.value}</Text>
              </View>
            </View>
          ))}
        </View>
      ) : (
        <Text style={styles.empty}>No qualified reading for this cell.</Text>
      )}

      {cell && !current ? (
        <View style={styles.staleNotice}>
          <Text style={styles.staleNoticeCode}>READING NOT CURRENT</Text>
          <Text style={styles.staleNoticeText}>
            The permissives above are the last values received, not the present state of the cell.
            Do not use them to judge readiness.
          </Text>
        </View>
      ) : null}

      <View style={styles.notice}>
        <Text style={styles.noticeCode}>SAFETY BOUNDARY</Text>
        <Text style={styles.noticeText}>
          These are readiness permissives for a controlled sequence. Machine safety remains local,
          independent and authoritative.
        </Text>
      </View>
    </Panel>
  );
}

/**
 * The guarded-command workflow is not yet wired to Control Core. It states that
 * plainly rather than showing a fabricated transaction in progress.
 */
function CommandWatch() {
  const stages = ['PREPARE', 'CREDENTIAL', 'BUTTON EDGE', 'LOCAL COMMIT', 'EXECUTION'];
  return (
    <Panel style={styles.commandPanel}>
      <SectionHeading
        eyebrow="CommandGuard / ConfirmGate"
        title="Guarded command watch"
        action={<StatusPill label="NOT CONNECTED" tone="neutral" />}
      />
      <Text style={styles.commandTarget}>
        This view is not yet reading prepared commands from Control Core. No transaction is shown
        because none has been retrieved.
      </Text>
      <View style={styles.stageList}>
        {stages.map((label, index) => (
          <View key={label} style={styles.stageRow}>
            <View style={styles.stageRail}>
              <View style={styles.stageDot} />
              {index < stages.length - 1 ? <View style={styles.stageLine} /> : null}
            </View>
            <View style={styles.stageCopy}>
              <Text style={styles.stageLabel}>{label}</Text>
              <Text style={styles.stageStatus}>No data</Text>
            </View>
          </View>
        ))}
      </View>
      <View style={styles.localOnly}>
        <Text style={styles.localOnlyTitle}>LOCAL ACTION REQUIRED</Text>
        <Text style={styles.localOnlyText}>
          Cryptographic credential proof and a new physical button edge are observed at the cell. No
          virtual confirmation exists here or anywhere in this application.
        </Text>
      </View>
    </Panel>
  );
}

function Meta({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <View>
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={mono ? styles.metaMono : styles.metaValue} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

function NoCellScope() {
  return (
    <View style={styles.banner}>
      <Text style={styles.bannerTitle}>NO CELL ASSIGNMENT</Text>
      <Text style={styles.bannerText}>
        This identity carries no ch1_cell scope, so no cell state can be requested. Cell assignment
        is granted by an administrator in the identity provider.
      </Text>
    </View>
  );
}

function ReadFailure({ detail }: { detail: string }) {
  return (
    <View style={[styles.banner, styles.bannerDanger]}>
      <Text style={[styles.bannerTitle, styles.bannerTitleDanger]}>READ REFUSED OR UNREACHABLE</Text>
      <Text style={styles.bannerText}>{detail}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, marginBottom: Spacing.md },
  primaryGrid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  cellPanel: { flex: 1.35, minWidth: 0 },
  commandPanel: { flex: 0.9, minWidth: 320 },
  cellMeta: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl, paddingBottom: Spacing.md },
  freshnessRow: { paddingBottom: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Palette.line },
  metaLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, fontWeight: '700', letterSpacing: 0.7, textTransform: 'uppercase', marginBottom: 4 },
  metaMono: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10 },
  metaValue: { color: Palette.cyan, fontFamily: Type.sans, fontSize: 11, fontWeight: '700' },
  interlockGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginTop: Spacing.lg },
  interlock: { width: '48%', minWidth: 190, flexGrow: 1, borderRadius: Radius.md, padding: Spacing.md, backgroundColor: '#0B2430', borderWidth: 1, borderColor: '#19404A', flexDirection: 'row', alignItems: 'center', gap: 10 },
  interlockInvalid: { backgroundColor: Palette.redSoft, borderColor: '#714046' },
  checkMark: { width: 24, height: 24, borderRadius: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.greenSoft },
  checkMarkInvalid: { backgroundColor: '#5A2A2E' },
  checkText: { color: Palette.green, fontSize: 12, fontWeight: '900' },
  checkTextInvalid: { color: Palette.red },
  interlockCopy: { flex: 1, gap: 2 },
  interlockLabel: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10 },
  interlockValue: { color: Palette.green, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  interlockValueInvalid: { color: Palette.red },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 11, marginTop: Spacing.lg },
  unansweredNotice: { marginTop: Spacing.md, borderRadius: Radius.md, padding: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', gap: 5 },
  unansweredCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  unansweredText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  unansweredCodes: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
  staleNotice: { marginTop: Spacing.lg, backgroundColor: Palette.amberSoft, borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: '#5F4521', gap: 5 },
  staleNoticeCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  staleNoticeText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  notice: { marginTop: Spacing.lg, backgroundColor: '#101F2E', borderRadius: Radius.md, padding: Spacing.md, borderLeftWidth: 3, borderLeftColor: Palette.cyan, gap: 5 },
  noticeCode: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  noticeText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  commandTarget: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  stageList: { marginTop: Spacing.xl },
  stageRow: { flexDirection: 'row', minHeight: 48 },
  stageRail: { width: 24, alignItems: 'center' },
  stageDot: { width: 12, height: 12, borderRadius: 6, borderWidth: 2, borderColor: Palette.inkMuted, backgroundColor: Palette.panel, zIndex: 2 },
  stageLine: { position: 'absolute', width: 1, backgroundColor: Palette.lineStrong, top: 12, bottom: -1 },
  stageCopy: { flex: 1, paddingLeft: Spacing.md, flexDirection: 'row', justifyContent: 'space-between' },
  stageLabel: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10, fontWeight: '700' },
  stageStatus: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  localOnly: { marginTop: Spacing.sm, padding: Spacing.lg, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, gap: 6 },
  localOnlyTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.7 },
  localOnlyText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  banner: { marginBottom: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  bannerDanger: { backgroundColor: Palette.redSoft, borderColor: '#714046' },
  bannerTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  bannerTitleDanger: { color: Palette.red },
  bannerText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
});
