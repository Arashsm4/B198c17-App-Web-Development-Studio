// @screen CH1-UX-SCR-0006 — Work-order board: revision-controlled release and progress

import { useState } from 'react';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type {
  CellState,
  WorkOrderBoardPage,
  ProductGroup,
  ProductRevisionSummary,
  RevisionLifecycleState,
  WorkOrderRecord,
} from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved } from '@/api/use-observed';
import { owns } from '@/api/capabilities';
import { assignedCells, useSession } from '@/auth/session';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { ActAuthority } from '@/components/act-authority';
import { ControlledActionForm, Shape } from '@/components/controlled-action-form';
import {
  ActionButton,
  Divider,
  KeyValue,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
  TextField,
} from '@/components/primitives';
import type { StatusTone } from '@/constants/status';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { StepUpPrompt } from '@/components/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0006 — work-order board: revision-controlled release and progress.
 *
 * The board reads three things. Products and their revisions come from
 * GET /api/v1/products; the order in progress comes from the cell state, which names the
 * work order loaded on the cell; and the board itself comes from GET /api/v1/work-orders.
 *
 * THAT LAST ONE IS AN OWNER-APPROVED READ, recorded in
 * traceability/owner-approved-operations.json. It is recorded conflict 14: the P03
 * catalogue can raise a work order and release one, and can read neither back, so until it
 * existed this screen could only show what this session happened to have written and had to
 * explain why the rest was invisible.
 *
 * RELEASE STATE IS REPORTED, NEVER CONFERRED. The read states so on its own response and
 * this screen renders that statement: releasing remains a controlled operation carrying a
 * phishing-resistant step-up grant, and nothing about being able to SEE an order changes
 * who may release one.
 */
export default function WorkOrderScreen() {
  return (
    <AppShell active="work-orders">
      <SessionGate>
        <WorkOrders />
      </SessionGate>
    </AppShell>
  );
}

function WorkOrders() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();
  const roles = session.claims?.roles ?? [];
  // Who owns this act is decided in one place now: the capability register, reconciled
  // against api_endpoints.json and the controlled-authority register by
  // `npm run capabilities`. This screen no longer spells the authority itself.
  // Raising and releasing are two acts with the same controlled authority, and both are
  // read from the register rather than inferred from one another.
  const canRaiseWorkOrder = owns('createWorkOrder', roles);
  const canReleaseWorkOrder = owns('releaseWorkOrder', roles);
  // Authoring a revision is the Engineer's act, not the Project Manager's. Two different
  // authorities on one screen, which is the ordinary case rather than an exception: a
  // revision-controlled board is where an engineer's definition meets a manager's order.
  const canCreateRevision = owns('createProductRevision', roles);

  const cells = assignedCells(session.claims);
  const primaryCell = cells[0];

  const products = useObserved<readonly ProductGroup[]>('/api/v1/products', session.accessToken);
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  // The board itself. An owner-approved read; the roles are the ones the service enforces.
  const canReadBoard =
    roles.includes('ProjectManager') ||
    roles.includes('Engineer') ||
    roles.includes('OperationsCoordinator') ||
    roles.includes('Inspector');
  const board = useObserved<WorkOrderBoardPage>(
    canReadBoard ? '/api/v1/work-orders' : undefined,
    session.accessToken,
  );

  // Orders this session raised or released, kept so a newly written order appears at once
  // rather than on the next poll. The board is the record; this is only a head start.
  const [raised, setRaised] = useState<readonly WorkOrderRecord[]>([]);
  const remember = (order: WorkOrderRecord) =>
    setRaised((current) => [order, ...current.filter((item) => item.workOrderId !== order.workOrderId)]);

  const groups = products.value ?? [];
  const revisions = groups.flatMap((group) => group.revisions);
  const released = revisions.filter((item) => item.lifecycleState === 'Released');

  return (
    <>
      <PageIntro
        eyebrow="ForgeFlow / CH1-UX-SCR-0006"
        title="Work-order board"
        description="Only a released revision can start a work order, and only a released work order can be executed. The revisions below are the controlled record; the order in progress is read from the cell itself."
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />

      {products.error !== undefined ? (
        <CapabilityNotice error={products.cause ?? products.error} context="GET /api/v1/products" />
      ) : null}

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Controlled revisions"
          value={products.loading ? '—' : String(revisions.length)}
          note={`${released.length} released and available to start an order`}
          tone={released.length === 0 ? 'warning' : 'info'}
        />
        <KpiCard
          label="Order on the cell"
          value={cell.value ? shortId(cell.value.workOrderId) : '—'}
          note={
            cell.value
              ? 'Read from the cell state, not from an order listing'
              : 'No cell assignment in this identity'
          }
          tone={cell.value ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Raised in this session"
          value={String(raised.length)}
          note="The catalogue has no work-order read operation; these are the responses this page received"
          tone="neutral"
        />
      </View>

      <Panel>
        <SectionHeading
          eyebrow="Board"
          title={
            canReadBoard
              ? `${board.value?.count ?? 0} work order${(board.value?.count ?? 0) === 1 ? '' : 's'} in this project`
              : 'The board is not shown to this identity'
          }
          action={<StatusPill label={canReadBoard ? 'BOARD' : 'WITHHELD'} tone={canReadBoard ? 'info' : 'neutral'} />}
        />

        {/*
          Authoring the next revision of a product. It answers with the revision it created,
          in Draft - releasing one is a separate controlled act, and a draft revision cannot
          have an order raised against it. The server refuses a revision code that already
          exists, so the operator learns that from the refusal rather than from this screen
          guessing.
        */}
        {canCreateRevision ? (
          <ControlledActionForm
            label="CREATE A PRODUCT REVISION"
            title="create the next controlled revision of a product"
            description="A revision is the controlled definition a work order is built to. This creates it in DRAFT: its bill of materials and route are authored separately, and no order can be raised against it until it is released."
            accessToken={session.accessToken}
            // The route's {productId} is the product CODE: ForgeFlowService takes a
            // productCode and a product exists here because a controlled revision of it
            // exists, which is what the schema records and what GET /products projects.
            endpoint={`/api/v1/products/${encodeURIComponent(products.value?.[0]?.productCode ?? '')}/revisions`}
            fields={[
              {
                name: 'revisionCode',
                label: 'Revision code',
                hint: 'The controlled identifier for this revision, such as R02. The server refuses one the product already has.',
              },
            ]}
            disabledReason={
              products.value?.[0]?.productCode === undefined
                ? 'No product has been retrieved, so there is nothing to revise. The panel above says why.'
                : undefined
            }
            onDone={products.refresh}
          />
        ) : (
          <ActAuthority act="createProductRevision">
            <></>
          </ActAuthority>
        )}

        {canReadBoard ? (
          <ControlledActionForm
            label="OPEN A WORK ORDER"
            title="open a work order against a released product revision"
            description="A work order names the controlled revision it is built to. Releasing it for execution is a separate act with its own step-up — opening one commits no capacity and starts nothing."
            accessToken={session.accessToken}
            endpoint="/api/v1/work-orders"
            fields={[
              { name: 'workOrderNumber', label: 'Work order number' },
              {
                name: 'revisionId',
                label: 'Product revision',
                initial: products.value?.[0]?.revisions[0]?.revisionId ?? '',
                hint: 'The controlled revision this order is built to. The server refuses one that is not released.',
              },
              {
                name: 'quantity',
                label: 'Quantity',
                initial: '1',
                validate: Shape.positiveInteger,
                transform: (value: string) => Number(value),
              },
              {
                name: 'cellId',
                label: 'Cell (optional)',
                optional: true,
                initial: cell.value?.cellId ?? '',
                hint: 'Leave blank to open the order without assigning it to a cell.',
              },
            ]}
            onDone={board.refresh}
          />
        ) : null}
        {!canReadBoard ? (
          <Text style={styles.boundaryText}>
            The work-order board is read by the Project Manager, the Engineer, the Operations Coordinator and
            the Inspector. This session holds none of them, so the board is WITHHELD rather than empty — an
            empty board would read as a project with no work in it.
          </Text>
        ) : board.error !== undefined ? (
          <CapabilityNotice error={board.cause ?? board.error} context="GET /api/v1/work-orders" />
        ) : (board.value?.items.length ?? 0) === 0 ? (
          <Text style={styles.boundaryText}>
            No work order has been raised in this project. This identity may read the board, so this is an
            empty board rather than a withheld one.
          </Text>
        ) : (
          <View>
            {board.value?.items.map((order) => (
              <View key={order.workOrderId} style={styles.boardRow}>
                <View style={styles.boardIdentity}>
                  <Text style={styles.boardNumber}>{order.workOrderNumber}</Text>
                  <Text style={styles.boardMeta}>
                    revision {shortId(order.revisionId)} · quantity {order.quantity}
                  </Text>
                </View>
                <View style={styles.boardCell}>
                  <Text style={styles.boardLabel}>Released</Text>
                  <Text style={styles.boardValue}>
                    {order.releasedAt === null ? 'not released' : instant(order.releasedAt)}
                  </Text>
                </View>
                <View style={styles.boardCell}>
                  <Text style={styles.boardLabel}>By</Text>
                  <Text style={styles.boardValue}>{order.releasedBy ?? '—'}</Text>
                </View>
                <StatusPill
                  label={order.status.toUpperCase()}
                  tone={order.status === 'Released' ? 'good' : 'info'}
                />
              </View>
            ))}
          </View>
        )}
        <Text style={styles.boundaryText}>
          {board.value?.releaseAuthority ??
            'Release state is reported by Control Core with the board and is conferred nowhere by reading it.'}
        </Text>
      </Panel>

      <View style={[styles.columns, narrow && styles.columnsStacked]}>
        <View style={styles.column}>
          <SectionHeading
            eyebrow="Revision control"
            title="Products and revisions"
          />
          {products.loading ? <Text style={styles.muted}>Reading the controlled register…</Text> : null}
          {!products.loading && groups.length === 0 ? (
            <Text style={styles.muted}>
              No product revision has been established for this project scope.
            </Text>
          ) : null}
          {groups.map((group) => (
            <ProductCard
              key={group.productCode}
              group={group}
              accessToken={session.accessToken}
              canRaise={canRaiseWorkOrder}
              cellId={primaryCell}
              onRaised={remember}
            />
          ))}
        </View>

        <View style={styles.column}>
          <SectionHeading
            eyebrow="Progress"
            title="On the cell now"
          />
          <OnTheCell cell={cell.value} freshnessKnown={cell.error === undefined} revisions={revisions} />

          <SectionHeading
            eyebrow="This session"
            title="Orders raised or released here"
          />
          {raised.length === 0 ? (
            <Text style={styles.muted}>Nothing has been raised or released from this page yet.</Text>
          ) : (
            raised.map((order) => (
              <RaisedOrder
                key={order.workOrderId}
                order={order}
                accessToken={session.accessToken}
                canRelease={canReleaseWorkOrder}
                onReleased={remember}
              />
            ))
          )}
        </View>
      </View>
    </>
  );
}

function ProductCard({
  group,
  accessToken,
  canRaise,
  cellId,
  onRaised,
}: {
  group: ProductGroup;
  accessToken: string | undefined;
  canRaise: boolean;
  cellId: string | undefined;
  onRaised: (order: WorkOrderRecord) => void;
}) {
  const [expanded, setExpanded] = useState<string | undefined>(undefined);

  return (
    <Panel style={styles.card}>
      <View style={styles.cardHead}>
        <View style={styles.cardTitleBlock}>
          <Text style={styles.cardEyebrow}>PRODUCT</Text>
          <Text style={styles.cardTitle}>{group.productCode}</Text>
        </View>
        <StatusPill label={`${group.revisions.length} REVISIONS`} tone="neutral" />
      </View>

      {group.revisions.map((revision) => (
        <View key={revision.revisionId} style={styles.revision}>
          <Divider />
          <View style={styles.revisionHead}>
            <View style={styles.revisionIdentity}>
              <Text style={styles.revisionCode}>{revision.revisionCode}</Text>
              <Text style={styles.revisionId}>{shortId(revision.revisionId)}</Text>
            </View>
            <StatusPill
              label={revision.lifecycleState.toUpperCase()}
              tone={lifecycleTone(revision.lifecycleState)}
            />
          </View>

          <Text style={styles.lifecycleNote}>{lifecycleNote(revision)}</Text>

          <View style={styles.metaGrid}>
            <KeyValue label="Content checksum" value={revision.sourceChecksum} mono />
            <KeyValue label="Version" value={String(revision.version)} mono />
            <KeyValue label="Released" value={revision.releasedAt ? instant(revision.releasedAt) : 'Not released'} />
            <KeyValue
              label="Superseded"
              value={revision.supersededAt ? instant(revision.supersededAt) : 'No'}
            />
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityState={{ expanded: expanded === revision.revisionId }}
            accessibilityLabel={`Show the bill of materials and route for revision ${revision.revisionCode}`}
            onPress={() =>
              setExpanded((current) => (current === revision.revisionId ? undefined : revision.revisionId))
            }
            style={({ pressed }) => [styles.expandRow, pressed && styles.pressed]}>
            <Text style={styles.expandText}>
              {expanded === revision.revisionId ? '▾ HIDE' : '▸ BOM AND ROUTE'} · {revision.bom.length} lines ·{' '}
              {revision.route.length} steps
            </Text>
          </Pressable>

          {expanded === revision.revisionId ? <RevisionDetail revision={revision} /> : null}

          {revision.lifecycleState === 'Released' ? (
            <RaiseOrderForm
              revision={revision}
              accessToken={accessToken}
              canRaise={canRaise}
              cellId={cellId}
              onRaised={onRaised}
            />
          ) : (
            <Text style={styles.blockedNote}>
              A {revision.lifecycleState.toLowerCase()} revision cannot start a work order. CH1-MFG-FR-0005
              makes that a rule of the record, and Control Core refuses it whatever this screen offers.
            </Text>
          )}
        </View>
      ))}
    </Panel>
  );
}

function RevisionDetail({ revision }: { revision: ProductRevisionSummary }) {
  return (
    <View style={styles.detail}>
      <Text style={styles.detailHeading}>BILL OF MATERIALS</Text>
      {revision.bom.length === 0 ? (
        <Text style={styles.muted}>No BOM lines recorded on this revision.</Text>
      ) : (
        revision.bom.map((line) => (
          <View key={line.componentCode} style={styles.detailRow}>
            <Text style={styles.detailPrimary}>{line.componentCode}</Text>
            <Text style={styles.detailSecondary}>
              {line.quantity} {line.unit}
            </Text>
          </View>
        ))
      )}

      <Text style={styles.detailHeading}>ROUTE</Text>
      {revision.route.length === 0 ? (
        <Text style={styles.muted}>No route steps recorded on this revision.</Text>
      ) : (
        revision.route.map((step) => (
          <View key={step.stepNumber} style={styles.detailRow}>
            <Text style={styles.detailPrimary}>
              {step.stepNumber}. {step.operationCode}
            </Text>
            <View style={styles.detailRight}>
              <Text style={styles.detailSecondary}>{step.description}</Text>
              {/* Never colour alone: the obligation is written out. */}
              <Text style={step.mandatoryInspection ? styles.inspectionRequired : styles.inspectionNone}>
                {step.mandatoryInspection ? 'INSPECTION MANDATORY' : 'no mandatory inspection'}
              </Text>
            </View>
          </View>
        ))
      )}
    </View>
  );
}

/**
 * Raising a work order. A Project Manager action in the catalogue, and one that takes no
 * step-up: it creates a record and starts nothing.
 */
function RaiseOrderForm({
  revision,
  accessToken,
  canRaise,
  cellId,
  onRaised,
}: {
  revision: ProductRevisionSummary;
  accessToken: string | undefined;
  canRaise: boolean;
  cellId: string | undefined;
  onRaised: (order: WorkOrderRecord) => void;
}) {
  const [open, setOpen] = useState(false);
  const [number, setNumber] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [attempted, setAttempted] = useState(false);
  const raise = useControlledAction<WorkOrderRecord>(accessToken);

  const amount = Number(quantity);
  const numberInvalid = number.trim().length === 0;
  const quantityInvalid = !Number.isInteger(amount) || amount <= 0;

  const submit = async () => {
    setAttempted(true);
    if (numberInvalid || quantityInvalid) return;

    const order = await raise.submit('/api/v1/work-orders', {
      workOrderNumber: number.trim(),
      revisionId: revision.revisionId,
      cellId: cellId ?? null,
      quantity: amount,
    });
    if (order) {
      // Cleared only after a success this screen saw; a refusal keeps the entry.
      setAttempted(false);
      setNumber('');
      setQuantity('1');
      onRaised(order);
    }
  };

  if (!canRaise) {
    return (
      <Text style={styles.blockedNote}>
        Raising a work order is a Project Manager action. This identity does not hold that role, so the
        control is not offered rather than offered and refused.
      </Text>
    );
  }

  return (
    <View style={styles.raiseBlock}>
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ expanded: open }}
        accessibilityLabel={`${open ? 'Close' : 'Open'} the work-order form for revision ${revision.revisionCode}`}
        onPress={() => setOpen((previous) => !previous)}
        style={({ pressed }) => [styles.expandRow, pressed && styles.pressed]}>
        <Text style={styles.expandText}>{open ? '▾ CLOSE' : '▸ RAISE A WORK ORDER'}</Text>
      </Pressable>

      {open ? (
        <View style={styles.raiseForm}>
          <TextField
            label="Work-order number"
            value={number}
            onChangeText={setNumber}
            placeholder="WO-REFAB-00018"
            maxLength={40}
            error={attempted && numberInvalid ? 'A work order must carry its controlled number.' : undefined}
          />
          <TextField
            label="Quantity"
            value={quantity}
            onChangeText={setQuantity}
            error={attempted && quantityInvalid ? 'Enter a whole quantity greater than zero.' : undefined}
            hint={cellId ? `Loaded on cell ${shortId(cellId)}` : 'No cell assignment; the order is raised without one'}
          />

          <Text style={styles.raiseNote}>
            Against revision {revision.revisionCode} at version {revision.version}. Raising an order
            starts nothing: it is a controlled record, and execution still needs the order released and
            the local confirmation chain completed at the cell.
          </Text>

          <ActionButton
            label={raise.pending ? 'RAISING…' : 'RAISE WORK ORDER'}
            onPress={() => void submit()}
            disabled={raise.pending}
          />

          {raise.error !== undefined ? (
            <CapabilityNotice error={raise.error} context="POST /api/v1/work-orders" />
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

/**
 * Releasing a work order. access.json puts this behind step-up, and the API redeems a
 * purpose-bound grant at phishing-resistant strength — so the re-authenticate route is
 * not offered at all rather than offered and certain to be refused.
 */
function RaisedOrder({
  order,
  accessToken,
  canRelease,
  onReleased,
}: {
  order: WorkOrderRecord;
  accessToken: string | undefined;
  canRelease: boolean;
  onReleased: (order: WorkOrderRecord) => void;
}) {
  const stepUp = useStepUp(accessToken);
  const release = useControlledAction<WorkOrderRecord>(accessToken);

  const submit = async (method: StepUpMethod) => {
    const grant = await stepUp.request(StepUpPurpose.WorkOrderRelease, method);
    if (!grant) return;

    const released = await release.submit(
      `/api/v1/work-orders/${order.workOrderId}/release`,
      undefined,
      { stepUpGrantId: grant.grantId },
    );
    if (released) {
      stepUp.clear();
      onReleased(released);
    }
  };

  return (
    <Panel style={styles.card}>
      <View style={styles.cardHead}>
        <View style={styles.cardTitleBlock}>
          <Text style={styles.cardEyebrow}>WORK ORDER</Text>
          <Text style={styles.cardTitle}>{order.workOrderNumber}</Text>
        </View>
        <StatusPill label={order.status.toUpperCase()} tone={orderTone(order.status)} />
      </View>

      <View style={styles.metaGrid}>
        <KeyValue label="Identifier" value={order.workOrderId} mono />
        <KeyValue label="Revision" value={shortId(order.revisionId)} mono />
        <KeyValue label="Quantity" value={String(order.quantity)} />
        <KeyValue label="Version" value={String(order.version)} mono />
        <KeyValue label="Released by" value={order.releasedBy ?? 'Not released'} />
        <KeyValue label="Released at" value={order.releasedAt ? instant(order.releasedAt) : '—'} />
      </View>

      {order.status === 'Released' ? (
        <Text style={styles.releasedNote}>
          Released for controlled execution. That authorises the order; it starts nothing. Execution
          still requires the prepared command, the local credential and the physical confirmation at
          the cell.
        </Text>
      ) : canRelease ? (
        <View style={styles.releaseBlock}>
          <StepUpPrompt
            action={`Release work order ${order.workOrderNumber}`}
            consequence="The order becomes executable under the controlled revision it names. No equipment starts, and no command is prepared."
            stepUp={stepUp}
            onGranted={(method) => void submit(method)}
            requirePhishingResistant
            disabled={release.pending}
          />
          {release.error !== undefined ? (
            <CapabilityNotice
              error={release.error}
              context={`POST /api/v1/work-orders/${order.workOrderId}/release`}
            />
          ) : null}
        </View>
      ) : (
        <Text style={styles.blockedNote}>
          Releasing a work order is a Project Manager action and additionally requires an origin-bound
          authenticator. This identity does not hold the role.
        </Text>
      )}
    </Panel>
  );
}

function OnTheCell({
  cell,
  freshnessKnown,
  revisions,
}: {
  cell: CellState | undefined;
  freshnessKnown: boolean;
  revisions: readonly ProductRevisionSummary[];
}) {
  if (!cell) {
    return (
      <Panel style={styles.card}>
        <Text style={styles.muted}>
          No cell state has been retrieved for this identity, so no order in progress can be shown.
        </Text>
      </Panel>
    );
  }

  return (
    <Panel style={styles.card}>
      <View style={styles.cardHead}>
        <View style={styles.cardTitleBlock}>
          <Text style={styles.cardEyebrow}>CELL {shortId(cell.cellId)}</Text>
          <Text style={styles.cardTitle}>{cell.state}</Text>
        </View>
        <StatusPill
          label={freshnessKnown ? cell.freshness.toUpperCase() : 'NOT CURRENT'}
          tone={freshnessKnown ? 'info' : 'warning'}
        />
      </View>
      <View style={styles.metaGrid}>
        <KeyValue label="Work order" value={cell.workOrderId} mono />
        <KeyValue label="Part" value={cell.partId} mono />
        <KeyValue label="Configuration revision" value={cell.configurationRevision} mono />
        <KeyValue label="Source time" value={instant(cell.sourceTimestamp)} />
      </View>
      <Text style={styles.cellNote}>
        {revisions.length === 0
          ? 'The revision this order was raised against cannot be named here: no revision has been retrieved.'
          : 'The order identifier comes from the controller through the cell state. The catalogue offers no way to fetch the order record itself, so its number, quantity and release state are not shown — an identifier that is real is better than fields that are guessed.'}
      </Text>
    </Panel>
  );
}

function lifecycleTone(state: RevisionLifecycleState): StatusTone {
  switch (state) {
    case 'Released':
      return 'good';
    case 'Draft':
      return 'info';
    case 'Superseded':
      return 'neutral';
    default:
      return 'warning';
  }
}

function orderTone(status: WorkOrderRecord['status']): StatusTone {
  switch (status) {
    case 'Released':
      return 'good';
    case 'Draft':
      return 'info';
    case 'Complete':
      return 'neutral';
    default:
      return 'warning';
  }
}

function lifecycleNote(revision: ProductRevisionSummary): string {
  switch (revision.lifecycleState) {
    case 'Draft':
      return 'Draft. It can still be edited, and it cannot start a work order.';
    case 'Released':
      return 'Released and immutable. This is the only state a work order can be raised against.';
    case 'Superseded':
      return 'Superseded by a later release. Existing work stands; no new order can be raised against it.';
    default:
      return 'Withdrawn. It governs nothing new.';
  }
}

const styles = StyleSheet.create({
  boardRow: {
    minHeight: 56,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Palette.line,
  },
  boardIdentity: { flex: 1.4, minWidth: 0, gap: 3 },
  boardNumber: { color: Palette.ink, fontFamily: Type.mono, fontSize: 10, fontWeight: '800' },
  boardMeta: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  boardCell: { flex: 1, minWidth: 0, gap: 3 },
  boardLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  boardValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.lg, marginBottom: Spacing.xl },
  columns: { flexDirection: 'row', gap: Spacing.xl, marginTop: Spacing.xl },
  columnsStacked: { flexDirection: 'column' },
  column: { flex: 1, minWidth: 0, gap: Spacing.lg },
  card: { gap: Spacing.md },
  cardHead: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: Spacing.md },
  cardTitleBlock: { flex: 1, gap: 3 },
  cardEyebrow: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  cardTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 16, fontWeight: '800' },
  revision: { gap: Spacing.sm },
  revisionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md },
  revisionIdentity: { flex: 1, gap: 2 },
  revisionCode: { color: Palette.ink, fontFamily: Type.sans, fontSize: 13, fontWeight: '700' },
  revisionId: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
  lifecycleNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 16 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  expandRow: { paddingVertical: 8 },
  expandText: { color: Palette.teal, fontFamily: Type.mono, fontSize: 10, fontWeight: '800', letterSpacing: 0.6 },
  pressed: { opacity: 0.7 },
  detail: { gap: 6, borderLeftWidth: 2, borderLeftColor: Palette.line, paddingLeft: Spacing.md },
  detailHeading: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 1, marginTop: 6 },
  detailRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: Spacing.md },
  detailPrimary: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10 },
  detailRight: { alignItems: 'flex-end', gap: 2, flexShrink: 1 },
  detailSecondary: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, textAlign: 'right' },
  inspectionRequired: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  inspectionNone: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  raiseBlock: { gap: 4 },
  raiseForm: { gap: Spacing.md, backgroundColor: Palette.panelRaised, borderRadius: Radius.md, borderWidth: 1, borderColor: Palette.line, padding: Spacing.lg },
  raiseNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  releaseBlock: { gap: Spacing.md },
  releasedNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 16 },
  blockedNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  boundaryText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  boundaryStrong: { color: Palette.ink, fontWeight: '800' },
  cellNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  muted: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 11 },
});
