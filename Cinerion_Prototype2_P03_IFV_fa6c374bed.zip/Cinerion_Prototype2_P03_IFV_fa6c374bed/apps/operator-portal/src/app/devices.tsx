// @screen CH1-UX-SCR-0018 — Device and configuration management: controlled assignment,
//                configuration revision, health and rollback

import { useState } from 'react';
import { useLocalSearchParams } from 'expo-router';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import { CinerionApiError } from '@/api/client';
import type { CellState, DeviceRecord, DeviceRevocation, DeviceTrustState } from '@/api/contracts';
import { instant, since } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved, useWallClock } from '@/api/use-observed';
import { owns } from '@/api/capabilities';
import { assignedCells, useSession } from '@/auth/session';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { ActAuthority } from '@/components/act-authority';
import { AppShell, PageIntro } from '@/components/app-shell';
import { DeviceEnrolmentPanel } from '@/components/device-enrolment';
import { CapabilityNotice } from '@/components/capability';
import {
  ActionButton,
  KeyValue,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { StepUpPrompt } from '@/components/step-up';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0018 — device and configuration management.
 *
 * One device at a time, because that is what the catalogue offers:
 * `GET /api/v1/devices/{deviceId}` reads a device by identifier and there is no listing
 * operation. The identifier of the controller on the assigned cell is known from the
 * cell state; anything else is entered. Trust can be withdrawn from here, which is a
 * consequential act and is gated accordingly.
 */
export default function DevicesScreen() {
  return (
    <AppShell active="devices">
      <SessionGate>
        <Devices />
      </SessionGate>
    </AppShell>
  );
}

function Devices() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();
  const now = useWallClock();
  const roles = session.claims?.roles ?? [];
  // Who may withdraw or grant device trust is decided in one place now - the capability
  // register, reconciled against api_endpoints.json and the controlled-authority register
  // by `npm run capabilities`. This screen no longer decides it.
  const isSecurityAdministrator = owns('revokeDevice', roles);
  // The catalogue gives this READ to the Engineer and the Maintenance Engineer, and
  // nobody else. Held separately from the revoke role, which is a different one, and left
  // here rather than in the register: the register covers controlled writes, because a
  // read withheld on a role guess hides data the server would have served.
  const canReadDevices = roles.includes('Engineer') || roles.includes('MaintenanceEngineer');

  const cells = assignedCells(session.claims);
  const primaryCell = cells[0];
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  // The device a link asked for. A controller named on a cell, an instrument named on a
  // measurement: both are identifiers a reader used to have to copy by hand.
  const arrived = useLocalSearchParams<{ deviceId?: string }>();
  const [entered, setEntered] = useState('');
  const [selected, setSelected] = useState<string | undefined>(undefined);
  const [attempted, setAttempted] = useState(false);
  const deviceId = selected ?? arrived.deviceId ?? cell.value?.controllerId;
  const entryInvalid = entered.trim().length === 0;

  const device = useObserved<DeviceRecord>(
    deviceId ? `/api/v1/devices/${encodeURIComponent(deviceId)}` : undefined,
    session.accessToken,
  );

  const refusal = device.cause ?? device.error;
  const notFound = refusal instanceof CinerionApiError && refusal.status === 404;

  return (
    <>
      <PageIntro
        eyebrow="CH1-UX-SCR-0018 / AssetVault"
        title="Device and configuration management"
        description="What the platform holds about one device: its identity, the configuration revision it is running, the certificate it enrolled under, whether it is trusted, and when it was last heard from."
        aside={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
      />

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Device"
          value={device.value ? device.value.deviceId : deviceId ? '—' : 'None selected'}
          note={
            selected
              ? 'Identifier entered on this page'
              : cell.value
                ? 'The controller on the assigned cell'
                : 'No cell assignment in this identity'
          }
          tone={device.value ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Trust"
          value={device.value ? device.value.trustState : '—'}
          note={device.value ? trustNote(device.value) : 'Nothing retrieved'}
          tone={device.value ? trustTone(device.value.trustState) : 'neutral'}
        />
        <KpiCard
          label="Last heard from"
          value={device.value?.lastSeenAt ? since(device.value.lastSeenAt, now) : 'Never'}
          note={
            device.value?.lastSeenQuality === 'Reported'
              ? 'When the device last reported — not a claim that it is online now'
              : 'The device has never reported'
          }
          tone={device.value?.lastSeenQuality === 'Reported' ? 'info' : 'warning'}
        />
      </View>

      {/*
        Enrolment, which this screen was missing. Revocation was offered and enrolment was
        not, so the one role that may withdraw a device's trust had no way to grant it -
        and every machine-fed reading in this system ultimately rests on a device having
        been enrolled here first.
      */}
      <ActAuthority act="enrolDevice">
        <DeviceEnrolmentPanel
          accessToken={session.accessToken}
          suggestedDeviceId={deviceId}
          onEnrolled={device.refresh}
        />
      </ActAuthority>

      <Panel>
        <SectionHeading eyebrow="Register" title="Which device" />
        <Text style={styles.copy}>
          The catalogue has <Text style={styles.strong}>no device listing operation</Text> — only
          <Text style={styles.strong}> GET /api/v1/devices/{'{deviceId}'}</Text>, which reads one device by
          identifier. So this page starts from the controller the assigned cell names, and otherwise takes
          an identifier. A register of every device in the project cannot be assembled from the controlled
          API, and is not simulated here.
        </Text>
        <View style={styles.lookup}>
          <View style={styles.lookupField}>
            <TextField
              label="Device identifier"
              value={entered}
              onChangeText={setEntered}
              placeholder="CH1-DEV-CELL-0001"
              maxLength={64}
              error={attempted && entryInvalid ? 'Enter a device identifier.' : undefined}
              hint={cell.value ? `Cell reports ${cell.value.controllerId}` : undefined}
            />
          </View>
          <ActionButton
            label="OPEN"
            onPress={() => {
              setAttempted(true);
              if (!entryInvalid) setSelected(entered.trim());
            }}
          />
          {selected ? (
            <ActionButton
              label="BACK TO THE CELL"
              kind="secondary"
              onPress={() => {
                setSelected(undefined);
                setEntered('');
                setAttempted(false);
              }}
            />
          ) : null}
        </View>
      </Panel>

      {notFound ? (
        <Panel>
          <SectionHeading eyebrow="Not found" title="No device answers to that identifier" />
          <Text style={styles.copy}>
            Either no such device is registered, or it belongs to a project this identity is not scoped
            to, or this identity holds neither the Engineer nor the Maintenance Engineer role the
            catalogue names for this read. All three answer identically, so probing cannot tell them
            apart.
          </Text>
          {isSecurityAdministrator && !canReadDevices ? (
            // Worth naming, because it is a property of the controlled access matrix
            // rather than of this identity's configuration. api_endpoints.json gives the
            // read to "Engineer or Maintainer" and the revoke to the Cybersecurity
            // Administrator, and access.json separates "Manage device configuration"
            // from "Enrol/revoke device" the same way. The consequence is that the role
            // which may withdraw trust cannot see what it is withdrawing it from.
            <Text style={styles.warning}>
              This identity may withdraw device trust but may not read a device: the catalogue gives the
              read to the Engineer and Maintenance Engineer, and the revocation to the Cybersecurity
              Administrator. Revoking from here would therefore be done without sight of the certificate
              thumbprint, trust state or last-seen time. Ask someone holding the Engineer or Maintenance
              Engineer role to confirm the device first.
            </Text>
          ) : null}
        </Panel>
      ) : device.error !== undefined ? (
        <CapabilityNotice error={refusal} context={`GET /api/v1/devices/${deviceId}`} />
      ) : null}

      {device.value ? (
        <View style={[styles.columns, narrow && styles.columnsStacked]}>
          <View style={styles.column}>
            <Panel>
              <SectionHeading eyebrow="Identity" title={device.value.deviceId} />
              <View style={styles.metaGrid}>
                <KeyValue label="Type" value={device.value.deviceType} />
                <KeyValue label="Assigned cell" value={device.value.cellId ?? 'Unassigned'} mono />
                <KeyValue label="Record version" value={String(device.value.version)} mono />
              </View>
              <Text style={styles.note}>
                CH1-IAM-FR-0008 keeps human, service and device accounts separate. A device account
                authenticates with its certificate and workload identity, never through the realm, and
                cannot hold a human role.
              </Text>
            </Panel>

            <Panel>
              <SectionHeading eyebrow="Configuration" title="What it is running" />
              <View style={styles.metaGrid}>
                <KeyValue label="Firmware" value={device.value.firmwareVersion} mono />
                <KeyValue label="Configuration revision" value={device.value.configurationRevision} mono />
              </View>
              <Text style={styles.note}>
                Reported by the device with its heartbeat, as CH1-COM-FR-0009 requires. Rollback to a
                previous configuration is not offered: the catalogue contains no operation that sets a
                device configuration, so a control here would be a button with nothing behind it.
              </Text>
            </Panel>
          </View>

          <View style={styles.column}>
            <Panel>
              <SectionHeading eyebrow="Trust" title="Certificate and state" />
              <View style={styles.trustRow}>
                <StatusPill
                  label={device.value.trustState.toUpperCase()}
                  tone={trustTone(device.value.trustState)}
                />
                {/* Never colour alone: the consequence is written out. */}
                <Text style={styles.trustWords}>{trustNote(device.value)}</Text>
              </View>
              <View style={styles.metaGrid}>
                <KeyValue
                  label="Certificate thumbprint"
                  value={device.value.certificateThumbprint ?? 'No certificate enrolled'}
                  mono
                />
                <KeyValue
                  label="Last seen"
                  value={device.value.lastSeenAt ? instant(device.value.lastSeenAt) : 'Never'}
                />
                <KeyValue
                  label="Revoked"
                  value={device.value.revokedAt ? instant(device.value.revokedAt) : 'No'}
                />
              </View>
              <Text style={styles.note}>
                The platform is a trust registry, not a certificate authority: it holds no signing key and
                issues nothing. The thumbprint is computed from the certificate the device presented, and
                there is no field in which a caller could supply one.
              </Text>
            </Panel>

            <Panel>
              <SectionHeading eyebrow="Lifecycle" title="Withdraw trust" />
              <RevokeControl
                device={device.value}
                accessToken={session.accessToken}
                permitted={isSecurityAdministrator}
                onRevoked={device.refresh}
              />
            </Panel>
          </View>
        </View>
      ) : null}
    </>
  );
}

/**
 * Revocation. api_endpoints.json makes this a Cybersecurity Administrator action behind
 * step-up MFA, and access.json asks for hardware-backed MFA to revoke a device — so the
 * re-authenticate route is not offered, only the origin-bound one.
 */
function RevokeControl({
  device,
  accessToken,
  permitted,
  onRevoked,
}: {
  device: DeviceRecord;
  accessToken: string | undefined;
  permitted: boolean;
  onRevoked: () => void;
}) {
  const [reason, setReason] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const revoke = useControlledAction<DeviceRevocation>(accessToken);
  const reasonInvalid = reason.trim().length < 8;

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (reasonInvalid) return;

    const grant = await stepUp.request(StepUpPurpose.DeviceTrust, method);
    if (!grant) return;

    const result = await revoke.submit(
      `/api/v1/devices/${encodeURIComponent(device.deviceId)}/revoke`,
      { reason: reason.trim() },
      { stepUpGrantId: grant.grantId },
    );
    if (result) {
      // Cleared only on a success this screen saw.
      setAttempted(false);
      setReason('');
      stepUp.clear();
      onRevoked();
    }
  };

  if (device.trustState === 'Revoked') {
    return (
      <Text style={styles.note}>
        Trust was withdrawn on {instant(device.revokedAt)}. The record is kept rather than cleared: a
        forgotten certificate could be presented elsewhere unnoticed. A revoked device is never silently
        restored — replacing it is a new enrolment decision, not a repeat of the old one.
      </Text>
    );
  }

  if (!permitted) {
    return (
      <Text style={styles.note}>
        Withdrawing device trust is a Cybersecurity Administrator action and additionally requires an
        origin-bound authenticator. This identity does not hold that role, so the control is not offered
        rather than offered and refused.
      </Text>
    );
  }

  return (
    <View style={styles.revokeBlock}>
      <TextField
        label="Reason"
        value={reason}
        onChangeText={setReason}
        placeholder="Controller returned to the supplier"
        maxLength={200}
        multiline
        error={attempted && reasonInvalid ? 'Say why in a few words. The reason is kept with the record.' : undefined}
      />

      <StepUpPrompt
        action={`Withdraw trust from ${device.deviceId}`}
        consequence="The device is refused on its next reading and an alarm is raised. Nothing it has already reported is deleted, and no equipment is stopped by this act."
        stepUp={stepUp}
        onGranted={(method) => void submit(method)}
        requirePhishingResistant
        disabled={revoke.pending}
      />

      {revoke.error !== undefined ? (
        <CapabilityNotice
          error={revoke.error}
          context={`POST /api/v1/devices/${device.deviceId}/revoke`}
        />
      ) : null}

      {revoke.result !== undefined ? <RevocationReceipt result={revoke.result} /> : null}
    </View>
  );
}

/**
 * What the revocation actually did, in the server's own words — including the half it
 * did not do. CH1-COM-IF-0004 puts the topic ACL in the MQTT broker, which is not
 * enabled, and a receipt that implied both halves had taken effect would be the more
 * dangerous kind of wrong.
 *
 * Exported so `npm run render:portal` can render it directly. Reaching it through the
 * screen needs a phishing-resistant step-up grant, and issuing one inside a test harness
 * would be the harness manufacturing an elevation — which is the one thing a step-up
 * exists not to be. The export is of a pure presentational component and grants nothing.
 */
export function RevocationReceipt({ result }: { result: DeviceRevocation }) {
  return (
    <View style={styles.receipt}>
      <Text style={styles.receiptTitle}>TRUST WITHDRAWN</Text>
      <Text style={styles.receiptLine}>
        {result.device.deviceId} · {result.device.trustState} · {instant(result.device.revokedAt)} by{' '}
        {result.device.revokedBy}
      </Text>
      {result.device.revocationReason ? (
        <Text style={styles.receiptLine}>Reason recorded: {result.device.revocationReason}</Text>
      ) : null}

      {result.alarm ? (
        <View style={styles.alarmBlock}>
          <Text style={styles.receiptAlarm}>
            Alarm {result.alarm.alarmCode} raised at priority {result.alarm.priority}, state{' '}
            {result.alarm.state}
          </Text>
          {/* The server's guidance, verbatim. Rewording it here would put this screen
              between an operator and the instruction the platform actually gave. */}
          <Text style={styles.receiptNote}>{result.alarm.guidance}</Text>
        </View>
      ) : null}

      <View style={styles.effects}>
        <Effect done={result.effect.platformTrustWithdrawn} label="Platform trust withdrawn" />
        <Effect done={result.effect.telemetryRefusedImmediately} label="Next reading refused" />
        <Effect done={result.effect.brokerTopicAclRevoked} label="Broker topic ACL revoked" />
      </View>
      <Text style={styles.receiptNote}>{result.effect.brokerTopicAclNote}</Text>
    </View>
  );
}

function Effect({ done, label }: { done: boolean; label: string }) {
  return (
    <Text style={done ? styles.effectDone : styles.effectNotDone}>
      {done ? 'DONE' : 'NOT DONE'} · {label}
    </Text>
  );
}

function trustTone(state: DeviceTrustState): StatusTone {
  switch (state) {
    case 'Trusted':
      return 'good';
    case 'Revoked':
      return 'danger';
    case 'Pending':
      return 'warning';
    default:
      return 'neutral';
  }
}

function trustNote(device: DeviceRecord): string {
  switch (device.trustState) {
    case 'Trusted':
      return 'Readings and commands from this device are accepted';
    case 'Revoked':
      return 'Every reading is refused; the record is kept as evidence';
    case 'Pending':
      return 'Enrolled but not yet trusted; readings are refused';
    default:
      return 'No certificate has been enrolled for this device';
  }
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.lg, marginBottom: Spacing.xl },
  columns: { flexDirection: 'row', gap: Spacing.xl, marginTop: Spacing.xl },
  columnsStacked: { flexDirection: 'column' },
  column: { flex: 1, minWidth: 0, gap: Spacing.lg },
  copy: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  strong: { color: Palette.ink, fontWeight: '800' },
  note: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  warning: { color: Palette.amber, fontFamily: Type.sans, fontSize: 11, lineHeight: 17, marginTop: Spacing.md },
  lookup: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.md, flexWrap: 'wrap', marginTop: Spacing.md },
  lookupField: { flex: 1, minWidth: 260 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  trustRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap' },
  trustWords: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, flexShrink: 1 },
  revokeBlock: { gap: Spacing.md },
  receipt: { backgroundColor: Palette.panelRaised, borderRadius: Radius.md, borderWidth: 1, borderColor: Palette.line, padding: Spacing.lg, gap: 6 },
  receiptTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 },
  receiptLine: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10 },
  receiptAlarm: { color: Palette.amber, fontFamily: Type.mono, fontSize: 10 },
  receiptNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  alarmBlock: { gap: 4 },
  effects: { gap: 3, marginTop: 4 },
  effectDone: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  effectNotDone: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
});
