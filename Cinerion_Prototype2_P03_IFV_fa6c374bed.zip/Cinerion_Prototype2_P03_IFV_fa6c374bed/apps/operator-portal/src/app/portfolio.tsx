// @screen CH1-UX-SCR-0003 — Project portfolio: project status and gate summary

import { useState } from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { ProjectSummary, SystemHealth } from '@/api/contracts';
import { instant } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved } from '@/api/use-observed';
import { owns } from '@/api/capabilities';
import { useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import {
  ActionButton,
  Divider,
  KeyValue,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { SessionGate } from '@/components/session-gate';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0003 — project portfolio: project status and gate summary.
 *
 * Two controlled operations sit behind this screen and nothing else does:
 * `GET /api/v1/projects`, which returns the stored governance record for the workspace
 * this identity is scoped to, and `POST /api/v1/projects`, which establishes it once.
 *
 * "Gate summary" is where this screen has to be careful. The controlled development
 * gates G0–G9 are a programme artefact, and the P03 catalogue contains no operation
 * that reports the state of one for a project — so a green row here would be a claim
 * with nothing behind it, on the very screen a reader would use to judge whether a
 * project may proceed. What the portal *can* evidence from controlled reads is stated
 * instead: whether the workspace exists, which baseline governs it, whether that
 * baseline is the one the running service was built from, and whether this deployment
 * carries simulation authority or production authority. The rest is named as absent.
 */
export default function PortfolioScreen() {
  return (
    <AppShell active="portfolio">
      <SessionGate>
        <Portfolio />
      </SessionGate>
    </AppShell>
  );
}

/** The pattern ch1.projects.project_code is CHECK-constrained to, mirrored for inline validation. */
const ProjectCodePattern = /^CH1(-[A-Z0-9]+)*$/;

function Portfolio() {
  const { width } = useWindowDimensions();
  const narrow = width < 1180;
  const session = useSession();
  const roles = session.claims?.roles ?? [];
  // Who owns this act is decided in one place now: the capability register, reconciled
  // against api_endpoints.json and the controlled-authority register by
  // `npm run capabilities`. This screen no longer spells the authority itself.
  const isProjectManager = owns('createProject', roles);

  const projects = useObserved<readonly ProjectSummary[]>('/api/v1/projects', session.accessToken);
  const health = useObserved<SystemHealth>('/api/v1/system/health', session.accessToken);

  const established = projects.value?.[0];
  // The scope is in the token; the record is in the database. The two disagreeing is
  // the state this screen exists to make visible, so they are read separately and
  // never merged.
  const scopedProjectId = session.claims?.ch1_project;

  return (
    <>
      <PageIntro
        eyebrow="Governance / CH1-UX-SCR-0003"
        title="Project portfolio"
        description="The controlled governance record for the workspace this identity is scoped to, and the baseline that governs it. A token scope is an authorisation, not a project: this page shows the stored record, or says plainly that none has been established."
        aside={
          <StatusPill
            label={established ? 'WORKSPACE ESTABLISHED' : 'NOT ESTABLISHED'}
            tone={established ? 'good' : 'warning'}
          />
        }
      />

      {projects.error !== undefined ? (
        <CapabilityNotice error={projects.cause ?? projects.error} context="GET /api/v1/projects" />
      ) : null}

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Authorised workspaces"
          value={projects.loading ? '—' : String(projects.value?.length ?? 0)}
          note="A token carries one project scope, so this list is never longer than one"
          tone={established ? 'info' : 'warning'}
        />
        <KpiCard
          label="Governing baseline"
          value={established?.baseline ?? '—'}
          note={established ? 'Recorded on the project when it was established' : 'No project record to read it from'}
          tone={established ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Service baseline"
          value={health.value?.baseline ?? '—'}
          note="The baseline the running Control Core was built from"
          tone={health.value ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Configuration revision"
          value={established ? `v${established.version}` : '—'}
          note="Project configuration is revisioned, never recreated"
          tone={established ? 'info' : 'neutral'}
        />
      </View>

      <View style={[styles.grid, narrow && styles.stacked]}>
        <ProjectRecordPanel
          project={established}
          scopedProjectId={typeof scopedProjectId === 'string' ? scopedProjectId : undefined}
          loading={projects.loading}
        />
        <GateSummary project={established} health={health.value} />
      </View>

      <Establish
        established={established !== undefined}
        isProjectManager={isProjectManager}
        onEstablished={() => projects.refresh()}
      />
    </>
  );
}

function ProjectRecordPanel({
  project,
  scopedProjectId,
  loading,
}: {
  project: ProjectSummary | undefined;
  scopedProjectId: string | undefined;
  loading: boolean;
}) {
  // A scope naming a project that has no record is a real and confusing state: every
  // read succeeds and returns nothing. Saying which of the two is missing turns it
  // from "the system is empty" into "the workspace was never established".
  const scopeWithoutRecord = !loading && project === undefined && scopedProjectId !== undefined;

  return (
    <Panel style={styles.wide}>
      <SectionHeading
        eyebrow="ch1.projects"
        title="Controlled governance record"
        action={<StatusPill label={project ? 'STORED' : 'ABSENT'} tone={project ? 'good' : 'warning'} />}
      />

      {project ? (
        <View style={styles.metaGrid}>
          <KeyValue label="Project code" value={project.projectCode} mono />
          <KeyValue label="Name" value={project.name} />
          <KeyValue label="Baseline" value={project.baseline} mono />
          <KeyValue label="Revision" value={`v${project.version}`} />
          <KeyValue label="Established" value={instant(project.createdAt)} />
          <KeyValue label="Identifier" value={project.projectId} mono />
        </View>
      ) : loading ? (
        <Text style={styles.muted}>Reading the governance record.</Text>
      ) : (
        <View style={styles.notice}>
          <Text style={styles.noticeCode}>NO PROJECT ESTABLISHED FOR THIS SCOPE</Text>
          <Text style={styles.noticeText}>
            {scopeWithoutRecord
              ? `This identity is scoped to ${scopedProjectId}, but no project record exists under it. ` +
                'The scope is an authorisation the identity provider issued; the record is a controlled ' +
                'act that has not been performed. Every read will succeed and return nothing until it is.'
              : 'This identity carries no ch1_project scope, so there is no workspace to read. Project ' +
                'scope is granted by an administrator in the identity provider.'}
          </Text>
        </View>
      )}

      <Divider />
      <Text style={styles.footnote}>
        This record is read from the database, not projected from the access token. Control Core
        never synthesises a project from a claim: doing so would report a governance record that
        nobody created and nothing audited.
      </Text>
    </Panel>
  );
}

/**
 * What can honestly be said about readiness, and what cannot.
 */
function GateSummary({
  project,
  health,
}: {
  project: ProjectSummary | undefined;
  health: SystemHealth | undefined;
}) {
  const baselineAgrees =
    project !== undefined && health !== undefined && project.baseline === health.baseline;

  const checks: readonly { label: string; state: string; tone: StatusTone; detail: string }[] = [
    {
      label: 'Workspace established',
      state: project ? 'YES' : 'NO',
      tone: project ? 'good' : 'warning',
      detail: project
        ? 'A controlled project record exists and was audited when it was created.'
        : 'No controlled record exists for this scope.',
    },
    {
      label: 'Baseline agreement',
      state: project === undefined || health === undefined ? 'UNKNOWN' : baselineAgrees ? 'AGREES' : 'DIFFERS',
      tone: project === undefined || health === undefined ? 'neutral' : baselineAgrees ? 'good' : 'danger',
      detail:
        project === undefined || health === undefined
          ? 'Both the project record and the service health are needed to compare them.'
          : baselineAgrees
            ? `The project is governed by ${project.baseline} and the service was built from the same baseline.`
            : `The project is governed by ${project.baseline} but the service reports ${health.baseline}. ` +
              'Evidence produced here is not evidence against the project baseline.',
    },
    {
      label: 'Execution authority',
      state: health ? health.runtimeProfile.toUpperCase() : 'UNKNOWN',
      tone: health === undefined ? 'neutral' : health.simulation ? 'info' : 'warning',
      detail: health
        ? health.safetyNotice
        : 'The service has not reported its runtime profile.',
    },
    {
      label: 'Identity source',
      state: health === undefined ? 'UNKNOWN' : health.developmentIdentityEnabled ? 'DEVELOPMENT' : 'FORTRESSGATE',
      tone: health === undefined ? 'neutral' : health.developmentIdentityEnabled ? 'danger' : 'good',
      detail:
        health?.developmentIdentityEnabled === true
          ? 'Development identity is enabled, so requests are authorised from headers rather than a ' +
            'verified token. Nothing produced in this state is controlled evidence.'
          : 'Every request is authorised from a signed token the identity provider issued.',
    },
  ];

  return (
    <Panel style={styles.narrow}>
      <SectionHeading eyebrow="Gate summary" title="What can be evidenced" />
      {checks.map((check, index) => (
        <View key={check.label}>
          {index === 0 ? null : <Divider />}
          <View style={styles.checkRow}>
            <Text style={styles.checkLabel}>{check.label}</Text>
            <StatusPill label={check.state} tone={check.tone} />
          </View>
          <Text style={styles.checkDetail}>{check.detail}</Text>
        </View>
      ))}

      <View style={styles.gap}>
        <Text style={styles.gapCode}>GATES G0–G9 ARE NOT SHOWN, AND THAT IS DELIBERATE</Text>
        <Text style={styles.gapText}>
          The controlled development gates are a programme artefact recorded in the project
          documentation. The P03 API catalogue contains no operation that reports the state of one,
          so this screen cannot read them. A row saying G4 was satisfied would be a claim with
          nothing behind it, on the screen a reader would use to decide whether the project may
          proceed — so the four checks above are what controlled reads actually support, and the
          gates are named as absent rather than drawn as pending.
        </Text>
      </View>
    </Panel>
  );
}

/**
 * `POST /api/v1/projects` — the only controlled mutation on this screen.
 *
 * The identifier is not a field. Control Core takes it from the caller's own
 * `ch1_project` scope, so a Project Manager cannot establish a workspace under an
 * identifier they were not issued, and the form has nowhere to put one.
 */
function Establish({
  established,
  isProjectManager,
  onEstablished,
}: {
  established: boolean;
  isProjectManager: boolean;
  onEstablished: () => void;
}) {
  const session = useSession();
  const action = useControlledAction<ProjectSummary>(session.accessToken);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [baseline, setBaseline] = useState('');
  const [validation, setValidation] = useState<string | undefined>(undefined);

  if (established) {
    return (
      <Panel>
        <SectionHeading eyebrow="POST /api/v1/projects" title="Establishing a workspace" />
        <Text style={styles.muted}>
          A workspace already exists for this scope. Establishing is a one-time controlled act;
          later changes are revisioned against the record above, not made by recreating it. A second
          attempt is refused with PROJECT_ALREADY_ESTABLISHED.
        </Text>
      </Panel>
    );
  }

  if (!isProjectManager) {
    return (
      <Panel>
        <SectionHeading eyebrow="POST /api/v1/projects" title="Establishing a workspace" />
        <Text style={styles.muted}>
          No workspace exists for this scope, and establishing one requires the Project Manager
          role, which this identity does not hold. The control is not offered rather than offered
          and certain to be refused — Control Core would refuse it regardless of what this screen
          displayed.
        </Text>
      </Panel>
    );
  }

  const submit = async () => {
    const trimmedCode = code.trim().toUpperCase();
    if (!ProjectCodePattern.test(trimmedCode)) {
      setValidation('The project code must match the controlled CH1 namespace, for example CH1-REFAB-01.');
      return;
    }

    if (name.trim().length === 0) {
      setValidation('A project name is required.');
      return;
    }

    if (baseline.trim().length === 0) {
      setValidation('A governing baseline is required; it is recorded permanently on the project.');
      return;
    }

    setValidation(undefined);
    const created = await action.submit('/api/v1/projects', {
      projectCode: trimmedCode,
      name: name.trim(),
      baseline: baseline.trim(),
    });

    // Cleared only after a success this screen has seen, so a refusal keeps the
    // entered work exactly as CH1-UXD-DSG-0001 requires.
    if (created) {
      setCode('');
      setName('');
      setBaseline('');
      onEstablished();
    }
  };

  return (
    <Panel>
      <SectionHeading
        eyebrow="POST /api/v1/projects"
        title="Establish this project workspace"
        action={<StatusPill label="PROJECT MANAGER" tone="info" />}
      />
      <Text style={styles.muted}>
        The workspace identifier is taken from this identity&apos;s own scope and is not a field
        here. The baseline is recorded permanently and is what later evidence is judged against.
      </Text>

      <View style={styles.form}>
        <TextField
          label="Project code"
          value={code}
          onChangeText={setCode}
          placeholder="CH1-REFAB-01"
          hint="Uppercase, CH1 namespace. Mirrors the CHECK constraint on ch1.projects.project_code."
          maxLength={64}
          editable={!action.pending}
        />
        <TextField
          label="Project name"
          value={name}
          onChangeText={setName}
          placeholder="ReFab cassette line"
          maxLength={128}
          editable={!action.pending}
        />
        <TextField
          label="Governing baseline"
          value={baseline}
          onChangeText={setBaseline}
          placeholder="P03/IFV"
          hint="Recorded on the project permanently."
          maxLength={64}
          editable={!action.pending}
        />
      </View>

      {validation ? (
        <Text accessibilityRole="alert" style={styles.validation}>
          ✕ {validation}
        </Text>
      ) : null}

      {action.error !== undefined ? (
        <CapabilityNotice error={action.error} context="POST /api/v1/projects" />
      ) : null}

      {action.result ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptCode}>WORKSPACE ESTABLISHED</Text>
          <Text style={styles.receiptText}>
            {action.result.projectCode} · {action.result.name} · baseline {action.result.baseline} ·
            revision v{action.result.version}, recorded at {instant(action.result.createdAt)} and
            written to the audit chain as ProjectEstablished.
          </Text>
        </View>
      ) : null}

      <View style={styles.actions}>
        <ActionButton
          label={action.pending ? 'ESTABLISHING…' : 'ESTABLISH WORKSPACE'}
          onPress={submit}
          disabled={action.pending}
        />
      </View>
    </Panel>
  );
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, marginBottom: Spacing.md },
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  wide: { flex: 1.3, minWidth: 0 },
  narrow: { flex: 1, minWidth: 320 },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl, paddingVertical: Spacing.md },
  muted: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  footnote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15, marginTop: Spacing.md },
  notice: { marginTop: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  noticeCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  noticeText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  checkRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: Spacing.md, paddingTop: Spacing.md },
  checkLabel: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, fontWeight: '700', flexShrink: 1 },
  checkDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15, paddingTop: 4, paddingBottom: Spacing.sm },
  gap: { marginTop: Spacing.md, backgroundColor: '#101F2E', borderRadius: Radius.md, padding: Spacing.md, borderLeftWidth: 3, borderLeftColor: Palette.cyan, gap: 5 },
  gapCode: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  gapText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  form: { gap: Spacing.md, paddingTop: Spacing.md },
  validation: { color: Palette.red, fontFamily: Type.sans, fontSize: 10, fontWeight: '700', paddingTop: Spacing.sm },
  receipt: { marginTop: Spacing.md, backgroundColor: Palette.greenSoft, borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: '#2C5A44', gap: 5 },
  receiptCode: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  actions: { flexDirection: 'row', gap: Spacing.md, paddingTop: Spacing.md },
});
