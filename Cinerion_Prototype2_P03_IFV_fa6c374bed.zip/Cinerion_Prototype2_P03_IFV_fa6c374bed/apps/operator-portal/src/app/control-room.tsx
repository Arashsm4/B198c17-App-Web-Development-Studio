// @screen CH1-UX-SCR-0005 — Live control room: freshness-qualified state, alarms and telemetry

import { useMemo, useState } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type {
  AlarmAcknowledgement,
  AlarmPage,
  AlarmRecord,
  AlarmState,
  TelemetryChannel,
  TelemetryPage,
  TelemetrySample,
} from '@/api/contracts';
import { instant, since, timeOfDay } from '@/api/format';
import { isCurrentObservation } from '@/api/freshness';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved, useWallClock } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { ConnectedObjects } from '@/components/object-link';
import {
  ActionButton,
  Panel,
  SectionHeading,
  SemanticMark,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { AlarmSemantics, describeAlarmPriority, MessageSemantics } from '@/constants/semantics';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/** Longest acknowledgement comment ch1.alarms accepts (Alarm.Acknowledge). */
const COMMENT_LIMIT = 1_000;

/** Rows requested per telemetry poll. Well inside the server's 1000-row bound. */
const TELEMETRY_ROWS = 200;

const ALARM_STATES: readonly AlarmState[] = [
  'Active',
  'Acknowledged',
  'ReturnedUnacknowledged',
  'Cleared',
];

export default function ControlRoomScreen() {
  return (
    <AppShell active="control-room">
      <SessionGate>
        <ControlRoom />
      </SessionGate>
    </AppShell>
  );
}

function ControlRoom() {
  const { width } = useWindowDimensions();
  const compact = width < 1180;
  const session = useSession();
  const cells = assignedCells(session.claims);

  /**
   * The cell a link asked for, if this screen was reached from one.
   *
   * It is a starting point, not a scope: the operator's own choice still wins, and
   * Control Core re-evaluates cell scope on every read regardless of what arrived here.
   * A cell this identity is not assigned to is refused there, exactly as it would be if
   * the identifier had been typed.
   */
  const arrived = useLocalSearchParams<{ cellId?: string }>();
  const [selectedCell, setSelectedCell] = useState<string | undefined>(undefined);
  const cellId = selectedCell ?? arrived.cellId ?? cells[0];
  const [stateFilter, setStateFilter] = useState<readonly AlarmState[]>([]);

  // The window is left to the server's default. Putting a computed `from` in the path
  // would change the URL on every render and refetch continuously.
  const telemetryPath = cellId
    ? `/api/v1/telemetry?cellId=${cellId}&limit=${TELEMETRY_ROWS}`
    : undefined;
  const alarmPath = cellId
    ? `/api/v1/alarms?cellId=${cellId}${stateFilter.map((state) => `&state=${state}`).join('')}`
    : undefined;

  const telemetry = useObserved<TelemetryPage>(
    telemetryPath,
    session.accessToken,
    (value) => value.freshness,
  );
  const alarms = useObserved<AlarmPage>(alarmPath, session.accessToken, (value) => value.freshness);

  return (
    <>
      <PageIntro
        eyebrow="CH1-UX-SCR-0005 / OperationsView"
        title="Live control room"
        description="Freshness-qualified telemetry and the alarms it raises. Every reading carries its source device, sampled time and quality; an alarm carries its priority, activation, acknowledgement and clear state as separate facts, because acknowledging one has never cleared the other."
        aside={<FreshnessTag freshness={alarms.freshness} detail="alarm feed" />}
      />

      {cells.length === 0 ? (
        <Banner
          tone="warning"
          title="NO CELL ASSIGNMENT"
          body="This identity carries no ch1_cell scope, so neither telemetry nor alarms can be requested. Cell assignment is granted by an administrator in the identity provider."
        />
      ) : null}

      {cells.length > 1 ? (
        <CellSelector cells={cells} selected={cellId} onSelect={setSelectedCell} />
      ) : null}

      <View style={[styles.grid, compact && styles.stacked]}>
        <ChannelStrip page={telemetry.value} cause={telemetry.cause} freshness={telemetry.freshness} />
        <TelemetryBounds page={telemetry.value} />
      </View>

      <AlarmBoard
        page={alarms.value}
        cause={alarms.cause}
        freshness={alarms.freshness}
        accessToken={session.accessToken}
        stateFilter={stateFilter}
        onStateFilter={setStateFilter}
        onReconcile={alarms.refresh}
      />
    </>
  );
}

function CellSelector({
  cells,
  selected,
  onSelect,
}: {
  cells: readonly string[];
  selected: string | undefined;
  onSelect: (cellId: string) => void;
}) {
  return (
    <View style={styles.selector}>
      <Text style={styles.selectorLabel}>ASSIGNED CELLS</Text>
      <View style={styles.selectorRow}>
        {cells.map((cell) => {
          const active = cell === selected;
          return (
            <Pressable
              key={cell}
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              onPress={() => onSelect(cell)}
              style={({ pressed }) => [
                styles.chip,
                active && styles.chipActive,
                pressed && styles.chipPressed,
              ]}>
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{cell}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

/**
 * The newest reading on each channel the controlled catalogue permits.
 *
 * Every allowlisted channel is listed, including those with no reading: an absent
 * channel would be indistinguishable from one that is simply not being published, and
 * the allowlist is only observable if what it contains is visible.
 */
function ChannelStrip({
  page,
  cause,
  freshness,
}: {
  page: TelemetryPage | undefined;
  cause: unknown;
  freshness: TelemetryPage['freshness'];
}) {
  const now = useWallClock();
  const latest = useMemo(() => newestPerChannel(page?.items ?? []), [page]);
  const channels = page?.channelAllowlist.channels ?? [];

  return (
    <Panel style={styles.channelPanel}>
      <SectionHeading
        eyebrow={`Channel allowlist ${page?.channelAllowlist.version ?? '—'}`}
        title="Telemetry"
        action={<FreshnessTag freshness={freshness} />}
      />

      {cause !== undefined ? <CapabilityNotice error={cause} context="GET /api/v1/telemetry" /> : null}

      {channels.length === 0 && cause === undefined ? (
        <Text style={styles.empty}>
          No channel catalogue has been retrieved, so nothing can be said about which channels this
          cell is permitted to publish.
        </Text>
      ) : null}

      <View style={styles.channelGrid}>
        {channels.map((channel) => (
          <ChannelCard
            key={channel.channelId}
            channel={channel}
            sample={latest.get(channel.channelId)}
            now={now}
          />
        ))}
      </View>
    </Panel>
  );
}

function ChannelCard({
  channel,
  sample,
  now,
}: {
  channel: TelemetryChannel;
  sample: TelemetrySample | undefined;
  now: number | undefined;
}) {
  const outside =
    sample !== undefined &&
    (sample.value < channel.lowerAlarmLimit || sample.value > channel.upperAlarmLimit);

  return (
    <View style={[styles.channelCard, outside && styles.channelCardOutside]}>
      <View style={styles.channelHeader}>
        <Text style={styles.channelId}>{channel.channelId}</Text>
        {sample ? (
          <FreshnessTag freshness={sample.freshness} quality={sample.quality} />
        ) : (
          <Text style={styles.channelNoReading}>NO READING</Text>
        )}
      </View>

      <Text style={[styles.channelValue, outside && styles.channelValueOutside]}>
        {sample ? `${formatValue(sample.value)} ${sample.unit}` : '—'}
      </Text>

      <Text style={styles.channelLimits}>
        Alarm limits {channel.lowerAlarmLimit} — {channel.upperAlarmLimit} {channel.unit}
      </Text>

      {outside ? (
        <Text style={styles.channelOutsideNote}>
          ▲ OUTSIDE ALARM LIMIT — Control Core raises the alarm, not this screen. Check the alarm
          list below for the record.
        </Text>
      ) : null}

      {sample ? (
        <View style={styles.channelFooter}>
          <Text style={styles.channelMeta} numberOfLines={1}>
            {sample.deviceId}
          </Text>
          <Text style={styles.channelMeta}>
            {timeOfDay(sample.sampledAt)} · {since(sample.sampledAt, now)}
          </Text>
        </View>
      ) : (
        <Text style={styles.channelMeta}>
          Declared in the catalogue; no sample stored inside the served window.
        </Text>
      )}
    </View>
  );
}

/** What the server actually applied, so a truncated answer is not read as a complete one. */
function TelemetryBounds({ page }: { page: TelemetryPage | undefined }) {
  return (
    <Panel style={styles.boundsPanel}>
      <SectionHeading eyebrow="CH1-SWA-API-0001" title="Query bounds" />
      <BoundRow label="Rows returned" value={page ? String(page.count) : '—'} />
      <BoundRow
        label="Complete answer"
        value={page ? (page.truncated ? 'NO — page is full' : 'Yes') : '—'}
        tone={page?.truncated ? 'warning' : undefined}
      />
      <BoundRow label="Row ceiling" value={page ? String(page.bounds.maximumRows) : '—'} />
      <BoundRow
        label="Window applied"
        value={page ? `${page.bounds.defaultWindowHours} h (default)` : '—'}
      />
      <BoundRow
        label="Widest window"
        value={page ? `${page.bounds.maximumWindowDays} days` : '—'}
      />
      <BoundRow label="Newest sample" value={instant(page?.newestSampleAt)} />
      <View style={styles.boundsNote}>
        <Text style={styles.boundsNoteTitle}>THE ALLOWLIST REFUSES, IT DOES NOT FILTER</Text>
        <Text style={styles.boundsNoteText}>
          A channel outside the catalogue is answered with TELEMETRY_CHANNEL_NOT_ALLOWED rather than
          an empty page, so an undeclared channel cannot be mistaken for a declared one with no data.
        </Text>
      </View>
    </Panel>
  );
}

function BoundRow({ label, value, tone }: { label: string; value: string; tone?: StatusTone }) {
  return (
    <View style={styles.boundRow}>
      <Text style={styles.boundLabel}>{label}</Text>
      <Text style={[styles.boundValue, tone === 'warning' && styles.boundValueWarning]}>{value}</Text>
    </View>
  );
}

function AlarmBoard({
  page,
  cause,
  freshness,
  accessToken,
  stateFilter,
  onStateFilter,
  onReconcile,
}: {
  page: AlarmPage | undefined;
  cause: unknown;
  freshness: AlarmPage['freshness'];
  accessToken: string | undefined;
  stateFilter: readonly AlarmState[];
  onStateFilter: (next: readonly AlarmState[]) => void;
  onReconcile: () => void;
}) {
  const [openAlarmId, setOpenAlarmId] = useState<string | undefined>(undefined);
  // Keyed by alarm so switching between alarms, or closing and reopening one, never
  // discards what was typed. CH1-UXD-DSG-0001 requires entered work to survive.
  const [comments, setComments] = useState<Record<string, string>>({});
  const [actingAlarmId, setActingAlarmId] = useState<string | undefined>(undefined);
  const [attempted, setAttempted] = useState<Record<string, boolean>>({});
  const action = useControlledAction<AlarmAcknowledgement>(accessToken);

  // A screen that is not current must not offer a consequential mutation, and must
  // offer a way to reconcile instead.
  const current = isCurrentObservation(freshness);
  const alarms = page?.items ?? [];
  const outstanding = alarms.filter((alarm) => alarm.outstanding).length;

  const toggleState = (state: AlarmState) => {
    onStateFilter(
      stateFilter.includes(state)
        ? stateFilter.filter((item) => item !== state)
        : [...stateFilter, state],
    );
  };

  const acknowledge = async (alarm: AlarmRecord) => {
    const comment = (comments[alarm.alarmId] ?? '').trim();
    setAttempted((previous) => ({ ...previous, [alarm.alarmId]: true }));
    if (comment.length === 0 || comment.length > COMMENT_LIMIT) return;

    setActingAlarmId(alarm.alarmId);
    const recorded = await action.submit(`/api/v1/alarms/${alarm.alarmId}/acknowledgements`, {
      comment,
    });
    if (recorded) {
      // Cleared only on a success this screen actually saw. A refusal leaves the
      // comment in the field so it can be corrected and resent.
      setComments((previous) => ({ ...previous, [alarm.alarmId]: '' }));
      setAttempted((previous) => ({ ...previous, [alarm.alarmId]: false }));
      onReconcile();
    }
  };

  return (
    <Panel>
      <SectionHeading
        eyebrow="CH1-AUT-FDS-0001 / CH1-MON-FR-0002"
        title="Alarms"
        action={
          <View style={styles.headerActions}>
            <FreshnessTag freshness={freshness} detail={page ? `as of ${timeOfDay(page.asOf)}` : undefined} />
            <StatusPill
              label={`${outstanding} OUTSTANDING`}
              tone={outstanding > 0 ? 'warning' : 'good'}
            />
          </View>
        }
      />

      <View style={styles.filterRow}>
        <Text style={styles.filterLabel}>STATE</Text>
        {ALARM_STATES.map((state) => {
          const active = stateFilter.includes(state);
          return (
            <Pressable
              key={state}
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              accessibilityLabel={`Filter alarms by state ${state}`}
              onPress={() => toggleState(state)}
              style={({ pressed }) => [
                styles.chip,
                active && styles.chipActive,
                pressed && styles.chipPressed,
              ]}>
              <Text style={[styles.chipText, active && styles.chipTextActive]}>
                {active ? '✓ ' : ''}
                {state}
              </Text>
            </Pressable>
          );
        })}
        {stateFilter.length > 0 ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Clear the alarm state filter"
            onPress={() => onStateFilter([])}
            style={({ pressed }) => [styles.chip, pressed && styles.chipPressed]}>
            <Text style={styles.chipText}>✕ CLEAR FILTER</Text>
          </Pressable>
        ) : null}
      </View>

      {cause !== undefined ? <CapabilityNotice error={cause} context="GET /api/v1/alarms" /> : null}

      {!current && alarms.length > 0 ? (
        <View style={styles.staleBar}>
          <View style={styles.staleCopy}>
            <Text style={styles.staleTitle}>▲ SCREEN NOT CURRENT — ACKNOWLEDGEMENT DISABLED</Text>
            <Text style={styles.staleText}>
              These alarms are the last list received, not the present state of the cell.
              Acknowledging is a permanent record against your identity, so it is withheld until the
              screen reconciles.
            </Text>
          </View>
          <ActionButton label="RECONCILE NOW" kind="secondary" onPress={onReconcile} />
        </View>
      ) : null}

      {alarms.length === 0 && cause === undefined ? (
        <Text style={styles.empty}>
          {stateFilter.length > 0
            ? 'No alarm matches this filter. That is a statement about the filter, not about the cell.'
            : 'No alarm has been raised for this cell inside the served window.'}
        </Text>
      ) : null}

      <View style={styles.alarmList}>
        {alarms.map((alarm) => (
          <AlarmRow
            key={alarm.alarmId}
            alarm={alarm}
            expanded={openAlarmId === alarm.alarmId}
            onToggle={() =>
              setOpenAlarmId((previous) => (previous === alarm.alarmId ? undefined : alarm.alarmId))
            }
            comment={comments[alarm.alarmId] ?? ''}
            onComment={(next) =>
              setComments((previous) => ({ ...previous, [alarm.alarmId]: next }))
            }
            attempted={attempted[alarm.alarmId] === true}
            onAcknowledge={() => void acknowledge(alarm)}
            pending={action.pending && actingAlarmId === alarm.alarmId}
            error={actingAlarmId === alarm.alarmId ? action.error : undefined}
            receipt={actingAlarmId === alarm.alarmId ? action.result : undefined}
            allowed={current}
          />
        ))}
      </View>
    </Panel>
  );
}

function AlarmRow({
  alarm,
  expanded,
  onToggle,
  comment,
  onComment,
  attempted,
  onAcknowledge,
  pending,
  error,
  receipt,
  allowed,
}: {
  alarm: AlarmRecord;
  expanded: boolean;
  onToggle: () => void;
  comment: string;
  onComment: (next: string) => void;
  attempted: boolean;
  onAcknowledge: () => void;
  pending: boolean;
  error: unknown;
  receipt: AlarmAcknowledgement | undefined;
  allowed: boolean;
}) {
  // Mirrors Alarm.Acknowledge: a terminal or already-acknowledged alarm has no
  // acknowledgement left to give, and saying so is more use than a dead control.
  const acknowledgeable =
    alarm.acknowledgedAt === null &&
    (alarm.state === 'Active' || alarm.state === 'ReturnedUnacknowledged');

  const validation =
    attempted && comment.trim().length === 0
      ? 'An acknowledgement comment is required. It is retained on the alarm record and in the audit chain.'
      : undefined;

  return (
    <View style={[styles.alarmRow, alarm.outstanding && styles.alarmRowOutstanding]}>
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ expanded }}
        accessibilityLabel={`${AlarmSemantics.noun} ${alarm.alarmCode}, ${describeAlarmPriority(alarm.priority)}, state ${alarm.state}`}
        onPress={onToggle}
        style={({ pressed }) => [styles.alarmHead, pressed && styles.chipPressed]}>
        <SemanticMark
          vocabulary={AlarmSemantics}
          suffix={describeAlarmPriority(alarm.priority).split(' ')[0]}
          tone={priorityTone(alarm.priority)}
        />
        <View style={styles.alarmCopy}>
          <Text style={styles.alarmCode}>{alarm.alarmCode}</Text>
          <Text style={styles.alarmSource} numberOfLines={1}>
            {describeAlarmPriority(alarm.priority)} · source {alarm.sourceId} · activated{' '}
            {instant(alarm.activatedAt)}
          </Text>
        </View>
        <View style={styles.alarmStates}>
          <StatusPill label={alarm.state.toUpperCase()} tone={stateTone(alarm.state)} />
          <Text style={styles.alarmExpand}>{expanded ? '▾ HIDE' : '▸ DETAIL'}</Text>
        </View>
      </Pressable>

      {/*
        Cause and acknowledgement are shown as two separate facts, always both, even
        when one is absent. Collapsing them into a single "handled" indicator is the
        confusion CH1-AUT-FDS-0001 and CH1-COL-FR-0003 exist to prevent.
      */}
      <View style={styles.alarmFacts}>
        <AlarmFact
          label="Cause"
          value={alarm.causeClear ? `Clear at ${instant(alarm.clearedAt)}` : 'STILL PRESENT'}
          tone={alarm.causeClear ? 'good' : 'danger'}
        />
        <AlarmFact
          label={AlarmSemantics.recordedVerb}
          value={
            alarm.acknowledgedAt === null
              ? 'Not acknowledged'
              : `${alarm.acknowledgedBy} at ${instant(alarm.acknowledgedAt)}`
          }
          tone={alarm.acknowledgedAt === null ? 'warning' : 'info'}
        />
        <AlarmFact
          label="Outstanding"
          value={alarm.outstanding ? 'YES' : 'No'}
          tone={alarm.outstanding ? 'warning' : 'good'}
        />
      </View>

      {expanded ? (
        <View style={styles.alarmDetail}>
          {/*
            An alarm names the cell it is on and the source that raised it, and both were
            inert text. CH1-UX-SCR-0016 asks for correlated software, resource and
            physical state; correlation an operator cannot follow is a claim rather than
            a capability.
          */}
          <ConnectedObjects
            items={[
              { kind: 'cell', id: alarm.cellId, caption: 'cell' },
              { kind: 'device', id: alarm.sourceId, caption: 'source' },
            ]}
          />

          <View style={styles.guidance}>
            <Text style={styles.guidanceTitle}>OPERATOR GUIDANCE</Text>
            <Text style={styles.guidanceText}>{alarm.guidance}</Text>
          </View>

          {alarm.acknowledgementComment !== null ? (
            <View style={styles.recordedComment}>
              <Text style={styles.recordedCommentTitle}>RECORDED ACKNOWLEDGEMENT COMMENT</Text>
              <Text style={styles.recordedCommentText} selectable>
                {alarm.acknowledgementComment}
              </Text>
            </View>
          ) : null}

          {acknowledgeable ? (
            <View style={styles.ackForm}>
              <TextField
                label={`Comment for ${alarm.alarmCode}`}
                value={comment}
                onChangeText={onComment}
                placeholder="What was observed, and what was done about it"
                hint={AlarmSemantics.disclaimer}
                error={validation}
                maxLength={COMMENT_LIMIT}
                multiline
                editable={allowed && !pending}
              />
              <View style={styles.ackActions}>
                <Text style={styles.ackNote}>
                  {allowed
                    ? 'Control Core evaluates authority: the assigned operator for this cell, or an Engineer.'
                    : 'Withheld while the screen is not current.'}
                </Text>
                <ActionButton
                  label={pending ? 'RECORDING…' : AlarmSemantics.actionVerb}
                  onPress={onAcknowledge}
                  disabled={!allowed || pending}
                />
              </View>
            </View>
          ) : (
            <Text style={styles.notAcknowledgeable}>
              {alarm.acknowledgedAt !== null
                ? `Already acknowledged by ${alarm.acknowledgedBy}. An alarm is acknowledged once; a second acknowledgement is refused rather than overwriting the first.`
                : 'This alarm is cleared and acknowledged. There is nothing left to acknowledge.'}
            </Text>
          )}

          {error !== undefined ? (
            <CapabilityNotice
              error={error}
              context={`POST /api/v1/alarms/${alarm.alarmId}/acknowledgements`}
            />
          ) : null}

          {receipt !== undefined ? <AcknowledgementReceipt receipt={receipt} /> : null}

          <View style={styles.threadLink}>
            <SemanticMark vocabulary={MessageSemantics} tone="info" />
            <Text style={styles.threadText}>
              Discussion of this alarm lives on its own thread. Posting there records a message and
              acknowledges nothing about the alarm.
            </Text>
            <ActionButton
              label="OPEN THREAD"
              kind="secondary"
              onPress={() =>
                router.push({
                  pathname: '/collaboration',
                  params: {
                    threadId: alarm.contextThreadId,
                    objectType: 'Alarm',
                    objectId: alarm.alarmId,
                    objectLabel: alarm.alarmCode,
                  },
                })
              }
            />
          </View>
        </View>
      ) : null}
    </View>
  );
}

/**
 * What the server said it did, and what it said it did not do. The control-side-effect
 * sentence is rendered verbatim rather than paraphrased: it is the server's own
 * statement of the guarantee, and a client rewording is exactly how the distinction
 * would drift.
 */
function AcknowledgementReceipt({ receipt }: { receipt: AlarmAcknowledgement }) {
  return (
    <View style={styles.receipt}>
      <Text style={styles.receiptTitle}>{AlarmSemantics.recordedVerb}</Text>
      <Text style={styles.receiptLine}>
        {receipt.acknowledgedBy} at {instant(receipt.acknowledgedAt)} · state now {receipt.state}
      </Text>
      <Text style={styles.receiptCause}>
        Cause {receipt.causeClear ? `clear at ${instant(receipt.clearedAt)}` : 'STILL PRESENT'} —
        unchanged by this acknowledgement.
      </Text>
      <Text style={styles.receiptEffect}>{receipt.controlSideEffect}</Text>
    </View>
  );
}

function AlarmFact({ label, value, tone }: { label: string; value: string; tone: StatusTone }) {
  const colour =
    tone === 'good'
      ? Palette.green
      : tone === 'danger'
        ? Palette.red
        : tone === 'warning'
          ? Palette.amber
          : Palette.cyan;
  return (
    <View style={styles.alarmFact}>
      <Text style={styles.alarmFactLabel}>{label}</Text>
      <Text style={[styles.alarmFactValue, { color: colour }]}>{value}</Text>
    </View>
  );
}

function Banner({ tone, title, body }: { tone: 'warning' | 'danger'; title: string; body: string }) {
  return (
    <View style={[styles.banner, tone === 'danger' && styles.bannerDanger]}>
      <Text style={[styles.bannerTitle, tone === 'danger' && styles.bannerTitleDanger]}>{title}</Text>
      <Text style={styles.bannerText}>{body}</Text>
    </View>
  );
}

/** Newest sample per channel, decided by the source's own observation time. */
function newestPerChannel(
  samples: readonly TelemetrySample[],
): ReadonlyMap<string, TelemetrySample> {
  const latest = new Map<string, TelemetrySample>();
  for (const sample of samples) {
    const held = latest.get(sample.channelId);
    if (held === undefined || Date.parse(sample.sampledAt) > Date.parse(held.sampledAt)) {
      latest.set(sample.channelId, sample);
    }
  }
  return latest;
}

function formatValue(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(2);
}

/** Priority 1 is the most urgent. Tone always accompanies the printed P-number. */
function priorityTone(priority: number): StatusTone {
  if (priority <= 2) return 'danger';
  if (priority === 3) return 'warning';
  return 'info';
}

function stateTone(state: AlarmState): StatusTone {
  switch (state) {
    case 'Active':
      return 'danger';
    case 'Acknowledged':
      return 'warning';
    case 'ReturnedUnacknowledged':
      return 'info';
    default:
      return 'good';
  }
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'stretch', marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  channelPanel: { flex: 1.5, minWidth: 0 },
  boundsPanel: { flex: 0.7, minWidth: 300 },
  selector: { marginBottom: Spacing.md, gap: 8 },
  selectorLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.9 },
  selectorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.pill, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.panel },
  chipActive: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  chipPressed: { opacity: 0.72 },
  chipText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  chipTextActive: { color: Palette.teal },
  channelGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  channelCard: { flex: 1, minWidth: 215, borderRadius: Radius.md, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.canvasRaised, padding: Spacing.md, gap: 6 },
  channelCardOutside: { borderColor: '#714046', backgroundColor: Palette.redSoft },
  channelHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6, flexWrap: 'wrap' },
  channelId: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9, fontWeight: '800', letterSpacing: 0.6 },
  channelNoReading: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  channelValue: { color: Palette.ink, fontFamily: Type.sans, fontSize: 22, fontWeight: '800' },
  channelValueOutside: { color: Palette.red },
  channelLimits: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  channelOutsideNote: { color: Palette.red, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  channelFooter: { flexDirection: 'row', justifyContent: 'space-between', gap: 6, flexWrap: 'wrap' },
  channelMeta: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  boundRow: { minHeight: 34, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Palette.line },
  boundLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10 },
  boundValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9, textAlign: 'right', flexShrink: 1 },
  boundValueWarning: { color: Palette.amber, fontWeight: '800' },
  boundsNote: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.cyan, paddingLeft: Spacing.md, gap: 5 },
  boundsNoteTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  boundsNoteText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap' },
  filterRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6, marginBottom: Spacing.md },
  filterLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.9, marginRight: 4 },
  staleBar: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap', backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, marginBottom: Spacing.md },
  staleCopy: { flex: 1, minWidth: 260, gap: 5 },
  staleTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.7 },
  staleText: { color: '#DBC49A', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 16 },
  alarmList: { gap: Spacing.sm },
  alarmRow: { borderRadius: Radius.md, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.canvasRaised, overflow: 'hidden' },
  alarmRowOutstanding: { borderColor: '#4A3520' },
  alarmHead: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, padding: Spacing.md, flexWrap: 'wrap' },
  alarmCopy: { flex: 1, minWidth: 200, gap: 3 },
  alarmCode: { color: Palette.ink, fontFamily: Type.mono, fontSize: 11, fontWeight: '800' },
  alarmSource: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  alarmStates: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  alarmExpand: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800' },
  alarmFacts: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.lg, paddingHorizontal: Spacing.md, paddingBottom: Spacing.md },
  alarmFact: { gap: 3, minWidth: 150 },
  alarmFactLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, fontWeight: '900', letterSpacing: 0.8 },
  alarmFactValue: { fontFamily: Type.sans, fontSize: 10, fontWeight: '700' },
  alarmDetail: { borderTopWidth: 1, borderTopColor: Palette.line, padding: Spacing.md, gap: Spacing.md, backgroundColor: '#08131F' },
  guidance: { borderLeftWidth: 3, borderLeftColor: Palette.violet, paddingLeft: Spacing.md, gap: 4 },
  guidanceTitle: { color: Palette.violet, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  guidanceText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  recordedComment: { borderRadius: Radius.md, backgroundColor: Palette.panel, borderWidth: 1, borderColor: Palette.line, padding: Spacing.md, gap: 4 },
  recordedCommentTitle: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, fontWeight: '900', letterSpacing: 0.8 },
  recordedCommentText: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  ackForm: { gap: Spacing.md },
  ackActions: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md, flexWrap: 'wrap' },
  ackNote: { flex: 1, minWidth: 220, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  notAcknowledgeable: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  receipt: { borderRadius: Radius.md, backgroundColor: Palette.greenSoft, borderWidth: 1, borderColor: '#2A6349', padding: Spacing.md, gap: 5 },
  receiptTitle: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10 },
  receiptCause: { color: Palette.amber, fontFamily: Type.sans, fontSize: 10, fontWeight: '700', lineHeight: 15 },
  receiptEffect: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  threadLink: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap', borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.md },
  threadText: { flex: 1, minWidth: 220, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  banner: { marginBottom: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', borderRadius: Radius.md, padding: Spacing.md, gap: 5 },
  bannerDanger: { backgroundColor: Palette.redSoft, borderColor: '#714046' },
  bannerTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  bannerTitleDanger: { color: Palette.red },
  bannerText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
});
