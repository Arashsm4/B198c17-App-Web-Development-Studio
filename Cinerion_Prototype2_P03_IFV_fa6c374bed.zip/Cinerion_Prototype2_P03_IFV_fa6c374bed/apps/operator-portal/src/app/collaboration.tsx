// @screen CH1-UX-SCR-0019 — Contextual collaboration: messages linked to controlled objects

import { useState } from 'react';
import { useLocalSearchParams } from 'expo-router';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import { CinerionApiError } from '@/api/client';
import type {
  CellState,
  ContextMessage,
  ContextObjectType,
  ContextThreadPage,
  ContextThreadSummary,
  Freshness,
  MessagePriority,
  MessageReadReceipt,
  PostedContextMessage,
} from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { isLinkCurrent } from '@/api/freshness';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import {
  ActionButton,
  Divider,
  Panel,
  SectionHeading,
  SemanticMark,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { AlarmSemantics, MessageSemantics } from '@/constants/semantics';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

const PRIORITIES: readonly MessagePriority[] = ['Routine', 'Elevated', 'Urgent'];

export default function CollaborationScreen() {
  return (
    <AppShell active="collaboration">
      <SessionGate>
        <Collaboration />
      </SessionGate>
    </AppShell>
  );
}

function Collaboration() {
  const session = useSession();
  const params = useLocalSearchParams<{
    threadId?: string;
    objectType?: string;
    objectId?: string;
    objectLabel?: string;
  }>();

  // With no thread named, the assigned cell's own thread is the one this identity
  // certainly has. The identifier is taken from the cell page rather than derived
  // here: deriving it a second time in the client would create a second definition of
  // thread identity that could disagree with the server's.
  const primaryCell = assignedCells(session.claims)[0];
  const cell = useObserved<CellState>(
    params.threadId === undefined && primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );

  const threadId = params.threadId ?? cell.value?.contextThreadId;
  const objectType = (params.objectType as ContextObjectType | undefined) ?? 'Cell';
  const objectId = params.objectId ?? cell.value?.cellId;
  const objectLabel = params.objectLabel ?? cell.value?.cellId;

  const thread = useObserved<ContextThreadPage>(
    threadId ? `/api/v1/context-threads/${threadId}/messages` : undefined,
    session.accessToken,
  );

  return (
    <>
      <PageIntro
        eyebrow="CH1-UX-SCR-0019 / ContextBridge"
        title="Contextual collaboration"
        description="Conversation attached to one controlled object. A message carries its author, origin, priority, delivery and read state — and no control authority whatever. Reading one acknowledges no alarm, clears no fault and confirms no command."
        aside={<SeparationBadge />}
      />

      <ThreadHeader
        threadId={threadId}
        objectType={objectType}
        objectLabel={objectLabel}
        thread={thread.value?.thread}
        derivedFromCell={params.threadId === undefined}
      />

      {threadId === undefined ? (
        <NoThreadSelected hasCell={primaryCell !== undefined} error={cell.error} />
      ) : (
        <ThreadView
          threadId={threadId}
          objectType={objectType}
          objectId={objectId}
          page={thread.value}
          cause={thread.cause}
          freshness={thread.freshness}
          accessToken={session.accessToken}
          selfId={session.claims?.sub}
          onReconcile={thread.refresh}
        />
      )}
    </>
  );
}

/**
 * States the distinction on the page itself, with both marks side by side. A user who
 * arrives here from an alarm should be able to see at a glance that they have moved to
 * a different kind of record with a different verb.
 */
function SeparationBadge() {
  return (
    <View style={styles.separation}>
      <View style={styles.separationRow}>
        <SemanticMark vocabulary={AlarmSemantics} tone="danger" />
        <Text style={styles.separationVerb}>{AlarmSemantics.actionVerb}</Text>
      </View>
      <View style={styles.separationRow}>
        <SemanticMark vocabulary={MessageSemantics} tone="info" />
        <Text style={styles.separationVerb}>{MessageSemantics.actionVerb}</Text>
      </View>
      <Text style={styles.separationNote}>Different records. Different verbs.</Text>
    </View>
  );
}

function ThreadHeader({
  threadId,
  objectType,
  objectLabel,
  thread,
  derivedFromCell,
}: {
  threadId: string | undefined;
  objectType: ContextObjectType;
  objectLabel: string | undefined;
  thread: ContextThreadSummary | undefined;
  derivedFromCell: boolean;
}) {
  return (
    <Panel style={styles.headerPanel}>
      <View style={styles.headerTop}>
        <View style={styles.headerCopy}>
          <Text style={styles.headerEyebrow}>
            THREAD ON {objectType.toUpperCase()}
            {derivedFromCell ? ' · DERIVED FROM YOUR ASSIGNED CELL' : ''}
          </Text>
          <Text style={styles.headerObject} selectable>
            {objectLabel ?? 'No object in scope'}
          </Text>
          <Text style={styles.headerThread} selectable>
            {threadId ?? 'No thread identifier'}
          </Text>
        </View>
        <View style={styles.headerFacts}>
          <HeaderFact label="Opened by" value={thread?.createdBy ?? '—'} />
          <HeaderFact label="Opened at" value={instant(thread?.createdAt)} />
          <HeaderFact
            label="Access scope"
            value={
              thread === undefined
                ? '—'
                : thread.accessScope.roles.length + thread.accessScope.actorIds.length === 0
                  ? 'Project scope'
                  : [...thread.accessScope.roles, ...thread.accessScope.actorIds].join(', ')
            }
          />
        </View>
      </View>
      <Divider />
      <Text style={styles.headerNote}>
        A thread identifier is derived from the object it belongs to, never chosen. There is one
        thread per object, and the P03 catalogue contains no operation that creates one — object
        pages carry the identifier, which is how this screen was reached.
      </Text>
    </Panel>
  );
}

function HeaderFact({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.headerFact}>
      <Text style={styles.headerFactLabel}>{label}</Text>
      <Text style={styles.headerFactValue} numberOfLines={2}>
        {value}
      </Text>
    </View>
  );
}

function NoThreadSelected({ hasCell, error }: { hasCell: boolean; error: string | undefined }) {
  return (
    <Panel>
      <SectionHeading eyebrow="No object in scope" title="Nothing to discuss yet" />
      <Text style={styles.empty}>
        {hasCell
          ? 'The assigned cell has not been retrieved, so its thread identifier is not known yet.'
          : 'This identity carries no ch1_cell scope, and no object was named. Open a thread from the object it belongs to — an alarm in the control room, or a cell on the operations view.'}
      </Text>
      {error ? <CapabilityNotice error={new Error(error)} context="GET /api/v1/cells/{cellId}/state" /> : null}
    </Panel>
  );
}

function ThreadView({
  threadId,
  objectType,
  objectId,
  page,
  cause,
  freshness,
  accessToken,
  selfId,
  onReconcile,
}: {
  threadId: string;
  objectType: ContextObjectType;
  objectId: string | undefined;
  page: ContextThreadPage | undefined;
  cause: unknown;
  freshness: Freshness;
  accessToken: string | undefined;
  selfId: string | undefined;
  onReconcile: () => void;
}) {
  const { width } = useWindowDimensions();
  const compact = width < 1100;
  const [body, setBody] = useState('');
  const [priority, setPriority] = useState<MessagePriority>('Routine');
  const [attempted, setAttempted] = useState(false);
  const [receiptFor, setReceiptFor] = useState<string | undefined>(undefined);

  const post = useControlledAction<PostedContextMessage>(accessToken);
  const receipt = useControlledAction<MessageReadReceipt>(accessToken);

  // A thread carries no server-declared freshness — there is nothing about a stored
  // conversation to be stale in the way a sampled reading is — so the gate on
  // recording a receipt is whether this client is still in touch, not whether the
  // reading is Live. Asking for Live here would disable the control permanently.
  const current = isLinkCurrent(freshness) && page !== undefined;
  const bodyLimit = page?.bounds.maximumBodyLength ?? 10_000;
  const messages = page?.items ?? [];

  /**
   * A thread exists only once its first message is posted — the P03 catalogue has no
   * operation that creates one — so a 404 on an object nobody has written about yet is
   * the ordinary empty state, not a failure. Reporting it as one would tell an operator
   * something is broken when the honest answer is that the conversation has not started.
   * Any other refusal is still shown as a refusal.
   */
  const notStarted = cause instanceof CinerionApiError && cause.isNotVisible;
  const refusal = notStarted ? undefined : cause;

  const send = async () => {
    setAttempted(true);
    const trimmed = body.trim();
    if (trimmed.length === 0 || trimmed.length > bodyLimit) return;

    const posted = await post.submit(`/api/v1/context-threads/${threadId}/messages`, {
      body: trimmed,
      priority,
      // Sent so the server can check the identifier against the object it derives
      // from. A thread that does not exist yet is opened by its first message.
      objectType,
      objectId,
    });
    if (posted) {
      // Cleared only on a success this screen saw; a refusal leaves the draft intact.
      setBody('');
      setAttempted(false);
      onReconcile();
    }
  };

  const markRead = async (message: ContextMessage) => {
    setReceiptFor(message.messageId);
    const recorded = await receipt.submit(
      `/api/v1/context-messages/${message.messageId}/acknowledgements`,
    );
    if (recorded) onReconcile();
  };

  return (
    <View style={[styles.grid, compact && styles.stacked]}>
      <Panel style={styles.messagePanel}>
        <SectionHeading
          eyebrow="CH1-COL-FR-0001 / CH1-COL-FR-0002"
          title="Messages"
          action={
            <View style={styles.headerActions}>
              {/*
                A thread that does not exist yet has no currency to report, and the
                hook's Disconnected — correct for a failed read — would read as a lost
                link rather than as an unstarted conversation.
              */}
              {notStarted ? (
                <StatusPill label="NOT STARTED" tone="neutral" />
              ) : (
                <FreshnessTag freshness={freshness} />
              )}
              <StatusPill
                label={`${messages.length} ON THIS THREAD`}
                tone={messages.length > 0 ? 'info' : 'neutral'}
              />
            </View>
          }
        />

        {refusal !== undefined ? (
          <CapabilityNotice
            error={refusal}
            context={`GET /api/v1/context-threads/${threadId}/messages`}
          />
        ) : null}

        {messages.length === 0 && refusal === undefined ? (
          <Text style={styles.empty}>
            {notStarted
              ? 'No conversation has been started about this object. A thread comes into existence with its first message, so posting below opens it.'
              : 'No message has been posted against this object. An empty thread is not a statement that nothing happened — controlled decisions live in their own records, not here.'}
          </Text>
        ) : null}

        <View style={styles.messageList}>
          {messages.map((message) => (
            <MessageRow
              key={message.messageId}
              message={message}
              selfId={selfId}
              allowed={current}
              pending={receipt.pending && receiptFor === message.messageId}
              error={receiptFor === message.messageId ? receipt.error : undefined}
              recorded={receiptFor === message.messageId ? receipt.result : undefined}
              onMarkRead={() => void markRead(message)}
            />
          ))}
        </View>

        {page?.nextCursor ? (
          <Text style={styles.moreNote}>
            More messages exist on this thread beyond the page shown.
          </Text>
        ) : null}
      </Panel>

      <View style={styles.sideColumn}>
        <Panel>
          <SectionHeading
            eyebrow="No control authority"
            title={`Post a ${MessageSemantics.noun.toLowerCase()}`}
          />
          <TextField
            label="Message"
            value={body}
            onChangeText={setBody}
            placeholder="Context, observation or hand-over note for this object"
            hint={`Retained as ${page?.retention.message ?? 'the declared policy'}. Not a controlled engineering decision.`}
            error={
              attempted && body.trim().length === 0
                ? 'A message body is required.'
                : undefined
            }
            maxLength={bodyLimit}
            multiline
            editable={!post.pending}
          />

          <View style={styles.priorityRow}>
            <Text style={styles.priorityLabel}>PRIORITY</Text>
            {PRIORITIES.map((option) => {
              const active = option === priority;
              return (
                <Pressable
                  key={option}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                  accessibilityLabel={`Message priority ${option}`}
                  onPress={() => setPriority(option)}
                  style={({ pressed }) => [
                    styles.chip,
                    active && styles.chipActive,
                    pressed && styles.chipPressed,
                  ]}>
                  <Text style={[styles.chipText, active && styles.chipTextActive]}>
                    {active ? '✓ ' : ''}
                    {option}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <Text style={styles.authorNote}>
            The author is the authenticated identity. There is no field for it, and no way to add
            one: a client-supplied author is exactly the control this operation exists to keep.
          </Text>

          <View style={styles.postActions}>
            <ActionButton
              label={post.pending ? 'POSTING…' : 'POST MESSAGE'}
              onPress={() => void send()}
              disabled={post.pending}
            />
          </View>

          {post.error !== undefined ? (
            <CapabilityNotice
              error={post.error}
              context={`POST /api/v1/context-threads/${threadId}/messages`}
            />
          ) : null}
        </Panel>

        <RetentionPanel page={page} />
      </View>
    </View>
  );
}

function MessageRow({
  message,
  selfId,
  allowed,
  pending,
  error,
  recorded,
  onMarkRead,
}: {
  message: ContextMessage;
  selfId: string | undefined;
  allowed: boolean;
  pending: boolean;
  error: unknown;
  recorded: MessageReadReceipt | undefined;
  onMarkRead: () => void;
}) {
  const authoredBySelf = selfId !== undefined && message.authorId === selfId;
  const alreadyRead =
    selfId !== undefined && message.readBy.some((entry) => entry.recipientId === selfId);

  return (
    <View style={styles.messageRow}>
      <View style={styles.messageHead}>
        <SemanticMark vocabulary={MessageSemantics} tone={priorityTone(message.priority)} />
        <View style={styles.messageWho}>
          <Text style={styles.messageAuthor}>{message.authorId}</Text>
          <Text style={styles.messageMeta}>
            {message.authorKind} · {message.priority} · {instant(message.createdAt)} ·{' '}
            {message.deliveryState}
          </Text>
        </View>
        <Text style={styles.messageId} selectable>
          {shortId(message.messageId)}
        </Text>
      </View>

      <Text style={styles.messageBody} selectable>
        {message.body}
      </Text>

      <View style={styles.messageFooter}>
        <View style={styles.readList}>
          {message.readBy.length === 0 ? (
            <Text style={styles.readNone}>No receipt recorded</Text>
          ) : (
            message.readBy.map((entry) => (
              <Text key={entry.recipientId} style={styles.readEntry}>
                {/* The verb comes from the server's own field, not from a label here. */}
                {entry.kind.toUpperCase()} · {entry.recipientId} · {instant(entry.acknowledgedAt)}
              </Text>
            ))
          )}
        </View>

        {authoredBySelf ? (
          <Text style={styles.readNote}>
            You wrote this. An author cannot receipt their own message.
          </Text>
        ) : alreadyRead ? (
          <StatusPill label={`${MessageSemantics.recordedVerb} BY YOU`} tone="good" />
        ) : (
          <ActionButton
            label={pending ? 'RECORDING…' : MessageSemantics.actionVerb}
            kind="secondary"
            onPress={onMarkRead}
            disabled={!allowed || pending}
          />
        )}
      </View>

      {error !== undefined ? (
        <CapabilityNotice
          error={error}
          context={`POST /api/v1/context-messages/${message.messageId}/acknowledgements`}
        />
      ) : null}

      {recorded !== undefined ? <ReadReceipt recorded={recorded} /> : null}
    </View>
  );
}

/**
 * The receipt as the server described it. `kind` and `controlSideEffect` are printed
 * verbatim: they are the server's statement that this was a read and nothing else, and
 * a client paraphrase is precisely how the alarm/message distinction would erode.
 */
// Exported so `npm run render:portal` can render it directly: recording a receipt
// through the screen needs a second identity, because an author cannot receipt their
// own message. The export is of a pure presentational component and grants nothing.
export function ReadReceipt({ recorded }: { recorded: MessageReadReceipt }) {
  return (
    <View style={styles.receipt}>
      <Text style={styles.receiptTitle}>RECEIPT KIND: {recorded.kind.toUpperCase()}</Text>
      <Text style={styles.receiptLine}>
        {recorded.recipientId} at {instant(recorded.acknowledgedAt)} · control authority{' '}
        {String(recorded.controlAuthority)}
      </Text>
      <Text style={styles.receiptEffect}>{recorded.controlSideEffect}</Text>
      <Text style={styles.receiptObject}>
        Thread object: {recorded.threadObject.type} {shortId(recorded.threadObject.id)}
      </Text>
    </View>
  );
}

function RetentionPanel({ page }: { page: ContextThreadPage | undefined }) {
  return (
    <Panel>
      <SectionHeading eyebrow="CH1-DBA-DD-0001" title="Retention and standing" />
      <RetentionRow label="Message" value={page?.retention.message ?? '—'} />
      <RetentionRow label="Receipt" value={page?.retention.acknowledgement ?? '—'} />
      <View style={styles.standing}>
        <Text style={styles.standingTitle}>WHAT THIS RECORD IS NOT</Text>
        <Text style={styles.standingText}>
          {page?.retention.standing ??
            'A contextual message is communication, not a controlled engineering decision.'}
        </Text>
        <Text style={styles.standingText}>{page?.retention.disposal ?? ''}</Text>
      </View>
      <View style={styles.deliveryNote}>
        <Text style={styles.deliveryTitle}>STORED AND READABLE, NOT PUSHED</Text>
        <Text style={styles.deliveryText}>
          Delivery state has one honest value. Per-recipient distribution belongs to the event
          backbone, which is not enabled, so nothing here claims a message reached anyone.
        </Text>
      </View>
    </Panel>
  );
}

function RetentionRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.retentionRow}>
      <Text style={styles.retentionLabel}>{label}</Text>
      <Text style={styles.retentionValue}>{value}</Text>
    </View>
  );
}

function priorityTone(priority: MessagePriority): StatusTone {
  switch (priority) {
    case 'Urgent':
      return 'warning';
    case 'Elevated':
      return 'info';
    default:
      return 'neutral';
  }
}

const styles = StyleSheet.create({
  separation: { alignItems: 'flex-end', gap: 6 },
  separationRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  separationVerb: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800' },
  separationNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  headerPanel: { marginBottom: Spacing.md, gap: Spacing.md },
  headerTop: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: Spacing.xl },
  headerCopy: { gap: 5, flexShrink: 1 },
  headerEyebrow: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.9 },
  headerObject: { color: Palette.ink, fontFamily: Type.mono, fontSize: 15, fontWeight: '800' },
  headerThread: { color: Palette.violet, fontFamily: Type.mono, fontSize: 9 },
  headerFacts: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl },
  headerFact: { gap: 3, maxWidth: 230 },
  headerFactLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, fontWeight: '900', letterSpacing: 0.8 },
  headerFactValue: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10 },
  headerNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start' },
  stacked: { flexDirection: 'column' },
  messagePanel: { flex: 1.3, minWidth: 0 },
  sideColumn: { flex: 0.8, minWidth: 330, gap: Spacing.md },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap' },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 16 },
  messageList: { gap: Spacing.sm },
  messageRow: { borderRadius: Radius.md, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.canvasRaised, padding: Spacing.md, gap: Spacing.sm },
  messageHead: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap' },
  messageWho: { flex: 1, minWidth: 180, gap: 2 },
  messageAuthor: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11, fontWeight: '800' },
  messageMeta: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  messageId: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  messageBody: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  messageFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md, flexWrap: 'wrap', borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.sm },
  readList: { flex: 1, minWidth: 200, gap: 3 },
  readNone: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  readEntry: { color: Palette.green, fontFamily: Type.mono, fontSize: 8 },
  readNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, maxWidth: 240, textAlign: 'right' },
  moreNote: { marginTop: Spacing.md, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  priorityRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6, marginTop: Spacing.md },
  priorityLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.9, marginRight: 4 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.pill, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.panel },
  chipActive: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  chipPressed: { opacity: 0.72 },
  chipText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  chipTextActive: { color: Palette.teal },
  authorNote: { marginTop: Spacing.md, color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  postActions: { marginTop: Spacing.md, flexDirection: 'row', justifyContent: 'flex-end' },
  receipt: { borderRadius: Radius.md, backgroundColor: '#0A222C', borderWidth: 1, borderColor: '#1B4D58', padding: Spacing.md, gap: 4 },
  receiptTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10 },
  receiptEffect: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  receiptObject: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  retentionRow: { minHeight: 34, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Palette.line },
  retentionLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10 },
  retentionValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  standing: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.amber, paddingLeft: Spacing.md, gap: 5 },
  standingTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  standingText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  deliveryNote: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.cyan, paddingLeft: Spacing.md, gap: 5 },
  deliveryTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  deliveryText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});
