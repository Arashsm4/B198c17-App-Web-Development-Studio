// @screen CH1-UX-SCR-0020 — R&D workbench: isolated experiments, versions, evidence and comparison

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { ExperimentPage, ExperimentSummary } from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useObserved } from '@/api/use-observed';
import { owns } from '@/api/capabilities';
import { useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { KpiCard, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { ControlledActionForm, StepUpPurpose } from '@/components/controlled-action-form';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0020 — R&D workbench.
 *
 * screens.json declares this for the R&D Engineer and Engineer: "isolated experiments,
 * simulation, versions, evidence and comparison".
 *
 * THE ISOLATION IS THE SUBJECT, not a caveat on it. CH1-RND-FR-0001 keeps R&D apart from
 * controlled production, and a workbench that did not say which side of that line each
 * record sat on would be the place the separation quietly stopped meaning anything. Every
 * row carries `productionAuthority`, and the page carries the statement the service sends
 * with it — rendered rather than paraphrased, so a change of policy reaches the screen
 * instead of being contradicted by it.
 *
 * SIMULATION IS RECORDED, NOT RUN. CH1-COM-IF-0020 puts the simulators behind a provider
 * interface that is not enabled, so a run is a recording with full provenance and this
 * screen says so rather than offering a control that would execute nothing.
 */
export default function ResearchScreen() {
  return (
    <AppShell active="research">
      <SessionGate>
        <Workbench />
      </SessionGate>
    </AppShell>
  );
}

function statusTone(experiment: ExperimentSummary): StatusTone {
  if (experiment.productionAuthority) return 'danger';
  if (experiment.promotionRequested) return 'warning';
  return 'info';
}

function Workbench() {
  const { width } = useWindowDimensions();
  const narrow = width < 1080;
  const session = useSession();
  const roles = session.claims?.roles ?? [];

  const canRead =
    roles.includes('RDEngineer') ||
    roles.includes('Engineer') ||
    roles.includes('Auditor') ||
    roles.includes('ProjectManager') ||
    roles.includes('ConfigurationManager');

  // Defining an experiment is an R&D act. The server evaluates the authority again and
  // refuses what this does not catch; this only decides whether offering the control is
  // honest, because a form that every attempt would refuse is a form that wastes an
  // operator's time rather than one that protects anything.
  // Who owns this act is decided in one place now: the capability register, reconciled
  // against api_endpoints.json and the controlled-authority register by
  // `npm run capabilities`. This screen no longer spells the authority itself.
  const canDefine = owns('createExperiment', roles);

  const experiments = useObserved<ExperimentPage>(
    canRead ? '/api/v1/experiments' : undefined,
    session.accessToken,
  );

  const items = experiments.value?.items ?? [];
  const awaitingReview = items.filter((item) => item.promotionRequested).length;
  const withAuthority = items.filter((item) => item.productionAuthority).length;

  return (
    <>
      <PageIntro
        eyebrow="ResearchBench / CH1-RND-FR-0001"
        title="R&D workbench"
        description="An experiment starts isolated and holds no production authority. Promotion is a governed transition, not a state an experiment can drift into."
        aside={<FreshnessTag freshness={experiments.freshness} quality={experiments.quality} />}
      />

      {!canRead ? (
        <Panel>
          <SectionHeading eyebrow="Withheld" title="The workbench is not shown to this identity" />
          <Text style={styles.blocked}>
            Experiments are read by the R&amp;D Engineer, the Engineer, the Auditor, the Project Manager and
            the Configuration Manager. This session holds none of them. WITHHELD, not empty.
          </Text>
        </Panel>
      ) : (
        <>
          <View style={[styles.kpis, narrow && styles.stacked]}>
            <KpiCard label="Experiments" value={`${items.length}`} note="In this project" tone="info" />
            <KpiCard
              label="Promotion requested"
              value={`${awaitingReview}`}
              note="Awaiting review in configuration control"
              tone={awaitingReview === 0 ? 'info' : 'warning'}
            />
            <KpiCard
              label="Holding production authority"
              value={`${withAuthority}`}
              note={withAuthority === 0 ? 'None, which is the isolated state' : 'Investigate: no operation grants this'}
              tone={withAuthority === 0 ? 'good' : 'danger'}
            />
          </View>

          <Panel style={styles.isolation}>
            <SectionHeading eyebrow="CH1-RND-FR-0001" title="What isolation means here" />
            <Text style={styles.isolationText}>
              {experiments.value?.isolationStatement ??
                'The isolation statement is sent by Control Core with the register and has not been received yet.'}
            </Text>
            <Text style={styles.blocked}>
              Runs are recorded, not executed. CH1-COM-IF-0020 puts the simulators behind a provider interface
              this deployment does not enable, so a run carries its configuration, inputs, outputs and
              checksums and claims no computation. A control that offered to execute one would be offering
              something nothing performs.
            </Text>
          </Panel>

          <Panel>
            <SectionHeading
              eyebrow="GET /api/v1/experiments"
              title="Experiments and their isolation state"
              action={<StatusPill label={canDefine ? 'DEFINE · RECORD · PROMOTE' : 'READ ONLY'} tone="info" />}
            />

            {canDefine ? (
              <ControlledActionForm
                label="DEFINE AN EXPERIMENT"
                title="define a bounded experiment"
                description="An experiment starts ISOLATED and holds no production authority. Nothing here can grant it one: the register has no operation that does, and promotion is a governed transition reviewed in configuration control."
                accessToken={session.accessToken}
                endpoint="/api/v1/experiments"
                fields={[
                  {
                    name: 'objective',
                    label: 'Objective',
                    multiline: true,
                    hint: 'What the experiment is for. Retained with every run recorded against it.',
                  },
                ]}
                onDone={experiments.refresh}
              />
            ) : null}

            {experiments.error !== undefined ? (
              <CapabilityNotice error={experiments.cause ?? experiments.error} context="GET /api/v1/experiments" />
            ) : items.length === 0 ? (
              <Text style={styles.empty}>
                No experiment is recorded in this project. This identity may read the register, so this is an
                empty workbench rather than a withheld one.
              </Text>
            ) : (
              <View>
                {items.map((experiment) => (
                  <View key={experiment.experimentId} style={styles.experimentBlock}>
                    <View style={[styles.row, narrow && styles.rowStacked]}>
                    <View style={styles.identity}>
                      <Text style={styles.objective} numberOfLines={2}>
                        {experiment.objective}
                      </Text>
                      <Text style={styles.owner}>
                        {shortId(experiment.experimentId)} · {experiment.ownerId}
                      </Text>
                    </View>
                    <View style={styles.cell}>
                      <Text style={styles.cellLabel}>Environment</Text>
                      <Text style={styles.cellValue}>{experiment.environment}</Text>
                    </View>
                    <View style={styles.cell}>
                      <Text style={styles.cellLabel}>Defined</Text>
                      <Text style={styles.cellValue}>{instant(experiment.createdAt)}</Text>
                    </View>
                    <View style={styles.statusCell}>
                      <StatusPill label={experiment.status.toUpperCase()} tone={statusTone(experiment)} />
                      <StatusPill
                        label={experiment.productionAuthority ? 'PRODUCTION AUTHORITY' : 'NO PRODUCTION AUTHORITY'}
                        tone={experiment.productionAuthority ? 'danger' : 'good'}
                      />
                    </View>
                    </View>

                    {canDefine ? (
                      <View style={styles.experimentActions}>
                        <ControlledActionForm
                          label="RECORD A RUN"
                          title={`record a run of ${shortId(experiment.experimentId)}`}
                          description="A run is RECORDED, not executed. CH1-COM-IF-0020 puts the simulators behind a provider interface this deployment does not enable, so what is stored is the configuration, the inputs, their checksums and the result someone else computed. Nothing here claims a computation."
                          accessToken={session.accessToken}
                          endpoint={`/api/v1/experiments/${experiment.experimentId}/runs`}
                          fields={[
                            { name: 'configurationReference', label: 'Configuration reference' },
                            { name: 'configurationSha256', label: 'Configuration SHA-256', hint: 'The checksum of the configuration as it was used.' },
                            { name: 'modelReference', label: 'Model reference' },
                            { name: 'inputReference', label: 'Input reference' },
                            { name: 'inputSha256', label: 'Input SHA-256' },
                            { name: 'resultSummary', label: 'Result summary', multiline: true },
                          ]}
                          onDone={experiments.refresh}
                        />

                        {experiment.promotionRequested ? null : (
                          <ControlledActionForm
                            label="REQUEST PROMOTION"
                            title={`request promotion of ${shortId(experiment.experimentId)}`}
                            description="An outbound REQUEST, not a grant. CH1-RND-FR-0003 requires an approved change record, an impact assessment and verification to travel with it, and the approval itself happens in configuration control — nothing here can give an experiment production authority."
                            consequence="A promotion request is recorded against the experiment and reviewed in configuration control. It grants nothing on its own."
                            accessToken={session.accessToken}
                            endpoint={`/api/v1/experiments/${experiment.experimentId}/promotion-requests`}
                            stepUpPurpose={StepUpPurpose.ConfigurationPromotion}
                            fields={[
                              { name: 'changeRecord', label: 'Approved change record' },
                              { name: 'impactAnalysis', label: 'Impact assessment', multiline: true },
                              { name: 'verification', label: 'Verification', multiline: true },
                            ]}
                            onDone={experiments.refresh}
                          />
                        )}
                      </View>
                    ) : null}
                  </View>
                ))}
              </View>
            )}
          </Panel>
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  experimentBlock: { borderBottomWidth: 1, borderBottomColor: Palette.line },
  experimentActions: { paddingBottom: Spacing.md },
  kpis: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  stacked: { flexDirection: 'column' },
  isolation: { marginBottom: Spacing.md },
  isolationText: {
    marginTop: Spacing.sm,
    borderRadius: Radius.md,
    borderLeftWidth: 3,
    borderLeftColor: Palette.violet,
    backgroundColor: '#18182A',
    padding: Spacing.md,
    color: Palette.inkSoft,
    fontFamily: Type.sans,
    fontSize: 9,
    lineHeight: 14,
  },
  row: {
    minHeight: 62,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Palette.line,
  },
  rowStacked: { flexDirection: 'column', alignItems: 'flex-start', paddingVertical: Spacing.md, gap: Spacing.sm },
  identity: { flex: 1.8, minWidth: 0, gap: 3 },
  objective: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  owner: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  cell: { flex: 1, minWidth: 0, gap: 3 },
  cellLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  cellValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  statusCell: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center', flexWrap: 'wrap' },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, paddingVertical: Spacing.lg, lineHeight: 14 },
  blocked: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 15, paddingTop: Spacing.sm },
});
