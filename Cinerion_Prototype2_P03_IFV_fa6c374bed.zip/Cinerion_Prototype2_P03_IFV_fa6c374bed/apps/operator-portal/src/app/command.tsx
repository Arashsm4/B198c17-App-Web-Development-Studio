// @screen CH1-UX-SCR-0008 — Pending local confirmation: prepared command status, no remote start

import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import { useState } from 'react';

import type { CellState, CommandTransaction } from '@/api/contracts';
import {
  PERMISSIVES_NOT_ANSWERED_EXPLANATION,
  deferredCheckSummary,
  permissiveSummary,
  permissivesAnswered,
} from '@/api/permissives';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { PrepareCommandForm, PreparedCommand } from '@/components/prepare-command';
import { Divider, KeyValue, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

export default function CommandScreen() {
  return (
    <AppShell active="command">
      <SessionGate>
        <Command />
      </SessionGate>
    </AppShell>
  );
}

function Command() {
  const { width } = useWindowDimensions();
  const compact = width < 1120;
  const session = useSession();
  const primaryCell = assignedCells(session.claims)[0];
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
    (value) => value.quality,
  );
  const target = cell.value;
  // The transaction this session last prepared. Held here rather than fetched, because
  // the portal has no list operation for commands and inventing one would be inventing a
  // read authority; what it legitimately knows is what it itself just did.
  const [prepared, setPrepared] = useState<CommandTransaction | undefined>(undefined);

  return (
    <>
      <PageIntro
        eyebrow="CommandGuard / explicit authority separation"
        title="Guarded command centre"
        description="A prepared procedure is bound to one cell, one expected state and a short expiry. Preparation never starts equipment; the local controller remains the only owner of credential proof, button edge, final permissive sampling and commit."
        aside={
          <StatusPill
            label={prepared ? `PREPARED · ${prepared.state.toUpperCase()}` : 'NO PREPARED COMMAND'}
            tone={prepared ? 'info' : 'neutral'}
          />
        }
      />

      <View style={[styles.grid, compact && styles.stacked]}>
        <Panel style={styles.formPanel}>
          <SectionHeading
            eyebrow="Target binding"
            title="What a preparation would be bound to"
            action={<FreshnessTag freshness={cell.freshness} quality={cell.quality} />}
          />
          <View style={styles.formSection}>
            <View style={styles.twoColumns}>
              <KeyValue label="Target cell" value={target?.cellId ?? '—'} mono />
              <KeyValue label="Target asset" value={target?.assetId ?? '—'} mono />
            </View>
            <View style={styles.twoColumns}>
              <KeyValue label="Site" value={target?.siteId ?? '—'} mono />
              <KeyValue label="Controller" value={target?.controllerId ?? '—'} mono />
            </View>
            <View style={styles.twoColumns}>
              <KeyValue label="Work order" value={target?.workOrderId ?? '—'} mono />
              <KeyValue label="Physical part" value={target?.partId ?? '—'} mono />
            </View>
            <KeyValue label="Configuration revision" value={target?.configurationRevision ?? '—'} mono />
          </View>
          <Divider />
          <View style={styles.stateBinding}>
            <Text style={styles.blockLabel}>EXPECTED STATE BINDING</Text>
            <View style={styles.hashBox}>
              <Text style={styles.hashLabel}>SHA-256</Text>
              <Text style={styles.hashText} selectable>
                {target?.stateHash ?? 'No cell state retrieved'}
              </Text>
            </View>
            <Text style={styles.hint}>
              This hash is the cell state Control Core currently reports. A preparation binds to it,
              and is cancelled if the controller boot, configuration, work order, part or material
              cell state changes.
            </Text>
          </View>

          <Divider />
          <PrepareCommandForm
            cell={target}
            projectId={session.claims?.ch1_project}
            accessToken={session.accessToken}
            onPrepared={setPrepared}
          />

          {prepared ? (
            <>
              <Divider />
              <PreparedCommand
                command={prepared}
                accessToken={session.accessToken}
                onCancelled={() => setPrepared(undefined)}
              />
            </>
          ) : null}
        </Panel>

        <View style={styles.sideColumn}>
          <AuthoritySequence />
          <Panel>
            <SectionHeading eyebrow="Policy inputs" title="What this session actually presents" />
            <PolicyRow label="Identity" value={session.claims?.preferred_username ?? session.claims?.sub ?? '—'} />
            <PolicyRow label="Roles granted" value={(session.claims?.roles ?? []).join(', ') || 'None'} />
            <PolicyRow label="Project scope" value={session.claims?.ch1_project ?? '—'} />
            <PolicyRow label="Cell assignments" value={String(assignedCells(session.claims).length)} />
            <PolicyRow
              label="Preliminary permissives"
              value={target ? permissiveSummary(target) : 'No reading'}
            />
            {target && !permissivesAnswered(target) ? (
              <View style={styles.unansweredNotice}>
                <Text style={styles.unansweredCode}>PERMISSIVES NOT ANSWERED</Text>
                <Text style={styles.unansweredText}>{PERMISSIVES_NOT_ANSWERED_EXPLANATION}</Text>
                {deferredCheckSummary(target) ? (
                  <Text style={styles.unansweredCodes}>{deferredCheckSummary(target)}</Text>
                ) : null}
              </View>
            ) : null}
            <View style={styles.policyFootnote}>
              <Text style={styles.policyFootnoteTitle}>THESE ARE INPUTS, NOT A DECISION</Text>
              <Text style={styles.policyFootnoteText}>
                Authorisation is evaluated by Control Core when a preparation is requested, against
                role, project and cell scope, authentication strength, session recency and equipment
                state. Nothing shown here grants authority, and the portal does not pre-judge the
                outcome.
              </Text>
            </View>
          </Panel>
        </View>
      </View>
    </>
  );
}



/**
 * The authority sequence is documentation of the required order, not a progress
 * indicator. No stage is ever marked active from portal state: only the controller
 * can report progress, and inventing it here would be exactly the false claim of
 * physical execution the architecture forbids.
 */
function AuthoritySequence() {
  const stages = [
    { code: '01', title: 'Server policy and expected state', detail: 'Control Core evaluates scope, revision, expiry and preliminary permissives' },
    { code: '02', title: 'Cryptographic local credential', detail: 'Proven at the cell reader, bound to one transaction' },
    { code: '03', title: 'New physical button edge', detail: 'Observed by conditioned local DI only' },
    { code: '04', title: 'Final permissive sample', detail: 'Controller authority, immediately before commit' },
    { code: '05', title: 'LOCAL COMMIT and sequence', detail: 'No remote equivalent exists' },
  ];
  return (
    <Panel>
      <SectionHeading eyebrow="Prepare → local commit" title="Authority sequence" action={<StatusPill label="NO REMOTE START" tone="info" />} />
      <View style={styles.sequenceList}>
        {stages.map((stage, index) => (
          <View key={stage.code} style={styles.sequenceRow}>
            <View style={styles.sequenceCode}>
              <Text style={styles.sequenceCodeText}>{stage.code}</Text>
            </View>
            <View style={styles.sequenceCopy}>
              <Text style={styles.sequenceTitle}>{stage.title}</Text>
              <Text style={styles.sequenceDetail}>{stage.detail}</Text>
            </View>
            {index < stages.length - 1 ? <View style={styles.sequenceLine} /> : null}
          </View>
        ))}
      </View>
      <View style={styles.physicalNotice}>
        <Text style={styles.physicalNoticeCode}>PHYSICAL READINESS GATE</Text>
        <Text style={styles.physicalNoticeTitle}>The illuminated button is at the cell—not on this screen.</Text>
        <Text style={styles.physicalNoticeText}>It is edge-detected, transaction-bound, short-lived, and rechecked against local permissives. It is not an emergency stop or safety function.</Text>
      </View>
    </Panel>
  );
}

/**
 * Reports a fact about the current session. Deliberately carries no tick or pass
 * mark: these are inputs to a server-side decision, and a green check would read as
 * an approval the portal is not entitled to give.
 */
function PolicyRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.policyRow}>
      <Text style={styles.policyLabel}>{label}</Text>
      <Text style={styles.policyValue} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start' },
  stacked: { flexDirection: 'column' },
  formPanel: { flex: 1.15, minWidth: 0 },
  sideColumn: { flex: 0.85, minWidth: 340, gap: Spacing.md },
  formSection: { gap: Spacing.xl, marginBottom: Spacing.xl },
  twoColumns: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl },
  parameterBlock: { paddingVertical: Spacing.xl, gap: Spacing.md },
  blockLabel: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '800', letterSpacing: 0.9 },
  parameterRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  parameter: { flex: 1, minWidth: 160, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, borderWidth: 1, borderColor: Palette.line, padding: Spacing.lg, gap: 5 },
  parameterLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10 },
  parameterValue: { color: Palette.ink, fontFamily: Type.mono, fontSize: 18, fontWeight: '800' },
  parameterLimit: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  stateBinding: { paddingVertical: Spacing.xl, gap: Spacing.md },
  hashBox: { borderRadius: Radius.md, backgroundColor: '#08131F', borderWidth: 1, borderColor: Palette.line, padding: Spacing.md, flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  hashLabel: { color: Palette.violet, fontFamily: Type.mono, fontSize: 9, fontWeight: '800' },
  hashText: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10, flexShrink: 1 },
  hint: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-end', gap: Spacing.sm, paddingTop: Spacing.lg },
  sequenceList: { gap: 0 },
  sequenceRow: { minHeight: 60, flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.md, position: 'relative' },
  sequenceCode: { width: 30, height: 30, borderRadius: 9, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Palette.lineStrong, backgroundColor: Palette.panelRaised, zIndex: 2 },
  sequenceCodeActive: { borderColor: '#277C76', backgroundColor: Palette.tealSoft },
  sequenceCodeText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '800' },
  sequenceCodeTextActive: { color: Palette.teal },
  sequenceCopy: { flex: 1, gap: 4, paddingTop: 2 },
  sequenceTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11, fontWeight: '700' },
  sequenceDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 13 },
  sequenceState: { fontFamily: Type.mono, fontSize: 8, fontWeight: '800', paddingTop: 5 },
  sequenceStateActive: { color: Palette.teal },
  sequenceStateBlocked: { color: Palette.inkMuted },
  sequenceLine: { position: 'absolute', left: 14, top: 30, bottom: 0, width: 1, backgroundColor: Palette.lineStrong },
  physicalNotice: { marginTop: Spacing.lg, backgroundColor: Palette.amberSoft, borderRadius: Radius.md, borderWidth: 1, borderColor: '#5F4521', padding: Spacing.lg, gap: 6 },
  physicalNoticeCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  physicalNoticeTitle: { color: '#F4D59D', fontFamily: Type.sans, fontSize: 11, fontWeight: '800' },
  physicalNoticeText: { color: '#CBB48B', fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  policyRow: { minHeight: 44, flexDirection: 'row', alignItems: 'center', gap: 9, borderBottomWidth: 1, borderBottomColor: Palette.line },
  policyCheck: { width: 20, height: 20, borderRadius: 7, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.greenSoft },
  policyCheckText: { color: Palette.green, fontSize: 10, fontWeight: '900' },
  policyLabel: { flex: 1, color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10 },
  policyValue: { color: Palette.green, fontFamily: Type.sans, fontSize: 9, fontWeight: '700', textAlign: 'right' },
  unansweredNotice: { marginTop: Spacing.md, borderRadius: Radius.md, padding: Spacing.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#5F4521', gap: 5 },
  unansweredCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  unansweredText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  unansweredCodes: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
  policyFootnote: { marginTop: Spacing.lg, borderLeftWidth: 3, borderLeftColor: Palette.cyan, paddingLeft: Spacing.md, gap: 5 },
  policyFootnoteTitle: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  policyFootnoteText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});
