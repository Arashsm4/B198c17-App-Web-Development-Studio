// @screen CH1-UX-SCR-0021 — Experiment promotion review: impact, change, verification and controlled-baseline promotion

import { useState } from 'react';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type { ExperimentDetail, ExperimentPage } from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useObserved } from '@/api/use-observed';
import { useSession } from '@/auth/session';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice } from '@/components/capability';
import { KeyValue, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * CH1-UX-SCR-0021 — experiment promotion review.
 *
 * screens.json declares this for the Engineer, Project Manager and Verification, showing
 * "impact, change, verification and controlled-baseline promotion". CH1-RND-FR-0003 makes
 * all three mandatory before a promotion may be considered, and the review exists so a
 * reviewer sees them together rather than one at a time.
 *
 * THE PLATFORM DOES NOT APPROVE. CH1 emits the promotion request; approving one is an act
 * in configuration control, which is a separate system. There is deliberately no approve
 * control here, and the response's own `promotionAuthority` statement is rendered rather
 * than paraphrased.
 *
 * An experiment with no promotion requested shows as exactly that. The service sends
 * `promotion: null` rather than an object of empty strings, so this screen cannot render
 * an unrequested promotion as a completed review with three blank fields.
 */
export default function PromotionScreen() {
  return (
    <AppShell active="promotion">
      <SessionGate>
        <PromotionReview />
      </SessionGate>
    </AppShell>
  );
}

function PromotionReview() {
  const { width } = useWindowDimensions();
  const narrow = width < 1080;
  const session = useSession();
  const roles = session.claims?.roles ?? [];

  const canRead =
    roles.includes('RDEngineer') ||
    roles.includes('Engineer') ||
    roles.includes('Auditor') ||
    roles.includes('ProjectManager') ||
    roles.includes('ConfigurationManager');

  const experiments = useObserved<ExperimentPage>(
    canRead ? '/api/v1/experiments' : undefined,
    session.accessToken,
  );

  const items = experiments.value?.items ?? [];
  // The review opens on something awaiting review when there is one, because that is what
  // a reviewer came for.
  const [chosen, setChosen] = useState<string | undefined>(undefined);
  const selected = chosen ?? items.find((item) => item.promotionRequested)?.experimentId ?? items[0]?.experimentId;

  const detail = useObserved<ExperimentDetail>(
    canRead && selected ? `/api/v1/experiments/${selected}` : undefined,
    session.accessToken,
  );

  const experiment = detail.value;
  const promotion = experiment?.promotion ?? null;

  return (
    <>
      <PageIntro
        eyebrow="ResearchBench / CH1-RND-FR-0003"
        title="Experiment promotion review"
        description="A promotion carries an approved change record, an impact assessment and verification. All three are shown together, because a reviewer deciding on one at a time is deciding on none of them."
        aside={<FreshnessTag freshness={detail.freshness} quality={detail.quality} />}
      />

      {!canRead ? (
        <Panel>
          <SectionHeading eyebrow="Withheld" title="The promotion review is not shown to this identity" />
          <Text style={styles.blocked}>
            The review is read by the R&amp;D Engineer, the Engineer, the Auditor, the Project Manager and the
            Configuration Manager. This session holds none of them.
          </Text>
        </Panel>
      ) : (
        <View style={[styles.grid, narrow && styles.stacked]}>
          <Panel style={styles.queue}>
            <SectionHeading
              eyebrow="GET /api/v1/experiments"
              title="Awaiting review"
              action={<StatusPill label={`${items.filter((i) => i.promotionRequested).length} REQUESTED`} tone="info" />}
            />
            {experiments.error !== undefined ? (
              <CapabilityNotice error={experiments.cause ?? experiments.error} context="GET /api/v1/experiments" />
            ) : items.length === 0 ? (
              <Text style={styles.empty}>No experiment is recorded in this project.</Text>
            ) : (
              <View>
                {items.map((item) => (
                  <Pressable
                    key={item.experimentId}
                    onPress={() => setChosen(item.experimentId)}
                    style={[styles.queueRow, item.experimentId === selected && styles.queueRowActive]}
                  >
                    <View style={styles.queueCopy}>
                      <Text style={styles.queueObjective} numberOfLines={2}>
                        {item.objective}
                      </Text>
                      <Text style={styles.queueMeta}>{shortId(item.experimentId)}</Text>
                    </View>
                    <StatusPill
                      label={item.promotionRequested ? 'REQUESTED' : 'NOT REQUESTED'}
                      tone={item.promotionRequested ? 'warning' : 'neutral'}
                    />
                  </Pressable>
                ))}
              </View>
            )}
          </Panel>

          <Panel style={styles.detail}>
            <SectionHeading
              eyebrow={selected ? `GET /api/v1/experiments/${shortId(selected)}` : 'No experiment selected'}
              title="Change, impact and verification"
              action={
                <StatusPill
                  label={experiment?.productionAuthority ? 'PRODUCTION AUTHORITY' : 'NO PRODUCTION AUTHORITY'}
                  tone={experiment?.productionAuthority ? 'danger' : 'good'}
                />
              }
            />

            {detail.error !== undefined ? (
              <CapabilityNotice error={detail.cause ?? detail.error} context="GET /api/v1/experiments/{id}" />
            ) : experiment === undefined ? (
              <Text style={styles.empty}>Select an experiment to review.</Text>
            ) : promotion === null ? (
              <View style={styles.notRequested}>
                <Text style={styles.notRequestedTitle}>No promotion has been requested for this experiment</Text>
                <Text style={styles.blocked}>
                  There is nothing to review. This is not a promotion with three empty fields — the platform
                  reports the absence of a request rather than an incomplete one, so a reviewer cannot mistake
                  one for the other.
                </Text>
              </View>
            ) : (
              <View style={styles.promotionBody}>
                <KeyValue label="Requested by" value={promotion.requestedBy ?? 'not stated'} />
                <KeyValue
                  label="Requested at"
                  value={promotion.requestedAt === null ? 'not stated' : instant(promotion.requestedAt)}
                />
                <Field title="Approved change record" body={promotion.changeRecord} />
                <Field title="Impact assessment" body={promotion.impactAnalysis} />
                <Field title="Verification" body={promotion.verification} />
              </View>
            )}

            {experiment !== undefined ? (
              <View style={styles.runs}>
                <SectionHeading
                  eyebrow="Provenance"
                  title={`${experiment.revisionCount} recorded run${experiment.revisionCount === 1 ? '' : 's'}`}
                />
                {experiment.revisions.length === 0 ? (
                  <Text style={styles.empty}>
                    No run has been recorded. A promotion with no run behind it has nothing to verify.
                  </Text>
                ) : (
                  experiment.revisions.map((revision) => (
                    <View key={revision.experimentRevisionId} style={styles.runRow}>
                      <Text style={styles.runNumber}>#{revision.revisionNumber}</Text>
                      <View style={styles.runCopy}>
                        <Text style={styles.runSummary} numberOfLines={2}>
                          {revision.resultSummary}
                        </Text>
                        <Text style={styles.runMeta}>
                          {revision.environment} · config {revision.configurationSha256.slice(0, 12)} · input{' '}
                          {revision.inputSha256.slice(0, 12)} · result {revision.resultSha256.slice(0, 12)}
                        </Text>
                        <Text style={styles.runMeta}>
                          requested {revision.requestedBy} · executed {revision.executedBy} ·{' '}
                          {instant(revision.finishedAt)}
                        </Text>
                      </View>
                    </View>
                  ))
                )}
              </View>
            ) : null}

            <Text style={styles.footnote}>
              {experiment?.promotionAuthority ??
                'The promotion authority statement is sent by Control Core with the experiment.'}
            </Text>
          </Panel>
        </View>
      )}
    </>
  );
}

/**
 * One of the three things CH1-RND-FR-0003 requires. A missing one is named as missing
 * rather than rendered as an empty box, because a reviewer scanning three boxes needs the
 * empty one to be louder than the full ones.
 */
function Field({ title, body }: { title: string; body: string | null }) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldTitle}>{title}</Text>
      {body === null || body.trim().length === 0 ? (
        <Text style={styles.fieldMissing}>NOT PROVIDED — this promotion is incomplete</Text>
      ) : (
        <Text style={styles.fieldBody}>{body}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start' },
  stacked: { flexDirection: 'column' },
  queue: { flex: 0.8, minWidth: 300 },
  detail: { flex: 1.6, minWidth: 0 },
  queueRow: {
    minHeight: 58,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Palette.line,
  },
  queueRowActive: { backgroundColor: Palette.canvasRaised, borderRadius: Radius.sm },
  queueCopy: { flex: 1, minWidth: 0, gap: 3 },
  queueObjective: { color: Palette.ink, fontFamily: Type.sans, fontSize: 9, fontWeight: '800' },
  queueMeta: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  promotionBody: { gap: Spacing.sm, paddingTop: Spacing.sm },
  field: {
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Palette.line,
    backgroundColor: Palette.canvasRaised,
    padding: Spacing.md,
    gap: 5,
  },
  fieldTitle: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  fieldBody: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  fieldMissing: { color: Palette.red, fontFamily: Type.mono, fontSize: 8, fontWeight: '900' },
  notRequested: { paddingVertical: Spacing.md, gap: 4 },
  notRequestedTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10, fontWeight: '800' },
  runs: { marginTop: Spacing.lg, gap: Spacing.sm },
  runRow: { flexDirection: 'row', gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Palette.line, paddingVertical: Spacing.sm },
  runNumber: { color: Palette.teal, fontFamily: Type.mono, fontSize: 10, fontWeight: '900', width: 32 },
  runCopy: { flex: 1, minWidth: 0, gap: 3 },
  runSummary: { color: Palette.ink, fontFamily: Type.sans, fontSize: 9, fontWeight: '700' },
  runMeta: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7 },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, paddingVertical: Spacing.lg, lineHeight: 14 },
  blocked: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 15, paddingTop: Spacing.sm },
  footnote: {
    marginTop: Spacing.lg,
    borderRadius: Radius.md,
    borderLeftWidth: 3,
    borderLeftColor: Palette.violet,
    backgroundColor: '#18182A',
    padding: Spacing.md,
    color: Palette.inkSoft,
    fontFamily: Type.sans,
    fontSize: 9,
    lineHeight: 14,
  },
});
