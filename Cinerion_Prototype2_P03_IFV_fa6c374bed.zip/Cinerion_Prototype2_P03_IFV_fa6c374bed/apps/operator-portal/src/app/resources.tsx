// @screen CH1-UX-SCR-0017 — Resource and capacity board: availability, reservation and conflict

import { useState } from 'react';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

import type {
  CapacityConflict,
  CellState,
  ReservationReceipt,
  ResourceAllocation,
  ResourceAvailability,
  ResourceAvailabilityState,
  ResourcePage,
} from '@/api/contracts';
import { instant, shortId } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { useObserved } from '@/api/use-observed';
import { assignedCells, useSession } from '@/auth/session';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { AppShell, PageIntro } from '@/components/app-shell';
import { CapabilityNotice, NotConnectedNotice } from '@/components/capability';
import {
  ActionButton,
  KpiCard,
  Panel,
  SectionHeading,
  StatusPill,
  TextField,
} from '@/components/primitives';
import { FreshnessTag, SessionGate } from '@/components/session-gate';
import { StepUpPrompt } from '@/components/step-up';
import type { StatusTone } from '@/constants/status';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

const STATES: readonly ResourceAvailabilityState[] = ['Available', 'Maintenance', 'Withdrawn'];

export default function ResourcesScreen() {
  return (
    <AppShell active="resources">
      <SessionGate>
        <Resources />
      </SessionGate>
    </AppShell>
  );
}

function Resources() {
  const { width } = useWindowDimensions();
  const compact = width < 1120;
  const session = useSession();
  const [stateFilter, setStateFilter] = useState<ResourceAvailabilityState | undefined>(undefined);

  const path = stateFilter
    ? `/api/v1/resources?availabilityState=${stateFilter}`
    : '/api/v1/resources';
  const resources = useObserved<ResourcePage>(path, session.accessToken, (value) => value.freshness);

  // CH1-MGT-FR-0004 requires every allocation to be linked to its work order or
  // experiment, and the API refuses one that names neither. The work order comes from
  // the cell this identity is assigned to rather than from a field the operator types,
  // so a reservation cannot be attached to a work order they are not working on.
  const primaryCell = assignedCells(session.claims)[0];
  const cell = useObserved<CellState>(
    primaryCell ? `/api/v1/cells/${primaryCell}/state` : undefined,
    session.accessToken,
    (value) => value.freshness,
  );

  const items = resources.value?.items ?? [];
  const conflicted = items.filter((item) => item.conflicted);
  const totalReservations = items.reduce(
    (sum, item) => sum + item.reservations.filter((r) => r.status === 'Reserved').length,
    0,
  );

  return (
    <>
      <PageIntro
        eyebrow="CH1-UX-SCR-0017 / ResourceOrchestrator"
        title="Resource and capacity board"
        description="Capacity, what is committed against it, and where the two disagree. A reservation holds capacity and starts nothing: every physical-effect path stays inside CommandGuard, local permissives and local confirmation."
        aside={<FreshnessTag freshness={resources.freshness} detail={resources.value ? `as of ${instant(resources.value.asOf)}` : undefined} />}
      />

      <View style={styles.kpiGrid}>
        <KpiCard
          label="Resources in scope"
          value={String(items.length)}
          note={resources.error ? 'Not retrieved' : 'Read from the reservation ledger'}
          tone={resources.error ? 'danger' : items.length > 0 ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Live reservations"
          value={String(totalReservations)}
          note="Inside the served window; cancelled reservations are retained but not counted"
          tone={totalReservations > 0 ? 'info' : 'neutral'}
        />
        <KpiCard
          label="Over-committed"
          value={String(conflicted.length)}
          note={
            conflicted.length > 0
              ? 'Capacity was reduced after these intervals were committed'
              : 'No interval commits more than its resource has'
          }
          tone={conflicted.length > 0 ? 'danger' : 'good'}
        />
        <KpiCard
          label="Window"
          value={resources.value ? `${resources.value.bounds.defaultWindowDays} d` : '—'}
          note={
            resources.value
              ? `${instant(resources.value.window.from)} → ${instant(resources.value.window.to)}`
              : 'No window retrieved'
          }
          tone="neutral"
        />
      </View>

      <View style={styles.filterRow}>
        <Text style={styles.filterLabel}>AVAILABILITY</Text>
        {STATES.map((state) => {
          const active = stateFilter === state;
          return (
            <Pressable
              key={state}
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              accessibilityLabel={`Filter resources by availability ${state}`}
              onPress={() => setStateFilter(active ? undefined : state)}
              style={({ pressed }) => [
                styles.chip,
                active && styles.chipActive,
                pressed && styles.chipPressed,
              ]}>
              <Text style={[styles.chipText, active && styles.chipTextActive]}>
                {active ? '✓ ' : ''}
                {state}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {resources.cause !== undefined ? (
        <CapabilityNotice error={resources.cause} context="GET /api/v1/resources" />
      ) : null}

      {items.length === 0 && resources.cause === undefined ? (
        <Panel>
          <SectionHeading eyebrow="Nothing to show" title="No resource in scope" />
          <Text style={styles.empty}>
            {stateFilter
              ? 'No resource is in this availability state. That is a statement about the filter, not about the project.'
              : 'No resource has been established for this project. CH1-MGT-FR-0001 wants resource configuration to come from revision-controlled operations, and the P03 catalogue contains none that creates one, so resources arrive through the prototype seed.'}
          </Text>
        </Panel>
      ) : null}

      <View style={styles.list}>
        {items.map((item) => (
          <ResourceCard
            key={item.resourceId}
            item={item}
            compact={compact}
            accessToken={session.accessToken}
            workOrderId={cell.value?.workOrderId}
            onReconcile={resources.refresh}
          />
        ))}
      </View>

      <Panel style={styles.managementPanel}>
        <SectionHeading eyebrow="CH1-MGT-FR-0001" title="What this board cannot do" />
        <NotConnectedNotice detail="Resource capacity itself has no controlled operation: the P03 catalogue contains nothing that creates, updates or withdraws a resource, so capacity changes remain an out-of-band administrative action. Reserving and cancelling are offered above and are real." />
      </Panel>
    </>
  );
}

function ResourceCard({
  item,
  compact,
  accessToken,
  workOrderId,
  onReconcile,
}: {
  item: ResourceAvailability;
  compact: boolean;
  accessToken: string | undefined;
  workOrderId: string | undefined;
  onReconcile: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const reserved = item.reservations.filter((r) => r.status === 'Reserved');
  const cancelled = item.reservations.filter((r) => r.status === 'Cancelled');

  return (
    <Panel style={[styles.resourceCard, item.conflicted && styles.resourceCardConflicted]}>
      <View style={[styles.resourceHead, compact && styles.stacked]}>
        <View style={styles.resourceCopy}>
          <Text style={styles.resourceType}>{item.resourceType.toUpperCase()}</Text>
          <Text style={styles.resourceName}>{item.name}</Text>
          <Text style={styles.resourceId} selectable>
            {item.resourceId} · version {item.version}
          </Text>
        </View>
        <View style={styles.resourceStates}>
          <StatusPill
            label={item.availabilityState.toUpperCase()}
            tone={availabilityTone(item.availabilityState)}
          />
          <StatusPill
            label={item.acceptsReservations ? 'ACCEPTS RESERVATIONS' : 'CLOSED TO RESERVATIONS'}
            tone={item.acceptsReservations ? 'good' : 'warning'}
          />
          {item.conflicted ? <StatusPill label="OVER-COMMITTED" tone="danger" /> : null}
        </View>
      </View>

      <View style={styles.capacityGrid}>
        <Capacity label="Capacity" value={`${item.capacity} ${item.unit}`} />
        <Capacity label="Committed now" value={`${item.committedNow} ${item.unit}`} />
        <Capacity
          label="Available now"
          value={`${item.availableNow} ${item.unit}`}
          tone={item.availableNow < 0 ? 'danger' : item.availableNow === 0 ? 'warning' : 'good'}
        />
        <Capacity
          label="Committed peak"
          value={`${item.committedPeak} ${item.unit}`}
          detail={`at ${instant(item.peakAt)}`}
          tone={item.committedPeak > item.capacity ? 'danger' : undefined}
        />
        <Capacity
          label="Free at peak"
          value={`${item.availableAtPeak} ${item.unit}`}
          tone={item.availableAtPeak < 0 ? 'danger' : undefined}
        />
      </View>

      <CapacityBar capacity={item.capacity} committed={item.committedPeak} unit={item.unit} />

      {item.conflicts.length > 0 ? (
        <View style={styles.conflictBlock}>
          <Text style={styles.conflictTitle}>
            ✕ OVER-COMMITTED INTERVALS — {item.conflicts.length}
          </Text>
          <Text style={styles.conflictLead}>
            A reservation cannot over-commit, so these intervals were committed while the resource
            was larger. Reducing capacity does not release what was already held.
          </Text>
          {item.conflicts.map((conflict) => (
            <ConflictRow key={`${conflict.from}-${conflict.to}`} conflict={conflict} unit={item.unit} />
          ))}
        </View>
      ) : null}

      <Pressable
        accessibilityRole="button"
        accessibilityState={{ expanded }}
        accessibilityLabel={`${expanded ? 'Hide' : 'Show'} reservations for ${item.name}`}
        onPress={() => setExpanded((previous) => !previous)}
        style={({ pressed }) => [styles.expandRow, pressed && styles.chipPressed]}>
        <Text style={styles.expandText}>
          {expanded ? '▾ HIDE' : '▸ SHOW'} {reserved.length} RESERVATION
          {reserved.length === 1 ? '' : 'S'}
          {cancelled.length > 0 ? ` · ${cancelled.length} CANCELLED, RETAINED` : ''}
        </Text>
      </Pressable>

      {expanded ? (
        <View style={styles.allocationList}>
          {item.reservations.length === 0 ? (
            <Text style={styles.empty}>
              Nothing is held against this resource inside the served window.
            </Text>
          ) : (
            item.reservations.map((allocation) => (
              <AllocationRow
                key={allocation.allocationId}
                allocation={allocation}
                unit={item.unit}
                accessToken={accessToken}
                onReconcile={onReconcile}
              />
            ))
          )}
        </View>
      ) : null}

      <ReserveForm
        item={item}
        accessToken={accessToken}
        workOrderId={workOrderId}
        onReconcile={onReconcile}
      />
    </Panel>
  );
}

/**
 * Holds capacity for a bounded interval.
 *
 * A reservation starts nothing. CH1-MGT-FR-0002 keeps every physical-effect path inside
 * CommandGuard, local permissives and local confirmation, so this form has no control
 * that could reach equipment, and the receipt it renders says so in the server's words.
 *
 * The version read from the board is echoed in If-Match. The conflict check reads
 * allocations, decides, then writes, so without a version comparison inside the same
 * transaction two callers who both saw room would both commit.
 */
function ReserveForm({
  item,
  accessToken,
  workOrderId,
  onReconcile,
}: {
  item: ResourceAvailability;
  accessToken: string | undefined;
  workOrderId: string | undefined;
  onReconcile: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [quantity, setQuantity] = useState('1');
  const [startsAt, setStartsAt] = useState('');
  const [endsAt, setEndsAt] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const reserve = useControlledAction<ReservationReceipt>(accessToken);

  const amount = Number(quantity);
  const quantityInvalid = !Number.isFinite(amount) || amount <= 0;
  const intervalInvalid =
    startsAt.trim().length === 0 ||
    endsAt.trim().length === 0 ||
    Number.isNaN(Date.parse(startsAt)) ||
    Number.isNaN(Date.parse(endsAt)) ||
    Date.parse(endsAt) <= Date.parse(startsAt);

  const begin = () => {
    // Seeded from the clock only when the form is opened, so the values are the
    // operator's to change and nothing shifts underneath them while they type.
    if (!open) {
      const now = new Date();
      const later = new Date(now.getTime() + 2 * 60 * 60 * 1000);
      setStartsAt(`${now.toISOString().slice(0, 19)}Z`);
      setEndsAt(`${later.toISOString().slice(0, 19)}Z`);
    }
    setOpen((previous) => !previous);
  };

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (quantityInvalid || intervalInvalid || workOrderId === undefined) return;

    const grant = await stepUp.request(StepUpPurpose.ResourceAllocation, method);
    if (!grant) return;

    const held = await reserve.submit(
      `/api/v1/resources/${item.resourceId}/reservations`,
      { quantity: amount, startsAt, endsAt, workOrderId },
      { stepUpGrantId: grant.grantId, ifMatchVersion: item.version },
    );
    if (held) {
      // Cleared only on a success this screen saw. A refusal leaves the interval and
      // quantity in place so they can be corrected and sent again.
      setAttempted(false);
      stepUp.clear();
      onReconcile();
    }
  };

  if (!item.acceptsReservations) {
    return (
      <Text style={styles.closedNote}>
        This resource is {item.availabilityState} and is closed to new reservations. Existing
        holdings stand.
      </Text>
    );
  }

  return (
    <View style={styles.reserveBlock}>
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ expanded: open }}
        accessibilityLabel={`${open ? 'Close' : 'Open'} the reservation form for ${item.name}`}
        onPress={begin}
        style={({ pressed }) => [styles.expandRow, pressed && styles.chipPressed]}>
        <Text style={styles.expandText}>{open ? '▾ CLOSE' : '▸ HOLD CAPACITY'}</Text>
      </Pressable>

      {open ? (
        <View style={styles.reserveForm}>
          {workOrderId === undefined ? (
            <Text style={styles.closedNote}>
              A reservation must be linked to a work order, and none has been retrieved for the
              cell this identity is assigned to. Nothing can be held until one is.
            </Text>
          ) : null}

          <View style={styles.reserveRow}>
            <View style={styles.reserveField}>
              <TextField
                label={`Quantity (${item.unit})`}
                value={quantity}
                onChangeText={setQuantity}
                error={
                  attempted && quantityInvalid ? 'Enter a quantity greater than zero.' : undefined
                }
                hint={`${item.availableNow} ${item.unit} free now`}
              />
            </View>
            <View style={styles.reserveField}>
              <TextField
                label="Starts at (UTC)"
                value={startsAt}
                onChangeText={setStartsAt}
                error={
                  attempted && intervalInvalid
                    ? 'Give an interval that ends after it begins.'
                    : undefined
                }
              />
            </View>
            <View style={styles.reserveField}>
              <TextField label="Ends at (UTC)" value={endsAt} onChangeText={setEndsAt} />
            </View>
          </View>

          <Text style={styles.reserveLink}>
            Linked to work order {shortId(workOrderId)} · version {item.version} is echoed, so a
            reservation made against a stale reading is refused rather than double-booking.
          </Text>

          <StepUpPrompt
            action={`Hold ${quantity} ${item.unit} of ${item.name}`}
            consequence="Capacity is committed for the interval above. No equipment starts, and nothing is prepared for execution."
            stepUp={stepUp}
            onGranted={(method) => void submit(method)}
            disabled={reserve.pending || workOrderId === undefined}
          />

          {reserve.error !== undefined ? (
            <CapabilityNotice
              error={reserve.error}
              context={`POST /api/v1/resources/${item.resourceId}/reservations`}
            />
          ) : null}

          {reserve.result !== undefined ? (
            <View style={styles.receipt}>
              <Text style={styles.receiptTitle}>HELD</Text>
              <Text style={styles.receiptLine}>
                {reserve.result.quantity} {item.unit} · {instant(reserve.result.startsAt)} to{' '}
                {instant(reserve.result.endsAt)} · v{reserve.result.version}
              </Text>
              <Text style={styles.receiptEffect}>{reserve.result.physicalEffect}</Text>
            </View>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

/**
 * Committed capacity against the resource's own capacity, at the peak. Never colour
 * alone: the numbers are printed and the over-commitment is labelled in words.
 */
function CapacityBar({
  capacity,
  committed,
  unit,
}: {
  capacity: number;
  committed: number;
  unit: string;
}) {
  const over = committed > capacity;
  // When it's over, the bar measures what was COMMITTED, so the in-capacity part and the
  // red overshoot share the track and add up to exactly 100%. It used to be 100% amber
  // plus a red slice parked past the end of a track with overflow hidden - so the red bit,
  // the whole point of the bar, had never once been on screen. A real browser caught it.
  const ratio = over
    ? (committed > 0 ? Math.max(0, capacity) / committed : 0)
    : capacity <= 0 ? 0 : committed / capacity;
  const overRatio = over ? 1 - ratio : 0;

  return (
    <View style={styles.bar} accessibilityRole="text" accessibilityLabel={`Committed ${committed} of ${capacity} ${unit} at peak`}>
      <View style={styles.barTrack}>
        <View
          style={[
            styles.barFill,
            { width: `${ratio * 100}%` },
            over && styles.barFillOver,
          ]}
        />
        {over ? <View style={[styles.barOver, { width: `${overRatio * 100}%` }]} /> : null}
      </View>
      <Text style={[styles.barLabel, over && styles.barLabelOver]}>
        {committed} / {capacity} {unit} at peak{over ? ` — OVER BY ${committed - capacity}` : ''}
      </Text>
    </View>
  );
}

function ConflictRow({ conflict, unit }: { conflict: CapacityConflict; unit: string }) {
  return (
    <View style={styles.conflictRow}>
      <Text style={styles.conflictInterval}>
        {instant(conflict.from)} → {instant(conflict.to)}
      </Text>
      <Text style={styles.conflictNumbers}>
        committed {conflict.committed} {unit} against capacity {conflict.capacity} {unit} — over by{' '}
        {conflict.overCommittedBy} {unit}
      </Text>
    </View>
  );
}

function AllocationRow({
  allocation,
  unit,
  accessToken,
  onReconcile,
}: {
  allocation: ResourceAllocation;
  unit: string;
  accessToken: string | undefined;
  onReconcile: () => void;
}) {
  const cancelled = allocation.status === 'Cancelled';
  const [releasing, setReleasing] = useState(false);
  const [reason, setReason] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const cancel = useControlledAction<ResourceAllocation>(accessToken);

  const release = async (method: StepUpMethod) => {
    setAttempted(true);
    if (reason.trim().length === 0) return;

    const grant = await stepUp.request(StepUpPurpose.ResourceAllocation, method);
    if (!grant) return;

    const released = await cancel.submit(
      `/api/v1/reservations/${allocation.allocationId}?reason=${encodeURIComponent(reason.trim())}`,
      undefined,
      { method: 'DELETE', stepUpGrantId: grant.grantId, ifMatchVersion: allocation.version },
    );
    if (released) {
      setReleasing(false);
      setAttempted(false);
      stepUp.clear();
      onReconcile();
    }
  };

  return (
    <View style={[styles.allocationRow, cancelled && styles.allocationCancelled]}>
      <View style={styles.allocationMain}>
        <Text style={styles.allocationQuantity}>
          {allocation.quantity} {unit}
        </Text>
        <Text style={styles.allocationInterval}>
          {instant(allocation.startsAt)} → {instant(allocation.endsAt)}
        </Text>
        <Text style={styles.allocationMeta}>
          {allocation.requestedBy} · v{allocation.version} ·{' '}
          {allocation.workOrderId
            ? `work order ${shortId(allocation.workOrderId)}`
            : allocation.experimentId
              ? `experiment ${shortId(allocation.experimentId)}`
              : 'no link'}
        </Text>
      </View>
      <View style={styles.allocationRight}>
        <StatusPill
          label={allocation.status.toUpperCase()}
          tone={cancelled ? 'neutral' : 'info'}
        />
        {cancelled ? (
          <Text style={styles.cancellation}>
            {allocation.cancelledBy} at {instant(allocation.cancelledAt)} —{' '}
            {allocation.cancellationReason}
          </Text>
        ) : (
          <Text style={styles.physicalEffect}>{allocation.physicalEffect}</Text>
        )}
        {cancelled ? null : (
          <ActionButton
            label={releasing ? 'KEEP IT' : 'RELEASE'}
            kind="secondary"
            onPress={() => setReleasing((previous) => !previous)}
          />
        )}
      </View>

      {releasing && !cancelled ? (
        <View style={styles.cancelForm}>
          <TextField
            label="Why is this capacity being released"
            value={reason}
            onChangeText={setReason}
            multiline
            hint="CH1-MGT-FR-0003 requires an assignment change to be attributable. The reason, your identity and the time are kept; the reservation is not deleted."
            error={attempted && reason.trim().length === 0 ? 'A reason is required.' : undefined}
            editable={!cancel.pending}
          />
          <StepUpPrompt
            action={`Release ${allocation.quantity} ${unit}`}
            consequence="The capacity becomes reservable again. The cancelled reservation is retained with your reason against it."
            stepUp={stepUp}
            onGranted={(method) => void release(method)}
            disabled={cancel.pending}
          />
          {cancel.error !== undefined ? (
            <CapabilityNotice
              error={cancel.error}
              context={`DELETE /api/v1/reservations/${allocation.allocationId}`}
            />
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

function Capacity({
  label,
  value,
  detail,
  tone,
}: {
  label: string;
  value: string;
  detail?: string;
  tone?: StatusTone;
}) {
  const colour =
    tone === 'danger'
      ? Palette.red
      : tone === 'warning'
        ? Palette.amber
        : tone === 'good'
          ? Palette.green
          : Palette.ink;
  return (
    <View style={styles.capacity}>
      <Text style={styles.capacityLabel}>{label}</Text>
      <Text style={[styles.capacityValue, { color: colour }]}>{value}</Text>
      {detail ? <Text style={styles.capacityDetail}>{detail}</Text> : null}
    </View>
  );
}

function availabilityTone(state: ResourceAvailabilityState): StatusTone {
  switch (state) {
    case 'Available':
      return 'good';
    case 'Maintenance':
      return 'warning';
    default:
      return 'neutral';
  }
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md, marginBottom: Spacing.md },
  filterRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6, marginBottom: Spacing.md },
  filterLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.9, marginRight: 4 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.pill, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.panel },
  chipActive: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  chipPressed: { opacity: 0.72 },
  chipText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  chipTextActive: { color: Palette.teal },
  list: { gap: Spacing.md },
  resourceCard: { gap: Spacing.md },
  resourceCardConflicted: { borderColor: '#714046' },
  resourceHead: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: Spacing.md },
  stacked: { flexDirection: 'column' },
  resourceCopy: { gap: 4, flexShrink: 1 },
  resourceType: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.9 },
  resourceName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 16, fontWeight: '800' },
  resourceId: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  resourceStates: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: Spacing.sm },
  capacityGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xl },
  capacity: { gap: 3, minWidth: 130 },
  capacityLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, fontWeight: '900', letterSpacing: 0.8 },
  capacityValue: { fontFamily: Type.sans, fontSize: 15, fontWeight: '800' },
  capacityDetail: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  bar: { gap: 5 },
  barTrack: { height: 8, borderRadius: 4, backgroundColor: '#08131F', borderWidth: 1, borderColor: Palette.line, flexDirection: 'row', overflow: 'hidden' },
  barFill: { height: '100%', backgroundColor: Palette.teal },
  barFillOver: { backgroundColor: Palette.amber },
  barOver: { height: '100%', backgroundColor: Palette.red },
  barLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  barLabelOver: { color: Palette.red, fontWeight: '900' },
  conflictBlock: { borderRadius: Radius.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#714046', padding: Spacing.md, gap: 6 },
  conflictTitle: { color: Palette.red, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  conflictLead: { color: '#D9A6A8', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  conflictRow: { borderTopWidth: 1, borderTopColor: '#5A3438', paddingTop: 6, gap: 2 },
  conflictInterval: { color: '#F2B3B5', fontFamily: Type.mono, fontSize: 9, fontWeight: '800' },
  conflictNumbers: { color: '#C99699', fontFamily: Type.sans, fontSize: 9 },
  expandRow: { borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.md },
  expandText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  allocationList: { gap: Spacing.sm },
  allocationRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: Spacing.md, borderRadius: Radius.md, backgroundColor: Palette.canvasRaised, borderWidth: 1, borderColor: Palette.line, padding: Spacing.md },
  allocationCancelled: { opacity: 0.7 },
  allocationMain: { flex: 1, minWidth: 220, gap: 3 },
  allocationQuantity: { color: Palette.ink, fontFamily: Type.sans, fontSize: 12, fontWeight: '800' },
  allocationInterval: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  allocationMeta: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  allocationRight: { alignItems: 'flex-end', gap: 5, maxWidth: 300 },
  cancellation: { color: Palette.amber, fontFamily: Type.sans, fontSize: 9, textAlign: 'right', lineHeight: 13 },
  physicalEffect: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, textAlign: 'right', lineHeight: 13 },
  empty: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 16 },
  managementPanel: { marginTop: Spacing.md },
  reserveBlock: { borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.md, gap: Spacing.md },
  reserveForm: { gap: Spacing.md },
  reserveRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  reserveField: { flex: 1, minWidth: 170 },
  reserveLink: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  closedNote: { color: Palette.amber, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  cancelForm: { marginTop: Spacing.md, gap: Spacing.md, borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.md },
  receipt: { borderRadius: Radius.md, backgroundColor: Palette.greenSoft, borderWidth: 1, borderColor: '#2A6349', padding: Spacing.md, gap: 4 },
  receiptTitle: { color: Palette.green, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.sans, fontSize: 10 },
  receiptEffect: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});
