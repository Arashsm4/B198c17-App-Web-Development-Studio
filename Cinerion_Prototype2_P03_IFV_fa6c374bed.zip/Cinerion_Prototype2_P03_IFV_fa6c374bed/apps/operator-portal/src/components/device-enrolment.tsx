// Enrols a device or service identity. This is how a machine gets its name tag here.

import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { useControlledAction } from '@/api/use-controlled-action';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { CapabilityNotice } from '@/components/capability';
import { Panel, SectionHeading, StatusPill, TextField } from '@/components/primitives';
import { StepUpPrompt } from '@/components/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * Enrols a device or service identity, which is how a machine gets into this system at all.
 *
 * This is the half the portal was missing. Revocation was offered and enrolment was not,
 * so the one role that may withdraw a device's trust could not grant it — and the act
 * that every machine-fed reading ultimately rests on had no interface. It matters more
 * than its size: `POST /test-runs/{id}/measurements` carries `sourceDeviceId`, and a
 * measurement is only attributable because the instrument that produced it was enrolled
 * here first.
 *
 * Three things this deliberately does not do.
 *
 * **It never accepts a private key, and there is no field for one.** The platform is a
 * trust registry, not a certificate authority: it holds no signing key, issues nothing,
 * and CH1-CYB-CSRS-0001 keeps the device's private key non-exportable inside its own
 * secure element. Material arriving here would mean that boundary had already failed.
 *
 * **It never computes the thumbprint.** Control Core derives it from the certificate
 * bytes and says so in the response; a thumbprint a caller supplied would be a caller
 * asserting the identity of its own certificate.
 *
 * **It offers only the origin-bound authenticator.** `access.json` asks for hardware-backed
 * MFA to enrol or revoke a device. The re-authenticate route would produce a grant the
 * server refuses, so it is not offered and the reason is on screen.
 */
export function DeviceEnrolmentPanel({
  accessToken,
  suggestedDeviceId,
  onEnrolled,
}: {
  accessToken: string | undefined;
  /** The device the screen is already looking at, as a starting point the operator may change. */
  suggestedDeviceId?: string;
  onEnrolled: () => void;
}) {
  const [deviceId, setDeviceId] = useState(suggestedDeviceId ?? '');
  const [deviceType, setDeviceType] = useState('CellController');
  const [certificate, setCertificate] = useState('');
  const [firmwareVersion, setFirmwareVersion] = useState('');
  const [configurationRevision, setConfigurationRevision] = useState('R01');
  const [channels, setChannels] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const enrol = useControlledAction<DeviceEnrolmentResult>(accessToken);

  const incomplete =
    deviceId.trim().length === 0 ||
    deviceType.trim().length === 0 ||
    certificate.trim().length === 0 ||
    firmwareVersion.trim().length === 0 ||
    configurationRevision.trim().length === 0;

  /**
   * Channels are written as `channelId:unit` pairs, one per line.
   *
   * A channel with no unit is refused here rather than sent, and that is a SHAPE check
   * rather than a decision: CH1-MON-FR-0001 requires every reading to carry its unit, and
   * a manifest that declared a channel without one would produce readings nobody can
   * interpret. What the channel means, whether the device may publish it, and whether the
   * unit is the right one are all the server's.
   */
  const parsedChannels = channels
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .map((line) => {
      const separator = line.indexOf(':');
      return separator === -1
        ? { channelId: line, unit: '' }
        : { channelId: line.slice(0, separator).trim(), unit: line.slice(separator + 1).trim() };
    });
  const channelsInvalid = parsedChannels.some(
    (channel) => channel.channelId.length === 0 || channel.unit.length === 0,
  );

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (incomplete || channelsInvalid) return;

    const grant = await stepUp.request(StepUpPurpose.DeviceTrust, method);
    if (!grant) return;

    const result = await enrol.submit(
      `/api/v1/devices/${encodeURIComponent(deviceId.trim())}/enrolment`,
      {
        certificate: certificate.trim(),
        schemaVersion: '1.0.0',
        deviceType: deviceType.trim(),
        firmwareVersion: firmwareVersion.trim(),
        configurationRevision: configurationRevision.trim(),
        telemetryChannels: parsedChannels,
        supportedCommands: [],
        securityProfile: 'MutualTls',
      },
      { stepUpGrantId: grant.grantId },
    );
    if (result !== undefined) {
      setCertificate('');
      setAttempted(false);
      stepUp.clear();
      onEnrolled();
    }
  };

  return (
    <Panel>
      <SectionHeading
        eyebrow="CH1-IAM-FR-0008 / CH1-CYB-FR-0002"
        title="Enrol a device or service identity"
        action={<StatusPill label="TRUST REGISTRY" tone="info" />}
      />

      <Text style={styles.body}>
        A device identity is separate from every human account and authenticates with mutual TLS.
        Enrolling one records the certificate this device will present and what it declares it can
        do; it starts nothing and commands nothing.
      </Text>

      <TextField
        label="Device identifier"
        value={deviceId}
        onChangeText={setDeviceId}
        hint="The identity the device presents, such as CH1-DEV-CELL-0001."
        error={attempted && deviceId.trim().length === 0 ? 'Name the device.' : undefined}
        editable={!enrol.pending}
      />
      <TextField
        label="Device type"
        value={deviceType}
        onChangeText={setDeviceType}
        hint="What kind of equipment this is, as the manifest declares it."
        error={attempted && deviceType.trim().length === 0 ? 'A device type is required.' : undefined}
        editable={!enrol.pending}
      />
      <TextField
        label="Firmware version"
        value={firmwareVersion}
        onChangeText={setFirmwareVersion}
        hint="What is actually running on it now."
        error={attempted && firmwareVersion.trim().length === 0 ? 'A firmware version is required.' : undefined}
        editable={!enrol.pending}
      />
      <TextField
        label="Configuration revision"
        value={configurationRevision}
        onChangeText={setConfigurationRevision}
        hint="The controlled revision this device is configured to."
        error={attempted && configurationRevision.trim().length === 0 ? 'A configuration revision is required.' : undefined}
        editable={!enrol.pending}
      />
      <TextField
        label="Telemetry channels"
        value={channels}
        onChangeText={setChannels}
        multiline
        hint="One per line, as channelId:unit — for example CH1-CH-TEMP-01:degC. Every reading must carry its unit, so a channel without one is not sent."
        error={attempted && channelsInvalid ? 'Each line needs channelId:unit.' : undefined}
        editable={!enrol.pending}
      />
      <TextField
        label="Certificate (PEM)"
        value={certificate}
        onChangeText={setCertificate}
        multiline
        hint="The public certificate this device presents. There is no field here for a private key and there never will be: it stays inside the device."
        error={attempted && certificate.trim().length === 0 ? 'The device must present a certificate.' : undefined}
        editable={!enrol.pending}
      />

      <StepUpPrompt
        action={`Enrol ${deviceId.trim() || 'a device'}`}
        consequence="The device is then trusted to present readings and to be addressed on the control network. It grants no human role and starts no equipment."
        stepUp={stepUp}
        onGranted={(method) => void submit(method)}
        // access.json asks for hardware-backed MFA to enrol or revoke a device, which is
        // stronger than the API control column's step-up MFA. The stronger is taken.
        requirePhishingResistant
        disabled={enrol.pending}
      />

      {enrol.error !== undefined ? (
        <CapabilityNotice
          error={enrol.error}
          context={`POST /api/v1/devices/${deviceId.trim()}/enrolment`}
        />
      ) : null}

      {enrol.result !== undefined ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptTitle}>ENROLLED</Text>
          <Text style={styles.receiptLine}>
            {enrol.result.device.deviceId} · {enrol.result.device.trustState}
          </Text>
          <Text style={styles.receiptLine}>
            Thumbprint {enrol.result.certificate.thumbprint}
          </Text>
          {/* Both statements are the server's own, verbatim: one says where the
              thumbprint came from, the other says what this platform never holds. */}
          <Text style={styles.receiptNote}>{enrol.result.certificate.thumbprintSource}</Text>
          <Text style={styles.receiptNote}>{enrol.result.privateKey}</Text>
        </View>
      ) : null}
    </Panel>
  );
}

/**
 * What an enrolment answers with.
 *
 * Only the fields this panel renders, and named exactly as the service sends them.
 * Declared here rather than in `contracts.ts` until `PortalContractFixtureTests` captures
 * a response for it — see defect 48, where four shapes declared on screens were the ones
 * the contract gate could not see.
 */
interface DeviceEnrolmentResult {
  readonly device: { readonly deviceId: string; readonly trustState: string };
  readonly certificate: {
    readonly thumbprint: string;
    readonly subject: string;
    readonly issuer: string;
    readonly thumbprintSource: string;
  };
  readonly privateKey: string;
}

const styles = StyleSheet.create({
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  receipt: {
    marginTop: Spacing.md,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: '#1D4852',
    backgroundColor: '#0B2230',
    padding: Spacing.md,
    gap: 4,
  },
  receiptTitle: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.mono, fontSize: 10 },
  receiptNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 13 },
});
