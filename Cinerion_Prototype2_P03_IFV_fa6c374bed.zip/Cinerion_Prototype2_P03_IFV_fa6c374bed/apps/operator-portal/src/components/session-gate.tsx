// Keeps screens behind a sign-in and tags data by freshness in words and shapes, not just
// colours.

import { StyleSheet, Text, View } from 'react-native';

import { identityConfigured, portalConfig } from '@/api/client';
import type { DataQuality, Freshness } from '@/api/contracts';
import { describeFreshness, describeQuality } from '@/api/freshness';
import { useSession } from '@/auth/session';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';
import { ActionButton, Panel } from './primitives';

/**
 * Freshness indicator. Always renders the state word and a distinct glyph as well as
 * a tone, so the six states remain distinguishable without relying on colour
 * (CH1-MON-FR-0003).
 */
export function FreshnessTag({
  freshness,
  quality,
  detail,
}: {
  freshness: Freshness;
  quality?: DataQuality;
  detail?: string;
}) {
  const shown = describeFreshness(freshness);
  const tones: Record<string, string> = {
    good: Palette.green,
    warning: Palette.amber,
    danger: Palette.red,
    info: Palette.cyan,
    neutral: Palette.inkMuted,
  };
  const colour = tones[shown.tone] ?? Palette.inkMuted;
  const qualityShown = quality ? describeQuality(quality) : undefined;
  return (
    <View style={styles.freshness} accessibilityRole="text">
      <Text style={[styles.freshnessGlyph, { color: colour }]}>{shown.glyph}</Text>
      <Text style={[styles.freshnessLabel, { color: colour }]}>{shown.label}</Text>
      {qualityShown ? <Text style={styles.freshnessQuality}>· QUALITY {qualityShown.label}</Text> : null}
      {detail ? <Text style={styles.freshnessDetail}>· {detail}</Text> : null}
    </View>
  );
}

/**
 * Renders children only for an authenticated session. Every other state is stated
 * explicitly rather than falling back to sample data, so the operator is never shown
 * figures that did not come from Control Core.
 */
export function SessionGate({ children }: { children: React.ReactNode }) {
  const session = useSession();

  if (session.status === 'signed-in') {
    return <>{children}</>;
  }

  return (
    <View style={styles.gate}>
      <Panel style={styles.gatePanel}>
        <Text style={styles.gateEyebrow}>FORTRESSGATE / OIDC</Text>
        <Text style={styles.gateTitle}>
          {session.status === 'unconfigured'
            ? 'Identity provider not configured'
            : session.status === 'ended'
              ? 'Your session ended'
              : 'Authentication required'}
        </Text>

        {/*
          An ended session is not the same event as never having signed in, and saying so
          is the whole point of the distinction. The operator needs to know that work in
          a form they had open is gone, and that nothing they typed was sent. Neither can
          be inferred from "Authentication required".
        */}
        {session.status === 'ended' ? (
          <View style={styles.gateEnded}>
            <Text style={styles.gateEndedTitle}>SESSION ENDED · NOTHING IN PROGRESS WAS SENT</Text>
            <Text style={styles.gateEndedText}>
              The access token expired and could not be renewed, so this tab no longer has a
              session. Any controlled form that was open has been discarded unsent — no
              operation reached Control Core. Signing in again starts a new session.
            </Text>
          </View>
        ) : null}

        {session.status === 'unconfigured' ? (
          <>
            <Text style={styles.gateBody}>
              This build has no OIDC issuer. Set EXPO_PUBLIC_CINERION_OIDC_AUTHORITY and rebuild.
              The portal will not display operational data from an unauthenticated source.
            </Text>
            <Text style={styles.gateMono}>EXPO_PUBLIC_CINERION_API_URL={portalConfig.apiBaseUrl}</Text>
          </>
        ) : (
          <>
            <Text style={styles.gateBody}>
              Sign in with your Cinerion identity. Authorisation is evaluated by Control Core on
              every request; signing in does not by itself grant access to a project or cell.
            </Text>
            <Text style={styles.gateMono}>{portalConfig.oidcIssuer}</Text>
            <View style={styles.gateActions}>
              <ActionButton
                label={
                  session.status === 'signing-in'
                    ? 'CONTACTING PROVIDER…'
                    : session.status === 'ended'
                      ? 'SIGN IN AGAIN'
                      : 'SIGN IN'
                }
                onPress={session.signIn}
                disabled={session.status === 'signing-in' || !identityConfigured}
              />
            </View>
          </>
        )}

        {session.error ? (
          <View style={styles.gateError}>
            <Text style={styles.gateErrorTitle}>
              {session.status === 'ended' ? 'WHY THE SESSION ENDED' : 'SIGN-IN FAILED'}
            </Text>
            <Text style={styles.gateErrorText}>{session.error}</Text>
          </View>
        ) : null}

        <View style={styles.gateNotice}>
          <Text style={styles.gateNoticeCode}>AUTHORITY BOUNDARY</Text>
          <Text style={styles.gateNoticeText}>
            The portal prepares intent only. It cannot provide local credential proof, generate a
            confirmation-button edge, or command equipment.
          </Text>
        </View>
      </Panel>
    </View>
  );
}

const styles = StyleSheet.create({
  gate: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  gatePanel: { width: '100%', maxWidth: 520, gap: Spacing.md },
  gateEyebrow: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  gateTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 22, fontWeight: '800' },
  gateBody: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 12, lineHeight: 19 },
  gateMono: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 10 },
  gateActions: { marginTop: Spacing.sm, flexDirection: 'row' },
  gateEnded: {
    marginTop: Spacing.sm,
    backgroundColor: Palette.amberSoft,
    borderColor: '#5F4521',
    borderWidth: 1,
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: 5,
  },
  gateEndedTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  gateEndedText: { color: '#E2C58F', fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  gateError: {
    marginTop: Spacing.sm,
    backgroundColor: Palette.redSoft,
    borderColor: '#714046',
    borderWidth: 1,
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: 4,
  },
  gateErrorTitle: { color: Palette.red, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  gateErrorText: { color: '#E6B4B6', fontFamily: Type.sans, fontSize: 11, lineHeight: 16 },
  gateNotice: {
    marginTop: Spacing.sm,
    backgroundColor: '#0B2230',
    borderRadius: Radius.md,
    borderLeftWidth: 3,
    borderLeftColor: Palette.teal,
    padding: Spacing.md,
    gap: 5,
  },
  gateNoticeCode: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  gateNoticeText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  freshness: { flexDirection: 'row', alignItems: 'center', gap: 5, flexWrap: 'wrap' },
  freshnessGlyph: { fontFamily: Type.mono, fontSize: 10, fontWeight: '900' },
  freshnessLabel: { fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  freshnessQuality: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, letterSpacing: 0.4 },
  freshnessDetail: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
});
