// Turns a failed read into a sentence a person can act on, instead of a sad empty panel.

import { StyleSheet, Text, View } from 'react-native';

import { CinerionApiError, CinerionUnreachableError } from '@/api/client';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

type Severity = 'gated' | 'refused' | 'disconnected';

interface Explanation {
  readonly severity: Severity;
  readonly title: string;
  readonly body: string;
  readonly code?: string;
}

/**
 * Translates a failed read into what the operator is entitled to conclude.
 *
 * The distinctions matter. A gated capability is a controlled decision that the
 * feature is not enabled. A refusal means this identity may not see the object, and
 * deliberately does not say whether the object exists. Disconnected means the portal
 * does not know the current state at all. None of them may be shown as empty data,
 * because an empty table reads as "there is nothing", which is a different claim.
 */
export function explainFailure(error: unknown): Explanation {
  if (error instanceof CinerionUnreachableError) {
    return {
      severity: 'disconnected',
      title: 'CONTROL CORE UNREACHABLE',
      body: `The portal could not reach Control Core, so the current state is unknown. ${error.message}`,
    };
  }
  if (error instanceof CinerionApiError) {
    if (error.isCapabilityGated) {
      return {
        severity: 'gated',
        title: 'CONTROLLED CAPABILITY NOT ENABLED',
        body: `${error.message} This is a controlled gate, not a failure, and no substitute data is shown.`,
        code: error.code,
      };
    }
    if (error.isUnauthenticated) {
      return {
        severity: 'refused',
        title: 'SESSION NO LONGER ACCEPTED',
        body: 'The access token was rejected. Sign in again to continue.',
        code: error.code,
      };
    }
    if (error.isNotVisible) {
      return {
        severity: 'refused',
        title: 'NOT AVAILABLE TO THIS IDENTITY',
        body: 'Either this object does not exist or this identity may not see it. The API does not distinguish the two, so neither can be inferred here.',
        code: error.code,
      };
    }
    return {
      severity: 'refused',
      title: 'CONTROLLED OPERATION REFUSED',
      body: error.message,
      code: error.code,
    };
  }
  return {
    severity: 'disconnected',
    title: 'UNEXPECTED CLIENT FAILURE',
    body: 'The portal could not complete the read and cannot describe the current state.',
  };
}

const palette: Record<Severity, { border: string; accent: string; background: string }> = {
  gated: { border: '#1B4D58', accent: Palette.cyan, background: '#0A222C' },
  refused: { border: '#5F4521', accent: Palette.amber, background: Palette.amberSoft },
  disconnected: { border: '#714046', accent: Palette.red, background: Palette.redSoft },
};

/** Renders why a panel has no data, instead of rendering an empty table. */
export function CapabilityNotice({ error, context }: { error: unknown; context?: string }) {
  const explanation = explainFailure(error);
  const colours = palette[explanation.severity];
  return (
    <View style={[styles.notice, { borderColor: colours.border, backgroundColor: colours.background }]}>
      <Text style={[styles.title, { color: colours.accent }]}>{explanation.title}</Text>
      <Text style={styles.body}>{explanation.body}</Text>
      {(explanation.code ?? context) ? (
        <Text style={styles.code}>
          {[context, explanation.code].filter(Boolean).join(' · ')}
        </Text>
      ) : null}
    </View>
  );
}

/**
 * States that a panel is not wired to Control Core yet. Distinct from a server-side
 * gate: this is an implementation gap in the portal, not a controlled decision, and
 * saying so plainly is preferable to showing sample figures.
 */
export function NotConnectedNotice({ detail }: { detail: string }) {
  return (
    <View style={[styles.notice, { borderColor: Palette.lineStrong, backgroundColor: Palette.canvasRaised }]}>
      <Text style={[styles.title, { color: Palette.inkMuted }]}>NOT CONNECTED TO CONTROL CORE</Text>
      <Text style={styles.body}>{detail}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  notice: { borderWidth: 1, borderRadius: Radius.md, padding: Spacing.lg, gap: 6, marginTop: Spacing.md },
  title: { fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 16 },
  code: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
});
