// The frame around every screen: rail, header and page intro. Also the reason page titles stay
// horizontal now.

import { useEffect, useState, type PropsWithChildren, type ReactNode } from 'react';
import { router, type Href } from 'expo-router';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import type { ProjectSummary } from '@/api/contracts';
import { useObserved, useWallClock } from '@/api/use-observed';
import { useSession } from '@/auth/session';
import { ContentMaxWidth, Palette, Radius, SidebarWidth, Spacing, Type } from '@/constants/theme';
import { StatusPill } from './primitives';

/**
 * The active workspace comes from the project the identity is scoped to, not from a
 * constant. When no project has been retrieved the shell says so rather than naming
 * a demonstrator it has not confirmed.
 */
function useActiveProject(): ProjectSummary | undefined {
  const session = useSession();
  const projects = useObserved<readonly ProjectSummary[]>('/api/v1/projects', session.accessToken);
  return projects.value?.[0];
}

type NavigationKey =
  | 'operations'
  | 'portfolio'
  | 'control-room'
  | 'command'
  | 'procedure'
  | 'work-orders'
  | 'genealogy'
  | 'calibration'
  | 'field'
  | 'research'
  | 'promotion'
  | 'quality'
  | 'assets'
  | 'devices'
  | 'comms'
  | 'resources'
  | 'collaboration'
  | 'credentials'
  | 'security'
  | 'session'
  | 'engineering'
  | 'audit';

const navigation: readonly { key: NavigationKey; href: Href; code: string; label: string; detail: string }[] = [
  { key: 'operations', href: '/', code: 'OV', label: 'Operations', detail: 'Cross-layer view' },
  { key: 'portfolio', href: '/portfolio', code: 'PP', label: 'Project portfolio', detail: 'Governance and baseline' },
  { key: 'control-room', href: '/control-room', code: 'LC', label: 'Control room', detail: 'Telemetry and alarms' },
  { key: 'command', href: '/command', code: 'CG', label: 'CommandGuard', detail: 'Prepared procedures' },
  { key: 'procedure', href: '/procedure', code: 'AP', label: 'Procedure progress', detail: 'Sequence and hold points' },
  { key: 'work-orders', href: '/work-orders', code: 'FF', label: 'Work orders', detail: 'Revisions and release' },
  { key: 'genealogy', href: '/genealogy', code: 'PG', label: 'Part genealogy', detail: 'Identity and history' },
  { key: 'quality', href: '/quality', code: 'QI', label: 'Quality & inspection', detail: 'Test, NCR, release' },
  { key: 'calibration', href: '/calibration', code: 'AV', label: 'Calibration register', detail: 'Instruments and validity' },
  { key: 'field', href: '/field', code: 'FC', label: 'Field & scan evidence', detail: 'Scanned identity and history' },
  { key: 'assets', href: '/assets', code: 'AV', label: 'Assets & devices', detail: 'Topology and health' },
  { key: 'devices', href: '/devices', code: 'DV', label: 'Devices', detail: 'Trust and configuration' },
  { key: 'comms', href: '/comms', code: 'CH', label: 'Communication health', detail: 'Controller link and quality' },
  { key: 'resources', href: '/resources', code: 'RO', label: 'Resources', detail: 'Capacity and reservations' },
  { key: 'collaboration', href: '/collaboration', code: 'CB', label: 'Collaboration', detail: 'Object-linked messages' },
  { key: 'credentials', href: '/credentials', code: 'FG', label: 'Your authenticators', detail: 'Passkeys and codes' },
  { key: 'security', href: '/security', code: 'SA', label: 'Security administration', detail: 'Identities and credentials' },
  { key: 'session', href: '/session', code: 'SS', label: 'Session', detail: 'Authentication state' },
  { key: 'engineering', href: '/explore', code: 'RB', label: 'Engineering', detail: 'Gates and R&D' },
  { key: 'research', href: '/research', code: 'RW', label: 'R&D workbench', detail: 'Isolated experiments' },
  { key: 'promotion', href: '/promotion', code: 'PR', label: 'Promotion review', detail: 'Impact and verification' },
  { key: 'audit', href: '/audit', code: 'AC', label: 'Audit chain', detail: 'Evidence integrity' },
];

export function AppShell({ active, children }: PropsWithChildren<{ active: NavigationKey }>) {
  const { width } = useWindowDimensions();
  const compact = width < 980;

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'right', 'left']}>
      <View style={[styles.shell, compact && styles.shellCompact]}>
        {compact ? <MobileNavigation active={active} /> : <Sidebar active={active} />}
        <View style={styles.main}>
          <View style={styles.classificationBar}>
            <Text style={styles.classification}>CONFIDENTIAL — PROJECT INTERNAL</Text>
            <Text style={styles.classificationRight}>P03 / IFV · SIMULATION AUTHORITY</Text>
          </View>
          <Header compact={compact} />
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={Platform.OS !== 'web'}>
            <View style={styles.content}>{children}</View>
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
}

export function PageIntro({
  eyebrow,
  title,
  description,
  aside,
}: {
  eyebrow: string;
  title: string;
  description: string;
  aside?: ReactNode;
}) {
  // The title gets a real minimum width and the aside gets told it's allowed to shrink.
  // Before this, a long aside (fifteen roles in one pill, say) won every tug of war and
  // the title came out one letter per line. Now if they can't share a row, the aside
  // politely moves downstairs.
  return (
    <View style={styles.pageIntro}>
      <View style={styles.pageIntroCopy}>
        <Text style={styles.pageEyebrow}>{eyebrow}</Text>
        <Text style={styles.pageTitle}>{title}</Text>
        <Text style={styles.pageDescription}>{description}</Text>
      </View>
      {aside ? <View style={styles.pageIntroAside}>{aside}</View> : null}
    </View>
  );
}

/**
 * The workspace rail.
 *
 * Three regions, and which of them scrolls is a deliberate decision rather than a
 * layout accident. The brand and the active workspace are pinned at the top because
 * they say WHICH plant this window is acting on, and a rail scrolled halfway that no
 * longer names its project is how an operator acts on the wrong cell. The AUTHORITY
 * BOUNDARY card and the signed-in identity are pinned at the bottom for the stronger
 * reason: the card is a safety statement — the portal prepares intent and cannot
 * emulate a credential, a physical edge or the safety chain — and a safety statement
 * that can be scrolled out of reach is not a statement. Only the navigation list
 * between them scrolls.
 *
 * Before this, the whole rail was one unbounded column inside a row whose cross-size
 * is the viewport, so with twenty-two destinations the tail of the list was clipped
 * by the default `overflow: hidden` and simply could not be reached. `flexShrink: 1`
 * and `minHeight: 0` on the scrolling region are both required: without them a flex
 * child refuses to shrink below its content and the ScrollView never gets a bounded
 * height to scroll inside.
 */
function Sidebar({ active }: { active: NavigationKey }) {
  const project = useActiveProject();
  return (
    <View style={styles.sidebar}>
      <View style={styles.sidebarHead}>
        <Brand />
        <View style={styles.projectBlock}>
          <Text style={styles.projectEyebrow}>ACTIVE WORKSPACE</Text>
          <Text style={styles.projectName} numberOfLines={2}>
            {project?.name ?? 'No project retrieved'}
          </Text>
          <View style={styles.projectMeta}>
            <StatusPill label={project?.projectCode ?? 'UNKNOWN'} tone={project ? 'info' : 'neutral'} />
            <Text style={styles.projectBaseline}>{project?.baseline ?? '—'}</Text>
          </View>
        </View>
      </View>
      <ScrollView
        style={styles.sidebarScroll}
        contentContainerStyle={styles.navList}
        showsVerticalScrollIndicator={Platform.OS !== 'web'}>
        {navigation.map((item) => (
          <NavigationItem key={item.key} item={item} selected={item.key === active} />
        ))}
      </ScrollView>
      <View style={styles.sidebarFoot}>
        <View style={styles.boundaryCard}>
          <Text style={styles.boundaryCode}>AUTHORITY BOUNDARY</Text>
          <Text style={styles.boundaryTitle}>Local commit only</Text>
          <Text style={styles.boundaryText}>The portal can prepare intent. It cannot emulate the credential, physical edge, or safety chain.</Text>
        </View>
        <SignedInIdentity />
      </View>
    </View>
  );
}

function MobileNavigation({ active }: { active: NavigationKey }) {
  return (
    <View style={styles.mobileHeader}>
      <Brand compact />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.mobileNavList}>
        {navigation.map((item) => (
          <Pressable
            key={item.key}
            accessibilityRole="link"
            accessibilityState={{ selected: item.key === active }}
            onPress={() => router.push(item.href)}
            style={[styles.mobileNavItem, item.key === active && styles.mobileNavSelected]}>
            <Text style={[styles.mobileNavText, item.key === active && styles.mobileNavTextSelected]}>{item.label}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

/**
 * Shows who is actually signed in, from the token the identity provider issued.
 * Roles are listed as granted; the interface never claims an assurance level, since
 * step-up is evaluated server-side per action and cannot be inferred here.
 */
function SignedInIdentity() {
  const session = useSession();
  const username = session.claims?.preferred_username ?? session.claims?.sub;
  const roles = session.claims?.roles ?? [];
  const signedIn = session.status === 'signed-in' && username !== undefined;

  return (
    <View style={styles.ownerBlock}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>{signedIn ? username!.slice(0, 2).toUpperCase() : '—'}</Text>
      </View>
      <View style={styles.ownerCopy}>
        <Text style={styles.ownerName} numberOfLines={1}>
          {signedIn ? username : 'Not signed in'}
        </Text>
        <Text style={styles.ownerRole} numberOfLines={1}>
          {signedIn ? (roles.length > 0 ? roles.join(', ') : 'No roles granted') : 'No identity'}
        </Text>
      </View>
      {signedIn ? (
        <Pressable accessibilityRole="button" onPress={session.signOut} style={styles.signOut}>
          <Text style={styles.signOutText}>OUT</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <View style={[styles.brand, compact && styles.brandCompact]}>
      <View style={styles.brandMark}>
        <View style={styles.brandMarkInner} />
      </View>
      <View>
        <Text style={styles.brandName}>CINERION</Text>
        <Text style={styles.brandCode}>CH1 CONTROL PLATFORM</Text>
      </View>
    </View>
  );
}

function NavigationItem({ item, selected }: { item: (typeof navigation)[number]; selected: boolean }) {
  return (
    <Pressable
      accessibilityRole="link"
      accessibilityState={{ selected }}
      onPress={() => router.push(item.href)}
      style={({ pressed }) => [styles.navItem, selected && styles.navItemSelected, pressed && styles.navItemPressed]}>
      <View style={[styles.navCode, selected && styles.navCodeSelected]}>
        <Text style={[styles.navCodeText, selected && styles.navCodeTextSelected]}>{item.code}</Text>
      </View>
      <View style={styles.navCopy}>
        <Text style={[styles.navLabel, selected && styles.navLabelSelected]}>{item.label}</Text>
        <Text style={styles.navDetail}>{item.detail}</Text>
      </View>
      {selected ? <View style={styles.navActiveMark} /> : null}
    </Pressable>
  );
}

/**
 * What the header is entitled to say about the session.
 *
 * It used to read SESSION: AUTHENTICATED for as long as a token string existed, which
 * meant it went on saying so after the token had expired — the realm declares no
 * `accessTokenLifespan`, so Keycloak's five-minute default applies — while every screen
 * behind it answered HTTP_401. A header asserting a state the service has already
 * rejected is the same class of error as a portal claiming a physical fact, and it is
 * the one an operator is most likely to believe, because it is the only thing on the
 * page that looks like an answer.
 *
 * So the pill is derived from the token's own expiry as well as from its presence, and
 * it names the three things that are actually different: a session being renewed, one
 * that has ended, and one whose credential is about to be renewed.
 */
function SessionPill() {
  const session = useSession();
  const now = useWallClock();
  const expiresAt = session.lifetime.expiresAt;

  if (session.status === 'ended') {
    return <StatusPill label="SESSION: ENDED" tone="danger" />;
  }
  if (session.status !== 'signed-in') {
    return <StatusPill label="SESSION: NOT AUTHENTICATED" tone="neutral" />;
  }
  if (session.lifetime.refreshing) {
    return <StatusPill label="SESSION: RENEWING" tone="info" />;
  }
  if (expiresAt !== undefined && now !== undefined && expiresAt <= now) {
    // The credential this tab holds has passed its own expiry and no renewal has
    // succeeded yet. Whether FortressGate would still renew it is not known here, and
    // the pill says what IS known rather than guessing either way.
    return <StatusPill label="SESSION: CREDENTIAL EXPIRED" tone="warning" />;
  }
  return <StatusPill label="SESSION: AUTHENTICATED" tone="good" />;
}

function Header({ compact }: { compact: boolean }) {
  const project = useActiveProject();
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <View style={styles.header}>
      <View style={styles.breadcrumbs}>
        <Text style={styles.breadcrumbMuted}>Cinerion</Text>
        <Text style={styles.breadcrumbSlash}>/</Text>
        <Text style={styles.breadcrumbActive}>{project?.name ?? '—'}</Text>
      </View>
      <View style={styles.headerActions}>
        {!compact ? <SessionPill /> : null}
        <View style={styles.headerTime}>
          {/*
            Local browser clock, labelled as such. It is not a qualified or trusted
            time source, and CH1-CYB-FR-0006 requires audit time to be qualified, so
            it must never be presented as one. Server records carry their own
            timestamps and time-quality.
          */}
          <Text style={styles.headerTimeLabel}>LOCAL CLOCK · UNQUALIFIED</Text>
          <Text style={styles.headerTimeValue}>{now.toISOString().slice(11, 19)} UTC</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: Palette.canvas },
  shell: { flex: 1, flexDirection: 'row', backgroundColor: Palette.canvas },
  shellCompact: { flexDirection: 'column' },
  sidebar: {
    width: SidebarWidth,
    // Bounded explicitly rather than relying on the row's cross-axis stretch, so the
    // scrolling region below has a height to be a fraction of on every platform.
    height: '100%',
    flexDirection: 'column',
    backgroundColor: '#081625',
    borderRightWidth: 1,
    borderRightColor: Palette.line,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  sidebarHead: { flexShrink: 0 },
  // flexShrink and minHeight together are what let this region be smaller than its
  // content; a flex child defaults to its content's height and would push the pinned
  // footer off the bottom instead of scrolling.
  sidebarScroll: { flexGrow: 1, flexShrink: 1, minHeight: 0, marginTop: Spacing.lg },
  sidebarFoot: { flexShrink: 0 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 4 },
  brandCompact: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md },
  brandMark: { width: 30, height: 30, borderRadius: 8, borderWidth: 1, borderColor: Palette.teal, alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '45deg' }] },
  brandMarkInner: { width: 12, height: 12, borderWidth: 2, borderColor: Palette.teal, backgroundColor: Palette.tealSoft },
  brandName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 15, fontWeight: '900', letterSpacing: 2 },
  brandCode: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, marginTop: 2, letterSpacing: 0.6 },
  projectBlock: { marginTop: Spacing.xxl, borderTopWidth: 1, borderBottomWidth: 1, borderColor: Palette.line, paddingVertical: Spacing.lg, paddingHorizontal: 4, gap: 7 },
  projectEyebrow: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700', letterSpacing: 1 },
  projectName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 13, fontWeight: '700' },
  projectMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  projectBaseline: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
  navList: { gap: 5, paddingBottom: Spacing.sm },
  navItem: { minHeight: 56, flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, paddingHorizontal: 9, gap: 10, borderWidth: 1, borderColor: 'transparent' },
  navItemSelected: { backgroundColor: '#10283A', borderColor: '#1C4052' },
  navItemPressed: { opacity: 0.72 },
  navCode: { width: 30, height: 30, borderRadius: 8, backgroundColor: Palette.panel, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Palette.line },
  navCodeSelected: { backgroundColor: Palette.tealSoft, borderColor: '#236D69' },
  navCodeText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '800' },
  navCodeTextSelected: { color: Palette.teal },
  navCopy: { flex: 1, gap: 2 },
  navLabel: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 12, fontWeight: '700' },
  navLabelSelected: { color: Palette.ink },
  navDetail: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
  navActiveMark: { position: 'absolute', right: -1, width: 3, height: 24, borderRadius: 2, backgroundColor: Palette.teal },
  boundaryCard: { marginTop: Spacing.lg, backgroundColor: '#0B2230', borderRadius: Radius.md, borderWidth: 1, borderColor: '#1D4852', padding: Spacing.lg, gap: 6 },
  boundaryCode: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  boundaryTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 12, fontWeight: '800' },
  boundaryText: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  ownerBlock: { marginTop: Spacing.lg, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 4 },
  avatar: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: Palette.panelRaised, borderWidth: 1, borderColor: Palette.lineStrong },
  avatarText: { color: Palette.ink, fontFamily: Type.mono, fontSize: 11, fontWeight: '800' },
  ownerCopy: { flex: 1, gap: 2 },
  ownerName: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11, fontWeight: '700' },
  ownerRole: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  signOut: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.sm, borderWidth: 1, borderColor: Palette.lineStrong },
  signOutText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800' },
  main: { flex: 1, minWidth: 0 },
  classificationBar: { height: 25, backgroundColor: '#0C2430', borderBottomWidth: 1, borderBottomColor: '#15404B', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl },
  classification: { color: Palette.teal, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  classificationRight: { color: '#79AEB8', fontFamily: Type.mono, fontSize: 8, letterSpacing: 0.4 },
  header: { minHeight: 64, backgroundColor: Palette.canvasRaised, borderBottomWidth: 1, borderBottomColor: Palette.line, paddingHorizontal: Spacing.xl, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.lg },
  breadcrumbs: { flexDirection: 'row', alignItems: 'center', gap: 8, flexShrink: 1 },
  breadcrumbMuted: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 11 },
  breadcrumbSlash: { color: Palette.lineStrong, fontFamily: Type.mono, fontSize: 11 },
  breadcrumbActive: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11, fontWeight: '700' },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: Spacing.lg },
  headerTime: { alignItems: 'flex-end', gap: 2 },
  headerTimeLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, letterSpacing: 0.8 },
  headerTimeValue: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10 },
  scroll: { flex: 1 },
  scrollContent: { flexGrow: 1, alignItems: 'center' },
  content: { width: '100%', maxWidth: ContentMaxWidth, padding: Spacing.xl, paddingBottom: 80 },
  // flexWrap is the escape hatch; minWidth is the floor the title can never be pushed through.
  pageIntro: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-end', justifyContent: 'space-between', gap: Spacing.xl, marginBottom: Spacing.xl },
  pageIntroCopy: { flexGrow: 1, flexShrink: 1, flexBasis: 420, minWidth: 260, maxWidth: 780, gap: 7 },
  pageIntroAside: { flexShrink: 1, minWidth: 0, maxWidth: '100%' },
  pageEyebrow: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
  pageTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 28, fontWeight: '800', letterSpacing: -0.5 },
  pageDescription: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 12, lineHeight: 18 },
  mobileHeader: { backgroundColor: '#081625', borderBottomWidth: 1, borderBottomColor: Palette.line, gap: 10 },
  mobileNavList: { paddingHorizontal: Spacing.md, paddingBottom: Spacing.md, gap: 6 },
  mobileNavItem: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.pill, backgroundColor: Palette.panel, borderWidth: 1, borderColor: Palette.line },
  mobileNavSelected: { backgroundColor: Palette.tealSoft, borderColor: '#236D69' },
  mobileNavText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, fontWeight: '700' },
  mobileNavTextSelected: { color: Palette.teal },
});
