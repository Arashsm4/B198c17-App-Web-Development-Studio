// Shows a controlled act to whoever owns it and tells everyone else who does. No mystery
// missing buttons.

import { StyleSheet, Text, View } from 'react-native';

import { act as controlledAct, isControlledRole, ownsAct, type ActName } from '@/api/capabilities';
import { useSession } from '@/auth/session';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * Offers a controlled act to an identity that owns it, and NAMES it to one that does not.
 *
 * The naming is the part worth arguing for. A screen that simply omits a control it
 * believes the operator may not use tells them nothing: they cannot tell whether the act
 * exists, whether the screen is broken, or whose job it is. On a shop floor the next step
 * after "I cannot do this" is always "who can", and the controlled documents answer that
 * question exactly - so the answer is put where the control would have been.
 *
 * What this is NOT is a prediction. Holding the role means the control is offered, not
 * that the act will succeed: project scope, cell assignment, authentication strength,
 * equipment state, calibration validity and two-person rules are all the server's to
 * evaluate and several cannot be known here at all. Where an authority is a relationship
 * rather than a role - the owner of a reservation, the recipient of a message - the
 * portal cannot evaluate it and does not try: the control is offered and the server
 * refuses it, verbatim, if the relationship does not hold.
 */
export function ActAuthority({
  act: name,
  children,
}: {
  act: ActName;
  /** The control itself, rendered only when this identity plausibly owns the act. */
  children: React.ReactNode;
}) {
  const session = useSession();
  const act = controlledAct(name);
  const owned = ownsAct(act, session.claims?.roles);

  if (owned) return <>{children}</>;

  // Token order, ours only. Keycloak's `default-roles-cinerion` in the middle of this list
  // made it read like one more authority, and it isn't one.
  const ours = (session.claims?.roles ?? []).filter(isControlledRole);
  const held = ours.length === 0 ? 'no controlled role' : ours.join(', ');

  return (
    <View style={styles.notice}>
      <Text style={styles.code}>ANOTHER ROLE OWNS THIS ACT</Text>
      <Text style={styles.act}>{act.act}</Text>
      <Text style={styles.body}>
        The controlled authority is <Text style={styles.quoted}>{act.authority}</Text>, which this
        platform maps to {act.roles?.join(' or ') ?? 'no role'}. This identity holds {held}.
      </Text>
      <Text style={styles.operation}>{act.operation}</Text>
    </View>
  );
}

/**
 * A compact statement of who owns an act, for a panel that already explains itself.
 *
 * Same purpose as {@link ActAuthority} and no control of its own: used where a screen
 * wants to say what an identity is looking at rather than replace a missing button.
 */
export function ActAuthorityLine({ act: name }: { act: ActName }) {
  const session = useSession();
  const act = controlledAct(name);
  if (ownsAct(act, session.claims?.roles)) return null;
  return (
    <Text style={styles.line}>
      {act.act} — authorised as “{act.authority}”, held here by{' '}
      {act.roles?.join(' or ') ?? 'a relationship rather than a role'}.
    </Text>
  );
}

const styles = StyleSheet.create({
  // This notice stands in for a panel, often inside a row, so it has to size like one:
  // grow into the gap, shrink when crowded, wrap its words. Without these it kept its
  // whole paragraph on one line and walked straight off the right edge of the screen.
  // flexBasis stays 'auto' on purpose - a 0 basis would collapse it inside a column.
  notice: {
    flexGrow: 1,
    flexShrink: 1,
    flexBasis: 'auto',
    minWidth: 0,
    borderWidth: 1,
    borderColor: Palette.lineStrong,
    backgroundColor: Palette.canvasRaised,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginTop: Spacing.md,
    gap: 5,
  },
  code: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  act: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, fontWeight: '700' },
  body: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  quoted: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  operation: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  line: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14, marginTop: Spacing.sm },
});
