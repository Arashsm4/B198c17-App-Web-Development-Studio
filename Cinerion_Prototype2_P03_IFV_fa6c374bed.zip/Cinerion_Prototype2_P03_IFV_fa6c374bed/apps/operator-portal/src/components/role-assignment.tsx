// Where an administrator grants and removes roles. With great power comes a step-up prompt.

import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import type { DirectoryPage, DirectoryUser } from '@/api/contracts';
import { useControlledAction } from '@/api/use-controlled-action';
import { CapabilityNotice } from '@/components/capability';
import { ActionButton, Panel, SectionHeading, StatusPill } from '@/components/primitives';
import { StepUpPrompt } from '@/components/step-up';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * The act the owner called "the admin grants permission": changing which controlled
 * roles an identity holds.
 *
 * `PUT /api/v1/users/{userId}/roles` has been implemented in Control Core, tested and
 * audited for some time, and the portal had no way to issue a PUT at all - so the one
 * operation that decides what every other role in this system may do was reachable only
 * with a command-line HTTP client. That is the gap this closes.
 *
 * Four properties are deliberate and each one is a decision rather than a detail.
 *
 * **It sends the whole set, not a change.** The catalogue's body is the full role list,
 * and the reason is in the endpoint's own comment: two administrators working from the
 * same view must not be able to compose a set neither of them intended. So the chips
 * below start from what the person holds NOW, and what is sent is what is shown.
 *
 * **It never pre-judges segregation.** `RoleSegregation` forbids several combinations -
 * CybersecurityAdministrator beside SystemAdministrator, and beside Inspector - and the
 * portal deliberately does not grey those chips out. The rule belongs to the domain, it
 * is evaluated against the SUBJECT and the ADMINISTRATOR together, and a client that
 * guessed it would eventually guess differently from the server. The refusal is shown
 * verbatim instead, which also makes the boundary visible to whoever pressed the button.
 *
 * **The step-up is phishing-resistant, and not because this file decided so.**
 * `access.json` requires hardware-backed MFA to manage users while `api_endpoints.json`
 * says step-up MFA; that is conflict 10, the stronger of the two controlled requirements
 * is taken, and the server redeems the grant at `StepUpPhishingResistant`. Offering the
 * weaker route here would produce a grant the server refuses, so only the passkey route
 * is offered and the reason is on screen.
 *
 * **It shows what actually changed.** A role change that reported only "saved" would
 * leave an administrator to compare two lists by eye. The response names what was granted
 * and what was withdrawn, and so does this.
 */
export function RoleAssignmentPanel({
  directory,
  accessToken,
  onChanged,
}: {
  /** The identities this project holds, from the read the screen already performs. */
  directory: DirectoryPage | undefined;
  accessToken: string | undefined;
  onChanged: () => void;
}) {
  const [selectedUserId, setSelectedUserId] = useState<string | undefined>(undefined);
  const [roles, setRoles] = useState<readonly string[] | undefined>(undefined);
  const stepUp = useStepUp(accessToken);
  const assign = useControlledAction<RoleAssignmentResult>(accessToken);

  const selected = directory?.items.find((user) => user.userId === selectedUserId);
  // Until a chip is touched, the working set IS what the person holds. Seeding it from
  // the record rather than from an empty array is what makes "send the whole set" safe:
  // an administrator who changes one thing does not silently withdraw everything else.
  const working = roles ?? selected?.roles ?? [];

  const choose = (user: DirectoryUser) => {
    setSelectedUserId(user.userId);
    setRoles(undefined);
    assign.reset();
    stepUp.clear();
  };

  const toggle = (role: string) => {
    setRoles((current) => {
      const base = current ?? selected?.roles ?? [];
      return base.includes(role) ? base.filter((held) => held !== role) : [...base, role];
    });
  };

  const changed =
    selected !== undefined &&
    (working.length !== selected.roles.length ||
      working.some((role) => !selected.roles.includes(role)));

  const submit = async (method: StepUpMethod) => {
    if (!selected || !changed) return;
    const grant = await stepUp.request(StepUpPurpose.RoleAssignment, method);
    if (!grant) return;
    const result = await assign.submit(
      `/api/v1/users/${encodeURIComponent(selected.userId)}/roles`,
      { roles: working },
      { method: 'PUT', stepUpGrantId: grant.grantId },
    );
    if (result !== undefined) {
      setRoles(undefined);
      stepUp.clear();
      onChanged();
    }
  };

  return (
    <Panel>
      <SectionHeading
        eyebrow="CH1-IAM-FR-0004 / CH1-CYB-ACP-0001"
        title="Grant and withdraw controlled roles"
        action={
          <StatusPill
            label={selected ? selected.username.toUpperCase() : 'NO IDENTITY CHOSEN'}
            tone={selected ? 'info' : 'neutral'}
          />
        }
      />

      <Text style={styles.body}>
        A role decides which acts an identity is offered across this portal. The whole set is
        replaced at once, so what is shown below is what will be sent — two administrators
        working from the same view cannot compose a set neither of them intended.
      </Text>

      {directory === undefined ? (
        <Text style={styles.note}>
          The directory has not been retrieved, so there is nobody to choose. The panel above says
          why.
        </Text>
      ) : (
        <View style={styles.people}>
          {directory.items.map((user) => (
            <Pressable
              key={user.userId}
              accessibilityRole="button"
              accessibilityState={{ selected: user.userId === selectedUserId }}
              onPress={() => choose(user)}
              style={({ pressed }) => [
                styles.person,
                user.userId === selectedUserId && styles.personSelected,
                pressed && styles.pressed,
              ]}>
              <Text
                style={[
                  styles.personName,
                  user.userId === selectedUserId && styles.personNameSelected,
                ]}>
                {user.username}
              </Text>
              <Text style={styles.personRoles}>{user.roles.length} roles</Text>
            </Pressable>
          ))}
        </View>
      )}

      {selected ? (
        <>
          <Text style={styles.choiceLabel}>ROLES THIS IDENTITY WILL HOLD</Text>
          <View style={styles.chips}>
            {ASSIGNABLE_ROLES.map((role) => {
              const held = working.includes(role);
              const wasHeld = selected.roles.includes(role);
              return (
                <Pressable
                  key={role}
                  accessibilityRole="button"
                  accessibilityState={{ selected: held }}
                  onPress={() => toggle(role)}
                  style={({ pressed }) => [
                    styles.chip,
                    held && styles.chipHeld,
                    held !== wasHeld && styles.chipChanged,
                    pressed && styles.pressed,
                  ]}>
                  <Text style={[styles.chipText, held && styles.chipTextHeld]}>{role}</Text>
                  {held !== wasHeld ? (
                    <Text style={styles.chipDelta}>{held ? '+' : '−'}</Text>
                  ) : null}
                </Pressable>
              );
            })}
          </View>

          <Text style={styles.note}>
            Some combinations are forbidden by role segregation — a cybersecurity administrator
            may not also be a system administrator or an inspector. Those chips are not greyed out
            here: the rule is evaluated by Control Core against this identity and yours together,
            and a refusal is shown exactly as it is sent.
          </Text>

          <Text style={styles.note}>
            {/*
              DeviceController is absent from the chips above and this says why, rather than
              leaving a reader to notice a role missing from a list of fifteen.
            */}
            DeviceController is not offered. Device accounts authenticate by mutual TLS and
            workload identity, never through the human realm, and CH1-IAM-FR-0008 keeps the two
            apart.
          </Text>

          {changed ? (
            <StepUpPrompt
              action={`Replace the roles held by ${selected.username}`}
              consequence="It takes effect at the identity provider immediately, is recorded against your identity, and changes which controlled acts that person is offered."
              stepUp={stepUp}
              onGranted={(method) => void submit(method)}
              // access.json requires hardware-backed MFA for user management, which is
              // stronger than the API control column's "step-up MFA". Conflict 10; the
              // stronger is taken, so the re-authenticate route is not offered at all
              // rather than offered and refused.
              requirePhishingResistant
              disabled={assign.pending}
            />
          ) : (
            <View style={styles.actions}>
              <ActionButton label="NO CHANGE TO SEND" onPress={() => undefined} disabled />
            </View>
          )}
        </>
      ) : null}

      {assign.error !== undefined ? (
        <CapabilityNotice error={assign.error} context="PUT /api/v1/users/{userId}/roles" />
      ) : null}

      {assign.result !== undefined ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptTitle}>ROLES REPLACED</Text>
          <Text style={styles.receiptLine}>
            {assign.result.username} now holds {assign.result.roles.join(', ') || 'no roles'}.
          </Text>
          <Text style={styles.receiptNote}>
            Granted {assign.result.granted.join(', ') || 'nothing'} · withdrawn{' '}
            {assign.result.withdrawn.join(', ') || 'nothing'} · previously{' '}
            {assign.result.previousRoles.join(', ') || 'no roles'}
          </Text>
          {assign.result.segregation.incompatiblePairs.length > 0 ? (
            <Text style={styles.receiptNote}>
              Segregation rules this platform enforces:{' '}
              {assign.result.segregation.incompatiblePairs
                .map((pair) => `${pair.first} ≠ ${pair.second}`)
                .join(' · ')}
            </Text>
          ) : null}
        </View>
      ) : null}
    </Panel>
  );
}

/**
 * What the response to a role replacement carries.
 *
 * Declared here rather than in `contracts.ts` only until the contract gate has a captured
 * response for it; `npm run contracts:portal` compares every declared shape against what
 * the service really sends, and a shape declared on a screen is one that gate cannot see.
 * See defect 48, which was exactly this.
 */
interface RoleAssignmentResult {
  readonly userId: string;
  readonly username: string;
  /** What the person held before. CH1-MGT-FR-0003 wants a change reversible to a known state. */
  readonly previousRoles: readonly string[];
  readonly roles: readonly string[];
  readonly granted: readonly string[];
  readonly withdrawn: readonly string[];
  /**
   * The segregation rules, as the SERVER states them.
   *
   * Shown rather than restated, for the reason a refusal is shown verbatim: a client that
   * wrote its own copy of "a cybersecurity administrator may not also be an inspector"
   * would eventually disagree with the rule actually being enforced, and the operator
   * would be reading the disagreement rather than the rule.
   */
  readonly segregation: {
    readonly securityPolicyRolesWithheld: readonly string[];
    readonly incompatiblePairs: readonly { readonly first: string; readonly second: string; readonly reason: string }[];
  };
}

/**
 * The roles an administrator may assign to a person.
 *
 * Fifteen of the sixteen `CinerionRoles` declares. `DeviceController` is deliberately
 * absent: CH1-IAM-FR-0008 keeps device accounts off the human realm entirely, so offering
 * it here would be offering an authority the identity provider cannot hold.
 */
const ASSIGNABLE_ROLES: readonly string[] = [
  'Viewer',
  'Auditor',
  'Engineer',
  'AutomationEngineer',
  'Inspector',
  'LocalConfirmer',
  'MaintenanceEngineer',
  'OperationsCoordinator',
  'ProjectManager',
  'ConfigurationManager',
  'RDEngineer',
  'DocumentController',
  'CybersecurityAdministrator',
  'SystemAdministrator',
  'ProjectOwner',
];

const styles = StyleSheet.create({
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 17 },
  note: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  people: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: Spacing.sm },
  person: {
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: Radius.sm,
    borderWidth: 1,
    borderColor: Palette.line,
    backgroundColor: Palette.panel,
    gap: 2,
  },
  personSelected: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  personName: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 10, fontWeight: '700' },
  personNameSelected: { color: Palette.teal },
  personRoles: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8 },
  choiceLabel: {
    color: Palette.inkMuted,
    fontFamily: Type.mono,
    fontSize: 8,
    fontWeight: '900',
    letterSpacing: 0.8,
    marginTop: Spacing.md,
  },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Palette.line,
    backgroundColor: Palette.panel,
  },
  chipHeld: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  chipChanged: { borderColor: Palette.amber },
  chipText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  chipTextHeld: { color: Palette.teal },
  chipDelta: { color: Palette.amber, fontFamily: Type.mono, fontSize: 10, fontWeight: '900' },
  actions: { flexDirection: 'row', marginTop: Spacing.md },
  pressed: { opacity: 0.72 },
  receipt: {
    marginTop: Spacing.md,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: '#1D4852',
    backgroundColor: '#0B2230',
    padding: Spacing.md,
    gap: 4,
  },
  receiptTitle: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11 },
  receiptNote: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, lineHeight: 12 },
});
