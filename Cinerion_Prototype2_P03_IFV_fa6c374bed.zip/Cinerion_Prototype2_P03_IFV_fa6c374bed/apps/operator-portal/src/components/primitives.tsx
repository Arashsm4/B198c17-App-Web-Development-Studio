// The small building blocks: panels, pills, headings and buttons. Lego for the control room.

import { useState, type PropsWithChildren, type ReactNode } from 'react';
import {
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';

import { Palette, Radius, Spacing, Type } from '@/constants/theme';
import type { SemanticVocabulary } from '@/constants/semantics';
import type { StatusTone } from '@/constants/status';

export function Panel({ children, style }: PropsWithChildren<{ style?: StyleProp<ViewStyle> }>) {
  return <View style={[styles.panel, style]}>{children}</View>;
}

export function SectionHeading({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <View style={styles.sectionHeading}>
      <View style={styles.headingCopy}>
        {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
      {action}
    </View>
  );
}

const tones: Record<StatusTone, { foreground: string; background: string; dot: string }> = {
  good: { foreground: Palette.green, background: Palette.greenSoft, dot: Palette.green },
  warning: { foreground: Palette.amber, background: Palette.amberSoft, dot: Palette.amber },
  danger: { foreground: Palette.red, background: Palette.redSoft, dot: Palette.red },
  info: { foreground: Palette.cyan, background: Palette.tealSoft, dot: Palette.cyan },
  neutral: { foreground: Palette.inkSoft, background: Palette.panelRaised, dot: Palette.inkMuted },
};

export function StatusPill({ label, tone = 'neutral' }: { label: string; tone?: StatusTone }) {
  const colors = tones[tone];
  return (
    <View style={[styles.pill, { backgroundColor: colors.background }]}>
      <View style={[styles.pillDot, { backgroundColor: colors.dot }]} />
      <Text style={[styles.pillText, { color: colors.foreground }]}>{label}</Text>
    </View>
  );
}

export function KpiCard({
  label,
  value,
  note,
  tone = 'info',
}: {
  label: string;
  value: string;
  note: string;
  tone?: StatusTone;
}) {
  const colors = tones[tone];
  return (
    <Panel style={styles.kpi}>
      <View style={[styles.kpiMark, { backgroundColor: colors.dot }]} />
      <Text style={styles.kpiLabel}>{label}</Text>
      <Text style={styles.kpiValue}>{value}</Text>
      <Text style={styles.kpiNote}>{note}</Text>
    </Panel>
  );
}

export function KeyValue({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <View style={styles.keyValue}>
      <Text style={styles.keyLabel}>{label}</Text>
      <Text style={[styles.keyText, mono && styles.mono]} selectable={mono}>
        {value}
      </Text>
    </View>
  );
}

export function ActionButton({
  label,
  onPress,
  kind = 'primary',
  disabled = false,
}: {
  label: string;
  onPress?: () => void;
  kind?: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
}) {
  const buttonStyle = kind === 'primary' ? styles.buttonPrimary : kind === 'danger' ? styles.buttonDanger : styles.buttonSecondary;
  const textStyle = kind === 'primary' ? styles.buttonPrimaryText : kind === 'danger' ? styles.buttonDangerText : styles.buttonSecondaryText;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [styles.button, buttonStyle, pressed && !disabled && styles.pressed, disabled && styles.disabled]}>
      <Text style={[styles.buttonText, textStyle]}>{label}</Text>
    </Pressable>
  );
}

export function Divider() {
  return <View style={styles.divider} />;
}

/**
 * The iconography half of the alarm/message separation CH1-UXD-DSG-0001 requires.
 *
 * Shape and letterform carry the distinction, not colour: an alarm mark has square
 * corners and a heavy border, a message mark is a borderless pill. The accessible
 * label spells the noun out, so a screen reader announces "Alarm" or "Message" rather
 * than three letters.
 */
export function SemanticMark({
  vocabulary,
  suffix,
  tone = 'neutral',
}: {
  vocabulary: SemanticVocabulary;
  /** Appended inside the mark, e.g. an alarm priority. */
  suffix?: string;
  tone?: StatusTone;
}) {
  const colors = tones[tone];
  const square = vocabulary.shape === 'square';
  return (
    <View
      accessibilityRole="text"
      accessibilityLabel={`${vocabulary.noun}${suffix ? ` ${suffix}` : ''}`}
      style={[
        styles.mark,
        square ? styles.markSquare : styles.markPill,
        { backgroundColor: colors.background, borderColor: square ? colors.dot : 'transparent' },
      ]}>
      <Text style={[styles.markText, { color: colors.foreground }]}>
        {suffix ? `${vocabulary.mark} ${suffix}` : vocabulary.mark}
      </Text>
    </View>
  );
}

/**
 * A labelled text control that validates inline and never discards what was typed.
 *
 * CH1-UXD-DSG-0001 requires forms to "validate inline and preserve entered work on
 * recoverable failure", so the value is owned by the caller and this component holds
 * none of it. The remaining-characters count is shown from the point it starts to
 * matter rather than always, so it reads as a warning and not as decoration.
 */
export function TextField({
  label,
  value,
  onChangeText,
  placeholder,
  hint,
  error,
  maxLength,
  multiline = false,
  editable = true,
}: {
  label: string;
  value: string;
  onChangeText: (next: string) => void;
  placeholder?: string;
  hint?: string;
  /** Inline validation message. Rendered with a text marker as well as a tone. */
  error?: string;
  maxLength?: number;
  multiline?: boolean;
  editable?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const remaining = maxLength === undefined ? undefined : maxLength - value.length;
  const nearLimit = remaining !== undefined && remaining <= Math.max(20, maxLength! * 0.1);

  return (
    <View style={styles.field}>
      <View style={styles.fieldHeader}>
        <Text style={styles.fieldLabel}>{label}</Text>
        {nearLimit ? (
          <Text style={[styles.fieldCount, remaining! <= 0 && styles.fieldCountSpent]}>
            {remaining} LEFT
          </Text>
        ) : null}
      </View>
      <TextInput
        accessibilityLabel={label}
        accessibilityHint={hint}
        editable={editable}
        maxLength={maxLength}
        multiline={multiline}
        onBlur={() => setFocused(false)}
        onChangeText={onChangeText}
        onFocus={() => setFocused(true)}
        placeholder={placeholder}
        placeholderTextColor={Palette.inkMuted}
        style={[
          styles.input,
          multiline && styles.inputMultiline,
          focused && styles.inputFocused,
          error !== undefined && styles.inputInvalid,
          !editable && styles.disabled,
        ]}
        value={value}
      />
      {error !== undefined ? (
        <Text style={styles.fieldError} accessibilityRole="alert">
          ✕ {error}
        </Text>
      ) : hint ? (
        <Text style={styles.fieldHint}>{hint}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    backgroundColor: Palette.panel,
    borderColor: Palette.line,
    borderWidth: 1,
    borderRadius: Radius.lg,
    padding: Spacing.xl,
  },
  // Same deal as the page intro: the heading may wrap, the action may drop below it, and
  // neither gets to crush the other into a column of single letters.
  sectionHeading: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  headingCopy: { flexShrink: 1, minWidth: 180, gap: 3 },
  eyebrow: {
    color: Palette.teal,
    fontFamily: Type.mono,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  sectionTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 18, fontWeight: '700' },
  // Short pills hold their shape (nobody wants "1" and "LISTED" on separate lines), but no
  // pill may ever be wider than its container. A long label wraps inside instead of
  // shoving the neighbours off a cliff, which is what the fifteen-role pill did.
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    alignSelf: 'flex-start',
    maxWidth: '100%',
    borderRadius: Radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  pillDot: { width: 6, height: 6, borderRadius: 3 },
  pillText: { flexShrink: 1, fontFamily: Type.sans, fontSize: 11, fontWeight: '700', letterSpacing: 0.2 },
  kpi: { minWidth: 180, flex: 1, padding: Spacing.lg, overflow: 'hidden' },
  kpiMark: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 3 },
  kpiLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 11, fontWeight: '700', letterSpacing: 0.7, textTransform: 'uppercase' },
  kpiValue: { color: Palette.ink, fontFamily: Type.sans, fontSize: 29, fontWeight: '700', marginTop: 10 },
  kpiNote: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 12, marginTop: 5, lineHeight: 17 },
  keyValue: { gap: 4 },
  keyLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, fontWeight: '700', letterSpacing: 0.6, textTransform: 'uppercase' },
  keyText: { color: Palette.ink, fontFamily: Type.sans, fontSize: 13, lineHeight: 19 },
  mono: { fontFamily: Type.mono, fontSize: 12 },
  button: { minHeight: 42, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.lg, borderWidth: 1 },
  buttonPrimary: { backgroundColor: Palette.teal, borderColor: Palette.teal },
  buttonSecondary: { backgroundColor: Palette.panelRaised, borderColor: Palette.lineStrong },
  buttonDanger: { backgroundColor: Palette.redSoft, borderColor: '#714046' },
  buttonText: { fontFamily: Type.sans, fontSize: 13, fontWeight: '800' },
  buttonPrimaryText: { color: '#03201D' },
  buttonSecondaryText: { color: Palette.ink },
  buttonDangerText: { color: Palette.red },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
  disabled: { opacity: 0.42 },
  divider: { height: 1, backgroundColor: Palette.line, width: '100%' },
  mark: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 4, borderWidth: 2 },
  markSquare: { borderRadius: 3 },
  markPill: { borderRadius: Radius.pill, borderWidth: 0, paddingHorizontal: 10 },
  markText: { fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.9 },
  field: { gap: 6 },
  fieldHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.sm },
  fieldLabel: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, fontWeight: '700', letterSpacing: 0.6, textTransform: 'uppercase' },
  fieldCount: { color: Palette.amber, fontFamily: Type.mono, fontSize: 8, fontWeight: '800' },
  fieldCountSpent: { color: Palette.red },
  input: {
    minHeight: 42,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Palette.lineStrong,
    backgroundColor: '#08131F',
    color: Palette.ink,
    fontFamily: Type.sans,
    fontSize: 12,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  inputMultiline: { minHeight: 84, textAlignVertical: 'top' },
  // A visible focus ring, not only a colour shift: CH1-UXD-DSG-0001 requires focus
  // visibility, and a keyboard user needs to see where they are.
  inputFocused: { borderColor: Palette.teal, borderWidth: 2, paddingHorizontal: Spacing.md - 1 },
  inputInvalid: { borderColor: Palette.red },
  fieldError: { color: Palette.red, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  fieldHint: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});

