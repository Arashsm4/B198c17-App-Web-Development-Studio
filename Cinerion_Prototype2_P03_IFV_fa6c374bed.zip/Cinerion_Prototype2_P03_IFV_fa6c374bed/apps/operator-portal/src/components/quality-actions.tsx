// The quality loop as buttons: measure, hold, NCR, retest, release. In that order, no
// shortcuts.

import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { CinerionApiError } from '@/api/client';
import type { CalibrationEntry, PartRecord, QualityMeasurement } from '@/api/contracts';
import { useControlledAction } from '@/api/use-controlled-action';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { ActionButton, Divider, TextField } from '@/components/primitives';
import { StepUpPrompt } from '@/components/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * The controlled quality loop, as acts rather than as a report.
 *
 * CH1-QMS-FR-0002 and CH1-QMS-FR-0006 put the whole of it behind evidence: a measurement
 * carries its unit, its limits, its source device and its calibration context, a failed
 * mandatory result HOLDS the physical part, and the hold is only lifted by a controlled
 * disposition and a passing retest. This screen showed all of that and could perform none
 * of it, which made the part's state something that happened to an operator rather than
 * something they did.
 *
 * Nothing here decides an outcome. Limits are the caller's declaration of what the
 * controlled characteristic requires, and the SERVER evaluates the value against them,
 * holds the part, and refuses a release while an NCR is open. The portal never computes
 * pass or fail, and never shows one it computed.
 */

/** A shared refusal panel: the server's own code and detail, never a rephrasing. */
function Refusal({ error }: { error: unknown }) {
  const refusal = error instanceof CinerionApiError ? error : undefined;
  if (!refusal) return null;
  return (
    <View style={styles.refusal}>
      <Text style={styles.refusalCode}>{refusal.code}</Text>
      <Text style={styles.refusalText}>{refusal.message}</Text>
    </View>
  );
}

function Expander({
  label,
  open,
  onPress,
}: {
  label: string;
  open: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ expanded: open }}
      onPress={onPress}
      style={({ pressed }) => [styles.expandRow, pressed && styles.pressed]}>
      <Text style={styles.expandText}>{open ? `▾ CLOSE` : `▸ ${label}`}</Text>
    </Pressable>
  );
}

/**
 * Records one acceptance measurement against a controlled test run.
 *
 * A measurement needs a RUN, and a run needs a procedure — a number with no procedure
 * behind it is not evidence. So this opens a run when none is held and records against
 * it, rather than inventing a measurement that belongs to nothing.
 *
 * `supersedesMeasurementId` is what makes a retest a retest instead of a second opinion:
 * the superseded result stays in the record, and the part's state moves on the new one.
 */
export function RecordMeasurement({
  part,
  calibrations,
  accessToken,
  onRecorded,
}: {
  part: PartRecord | undefined;
  /**
   * The instrument calibrations this identity can see, from the owner-approved read the
   * calibration register already uses. A measurement must name the calibration record its
   * instrument was covered by — CH1-QMS-FR-0006 refuses a result from an instrument whose
   * calibration is not valid, and the server decides that from the RECORD. Sending a
   * made-up identifier would be refused, and sending none would not compile the intent at
   * all, so the operator picks from what actually exists.
   */
  calibrations: readonly CalibrationEntry[];
  accessToken: string | undefined;
  onRecorded: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [characteristic, setCharacteristic] = useState('Coating thickness');
  const [value, setValue] = useState('');
  const [unit, setUnit] = useState('um');
  const [lower, setLower] = useState('9.50');
  const [upper, setUpper] = useState('10.50');
  const [procedureId, setProcedureId] = useState('CH1-REFAB-PROC-0001');
  const [procedureRevision, setProcedureRevision] = useState('R01');
  const [supersedes, setSupersedes] = useState('');
  const [calibrationId, setCalibrationId] = useState('');
  const [attempted, setAttempted] = useState(false);
  const chosenCalibration = calibrationId || calibrations[0]?.calibrationId || '';
  const startRun = useControlledAction<{ testRunId: string }>(accessToken);
  const measure = useControlledAction<{ measurement: QualityMeasurement }>(accessToken);

  const numeric = (raw: string) => {
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : undefined;
  };
  const reading = numeric(value);
  const low = numeric(lower);
  const high = numeric(upper);
  const invalid =
    characteristic.trim().length === 0 ||
    reading === undefined ||
    low === undefined ||
    high === undefined ||
    high <= low ||
    unit.trim().length === 0 ||
    procedureId.trim().length === 0 ||
    chosenCalibration.length === 0;

  const submit = async () => {
    setAttempted(true);
    if (invalid || !part) return;

    // One run per recording session. The server links the measurement to it, and a
    // measurement with no run is refused rather than stored loose.
    const run = await startRun.submit('/api/v1/test-runs', {
      partId: part.partId,
      procedureId: procedureId.trim(),
      procedureRevision: procedureRevision.trim(),
    });
    if (!run) return;

    const recorded = await measure.submit(`/api/v1/test-runs/${run.testRunId}/measurements`, {
      partId: part.partId,
      characteristic: characteristic.trim(),
      value: reading,
      unit: unit.trim(),
      lowerLimit: low,
      upperLimit: high,
      mandatory: true,
      // The instrument and its calibration travel with the reading. CH1-QMS-FR-0006
      // refuses a result from an instrument whose calibration is not valid, and the
      // server decides that from the record rather than from this flag.
      sourceDeviceId: 'CH1-DEV-CELL-0001',
      calibrationRecordId: chosenCalibration,
      // What the caller believes about the instrument. The server does not take this on
      // trust: it reads the calibration record named above and refuses an expired one,
      // which is what made client-asserted calibration defect 14.
      calibrationValid: true,
      supersedesMeasurementId: supersedes.trim().length > 0 ? supersedes.trim() : null,
    });

    if (recorded) {
      setValue('');
      setSupersedes('');
      setAttempted(false);
      setOpen(false);
      onRecorded();
    }
  };

  if (!part) return null;

  return (
    <View>
      <Expander label="RECORD A MEASUREMENT" open={open} onPress={() => setOpen((p) => !p)} />
      {open ? (
        <View style={styles.form}>
          <View style={styles.row}>
            <View style={styles.field}>
              <TextField label="Characteristic" value={characteristic} onChangeText={setCharacteristic} />
            </View>
            <View style={styles.fieldNarrow}>
              <TextField label="Unit" value={unit} onChangeText={setUnit} />
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.fieldNarrow}>
              <TextField
                label="Reading"
                value={value}
                onChangeText={setValue}
                error={attempted && reading === undefined ? 'A number is required.' : undefined}
              />
            </View>
            <View style={styles.fieldNarrow}>
              <TextField label="Lower limit" value={lower} onChangeText={setLower} />
            </View>
            <View style={styles.fieldNarrow}>
              <TextField
                label="Upper limit"
                value={upper}
                onChangeText={setUpper}
                error={attempted && low !== undefined && high !== undefined && high <= low
                  ? 'The upper limit must exceed the lower.'
                  : undefined}
              />
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.field}>
              <TextField label="Procedure" value={procedureId} onChangeText={setProcedureId} />
            </View>
            <View style={styles.fieldNarrow}>
              <TextField label="Revision" value={procedureRevision} onChangeText={setProcedureRevision} />
            </View>
          </View>
          <TextField
            label="Instrument calibration record"
            value={chosenCalibration}
            onChangeText={setCalibrationId}
            error={attempted && chosenCalibration.length === 0
              ? 'A measurement must name the calibration its instrument was covered by.'
              : undefined}
            hint={calibrations.length > 0
              ? `${calibrations.length} calibration record(s) visible to this identity`
              : 'No calibration records retrieved. The server will refuse a measurement without one.'}
          />
          <TextField
            label="Supersedes measurement (optional)"
            value={supersedes}
            onChangeText={setSupersedes}
            hint="A retest names the result it replaces. The superseded reading stays in the record."
          />

          <View style={styles.boundary}>
            <Text style={styles.boundaryTitle}>THE SERVER DECIDES THE OUTCOME</Text>
            <Text style={styles.boundaryText}>
              This records a reading and its limits. Whether it passes, whether the part is held,
              and whether an NCR is required are evaluated by Control Core against the controlled
              characteristic. Nothing here computes a result.
            </Text>
          </View>

          <ActionButton
            label={measure.pending || startRun.pending ? 'RECORDING…' : 'RECORD MEASUREMENT'}
            onPress={() => void submit()}
            disabled={measure.pending || startRun.pending}
          />
          <Refusal error={startRun.error ?? measure.error} />
        </View>
      ) : null}
    </View>
  );
}

/** Raises a non-conformance against the part. No step-up: raising is not a disposition. */
export function RaiseNcr({
  part,
  accessToken,
  onRaised,
}: {
  part: PartRecord | undefined;
  accessToken: string | undefined;
  onRaised: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [attempted, setAttempted] = useState(false);
  const raise = useControlledAction<{ ncrId: string }>(accessToken);
  const invalid = title.trim().length === 0 || description.trim().length === 0;

  const submit = async () => {
    setAttempted(true);
    if (invalid || !part) return;
    const raised = await raise.submit('/api/v1/ncrs', {
      partId: part.partId,
      title: title.trim(),
      description: description.trim(),
    });
    if (raised) {
      setTitle('');
      setDescription('');
      setAttempted(false);
      setOpen(false);
      onRaised();
    }
  };

  if (!part) return null;

  return (
    <View>
      <Expander label="RAISE A NON-CONFORMANCE" open={open} onPress={() => setOpen((p) => !p)} />
      {open ? (
        <View style={styles.form}>
          <TextField
            label="Title"
            value={title}
            onChangeText={setTitle}
            error={attempted && title.trim().length === 0 ? 'A title is required.' : undefined}
          />
          <TextField
            label="Description"
            value={description}
            onChangeText={setDescription}
            multiline
            error={
              attempted && description.trim().length === 0
                ? 'Describe what was observed. This is retained.'
                : undefined
            }
          />
          <ActionButton
            label={raise.pending ? 'RAISING…' : 'RAISE NCR'}
            onPress={() => void submit()}
            disabled={raise.pending}
          />
          <Refusal error={raise.error} />
        </View>
      ) : null}
    </View>
  );
}

const DISPOSITIONS = ['Rework', 'UseAsIs', 'Scrap', 'Close'] as const;

/**
 * Dispositions one open NCR.
 *
 * Step-up for the purpose NcrDisposition alone: this decides what happens to a physical
 * part that a measurement has held, and CH1-QMS-FR-0004 makes it an attributable act. A
 * grant issued for a reservation cannot authorise it.
 */
export function DispositionNcr({
  ncrId,
  accessToken,
  onDisposed,
}: {
  ncrId: string;
  accessToken: string | undefined;
  onDisposed: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [disposition, setDisposition] = useState<(typeof DISPOSITIONS)[number]>('Rework');
  const [justification, setJustification] = useState('');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const dispose = useControlledAction<{ partStatus: string }>(accessToken);
  const invalid = justification.trim().length === 0;

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (invalid) return;
    const grant = await stepUp.request(StepUpPurpose.NcrDisposition, method);
    if (!grant) return;
    const disposed = await dispose.submit(
      `/api/v1/ncrs/${ncrId}/dispositions`,
      { disposition, justification: justification.trim() },
      { stepUpGrantId: grant.grantId },
    );
    if (disposed) {
      setJustification('');
      setAttempted(false);
      setOpen(false);
      stepUp.clear();
      onDisposed();
    }
  };

  return (
    <View style={styles.ncrAction}>
      <Expander label="DISPOSITION" open={open} onPress={() => setOpen((p) => !p)} />
      {open ? (
        <View style={styles.form}>
          <View style={styles.chips}>
            {DISPOSITIONS.map((kind) => {
              const active = kind === disposition;
              return (
                <Pressable
                  key={kind}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                  onPress={() => setDisposition(kind)}
                  style={({ pressed }) => [
                    styles.chip,
                    active && styles.chipActive,
                    pressed && styles.pressed,
                  ]}>
                  <Text style={[styles.chipText, active && styles.chipTextActive]}>
                    {kind.toUpperCase()}
                  </Text>
                </Pressable>
              );
            })}
          </View>
          <TextField
            label="Justification"
            value={justification}
            onChangeText={setJustification}
            multiline
            error={
              attempted && invalid
                ? 'A disposition is attributable. State the basis for it.'
                : undefined
            }
            hint="Retained on the NCR and in the audit chain."
          />
          <StepUpPrompt
            action={`disposition this non-conformance as ${disposition}`}
            consequence="The part's controlled status moves on this decision, and the record is permanent."
            stepUp={stepUp}
            onGranted={submit}
            disabled={dispose.pending}
          />
          <Refusal error={dispose.error} />
        </View>
      ) : null}
    </View>
  );
}

/**
 * Releases the physical part.
 *
 * Phishing-resistant step-up, for PartRelease alone. CH1-QMS-FR-0005 makes release an
 * INDEPENDENT act — the server refuses a releaser who is the part's own operator, and
 * refuses any release while an NCR stands or a mandatory measurement has not passed.
 * None of that is decided here; the button simply asks.
 */
export function ReleasePart({
  part,
  accessToken,
  onReleased,
}: {
  part: PartRecord | undefined;
  accessToken: string | undefined;
  onReleased: () => void;
}) {
  const [open, setOpen] = useState(false);
  const stepUp = useStepUp(accessToken);
  const release = useControlledAction<unknown>(accessToken);

  const submit = async (method: StepUpMethod) => {
    if (!part) return;
    const grant = await stepUp.request(StepUpPurpose.PartRelease, method);
    if (!grant) return;
    const released = await release.submit(
      '/api/v1/release-records',
      { partId: part.partId },
      { stepUpGrantId: grant.grantId },
    );
    if (released !== undefined) {
      setOpen(false);
      stepUp.clear();
      onReleased();
    }
  };

  if (!part) return null;

  if (part.release) {
    return (
      <Text style={styles.note}>
        Released by {part.release.inspectorId}. A release is permanent and is not repeated.
      </Text>
    );
  }

  return (
    <View>
      <Divider />
      <Expander label="RELEASE THIS PART" open={open} onPress={() => setOpen((p) => !p)} />
      {open ? (
        <View style={styles.form}>
          {part.openNcrIds.length > 0 ? (
            <Text style={styles.warn}>
              {part.openNcrIds.length} non-conformance(s) stand against this part. The server will
              refuse a release while any remains open, and that refusal is the control working.
            </Text>
          ) : null}
          <View style={styles.boundary}>
            <Text style={styles.boundaryTitle}>RELEASE IS INDEPENDENT</Text>
            <Text style={styles.boundaryText}>
              An identity may not release a part it built. The server checks that, the evidence
              completeness and every open non-conformance, and refuses rather than warns.
            </Text>
          </View>
          <StepUpPrompt
            action={`release part ${part.serialNumber}`}
            consequence="The part becomes Released, and the record is permanent and immutable."
            stepUp={stepUp}
            onGranted={submit}
            requirePhishingResistant
            disabled={release.pending}
          />
          <Refusal error={release.error} />
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  form: { gap: Spacing.md, marginTop: Spacing.md },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  field: { flex: 1, minWidth: 180 },
  fieldNarrow: { flexGrow: 1, minWidth: 96 },
  expandRow: { borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.md, marginTop: Spacing.md },
  expandText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  pressed: { opacity: 0.72 },
  note: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14, marginTop: Spacing.md },
  warn: { color: Palette.amber, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  boundary: { borderRadius: Radius.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#6B5227', padding: Spacing.md, gap: 6 },
  boundaryTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  boundaryText: { color: '#D9BD8C', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  refusal: { borderRadius: Radius.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#714046', padding: Spacing.md, gap: 4 },
  refusalCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 10, fontWeight: '900', letterSpacing: 0.6 },
  refusalText: { color: '#D9A6A8', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.pill, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.panel },
  chipActive: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  chipText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  chipTextActive: { color: Palette.teal },
  ncrAction: { marginTop: 4 },
});
