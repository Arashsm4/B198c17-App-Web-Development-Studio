// The re-authentication prompt: here's what you're about to do, now prove it's you.

import { StyleSheet, Text, View } from 'react-native';

import { CinerionApiError } from '@/api/client';
import type { StepUpGrant } from '@/api/contracts';
import { instant } from '@/api/format';
import { useSession } from '@/auth/session';
import { passkeysAvailable, type StepUpMethod, type StepUpState } from '@/auth/step-up';
import { CapabilityNotice } from '@/components/capability';
import { ActionButton } from '@/components/primitives';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * Asks the operator to re-authenticate for one action, and says what the action is.
 *
 * CH1-UXD-DSG-0001 requires authentication to guide users toward passkeys and to
 * explain step-up without exposing policy internals. So this names the action in plain
 * words, states that the elevation covers that action alone, and offers the
 * phishing-resistant route first — but it never says which role, strength or rule the
 * server will apply. The operator learns what they are about to authorise; an attacker
 * learns nothing about the policy.
 */
export function StepUpPrompt({
  action,
  consequence,
  stepUp,
  onGranted,
  requirePhishingResistant = false,
  disabled = false,
}: {
  /** What the operator is about to do, in their words. */
  action: string;
  /** What happens if it succeeds. Stated plainly so consent is informed. */
  consequence: string;
  stepUp: StepUpState;
  onGranted: (method: StepUpMethod) => void;
  /**
   * True for actions the baseline gates behind an origin-bound authenticator. The
   * re-authenticate route is not offered at all, rather than offered and refused.
   */
  requirePhishingResistant?: boolean;
  disabled?: boolean;
}) {
  const passkeyReady = passkeysAvailable();

  return (
    <View style={styles.prompt}>
      <Text style={styles.title}>CONFIRM IT IS YOU</Text>
      <Text style={styles.action}>{action}</Text>
      <Text style={styles.consequence}>{consequence}</Text>

      <Text style={styles.scope}>
        This confirmation covers this one action. It expires shortly, cannot be reused, and is
        not stored — closing this page ends it.
      </Text>

      {stepUp.grant ? (
        <GrantHeld grant={stepUp.grant} />
      ) : (
        <View style={styles.actions}>
          <ActionButton
            label={stepUp.pending ? 'WAITING FOR YOUR KEY…' : 'USE SECURITY KEY OR PASSKEY'}
            onPress={() => onGranted('Passkey')}
            disabled={disabled || stepUp.pending || !passkeyReady}
          />
          {requirePhishingResistant ? null : (
            <ActionButton
              label={stepUp.pending ? 'CONFIRMING…' : 'CONFIRM WITH MY SIGN-IN'}
              kind="secondary"
              onPress={() => onGranted('Reauthenticate')}
              disabled={disabled || stepUp.pending}
            />
          )}
        </View>
      )}

      {!passkeyReady ? (
        <Text style={styles.unavailable}>
          {requirePhishingResistant
            ? 'This action needs a security key or passkey, and this browser cannot use one. Open the portal in a browser with an authenticator available.'
            : 'This browser cannot use a security key or passkey.'}
        </Text>
      ) : null}

      {requirePhishingResistant ? (
        <Text style={styles.strongOnly}>
          This action accepts a security key or passkey only. A one-time password is a shared
          secret and is not accepted here.
        </Text>
      ) : null}

      {stepUp.error !== undefined ? (
        <>
          <CapabilityNotice error={stepUp.error} context="POST /api/v1/auth/step-up" />
          <ReauthenticationOffer error={stepUp.error} />
        </>
      ) : null}
    </View>
  );
}

/**
 * Offers the one thing the refusal asks for.
 *
 * Step-up rests on a *recent* authentication, so a session older than the permitted age
 * is refused with AUTH_REAUTHENTICATION_REQUIRED — correctly. But a message telling an
 * operator to authenticate again, on a screen with no way to do it, leaves them to work
 * out that they must sign out and back in. CH1-UXD-DSG-0001 requires a stale screen to
 * offer reconciliation; a stale authentication deserves the same treatment.
 *
 * Signing in again ends the page's in-memory token, which is why this is an explicit
 * choice rather than something the portal does on the operator's behalf: unsaved work on
 * another screen would be lost, and that decision is theirs.
 */
function ReauthenticationOffer({ error }: { error: unknown }) {
  const session = useSession();
  const stale =
    error instanceof CinerionApiError &&
    (error.code === 'AUTH_REAUTHENTICATION_REQUIRED' ||
      error.code === 'AUTH_AUTHENTICATION_TIME_UNKNOWN');

  if (!stale) return null;

  return (
    <View style={styles.reauth}>
      <Text style={styles.reauthText}>
        Signing in again refreshes how recently you proved who you are. It ends this session in
        this tab, so finish anything unsaved on other screens first.
      </Text>
      <ActionButton label="SIGN IN AGAIN" kind="secondary" onPress={session.signIn} />
    </View>
  );
}

/**
 * Reports the grant that is held, and how it was obtained.
 *
 * The strength shown is the server's, not the portal's guess: a passkey assertion is
 * the only thing that reaches StepUpPhishingResistant, and it does so because Control
 * Core verified the assertion, not because the browser said it did.
 */
function GrantHeld({ grant }: { grant: StepUpGrant }) {
  const strong = grant.grantedStrength === 'StepUpPhishingResistant';
  return (
    <View style={[styles.held, strong && styles.heldStrong]}>
      <Text style={[styles.heldTitle, strong && styles.heldTitleStrong]}>
        {strong ? '● CONFIRMED WITH A SECURITY KEY' : '● CONFIRMED'}
      </Text>
      <Text style={styles.heldDetail}>
        {grant.grantedStrength} · for {grant.purpose} only · expires {instant(grant.expiresAt)}
      </Text>
      <Text style={styles.heldNote}>
        Single use. It is spent by the next attempt, whether that attempt succeeds or is refused.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  prompt: {
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: '#1D4852',
    backgroundColor: '#0B2230',
    padding: Spacing.lg,
    gap: 8,
  },
  title: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.9 },
  action: { color: Palette.ink, fontFamily: Type.sans, fontSize: 13, fontWeight: '800' },
  consequence: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 11, lineHeight: 16 },
  scope: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginTop: Spacing.sm },
  unavailable: { color: Palette.amber, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  strongOnly: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  held: { marginTop: Spacing.sm, borderRadius: Radius.md, backgroundColor: Palette.tealSoft, padding: Spacing.md, gap: 4 },
  heldStrong: { backgroundColor: Palette.greenSoft },
  heldTitle: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  heldTitleStrong: { color: Palette.green },
  heldDetail: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 8 },
  heldNote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 13 },
  reauth: { marginTop: Spacing.sm, gap: Spacing.sm, alignItems: 'flex-start' },
  reauthText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
});
