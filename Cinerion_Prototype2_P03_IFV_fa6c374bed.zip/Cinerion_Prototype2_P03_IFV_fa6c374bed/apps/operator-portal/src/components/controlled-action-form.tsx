// A form for one controlled write, declared as data. You fill in the blanks, it handles the
// ceremony.

import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { CinerionApiError } from '@/api/client';
import { useControlledAction } from '@/api/use-controlled-action';
import { StepUpPurpose, useStepUp, type StepUpMethod, type StepUpPurposeName } from '@/auth/step-up';
import { ActionButton, TextField } from '@/components/primitives';
import { StepUpPrompt } from '@/components/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * One controlled mutation, declared rather than written.
 *
 * Three screens were built by hand first — reservations, the command preparation and the
 * quality loop — and the shape that survived all three is here: a disclosure, a set of
 * fields, an optional step-up for one named purpose, the server's own refusal shown
 * verbatim, and a reconcile on success. Everything below is the part that was identical
 * every time; everything that was NOT identical stays in its own component, because a form
 * that needs to explain what it does to a physical part is not a form this abstraction
 * should swallow.
 *
 * What it deliberately does not do:
 *
 *   * it never disables a control to pre-judge an outcome. Authorisation, state and
 *     interlocks are the server's to evaluate, and a portal that greys out a button it
 *     believes would fail is a portal asserting a decision it did not make. Fields are
 *     validated for SHAPE — a number that is not a number, a required box left empty —
 *     and nothing else;
 *   * it never rephrases a refusal. The server's stable code and detail are shown as sent,
 *     because a client that translates an error invents one;
 *   * it has no route to a controller-local operation. `scripts/check-repository-policy.mjs`
 *     refuses /credential-proofs and /local-commits anywhere in this tree.
 */

export interface ActionField {
  readonly name: string;
  readonly label: string;
  /** Prefilled value. The operator's to change; nothing recomputes it while they type. */
  readonly initial?: string;
  readonly hint?: string;
  readonly multiline?: boolean;
  readonly maxLength?: number;
  /** Shape only. Return a message when the text could not form a valid value. */
  readonly validate?: (value: string) => string | undefined;
  /** How the text becomes the body value. Defaults to the trimmed string. */
  readonly transform?: (value: string) => unknown;
  /** Fixed set of permitted values, rendered as chips instead of free text. */
  readonly choices?: readonly string[];
  /** Omit the field from the body entirely when it is blank. */
  readonly optional?: boolean;
}

export function ControlledActionForm({
  label,
  title,
  description,
  fields,
  endpoint,
  method = 'POST',
  stepUpPurpose,
  requirePhishingResistant = false,
  consequence,
  accessToken,
  extraBody,
  disabledReason,
  onDone,
}: {
  /** What the closed disclosure says. */
  label: string;
  /** What the open form is for, in the operator's words. */
  title: string;
  description?: string;
  fields: readonly ActionField[];
  endpoint: string;
  method?: 'POST' | 'PUT' | 'DELETE';
  /** When set, the action is gated behind a grant for this purpose alone. */
  stepUpPurpose?: StepUpPurposeName;
  requirePhishingResistant?: boolean;
  /** Stated before consent. Required whenever a step-up is. */
  consequence?: string;
  accessToken: string | undefined;
  /** Values the screen supplies that the operator does not type. */
  extraBody?: Record<string, unknown>;
  /**
   * Why this cannot be attempted at all — a missing scope, an absent record. Stated
   * rather than expressed by a dead control, and never used for a decision the server
   * would make.
   */
  disabledReason?: string;
  onDone: (result: unknown) => void;
}) {
  const [open, setOpen] = useState(false);
  const [values, setValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(fields.map((field) => [field.name, field.initial ?? ''])),
  );
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const action = useControlledAction<unknown>(accessToken);

  const errorFor = (field: ActionField): string | undefined => {
    const raw = values[field.name] ?? '';
    if (field.optional && raw.trim().length === 0) return undefined;
    if (!field.optional && raw.trim().length === 0) return `${field.label} is required.`;
    return field.validate?.(raw);
  };
  const invalid = fields.some((field) => errorFor(field) !== undefined);

  const body = (): Record<string, unknown> => {
    const composed: Record<string, unknown> = { ...extraBody };
    for (const field of fields) {
      const raw = values[field.name] ?? '';
      if (field.optional && raw.trim().length === 0) continue;
      composed[field.name] = field.transform ? field.transform(raw) : raw.trim();
    }
    return composed;
  };

  const run = async (grantId?: string) => {
    const result = await action.submit(endpoint, method === 'DELETE' ? undefined : body(), {
      method,
      ...(grantId ? { stepUpGrantId: grantId } : {}),
    });
    if (result !== undefined) {
      setAttempted(false);
      setOpen(false);
      stepUp.clear();
      setValues(Object.fromEntries(fields.map((field) => [field.name, field.initial ?? ''])));
      onDone(result);
    }
  };

  const submitPlain = async () => {
    setAttempted(true);
    if (invalid) return;
    await run();
  };

  const submitElevated = async (methodChosen: StepUpMethod) => {
    setAttempted(true);
    if (invalid || !stepUpPurpose) return;
    const grant = await stepUp.request(stepUpPurpose, methodChosen);
    if (!grant) return;
    await run(grant.grantId);
  };

  const refusal = action.error instanceof CinerionApiError ? action.error : undefined;

  return (
    <View>
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ expanded: open, disabled: disabledReason !== undefined }}
        accessibilityLabel={`${open ? 'Close' : 'Open'} the form to ${title}`}
        disabled={disabledReason !== undefined}
        onPress={() => setOpen((previous) => !previous)}
        style={({ pressed }) => [styles.expandRow, pressed && styles.pressed]}>
        <Text style={[styles.expandText, disabledReason !== undefined && styles.expandTextOff]}>
          {open ? '▾ CLOSE' : `▸ ${label}`}
        </Text>
      </Pressable>

      {disabledReason ? <Text style={styles.note}>{disabledReason}</Text> : null}

      {open && !disabledReason ? (
        <View style={styles.form}>
          {description ? <Text style={styles.note}>{description}</Text> : null}

          {fields.map((field) => {
            const raw = values[field.name] ?? '';
            const set = (next: string) =>
              setValues((previous) => ({ ...previous, [field.name]: next }));

            if (field.choices) {
              return (
                <View key={field.name} style={styles.choiceBlock}>
                  <Text style={styles.choiceLabel}>{field.label.toUpperCase()}</Text>
                  <View style={styles.chips}>
                    {field.choices.map((choice) => {
                      const active = raw === choice;
                      return (
                        <Pressable
                          key={choice}
                          accessibilityRole="button"
                          accessibilityState={{ selected: active }}
                          onPress={() => set(choice)}
                          style={({ pressed }) => [
                            styles.chip,
                            active && styles.chipActive,
                            pressed && styles.pressed,
                          ]}>
                          <Text style={[styles.chipText, active && styles.chipTextActive]}>
                            {choice.toUpperCase()}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                  {field.hint ? <Text style={styles.hint}>{field.hint}</Text> : null}
                  {attempted && errorFor(field) ? (
                    <Text style={styles.fieldError}>{errorFor(field)}</Text>
                  ) : null}
                </View>
              );
            }

            return (
              <TextField
                key={field.name}
                label={field.label}
                value={raw}
                onChangeText={set}
                hint={field.hint}
                multiline={field.multiline}
                maxLength={field.maxLength}
                error={attempted ? errorFor(field) : undefined}
              />
            );
          })}

          {stepUpPurpose ? (
            <StepUpPrompt
              action={title}
              consequence={consequence ?? 'This act is recorded and is not reversible by repeating it.'}
              stepUp={stepUp}
              onGranted={submitElevated}
              requirePhishingResistant={requirePhishingResistant}
              disabled={action.pending}
            />
          ) : (
            <ActionButton
              label={action.pending ? 'SENDING…' : label}
              onPress={() => void submitPlain()}
              disabled={action.pending}
            />
          )}

          {refusal ? (
            <View style={styles.refusal}>
              <Text style={styles.refusalCode}>{refusal.code}</Text>
              <Text style={styles.refusalText}>{refusal.message}</Text>
              {refusal.correlationId ? (
                <Text style={styles.refusalCorrelation}>correlation {refusal.correlationId}</Text>
              ) : null}
            </View>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

/** Shape validators, reused across screens so a rule is written once. */
export const Shape = {
  number: (value: string) => (Number.isFinite(Number(value)) ? undefined : 'A number is required.'),
  positiveInteger: (value: string) => {
    const parsed = Number(value);
    return Number.isInteger(parsed) && parsed > 0 ? undefined : 'A whole number above zero is required.'; },
  instant: (value: string) =>
    Number.isNaN(Date.parse(value)) ? 'A UTC timestamp such as 2026-01-01T09:00:00Z.' : undefined,
} as const;

export { StepUpPurpose };

const styles = StyleSheet.create({
  form: { gap: Spacing.md, marginTop: Spacing.md },
  expandRow: { borderTopWidth: 1, borderTopColor: Palette.line, paddingTop: Spacing.md, marginTop: Spacing.md },
  expandText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  expandTextOff: { opacity: 0.45 },
  pressed: { opacity: 0.72 },
  note: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  hint: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 8, lineHeight: 12 },
  fieldError: { color: Palette.red, fontFamily: Type.sans, fontSize: 9 },
  choiceBlock: { gap: 6 },
  choiceLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.pill, borderWidth: 1, borderColor: Palette.line, backgroundColor: Palette.panel },
  chipActive: { borderColor: '#236D69', backgroundColor: Palette.tealSoft },
  chipText: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9, fontWeight: '700' },
  chipTextActive: { color: Palette.teal },
  refusal: { borderRadius: Radius.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#714046', padding: Spacing.md, gap: 4 },
  refusalCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 10, fontWeight: '900', letterSpacing: 0.6 },
  refusalText: { color: '#D9A6A8', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  refusalCorrelation: { color: '#A87B7E', fontFamily: Type.mono, fontSize: 8 },
});
