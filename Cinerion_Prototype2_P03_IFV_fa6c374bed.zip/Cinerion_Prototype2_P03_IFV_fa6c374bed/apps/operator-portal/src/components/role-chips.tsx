// Who am I today? One chip per role, wrapping onto as many lines as it takes.
//
// This replaced a single pill with every role glued together in capitals. With fifteen
// roles that pill was about two thousand pixels wide, refused to shrink, and squashed the
// page title next to it into one letter per line. Chips wrap. Titles stay titles.

import { StyleSheet, Text, View } from 'react-native';

import { splitRoles } from '@/api/capabilities';
import { Palette, Radius, Type } from '@/constants/theme';

export function RoleChips({ roles }: { roles: readonly string[] | undefined }) {
  const { controlled, other } = splitRoles(roles);

  // No controlled role at all is worth shouting about, so it gets the amber treatment.
  if (controlled.length === 0) {
    return (
      <View style={styles.wrap} accessibilityLabel="No controlled role">
        <View style={[styles.chip, styles.chipWarning]}>
          <Text style={[styles.chipText, styles.chipTextWarning]}>NO CONTROLLED ROLE</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.wrap} accessibilityLabel={`Roles held: ${controlled.join(', ')}`}>
      <Text style={styles.count}>
        {controlled.length} {controlled.length === 1 ? 'ROLE' : 'ROLES'}
      </Text>
      <View style={styles.chips}>
        {controlled.map((role) => (
          <View key={role} style={styles.chip}>
            <Text style={styles.chipText}>{role}</Text>
          </View>
        ))}
      </View>
      {/* The provider's own housekeeping roles. Shown small, not hidden: they're in the
          token, so pretending otherwise would be fibbing. They just don't grant anything. */}
      {other.length > 0 ? (
        <Text style={styles.other}>
          Also in the token, granting nothing here: {other.join(', ')}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  // Shrinks and wraps. The whole point of this file, really.
  wrap: { flexShrink: 1, maxWidth: 560, gap: 6 },
  count: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: {
    backgroundColor: Palette.tealSoft,
    borderRadius: Radius.pill,
    paddingHorizontal: 9,
    paddingVertical: 4,
  },
  chipWarning: { backgroundColor: Palette.amberSoft },
  chipText: { color: Palette.cyan, fontFamily: Type.sans, fontSize: 11, fontWeight: '700' },
  chipTextWarning: { color: Palette.amber },
  other: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 10, lineHeight: 14 },
});
