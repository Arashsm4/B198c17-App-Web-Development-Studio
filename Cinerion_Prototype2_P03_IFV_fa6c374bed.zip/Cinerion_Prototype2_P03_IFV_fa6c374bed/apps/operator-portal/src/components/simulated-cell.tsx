// Asks the SIMULATED cell to confirm a prepared command. Nothing physical moves, and it says
// so up front.

import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { portalConfig } from '@/api/client';
import { ActionButton, Divider } from '@/components/primitives';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * Asks a SIMULATED cell to do what a real cell would do with a prepared command.
 *
 * Read the boundary carefully, because this control sits closer to it than anything else
 * in the portal.
 *
 * **It is not a commit control and the portal does not gain one.** The portal has no route
 * to `/credential-proofs` or `/local-commits`; `scripts/check-repository-policy.mjs`
 * refuses either string anywhere under `apps/operator-portal/src/`, and that refusal is
 * still in force over this file. What this sends is a request to a DIFFERENT service — a
 * stand-in cell controller holding its own device certificate, which Control Core resolves
 * to an enrolled device record. That service performs the controller's half; the portal
 * only asks it to.
 *
 * **Nothing physical happens, and the portal must never imply otherwise.** The stand-in
 * injects an edge marked `SimulatorInjection` and a presence marked `SimulatedPresence`.
 * Control Core refuses both outside the Simulation profile and records both as marked in
 * the audit chain. No output is energised anywhere: the pin map declares two actuator
 * signals and neither is energisable at hardware revision R01.
 *
 * **It is offered only when a simulator is configured**, and it says so when it is not.
 * `EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL` is absent in any build that is not a
 * laboratory, so the control does not exist there — rather than existing and failing,
 * which would leave an operator wondering whether the cell was unreachable.
 *
 * **It cannot make a command commit that should not.** Every guard runs against the
 * stand-in exactly as against a real controller: the interlocks are re-sampled, the
 * expected state hash must still match, the controller boot identity must be the one the
 * command was prepared against, and neither the proof nor the command may have expired. A
 * refusal comes back as the service sent it and is shown here unaltered.
 */
export function AskSimulatedCell({
  commandId,
  state,
  onConfirmed,
}: {
  commandId: string;
  /** The command's current state, so the control is offered only where it means anything. */
  state: string;
  onConfirmed: () => void;
}) {
  const [pending, setPending] = useState(false);
  const [outcome, setOutcome] = useState<SimulatedConfirmation | undefined>(undefined);
  const [failure, setFailure] = useState<string | undefined>(undefined);

  if (!portalConfig.cellSimulatorUrl) {
    // Stated rather than silent. A reader looking at a command stuck awaiting a credential
    // needs to know whether nothing is answering or nothing was ever configured to.
    return (
      <View style={styles.absent}>
        <Text style={styles.absentCode}>NO SIMULATED CELL IS CONFIGURED</Text>
        <Text style={styles.absentText}>
          This build names no cell simulator, so there is nothing to ask. A prepared command waits
          for a real cell controller to present a credential proof and observe a button edge; the
          portal cannot do either and is not able to.
        </Text>
      </View>
    );
  }

  if (state !== 'AwaitingCredential' && state !== 'AwaitingButton') {
    return null;
  }

  const ask = async () => {
    setPending(true);
    setFailure(undefined);
    setOutcome(undefined);
    try {
      const response = await fetch(`${portalConfig.cellSimulatorUrl}/confirm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ commandId }),
      });
      const body: unknown = await response.json().catch(() => undefined);
      if (!response.ok) {
        // The stand-in forwards Control Core's own refusal rather than rephrasing it, and
        // so does this: what is shown is what the platform said.
        setFailure(JSON.stringify(body ?? { status: response.status }, null, 2));
        return;
      }
      setOutcome(body as SimulatedConfirmation);
      onConfirmed();
    } catch (cause) {
      setFailure(
        cause instanceof Error
          ? `The simulated cell could not be reached: ${cause.message}`
          : 'The simulated cell could not be reached.',
      );
    } finally {
      setPending(false);
    }
  };

  return (
    <View style={styles.block}>
      <Divider />
      <Text style={styles.label}>SIMULATED CELL</Text>
      <Text style={styles.body}>
        A stand-in cell controller can answer this command the way a real one would: present a
        credential proof, observe a rising button edge, and let Control Core re-sample the
        interlocks and commit locally. It runs as its own service with its own device certificate;
        the portal asks it, and has no route to either controller operation itself.
      </Text>

      <View style={styles.warning}>
        <Text style={styles.warningCode}>THIS IS NOT A PHYSICAL CONFIRMATION</Text>
        <Text style={styles.warningText}>
          No person presents a credential and no button is pressed. The edge is marked
          SimulatorInjection and the presence is marked SimulatedPresence; Control Core refuses
          both outside the Simulation profile and records both as marked in the audit chain.
          Nothing is energised.
        </Text>
      </View>

      <ActionButton
        label={pending ? 'ASKING THE SIMULATED CELL…' : 'ASK THE SIMULATED CELL TO CONFIRM'}
        onPress={() => void ask()}
        disabled={pending}
        kind="secondary"
      />

      {failure !== undefined ? (
        <View style={styles.refusal}>
          <Text style={styles.refusalCode}>THE SIMULATED CELL DID NOT CONFIRM</Text>
          <Text style={styles.refusalText} selectable>
            {failure}
          </Text>
        </View>
      ) : null}

      {outcome !== undefined ? (
        <View style={styles.receipt}>
          <Text style={styles.receiptTitle}>SIMULATED CONFIRMATION COMPLETED</Text>
          <Text style={styles.receiptLine}>The command is now {outcome.state}.</Text>
          {(outcome.steps ?? []).map((step, index) => (
            <Text key={`${step.step}-${index}`} style={styles.receiptStep}>
              {index + 1}. {step.step}
              {step.state ? ` → ${step.state}` : ''}
              {step.authenticatorClass ? ` (${step.authenticatorClass})` : ''}
            </Text>
          ))}
          {/* The stand-in's own notice, verbatim. It is the sentence that stops this
              receipt being quoted as evidence that something ran. */}
          <Text style={styles.receiptNotice}>{outcome.notice}</Text>
        </View>
      ) : null}
    </View>
  );
}

/** What the stand-in answers with. Its shape, not Control Core's. */
interface SimulatedConfirmation {
  readonly confirmed: boolean;
  readonly state?: string;
  readonly notice: string;
  readonly steps?: readonly {
    readonly step: string;
    readonly state?: string;
    readonly authenticatorClass?: string;
  }[];
}

const styles = StyleSheet.create({
  block: { gap: Spacing.sm, marginTop: Spacing.md },
  label: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  body: { color: Palette.inkSoft, fontFamily: Type.sans, fontSize: 10, lineHeight: 15 },
  warning: {
    borderRadius: Radius.md,
    backgroundColor: Palette.amberSoft,
    borderWidth: 1,
    borderColor: '#6B5227',
    padding: Spacing.md,
    gap: 5,
  },
  warningCode: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  warningText: { color: '#D9BD8C', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  absent: {
    borderRadius: Radius.md,
    backgroundColor: Palette.canvasRaised,
    borderWidth: 1,
    borderColor: Palette.lineStrong,
    padding: Spacing.md,
    marginTop: Spacing.md,
    gap: 5,
  },
  absentCode: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  absentText: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  refusal: {
    borderRadius: Radius.md,
    backgroundColor: Palette.redSoft,
    borderWidth: 1,
    borderColor: '#714046',
    padding: Spacing.md,
    gap: 4,
  },
  refusalCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.6 },
  refusalText: { color: '#D9A6A8', fontFamily: Type.mono, fontSize: 8, lineHeight: 13 },
  receipt: {
    borderRadius: Radius.md,
    backgroundColor: '#0B2230',
    borderWidth: 1,
    borderColor: '#1D4852',
    padding: Spacing.md,
    gap: 4,
  },
  receiptTitle: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  receiptLine: { color: Palette.ink, fontFamily: Type.sans, fontSize: 11 },
  receiptStep: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9 },
  receiptNotice: { color: Palette.amber, fontFamily: Type.sans, fontSize: 9, lineHeight: 14, marginTop: 4 },
});
