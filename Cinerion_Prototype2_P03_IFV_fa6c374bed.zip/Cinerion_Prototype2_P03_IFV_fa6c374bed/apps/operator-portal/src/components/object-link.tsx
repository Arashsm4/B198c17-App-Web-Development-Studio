// Makes an identifier clickable, so an ID takes you somewhere instead of just sitting there.

import { router, type Href } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Palette, Radius, Type } from '@/constants/theme';

/**
 * Makes an identifier a way to get to the thing it names.
 *
 * The data in this portal has always carried every identifier that connects it - an alarm
 * names its cell, a cell names the work order and the part on it, a part names its
 * measurements and its nonconformities, every controlled object names its collaboration
 * thread - and every screen rendered those identifiers as inert monospace text. So a
 * reader could see that an alarm belonged to a cell, and then had to copy a UUID into
 * another screen's search box to find out anything about it. That is the whole difference
 * between a set of reports and something that feels like controlling one operation.
 *
 * Three rules.
 *
 * **The identifier is still shown.** A link that replaced `00000000-…-0103` with "the
 * cell" would be an interface deciding what an operator may check. The identifier is what
 * appears in the audit record, in the controller's own log and in a refusal's correlation
 * id, and a reader must be able to compare them. So the link carries the identifier and
 * adds a destination, rather than hiding one behind the other.
 *
 * **Navigating asserts nothing.** Following a link is a read, and the destination screen
 * performs its own controlled read against Control Core, which re-evaluates project and
 * cell scope. An object this identity may not see answers 404 there exactly as it would
 * have if the identifier had been typed - and 404 is deliberately the same answer for
 * "does not exist", so a link cannot be used to prove that an object exists either.
 *
 * **A missing identifier is not a dead control.** When the object is not known the label
 * renders as plain text with no affordance, because a link that goes nowhere teaches an
 * operator to distrust the ones that do.
 */
export type LinkedObjectKind =
  | 'cell'
  | 'part'
  | 'workOrder'
  | 'device'
  | 'thread'
  | 'testRun'
  | 'ncr'
  | 'experiment';

interface Destination {
  readonly pathname: string;
  /** How the identifier is named in the destination screen's own search parameters. */
  readonly parameter: string;
  /** What the destination is, for the accessibility label. */
  readonly describe: string;
}

/**
 * Where each kind of object is looked at.
 *
 * One table rather than a `router.push` at each call site, so the answer to "where does a
 * part open" is written once. Every pathname here is a route this portal builds and
 * `npm run screens` reconciles against the controlled screen register.
 */
const DESTINATIONS: Record<LinkedObjectKind, Destination> = {
  cell: { pathname: '/control-room', parameter: 'cellId', describe: 'the control room for this cell' },
  part: { pathname: '/genealogy', parameter: 'partId', describe: 'the genealogy of this part' },
  workOrder: { pathname: '/work-orders', parameter: 'workOrderId', describe: 'this work order on the board' },
  device: { pathname: '/devices', parameter: 'deviceId', describe: 'this device and its trust state' },
  thread: { pathname: '/collaboration', parameter: 'threadId', describe: 'the thread about this object' },
  // A test run and a nonconformity are both looked at on the quality screen, which reads
  // them through the part they belong to - so both carry the part as well.
  testRun: { pathname: '/quality', parameter: 'testRunId', describe: 'this test run' },
  ncr: { pathname: '/quality', parameter: 'ncrId', describe: 'this nonconformity' },
  experiment: { pathname: '/research', parameter: 'experimentId', describe: 'this experiment' },
};

export function ObjectLink({
  kind,
  id,
  label,
  extra,
}: {
  kind: LinkedObjectKind;
  /** The identifier. Undefined renders as plain text rather than as a control. */
  id: string | undefined;
  /** What to show. Defaults to the identifier itself, which is usually what a reader wants. */
  label?: string;
  /** Further parameters the destination needs, such as the part a test run belongs to. */
  extra?: Record<string, string | undefined>;
}) {
  const shown = label ?? id ?? '—';
  if (id === undefined || id.length === 0) {
    return <Text style={styles.inert}>{shown}</Text>;
  }

  const destination = DESTINATIONS[kind];
  const params: Record<string, string> = { [destination.parameter]: id };
  for (const [name, value] of Object.entries(extra ?? {})) {
    if (value !== undefined && value.length > 0) params[name] = value;
  }

  return (
    <Pressable
      accessibilityRole="link"
      accessibilityLabel={`Open ${destination.describe} (${id})`}
      onPress={() => router.push({ pathname: destination.pathname, params } as Href)}
      style={({ pressed }) => [styles.link, pressed && styles.pressed]}>
      <Text style={styles.linkText}>{shown}</Text>
      <Text style={styles.arrow}>↗</Text>
    </Pressable>
  );
}

/**
 * A row of the objects one record connects to.
 *
 * Rendered as a strip under a record rather than scattered through its fields, so an
 * operator can see at a glance what this thing touches: the cell it is on, the order it
 * belongs to, the part it made, the thread it is discussed on. Entries whose identifier is
 * absent are dropped rather than shown as dead ends - an alarm with no part is an alarm
 * with no part, not a broken link.
 */
export function ConnectedObjects({
  items,
}: {
  items: readonly {
    readonly kind: LinkedObjectKind;
    readonly id: string | undefined;
    readonly caption: string;
    readonly label?: string;
    readonly extra?: Record<string, string | undefined>;
  }[];
}) {
  const present = items.filter((item) => item.id !== undefined && item.id.length > 0);
  if (present.length === 0) return null;

  return (
    <View style={styles.strip}>
      <Text style={styles.stripLabel}>CONNECTED</Text>
      {present.map((item) => (
        <View key={`${item.kind}:${item.id}`} style={styles.stripItem}>
          <Text style={styles.caption}>{item.caption}</Text>
          <ObjectLink kind={item.kind} id={item.id} label={item.label} extra={item.extra} />
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  link: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: Radius.sm,
    borderWidth: 1,
    borderColor: '#1D4852',
    backgroundColor: '#0B2230',
  },
  pressed: { opacity: 0.72 },
  linkText: { color: Palette.cyan, fontFamily: Type.mono, fontSize: 9 },
  arrow: { color: Palette.teal, fontFamily: Type.mono, fontSize: 9, fontWeight: '800' },
  inert: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 9 },
  strip: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  stripLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  stripItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  caption: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9 },
});
