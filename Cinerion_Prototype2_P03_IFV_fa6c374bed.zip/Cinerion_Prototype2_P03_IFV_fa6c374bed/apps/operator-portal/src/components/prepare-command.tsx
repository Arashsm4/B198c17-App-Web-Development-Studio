// Step one of PREPARE then LOCAL COMMIT. The portal prepares, the button at the cell decides.
// Always.

import { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { CinerionApiError } from '@/api/client';
import type { CellState, CommandTransaction } from '@/api/contracts';
import { instant } from '@/api/format';
import { useControlledAction } from '@/api/use-controlled-action';
import { permissivesAnswered } from '@/api/permissives';
import { StepUpPurpose, useStepUp, type StepUpMethod } from '@/auth/step-up';
import { ActionButton, Divider, KeyValue, StatusPill, TextField } from '@/components/primitives';
import { AskSimulatedCell } from '@/components/simulated-cell';
import { StepUpPrompt } from '@/components/step-up';
import { Palette, Radius, Spacing, Type } from '@/constants/theme';

/**
 * Requests one semantic procedure: step 1 of the controlled PREPARE / LOCAL COMMIT
 * sequence, and the only step of it that belongs to this application.
 *
 * WHAT THIS IS NOT. It does not start equipment, and there is deliberately no control
 * here that could. A preparation moves a transaction to `AwaitingCredential` and stops;
 * the credential proof and the physical button edge are observed AT THE CELL by the
 * controller, which is the only party that may commit. `scripts/check-repository-policy.mjs`
 * refuses `/credential-proofs` and `/local-commits` anywhere in this source tree, so the
 * absence is enforced rather than merely intended.
 *
 * WHY IT EXISTS ANYWAY. The controlled sequence's first message is the Engineer asking for
 * a procedure, and until now this screen said what a preparation "would be" bound to and
 * offered no way to make one. That is not the safety boundary being respected — the
 * boundary is between PREPARE and COMMIT, not between an engineer and a form. A portal
 * that cannot even request intent leaves the whole workflow unreachable from the
 * application that exists to reach it.
 *
 * The command TYPE is semantic and allowlisted server-side against
 * `^[A-Z][A-Z0-9_]{2,63}$`. A free-form instruction has no way in, here or anywhere: the
 * portal names a procedure, it does not describe motion.
 */
export function PrepareCommandForm({
  cell,
  projectId,
  accessToken,
  onPrepared,
}: {
  cell: CellState | undefined;
  /**
   * The project scope this session actually holds, from the `ch1_project` claim rather
   * than from the cell read — which does not carry one. That is the right source and not
   * a workaround: the server refuses a preparation whose project differs from the
   * actor's (AUTH_PROJECT_SCOPE), so sending the claim is sending the thing that will be
   * checked.
   */
  projectId: string | undefined;
  accessToken: string | undefined;
  onPrepared: (command: CommandTransaction) => void;
}) {
  const [open, setOpen] = useState(false);
  const [commandType, setCommandType] = useState('RUN_TENSION_CALIBRATION');
  const [procedureRevision, setProcedureRevision] = useState('CH1-REFAB-PROC-0001-R01');
  const [ttlSeconds, setTtlSeconds] = useState('60');
  const [attempted, setAttempted] = useState(false);
  const stepUp = useStepUp(accessToken);
  const prepare = useControlledAction<CommandTransaction>(accessToken);

  /**
   * One key per opened form, not one per submission.
   *
   * The key belongs to the ATTEMPT. A retry after a timeout must carry the same key so the
   * server answers with the record it already made instead of preparing a second command
   * against the same cell; a genuinely new preparation gets a fresh key when the form is
   * reopened. Regenerating it on every press would defeat the control entirely.
   */
  const [idempotencyKey, setIdempotencyKey] = useState(() => newKey());

  const ttl = Number(ttlSeconds);
  const typeInvalid = !/^[A-Z][A-Z0-9_]{2,63}$/.test(commandType.trim());
  const revisionInvalid = procedureRevision.trim().length === 0;
  const ttlInvalid = !Number.isFinite(ttl) || ttl < 5 || ttl > 120;

  // Every identity the intent must carry. The server checks all of them again; this only
  // decides whether there is anything worth sending.
  const bindingComplete = useMemo(
    () =>
      Boolean(
        projectId &&
          cell?.siteId &&
          cell?.cellId &&
          cell?.assetId &&
          cell?.workOrderId &&
          cell?.partId &&
          cell?.configurationRevision &&
          cell?.stateHash,
      ),
    [cell, projectId],
  );

  const toggle = useCallback(() => {
    setOpen((previous) => {
      if (previous) return false;
      setIdempotencyKey(newKey());
      setAttempted(false);
      return true;
    });
  }, []);

  const submit = async (method: StepUpMethod) => {
    setAttempted(true);
    if (typeInvalid || revisionInvalid || ttlInvalid || !bindingComplete || !cell) return;

    const grant = await stepUp.request(StepUpPurpose.PhysicalCommandPreparation, method);
    if (!grant) return;

    const prepared = await prepare.submit(
      '/api/v1/commands/prepare',
      {
        commandType: commandType.trim(),
        projectId,
        siteId: cell.siteId,
        cellId: cell.cellId,
        assetId: cell.assetId,
        workOrderId: cell.workOrderId,
        partId: cell.partId,
        procedureRevision: procedureRevision.trim(),
        configurationRevision: cell.configurationRevision,
        // The state the operator actually read. If the cell has moved since, the server
        // refuses as CMD_EXPECTED_STATE_STALE rather than preparing against a cell in a
        // condition nobody saw.
        expectedStateHash: cell.stateHash,
        sequence: Date.now(),
        expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
        parameters: {},
      },
      { stepUpGrantId: grant.grantId, idempotencyKey },
    );

    if (prepared) {
      setAttempted(false);
      stepUp.clear();
      setOpen(false);
      onPrepared(prepared);
    }
  };

  const refusal = prepare.error instanceof CinerionApiError ? prepare.error : undefined;

  return (
    <View style={styles.block}>
      <ActionButton
        label={open ? 'CLOSE' : 'PREPARE A PROCEDURE'}
        onPress={toggle}
        disabled={!bindingComplete}
      />

      {!bindingComplete ? (
        <Text style={styles.note}>
          A preparation binds to a project, site, cell, asset, work order, part, configuration
          revision and the cell&apos;s own state hash. Control Core has not reported all of them
          for this cell, so there is nothing a preparation could be bound to.
        </Text>
      ) : null}

      {open ? (
        <View style={styles.form}>
          <TextField
            label="Semantic procedure"
            value={commandType}
            onChangeText={setCommandType}
            error={
              attempted && typeInvalid
                ? 'A procedure name is upper case, 3-64 characters, letters, digits and underscores.'
                : undefined
            }
            hint="Named, never described. The server matches this against its own allowlist."
          />
          <TextField
            label="Released procedure revision"
            value={procedureRevision}
            onChangeText={setProcedureRevision}
            error={attempted && revisionInvalid ? 'A released procedure revision is required.' : undefined}
          />
          <TextField
            label="Validity window (seconds)"
            value={ttlSeconds}
            onChangeText={setTtlSeconds}
            error={attempted && ttlInvalid ? 'Between 5 and 120 seconds.' : undefined}
            hint="How long the confirmation stays armed at the cell before it expires unused."
          />

          <Divider />

          <View style={styles.boundary}>
            <Text style={styles.boundaryTitle}>WHAT THIS DOES, AND WHAT IT DOES NOT</Text>
            <Text style={styles.boundaryText}>
              This creates a transaction awaiting a credential. It does not start the procedure.
              A person at the cell must present a cryptographic credential and press the physical
              button, and the controller resamples every interlock before it commits. Nothing in
              this application can perform, emulate or skip any of that.
            </Text>
          </View>

          {cell && !permissivesAnswered(cell) ? (
            <Text style={styles.warn}>
              This controller has not answered its permissives. A preparation will be refused, and
              that refusal is the correct outcome rather than a fault.
            </Text>
          ) : null}

          <StepUpPrompt
            action={`prepare ${commandType.trim() || 'a procedure'} at this cell`}
            consequence="A confirmation is armed at the cell for the validity window you set. A person there must still present a credential and press the button."
            stepUp={stepUp}
            onGranted={submit}
            requirePhishingResistant
            disabled={prepare.pending}
          />

          {refusal ? (
            <View style={styles.refusal}>
              <Text style={styles.refusalCode}>{refusal.code}</Text>
              <Text style={styles.refusalText}>{refusal.message}</Text>
              {refusal.correlationId ? (
                <Text style={styles.refusalCorrelation}>correlation {refusal.correlationId}</Text>
              ) : null}
            </View>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

/**
 * The prepared transaction, as Control Core reports it — including what the equipment
 * answered.
 *
 * `acknowledgements` is a separate field from `state` and is shown as one. A controller
 * saying it received a command is evidence about delivery; the command advances on a
 * credential proof and a physical button edge, and presenting the two together would
 * invite a reader to treat an acknowledgement as execution.
 */
export function PreparedCommand({
  command,
  accessToken,
  onCancelled,
}: {
  command: CommandTransaction;
  accessToken: string | undefined;
  onCancelled: () => void;
}) {
  const [reason, setReason] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const cancel = useControlledAction<CommandTransaction>(accessToken);
  const reasonInvalid = reason.trim().length === 0;

  const submit = async () => {
    setAttempted(true);
    if (reasonInvalid) return;
    const cancelled = await cancel.submit(`/api/v1/commands/${command.commandId}/cancel`, {
      reason: reason.trim(),
    });
    if (cancelled) {
      setConfirming(false);
      setReason('');
      setAttempted(false);
      onCancelled();
    }
  };

  const refusal = cancel.error instanceof CinerionApiError ? cancel.error : undefined;
  const terminal = command.state === 'Cancelled' || command.state === 'Completed' ||
    command.state === 'FaultLatched';

  return (
    <View style={styles.prepared}>
      <View style={styles.preparedHead}>
        <Text style={styles.preparedTitle}>{command.intent?.commandType ?? 'Prepared command'}</Text>
        <StatusPill
          label={command.state.replace(/([a-z])([A-Z])/g, '$1 $2').toUpperCase()}
          tone={terminal ? 'neutral' : 'info'}
        />
      </View>

      <KeyValue label="Command" value={command.commandId} mono />
      <KeyValue label="Confirmation challenge" value={command.confirmationId} mono />
      <KeyValue label="Correlation" value={command.correlationId} mono />
      <KeyValue label="Prepared at" value={instant(command.preparedAt)} />
      <KeyValue label="Expires" value={command.intent ? instant(command.intent.expiresAt) : '—'} />
      {command.terminalReason ? (
        <KeyValue label="Terminal reason" value={command.terminalReason} mono />
      ) : null}

      <Divider />

      <Text style={styles.blockLabel}>WHAT THE EQUIPMENT ANSWERED</Text>
      {(command.acknowledgements ?? []).length === 0 ? (
        <Text style={styles.note}>
          No controller has answered this command yet. An empty list and an absent one say
          different things, and this is the empty one.
        </Text>
      ) : (
        (command.acknowledgements ?? []).map((ack) => (
          <View key={ack.eventId} style={styles.ack}>
            <Text style={styles.ackDecision}>{ack.decision.toUpperCase()}</Text>
            <Text style={styles.ackDetail}>
              {ack.gatewayIdentity} · {instant(ack.recordedAt)} · {ack.timeQuality}
            </Text>
            <Text style={styles.ackHash} selectable>
              {ack.eventHash}
            </Text>
          </View>
        ))
      )}
      <Text style={styles.ackFootnote}>
        An acknowledgement is evidence about delivery, never authority to execute.
      </Text>

      {(command.auditLinks ?? []).length > 0 ? (
        <>
          <Divider />
          <Text style={styles.blockLabel}>IMMUTABLE AUDIT LINKS ({(command.auditLinks ?? []).length})</Text>
          {(command.auditLinks ?? []).map((link) => (
            <View key={link.eventId} style={styles.link}>
              <Text style={styles.linkType}>{link.eventType}</Text>
              <Text style={styles.linkDetail}>
                {link.decision} · {link.reasonCode} · {instant(link.occurredAt)}
              </Text>
            </View>
          ))}
        </>
      ) : null}

      {/*
        The stand-in cell, offered only while the command is still waiting for one and only
        when a simulator is configured. It is not a commit control: the portal has no route
        to /credential-proofs or /local-commits and the repository policy gate refuses
        either string anywhere in this tree. What it sends is a request to a separate
        service holding its own device certificate.
      */}
      {!terminal ? (
        <AskSimulatedCell
          commandId={command.commandId}
          state={command.state}
          onConfirmed={onCancelled}
        />
      ) : null}

      {!terminal ? (
        <>
          <Divider />
          <ActionButton
            label={confirming ? 'KEEP THIS PREPARATION' : 'CANCEL THIS PREPARATION'}
            onPress={() => setConfirming((previous) => !previous)}
            kind="danger"
          />
          {confirming ? (
            <View style={styles.cancelForm}>
              <TextField
                label="Reason"
                value={reason}
                onChangeText={setReason}
                error={attempted && reasonInvalid ? 'A cancellation is attributable. State why.' : undefined}
                hint="Recorded against the transaction and kept."
              />
              <ActionButton
                label={cancel.pending ? 'CANCELLING…' : 'CONFIRM CANCELLATION'}
                onPress={submit}
                disabled={cancel.pending}
                kind="danger"
              />
            </View>
          ) : null}
          {refusal ? (
            <View style={styles.refusal}>
              <Text style={styles.refusalCode}>{refusal.code}</Text>
              <Text style={styles.refusalText}>{refusal.message}</Text>
            </View>
          ) : null}
        </>
      ) : null}
    </View>
  );
}

function newKey(): string {
  const raw = globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
  return `portal-${raw.replace(/-/g, '')}`.slice(0, 64);
}

const styles = StyleSheet.create({
  block: { gap: Spacing.sm },
  form: { gap: Spacing.md, marginTop: Spacing.md },
  note: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  warn: { color: Palette.amber, fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  blockLabel: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8, fontWeight: '900', letterSpacing: 0.8, marginBottom: 6 },
  boundary: { borderRadius: Radius.md, backgroundColor: Palette.amberSoft, borderWidth: 1, borderColor: '#6B5227', padding: Spacing.md, gap: 6 },
  boundaryTitle: { color: Palette.amber, fontFamily: Type.mono, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  boundaryText: { color: '#D9BD8C', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  refusal: { borderRadius: Radius.md, backgroundColor: Palette.redSoft, borderWidth: 1, borderColor: '#714046', padding: Spacing.md, gap: 4 },
  refusalCode: { color: Palette.red, fontFamily: Type.mono, fontSize: 10, fontWeight: '900', letterSpacing: 0.6 },
  refusalText: { color: '#D9A6A8', fontFamily: Type.sans, fontSize: 9, lineHeight: 14 },
  refusalCorrelation: { color: '#A87B7E', fontFamily: Type.mono, fontSize: 8 },
  prepared: { gap: 6 },
  preparedHead: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.sm, marginBottom: 4 },
  preparedTitle: { color: Palette.ink, fontFamily: Type.sans, fontSize: 14, fontWeight: '800' },
  ack: { gap: 2, marginBottom: Spacing.sm, borderLeftWidth: 2, borderLeftColor: Palette.line, paddingLeft: Spacing.sm },
  ackDecision: { color: Palette.ink, fontFamily: Type.mono, fontSize: 10, fontWeight: '900' },
  ackDetail: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  ackHash: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 7, opacity: 0.7 },
  ackFootnote: { color: Palette.inkMuted, fontFamily: Type.sans, fontSize: 9, fontStyle: 'italic', marginTop: 4 },
  link: { gap: 2, marginBottom: 6, borderLeftWidth: 2, borderLeftColor: Palette.line, paddingLeft: Spacing.sm },
  linkType: { color: Palette.inkSoft, fontFamily: Type.mono, fontSize: 9, fontWeight: '800' },
  linkDetail: { color: Palette.inkMuted, fontFamily: Type.mono, fontSize: 8 },
  cancelForm: { gap: Spacing.md, marginTop: Spacing.md },
});
