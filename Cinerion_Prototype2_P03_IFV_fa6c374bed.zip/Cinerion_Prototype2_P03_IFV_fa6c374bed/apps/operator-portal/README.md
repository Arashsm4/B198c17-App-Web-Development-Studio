# Cinerion Operator Portal

The Expo/React Native operator surface for the Cinerion CH1 platform. The same source targets web, Android, and iOS; Prototype 1 is verified as a static web export and can be started with:

```bash
npm run web
```

The portal may prepare or cancel command intent. It deliberately exposes no software control capable of satisfying local physical commitment. Device-originated credential proof, a new physical-button edge, and current controller permissives are enforced by the command service and device state machines.

All displayed records are representative simulated data until the API adapter is enabled. `P03/IFV` permits simulation and controlled extra-low-voltage prototype work only.
