/**
 * Loads the portal's own TypeScript/JSX sources into plain Node.
 *
 * The harness renders the shipped screen modules unmodified, so something has to do
 * what Metro does at build time: strip the types, compile the JSX, resolve the `@/`
 * alias, and point `react-native` at `react-native-web`. That is all this does. It
 * adds no dependency — `@babel/core`, the JSX transform and the TypeScript preset are
 * already in the tree because Expo builds the portal with them.
 *
 * What it deliberately does NOT do is substitute anything the screen reasons with. The
 * only modules aliased away are the ones that are a *host* rather than a subject:
 * navigation, the OIDC browser flow, and the native-only shims. Their stubs live in
 * `stubs/` and each says what it stands in for and what would be untested because of
 * it. Anything else — the API client, the hooks, the contracts, the components, the
 * screen — is the real file.
 */
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

import babel from '@babel/core';

const harnessDir = path.dirname(fileURLToPath(import.meta.url));
const portalDir = path.dirname(harnessDir);
const srcDir = path.join(portalDir, 'src');
const stubsDir = path.join(harnessDir, 'stubs');

const SOURCE_EXTENSIONS = ['.tsx', '.ts', '.jsx', '.js'];

/**
 * Modules replaced by a harness stub, each with the reason.
 *
 * Every entry here is a boundary the harness cannot cross in Node, not a convenience.
 * `scripts/check-portal-render.mjs` prints this list with every run, so a reader of the
 * gate's output can see exactly what was not real without opening this file.
 */
export const STUBBED_MODULES = Object.freeze({
  'expo-router':
    'Navigation. The harness renders one route directly, so the router is a recorder: it captures pushes rather than performing them, and a screen that navigates can be asserted on.',
  'expo-auth-session':
    'The OIDC browser redirect. Obtaining a real token needs a person at a keyboard, so the harness supplies the session it was given and never authenticates.',
  'expo-web-browser': 'Opens the system browser. Nothing in a rendered screen may do that here.',
  'expo-linking': 'Builds native deep links from the app scheme.',
  'expo-constants': 'Expo build manifest.',
  'expo-crypto': 'Native crypto shim; Node has WebCrypto.',
  'expo-status-bar': 'A native status bar has no meaning on a rendered page.',
  'react-native-safe-area-context':
    'Device safe-area insets. A workstation has none, so this is the passthrough a web build already resolves to.',
});

function resolveSourceFile(candidate) {
  if (path.extname(candidate) !== '' && existsSync(candidate)) return candidate;
  for (const extension of SOURCE_EXTENSIONS) {
    const withExtension = `${candidate}${extension}`;
    if (existsSync(withExtension)) return withExtension;
  }
  for (const extension of SOURCE_EXTENSIONS) {
    const asIndex = path.join(candidate, `index${extension}`);
    if (existsSync(asIndex)) return asIndex;
  }
  return undefined;
}

export function resolve(specifier, context, nextResolve) {
  const stub = Object.keys(STUBBED_MODULES).find(
    (name) => specifier === name || specifier.startsWith(`${name}/`),
  );
  if (stub !== undefined) {
    const file = path.join(stubsDir, `${stub}.mjs`);
    return { url: pathToFileURL(file).href, shortCircuit: true };
  }

  // react-native is the module the source imports; react-native-web is what a browser
  // actually runs. Expo does this substitution with babel-plugin-react-native-web.
  if (specifier === 'react-native') {
    return nextResolve('react-native-web', context);
  }

  if (specifier.startsWith('@/')) {
    const rest = specifier.slice(2);
    const base = rest.startsWith('assets/')
      ? path.join(portalDir, rest)
      : path.join(srcDir, rest);
    const file = resolveSourceFile(base);
    if (file === undefined) throw new Error(`Harness cannot resolve "${specifier}".`);
    return { url: pathToFileURL(file).href, shortCircuit: true };
  }

  if (
    (specifier.startsWith('./') || specifier.startsWith('../')) &&
    context.parentURL?.startsWith('file:')
  ) {
    const parent = path.dirname(fileURLToPath(context.parentURL));
    const base = path.resolve(parent, specifier);
    if (path.extname(base) === '' || !existsSync(base)) {
      const file = resolveSourceFile(base);
      if (file !== undefined) return { url: pathToFileURL(file).href, shortCircuit: true };
    }
  }

  return nextResolve(specifier, context);
}

export function load(url, context, nextLoad) {
  if (!url.startsWith('file:')) return nextLoad(url, context);
  const file = fileURLToPath(url);
  const extension = path.extname(file);
  if (extension !== '.ts' && extension !== '.tsx') return nextLoad(url, context);

  const source = readFileSync(file, 'utf8');
  const compiled = babel.transformSync(source, {
    filename: file,
    babelrc: false,
    configFile: false,
    sourceMaps: 'inline',
    // ESM is kept as ESM: Node loads the output directly, so nothing needs to be
    // downlevelled beyond types and JSX.
    presets: [[require_('@babel/preset-typescript'), { isTSX: true, allExtensions: true }]],
    plugins: [[require_('@babel/plugin-transform-react-jsx'), { runtime: 'automatic' }]],
  });

  return { format: 'module', source: compiled.code, shortCircuit: true };
}

// Resolved from the portal's own dependency tree rather than by bare specifier, so the
// loader uses the same Babel the build does.
function require_(name) {
  return path.join(portalDir, '..', '..', 'node_modules', name);
}
