/**
 * The safe-area inset provider, which only a physical device has.
 *
 * On a web build this resolves to a passthrough already: there is no notch and no home
 * indicator on an operator workstation, so `SafeAreaView` is a `View` with zero insets.
 * The package's published entry point is its native one, whose specs are Flow source
 * Node cannot parse, so the web behaviour is expressed directly here.
 */
import { createElement } from 'react';
import { View } from 'react-native-web';

const ZERO_INSETS = { top: 0, right: 0, bottom: 0, left: 0 };

export function SafeAreaView({ children, style, ...rest }) {
  return createElement(View, { style, ...rest }, children);
}

export function SafeAreaProvider({ children }) {
  return children;
}

export function useSafeAreaInsets() {
  return ZERO_INSETS;
}

export function useSafeAreaFrame() {
  return { x: 0, y: 0, width: 1440, height: 900 };
}

export const initialWindowMetrics = { frame: { x: 0, y: 0, width: 1440, height: 900 }, insets: ZERO_INSETS };
