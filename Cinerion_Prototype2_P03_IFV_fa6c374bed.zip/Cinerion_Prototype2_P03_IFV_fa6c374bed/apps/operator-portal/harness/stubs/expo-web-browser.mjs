/**
 * Opening the system browser is refused rather than simulated.
 *
 * Nothing a rendered screen does in this harness may leave the process. A screen that
 * tried would fail loudly here instead of silently doing nothing.
 */
export async function openAuthSessionAsync() {
  throw new Error('The harness does not open a browser.');
}
export async function openBrowserAsync() {
  throw new Error('The harness does not open a browser.');
}
export function maybeCompleteAuthSession() {
  return { type: 'failed' };
}
