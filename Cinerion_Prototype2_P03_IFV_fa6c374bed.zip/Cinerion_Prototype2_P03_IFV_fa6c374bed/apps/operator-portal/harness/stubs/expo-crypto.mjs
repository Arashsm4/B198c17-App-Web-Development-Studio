// Stand-in for expo-crypto in the render harness, backed by Node's own crypto.

export function randomUUID() {
  return globalThis.crypto.randomUUID();
}
export function getRandomBytes(length) {
  return globalThis.crypto.getRandomValues(new Uint8Array(length));
}
