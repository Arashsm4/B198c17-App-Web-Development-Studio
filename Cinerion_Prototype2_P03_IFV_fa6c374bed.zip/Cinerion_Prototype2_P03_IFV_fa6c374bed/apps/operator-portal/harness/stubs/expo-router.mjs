/**
 * Navigation, recorded rather than performed.
 *
 * The harness renders one route at a time, so there is nowhere for a push to go. What
 * matters for a screen's verified behaviour is *that* it navigates and *where*, so
 * every call is recorded and can be asserted on. A screen that navigated somewhere it
 * should not is then a failed assertion rather than an invisible no-op.
 */
import { createElement } from 'react';

const navigations = [];

export function recordedNavigations() {
  return navigations.slice();
}

export function clearRecordedNavigations() {
  navigations.length = 0;
}

export const router = {
  push: (target) => navigations.push({ kind: 'push', target }),
  replace: (target) => navigations.push({ kind: 'replace', target }),
  navigate: (target) => navigations.push({ kind: 'navigate', target }),
  back: () => navigations.push({ kind: 'back' }),
  canGoBack: () => false,
  setParams: (params) => navigations.push({ kind: 'setParams', target: params }),
};

/**
 * Route parameters, supplied by the harness rather than parsed from a URL.
 *
 * A screen reached with a parameter (an alarm's thread, a part identifier) has to be
 * renderable with one, so the harness sets them before rendering.
 */
let searchParams = {};

export function setLocalSearchParams(params) {
  searchParams = { ...params };
}

export function useLocalSearchParams() {
  return searchParams;
}

export function useGlobalSearchParams() {
  return searchParams;
}

export function usePathname() {
  return '/';
}

export function useRouter() {
  return router;
}

export function Link({ children }) {
  return createElement('a', {}, children);
}

export const DarkTheme = { dark: true, colors: {} };

export function Stack() {
  return null;
}
Stack.Screen = function StackScreen() {
  return null;
};

export function ThemeProvider({ children }) {
  return children;
}
