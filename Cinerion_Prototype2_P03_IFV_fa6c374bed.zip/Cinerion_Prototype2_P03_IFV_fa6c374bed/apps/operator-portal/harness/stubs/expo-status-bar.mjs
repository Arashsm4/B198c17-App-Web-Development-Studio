/** A native status bar has no rendered form on a page. */
export function StatusBar() {
  return null;
}
