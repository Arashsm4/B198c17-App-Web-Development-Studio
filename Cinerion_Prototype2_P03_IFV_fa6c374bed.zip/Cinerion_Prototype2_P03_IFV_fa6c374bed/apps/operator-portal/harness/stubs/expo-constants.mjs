// Stand-in for expo-constants in the render harness. It has nothing to say, and says it.

export default { expoConfig: { scheme: 'cinerion' }, executionEnvironment: 'bare' };
