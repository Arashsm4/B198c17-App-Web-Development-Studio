/**
 * The OIDC browser redirect, and only that.
 *
 * A real access token comes from a person typing a password at FortressGate, which is
 * the one class of evidence this harness cannot produce. So the redirect is stood in
 * for — and nothing else about the session is. `SessionProvider` is the shipped one:
 * it still reads the authorisation response out of the address bar, still compares the
 * returned state against what the tab stored, still consumes the pending request so it
 * cannot be redeemed twice, and still decodes the token's claims with the portal's own
 * `readTokenClaims`. The harness drives that path exactly as the browser does.
 *
 * `exchangeCodeAsync` therefore refuses an authorisation code the harness did not
 * issue. A stub that answered any code with a token would make the state check
 * unfalsifiable and would report a signed-in session for a redemption that never
 * happened.
 */
export const ResponseType = Object.freeze({ Code: 'code', Token: 'token' });

let issued;

/**
 * Arranges one authorisation the harness will later redeem.
 *
 * The access token is supplied by the caller: an unsigned JWT carrying the claims the
 * screen is to be rendered for. The portal never verifies a token — Control Core does,
 * on every request — so an unsigned one is the honest shape for a harness that is
 * testing rendering rather than authentication.
 */
export function issueHarnessAuthorization({ code, accessToken, discovery, refreshToken }) {
  issued = { code, accessToken, discovery, refreshToken };
  return issued;
}

export function useAutoDiscovery(issuer) {
  if (!issuer) return null;
  return (
    issued?.discovery ?? {
      authorizationEndpoint: `${issuer}/protocol/openid-connect/auth`,
      tokenEndpoint: `${issuer}/protocol/openid-connect/token`,
      endSessionEndpoint: `${issuer}/protocol/openid-connect/logout`,
    }
  );
}

export function makeRedirectUri() {
  return globalThis.location?.origin ?? 'http://portal.harness.invalid';
}

export function useAuthRequest() {
  // No popup path here: the harness always arrives through the redirect route, which
  // is what a browser on an operator workstation does.
  return [null, null, async () => ({ type: 'dismiss' })];
}

export async function exchangeCodeAsync(config) {
  if (issued === undefined || config.code !== issued.code) {
    throw new Error(
      'The harness was asked to redeem an authorisation code it never issued. Nothing was exchanged.',
    );
  }
  // An authorisation code is single-use at every real provider, and the harness refuses
  // a second redemption for the same reason it refuses an unknown one: a stub that
  // answered a replay would let the portal resurrect a session that had ended, and
  // would report that as a pass. It did exactly that until this was added.
  if (issued.redeemed) {
    throw new Error('invalid_grant: the authorisation code has already been redeemed.');
  }
  issued.redeemed = true;
  return {
    accessToken: issued.accessToken,
    refreshToken: issued.refreshToken,
    tokenType: 'Bearer',
    expiresIn: 300,
  };
}

/**
 * What the provider will do when this tab asks to renew.
 *
 * Declared per scenario rather than defaulted, because the two outcomes are the whole
 * subject: a provider that renews while the SSO session is alive, and one that refuses
 * because it is not. A default would make one of them the case nothing exercises.
 *
 * `refreshAsync` refuses a refresh token the harness did not issue, for the same reason
 * `exchangeCodeAsync` refuses an unknown code: a stub that renewed anything would make
 * the single-flight guard and the rotation behaviour unfalsifiable.
 */
let renewal;

export function arrangeHarnessRenewal(plan) {
  renewal = { attempts: 0, ...plan };
  return renewal;
}

/** How many times the portal actually asked to renew. Single-flight is measured with this. */
export function renewalAttempts() {
  return renewal?.attempts ?? 0;
}

export async function refreshAsync(config, _discovery) {
  if (renewal === undefined) {
    throw new Error('The harness was asked to renew a session for which no renewal was arranged.');
  }
  renewal.attempts += 1;
  if (config.refreshToken !== renewal.expectRefreshToken) {
    throw new Error(
      `The harness was presented a refresh token it never issued (${String(config.refreshToken)}).`,
    );
  }
  if (renewal.refuse) {
    throw new Error(renewal.refuse);
  }
  return {
    accessToken: renewal.accessToken,
    // Keycloak rotates the refresh token on every use, so the harness does too: a
    // portal that kept presenting the first one would fail against a real provider.
    refreshToken: renewal.rotatedRefreshToken ?? renewal.expectRefreshToken,
    tokenType: 'Bearer',
    expiresIn: 300,
  };
}

export async function revokeAsync() {
  return true;
}
