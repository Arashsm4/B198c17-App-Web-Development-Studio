// Stand-in for expo-linking in the render harness. Links lead nowhere in a test, which is
// exactly where we want them.

export function createURL(pathname = '/') {
  return `http://portal.harness.invalid${pathname}`;
}
export function useURL() {
  return undefined;
}
