/**
 * The captured responses this harness renders against.
 *
 * `artifacts/contracts/*.json` is written by `PortalContractFixtureTests`, which issues
 * a real request through the test host for every shape the portal declares and stores
 * what came back. `npm run contracts:portal` already refuses a declared property the
 * service does not send. So a screen rendered against these is rendered against what
 * Control Core actually answers — not against a fixture somebody typed, which would be
 * a second declaration to keep in step rather than evidence about the first.
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const contractsDir = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  '..',
  '..',
  '..',
  'artifacts',
  'contracts',
);

export function captured(shape) {
  const file = path.join(contractsDir, `${shape}.json`);
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch (cause) {
    throw new Error(
      `No captured response for ${shape}. Run "dotnet test" to regenerate artifacts/contracts (${cause.message}).`,
    );
  }
}
