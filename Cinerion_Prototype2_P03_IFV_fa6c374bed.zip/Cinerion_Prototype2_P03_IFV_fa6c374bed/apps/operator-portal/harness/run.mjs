/**
 * Runs one portal scenario in its own process.
 *
 * One process per scenario, deliberately. Node caches modules for the lifetime of a
 * process and several of the portal's own modules are stateful at module scope —
 * `client.ts` reads its endpoint configuration once, and `session.tsx` consumes the
 * authorisation response of "this page load" exactly once, which is correct behaviour
 * and would make a second scenario in the same process a different test from the first.
 * A fresh process is the cheap way to make every scenario start from the state a
 * freshly loaded tab starts from.
 *
 *   node apps/operator-portal/harness/run.mjs --scenario control-room-live
 *   node apps/operator-portal/harness/run.mjs --list
 */
import { installBrowserEnvironment, ControlCoreDouble } from './environment.mjs';
import { harnessAccessToken } from './identity.mjs';
import { scenarios as appShellScenarios } from './screens/app-shell.mjs';
import { scenarios as auditSecurityCommsCredentialScenarios } from './screens/audit-security-comms-credentials.mjs';
import { scenarios as collaborationScenarios } from './screens/collaboration.mjs';
import { scenarios as controlRoomScenarios } from './screens/control-room.mjs';
import { scenarios as devicesScenarios } from './screens/devices.mjs';
import { scenarios as genealogyScenarios } from './screens/genealogy.mjs';
import { scenarios as operationalStateScenarios } from './screens/operational-state.mjs';
import { scenarios as ownerApprovedReadScenarios } from './screens/owner-approved-reads.mjs';
import { scenarios as permissiveScenarios } from './screens/permissives.mjs';
import { scenarios as procedureScenarios } from './screens/procedure.mjs';
import { scenarios as qualityPortfolioAssetScenarios } from './screens/quality-portfolio-assets.mjs';
import { scenarios as resourceScenarios } from './screens/resources.mjs';
import { scenarios as roleCapabilityScenarios } from './screens/role-capability.mjs';
import { scenarios as sessionLifetimeScenarios } from './screens/session-lifetime.mjs';
import { scenarios as simulatedCellScenarios } from './screens/simulated-cell.mjs';
import { scenarios as sessionScenarios } from './screens/session.mjs';
import { scenarios as workOrderScenarios } from './screens/work-orders.mjs';

export const allScenarios = [
  ...appShellScenarios,
  ...auditSecurityCommsCredentialScenarios,
  ...collaborationScenarios,
  ...controlRoomScenarios,
  ...genealogyScenarios,
  ...devicesScenarios,
  ...operationalStateScenarios,
  ...permissiveScenarios,
  ...procedureScenarios,
  ...qualityPortfolioAssetScenarios,
  ...resourceScenarios,
  ...roleCapabilityScenarios,
  ...sessionLifetimeScenarios,
  ...simulatedCellScenarios,
  ...sessionScenarios,
  ...workOrderScenarios,
  ...ownerApprovedReadScenarios,
];

const AUTHORIZATION = Object.freeze({
  code: 'harness-authorization-code',
  state: 'harness-request-state',
  pending: { state: 'harness-request-state', codeVerifier: 'harness-code-verifier' },
});

function argument(name) {
  const index = process.argv.indexOf(name);
  return index === -1 ? undefined : process.argv[index + 1];
}

if (process.argv.includes('--list')) {
  for (const scenario of allScenarios) {
    console.log(`${scenario.id}\t${scenario.screen}\t${scenario.verificationCase ?? '-'}\t${scenario.title}`);
  }
  process.exit(0);
}

const scenarioId = argument('--scenario');
const scenario = allScenarios.find((candidate) => candidate.id === scenarioId);
if (scenario === undefined) {
  console.error(`Unknown scenario "${scenarioId}". Run with --list to see them.`);
  process.exit(2);
}

// Order is load-bearing: the environment sets the EXPO_PUBLIC_* values `client.ts` reads
// at module scope and installs the DOM `react-native-web` registers against while it
// loads, and both have to be in place before any portal module is imported.
installBrowserEnvironment({
  route: scenario.route,
  authorization: AUTHORIZATION,
  // A scenario that says nothing about the window gets the desktop viewport, which is
  // what an operator workstation is. A scenario about layout declares its own.
  viewport: scenario.viewport,
  environment: scenario.environment,
});

const { installModuleResolution } = await import('./bootstrap.mjs');
installModuleResolution();

const authSession = await import('./stubs/expo-auth-session.mjs');
authSession.issueHarnessAuthorization({
  code: AUTHORIZATION.code,
  accessToken: harnessAccessToken(scenario.claims),
  // A scenario that says nothing about renewal gets no refresh token at all, which is
  // what a provider that issues none looks like. Only a scenario about session lifetime
  // arranges one, so nothing else silently depends on renewal existing.
  refreshToken: scenario.renewal?.expectRefreshToken,
});
if (scenario.renewal !== undefined) {
  authSession.arrangeHarnessRenewal(scenario.renewal);
}

const service = new ControlCoreDouble(scenario.routes());
service.install();

const routerStub = await import('./stubs/expo-router.mjs');
const react = await import('react');
const render = await import('./render.mjs');
const { SessionProvider } = await import('@/auth/session');

/**
 * Mounts a shipped screen inside the shipped session provider.
 *
 * `SessionProvider` is the real one. It reads the authorisation response out of the
 * address bar, compares its state against the request the tab stored, consumes both,
 * exchanges the code and decodes the claims with the portal's own `readTokenClaims`.
 * Only the redirect itself is stood in for; see `stubs/expo-auth-session.mjs`.
 */
async function mountScreen(modulePath) {
  const module = await import(modulePath);
  return render.mount(react.createElement(SessionProvider, null, react.createElement(module.default)));
}

const context = {
  service,
  mountScreen,
  mountElement: render.mount,
  createElement: react.createElement,
  importPortal: (modulePath) => import(modulePath),
  renderedText: render.renderedText,
  findByText: render.findByText,
  findAll: render.findAll,
  press: render.press,
  pressAll: render.pressAll,
  typeInto: render.typeInto,
  settle: render.settle,
  advance: render.advance,
  navigations: routerStub.recordedNavigations,
  renewalAttempts: authSession.renewalAttempts,
};

console.log(`SCENARIO ${scenario.id} — ${scenario.title}`);
let checks;
try {
  checks = await scenario.run.call(scenario, context);
} catch (cause) {
  console.error(`  FAIL the scenario raised: ${cause?.stack ?? cause}`);
  process.exit(1);
}

// Optional: save what we just rendered so a REAL browser can lay it out. jsdom never
// computes a single box, which is exactly how a title squashed to one letter per line
// sailed through 630 green checks. Off unless you ask for it.
if (process.env.CINERION_RENDER_SNAPSHOT_DIR) {
  const { writeSnapshot } = await import('./snapshot.mjs');
  await writeSnapshot(process.env.CINERION_RENDER_SNAPSHOT_DIR, scenario);
}

const passed = checks.report();
console.log(
  `  ${checks.results.length} checks, ${checks.failures.length} failed` +
    `, ${service.requests.length} requests to Control Core` +
    `, ${service.unexpected.length} of them unanswerable from captured responses`,
);
if (passed && scenario.verificationCase !== undefined) {
  // Printed only after every assertion above has held, which is the rule every
  // announcing harness in this repository follows.
  console.log(`VERIFICATION-CASE ${scenario.verificationCase}`);
}
process.exit(passed ? 0 : 1);
