/**
 * A DOM for the portal, and a Control Core that answers only what was captured.
 *
 * Two things have to be true before a screen module may be imported. The portal's
 * build-time configuration has to be in the environment, because `client.ts` reads
 * `EXPO_PUBLIC_*` at module scope and a value set afterwards would never be seen. And
 * a DOM has to exist, because `react-native-web` registers its style sheet against
 * `document` while it loads. Both are done here, before anything from `src/` is
 * imported.
 */
import { JSDOM } from 'jsdom';

/** Where the harness's Control Core lives. Nothing may reach a real host from here. */
export const API_BASE_URL = 'http://control-core.harness.invalid';
export const OIDC_AUTHORITY = 'http://fortressgate.harness.invalid/realms/cinerion';
export const PORTAL_ORIGIN = 'http://portal.harness.invalid';

/**
 * Globals the harness deliberately keeps as Node's own.
 *
 * Everything else jsdom defines is copied onto the global object, because
 * `react-native-web` and the portal's components reach for browser constructors at
 * module scope — `ShadowRoot`, `CSSStyleSheet`, `MutationObserver` — and a missing one
 * fails at import time rather than at render time. Timers, promises and `fetch` stay
 * Node's: the first two are what React's `act` schedules on, and the third is replaced
 * by the captured-response double below.
 */
const KEPT_FROM_NODE = new Set([
  'window',
  'globalThis',
  'global',
  'self',
  'top',
  'parent',
  'frames',
  'undefined',
  'fetch',
  'Headers',
  'Request',
  'Response',
  'AbortController',
  'AbortSignal',
  'setTimeout',
  'clearTimeout',
  'setInterval',
  'clearInterval',
  'setImmediate',
  'clearImmediate',
  'queueMicrotask',
  'Promise',
  'crypto',
  'performance',
  'console',
  'process',
  'Buffer',
  'require',
  'module',
  'exports',
  // jsdom's own `atob`/`btoa` are methods of its window and refuse to run with any
  // other receiver, and in this process `globalThis` is not that window. In a browser
  // the two are the same object, so `globalThis.atob(...)` — which is how the portal
  // decodes a token's claims — works there and would throw here for a reason that has
  // nothing to do with the portal. Node's implementations are the same WHATWG
  // algorithm and have no receiver to lose.
  'atob',
  'btoa',
]);

/**
 * Installs the browser globals the portal's own code and react-native-web expect.
 *
 * `pendingAuthorization` seeds `sessionStorage` exactly as the shipped `signIn` does
 * before it navigates away, and the URL carries the authorisation response exactly as
 * FortressGate's redirect does. `SessionProvider` is then the shipped one, running its
 * real state comparison against a real stored request.
 */
export const DESKTOP_VIEWPORT = Object.freeze({ width: 1440, height: 900 });

/**
 * Gives jsdom a viewport, because without one the portal renders a branch no operator
 * ever sees.
 *
 * `react-native-web`'s `Dimensions` reads `document.documentElement.clientWidth` and
 * `clientHeight`. jsdom performs no layout and answers 0 for both, so every screen in
 * this harness measured a zero-width window - and `AppShell` treats anything below 980
 * as compact. Every scenario had therefore only ever rendered the mobile header; the
 * desktop workspace rail had never been rendered by anything in CI at all, which is how
 * a rail that clipped its own navigation list survived.
 *
 * Defining the two properties is the whole fix: they are the only inputs `Dimensions`
 * has, and a declared viewport is an honest stand-in for a measurement jsdom cannot
 * make. `innerWidth`/`innerHeight` are set to match so nothing reading the other pair
 * disagrees with it.
 */
function declareViewport(window, { width, height }) {
  for (const [name, value] of [['clientWidth', width], ['clientHeight', height]]) {
    Object.defineProperty(window.document.documentElement, name, {
      value,
      configurable: true,
    });
  }
  window.innerWidth = width;
  window.innerHeight = height;
}

export function installBrowserEnvironment({
  route = '/control-room',
  authorization,
  viewport,
  environment,
} = {}) {
  process.env.EXPO_PUBLIC_CINERION_API_URL = API_BASE_URL;
  process.env.EXPO_PUBLIC_CINERION_OIDC_AUTHORITY = OIDC_AUTHORITY;
  process.env.EXPO_PUBLIC_CINERION_OIDC_CLIENT_ID = 'cinerion-operator-portal';
  // Further build-time values a scenario declares. `client.ts` reads EXPO_PUBLIC_* once at
  // module scope, so a value set after the first portal import would never be seen - which
  // is the same ordering this whole function exists to get right. A scenario that declares
  // nothing gets a build with nothing extra configured, which is what a production build is.
  for (const [name, value] of Object.entries(environment ?? {})) {
    process.env[name] = value;
  }

  const query =
    authorization === undefined
      ? ''
      : `?code=${encodeURIComponent(authorization.code)}&state=${encodeURIComponent(authorization.state)}`;

  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    url: `${PORTAL_ORIGIN}${route}${query}`,
    pretendToBeVisual: true,
  });

  // Assigned by descriptor because Node defines some of these — `navigator` among
  // them — as getter-only on the global object, and a plain assignment throws.
  const define = (name, value) =>
    Object.defineProperty(globalThis, name, { value, configurable: true, writable: true });

  define('window', dom.window);
  define('document', dom.window.document);
  define('navigator', dom.window.navigator);
  define('location', dom.window.location);
  define('history', dom.window.history);
  define('localStorage', dom.window.localStorage);
  define('sessionStorage', dom.window.sessionStorage);
  for (const name of Object.getOwnPropertyNames(dom.window)) {
    if (KEPT_FROM_NODE.has(name)) continue;
    if (name.startsWith('_')) continue;
    const existing = Object.getOwnPropertyDescriptor(globalThis, name);
    // A non-configurable global (`Infinity`, `NaN`, the intrinsics) is the language's,
    // not the document's, and is left exactly as it is.
    if (existing !== undefined && existing.configurable === false) continue;
    const value = dom.window[name];
    if (value === undefined) continue;
    define(name, value);
  }
  // react-native-web measures the viewport through Dimensions, which reads the
  // document element's client box rather than innerWidth. See declareViewport.
  declareViewport(dom.window, viewport ?? DESKTOP_VIEWPORT);

  if (authorization?.pending !== undefined) {
    dom.window.sessionStorage.setItem(
      'cinerion.oidc.pending-authorization',
      JSON.stringify(authorization.pending),
    );
  }

  // jsdom implements no layout, so it has no ResizeObserver. react-native-web's
  // `onLayout` warns once and continues without it; nothing this harness asserts is a
  // measured size, so a no-op observer is the honest stand-in rather than a fabricated
  // measurement.
  if (globalThis.ResizeObserver === undefined) {
    define('ResizeObserver', class HarnessResizeObserver {
      observe() {}
      unobserve() {}
      disconnect() {}
    });
    dom.window.ResizeObserver = globalThis.ResizeObserver;
  }

  globalThis.IS_REACT_ACT_ENVIRONMENT = true;
  return dom;
}

/**
 * A record of what the screen asked Control Core for, and what it was given.
 *
 * The routes are declared by the screen definition and answered from
 * `artifacts/contracts/`, which holds responses captured from a *real* service by
 * `PortalContractFixtureTests`. A request the definition does not declare is refused
 * and recorded as unexpected — never answered with an invented body and never quietly
 * 404'd, because either would let a screen that asks for the wrong thing keep passing.
 */
export class ControlCoreDouble {
  constructor(routes) {
    this.routes = routes;
    this.requests = [];
    this.unexpected = [];
  }

  /** Refuses this route from now on, as a service that has gone away does. */
  disconnect(pattern) {
    this.disconnected = pattern;
  }

  reconnect() {
    this.disconnected = undefined;
  }

  install() {
    globalThis.fetch = async (input, init = {}) => {
      const url = typeof input === 'string' ? input : input.url;
      const method = (init.method ?? 'GET').toUpperCase();
      if (!url.startsWith(API_BASE_URL)) {
        this.unexpected.push({ method, url, reason: 'not addressed to Control Core' });
        throw new TypeError(`The harness refuses a request to ${url}.`);
      }
      const target = url.slice(API_BASE_URL.length);
      const body = init.body === undefined ? undefined : JSON.parse(init.body);
      const headers = init.headers ?? {};
      this.requests.push({ method, path: target, body, headers });

      if (this.disconnected !== undefined && target.startsWith(this.disconnected)) {
        throw new TypeError('fetch failed');
      }

      const route = this.routes.find(
        (candidate) => candidate.method === method && candidate.matches(target),
      );
      if (route === undefined) {
        this.unexpected.push({ method, url: target, reason: 'no captured response declared' });
        throw new TypeError(`The harness has no captured response for ${method} ${target}.`);
      }
      const answered = await route.answer(target, body);
      // A route whose status is fixed declares it once; a route whose status CHANGES
      // between calls — refused while a token is expired, answered once it has been
      // renewed — returns `refusal(...)` instead. It cannot be done with `route.status`
      // because the status would have to be read before `answer` runs, and then a route
      // could never refuse and recover within one scenario.
      return answered instanceof HarnessRefusal
        ? jsonResponse(answered.status, answered.body)
        : jsonResponse(route.status ?? 200, answered);
    };
  }

  /** Requests this screen made, in order, for assertions about what it asked for. */
  pathsRequested(method = 'GET') {
    return this.requests.filter((request) => request.method === method).map((request) => request.path);
  }
}

/**
 * A refusal a route decides on per call, rather than for its whole lifetime.
 *
 * Returned from `answer` so the status and the body are decided together; a route that
 * answered a 200 body with a 401 status, or the reverse, would be testing the harness.
 */
class HarnessRefusal {
  constructor(status, body) {
    this.status = status;
    this.body = body;
  }
}

export function refusal(status, body) {
  return new HarnessRefusal(status, body);
}

function jsonResponse(status, payload) {
  const text = JSON.stringify(payload);
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: status === 200 ? 'OK' : 'Refused',
    json: async () => JSON.parse(text),
    text: async () => text,
  };
}
