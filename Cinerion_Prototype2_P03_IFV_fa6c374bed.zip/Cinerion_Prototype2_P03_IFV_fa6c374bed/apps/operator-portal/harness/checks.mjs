/**
 * The assertion record for one scenario.
 *
 * Every check is named and its result printed, passing or failing, so the gate's output
 * is a list of what was actually established rather than a count. A scenario that
 * asserts nothing is itself a failure: a harness that renders a screen and checks
 * nothing about it would pass forever.
 */
export class Checks {
  constructor(scenario) {
    this.scenario = scenario;
    this.results = [];
  }

  that(label, condition, detail) {
    this.results.push({ label, passed: condition === true, detail });
    return condition === true;
  }

  /** Asserts the rendered page contains a phrase, quoting what was missing if not. */
  contains(label, text, needle) {
    return this.that(label, text.includes(needle), `expected to find: ${needle}`);
  }

  omits(label, text, needle) {
    return this.that(label, !text.includes(needle), `expected NOT to find: ${needle}`);
  }

  equals(label, actual, expected) {
    return this.that(label, Object.is(actual, expected), `expected ${expected}, observed ${actual}`);
  }

  get failures() {
    return this.results.filter((result) => !result.passed);
  }

  report() {
    for (const result of this.results) {
      const mark = result.passed ? 'ok  ' : 'FAIL';
      console.log(`  ${mark} ${result.label}${result.passed ? '' : ` — ${result.detail ?? ''}`}`);
    }
    if (this.results.length === 0) {
      console.log('  FAIL scenario asserted nothing');
      return false;
    }
    return this.failures.length === 0;
  }
}

/**
 * The harness's own rendering of a controlled timestamp.
 *
 * Deliberately a second implementation rather than a call into the portal's `instant`:
 * an expected value computed by the code under test agrees with it by construction and
 * proves nothing. This is the same argument the Modbus map's two copies rest on.
 */
export function expectedInstant(iso) {
  if (!iso) return '—';
  const parsed = Date.parse(iso);
  if (Number.isNaN(parsed)) return iso;
  return `${new Date(parsed).toISOString().slice(0, 19).replace('T', ' ')}Z`;
}

export function expectedTimeOfDay(iso) {
  if (!iso) return '—';
  const parsed = Date.parse(iso);
  if (Number.isNaN(parsed)) return iso;
  return `${new Date(parsed).toISOString().slice(11, 19)}Z`;
}

/**
 * The harness's own rendering of a telemetry value, and its own idea of which reading is
 * current on a channel.
 *
 * Both are second implementations for the same reason as {@link expectedInstant}: an
 * expectation computed by calling the screen's `formatValue` or `newestPerChannel` would
 * agree with them however either behaved.
 */
export function expectedValue(value) {
  return Number.isInteger(value) ? String(value) : value.toFixed(2);
}

export function newestPerChannel(samples) {
  const newest = new Map();
  for (const sample of samples) {
    const held = newest.get(sample.channelId);
    if (held === undefined || Date.parse(sample.sampledAt) > Date.parse(held.sampledAt)) {
      newest.set(sample.channelId, sample);
    }
  }
  return newest;
}
