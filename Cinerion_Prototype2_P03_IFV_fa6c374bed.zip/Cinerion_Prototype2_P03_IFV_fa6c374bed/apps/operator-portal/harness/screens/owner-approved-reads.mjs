/**
 * The four screens that could not be built until the owner approved five reads, driven at
 * the interface.
 *
 * CH1-UX-SCR-0012 (instrument and calibration register), CH1-UX-SCR-0015 (mobile scan and
 * evidence mode), CH1-UX-SCR-0020 (R&D workbench) and CH1-UX-SCR-0021 (experiment promotion
 * review) each named a subject the P03 catalogue can write and cannot read back. They were
 * recorded as unbuildable for four sessions.
 *
 * WHAT THESE SCENARIOS ARE FOR is not that the screens render. It is that each one still
 * distinguishes the three states an operator must never confuse:
 *
 *   withheld   — this identity may not read it
 *   empty      — this identity may read it and there is nothing there
 *   populated  — this is what there is
 *
 * A screen that showed an empty register to an identity lacking the role would be telling
 * an inspector that no instrument in the project has a certificate. That is the same class
 * of mistake as defect 47, where a protobuf default rendered as a fact.
 *
 * And two safety-relevant properties that survive being read rather than written: the scan
 * register must never disclose the session signature, and the workbench must never render
 * an experiment as production work.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');

/** An identity holding the roles each screen's read actually requires. */
function reader(roles) {
  return { ...assignedOperator(), roles };
}

function baseRoutes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
  ];
}

export const scenarios = [
  // ------------------------------------------------------------- CH1-UX-SCR-0012
  {
    id: 'calibration-register',
    screen: 'CH1-UX-SCR-0012',
    route: '/calibration',
    title: 'Certificates, and whether each is still valid',
    claims: reader(['Inspector', 'Viewer']),
    routes: () => [
      ...baseRoutes(),
      {
        method: 'GET',
        matches: (p) => p.startsWith('/api/v1/calibrations'),
        answer: async () => captured('CalibrationPage'),
      },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('calibration-register');
      await mountScreen('@/app/calibration.tsx');
      const text = renderedText();
      const page = captured('CalibrationPage');

      checks.that(
        'the screen asked Control Core for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'reading the register wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      // Every certificate the service sent is on the screen, by instrument and by number.
      for (const entry of page.items) {
        checks.contains(`instrument ${entry.instrumentId} is listed`, text, entry.instrumentId);
        checks.contains(`its certificate ${entry.certificateNumber} is listed`, text, entry.certificateNumber);
      }

      // The validity verdict comes from the service, and the screen renders the service's
      // verdict rather than one of its own. Derived from the capture, never written out.
      const expired = page.items.filter((entry) => entry.expired);
      const current = page.items.filter((entry) => !entry.expired && entry.daysRemaining > 30);
      checks.that(
        'the register renders a verdict for every certificate rather than dates alone',
        page.items.length > 0 &&
          (expired.length === 0 || text.includes('EXPIRED')) &&
          (current.length === 0 || text.includes('IN CALIBRATION')),
        `${expired.length} expired and ${current.length} current in the captured page`,
      );
      checks.that(
        'the count of certificates held is the count the service sent',
        text.includes(String(page.items.length)),
        `page carried ${page.items.length}`,
      );

      // The vault is a declared future phase, and the screen says the certificate itself
      // is not here rather than offering something that would fail.
      checks.contains(
        'the screen states that it holds the record and not the certificate document',
        text,
        'The register records the certificate, never its content',
      );
      return checks;
    },
  },
  {
    id: 'calibration-withheld-without-the-role',
    screen: 'CH1-UX-SCR-0012',
    route: '/calibration',
    title: 'An identity without the role is told the register is withheld, not that it is empty',
    claims: reader(['Viewer']),
    routes: baseRoutes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('calibration-withheld-without-the-role');
      await mountScreen('@/app/calibration.tsx');
      const text = renderedText();

      checks.that(
        'the screen did not ask for a register it may not read',
        service.requests.every((request) => !request.path.startsWith('/api/v1/calibrations')),
        service.requests.map((request) => request.path).join(' | '),
      );
      checks.contains('the screen says the register is withheld', text, 'WITHHELD');
      checks.that(
        'and never claims the project has no instruments',
        !text.includes('No calibration certificate is recorded'),
        'the empty-register wording must not appear for a withheld register',
      );
      return checks;
    },
  },

  // ------------------------------------------------------------- CH1-UX-SCR-0015
  {
    id: 'field-scan-evidence',
    screen: 'CH1-UX-SCR-0015',
    route: '/field',
    title: 'What was scanned, what it resolved to, and what the screen refuses to show',
    claims: reader(['Inspector', 'Viewer']),
    routes: () => [
      ...baseRoutes(),
      {
        method: 'GET',
        matches: (p) => p.startsWith('/api/v1/parts/scan-events'),
        answer: async () => captured('ScanEventPage'),
      },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('field-scan-evidence');
      await mountScreen('@/app/field.tsx');
      const text = renderedText();
      const page = captured('ScanEventPage');

      checks.that(
        'the screen asked Control Core for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      for (const entry of page.items) {
        checks.contains(`the scanned identifier ${entry.identifierValue} is shown`, text, entry.identifierValue);
        checks.contains(`the station ${entry.stationId} is shown`, text, entry.stationId);
      }

      // THE PROPERTY THAT MATTERS. The session signature is the proof the device
      // authenticated with. It is absent from the response by construction, and this
      // asserts it is absent from the rendering too — a screen cannot leak what it was
      // never sent, but a screen that started rendering a raw record could.
      const signature = captured('ScanEventEntry').sessionSignatureSha256;
      checks.that(
        'the response carries no session signature at all',
        signature === undefined,
        `captured entry keys: ${Object.keys(captured('ScanEventEntry')).join(', ')}`,
      );
      checks.that(
        'and nothing signature-shaped reaches the screen',
        !/[0-9a-f]{64}/i.test(text),
        'a 64-character hex string appeared in the rendered text',
      );

      // Scanning needs an enrolled device. Offering a control certain to be refused is
      // worse than not offering one, so the screen says why instead.
      checks.contains(
        'the screen states that scanning happens on an enrolled device rather than here',
        text,
        'Scanning happens on an enrolled device, not here',
      );
      checks.contains(
        'and explains that photos and notes have no store behind them',
        text,
        'CH1-COM-IF-0015',
      );
      return checks;
    },
  },

  // ------------------------------------------------------------- CH1-UX-SCR-0020
  {
    id: 'research-workbench',
    screen: 'CH1-UX-SCR-0020',
    route: '/research',
    title: 'Experiments, each stating which side of the production boundary it sits on',
    claims: reader(['RDEngineer', 'Viewer']),
    routes: () => [
      ...baseRoutes(),
      {
        method: 'GET',
        matches: (p) => p === '/api/v1/experiments' || p.startsWith('/api/v1/experiments?'),
        answer: async () => captured('ExperimentPage'),
      },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('research-workbench');
      await mountScreen('@/app/research.tsx');
      const text = renderedText();
      const page = captured('ExperimentPage');

      checks.that(
        'the screen asked Control Core for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      for (const experiment of page.items) {
        checks.contains(`the objective of ${experiment.experimentId} is shown`, text, experiment.objective);
      }

      // The isolation statement is the service's own words, rendered rather than
      // paraphrased, so a change of policy reaches the screen instead of being
      // contradicted by it.
      checks.contains(
        'the isolation statement is the service’s own words',
        text,
        page.isolationStatement,
      );

      // Every row says which side of the boundary it is on. An experiment rendered
      // without that is an experiment that could be read as production work.
      checks.that(
        'every experiment states its production authority',
        page.items.length > 0 && text.includes('NO PRODUCTION AUTHORITY'),
        `${page.items.length} experiment(s) in the captured page`,
      );
      checks.that(
        'and none of them holds it',
        page.items.every((experiment) => experiment.productionAuthority === false),
        JSON.stringify(page.items.map((experiment) => experiment.productionAuthority)),
      );

      checks.contains(
        'the screen states that runs are recorded rather than executed',
        text,
        'Runs are recorded, not executed',
      );
      return checks;
    },
  },

  // ------------------------------------------------------------- CH1-UX-SCR-0021
  {
    id: 'promotion-review',
    screen: 'CH1-UX-SCR-0021',
    route: '/promotion',
    title: 'Change, impact and verification together, and an absent request named as absent',
    claims: reader(['ProjectManager', 'Engineer', 'Viewer']),
    routes: () => [
      ...baseRoutes(),
      {
        method: 'GET',
        matches: (p) => p === '/api/v1/experiments' || p.startsWith('/api/v1/experiments?'),
        answer: async () => captured('ExperimentPage'),
      },
      {
        method: 'GET',
        matches: (p) => /^\/api\/v1\/experiments\/[0-9a-fA-F-]{36}$/.test(p),
        answer: async () => captured('ExperimentDetail'),
      },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('promotion-review');
      await mountScreen('@/app/promotion.tsx');
      const text = renderedText();
      const detail = captured('ExperimentDetail');

      checks.that(
        'the screen asked Control Core for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'reviewing wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      // The captured experiment has no promotion requested. The screen must say THAT,
      // rather than rendering three empty boxes a reviewer could read as a completed
      // review with nothing to object to.
      checks.that(
        'the captured experiment has no promotion requested',
        detail.promotion === null,
        JSON.stringify(detail.promotion),
      );
      checks.contains(
        'and the screen names the absence rather than showing empty fields',
        text,
        'No promotion has been requested for this experiment',
      );
      checks.that(
        'so no promotion field is rendered at all',
        !text.includes('Approved change record'),
        'a promotion field appeared for an experiment with no request',
      );

      // The provenance is what a reviewer would verify against, so the runs are shown.
      checks.that(
        'the recorded runs are shown with their provenance',
        detail.revisions.length === 0 || text.includes(detail.revisions[0].resultSummary),
        `${detail.revisions.length} revision(s) in the capture`,
      );

      // And the platform states that it does not approve.
      checks.contains(
        'the screen states that approving is an act in configuration control',
        text,
        detail.promotionAuthority,
      );
      return checks;
    },
  },
];
