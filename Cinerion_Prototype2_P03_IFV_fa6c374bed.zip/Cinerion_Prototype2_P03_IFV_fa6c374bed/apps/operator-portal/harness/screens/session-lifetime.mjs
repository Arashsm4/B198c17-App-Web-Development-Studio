/**
 * What the portal does when the access token runs out.
 *
 * The defect these scenarios exist to refuse was photographed rather than reported: the
 * header reading `SESSION: AUTHENTICATED` beside a screen reading `HTTP_401`. The realm
 * declares no `accessTokenLifespan`, so Keycloak's five-minute default applied; the
 * portal held no refresh token, had no reaction to a 401, and derived its session state
 * from the mere presence of a token string. After five minutes every read was refused
 * and nothing on the page said so.
 *
 * Three properties are exercised here, and each one is a separate way the previous
 * behaviour was wrong.
 *
 *   1. A token that Control Core refuses provokes a RENEWAL, not a verdict. The session
 *      survives, the screen recovers, and the operator sees nothing.
 *   2. A renewal the provider REFUSES ends the session, and the interface says the
 *      session ended rather than that authentication is required. Those are different
 *      events: one means work in an open form was lost, the other does not.
 *   3. Several refusals arriving together produce ONE renewal. Keycloak rotates the
 *      refresh token on every use, so a second concurrent attempt would present a token
 *      the first had already spent and would end a perfectly healthy session. That is
 *      not a theoretical race: every screen in this portal polls once a second, so an
 *      expired token produces a burst.
 *
 * The renewal is arranged per scenario and the stub refuses a refresh token it never
 * issued, exactly as it refuses an authorisation code it never issued. A stub that
 * renewed anything presented to it would make both the rotation and the single-flight
 * guard unfalsifiable.
 */
import { captured } from '../fixtures.mjs';
import { refusal } from '../environment.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator, harnessAccessToken } from '../identity.mjs';

const FIRST_REFRESH_TOKEN = 'harness-refresh-token-1';
const ROTATED_REFRESH_TOKEN = 'harness-refresh-token-2';

/**
 * An identity whose token is NOWHERE NEAR expiring by its own claim.
 *
 * Load-bearing, and it took an attack to find out. `assignedOperator()`'s default `exp`
 * is a fixed instant in the past, so every scenario using it renews immediately from the
 * SCHEDULED path — which meant the three scenarios below all passed with the 401
 * backstop deleted. A token the portal believes is healthy is the only condition under
 * which a refusal from Control Core is the sole possible trigger.
 */
function unexpiredClaims() {
  return assignedOperator({ exp: Math.floor(Date.now() / 1000) + 3600 });
}

/** An identity already inside the renewal window, for the scheduled path. */
function expiringSoonClaims() {
  return assignedOperator({ exp: Math.floor(Date.now() / 1000) + 10 });
}

/** The claims a renewed token carries: the same identity, a later expiry. */
function renewedClaims() {
  return assignedOperator({ exp: Math.floor(Date.now() / 1000) + 3600 });
}

/**
 * A Control Core that refuses this session's token until it is renewed.
 *
 * The refusal is a real 401 with a real problem body, answered by the same double every
 * other scenario uses, so the portal's own `apiRequest` classifies it and raises its own
 * `CinerionApiError` — nothing about the refusal path is stood in for.
 */
function routesRefusingUntilRenewed(state) {
  const route = (path, answer) => ({
    method: 'GET',
    matches: (p) => p === path,
    answer: async () => {
      if (state.renewed) return answer();
      state.refusals += 1;
      return refusal(401, {
        code: 'AUTH_TOKEN_EXPIRED',
        detail: 'The access token has expired.',
        correlationId: 'harness-correlation',
      });
    },
  });
  return [
    route('/api/v1/projects', () => [captured('ProjectSummary')]),
    route('/api/v1/system/health', () => captured('SystemHealth')),
  ];
}

export const scenarios = [
  {
    id: 'session-renews-before-it-expires',
    screen: 'CH1-UX-SCR-0001',
    route: '/session',
    title: 'The token is renewed before it expires, with nothing refused and nothing shown',
    // Ten seconds from expiry, which is inside the forty-five-second renewal window.
    claims: expiringSoonClaims(),
    renewal: {
      expectRefreshToken: FIRST_REFRESH_TOKEN,
      rotatedRefreshToken: ROTATED_REFRESH_TOKEN,
      accessToken: harnessAccessToken(renewedClaims()),
    },
    routes() {
      // Control Core never refuses anything here. That is the point: the renewal has to
      // come from the token's own expiry, not from a refusal, so the ORDINARY path is
      // established separately from the backstop.
      this.state = { renewed: true, refusals: 0 };
      return routesRefusingUntilRenewed(this.state);
    },
    async run({ mountScreen, renderedText, advance, renewalAttempts }) {
      const checks = new Checks('session-renews-before-it-expires');
      await mountScreen('@/app/session.tsx');
      await advance(1400);

      checks.equals('nothing was ever refused', this.state.refusals, 0);
      checks.equals('and the token was renewed anyway, before expiry', renewalAttempts(), 1);

      const text = renderedText();
      checks.contains('the session is still signed in', text, 'ch1-portal-demo');
      checks.omits('and nothing tells the operator anything happened', text, 'Your session ended');
      checks.contains(
        'the screen reports that renewal is available',
        text,
        'RENEWAL AVAILABLE',
      );
      checks.contains(
        'and states where the renewal credential is kept',
        text,
        'MEMORY ONLY',
      );
      return checks;
    },
  },

  {
    id: 'session-renews-silently-when-the-token-is-refused',
    screen: 'CH1-UX-SCR-0001',
    route: '/session',
    title: 'A refused token is renewed without the operator seeing anything',
    claims: unexpiredClaims(),
    renewal: {
      expectRefreshToken: FIRST_REFRESH_TOKEN,
      rotatedRefreshToken: ROTATED_REFRESH_TOKEN,
      accessToken: harnessAccessToken(renewedClaims()),
    },
    routes() {
      this.state = { renewed: false, refusals: 0 };
      return routesRefusingUntilRenewed(this.state);
    },
    async run({ mountScreen, renderedText, advance, renewalAttempts }) {
      const checks = new Checks('session-renews-silently-when-the-token-is-refused');
      await mountScreen('@/app/session.tsx');

      // The first reads were refused with 401, which is the trigger under test. If they
      // were not, everything below would pass against a session that never expired.
      checks.that(
        'the service refused the token at least once',
        this.state.refusals > 0,
        `observed ${this.state.refusals} refusals`,
      );

      // Renewal is asynchronous; one poll interval is enough for it to complete and for
      // the screen to read again with the new token.
      this.state.renewed = true;
      await advance(1400);

      checks.equals('exactly one renewal was requested', renewalAttempts(), 1);
      const text = renderedText();
      checks.contains('the session is still signed in', text, 'ch1-portal-demo');
      checks.omits('and the operator is not told the session ended', text, 'Your session ended');
      checks.omits('nor asked to sign in again', text, 'SIGN IN AGAIN');
      return checks;
    },
  },

  {
    id: 'session-ends-when-renewal-is-refused',
    screen: 'CH1-UX-SCR-0001',
    route: '/session',
    title: 'A renewal the provider refuses ends the session, and the screen says so',
    claims: unexpiredClaims(),
    renewal: {
      expectRefreshToken: FIRST_REFRESH_TOKEN,
      refuse: 'invalid_grant: Session not active',
    },
    routes() {
      this.state = { renewed: false, refusals: 0 };
      return routesRefusingUntilRenewed(this.state);
    },
    async run({ mountScreen, renderedText, advance, renewalAttempts }) {
      const checks = new Checks('session-ends-when-renewal-is-refused');
      await mountScreen('@/app/session.tsx');
      await advance(1400);

      checks.that('a renewal was attempted', renewalAttempts() >= 1, 'no renewal was attempted');

      const text = renderedText();
      // The distinction that matters: ENDED, not "authentication required". An operator
      // who is told the latter cannot tell whether anything they typed was sent.
      checks.contains('the screen states that the session ended', text, 'Your session ended');
      checks.contains(
        'and that nothing in progress reached Control Core',
        text,
        'NOTHING IN PROGRESS WAS SENT',
      );
      checks.contains(
        'the provider’s own reason is shown rather than paraphrased',
        text,
        'Session not active',
      );
      checks.contains('under a heading that names what it explains', text, 'WHY THE SESSION ENDED');
      checks.contains('and signing in again is offered', text, 'SIGN IN AGAIN');
      checks.omits(
        'the screen no longer claims an authenticated session',
        text,
        'SESSION: AUTHENTICATED',
      );
      return checks;
    },
  },

  {
    id: 'session-renewal-is-single-flight',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    title: 'A burst of refusals across several reads produces one renewal, not one each',
    claims: unexpiredClaims(),
    renewal: {
      expectRefreshToken: FIRST_REFRESH_TOKEN,
      rotatedRefreshToken: ROTATED_REFRESH_TOKEN,
      accessToken: harnessAccessToken(renewedClaims()),
    },
    routes() {
      this.state = { renewed: false, refusals: 0 };
      return [
        ...routesRefusingUntilRenewed(this.state),
        {
          method: 'GET',
          matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
          answer: async () => {
            if (this.state.renewed) return captured('CellState');
            this.state.refusals += 1;
            return refusal(401, {
              code: 'AUTH_TOKEN_EXPIRED',
              detail: 'The access token has expired.',
            });
          },
        },
      ];
    },
    async run({ mountScreen, advance, renewalAttempts }) {
      const checks = new Checks('session-renewal-is-single-flight');
      await mountScreen('@/app/index.tsx');

      // The overview reads projects, health and cell state, so several refusals arrive
      // for one expired token. That is the condition, and it is asserted rather than
      // assumed: with one refusal the check below would hold for the wrong reason.
      checks.that(
        'more than one read was refused, so the refusals really did arrive together',
        this.state.refusals > 1,
        `observed ${this.state.refusals} refusals`,
      );
      checks.equals('but only one renewal was requested', renewalAttempts(), 1);

      // A second burst after the guard's minimum interval must still not multiply:
      // the stub would throw on a spent token and the session would end.
      await advance(1400);
      checks.that(
        'and the session was not ended by a second attempt presenting a spent token',
        renewalAttempts() <= 2,
        `observed ${renewalAttempts()} renewal attempts`,
      );
      return checks;
    },
  },
];
