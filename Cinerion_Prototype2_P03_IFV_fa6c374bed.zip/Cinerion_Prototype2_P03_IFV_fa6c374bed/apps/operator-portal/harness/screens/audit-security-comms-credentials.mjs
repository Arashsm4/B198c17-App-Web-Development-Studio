/**
 * The last four built screens: CH1-UX-SCR-0014, 0013, 0022 and 0002.
 *
 * Each is gated on a statement about what the platform does **not** hold or does **not**
 * prove — the class of claim that is invisible to a typechecker, cheap to delete by
 * accident, and expensive to be wrong about.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const auditPage = () => captured('AuditPage');
const directoryPage = () => captured('DirectoryPage');
const chainVerification = () => captured('ChainVerification');

const projectRoute = {
  method: 'GET',
  matches: (p) => p === '/api/v1/projects',
  answer: async () => projects(),
};

/** Words a credential screen must never render, whatever the service sent. */
const SECRET_WORDS = ['privateKey', 'private_key', 'BEGIN PRIVATE KEY', 'clientSecret'];

export const scenarios = [
  {
    id: 'audit-chain-verification-is-the-servers-answer',
    screen: 'CH1-UX-SCR-0014',
    route: '/audit',
    title: 'The chain explorer renders the events and the verification the service returned',
    claims: assignedOperator({ roles: ['Auditor', 'Viewer'] }),
    routes: () => [
      projectRoute,
      { method: 'GET', matches: (p) => p.startsWith('/api/v1/audit/events'), answer: async () => auditPage() },
      {
        method: 'POST',
        matches: (p) => p === '/api/v1/audit/chain-verifications',
        status: 201,
        answer: async () => chainVerification(),
      },
    ],
    async run({ mountScreen, renderedText, findByText, press, service }) {
      const checks = new Checks('audit-chain-verification-is-the-servers-answer');
      await mountScreen('@/app/audit.tsx');
      const text = renderedText();
      const page = auditPage();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'the captured chain carries an event, so the listing is exercised',
        page.items.length > 0,
        'the captured audit page is empty',
      );

      for (const event of page.items.slice(0, 4)) {
        checks.contains(`event ${event.sequence} names its type`, text, event.eventType);
        checks.contains(`event ${event.sequence} names the actor`, text, event.actorId);
        checks.contains(`event ${event.sequence} carries its decision`, text, event.decision);
      }

      // The chain stores a payload hash rather than the payload, and the screen must not
      // imply otherwise: what is verifiable here is linkage, not content.
      checks.contains(
        'the screen states that a canonical payload hash is what is recorded',
        text,
        'a canonical payload hash and the preceding chain link',
      );
      checks.contains(
        'and that external immutable anchoring is a later controlled gate',
        text,
        'external immutable anchoring remains a later controlled gate',
      );

      // Verification is an answer the server gives, never one the screen computes.
      const writesBefore = service.requests.filter((r) => r.method !== 'GET').length;
      const verify = findByText('VERIFY CHAIN');
      checks.that('verification is offered', verify !== undefined, 'no verify control rendered');
      if (verify !== undefined) {
        await press(verify);
        const after = service.requests.filter((r) => r.method !== 'GET');
        checks.that(
          'verifying asks Control Core rather than computing an answer here',
          after.length === writesBefore + 1 &&
            after[after.length - 1].path === '/api/v1/audit/chain-verifications',
          after.map((r) => `${r.method} ${r.path}`).join(' | '),
        );
        const verified = chainVerification();
        checks.contains(
          'and the count checked is the server’s own',
          renderedText(),
          String(verified.checked),
        );
      }
      return checks;
    },
  },

  {
    id: 'security-directory-shows-no-credential-field',
    screen: 'CH1-UX-SCR-0013',
    route: '/security',
    title: 'The directory shows identifiers, scope and lifecycle, and never a credential',
    claims: assignedOperator({ roles: ['SystemAdministrator', 'Viewer'] }),
    routes: () => [
      projectRoute,
      { method: 'GET', matches: (p) => p === '/api/v1/users', answer: async () => directoryPage() },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('security-directory-shows-no-credential-field');
      await mountScreen('@/app/security.tsx');
      const text = renderedText();
      const page = directoryPage();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'the captured listing carries an identity, so the panel is exercised',
        page.items.length > 0,
        'the captured directory page is empty',
      );

      for (const user of page.items) {
        checks.contains(`identity ${user.username} is listed`, text, user.username);
        checks.contains(`identity ${user.username} states its actor kind`, text, user.actorKind);
        for (const role of user.roles) {
          checks.contains(`identity ${user.username} lists role ${role}`, text, role);
        }
      }

      checks.contains(
        'the disclosure the service attaches to the listing is rendered',
        text,
        page.disclosure,
      );
      for (const secret of SECRET_WORDS) {
        checks.omits(`no credential material is rendered ("${secret}")`, text, secret);
      }
      return checks;
    },
  },

  {
    // The one from the screenshot. The lab identity holds fourteen roles and Keycloak
    // tacks on its own `default-roles-cinerion`, in whatever order the set comes out.
    // Glued into one pill that was ~2000px of text that wouldn't shrink, and the page
    // title lost the fight: one letter per line. Every scenario before this one used two
    // roles, so nothing was ever wide enough to lose.
    id: 'security-intro-survives-every-role-the-lab-identity-holds',
    screen: 'CH1-UX-SCR-0013',
    route: '/security',
    title: 'Fifteen roles in the token and the page title still reads as a title',
    claims: assignedOperator({
      roles: [
        'LocalConfirmer', 'OperationsCoordinator', 'AutomationEngineer', 'DocumentController',
        'SystemAdministrator', 'Viewer', 'default-roles-cinerion', 'ProjectManager', 'Auditor',
        'RDEngineer', 'MaintenanceEngineer', 'Inspector', 'ConfigurationManager', 'Engineer',
        'ProjectOwner',
      ],
    }),
    routes: () => [
      projectRoute,
      { method: 'GET', matches: (p) => p === '/api/v1/users', answer: async () => directoryPage() },
    ],
    async run({ mountScreen, renderedText, findAll, service }) {
      const checks = new Checks('security-intro-survives-every-role-the-lab-identity-holds');
      await mountScreen('@/app/security.tsx');
      const text = renderedText();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      // The words. Each controlled role is its own chip, counted once.
      checks.contains('the roles are counted, and the provider role is not one of them', text, '14 ROLES');
      for (const role of ['LocalConfirmer', 'SystemAdministrator', 'ProjectOwner', 'RDEngineer']) {
        const chips = findAll((own, node) => own === role && node.children.length === 0);
        checks.that(`${role} is a chip of its own`, chips.length >= 1, `no leaf reading exactly "${role}"`);
      }
      checks.contains(
        "Keycloak's own role is disclosed as granting nothing, not hidden and not counted",
        text,
        'Also in the token, granting nothing here: default-roles-cinerion',
      );
      checks.omits(
        'the old glued-together capitals are gone',
        text,
        'LOCALCONFIRMER · OPERATIONSCOORDINATOR',
      );

      // The layout contract. jsdom lays nothing out, so we can't measure the squeeze; what
      // we CAN check is the three style promises that make the squeeze impossible.
      const [title] = findAll((own, node) => own === 'Security administration' && node.children.length === 0);
      const copy = title?.parentElement;
      const row = copy?.parentElement;
      const style = (node) => (node ? globalThis.window.getComputedStyle(node) : undefined);
      checks.equals('the intro row wraps when the aside will not fit', style(row)?.flexWrap, 'wrap');
      checks.equals('the title column has a floor it cannot be squeezed through', style(copy)?.minWidth, '260px');
      const aside = row?.children?.[1];
      checks.equals('the aside is allowed to shrink', style(aside)?.flexShrink, '1');
      return checks;
    },
  },

  {
    id: 'security-directory-unavailable-is-not-empty',
    screen: 'CH1-UX-SCR-0013',
    route: '/security',
    title: 'A directory the platform cannot see reads as unavailable, never as empty',
    // The fail-closed direction, and the one that matters: an empty user list and a
    // directory nobody could reach look identical unless the screen says which it is, and
    // only one of them means nobody holds a role.
    claims: assignedOperator({ roles: ['SystemAdministrator', 'Viewer'] }),
    routes: () => [
      projectRoute,
      {
        method: 'GET',
        matches: (p) => p === '/api/v1/users',
        status: 400,
        answer: async () => ({
          code: 'IDENTITY_PROVIDER_NOT_CONFIGURED',
          detail: 'No identity directory is configured for this deployment.',
          correlationId: 'harness',
        }),
      },
    ],
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('security-directory-unavailable-is-not-empty');
      await mountScreen('@/app/security.tsx');
      const text = renderedText();

      checks.contains(
        'the refusal is reported with the code the service gave',
        text,
        'IDENTITY_PROVIDER_NOT_CONFIGURED',
      );
      checks.contains(
        'the screen names this as the fail-closed direction',
        text,
        'This is the fail-closed direction.',
      );
      checks.contains(
        'and says an unreachable directory is not an empty one',
        text,
        'A directory the platform cannot see is reported as unavailable, never as empty.',
      );
      checks.omits(
        'no identity is listed for a directory that could not be read',
        text,
        directoryPage().items[0]?.username ?? 'no-user',
      );
      checks.contains(
        'and the panel says the listing was not retrieved rather than showing a count',
        text,
        'NOT RETRIEVED',
      );
      return checks;
    },
  },

  {
    id: 'comms-deferred-checks-are-explained',
    screen: 'CH1-UX-SCR-0022',
    route: '/comms',
    title: 'A deferred check is explained rather than shown as a number',
    claims: assignedOperator(),
    routes: () => [
      projectRoute,
      {
        method: 'GET',
        matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
        // The controller declares it cannot read its permissives, which is the case this
        // screen exists to explain.
        answer: async () => ({
          ...cellState(),
          permissivesReported: false,
          deferredCheckCodes: [206, 207],
        }),
      },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('comms-deferred-checks-are-explained');
      await mountScreen('@/app/comms.tsx');
      const text = renderedText();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      checks.contains(
        'the controller is reported as unable to read its permissives, in words',
        text,
        'The controller declared it cannot read them',
      );
      checks.contains(
        'and a deferred check is explained as the controller being honest',
        text,
        'A deferred check is the controller being honest about what it cannot',
      );
      for (const code of [206, 207]) {
        checks.contains(`deferred check ${code} is named`, text, String(code));
      }
      checks.contains(
        'the screen states what it can and cannot show',
        text,
        'What this screen can and cannot show',
      );
      return checks;
    },
  },

  {
    id: 'credentials-never-shows-a-private-key',
    screen: 'CH1-UX-SCR-0002',
    route: '/credentials',
    title: 'Nothing on the authenticators page ever shows a private key',
    claims: assignedOperator(),
    routes: () => [projectRoute],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('credentials-never-shows-a-private-key');
      await mountScreen('@/app/credentials.tsx');
      const text = renderedText();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      checks.contains(
        'the page states outright that it never shows a private key',
        text,
        'Nothing on this page ever shows a private key.',
      );
      checks.contains(
        'and distinguishes a phishing-resistant authenticator from a shared secret',
        text,
        'a one-time password is a shared secret and is never accepted where phishing resistance is required',
      );
      for (const secret of SECRET_WORDS) {
        checks.omits(`no key material is rendered ("${secret}")`, text, secret);
      }

      // jsdom exposes no authenticator, which is the honest state for a workstation
      // without one — and the screen must say so rather than offering a control that
      // cannot work.
      checks.contains(
        'a browser with no authenticator is told so rather than offered a control that cannot work',
        text,
        'This browser exposes no WebAuthn authenticator',
      );
      return checks;
    },
  },
];
