/**
 * CH1-UX-SCR-0009, automatic procedure progress.
 *
 * The property worth gating on this screen is an **absence**, which is unusual and is
 * exactly why it needs a gate: nothing else would notice it going away.
 *
 * No controlled operation reports a controller's position in a sequence. The cell reports
 * its own state and the part reports its evidence, and neither is a step pointer. A
 * highlighted "current step" drawn from either would be a guess rendered as fact on the
 * screen a Local Confirmer uses to decide whether a hold point has been reached — which
 * is the moment CH1-AUT-FDS-0001 exists to govern. So the sequence is shown, the hold
 * points are marked, and the screen says plainly what it cannot tell you.
 *
 * A later change that added a plausible-looking progress indicator would make this screen
 * dangerous while making it look more useful. These checks are what stands in the way.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const genealogy = () => captured('PartGenealogy');
const products = () => [captured('ProductGroup')];

function routes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    { method: 'GET', matches: (p) => p === '/api/v1/products', answer: async () => products() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/parts\/[^/]+\/genealogy$/.test(p),
      answer: async () => genealogy(),
    },
  ];
}

/** Words that would mean the screen had started claiming a position in the sequence. */
const POSITION_CLAIMS = [
  'CURRENT STEP',
  'Current step',
  'IN PROGRESS',
  'Now running',
  'EXECUTING',
  'Step 1 of',
  'NEXT STEP',
];

export const scenarios = [
  {
    id: 'procedure-sequence-and-hold-points',
    screen: 'CH1-UX-SCR-0009',
    route: '/procedure',
    title: 'The controlled sequence is shown with its hold points marked',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('procedure-sequence-and-hold-points');
      await mountScreen('@/app/procedure.tsx');
      const text = renderedText();

      const revision = products()[0].revisions.find(
        (candidate) => candidate.revisionId === genealogy().part.revisionId,
      );
      checks.that(
        'the governing revision resolves from the cell through the part, as the screen depends on',
        revision !== undefined,
        `part revision ${genealogy().part.revisionId} is not in the captured catalogue`,
      );
      if (revision === undefined) return checks;

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'a read-only screen wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      checks.that(
        'the captured route carries a hold point, so the marking is exercised',
        revision.route.some((step) => step.mandatoryInspection),
        'no captured route step requires mandatory inspection',
      );

      for (const step of revision.route) {
        checks.contains(
          `step ${step.stepNumber} is numbered as the record numbers it`,
          text,
          String(step.stepNumber).padStart(3, '0'),
        );
        checks.contains(`step ${step.stepNumber} names its operation`, text, step.operationCode);
        checks.contains(`step ${step.stepNumber} carries its description`, text, step.description);
      }
      checks.contains(
        'a step requiring mandatory inspection is marked as a hold point',
        text,
        'HOLD POINT',
      );
      return checks;
    },
  },

  {
    id: 'procedure-draws-no-step-pointer',
    screen: 'CH1-UX-SCR-0009',
    route: '/procedure',
    title: 'No step is marked as executing, and the screen says why it cannot be',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('procedure-draws-no-step-pointer');
      await mountScreen('@/app/procedure.tsx');
      const text = renderedText();

      for (const claim of POSITION_CLAIMS) {
        checks.omits(
          `the screen never claims a position in the sequence ("${claim}")`,
          text,
          claim,
        );
      }

      checks.contains(
        'and states outright that no operation reports which step is executing',
        text,
        'The P03 catalogue contains no\n          operation that reports a controller'.replace(/\s+/g, ' '),
      );
      checks.contains(
        'that neither the cell state nor the part evidence is a step pointer',
        text,
        'neither is a step pointer, and this screen will\n          not draw one from them'.replace(/\s+/g, ' '),
      );
      checks.contains(
        'and that whether a hold point has been reached lives in the controller',
        text,
        'That state lives in the controller',
      );
      checks.contains(
        'naming the requirement that governs the hold',
        text,
        'CH1-AUT-FDS-0001',
      );
      return checks;
    },
  },
];
