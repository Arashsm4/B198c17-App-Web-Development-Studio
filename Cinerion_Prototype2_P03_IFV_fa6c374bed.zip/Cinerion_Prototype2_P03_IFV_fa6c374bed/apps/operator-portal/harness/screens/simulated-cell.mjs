/**
 * The control that asks a simulated cell to confirm, and everything it must not claim.
 *
 * This is the control that sits closest to the authority boundary in the whole portal, so
 * what is asserted here is mostly what it does NOT do.
 *
 *   1. It is offered only while a command is still waiting for a controller, and only when
 *      a simulator is configured. A build with no simulator says so plainly instead of
 *      offering a control that would fail — an operator meeting a failure cannot tell a
 *      cell that is unreachable from one that was never configured.
 *   2. It states, before it is pressed, that this is NOT a physical confirmation: no person
 *      presents a credential, no button is pressed, the edge and the presence are both
 *      marked, and nothing is energised.
 *   3. Pressing it sends nothing to Control Core. The portal has no route to
 *      /credential-proofs or /local-commits — `scripts/check-repository-policy.mjs` refuses
 *      either string anywhere in this tree — and this scenario checks the OTHER half of
 *      that: that the portal does not reach Control Core for this at all. What it asks is
 *      a separate service with its own device certificate.
 *   4. The stand-in's own notice is rendered verbatim on the receipt. That sentence is what
 *      stops a screenshot of a successful confirmation being quoted as evidence that
 *      something ran.
 *
 * The simulator is answered by the harness's own fetch double rather than by the real
 * service, for the reason every scenario here answers from captured responses: what is
 * under test is the screen.
 */
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const COMMAND_ID = '3f1c0a52-9d61-4b77-9f1e-2a0b7c4d55e1';
const SIMULATOR_URL = 'http://cell-simulator.harness.invalid';

/** A prepared command in the state a controller is expected to answer. */
function preparedCommand(state = 'AwaitingCredential') {
  return {
    commandId: COMMAND_ID,
    confirmationId: '8a2e11b4-5c3d-4e6f-9a01-77bb22cc33dd',
    correlationId: 'd41d8cd9-8f00-4204-a980-0998ecf8427e',
    requesterId: 'USR-ENG-01',
    state,
    intent: { commandType: 'RUN_COATING_CYCLE', expiresAt: '2026-02-02T03:40:00Z' },
    preparedAt: '2026-02-02T03:38:30Z',
    credentialProof: null,
    localCommitId: null,
    terminalReason: null,
    version: 1,
    physicalConfirmationRequired: true,
    remoteStartAvailable: false,
    acknowledgements: [],
    acknowledgementIsNotExecution: true,
    auditLinks: [],
  };
}

/**
 * Answers the stand-in controller, and records what it was asked.
 *
 * Installed over the harness's Control Core double rather than through it, because the
 * simulator is a DIFFERENT service on a different origin and the double refuses anything
 * not addressed to Control Core - which is the property scenario 3 rests on.
 */
function installSimulator(answer) {
  const asked = [];
  const controlCore = globalThis.fetch;
  globalThis.fetch = async (input, init = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    if (url.startsWith(SIMULATOR_URL)) {
      asked.push({ url, body: init.body === undefined ? undefined : JSON.parse(init.body) });
      const payload = JSON.stringify(answer);
      return {
        ok: true,
        status: 200,
        statusText: 'OK',
        json: async () => JSON.parse(payload),
        text: async () => payload,
      };
    }
    return controlCore(input, init);
  };
  return asked;
}

const NOTICE =
  'Confirmed by a SIMULATED cell controller. The button edge was marked SimulatorInjection ' +
  'and the presence was marked SimulatedPresence; the audit record says so. No person was ' +
  'present, no credential was read, and no equipment moved.';

export const scenarios = [
  {
    id: 'simulated-cell-states-it-is-not-physical-before-it-is-pressed',
    screen: 'CH1-UX-SCR-0008',
    route: '/command',
    title: 'The control says it is not a physical confirmation before anybody presses it',
    claims: assignedOperator({ roles: ['Engineer', 'Viewer'] }),
    environment: { EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL: SIMULATOR_URL },
    routes: () => [],
    async run({ mountElement, createElement, importPortal, renderedText }) {
      const checks = new Checks('simulated-cell-states-it-is-not-physical-before-it-is-pressed');
      const { AskSimulatedCell } = await importPortal('@/components/simulated-cell.tsx');
      const mounted = await mountElement(
        createElement(AskSimulatedCell, {
          commandId: COMMAND_ID,
          state: 'AwaitingCredential',
          onConfirmed: () => undefined,
        }),
      );
      const text = renderedText(mounted.container);

      checks.contains('the control is offered', text, 'ASK THE SIMULATED CELL TO CONFIRM');
      checks.contains(
        'and states that it is not a physical confirmation',
        text,
        'THIS IS NOT A PHYSICAL CONFIRMATION',
      );
      checks.contains('naming what does not happen', text, 'No person presents a credential');
      checks.contains('and that both halves are marked', text, 'marked SimulatorInjection');
      checks.contains('and that nothing is energised', text, 'Nothing is energised');
      checks.contains(
        'the portal says it has no route to the controller operations itself',
        text,
        'has no route to either controller operation itself',
      );
      return checks;
    },
  },

  {
    id: 'simulated-cell-absent-is-said-rather-than-shown-as-a-failure',
    screen: 'CH1-UX-SCR-0008',
    route: '/command',
    title: 'A build with no simulator says so instead of offering a control that fails',
    claims: assignedOperator({ roles: ['Engineer', 'Viewer'] }),
    // No simulator URL. This is what every build that is not a laboratory looks like.
    routes: () => [],
    async run({ mountElement, createElement, importPortal, renderedText }) {
      const checks = new Checks('simulated-cell-absent-is-said-rather-than-shown-as-a-failure');
      const { AskSimulatedCell } = await importPortal('@/components/simulated-cell.tsx');
      const mounted = await mountElement(
        createElement(AskSimulatedCell, {
          commandId: COMMAND_ID,
          state: 'AwaitingCredential',
          onConfirmed: () => undefined,
        }),
      );
      const text = renderedText(mounted.container);

      checks.contains('the absence is stated', text, 'NO SIMULATED CELL IS CONFIGURED');
      checks.omits('and no control is offered', text, 'ASK THE SIMULATED CELL TO CONFIRM');
      checks.contains(
        'the screen still says what a prepared command is waiting for',
        text,
        'present a credential proof and observe a button edge',
      );
      checks.contains(
        'and that the portal cannot do either',
        text,
        'the portal cannot do either and is not able to',
      );
      return checks;
    },
  },

  {
    id: 'simulated-cell-asks-the-simulator-and-never-control-core',
    screen: 'CH1-UX-SCR-0008',
    route: '/command',
    title: 'Pressing it reaches the stand-in service and sends nothing to Control Core',
    claims: assignedOperator({ roles: ['Engineer', 'Viewer'] }),
    environment: { EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL: SIMULATOR_URL },
    routes: () => [],
    async run({ mountElement, createElement, importPortal, renderedText, findByText, press, service }) {
      const checks = new Checks('simulated-cell-asks-the-simulator-and-never-control-core');
      const asked = installSimulator({
        confirmed: true,
        state: 'Committed',
        notice: NOTICE,
        steps: [
          { step: 'read', state: 'AwaitingCredential' },
          { step: 'credentialProof', authenticatorClass: 'SimulatedPresence' },
          { step: 'localCommit', state: 'Committed' },
        ],
      });

      const { AskSimulatedCell } = await importPortal('@/components/simulated-cell.tsx');
      let confirmedCalls = 0;
      const mounted = await mountElement(
        createElement(AskSimulatedCell, {
          commandId: COMMAND_ID,
          state: 'AwaitingCredential',
          onConfirmed: () => {
            confirmedCalls += 1;
          },
        }),
      );

      await press(findByText('ASK THE SIMULATED CELL TO CONFIRM', mounted.container));

      checks.equals('the stand-in service was asked exactly once', asked.length, 1);
      checks.that(
        'and was asked to confirm this command',
        asked[0]?.body?.commandId === COMMAND_ID,
        JSON.stringify(asked[0]?.body),
      );
      checks.that(
        'the request went to the simulator, not to Control Core',
        asked[0]?.url.startsWith(SIMULATOR_URL) === true,
        asked[0]?.url,
      );
      // The other half of the repository policy gate's rule, checked at runtime: the
      // portal issued NOTHING to Control Core for this act.
      checks.equals('Control Core received no request at all', service.requests.length, 0);
      checks.equals('and the screen was told the command had moved', confirmedCalls, 1);

      const text = renderedText(mounted.container);
      checks.contains('the receipt reports the new state', text, 'The command is now Committed');
      checks.contains('and names the marked presence', text, 'SimulatedPresence');
      checks.contains(
        'the stand-in’s own notice is rendered verbatim, not paraphrased',
        text,
        NOTICE,
      );
      return checks;
    },
  },

  {
    id: 'simulated-cell-is-not-offered-once-the-command-is-past-it',
    screen: 'CH1-UX-SCR-0008',
    route: '/command',
    title: 'A committed or cancelled command is not offered a second confirmation',
    claims: assignedOperator({ roles: ['Engineer', 'Viewer'] }),
    environment: { EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL: SIMULATOR_URL },
    routes: () => [],
    async run({ mountElement, createElement, importPortal, renderedText }) {
      const checks = new Checks('simulated-cell-is-not-offered-once-the-command-is-past-it');
      const { AskSimulatedCell } = await importPortal('@/components/simulated-cell.tsx');

      for (const state of ['Committed', 'Executing', 'Completed', 'Cancelled', 'FaultLatched']) {
        const mounted = await mountElement(
          createElement(AskSimulatedCell, {
            commandId: COMMAND_ID,
            state,
            onConfirmed: () => undefined,
          }),
        );
        checks.omits(
          `a ${state} command is offered no confirmation`,
          renderedText(mounted.container),
          'ASK THE SIMULATED CELL TO CONFIRM',
        );
        await mounted.unmount();
      }

      // And the one state where it IS offered, so the check above is not passing because
      // the control never renders at all.
      const waiting = await mountElement(
        createElement(AskSimulatedCell, {
          commandId: COMMAND_ID,
          state: 'AwaitingButton',
          onConfirmed: () => undefined,
        }),
      );
      checks.contains(
        'a command awaiting a button edge IS offered one',
        renderedText(waiting.container),
        'ASK THE SIMULATED CELL TO CONFIRM',
      );
      return checks;
    },
  },
];

export { preparedCommand };
