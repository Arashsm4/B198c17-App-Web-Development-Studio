/**
 * CH1-UX-SCR-0001, session and authentication.
 *
 * The property gated here is a refusal to overstate what a token proves. An OIDC session
 * reaches `Mfa` at most and the realm emits no `amr` or `acr` claim, so *which*
 * authenticators were actually presented is not known to this portal. A padlock rendered
 * anyway would be a permanent visual assertion of strength that nothing attested — the
 * exact thing `npm run policy` refuses for a stored `ch1_auth_strength`, one level up.
 *
 * The second is that clearing a token and ending a session are different acts. `signOut`
 * used to drop the in-memory token and nothing else, leaving the session live at
 * FortressGate so a fresh sign-in resumed it without anybody re-authenticating — which on
 * a shared workstation is the whole difference between leaving and being logged out. Both
 * controls are now offered, labelled for what each does, and the difference is stated.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const health = () => captured('SystemHealth');

function routes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    { method: 'GET', matches: (p) => p === '/api/v1/system/health', answer: async () => health() },
  ];
}

/** Claims about authenticator strength that nothing in the token attests. */
const UNATTESTED_STRENGTH = [
  'Hardware-backed',
  'Phishing-resistant session',
  'Passkey verified',
  'MFA verified',
];

export const scenarios = [
  {
    id: 'session-states-what-the-token-cannot-prove',
    screen: 'CH1-UX-SCR-0001',
    route: '/session',
    title: 'Which authenticators were used is reported as not known, never as a padlock',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('session-states-what-the-token-cannot-prove');
      await mountScreen('@/app/session.tsx');
      const text = renderedText();
      const claims = assignedOperator();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      // What the token does carry is shown, decoded for display and scoping only.
      checks.contains('the subject is shown', text, claims.sub);
      checks.contains('the project scope is shown', text, claims.ch1_project);
      for (const role of claims.roles) {
        checks.contains(`role ${role} is listed`, text, role);
      }

      // What it does not carry is stated rather than filled in.
      checks.contains(
        'the screen asks which authenticators were actually used',
        text,
        'Which authenticators were actually used',
      );
      checks.contains(
        'and answers that the realm emits no amr or acr claim',
        text,
        'The realm emits no',
      );
      checks.contains(
        'so a padlock it cannot justify is not shown',
        text,
        'rather than showing a padlock it cannot justify',
      );
      for (const claim of UNATTESTED_STRENGTH) {
        checks.omits(
          `the screen asserts no authenticator strength it cannot attest ("${claim}")`,
          text,
          claim,
        );
      }
      return checks;
    },
  },

  {
    id: 'session-two-controls-are-not-the-same',
    screen: 'CH1-UX-SCR-0001',
    route: '/session',
    title: 'Clearing the token and ending the session are offered as different acts',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, findByText }) {
      const checks = new Checks('session-two-controls-are-not-the-same');
      await mountScreen('@/app/session.tsx');
      const text = renderedText();

      checks.that(
        'ending the session at the provider is offered',
        findByText('END SESSION AT FORTRESSGATE') !== undefined,
        'no control ends the session at the identity provider',
      );
      checks.that(
        'and clearing the tab’s token is offered separately',
        findByText('CLEAR TOKEN IN THIS TAB ONLY') !== undefined,
        'no control clears the token in this tab',
      );
      checks.contains(
        'the screen states that the two are not the same',
        text,
        'THE TWO CONTROLS ARE NOT THE SAME',
      );
      checks.contains(
        'and says what clearing the token leaves behind',
        text,
        'The session at\n          FortressGate stays live'.replace(/\s+/g, ' '),
      );
      checks.contains(
        'naming the consequence on a shared workstation',
        text,
        'without anybody re-authenticating',
      );
      return checks;
    },
  },

  {
    id: 'session-ending-requires-confirmation',
    screen: 'CH1-UX-SCR-0001',
    route: '/session',
    title: 'Ending a session everywhere is confirmed before anything is sent',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, findByText, press, service }) {
      const checks = new Checks('session-ending-requires-confirmation');
      await mountScreen('@/app/session.tsx');

      const writes = () =>
        service.requests.filter((request) => request.method !== 'GET');
      checks.equals('nothing has been written yet', writes().length, 0);

      const end = findByText('END SESSION AT FORTRESSGATE');
      checks.that('the control is offered', end !== undefined, 'no end-session control');
      if (end === undefined) return checks;

      await press(end);
      checks.equals(
        'pressing it sends nothing — it asks for confirmation first',
        writes().length,
        0,
      );
      const confirming = renderedText();
      checks.contains(
        'and the confirmation names what it will do',
        confirming,
        'CONFIRM — END EVERYWHERE',
      );
      checks.that(
        'with a way back',
        findByText('CANCEL') !== undefined,
        'no cancel control was offered on the confirmation',
      );
      return checks;
    },
  },
];
