/**
 * CH1-UX-SCR-0010, CH1-UX-SCR-0003 and CH1-UX-SCR-0004.
 *
 * Three screens whose gated property is the same shape: each refuses to let an absence
 * read as a pass.
 *
 * The inspection dashboard must not present an empty acceptance record as an accepted
 * part — nothing measured is not the same as nothing wrong — and must keep a superseded
 * failure visible, which is CH1-QMS-FR-0004 again on a second screen.
 *
 * The portfolio must not draw the controlled development gates G0–G9. They are a
 * programme artefact and the catalogue has no operation that reports one, so a row saying
 * G4 was satisfied would be a claim with nothing behind it — on the screen a reader would
 * use to decide whether the project may proceed.
 *
 * The topology view must not describe a device register it cannot read. It calls the
 * endpoint and reports the server's answer, so the day AssetVault is implemented the panel
 * starts working without being edited.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const genealogy = () => captured('PartGenealogy');
const health = () => captured('SystemHealth');

const gatedDevice = {
  method: 'GET',
  matches: (p) => /^\/api\/v1\/devices\/[^/]+$/.test(p),
  status: 501,
  answer: async () => ({
    code: 'CAPABILITY_NOT_ENABLED',
    detail: 'AssetVault is a controlled capability that is not enabled in this build.',
    correlationId: 'harness',
  }),
};

const cellRoute = {
  method: 'GET',
  matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
  answer: async () => cellState(),
};

const projectRoute = {
  method: 'GET',
  matches: (p) => p === '/api/v1/projects',
  answer: async () => projects(),
};

/** Words that would mean an empty or incomplete record had been presented as an outcome. */
const FALSE_ACCEPTANCE = ['ACCEPTED', 'ALL CLEAR', 'NO ISSUES', 'READY FOR RELEASE'];

export const scenarios = [
  {
    id: 'quality-empty-record-is-not-a-pass',
    screen: 'CH1-UX-SCR-0010',
    route: '/quality',
    title: 'An empty acceptance record is not a pass, and a superseded failure stays visible',
    claims: assignedOperator(),
    routes: () => [
      projectRoute,
      cellRoute,
      {
        method: 'GET',
        matches: (p) => /^\/api\/v1\/parts\/[^/]+\/genealogy$/.test(p),
        answer: async () => genealogy(),
      },
      {
        // The quality screen reads the calibration register so a measurement can name the
        // record its instrument was covered by. Declared here because the screen genuinely
        // asks for it; an undeclared request is what this harness exists to catch.
        method: 'GET',
        matches: (p) => p.startsWith('/api/v1/calibrations'),
        answer: async () => captured('CalibrationPage'),
      },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('quality-empty-record-is-not-a-pass');
      await mountScreen('@/app/quality.tsx');
      const text = renderedText();
      const measurements = genealogy().part.measurements;

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'an inspection dashboard wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      checks.contains(
        'the count of recorded measurements is the record’s own',
        text,
        `${measurements.length} RECORDED`,
      );
      checks.contains(
        'the screen states that a failed mandatory result holds the part',
        text,
        'A failed mandatory result holds the physical part until controlled disposition and a passing retest.',
      );

      for (const measurement of measurements) {
        checks.contains(
          `measurement ${measurement.measurementId} is listed with its characteristic`,
          text,
          measurement.characteristic,
        );
        checks.contains(
          `measurement ${measurement.measurementId} writes its result out`,
          text,
          measurement.result === 'Pass' ? 'PASS' : 'FAIL',
        );
        if (measurement.mandatory) {
          checks.contains(
            `measurement ${measurement.measurementId} is marked mandatory`,
            text,
            'MANDATORY',
          );
        }
      }

      // The same requirement as on the genealogy screen, on a second screen: a failure
      // that has been retested is superseded, not removed.
      const superseded = measurements.filter((candidate) =>
        measurements.some((other) => other.supersedesMeasurementId === candidate.measurementId),
      );
      checks.that(
        'the captured part carries a superseded measurement, so the branch is exercised',
        superseded.length > 0,
        'no captured measurement is superseded',
      );
      if (superseded.length > 0) {
        checks.contains(
          'a superseded result is marked as superseded rather than dropped',
          text,
          'Superseded by a later retest',
        );
        for (const failure of superseded) {
          checks.contains(
            `the superseded reading of ${failure.value} is still on the page`,
            text,
            String(failure.value),
          );
        }
      }
      return checks;
    },
  },

  {
    id: 'quality-absence-of-an-ncr-is-not-acceptance',
    screen: 'CH1-UX-SCR-0011',
    route: '/quality',
    title: 'No open nonconformance is not the same as an accepted part',
    // The same route declares CH1-UX-SCR-0010 and CH1-UX-SCR-0011, and the disposition
    // half needs its own scenario: "nothing open" is the reading most likely to be taken
    // for "nothing wrong", and the release chain is what stands between them.
    claims: assignedOperator(),
    routes: () => [
      projectRoute,
      cellRoute,
      {
        method: 'GET',
        matches: (p) => /^\/api\/v1\/parts\/[^/]+\/genealogy$/.test(p),
        answer: async () => genealogy(),
      },
      {
        // The quality screen reads the calibration register so a measurement can name the
        // record its instrument was covered by. Declared here because the screen genuinely
        // asks for it; an undeclared request is what this harness exists to catch.
        method: 'GET',
        matches: (p) => p.startsWith('/api/v1/calibrations'),
        answer: async () => captured('CalibrationPage'),
      },
    ],
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('quality-absence-of-an-ncr-is-not-acceptance');
      await mountScreen('@/app/quality.tsx');
      const text = renderedText();
      const part = genealogy().part;

      checks.contains(
        'the open nonconformance count is the record’s own',
        text,
        part.openNcrIds.length > 0 ? `${part.openNcrIds.length} open` : 'No open NCR',
      );
      if (part.openNcrIds.length === 0) {
        checks.contains(
          'and an absent NCR is explicitly not acceptance',
          text,
          'Absence of an NCR is not acceptance.',
        );
      }
      for (const ncr of part.openNcrIds) {
        checks.contains(`open nonconformance ${ncr} is named`, text, ncr);
      }

      // These two checks used to pin the ABSENCE of the disposition workflow, quoting the
      // placeholder that said it was not yet retrieved. The workflow exists now, so they
      // pin its presence instead — and pinning presence is the weaker claim, so the third
      // check below is what carries the weight: the screen must still say that raising a
      // non-conformance is not the same as dispositioning one, and must not offer a
      // release the server would refuse.
      // This scenario's part has NO open non-conformance, so there is nothing to
      // disposition and no disposition control is offered. That is the property worth
      // pinning: a control that appeared with nothing behind it would invite an operator
      // to act on a record that does not exist.
      checks.that(
        'no disposition is offered, because no non-conformance is open',
        !text.includes('DISPOSITION'),
      );
      checks.contains('but one can be raised against the part', text, 'RAISE A NON-CONFORMANCE');
      // The independence requirement, from whichever side the record is on. An unreleased
      // part is told what release will take; a released one shows who granted it, and the
      // scenario asserts that was not the person who did the work.
      if (part.release === null) {
        checks.contains(
          'an unreleased part is told the operator cannot release their own work',
          text,
          'The person who performed the operation cannot release their own work.',
        );
      } else {
        checks.contains('a released part names the inspector who granted it', text, part.release.inspectorId);
        checks.that(
          'and that inspector is not the operator who performed the work',
          part.release.inspectorId !== part.operatorId,
          `released by ${part.release.inspectorId}, made by ${part.operatorId}`,
        );
        checks.contains('the release gate reads as released', text, 'Released');
      }
      return checks;
    },
  },

  {
    id: 'portfolio-does-not-draw-the-gates',
    screen: 'CH1-UX-SCR-0003',
    route: '/portfolio',
    title: 'The controlled gates are named as absent rather than drawn as pending',
    claims: assignedOperator(),
    routes: () => [
      projectRoute,
      { method: 'GET', matches: (p) => p === '/api/v1/system/health', answer: async () => health() },
    ],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('portfolio-does-not-draw-the-gates');
      await mountScreen('@/app/portfolio.tsx');
      const text = renderedText();
      const [project] = projects();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      checks.contains('the stored project record is shown', text, project.projectCode);
      checks.contains('with the baseline it is governed by', text, project.baseline);

      checks.contains(
        'the gates are stated as deliberately not shown',
        text,
        'GATES G0–G9 ARE NOT SHOWN, AND THAT IS DELIBERATE',
      );
      checks.contains(
        'and the reason is the catalogue, not an oversight',
        text,
        'The P03 API catalogue contains no operation that reports the state of one',
      );
      checks.contains(
        'with what a drawn gate would amount to',
        text,
        'A row saying G4 was satisfied would be a claim with\n          nothing behind it'.replace(/\s+/g, ' '),
      );

      // A gate row would look like this. None of them may appear.
      for (const gate of ['G0', 'G1', 'G2', 'G3', 'G5', 'G6', 'G7', 'G8', 'G9']) {
        checks.omits(`no ${gate} row is drawn`, text, `${gate} SATISFIED`);
        checks.omits(`and no ${gate} pending row either`, text, `${gate} PENDING`);
      }

      checks.contains(
        'the runtime profile shown is the service’s own',
        text,
        health().runtimeProfile.toUpperCase(),
      );
      return checks;
    },
  },

  {
    id: 'assets-device-register-reports-the-server-answer',
    screen: 'CH1-UX-SCR-0004',
    route: '/assets',
    title: 'The device register reports what the server said rather than describing itself',
    claims: assignedOperator(),
    routes: () => [projectRoute, cellRoute, gatedDevice],
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('assets-device-register-reports-the-server-answer');
      await mountScreen('@/app/assets.tsx');
      const text = renderedText();
      const cell = cellState();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'the register was actually called rather than described in prose',
        service.pathsRequested().some((path) => path.startsWith('/api/v1/devices/')),
        service.pathsRequested().join(' | '),
      );

      // The controller identity is real: it comes from the cell state the controller
      // published, not from a register that is not enabled.
      checks.contains('the controller the cell reports is named', text, cell.controllerId);
      checks.contains('with the asset it belongs to', text, cell.assetId);
      checks.contains(
        'and the configuration revision it is running',
        text,
        cell.configurationRevision,
      );
      checks.contains(
        'the controller block says the identity came from the cell',
        text,
        'CONTROLLER REPORTED BY THE CELL',
      );

      checks.contains(
        'and the register itself is reported as unavailable, from the server’s refusal',
        text,
        'REGISTER UNAVAILABLE',
      );
      for (const claim of FALSE_ACCEPTANCE) {
        checks.omits(`the topology asserts no readiness of its own ("${claim}")`, text, claim);
      }
      return checks;
    },
  },
];
