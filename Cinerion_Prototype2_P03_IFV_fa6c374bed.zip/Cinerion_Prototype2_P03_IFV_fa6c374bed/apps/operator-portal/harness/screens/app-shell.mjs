/**
 * The workspace rail, and whether every destination in it can actually be reached.
 *
 * This is the first scenario in this harness that renders the DESKTOP shell. Until the
 * viewport was declared (see `declareViewport` in `environment.mjs`) jsdom answered 0
 * for the document element's client box, `react-native-web`'s `Dimensions` therefore
 * reported a zero-width window, and `AppShell` took its `compact` branch every time. So
 * every scenario in this gate had only ever rendered the mobile header: the rail an
 * operator at a workstation actually uses had never been rendered by anything in CI.
 *
 * What that hid is the defect these scenarios exist to refuse. The rail was one
 * unbounded column of twenty-two destinations, a workspace block, a safety card and an
 * identity block, inside a row whose cross-size is the viewport. React Native's default
 * `overflow: hidden` then simply cut the column off at the bottom edge, with no
 * scrollbar and no way to reach what was below it - "Calibration register" was the first
 * casualty, and on a short window it took several more with it.
 *
 * The checks are structural rather than visual, because jsdom performs no layout and a
 * harness that claimed to measure a clipped pixel would be inventing a measurement. What
 * it can establish exactly is the mechanism: which region scrolls, which is pinned, and
 * whether the scrolling region is permitted to be smaller than its content. A flex child
 * that cannot shrink below its content is precisely the bug, and a rail whose height is
 * its content's rather than the window's is the other half of it, so both computed
 * values are asserted by name.
 *
 * The pinning is a deliberate decision and is checked as one. The AUTHORITY BOUNDARY
 * card states that the portal prepares intent and cannot emulate a credential, a
 * physical edge or the safety chain. A safety statement that scrolls out of reach is not
 * a statement, so it is outside the scrolling region, and so is the block naming which
 * project this window is acting on.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

function routes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => [captured('ProjectSummary')] },
    { method: 'GET', matches: (p) => p === '/api/v1/system/health', answer: async () => captured('SystemHealth') },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => captured('CellState'),
    },
  ];
}

/**
 * Every destination the rail offers, as an operator reads them.
 *
 * Written out rather than imported from `app-shell.tsx`, for the reason the harness's
 * `expectedInstant` is a second implementation: a list read from the code under test
 * agrees with it however that code behaves, and the property here is that the rail
 * renders all of them - including the ones past the fold.
 */
const DESTINATIONS = [
  'Operations',
  'Project portfolio',
  'Control room',
  'CommandGuard',
  'Procedure progress',
  'Work orders',
  'Part genealogy',
  'Quality & inspection',
  'Calibration register',
  'Field & scan evidence',
  'Assets & devices',
  'Devices',
  'Communication health',
  'Resources',
  'Collaboration',
  'Your authenticators',
  'Security administration',
  'Session',
  'Engineering',
  'R&D workbench',
  'Promotion review',
  'Audit chain',
];

/** The nearest ancestor that scrolls vertically, or undefined if nothing above it does. */
function verticalScrollAncestor(node) {
  let current = node?.parentElement;
  while (current !== null && current !== undefined) {
    const overflowY = globalThis.window.getComputedStyle(current).overflowY;
    if (overflowY === 'auto' || overflowY === 'scroll') return current;
    current = current.parentElement;
  }
  return undefined;
}

function horizontalScrollAncestor(node) {
  let current = node?.parentElement;
  while (current !== null && current !== undefined) {
    const overflowX = globalThis.window.getComputedStyle(current).overflowX;
    if (overflowX === 'auto' || overflowX === 'scroll') return current;
    current = current.parentElement;
  }
  return undefined;
}

/** The label element for one destination, chosen deepest-first so a leaf wins. */
function destinationNode(findAll, label) {
  return findAll((text) => text.trim() === label)[0];
}

async function mountShell({ mountElement, createElement, importPortal }, active = 'operations') {
  const { AppShell } = await importPortal('@/components/app-shell.tsx');
  const { SessionProvider } = await importPortal('@/auth/session');
  return mountElement(
    createElement(
      SessionProvider,
      null,
      createElement(AppShell, { active }, createElement('span', null, 'SCREEN BODY')),
    ),
  );
}

function assertEveryDestinationRenders(checks, text) {
  for (const label of DESTINATIONS) {
    checks.contains(`"${label}" is offered in the rail`, text, label);
  }
}

export const scenarios = [
  {
    id: 'app-shell-rail-scrolls-on-a-tall-window',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    viewport: { width: 1440, height: 900 },
    title: 'On a workstation window the rail lists every destination and the list scrolls',
    claims: assignedOperator(),
    routes,
    async run(context) {
      const checks = new Checks('app-shell-rail-scrolls-on-a-tall-window');
      const { renderedText, findAll } = context;
      await mountShell(context);
      const text = renderedText();

      // The desktop rail, not the compact header. Asserted first, because every check
      // below would be vacuous against the other branch.
      checks.contains('the desktop rail is the branch rendered', text, 'ACTIVE WORKSPACE');
      assertEveryDestinationRenders(checks, text);

      const first = destinationNode(findAll, DESTINATIONS[0]);
      const last = destinationNode(findAll, DESTINATIONS[DESTINATIONS.length - 1]);
      const clipped = destinationNode(findAll, 'Calibration register');
      checks.that('the first destination is in the document', first !== undefined);
      checks.that('the last destination is in the document', last !== undefined);

      const listRegion = verticalScrollAncestor(last);
      checks.that(
        'the navigation list sits inside a region that scrolls vertically',
        listRegion !== undefined,
        'no ancestor of the last destination has overflow-y auto or scroll',
      );
      checks.that(
        'the first and last destinations are in the SAME scrolling region',
        listRegion !== undefined && verticalScrollAncestor(first) === listRegion,
        'the rail is split across more than one scrolling region',
      );
      checks.that(
        'the destination that used to be cut off is in that region too',
        listRegion !== undefined && verticalScrollAncestor(clipped) === listRegion,
        '"Calibration register" is not inside the scrolling list',
      );

      if (listRegion !== undefined) {
        // The mechanism, in two parts, and both are asserted because both were absent.
        // A flex child that may not shrink takes its content's height, grows the rail
        // past the viewport and is clipped by the parent - which is the defect, not a
        // styling preference. And the rail has to be bounded by the window before any
        // fraction of it means anything.
        //
        // `min-height: 0` is deliberately NOT asserted here: `react-native-web` sets it
        // on the base View class, so every element in this tree reports it and a check
        // on it would pass whatever this code did. It stays in the stylesheet as an
        // explicit statement of intent; it is simply not evidence.
        checks.equals(
          'the scrolling region is allowed to shrink',
          globalThis.window.getComputedStyle(listRegion).flexShrink,
          '1',
        );
        const rail = listRegion.parentElement;
        checks.equals(
          'and the rail it sits in is bounded by the window rather than by its content',
          globalThis.window.getComputedStyle(rail).height,
          '100%',
        );
      }
      return checks;
    },
  },

  {
    id: 'app-shell-safety-statement-is-pinned',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    viewport: { width: 1440, height: 900 },
    title: 'The authority boundary and the active workspace are outside the scrolling list',
    claims: assignedOperator(),
    routes,
    async run(context) {
      const checks = new Checks('app-shell-safety-statement-is-pinned');
      const { renderedText, findAll } = context;
      await mountShell(context);
      const text = renderedText();

      const last = destinationNode(findAll, DESTINATIONS[DESTINATIONS.length - 1]);
      const listRegion = verticalScrollAncestor(last);
      checks.that('the navigation list scrolls', listRegion !== undefined);

      const boundary = findAll((value) => value.trim() === 'AUTHORITY BOUNDARY')[0];
      checks.that('the authority boundary card is rendered', boundary !== undefined);
      checks.contains(
        'and states what the portal cannot do',
        text,
        'It cannot emulate the credential, physical edge, or safety chain.',
      );
      checks.that(
        'the safety statement cannot be scrolled out of the rail',
        boundary !== undefined && verticalScrollAncestor(boundary) !== listRegion,
        'the authority boundary card is inside the scrolling navigation list',
      );

      const workspace = findAll((value) => value.trim() === 'ACTIVE WORKSPACE')[0];
      checks.that('the active workspace block is rendered', workspace !== undefined);
      checks.that(
        'and naming which project this window acts on is pinned too',
        workspace !== undefined && verticalScrollAncestor(workspace) !== listRegion,
        'the active workspace block is inside the scrolling navigation list',
      );
      return checks;
    },
  },

  {
    id: 'app-shell-rail-on-a-short-window',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    // The window height at which the defect actually bit. Twenty-two destinations at
    // 56 px each need well over a thousand pixels; this is half of that.
    viewport: { width: 1440, height: 560 },
    title: 'A short window changes nothing: every destination is still reachable',
    claims: assignedOperator(),
    routes,
    async run(context) {
      const checks = new Checks('app-shell-rail-on-a-short-window');
      const { renderedText, findAll } = context;
      await mountShell(context);
      const text = renderedText();

      checks.contains('the desktop rail is still the branch rendered', text, 'ACTIVE WORKSPACE');
      assertEveryDestinationRenders(checks, text);

      const last = destinationNode(findAll, DESTINATIONS[DESTINATIONS.length - 1]);
      const listRegion = verticalScrollAncestor(last);
      checks.that(
        'the navigation list still scrolls when the window is half as tall',
        listRegion !== undefined,
        'no scrolling ancestor at 560 px of window height',
      );
      const boundary = findAll((value) => value.trim() === 'AUTHORITY BOUNDARY')[0];
      checks.that(
        'and the safety statement is still pinned rather than pushed off',
        boundary !== undefined && verticalScrollAncestor(boundary) !== listRegion,
        'the authority boundary card moved into the scrolling list',
      );
      return checks;
    },
  },

  {
    id: 'app-shell-compact-rail',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    // Below AppShell's 980 px threshold, where the rail becomes a horizontal header.
    viewport: { width: 900, height: 640 },
    title: 'Below 980 px the rail becomes a header that scrolls sideways, with nothing dropped',
    claims: assignedOperator(),
    routes,
    async run(context) {
      const checks = new Checks('app-shell-compact-rail');
      const { renderedText, findAll } = context;
      await mountShell(context);
      const text = renderedText();

      checks.omits('the desktop rail is not rendered at this width', text, 'ACTIVE WORKSPACE');
      assertEveryDestinationRenders(checks, text);

      const first = destinationNode(findAll, DESTINATIONS[0]);
      const last = destinationNode(findAll, DESTINATIONS[DESTINATIONS.length - 1]);
      const header = horizontalScrollAncestor(last);
      checks.that(
        'the compact header scrolls horizontally',
        header !== undefined,
        'no ancestor of the last destination has overflow-x auto or scroll',
      );
      checks.that(
        'and holds every destination in one region',
        header !== undefined && horizontalScrollAncestor(first) === header,
        'the compact header is split across more than one scrolling region',
      );
      return checks;
    },
  },
];
