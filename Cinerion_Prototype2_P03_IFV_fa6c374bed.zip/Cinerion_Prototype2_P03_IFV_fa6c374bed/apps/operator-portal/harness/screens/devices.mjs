/**
 * CH1-UX-SCR-0018, device and configuration management.
 *
 * The property worth gating here is honesty about what a consequential act did **not**
 * do. CH1-COM-IF-0004 puts the MQTT topic ACL in the broker, which is not enabled, so
 * revocation withdraws platform trust and nothing else. A receipt implying both halves
 * took effect would be the more dangerous kind of wrong: an administrator would believe a
 * device had been cut off at the transport when it had not. The API reports
 * `brokerTopicAclRevoked: false` with a note, and this asserts the screen renders the
 * refusal rather than a tidy summary of its own.
 *
 * The second property is authority. The catalogue gives the device *read* to the Engineer
 * and Maintenance Engineer and the *revocation* to the Cybersecurity Administrator — two
 * different roles, which is conflict 16 in the handover. An identity holding one and not
 * the other must be told exactly that, and the control it may not use must not be offered
 * at all rather than offered and refused.
 */
import { captured } from '../fixtures.mjs';
import { Checks, expectedInstant } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const deviceRecord = () => captured('DeviceRecord');
const revocation = () => captured('DeviceRevocation');

const DEVICE = /^\/api\/v1\/devices\/[^/]+$/;

function baseRoutes({ deviceStatus = 200, deviceAnswer = deviceRecord } = {}) {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    {
      method: 'GET',
      matches: (p) => DEVICE.test(p),
      status: deviceStatus,
      answer: async () => deviceAnswer(),
    },
  ];
}

const notVisible = () => ({
  code: 'DEVICE_NOT_FOUND',
  detail: 'No device answers to that identifier.',
  correlationId: 'harness',
});

export const scenarios = [
  {
    id: 'devices-record',
    screen: 'CH1-UX-SCR-0018',
    route: '/devices',
    title: 'The device record is rendered as the service states it, last-seen included',
    claims: assignedOperator(),
    routes: () => baseRoutes(),
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('devices-record');
      await mountScreen('@/app/devices.tsx');
      const text = renderedText();
      const device = deviceRecord();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'the device it opened is the controller the assigned cell reports',
        service.pathsRequested().includes(`/api/v1/devices/${cellState().controllerId}`),
        service.pathsRequested().join(' | '),
      );

      checks.contains('the device identifier is shown', text, device.deviceId);
      checks.contains('with its type', text, device.deviceType);
      checks.contains('the firmware it is running', text, device.firmwareVersion);
      checks.contains('and the configuration revision it is running', text, device.configurationRevision);
      checks.contains('the trust state is written out', text, device.trustState);
      checks.contains(
        'when it was last heard from is stated rather than presented as "online"',
        text,
        expectedInstant(device.lastSeenAt),
      );
      checks.omits(
        'and the screen never claims the device is online, which is not a fact the record carries',
        text,
        'Device online',
      );

      // A device that has been heard from is not a device that is up. The service says
      // "Reported" or "Unknown" and leaves the judgement to the reader.
      checks.contains(
        'the last-seen value is qualified by the service, not by the screen',
        text,
        device.lastSeenQuality,
      );
      checks.that(
        'reading a device wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );
      return checks;
    },
  },

  {
    id: 'devices-revoke-not-offered-without-the-role',
    screen: 'CH1-UX-SCR-0018',
    route: '/devices',
    title: 'An identity without the role is not offered the revocation at all',
    claims: assignedOperator(),
    routes: () => baseRoutes(),
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('devices-revoke-not-offered-without-the-role');
      await mountScreen('@/app/devices.tsx');
      const text = renderedText();

      checks.omits(
        'no reason field is rendered for an identity that may not revoke',
        text,
        'Controller returned to the supplier',
      );
      checks.contains(
        'and the screen says why the control is absent rather than leaving it unexplained',
        text,
        'This identity does not hold that role, so the control is not offered rather than offered and refused.',
      );
      checks.contains(
        'naming the authenticator the act additionally requires',
        text,
        'origin-bound authenticator',
      );
      return checks;
    },
  },

  {
    id: 'devices-revoke-blind',
    screen: 'CH1-UX-SCR-0018',
    route: '/devices',
    title: 'The role that may withdraw trust but not read the device is told exactly that',
    // Conflict 16: api_endpoints.json gives the read to the Engineer and Maintenance
    // Engineer, and the revocation to the Cybersecurity Administrator. Both controlled
    // documents agree, so this is the intended position — and its consequence is that
    // revocation would be performed blind unless the screen says so.
    claims: assignedOperator({ roles: ['CybersecurityAdministrator'] }),
    routes: () => baseRoutes({ deviceStatus: 404, deviceAnswer: notVisible }),
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('devices-revoke-blind');
      await mountScreen('@/app/devices.tsx');
      const text = renderedText();

      checks.contains(
        'the empty state does not distinguish absent from unauthorised',
        text,
        'All three answer identically, so probing cannot tell them apart.',
      );
      checks.contains(
        'and the split between the two roles is named, because it is a property of the catalogue',
        text,
        'This identity may withdraw device trust but may not read a device',
      );
      checks.contains(
        'with what that costs stated plainly',
        text,
        'Revoking from here would therefore be done without sight of the certificate',
      );
      checks.contains(
        'and what to do instead',
        text,
        'Ask someone holding the Engineer or Maintenance Engineer role to confirm the device first.',
      );
      return checks;
    },
  },

  {
    id: 'devices-revocation-receipt-is-honest',
    screen: 'CH1-UX-SCR-0018',
    route: '/devices',
    title: 'The revocation receipt reports the half that did not happen',
    claims: assignedOperator(),
    // Rendered directly, because reaching the receipt through the screen needs a
    // phishing-resistant step-up grant, and issuing one here would be the harness
    // manufacturing an elevation. The component is the shipped one and the receipt is the
    // response the service really sent; what is not exercised is the step-up flow that
    // precedes it, which is stated rather than glossed.
    routes: () => baseRoutes(),
    async run({ mountElement, createElement, importPortal, renderedText }) {
      const checks = new Checks('devices-revocation-receipt-is-honest');
      const screen = await importPortal('@/app/devices.tsx');
      const result = revocation();

      checks.that(
        'the shipped receipt component is exported for rendering',
        typeof screen.RevocationReceipt === 'function',
        'RevocationReceipt is not exported from the devices screen',
      );
      if (typeof screen.RevocationReceipt !== 'function') return checks;

      const mounted = await mountElement(
        createElement(screen.RevocationReceipt, { result }),
      );
      const text = renderedText(mounted.container);

      checks.contains('the device is named', text, result.device.deviceId);
      checks.contains('with its new trust state', text, result.device.trustState);
      checks.contains('and who withdrew it', text, result.device.revokedBy);
      if (result.device.revocationReason) {
        checks.contains('the recorded reason is readable', text, result.device.revocationReason);
      }
      if (result.alarm) {
        checks.contains('the alarm the platform raised is named', text, result.alarm.alarmCode);
        checks.contains(
          'and the guidance is the server’s own words',
          text,
          result.alarm.guidance,
        );
      }

      // The point of the whole scenario.
      const effect = result.effect;
      checks.contains(
        'what did take effect is marked DONE',
        text,
        `DONE · Platform trust withdrawn`,
      );
      checks.that(
        'and what did NOT take effect is marked NOT DONE rather than omitted',
        effect.brokerTopicAclRevoked === true
          ? text.includes('DONE · Broker topic ACL revoked')
          : text.includes('NOT DONE · Broker topic ACL revoked'),
        `brokerTopicAclRevoked is ${effect.brokerTopicAclRevoked}`,
      );
      checks.that(
        'the captured response really does carry an un-done half, so this is not asserted against a happy path',
        effect.brokerTopicAclRevoked === false,
        'the broker ACL half reports as done, so the honesty of the receipt is untested',
      );
      checks.contains(
        'and the note explaining it is rendered verbatim',
        text,
        effect.brokerTopicAclNote,
      );
      await mounted.unmount();
      return checks;
    },
  },
];
