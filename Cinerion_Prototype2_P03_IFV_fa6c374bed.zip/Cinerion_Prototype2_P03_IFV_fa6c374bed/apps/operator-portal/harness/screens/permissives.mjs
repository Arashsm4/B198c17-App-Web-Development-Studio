/**
 * "Not permissive" and "nobody has been asked" are different facts, and the interface
 * has to keep them apart.
 *
 * CH1-COM-IF-0003 made the API distinguish them: `permissivesReported` says whether the
 * controller answered its permissives **at all**, and `deferredCheckCodes` says which
 * checks it declared it could not perform — 207 PRELIMINARY_PERMISSIVE_INVALID above all,
 * which the OPC UA and Modbus profiles both declare because a stand-in has no wired
 * inputs to read. Proto3 leaves an unset boolean false, so a gateway that populates the
 * interlocks and forgets the flag sends exactly the dangerous message; the domain
 * therefore resolves such a cell as **not permissive whatever the individual fields say**.
 *
 * CH1-MON-FR-0003 is precisely about keeping those states apart in an operational view.
 * A screen that reads the six interlock booleans and renders "6 / 6 valid" for a cell
 * nobody has answered for shows a fully ready cell, in green, on the strength of a
 * default value — which is the one reading an operator must never be given.
 *
 * These scenarios were written **before** the screens could satisfy them, which is the
 * order this repository uses for anything safety-relevant: the gate first, then the code
 * it protects.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];

/** The captured cell as it stands: every interlock true, and no controller has answered. */
const unanswered = () => {
  const cell = captured('CellState');
  return { ...cell, permissivesReported: false, deferredCheckCodes: [206, 207] };
};

/** The same cell with a controller that did answer, so the contrast is the flag alone. */
const answered = () => {
  const cell = captured('CellState');
  return { ...cell, permissivesReported: true, deferredCheckCodes: [] };
};

function routesFor(cellState) {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    // The operations overview also asks the device register about the controller; the
    // register is a controlled capability that answers 501 in this build, and the screen
    // reports that rather than inventing an inventory.
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/devices\/[^/]+$/.test(p),
      status: 501,
      answer: async () => ({
        code: 'CAPABILITY_NOT_ENABLED',
        detail: 'AssetVault is a controlled capability that is not enabled in this build.',
        correlationId: 'harness',
      }),
    },
  ];
}

/**
 * Asserted the same way on every screen that shows a readiness envelope, because the
 * distinction has to hold on all of them or an operator can simply read the other one.
 */
async function assertsTheDistinction(checks, { text, screenName }) {
  const cell = unanswered();

  checks.that(
    `${screenName}: the fixture is the dangerous case — every interlock true, nobody asked`,
    Object.values(cell.interlocks).every((value, index) =>
      Object.keys(cell.interlocks)[index] === 'faultCauseActive' ? value === false : value === true,
    ) && cell.permissivesReported === false,
    JSON.stringify(cell.interlocks),
  );

  checks.omits(
    `${screenName}: a cell nobody has answered for is NOT counted as fully valid`,
    text,
    '6 / 6',
  );
  checks.that(
    `${screenName}: and the count is not written any other way either`,
    !/6\s*\/\s*6/.test(text),
    'the six interlocks must not read as six valid permissives when none were reported',
  );
  checks.contains(
    `${screenName}: the screen says the permissives were never answered`,
    text,
    'NOT ANSWERED',
  );
  checks.contains(
    `${screenName}: and says what that means rather than only flagging it`,
    text,
    'The controller has not reported its permissives',
  );
  for (const code of cell.deferredCheckCodes) {
    checks.contains(
      `${screenName}: deferred check ${code} is named, because the reason is what an operator needs`,
      text,
      String(code),
    );
  }
}

export const scenarios = [
  {
    id: 'operations-permissives-not-answered',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    title: 'The operations overview does not read a cell nobody answered for as ready',
    claims: assignedOperator(),
    routes: () => routesFor(unanswered),
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('operations-permissives-not-answered');
      await mountScreen('@/app/index.tsx');
      await assertsTheDistinction(checks, {
        text: renderedText(),
        screenName: 'CH1-UX-SCR-0016',
      });
      return checks;
    },
  },

  {
    id: 'operations-permissives-answered',
    screen: 'CH1-UX-SCR-0016',
    route: '/',
    title: 'A cell whose controller did answer still reads as it always did',
    claims: assignedOperator(),
    routes: () => routesFor(answered),
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('operations-permissives-answered');
      await mountScreen('@/app/index.tsx');
      const text = renderedText();

      // The contrast is the whole point. Without this the screen could satisfy the
      // scenario above by never showing a healthy cell as healthy, which would be a
      // different defect rather than a fix.
      checks.contains(
        'a cell whose controller answered, with every interlock valid, does read as fully valid',
        text,
        '6 / 6',
      );
      checks.omits(
        'and is not marked as unanswered',
        text,
        'NOT ANSWERED',
      );
      return checks;
    },
  },

  {
    id: 'command-permissives-not-answered',
    screen: 'CH1-UX-SCR-0008',
    route: '/command',
    title: 'The prepared-command screen does not summarise unanswered permissives as valid',
    claims: assignedOperator(),
    routes: () => routesFor(unanswered),
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('command-permissives-not-answered');
      await mountScreen('@/app/command.tsx');
      await assertsTheDistinction(checks, {
        text: renderedText(),
        screenName: 'CH1-UX-SCR-0008',
      });
      return checks;
    },
  },
];
