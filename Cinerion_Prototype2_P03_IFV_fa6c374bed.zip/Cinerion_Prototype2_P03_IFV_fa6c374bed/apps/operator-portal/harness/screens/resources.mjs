/**
 * CH1-UX-SCR-0017, the resource and capacity board.
 *
 * Two properties. The first is that **a reservation starts nothing**: holding capacity is
 * a bookkeeping act, and every physical-effect path stays inside CommandGuard, local
 * permissives and local confirmation. A board that implied otherwise would be the portal
 * claiming physical execution, which AGENTS.md forbids outright.
 *
 * The second is that an over-committed resource says so. Capacity can be withdrawn out of
 * band beneath a live holding — the captured page carries exactly that, 200 m committed
 * against a capacity of 150 — and a board that clamped the arithmetic to zero, or hid the
 * conflict, would show a resource as merely fully booked when it is in fact over-committed.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const resourcePage = () => captured('ResourcePage');

function routes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    { method: 'GET', matches: (p) => p.startsWith('/api/v1/resources'), answer: async () => resourcePage() },
  ];
}

export const scenarios = [
  {
    id: 'resources-board',
    screen: 'CH1-UX-SCR-0017',
    route: '/resources',
    title: 'Capacity, what is committed against it, and where the two disagree',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('resources-board');
      await mountScreen('@/app/resources.tsx');
      const text = renderedText();
      const page = resourcePage();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'looking at the board wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      checks.contains(
        'the board states that a reservation starts nothing',
        text,
        'A reservation holds capacity and starts nothing',
      );
      checks.contains(
        'and that every physical-effect path stays inside the confirmation chain',
        text,
        'every physical-effect path stays inside CommandGuard, local permissives and local confirmation',
      );

      for (const item of page.items) {
        checks.contains(`resource ${item.name} is listed`, text, item.name);
        checks.contains(
          `resource ${item.name} states its capacity in its own unit`,
          text,
          `${item.capacity}`,
        );
        checks.contains(
          `resource ${item.name} states its availability state as the service reports it`,
          text,
          item.availabilityState,
        );
      }

      // The conflict, which is the case a board is most likely to smooth over.
      const conflicted = page.items.filter((item) => item.conflicted);
      checks.that(
        'the captured page carries an over-committed resource, so that branch is exercised',
        conflicted.length > 0,
        'no captured resource is conflicted',
      );
      for (const item of conflicted) {
        checks.contains(
          `the over-committed ${item.name} is marked as such rather than merely full`,
          text,
          'OVER-COMMITTED',
        );
        checks.that(
          `and its negative availability is shown rather than clamped to zero`,
          item.availableNow >= 0 || text.includes(String(item.availableNow)),
          `availableNow is ${item.availableNow} and does not appear on the page`,
        );
      }
      return checks;
    },
  },

  {
    id: 'resources-allocation-states-its-physical-effect',
    screen: 'CH1-UX-SCR-0017',
    route: '/resources',
    title: 'Every holding carries the server’s statement that it started nothing',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, pressAll }) {
      const checks = new Checks('resources-allocation-states-its-physical-effect');
      await mountScreen('@/app/resources.tsx');

      // Holdings sit behind a per-resource disclosure, so every one is opened first.
      const opened = await pressAll('▸ SHOW');
      checks.that(
        'every resource offers a disclosure for what is held against it',
        opened === resourcePage().items.length,
        `${opened} disclosures for ${resourcePage().items.length} resources`,
      );
      const text = renderedText();

      const allocations = resourcePage().items.flatMap((item) => item.reservations ?? []);
      checks.that(
        'the captured page carries a holding, so the statement is exercised',
        allocations.length > 0,
        'no captured resource carries a reservation',
      );

      for (const allocation of allocations) {
        checks.contains(
          `holding ${allocation.allocationId} carries the server’s physical-effect statement`,
          text,
          allocation.physicalEffect,
        );
        checks.that(
          `and that statement really does report no physical effect`,
          /none/i.test(allocation.physicalEffect),
          `the service reported physicalEffect "${allocation.physicalEffect}"`,
        );
      }
      return checks;
    },
  },
];
