/**
 * CH1-UX-SCR-0005, the live control room, rendered and driven.
 *
 * What this establishes that no other gate does: the screen's *rendered* behaviour.
 * `npm run contracts:portal` proves the portal reads fields the service actually sends;
 * `dotnet test` proves the service sends the right ones. Neither says anything about
 * what an operator ends up looking at, and the properties CH1-MON-FR-0003,
 * CH1-COL-FR-0002 and CH1-UXD-DSG-0001 state are properties of exactly that.
 *
 * Every expectation below is derived from the captured response rather than written
 * out, so the checks stay true when the fixtures are recaptured and cannot quietly
 * become assertions about a constant.
 */
import { captured } from '../fixtures.mjs';
import {
  Checks,
  expectedInstant,
  expectedTimeOfDay,
  expectedValue,
  newestPerChannel,
} from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const CELL = '00000000-0000-4000-8000-000000000103';

const alarmPage = () => captured('AlarmPage');
const telemetryPage = () => captured('TelemetryPage');
const projects = () => [captured('ProjectSummary')];

/** The reads this screen and its shell are permitted to make, and their answers. */
function readRoutes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => p.startsWith('/api/v1/telemetry'),
      answer: async () => telemetryPage(),
    },
    { method: 'GET', matches: (p) => p.startsWith('/api/v1/alarms'), answer: async () => alarmPage() },
    {
      // The one mutation this screen can issue. Answered with the acknowledgement the
      // service really returned, so the receipt the screen renders is the server's words.
      method: 'POST',
      matches: (p) => /^\/api\/v1\/alarms\/[^/]+\/acknowledgements$/.test(p),
      status: 201,
      answer: async () => captured('AlarmAcknowledgement'),
    },
  ];
}

function priorityWord(priority) {
  return { 1: 'CRITICAL', 2: 'HIGH', 3: 'MEDIUM', 4: 'LOW', 5: 'INFORMATION' }[priority] ?? 'UNCLASSIFIED';
}

export const scenarios = [
  {
    id: 'control-room-live',
    screen: 'CH1-UX-SCR-0005',
    route: '/control-room',
    title: 'The control room renders every captured alarm and channel, from the service response alone',
    claims: assignedOperator(),
    routes: readRoutes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('control-room-live');
      await mountScreen('@/app/control-room.tsx');
      const text = renderedText();
      const alarms = alarmPage();
      const telemetry = telemetryPage();

      checks.that(
        'the screen asked Control Core for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'telemetry and alarms were both requested for the cell the identity is scoped to',
        service.pathsRequested().some((path) => path.startsWith(`/api/v1/telemetry?cellId=${CELL}`)) &&
          service.pathsRequested().some((path) => path.startsWith(`/api/v1/alarms?cellId=${CELL}`)),
        service.pathsRequested().join(' | '),
      );
      checks.that(
        'the screen issued no mutation while merely being looked at',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      // -- Every allowlisted channel is visible, whether or not it is publishing. ------
      for (const channel of telemetry.channelAllowlist.channels) {
        checks.contains(`channel ${channel.channelId} is listed`, text, channel.channelId);
        checks.contains(
          `channel ${channel.channelId} states its alarm limits`,
          text,
          `Alarm limits ${channel.lowerAlarmLimit} — ${channel.upperAlarmLimit} ${channel.unit}`,
        );
      }
      const publishing = new Set(telemetry.items.map((sample) => sample.channelId));
      const silent = telemetry.channelAllowlist.channels.filter((c) => !publishing.has(c.channelId));
      checks.that(
        'a declared channel with no sample says so rather than being left out',
        silent.length === 0 || text.includes('NO READING'),
        `${silent.length} declared channels have no sample in the captured page`,
      );

      // -- The newest reading on each publishing channel, with its provenance. --------
      // Only the newest per channel is shown, which is the screen's stated design; the
      // harness works out which that is rather than asking the screen.
      const newest = newestPerChannel(telemetry.items);
      checks.that(
        'the captured page carries more than one reading on some channel, so "newest" means something',
        telemetry.items.length > newest.size,
        `${telemetry.items.length} samples across ${newest.size} channels`,
      );
      const superseded = telemetry.items.filter(
        (sample) => newest.get(sample.channelId).sampleId !== sample.sampleId,
      );
      for (const stale of superseded) {
        checks.omits(
          `the superseded ${stale.channelId} reading of ${expectedValue(stale.value)} is not shown beside the newest`,
          text,
          `${expectedValue(stale.value)} ${stale.unit}`,
        );
      }
      for (const sample of newest.values()) {
        checks.contains(
          `the ${sample.channelId} reading carries its value and unit`,
          text,
          `${expectedValue(sample.value)} ${sample.unit}`,
        );
        checks.contains(
          `the ${sample.channelId} reading names the device that took it`,
          text,
          sample.deviceId,
        );
        checks.contains(
          `the ${sample.channelId} reading states when it was sampled`,
          text,
          expectedTimeOfDay(sample.sampledAt),
        );
        checks.contains(
          `the ${sample.channelId} reading states its quality`,
          text,
          `QUALITY ${sample.quality.toUpperCase()}`,
        );
        checks.contains(
          `the ${sample.channelId} reading states the freshness the server declared`,
          text,
          sample.freshness.toUpperCase(),
        );

        // A reading past its limit must say who decides that it is an alarm. The screen
        // renders no alarm of its own and must not look as though it had.
        const channel = telemetry.channelAllowlist.channels.find(
          (candidate) => candidate.channelId === sample.channelId,
        );
        const outside =
          channel !== undefined &&
          (sample.value < channel.lowerAlarmLimit || sample.value > channel.upperAlarmLimit);
        if (outside) {
          checks.contains(
            `the out-of-limit ${sample.channelId} reading names Control Core as what raises the alarm`,
            text,
            '▲ OUTSIDE ALARM LIMIT — Control Core raises the alarm, not this screen.',
          );
        }
      }
      checks.that(
        'the captured page carries a reading outside its alarm limits, so that branch is exercised',
        [...newest.values()].some((sample) => {
          const channel = telemetry.channelAllowlist.channels.find(
            (candidate) => candidate.channelId === sample.channelId,
          );
          return (
            channel !== undefined &&
            (sample.value < channel.lowerAlarmLimit || sample.value > channel.upperAlarmLimit)
          );
        }),
        'every captured reading is inside its limits',
      );

      // -- The bounds the server applied, so a full page is not read as a complete one.
      checks.contains('the row count is the one the server returned', text, `Rows returned${telemetry.count}`);
      checks.contains(
        'completeness is stated, not implied',
        text,
        telemetry.truncated ? 'Complete answerNO — page is full' : 'Complete answerYes',
      );
      checks.contains('the row ceiling is the server declared bound', text, `Row ceiling${telemetry.bounds.maximumRows}`);
      checks.contains(
        'the widest permitted window is stated',
        text,
        `Widest window${telemetry.bounds.maximumWindowDays} days`,
      );

      // -- Cause, acknowledgement and outstanding, as three separate facts. -----------
      const outstanding = alarms.items.filter((alarm) => alarm.outstanding).length;
      checks.contains('the outstanding count is the one in the response', text, `${outstanding} OUTSTANDING`);

      for (const alarm of alarms.items) {
        checks.contains(`alarm ${alarm.alarmCode} is listed`, text, alarm.alarmCode);
        checks.contains(
          `alarm ${alarm.alarmCode} states its priority in words, not by colour`,
          text,
          `P${alarm.priority} ${priorityWord(alarm.priority)}`,
        );
        checks.contains(
          `alarm ${alarm.alarmCode} names the source that raised it`,
          text,
          `source ${alarm.sourceId}`,
        );
        checks.contains(
          `alarm ${alarm.alarmCode} states when it activated`,
          text,
          `activated ${expectedInstant(alarm.activatedAt)}`,
        );
        checks.contains(
          `alarm ${alarm.alarmCode} states its state as a word`,
          text,
          alarm.state.toUpperCase(),
        );

        // The three facts. Collapsing them into one "handled" indicator is the confusion
        // CH1-AUT-FDS-0001 and CH1-COL-FR-0003 exist to prevent, so each is asserted with
        // the value the response actually carries.
        checks.contains(
          `alarm ${alarm.alarmCode}: the cause is a fact of its own`,
          text,
          alarm.causeClear ? `CauseClear at ${expectedInstant(alarm.clearedAt)}` : 'CauseSTILL PRESENT',
        );
        checks.contains(
          `alarm ${alarm.alarmCode}: the acknowledgement is a separate fact`,
          text,
          alarm.acknowledgedAt === null
            ? 'ACKNOWLEDGEDNot acknowledged'
            : `ACKNOWLEDGED${alarm.acknowledgedBy} at ${expectedInstant(alarm.acknowledgedAt)}`,
        );
        checks.contains(
          `alarm ${alarm.alarmCode}: whether it is still outstanding is a third fact`,
          text,
          alarm.outstanding ? 'OutstandingYES' : 'OutstandingNo',
        );

        // The one that matters most: an alarm acknowledged while its cause is present
        // must not read as resolved anywhere on the page.
        if (alarm.acknowledgedAt !== null && !alarm.causeClear) {
          checks.that(
            `alarm ${alarm.alarmCode} is acknowledged with its cause present, and the screen states all three`,
            text.includes('CauseSTILL PRESENT') &&
              text.includes(`ACKNOWLEDGED${alarm.acknowledgedBy}`) &&
              text.includes('OutstandingYES'),
            'an acknowledgement must not present as a cleared cause',
          );
        }
      }
      return checks;
    },
  },

  {
    id: 'control-room-alarm-detail',
    screen: 'CH1-UX-SCR-0005',
    route: '/control-room',
    title: 'Every alarm opens on the server guidance, and its thread acknowledges nothing',
    claims: assignedOperator(),
    routes: readRoutes,
    async run({ mountScreen, renderedText, findAll, findByText, press, service, navigations }) {
      const checks = new Checks('control-room-alarm-detail');
      await mountScreen('@/app/control-room.tsx');
      const alarms = alarmPage().items;
      checks.that(
        'the captured alarm page carries an alarm to open',
        alarms.length > 0,
        'AlarmPage.items is empty',
      );

      // Bound to the alarm's own row rather than to a position on the page. The screen
      // opens one alarm at a time, and a positional lookup would silently start driving a
      // different alarm the moment the capture returned them in another order.
      const openAlarm = async (alarm) => {
        const row = findAll(
          (text) => text.includes(alarm.alarmCode) && text.includes('▸ DETAIL'),
        )[0];
        if (row === undefined) return false;
        await press(findByText('▸ DETAIL', row));
        return true;
      };

      for (const alarm of alarms) {
        const opened = await openAlarm(alarm);
        checks.that(`alarm ${alarm.alarmCode} can be opened`, opened, 'no detail control in its row');
        if (!opened) continue;
        const text = renderedText();

        checks.contains(
          `alarm ${alarm.alarmCode} shows the guidance the server sent`,
          text,
          alarm.guidance,
        );
        checks.contains(
          `alarm ${alarm.alarmCode} names its thread as a discussion that acknowledges nothing`,
          text,
          'Posting there records a message and acknowledges nothing about the alarm.',
        );

        if (alarm.acknowledgedAt === null) {
          checks.contains(
            `alarm ${alarm.alarmCode} offers the acknowledgement it still needs`,
            text,
            'ACKNOWLEDGE ALARM',
          );
          checks.contains(
            `alarm ${alarm.alarmCode} states what acknowledging does not do`,
            text,
            'It does not clear the cause, satisfy an interlock or confirm a physical action.',
          );
        } else {
          checks.contains(
            `alarm ${alarm.alarmCode} refuses a second acknowledgement rather than offering one`,
            text,
            `Already acknowledged by ${alarm.acknowledgedBy}. An alarm is acknowledged once; a second acknowledgement is refused rather than overwriting the first.`,
          );
          if (alarm.acknowledgementComment !== null) {
            checks.contains(
              `alarm ${alarm.alarmCode} keeps its recorded comment readable, not only auditable`,
              text,
              alarm.acknowledgementComment,
            );
          }
        }

        const openThread = findByText('OPEN THREAD');
        checks.that(`alarm ${alarm.alarmCode} offers its thread`, openThread !== undefined, 'no thread control');
        if (openThread !== undefined) {
          await press(openThread);
          const pushed = navigations().filter((entry) => entry.kind === 'push').pop();
          checks.that(
            `alarm ${alarm.alarmCode} opens its own thread, not an identifier the screen chose`,
            pushed?.target?.params?.threadId === alarm.contextThreadId,
            `pushed ${JSON.stringify(pushed?.target?.params ?? null)}, alarm thread ${alarm.contextThreadId}`,
          );
          checks.that(
            `alarm ${alarm.alarmCode} carries itself as the thread's subject rather than being replaced by it`,
            pushed?.target?.params?.objectType === 'Alarm' &&
              pushed?.target?.params?.objectId === alarm.alarmId,
            JSON.stringify(pushed?.target?.params ?? null),
          );
        }
      }

      checks.that(
        'opening every alarm and every thread wrote nothing to Control Core',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );
      return checks;
    },
  },

  {
    id: 'control-room-acknowledgement',
    screen: 'CH1-UX-SCR-0005',
    route: '/control-room',
    title: 'An acknowledgement needs a comment, and an empty one sends nothing',
    claims: assignedOperator(),
    routes: readRoutes,
    async run({ mountScreen, renderedText, findAll, findByText, press, typeInto, service }) {
      const checks = new Checks('control-room-acknowledgement');
      await mountScreen('@/app/control-room.tsx');

      const outstanding = alarmPage().items.find((alarm) => alarm.acknowledgedAt === null);
      if (outstanding === undefined) {
        checks.that(
          'the captured alarm page carries an alarm nobody has acknowledged',
          false,
          'every captured alarm is already acknowledged, so the acknowledgement control is never offered',
        );
        return checks;
      }

      const row = findAll(
        (text) => text.includes(outstanding.alarmCode) && text.includes('▸ DETAIL'),
      )[0];
      await press(findByText('▸ DETAIL', row));

      const posts = () => service.requests.filter((request) => request.method === 'POST');
      checks.equals('nothing has been written yet', posts().length, 0);

      // The refusal that matters: a required comment is enforced before anything leaves the
      // browser, so an incomplete acknowledgement never reaches the audit chain at all.
      await press(findByText('ACKNOWLEDGE ALARM'));
      const refused = renderedText();
      checks.contains(
        'an empty comment is refused in the interface, with the reason',
        refused,
        'An acknowledgement comment is required. It is retained on the alarm record and in the audit chain.',
      );
      checks.equals('and the refusal sent no request at all', posts().length, 0);

      const comment = 'Observed on the control room screen; fixturing inspected.';
      const field = [...globalThis.document.querySelectorAll('textarea, input')].pop();
      checks.that('the comment field is reachable', field !== undefined && field !== null, 'no field rendered');
      if (field === undefined || field === null) return checks;
      await typeInto(field, comment);

      await press(findByText('ACKNOWLEDGE ALARM'));
      const sent = posts();
      checks.equals('acknowledging with a comment sends exactly one request', sent.length, 1);
      if (sent.length === 1) {
        checks.equals(
          'it is addressed to the alarm being acknowledged',
          sent[0].path,
          `/api/v1/alarms/${outstanding.alarmId}/acknowledgements`,
        );
        checks.equals('and carries the comment that was typed', sent[0].body?.comment, comment);
      }

      const receipt = captured('AlarmAcknowledgement');
      const after = renderedText();
      checks.contains(
        'the receipt names who acknowledged it and when, from the response',
        after,
        `${receipt.acknowledgedBy} at ${expectedInstant(receipt.acknowledgedAt)}`,
      );
      checks.contains(
        'the receipt states the cause is unchanged by the acknowledgement',
        after,
        receipt.causeClear
          ? `Cause clear at ${expectedInstant(receipt.clearedAt)} — unchanged by this acknowledgement.`
          : 'Cause STILL PRESENT — unchanged by this acknowledgement.',
      );
      checks.contains(
        'and the control side effect is the server’s own words, not a label of the screen’s',
        after,
        receipt.controlSideEffect,
      );
      return checks;
    },
  },

  {
    id: 'control-room-link-lost',
    screen: 'CH1-UX-SCR-0005',
    route: '/control-room',
    title: 'When the link goes, the screen says so and withholds the acknowledgement',
    claims: assignedOperator(),
    routes: readRoutes,
    async run({ mountScreen, renderedText, findByText, press, advance, service }) {
      const checks = new Checks('control-room-link-lost');
      await mountScreen('@/app/control-room.tsx');
      const before = renderedText();
      checks.contains(
        'while the link is up the alarm feed reports the freshness the server declared',
        before,
        alarmPage().freshness.toUpperCase(),
      );

      // Long enough for the screen's own one-second poll to try again and fail.
      service.disconnect('/api/v1/alarms');
      await advance(1_400);
      const during = renderedText();

      checks.contains('the alarm feed reports DISCONNECTED', during, 'DISCONNECTED');
      checks.contains(
        'the screen states it is not current, in the words the operator needs',
        during,
        '▲ SCREEN NOT CURRENT — ACKNOWLEDGEMENT DISABLED',
      );
      checks.contains(
        'and says why acknowledging is withheld rather than simply greying out',
        during,
        'Acknowledging is a permanent record against your identity, so it is withheld until the screen reconciles.',
      );
      checks.contains('reconciliation is offered', during, 'RECONCILE NOW');
      checks.contains(
        'the last list received is still shown rather than the screen blanking',
        during,
        alarmPage().items[0]?.alarmCode ?? 'CH1-ALM',
      );

      const requestsBefore = service.requests.length;
      service.reconnect();
      const reconcile = findByText('RECONCILE NOW');
      if (reconcile !== undefined) await press(reconcile);
      await advance(1_400);
      const after = renderedText();
      checks.that(
        'reconciling asks Control Core again',
        service.requests.length > requestsBefore,
        `${requestsBefore} requests before, ${service.requests.length} after`,
      );
      checks.omits('and the not-current banner clears once it answers', after, '▲ SCREEN NOT CURRENT');
      checks.that(
        'nothing was written to Control Core at any point',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );
      return checks;
    },
  },

  {
    id: 'control-room-no-cell-scope',
    screen: 'CH1-UX-SCR-0005',
    route: '/control-room',
    title: 'An identity with no cell scope is told so, and no cell data is requested for it',
    claims: assignedOperator({ ch1_cell: undefined }),
    routes: readRoutes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('control-room-no-cell-scope');
      await mountScreen('@/app/control-room.tsx');
      const text = renderedText();

      checks.contains('the absence of a cell assignment is stated', text, 'NO CELL ASSIGNMENT');
      checks.contains(
        'and where the assignment comes from is stated with it',
        text,
        'Cell assignment is granted by an administrator in the identity provider.',
      );
      checks.that(
        'no telemetry was requested for an identity with no cell scope',
        !service.pathsRequested().some((path) => path.startsWith('/api/v1/telemetry')),
        service.pathsRequested().join(' | '),
      );
      checks.that(
        'no alarms were requested either',
        !service.pathsRequested().some((path) => path.startsWith('/api/v1/alarms')),
        service.pathsRequested().join(' | '),
      );
      checks.that(
        'and nothing was requested that the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      return checks;
    },
  },
];
