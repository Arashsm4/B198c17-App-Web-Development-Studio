/**
 * CH1-UX-SCR-0007, part genealogy, rendered and driven.
 *
 * The load-bearing property here is CH1-QMS-FR-0004's: a failing measurement and the
 * retest that supersedes it must **both** stay readable. A screen that showed only the
 * accepted result would render a part with a clean history and would be wrong in the one
 * direction that matters — an inspector reading it would not know a failure had ever
 * happened. Nothing else in the repository checks that the page actually shows both.
 *
 * The second is that a part outside the caller's scope and a part that never existed must
 * be indistinguishable. Control Core answers both `404`; this asserts the screen does not
 * then say which of the two occurred.
 */
import { captured } from '../fixtures.mjs';
import { Checks, expectedInstant } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const cellState = () => captured('CellState');
const genealogy = () => captured('PartGenealogy');
const identity = () => captured('PartIdentity');
const projects = () => [captured('ProjectSummary')];

const GENEALOGY = /^\/api\/v1\/parts\/([^/]+)\/genealogy$/;
const LOOKUP = /^\/api\/v1\/parts\?serialNumber=/;
const serialIn = (path) => decodeURIComponent(path.split('serialNumber=')[1] ?? '');

function readRoutes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    { method: 'GET', matches: (p) => GENEALOGY.test(p), answer: async () => genealogy() },
    // The owner-approved serial lookup recorded for conflict 15. It answers only for the
    // serial the captured part actually carries; anything else is a 404, which is what
    // Control Core answers both for an unknown serial and for one the caller may not
    // reach. A harness that answered every serial would be testing a service that does
    // not exist.
    {
      method: 'GET',
      matches: (p) => LOOKUP.test(p) && serialIn(p) === identity().serialNumber,
      answer: async () => identity(),
    },
    {
      method: 'GET',
      matches: (p) => LOOKUP.test(p),
      status: 404,
      answer: async () => ({
        code: 'PART_NOT_FOUND',
        detail: 'No part answers to that identifier.',
        correlationId: 'harness',
      }),
    },
  ];
}

/**
 * The same reads, but every genealogy answered as Control Core answers one the caller may
 * not see — which is the same answer it gives for a part that does not exist.
 */
function notVisibleRoutes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    {
      method: 'GET',
      matches: (p) => GENEALOGY.test(p),
      status: 404,
      answer: async () => ({
        code: 'PART_NOT_FOUND',
        detail: 'No part answers to that identifier.',
        correlationId: 'harness',
      }),
    },
  ];
}

export const scenarios = [
  {
    id: 'genealogy-part-history',
    screen: 'CH1-UX-SCR-0007',
    route: '/genealogy',
    title: 'The failure stays readable beside the retest that supersedes it',
    claims: assignedOperator(),
    routes: readRoutes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('genealogy-part-history');
      await mountScreen('@/app/genealogy.tsx');
      const text = renderedText();
      const record = genealogy();
      const part = record.part;

      checks.that(
        'the screen asked Control Core for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'the part it opened is the one the assigned cell reports, not one the screen chose',
        service.pathsRequested().includes(`/api/v1/parts/${cellState().partId}/genealogy`),
        service.pathsRequested().join(' | '),
      );
      checks.that(
        'reading a genealogy wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      // -- Permanent identity and origin -------------------------------------------
      checks.contains('the permanent serial number is shown', text, part.serialNumber);
      checks.contains('with the identity URI it was issued under', text, part.permanentIdentityUri);
      checks.contains('the work order that governed it is named', text, part.workOrderId);
      checks.contains('so is the revision in force', text, part.revisionId);
      checks.contains('and who made it', text, part.operatorId);

      // -- Disposition --------------------------------------------------------------
      checks.contains('the status is the one the record carries', text, part.status);
      checks.contains(
        'the number of open nonconformities is stated',
        text,
        String(part.openNcrIds.length),
      );
      for (const ncr of part.openNcrIds) {
        checks.contains(`open nonconformity ${ncr} is listed rather than counted only`, text, ncr);
      }
      if (part.release !== null) {
        checks.contains('the release record is named', text, part.release.releaseId);
        checks.contains('with the inspector who released it', text, part.release.inspectorId);
        checks.contains(
          'and when',
          text,
          expectedInstant(part.release.releasedAt),
        );
      } else {
        checks.contains(
          'an unreleased part says release is an independent Inspector action',
          text,
          'Release is an Inspector action, independent of whoever performed the work',
        );
      }

      // -- Provenance is the server's word, never the screen's ----------------------
      checks.contains('the provenance is rendered verbatim', text, record.provenance);
      checks.contains(
        'and evidence completeness is reported rather than computed',
        text,
        `Evidence completeness: ${record.evidenceCompleteness}`,
      );

      // -- The history, which is the whole point -----------------------------------
      checks.contains(
        'the measurement count is the one in the record',
        text,
        `Measurements (${part.measurements.length})`,
      );

      const failures = part.measurements.filter((m) => m.result !== 'Pass');
      const retests = part.measurements.filter((m) => m.supersedesMeasurementId !== null);
      checks.that(
        'the captured part carries a failure and a retest, so the requirement can be exercised',
        failures.length > 0 && retests.length > 0,
        `${failures.length} failures, ${retests.length} retests`,
      );

      for (const measurement of part.measurements) {
        checks.contains(
          `measurement ${measurement.measurementId} names its characteristic`,
          text,
          measurement.characteristic,
        );
        checks.contains(
          `measurement ${measurement.measurementId} states its reading against its limits`,
          text,
          `${measurement.value} ${measurement.unit} against ${measurement.lowerLimit}–${measurement.upperLimit} ${measurement.unit}`,
        );
        checks.contains(
          `measurement ${measurement.measurementId} writes its result out rather than relying on colour`,
          text,
          measurement.result === 'Pass' ? 'PASS' : 'FAIL',
        );
        checks.contains(
          `measurement ${measurement.measurementId} names the controlled run it belongs to`,
          text,
          measurement.testRunId.slice(0, 8),
        );
        checks.contains(
          `measurement ${measurement.measurementId} names the instrument that took it`,
          text,
          measurement.sourceDeviceId,
        );
        checks.contains(
          `measurement ${measurement.measurementId} says whether its calibration was valid when measured`,
          text,
          measurement.calibrationValid ? 'Valid when measured' : 'Not valid',
        );

        if (measurement.supersedesMeasurementId !== null) {
          checks.contains(
            `the retest names the result it supersedes and why the earlier one is kept`,
            text,
            `Retest superseding ${measurement.supersedesMeasurementId.slice(0, 8)}`,
          );
          checks.contains(
            'and cites the requirement that keeps it',
            text,
            'CH1-QMS-FR-0004 requires the failure and its rework to both remain readable.',
          );
        }
      }

      // The one that matters: a superseded failure is still on the page, with its own
      // failing value, marked as superseded rather than removed.
      for (const failure of failures) {
        const supersededBy = part.measurements.find(
          (m) => m.supersedesMeasurementId === failure.measurementId,
        );
        if (supersededBy === undefined) continue;
        checks.that(
          `the failing ${failure.value} ${failure.unit} is still readable beside the ${supersededBy.value} ${supersededBy.unit} retest`,
          text.includes(`${failure.value} ${failure.unit} against`) &&
            text.includes(`${supersededBy.value} ${supersededBy.unit} against`) &&
            text.includes('SUPERSEDED'),
          'a superseded failure must not be removed from the history',
        );
        checks.contains(
          'and the failing result is still marked as outside its limits',
          text,
          'OUTSIDE LIMITS',
        );
      }
      return checks;
    },
  },

  {
    id: 'genealogy-not-visible',
    screen: 'CH1-UX-SCR-0007',
    route: '/genealogy',
    title: 'A part the caller may not see reads exactly like one that never existed',
    claims: assignedOperator(),
    routes: notVisibleRoutes,
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('genealogy-not-visible');
      await mountScreen('@/app/genealogy.tsx');
      const text = renderedText();

      checks.contains(
        'the empty state is stated as an answer, not as a fault',
        text,
        'No part answers to that identifier',
      );
      checks.contains(
        'and says the two possibilities are deliberately indistinguishable',
        text,
        'Those two answer identically on purpose',
      );
      checks.omits(
        'the screen does not say the caller lacks authority, which would be the leak itself',
        text,
        'not authorised',
      );
      checks.omits('nor does it name a scope the caller cannot see', text, 'Forbidden');
      checks.omits(
        'and it renders no measurement history for a part it could not read',
        text,
        'Coating thickness',
      );
      return checks;
    },
  },

  {
    id: 'genealogy-serial-resolves-to-an-identity',
    screen: 'CH1-UX-SCR-0007',
    route: '/genealogy',
    title: 'A serial number resolves to a part identity, and the page says no scan was recorded',
    claims: assignedOperator({ ch1_cell: [] }),
    routes: readRoutes,
    async run({ mountScreen, renderedText, findByText, press, typeInto, service }) {
      const checks = new Checks('genealogy-serial-resolves-to-an-identity');
      await mountScreen('@/app/genealogy.tsx');

      const serial = identity().serialNumber;
      const before = service.pathsRequested().length;

      const field = [...globalThis.document.querySelectorAll('input, textarea')][0];
      checks.that('the identity field is reachable', field !== undefined, 'no field rendered');
      if (field === undefined) return checks;

      await typeInto(field, serial);
      await press(findByText('OPEN'));
      const requested = service.pathsRequested().slice(before);
      const text = renderedText();

      // Conflict 15's resolution, driven rather than described: the screen turned a
      // printed serial number into the controlled identifier the genealogy takes.
      checks.that(
        'the serial number was resolved through the owner-approved read',
        requested.some((path) => LOOKUP.test(path) && path.includes(encodeURIComponent(serial))),
        requested.join(' | '),
      );
      // With no cell assignment this identity had no part at all before typing, so the
      // genealogy request below exists only because the lookup produced an identifier.
      // That is conflict 15 in one line: an engineer holding a printed serial number and
      // nothing else could not reach the history at all.
      checks.that(
        'and the genealogy was then read for the identifier it returned',
        requested.some((path) => path === `/api/v1/parts/${identity().partId}/genealogy`),
        requested.join(' | '),
      );
      checks.contains('the resolved part is shown', text, genealogy().part.serialNumber);

      // The evidence path is NOT this one, and the screen must not let a reader think a
      // lookup that answered was a scan that was recorded.
      checks.contains('the page says no scan event was recorded', text, 'no scan event was recorded');
      checks.contains(
        'and states that recording one needs an enrolled device',
        text,
        'requires a signed session',
      );
      checks.that(
        'nothing was posted: the lookup mints no evidence',
        !requested.some((path) => path.includes('scan-events')),
        requested.join(' | '),
      );
      return checks;
    },
  },

  {
    id: 'genealogy-unknown-serial-is-not-a-fault',
    screen: 'CH1-UX-SCR-0007',
    route: '/genealogy',
    title: 'A serial the caller cannot reach reads the same as one that never existed',
    claims: assignedOperator(),
    routes: readRoutes,
    async run({ mountScreen, renderedText, findByText, press, typeInto }) {
      const checks = new Checks('genealogy-unknown-serial-is-not-a-fault');
      await mountScreen('@/app/genealogy.tsx');

      const field = [...globalThis.document.querySelectorAll('input, textarea')][0];
      checks.that('the identity field is reachable', field !== undefined, 'no field rendered');
      if (field === undefined) return checks;

      await typeInto(field, 'CH1-PART-999999-99');
      await press(findByText('OPEN'));
      const text = renderedText();

      // The two must be indistinguishable on the page as well as in the response, or the
      // screen leaks what the service refused to.
      checks.contains(
        'the refusal states that the two cases answer alike',
        text,
        'A serial you are not permitted to reach answers the same way',
      );
      checks.that(
        'and it is an empty state rather than a fault',
        !/error|failed|exception/i.test(text),
        text.slice(0, 200),
      );
      return checks;
    },
  },
];
