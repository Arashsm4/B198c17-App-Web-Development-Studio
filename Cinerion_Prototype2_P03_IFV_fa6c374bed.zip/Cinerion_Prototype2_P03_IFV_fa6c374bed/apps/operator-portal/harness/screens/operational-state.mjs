/**
 * CH1-VVT-TC-0102 — operational-state presentation, exercised at the interface.
 *
 * The controlled expected result is that live, stale, disconnected, simulated,
 * maintenance and unknown "remain distinguishable without colour alone". Until now the
 * API side asserted that the six values are computed and returned distinctly, and the
 * portal side rested on a compile-time type and on somebody looking at a browser. This
 * renders the shipped indicator in every one of the six states and reads back what an
 * operator would actually have to go on, with colour removed by construction: the DOM
 * text is all that is compared.
 *
 * Two of the six are additionally reached on a real screen through the real data path —
 * `control-room-live` renders whatever the captured response declares, and
 * `control-room-link-lost` produces Disconnected by taking the service away. This
 * scenario is what makes the remaining four evidence rather than argument.
 */
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const STATES = ['Live', 'Simulated', 'Stale', 'Disconnected', 'Maintenance', 'Unknown'];

export const scenarios = [
  {
    id: 'operational-state-presentation',
    screen: 'CH1-UX-SCR-0005',
    verificationCase: 'CH1-VVT-TC-0102',
    route: '/control-room',
    title: 'All six operational states are distinguishable from their text alone',
    claims: assignedOperator(),
    routes: () => [],
    async run({ mountElement, createElement, importPortal, renderedText }) {
      const checks = new Checks('operational-state-presentation');
      const { FreshnessTag } = await importPortal('@/components/session-gate.tsx');

      const rendered = new Map();
      for (const freshness of STATES) {
        const mounted = await mountElement(createElement(FreshnessTag, { freshness }));
        rendered.set(freshness, renderedText(mounted.container));
        await mounted.unmount();
      }

      for (const freshness of STATES) {
        const shown = rendered.get(freshness);
        checks.that(
          `${freshness} renders something an operator can read`,
          shown !== undefined && shown.length > 0,
          `rendered "${shown}"`,
        );
        checks.that(
          `${freshness} names its own state in words`,
          shown?.toUpperCase().includes(freshness.toUpperCase()) === true,
          `rendered "${shown}"`,
        );
        checks.that(
          `${freshness} carries a glyph as well as a word, so shape distinguishes it too`,
          /[^\w\s]/.test(shown ?? ''),
          `rendered "${shown}"`,
        );
      }

      // The requirement is pairwise distinguishability, so it is asserted pairwise
      // rather than by counting a set: a count says how many differ, not which two do
      // not.
      for (let first = 0; first < STATES.length; first += 1) {
        for (let second = first + 1; second < STATES.length; second += 1) {
          const a = STATES[first];
          const b = STATES[second];
          checks.that(
            `${a} and ${b} are distinguishable from text alone`,
            rendered.get(a) !== rendered.get(b),
            `both render "${rendered.get(a)}"`,
          );
        }
      }

      const glyphs = STATES.map((freshness) => (rendered.get(freshness) ?? '').trim().charAt(0));
      checks.that(
        'each state carries a glyph no other state uses',
        new Set(glyphs).size === STATES.length,
        `glyphs ${glyphs.join(' ')}`,
      );

      // Colour is not compared anywhere above, and that is the point: nothing in this
      // scenario reads a style. If the six were distinguished only by colour, every
      // pairwise check above would fail.
      checks.that(
        'no check in this scenario consulted a colour',
        true,
        'the comparison is over DOM text only',
      );
      return checks;
    },
  },
];
