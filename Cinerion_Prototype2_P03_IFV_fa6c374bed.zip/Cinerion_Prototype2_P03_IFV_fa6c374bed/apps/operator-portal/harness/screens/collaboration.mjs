/**
 * CH1-UX-SCR-0019, contextual collaboration.
 *
 * The property gated here is the one CH1-VVT-TC-0109 is about, seen from the interface:
 * a message carries **no control authority whatever**. Reading one acknowledges no alarm,
 * clears no fault and confirms no command. The alarm and message vocabularies are already
 * held apart at compile time by `Distinct<A, B>` in `constants/semantics.ts`, and the
 * database refuses the confusion with CHECK constraints — but neither says anything about
 * what the screen puts in front of a reader, and a screen that labelled a receipt
 * "acknowledged" would erode the distinction at the only point where a person acts on it.
 *
 * So the receipt's verb, its control-authority flag and its side-effect sentence are all
 * asserted to be the server's own words rather than anything the portal composed.
 */
import { captured } from '../fixtures.mjs';
import { Checks, expectedInstant } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const threadPage = () => captured('ContextThreadPage');
const readReceipt = () => captured('MessageReadReceipt');

function routes() {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/context-threads\/[^/]+\/messages/.test(p),
      answer: async () => threadPage(),
    },
    {
      method: 'POST',
      matches: (p) => /^\/api\/v1\/context-threads\/[^/]+\/messages$/.test(p),
      status: 201,
      answer: async () => captured('PostedContextMessage'),
    },
    {
      method: 'POST',
      matches: (p) => /acknowledgements$/.test(p),
      status: 201,
      answer: async () => readReceipt(),
    },
  ];
}

/**
 * Facts about an alarm that a message thread has no business asserting.
 *
 * Deliberately not "the alarm verb never appears": the screen shows both verbs side by
 * side on purpose, under "Different records. Different verbs.", which is the clearest
 * possible statement of the separation. What must never appear is a message thread
 * claiming something about an alarm's cause or acknowledgement state.
 */
const ALARM_CLAIMS = ['Cause STILL PRESENT', 'CAUSE CLEAR', 'Cause clear at', 'OutstandingYES'];

export const scenarios = [
  {
    id: 'collaboration-message-has-no-control-authority',
    screen: 'CH1-UX-SCR-0019',
    route: '/collaboration',
    title: 'A message carries no control authority, and the screen says so in the server’s words',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('collaboration-message-has-no-control-authority');
      await mountScreen('@/app/collaboration.tsx');
      const text = renderedText();
      const page = threadPage();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'reading a thread wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      checks.contains(
        'the page states outright that reading acknowledges no alarm',
        text,
        'Reading one acknowledges no alarm, clears no fault and confirms no command.',
      );
      checks.contains(
        'and the compose panel is headed as carrying no control authority',
        text,
        'No control authority',
      );
      for (const claim of ALARM_CLAIMS) {
        checks.omits(
          `the thread asserts nothing about an alarm's state ("${claim}")`,
          text,
          claim,
        );
      }

      // The separation is made by showing both verbs and naming the difference, which is
      // stronger than never mentioning the other one.
      checks.contains(
        'both verbs are shown side by side',
        text,
        'ACKNOWLEDGE ALARM',
      );
      checks.contains('with the message verb beside it', text, 'MARK AS READ');
      checks.contains(
        'and the difference stated rather than left to be inferred',
        text,
        'Different records. Different verbs.',
      );

      for (const message of page.items) {
        checks.contains(`message ${message.messageId} shows its body`, text, message.body);
        checks.contains(`message ${message.messageId} names its author`, text, message.authorId);
        checks.contains(
          `message ${message.messageId} states the author kind, human or otherwise`,
          text,
          message.authorKind,
        );
        checks.contains(
          `message ${message.messageId} states its delivery state as the service reports it`,
          text,
          message.deliveryState,
        );
        checks.contains(
          `message ${message.messageId} states when it was written`,
          text,
          expectedInstant(message.createdAt),
        );
      }

      // Retention is the server's declared policy, rendered rather than restated.
      checks.contains('the message retention is the declared one', text, page.retention.message);
      checks.contains('so is the receipt retention', text, page.retention.acknowledgement);
      checks.contains(
        'and the standing of a contextual message is stated',
        text,
        'A contextual message is communication, not a controlled engineering decision.',
      );
      return checks;
    },
  },

  {
    id: 'collaboration-empty-message-sends-nothing',
    screen: 'CH1-UX-SCR-0019',
    route: '/collaboration',
    title: 'A message with no body is refused in the interface and sends nothing',
    claims: assignedOperator(),
    routes,
    async run({ mountScreen, renderedText, findByText, press, service }) {
      const checks = new Checks('collaboration-empty-message-sends-nothing');
      await mountScreen('@/app/collaboration.tsx');

      const posts = () => service.requests.filter((request) => request.method === 'POST');
      checks.equals('nothing has been written yet', posts().length, 0);

      const post = findByText('POST MESSAGE');
      checks.that('the compose control is offered', post !== undefined, 'no post control rendered');
      if (post === undefined) return checks;

      await press(post);
      checks.contains(
        'an empty message is refused in the interface',
        renderedText(),
        'A message body is required.',
      );
      checks.equals('and the refusal sent no request at all', posts().length, 0);
      return checks;
    },
  },

  {
    id: 'collaboration-receipt-is-a-read-not-an-acknowledgement',
    screen: 'CH1-UX-SCR-0019',
    route: '/collaboration',
    title: 'A read receipt reports the server’s verb and no control authority',
    claims: assignedOperator(),
    routes,
    // Rendered directly. Recording a receipt through the screen needs a second identity —
    // an author cannot receipt their own message — and the captured receipt is the one the
    // service really issued, which is the point: the verb must be the server's.
    async run({ mountElement, createElement, importPortal, renderedText }) {
      const checks = new Checks('collaboration-receipt-is-a-read-not-an-acknowledgement');
      const screen = await importPortal('@/app/collaboration.tsx');
      const recorded = readReceipt();

      checks.that(
        'the shipped receipt component is exported for rendering',
        typeof screen.ReadReceipt === 'function',
        'ReadReceipt is not exported from the collaboration screen',
      );
      if (typeof screen.ReadReceipt !== 'function') return checks;

      const mounted = await mountElement(createElement(screen.ReadReceipt, { recorded }));
      const text = renderedText(mounted.container);

      checks.contains(
        'the receipt reports the verb the server used, not one the screen chose',
        text,
        `RECEIPT KIND: ${recorded.kind.toUpperCase()}`,
      );
      checks.that(
        'and that verb really is a read rather than an acknowledgement',
        recorded.kind.toLowerCase() === 'read',
        `the service reported kind "${recorded.kind}"`,
      );
      checks.contains(
        'the receipt states it carries no control authority',
        text,
        `control authority ${String(recorded.controlAuthority)}`,
      );
      checks.that(
        'and the captured receipt really does carry none, so this is not asserted against a happy path',
        recorded.controlAuthority === false,
        'the captured receipt claims control authority',
      );
      checks.contains(
        'the side effect is the server’s sentence, rendered verbatim',
        text,
        recorded.controlSideEffect,
      );
      checks.contains(
        'and the object the thread hangs on is named',
        text,
        recorded.threadObject.type,
      );
      await mounted.unmount();
      return checks;
    },
  },
];
