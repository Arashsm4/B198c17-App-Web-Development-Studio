/**
 * Who is offered which act, and what an identity that holds none of them is told.
 *
 * The owner's words were "each role can respond and do their task". What the portal did
 * instead was decide that eight times over, in eight screens, as `roles.includes(...)`
 * written wherever a control happened to be - so the same authority was spelled
 * differently in different places and an identity holding none of a screen's roles was
 * shown a blank panel. A blank panel is the worst answer available: the operator cannot
 * tell whether the act exists, whether the screen is broken, or whose job it is.
 *
 * Three properties are exercised.
 *
 *   1. An identity that holds the role is OFFERED the control. Not "is predicted to
 *      succeed" - the server still evaluates scope, strength and segregation, and several
 *      of those cannot be known here at all.
 *   2. An identity that does not hold it is TOLD: the act, the controlled authority phrase
 *      verbatim, the roles this platform maps it to, and what this identity actually
 *      holds. That is enough to know who to ask.
 *   3. The control is never withheld for a reason the SERVER owns. Role segregation
 *      forbids several role combinations, and the chips for them are still offered: the
 *      rule is evaluated against the subject and the administrator together, a client that
 *      guessed it would eventually guess differently, and the refusal is shown as sent.
 *
 * The role-assignment act is the one the owner asked for by name - "admin or higher
 * operator should be able to ... add ... or other stuff", and underneath all of it, the
 * admin granting the permission in the first place. It is also the act that had been
 * implemented, tested and audited in Control Core for some time and was reachable only
 * with a command-line HTTP client, because the portal's API client had no PUT.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projectRoute = {
  method: 'GET',
  matches: (p) => p === '/api/v1/projects',
  answer: async () => [captured('ProjectSummary')],
};

function directoryPage() {
  return captured('DirectoryPage');
}

function routes() {
  return [
    projectRoute,
    { method: 'GET', matches: (p) => p === '/api/v1/users', answer: async () => directoryPage() },
  ];
}

/** Every role the panel may assign. DeviceController is deliberately not among them. */
const ASSIGNABLE = [
  'Viewer',
  'Auditor',
  'Engineer',
  'AutomationEngineer',
  'Inspector',
  'LocalConfirmer',
  'MaintenanceEngineer',
  'OperationsCoordinator',
  'ProjectManager',
  'ConfigurationManager',
  'RDEngineer',
  'DocumentController',
  'CybersecurityAdministrator',
  'SystemAdministrator',
  'ProjectOwner',
];

export const scenarios = [
  {
    id: 'capability-administrator-is-offered-role-assignment',
    screen: 'CH1-UX-SCR-0013',
    route: '/security',
    title: 'A system administrator is offered the act that grants every other authority',
    claims: assignedOperator({ roles: ['SystemAdministrator', 'Viewer'] }),
    routes,
    async run({ mountScreen, renderedText, findByText, service }) {
      const checks = new Checks('capability-administrator-is-offered-role-assignment');
      await mountScreen('@/app/security.tsx');
      const text = renderedText();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );

      checks.contains('the act is offered', text, 'Grant and withdraw controlled roles');
      checks.that(
        'and an identity can be chosen from the directory the screen already reads',
        directoryPage().items.every((user) => text.includes(user.username)),
        'not every listed identity is offered',
      );
      // Not "no act on this screen is withheld". This identity is a system administrator
      // and NOT a cybersecurity administrator, and role segregation is what keeps those
      // apart - so the two credential acts are correctly named rather than offered, and
      // asserting otherwise would be asserting that segregation had been ignored.
      checks.omits(
        'the role-assignment control itself is not replaced by an authority notice',
        text,
        'ANOTHER ROLE OWNS THIS ACT Change which controlled roles an identity holds',
      );
      checks.contains(
        'and the credential acts this identity does NOT hold are named, not hidden',
        text,
        'Register a cryptographic physical credential',
      );

      // Choosing a person is what reveals the role chips, so the scenario performs the
      // act an administrator performs rather than asserting on a closed panel.
      const person = findByText(directoryPage().items[0].username);
      checks.that('an identity in the directory is selectable', person !== undefined);
      return checks;
    },
  },

  {
    id: 'capability-role-chips-are-offered-without-pre-judging-segregation',
    screen: 'CH1-UX-SCR-0013',
    route: '/security',
    title: 'Every assignable role is offered, including combinations the server will refuse',
    claims: assignedOperator({ roles: ['SystemAdministrator', 'Viewer'] }),
    routes,
    async run({ mountScreen, renderedText, findByText, findAll, press, service }) {
      const checks = new Checks('capability-role-chips-are-offered-without-pre-judging-segregation');
      await mountScreen('@/app/security.tsx');

      const subject = directoryPage().items[0];
      await press(findByText(subject.username));
      const text = renderedText();

      checks.contains('the working role set is shown', text, 'ROLES THIS IDENTITY WILL HOLD');
      for (const role of ASSIGNABLE) {
        checks.contains(`${role} can be granted or withdrawn`, text, role);
      }

      // The point of this scenario. CybersecurityAdministrator may not sit beside
      // SystemAdministrator or Inspector, and the chip is offered anyway: the rule is the
      // domain's, evaluated against both identities, and a client that greyed it out would
      // be asserting a decision it did not make.
      checks.contains(
        'the screen states that segregation is the server’s to evaluate, not a greyed-out chip',
        text,
        'a refusal is shown exactly as it is sent',
      );
      checks.contains(
        'and says why DeviceController is not among the chips',
        text,
        'Device accounts authenticate by mutual TLS',
      );
      // Asserted on the CHIPS rather than on the page text, because the panel's own note
      // explains why DeviceController is absent and a text search finds that explanation.
      // Item 63's lesson one level out: prose about a control is not the control.
      const chipFor = (role) => findAll((value) => value.trim() === role).length;
      checks.that(
        'every assignable role has a chip of its own',
        ASSIGNABLE.every((role) => chipFor(role) > 0),
        ASSIGNABLE.filter((role) => chipFor(role) === 0).join(', '),
      );
      checks.equals('DeviceController has no chip', chipFor('DeviceController'), 0);

      checks.equals(
        'nothing has been sent merely by choosing an identity',
        service.requests.filter((request) => request.method !== 'GET').length,
        0,
      );
      return checks;
    },
  },

  {
    id: 'capability-act-not-held-is-named-not-hidden',
    screen: 'CH1-UX-SCR-0013',
    route: '/security',
    title: 'An identity without the role is told the act exists and who holds it',
    // An inspector: a real, useful identity in this plant that simply does not administer
    // identities. The previous behaviour showed them an empty screen.
    claims: assignedOperator({ roles: ['Inspector', 'Viewer'] }),
    routes,
    async run({ mountScreen, renderedText }) {
      const checks = new Checks('capability-act-not-held-is-named-not-hidden');
      await mountScreen('@/app/security.tsx');
      const text = renderedText();

      checks.contains('the act is named rather than omitted', text, 'ANOTHER ROLE OWNS THIS ACT');
      checks.contains(
        'the act itself is stated in the operator’s words',
        text,
        'Change which controlled roles an identity holds',
      );
      checks.contains(
        'the controlled authority phrase is quoted, not paraphrased',
        text,
        'System Administrator',
      );
      checks.contains(
        'and what this identity actually holds is stated',
        text,
        'This identity holds Inspector, Viewer',
      );
      checks.contains(
        'the operation is named, so the refusal can be looked up',
        text,
        'PUT /api/v1/users/{userId}/roles',
      );

      // The control itself is absent - that is the whole point of not offering an act the
      // controlled authority does not give this identity.
      checks.omits('the control is not offered', text, 'ROLES THIS IDENTITY WILL HOLD');

      // And the credential acts, which the same identity also does not hold, are named
      // too. One act named and another silently dropped would be the old behaviour with
      // extra steps.
      checks.contains(
        'the credential registration act is named as well',
        text,
        'Register a cryptographic physical credential',
      );
      checks.contains(
        'and so is credential revocation',
        text,
        'Revoke a lost or compromised credential',
      );
      return checks;
    },
  },
];
