/**
 * CH1-UX-SCR-0006, the work-order board.
 *
 * Two properties are worth gating, and both are about refusing to look complete.
 *
 * The board READS THE REGISTER now. Conflict 14 — the catalogue can raise a work order and
 * release one and can read neither back — is resolved by an owner-approved read, so the
 * screen shows what has been raised rather than explaining why it cannot. What has to stay
 * true is the property that replaced it: release state is REPORTED and conferred nowhere,
 * and the screen renders the service's own statement of that rather than a paraphrase. A
 * board that let "I can see it" drift into "I may release it" is the failure this guards.
 *
 * And a draft revision cannot start work. CH1-MFG-FR-0005 makes that a rule of the record
 * and Control Core refuses it whatever the screen offers — but a screen that offered the
 * control anyway would be inviting an operator into a refusal, so the form is withheld and
 * the reason given.
 */
import { captured } from '../fixtures.mjs';
import { Checks } from '../checks.mjs';
import { assignedOperator } from '../identity.mjs';

const projects = () => [captured('ProjectSummary')];
const cellState = () => captured('CellState');
const products = () => [captured('ProductGroup')];

/** The same catalogue with its released revision marked draft, so both branches are real. */
const productsWithADraft = () => {
  const group = captured('ProductGroup');
  return [
    {
      ...group,
      revisions: group.revisions.map((revision) => ({ ...revision, lifecycleState: 'Draft' })),
    },
  ];
};

function routes(productAnswer = products) {
  return [
    { method: 'GET', matches: (p) => p === '/api/v1/projects', answer: async () => projects() },
    { method: 'GET', matches: (p) => p === '/api/v1/products', answer: async () => productAnswer() },
    {
      method: 'GET',
      matches: (p) => /^\/api\/v1\/cells\/[^/]+\/state$/.test(p),
      answer: async () => cellState(),
    },
    // The board itself, an owner-approved read. Recorded conflict 14 said this screen
    // could only show what the session had written; it reads the register now.
    {
      method: 'GET',
      matches: (p) => p === '/api/v1/work-orders' || p.startsWith('/api/v1/work-orders?'),
      answer: async () => captured('WorkOrderBoardPage'),
    },
  ];
}

export const scenarios = [
  {
    id: 'work-orders-board',
    screen: 'CH1-UX-SCR-0006',
    route: '/work-orders',
    title: 'The board shows the controlled revisions and states what it cannot see',
    claims: assignedOperator(),
    routes: () => routes(),
    async run({ mountScreen, renderedText, service }) {
      const checks = new Checks('work-orders-board');
      await mountScreen('@/app/work-orders.tsx');
      const text = renderedText();
      const [group] = products();

      checks.that(
        'the screen asked for nothing the harness had not captured',
        service.unexpected.length === 0,
        JSON.stringify(service.unexpected),
      );
      checks.that(
        'looking at the board wrote nothing',
        service.requests.every((request) => request.method === 'GET'),
        service.requests.map((request) => `${request.method} ${request.path}`).join(' | '),
      );

      checks.contains('the product is listed', text, group.productCode);
      for (const revision of group.revisions) {
        checks.contains(`revision ${revision.revisionCode} is listed`, text, revision.revisionCode);
        checks.contains(
          `revision ${revision.revisionCode} states its lifecycle in words`,
          text,
          revision.lifecycleState.toUpperCase(),
        );
      }

      // The register itself. Every order the service sent is on the board, by number and
      // by status, so a board cannot render "released" from an absence.
      const board = captured('WorkOrderBoardPage');
      for (const order of board.items) {
        checks.contains(`work order ${order.workOrderNumber} is listed`, text, order.workOrderNumber);
        checks.contains(
          `and states its status rather than leaving it to be inferred`,
          text,
          order.status.toUpperCase(),
        );
      }
      checks.that(
        'the board reports the count the service sent',
        text.includes(String(board.count)),
        `the service sent ${board.count}`,
      );

      // The property that replaced the gap: seeing an order is not being allowed to
      // release one, and the screen says so in the service's own words.
      checks.contains(
        'the board states that release is reported and conferred nowhere',
        text,
        board.releaseAuthority,
      );
      checks.contains(
        'the order the cell reports is read from the cell state, not from a listing',
        text,
        'Read from the cell state, not from an order listing',
      );
      return checks;
    },
  },

  {
    id: 'work-orders-draft-cannot-start',
    screen: 'CH1-UX-SCR-0006',
    route: '/work-orders',
    title: 'A draft revision offers no way to raise an order, and says why',
    claims: assignedOperator({ roles: ['ProjectManager', 'Viewer'] }),
    routes: () => routes(productsWithADraft),
    async run({ mountScreen, renderedText, findByText }) {
      const checks = new Checks('work-orders-draft-cannot-start');
      await mountScreen('@/app/work-orders.tsx');
      const text = renderedText();

      checks.contains('the draft is still shown rather than hidden', text, 'DRAFT');
      checks.contains(
        'and says a draft revision cannot start a work order',
        text,
        'A draft revision cannot start a work order.',
      );
      checks.contains(
        'naming the requirement that makes it a rule of the record',
        text,
        'CH1-MFG-FR-0005',
      );
      checks.contains(
        'and stating that the server refuses it whatever the screen offers',
        text,
        'Control Core refuses it whatever this screen offers',
      );
      checks.that(
        'no control to raise an order against a draft is rendered',
        findByText('RAISE WORK ORDER') === undefined,
        'a raise control was offered for a draft revision',
      );
      return checks;
    },
  },

  {
    id: 'work-orders-released-offers-the-control',
    screen: 'CH1-UX-SCR-0006',
    route: '/work-orders',
    title: 'A released revision offers the form, and an order without its number sends nothing',
    claims: assignedOperator({ roles: ['ProjectManager', 'Viewer'] }),
    routes: () => [
      ...routes(),
      {
        // The one mutation this board issues that needs no step-up. Answered with the
        // record the service really returned.
        method: 'POST',
        matches: (p) => p === '/api/v1/work-orders',
        status: 201,
        answer: async () => captured('WorkOrderRecord'),
      },
    ],
    async run({ mountScreen, renderedText, findByText, press, typeInto, service }) {
      const checks = new Checks('work-orders-released-offers-the-control');
      await mountScreen('@/app/work-orders.tsx');

      checks.that(
        'the captured catalogue carries a released revision, so this contrast is real',
        products()[0].revisions.some((revision) => revision.lifecycleState === 'Released'),
        'every captured revision is a draft',
      );
      checks.omits(
        'a released revision carries no draft refusal',
        renderedText(),
        'A draft revision cannot start a work order.',
      );

      const disclosure = findByText('▸ RAISE A WORK ORDER');
      checks.that(
        'a released revision offers the form a draft does not',
        disclosure !== undefined,
        'no raise disclosure was offered for a released revision',
      );
      if (disclosure === undefined) return checks;
      await press(disclosure);

      const posts = () => service.requests.filter((request) => request.method === 'POST');
      checks.equals('nothing has been written yet', posts().length, 0);

      await press(findByText('RAISE WORK ORDER'));
      const refused = renderedText();
      checks.contains(
        'an order with no controlled number is refused in the interface',
        refused,
        'A work order must carry its controlled number.',
      );
      checks.equals('and the refusal sent no request at all', posts().length, 0);

      checks.contains(
        'the form states that raising an order starts nothing',
        refused,
        'starts nothing: it is a controlled record',
      );
      checks.contains(
        'and that execution still needs the local confirmation chain at the cell',
        refused,
        'the local confirmation chain completed at the cell',
      );
      return checks;
    },
  },
  {
    id: 'work-orders-raise-not-offered-without-the-role',
    screen: 'CH1-UX-SCR-0006',
    route: '/work-orders',
    title: 'An identity that may not raise an order is not offered the form at all',
    // Written because attacking the gate found this uncovered: neutering `canRaise`
    // changed nothing any scenario asserted, so the role gate could have been removed
    // without a single check noticing. The catalogue gives POST /work-orders to the
    // Project Manager, and the server refuses regardless — but offering a control that is
    // certain to be refused invites an operator into a refusal for no reason.
    claims: assignedOperator({ roles: ['Engineer', 'Viewer'] }),
    routes: () => routes(),
    async run({ mountScreen, renderedText, findByText }) {
      const checks = new Checks('work-orders-raise-not-offered-without-the-role');
      await mountScreen('@/app/work-orders.tsx');
      const text = renderedText();

      checks.that(
        'no raise disclosure is rendered for an identity without the role',
        findByText('▸ RAISE A WORK ORDER') === undefined,
        'the raise form was offered to an identity that may not raise an order',
      );
      checks.contains(
        'and the screen says whose action it is rather than leaving the absence unexplained',
        text,
        'Raising a work order is a Project Manager action.',
      );
      checks.contains(
        'stating that the control is withheld rather than offered and refused',
        text,
        'the control is not offered rather than offered and refused',
      );
      checks.that(
        'and the release control is withheld on the same terms',
        findByText('RELEASE WORK ORDER') === undefined,
        'a release control was offered to an identity without the role',
      );
      return checks;
    },
  },
];
