/**
 * Mounts a shipped portal screen and lets its effects run.
 *
 * Server rendering was the obvious way to do this and does not work: every screen
 * reads through `useObserved`, whose fetch happens in a `useEffect`, and server
 * rendering never runs effects — so `renderToStaticMarkup` produces the loading state
 * of every screen in the portal and nothing else. A DOM and a client render are what
 * make the screen's own data path actually execute.
 */
import { createElement, act } from 'react';
import { createRoot } from 'react-dom/client';

/** Mounts one element and flushes effects until the screen stops changing. */
export async function mount(element) {
  const container = globalThis.document.getElementById('root');
  const root = createRoot(container);
  await act(async () => {
    root.render(element);
  });
  await settle();
  return {
    container,
    unmount: async () => {
      await act(async () => root.unmount());
    },
  };
}

/**
 * Lets pending promises and effects run to completion.
 *
 * A poll resolves in a microtask and schedules a state update, which schedules another
 * effect. Two turns of the loop is the point at which a screen backed by a
 * fixture-answered fetch has stopped moving; the timer-driven refetch then repeats the
 * same answer, so waiting longer changes nothing.
 */
export async function settle(turns = 3) {
  for (let turn = 0; turn < turns; turn += 1) {
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });
  }
}

/**
 * Lets real time pass, so the screen's own one-second poll actually fires.
 *
 * `settle` only drains the microtask queue; the refresh in `useObserved` is scheduled on
 * a `setInterval`, so a scenario about what happens when the service goes away has to
 * wait for the next poll rather than for the next tick. Waiting really is the point
 * here: a harness that reached in and called `refresh()` would be testing its own call,
 * not the screen's cadence.
 */
export async function advance(milliseconds) {
  await act(async () => {
    await new Promise((resolve) => setTimeout(resolve, milliseconds));
  });
  await settle();
}

export function element(type, props, ...children) {
  return createElement(type, props, ...children);
}

/** All rendered text, whitespace-collapsed, as an operator would read it. */
export function renderedText(container = globalThis.document.body) {
  return container.textContent.replace(/\s+/g, ' ').trim();
}

/** Every element whose own text matches, deepest first, so a leaf wins over its panel. */
export function findAll(predicate, container = globalThis.document.body) {
  const found = [];
  for (const node of container.querySelectorAll('*')) {
    if (predicate(node.textContent ?? '', node)) found.push(node);
  }
  return found.reverse();
}

export function findByText(needle, container = globalThis.document.body) {
  return findAll((text) => text.includes(needle), container)[0];
}

/** The nearest ancestor that is a control, so clicking a label presses its button. */
export function pressableAncestor(node) {
  let current = node;
  while (current !== null && current !== undefined) {
    if (current.getAttribute?.('role') === 'button' || current.tagName === 'BUTTON') return current;
    current = current.parentElement;
  }
  return undefined;
}

export async function press(node) {
  const target = pressableAncestor(node);
  if (target === undefined) throw new Error('Nothing pressable was found at that node.');
  await act(async () => {
    target.dispatchEvent(new globalThis.window.MouseEvent('click', { bubbles: true }));
  });
  await settle();
  return target;
}

/**
 * Presses every distinct control whose label matches, once each.
 *
 * For a screen with one disclosure per row, pressing them by hand means finding each row
 * first — and a predicate that has to identify a row is easy to get subtly wrong. Matching
 * the control's own label and de-duplicating by the element actually pressed removes that
 * whole class of mistake. Returns how many were pressed, so a scenario can assert it
 * opened what it expected to.
 */
export async function pressAll(startsWith, container = globalThis.document.body) {
  const targets = new Set();
  for (const node of findAll((text) => text.trim().startsWith(startsWith), container)) {
    const target = pressableAncestor(node);
    if (target !== undefined) targets.add(target);
  }
  for (const target of targets) {
    await act(async () => {
      target.dispatchEvent(new globalThis.window.MouseEvent('click', { bubbles: true }));
    });
    await settle();
  }
  return targets.size;
}

/** Types into a field the way a keyboard does: React's own change event, not a value poke. */
export async function typeInto(node, value) {
  await act(async () => {
    const setter = Object.getOwnPropertyDescriptor(
      node.tagName === 'TEXTAREA'
        ? globalThis.window.HTMLTextAreaElement.prototype
        : globalThis.window.HTMLInputElement.prototype,
      'value',
    ).set;
    setter.call(node, value);
    node.dispatchEvent(new globalThis.window.Event('input', { bubbles: true }));
  });
  await settle();
}
