# Portal render harness

Mounts the operator portal's own screen modules in a DOM, answers their fetches from
responses captured from a real service, drives them, and reads back what an operator
would see.

```bash
npm run render:portal                                     # the gate
node apps/operator-portal/harness/run.mjs --list          # the scenarios
node apps/operator-portal/harness/run.mjs --scenario control-room-live
```

It needs `artifacts/contracts/` to exist. That directory is git-ignored and written by
`PortalContractFixtureTests`, so run `dotnet test Cinerion.slnx -c Release` first. In
`scripts/verify.sh` this is why the verification step follows the .NET step.

## What is real, and what is not

Real: the screen module, `AppShell`, `SessionGate`, `SessionProvider`, `useObserved`,
`apiFetch`, `contracts.ts`, every component and every formatter. None of it is modified
and none of it is mocked at the hook boundary — mocking there would test the mock.

Stood in for, each because it is a *host* rather than a subject, each with its reason in
`loader.mjs`: `expo-router` (navigation, recorded so it can be asserted on),
`expo-auth-session` (the OIDC browser redirect), `react-native-safe-area-context` (device
insets), and the remaining `expo-*` native shims.

**Authentication is not tested here and is not claimed to be.** The access token is
unsigned; the portal never verifies one anyway, and Control Core revalidates signature,
issuer, audience, expiry and scope on every request. What the claims decide is which cell
the interface asks about and whom it names — which is what these scenarios are about.

## Adding a screen

1. Add a file under `screens/` exporting `scenarios`. Each scenario declares `id`,
   `screen` (an identifier `screens.json` contains), `route`, `claims`, `routes()` and an
   async `run(context)` returning its `Checks`.
2. Import it in `run.mjs` and add it to `allScenarios`.
3. Derive every expectation from the captured response rather than writing the value out,
   so a recapture does not turn the scenario into an assertion about a constant.
4. Declare every route the screen requests. An undeclared one is **refused**, not
   answered — a screen asking for the wrong thing must not pass.
5. Then attack it: revert the control the scenario exists for and confirm it fails, by
   name. Twice in this repository that has shown the test was weak rather than the code.

To announce a controlled verification case, add `verificationCase` to the scenario, bind
it in `traceability/verification-map.json`, and say in the note what is exercised and what
is not. The gate refuses either half alone.
