/**
 * The identity a screen is rendered for.
 *
 * An unsigned token, and deliberately so. The portal never verifies one — `readTokenClaims`
 * says as much in its own comment, and Control Core revalidates signature, issuer,
 * audience, expiry and scope on every request. What the claims decide here is only what
 * the interface asks about and whom it names, which is exactly what this harness is
 * testing. Nothing about authentication or authorisation is established by rendering a
 * screen, and the harness never implies otherwise.
 */
export function harnessAccessToken(claims) {
  const encode = (value) => Buffer.from(JSON.stringify(value), 'utf8').toString('base64url');
  return `${encode({ alg: 'none', typ: 'JWT' })}.${encode(claims)}.`;
}

/** The laboratory identity's shape: project scope, one assigned cell, read roles. */
export function assignedOperator(overrides = {}) {
  return {
    sub: '11111111-2222-4333-8444-555555555555',
    sid: '66666666-7777-4888-8999-aaaaaaaaaaaa',
    preferred_username: 'ch1-portal-demo',
    ch1_project: '00000000-0000-4000-8000-000000000101',
    ch1_cell: ['00000000-0000-4000-8000-000000000103'],
    roles: ['Viewer', 'Auditor', 'Engineer', 'Inspector'],
    auth_time: 1_770_000_000,
    exp: 1_770_003_600,
    ...overrides,
  };
}
