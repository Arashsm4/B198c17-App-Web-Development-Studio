// Freezes a rendered scenario into a plain HTML file you can open in any browser.
//
// Why bother: jsdom builds the DOM but never lays anything out, so every width in the
// render harness is zero and no flexbox fight is ever lost where anyone can see it. A
// real browser opening this file does the layout jsdom skipped, which is how you catch a
// title getting squeezed into a vertical word search.
//
// react-native-web adds its styles with insertRule(), which never shows up in a <style>
// tag's text. So we read the rules back out of the CSS object model ourselves, otherwise
// the snapshot would be the right DOM wearing no clothes.
//
//   CINERION_RENDER_SNAPSHOT_DIR=artifacts/render-snapshots node apps/operator-portal/harness/run.mjs --scenario <id>

import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

export async function writeSnapshot(directory, scenario) {
  const { document } = globalThis;
  const rules = [];
  for (const sheet of Array.from(document.styleSheets)) {
    let list;
    try {
      list = sheet.cssRules;
    } catch {
      continue; // a sheet we can't read is a sheet we can't copy; move along
    }
    for (const rule of Array.from(list)) rules.push(rule.cssText);
  }

  // Scripts are dropped on purpose. This is a photograph, not a second copy of the app.
  const body = document.body.innerHTML.replace(/<script[\s\S]*?<\/script>/gi, '');
  const html = [
    '<!doctype html>',
    '<html lang="en"><head><meta charset="utf-8">',
    `<title>${scenario.id}</title>`,
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    // The same reset Expo's web shell ships, so the root fills the window like it does live.
    '<style>html,body,#root{height:100%;margin:0}body{overflow:auto;background:#06111d}</style>',
    `<style>${rules.join('\n')}</style>`,
    '</head><body>',
    body,
    '</body></html>',
  ].join('\n');

  await mkdir(directory, { recursive: true });
  await writeFile(resolve(directory, `${scenario.id}.html`), html, 'utf8');
}
