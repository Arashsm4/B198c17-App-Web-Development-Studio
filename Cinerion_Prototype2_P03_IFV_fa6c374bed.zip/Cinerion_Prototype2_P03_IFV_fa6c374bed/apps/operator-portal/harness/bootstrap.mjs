/**
 * Puts the portal's build-time substitutions in place, then hands back a loader.
 *
 * Order matters here and is the reason this is its own file. `jsdom` and everything
 * else the harness itself needs is loaded *before* the module hooks are registered, so
 * the hooks only ever see the portal's own graph. Then the two substitutions Metro
 * makes at build time are made here: `react-native` resolves to `react-native-web`,
 * and `@/` resolves into `src/`.
 */
import { register, createRequire } from 'node:module';

const require = createRequire(import.meta.url);

/**
 * Points CommonJS `require('react-native')` at `react-native-web`.
 *
 * The ESM hooks below cover every `import`, but `react-native-safe-area-context` is
 * CommonJS and reaches for `react-native` with a bare `require`, which those hooks do
 * not intercept. Seeding the module cache is the same substitution by the other route:
 * the first `require('react-native')` finds `react-native-web` already loaded under
 * that name. Without it the real React Native package is loaded and fails at its first
 * line, which is Flow syntax Node cannot parse.
 */
function substituteReactNative() {
  const reactNativeWeb = require('react-native-web');
  const reactNativePath = require.resolve('react-native');
  require.cache[reactNativePath] = {
    id: reactNativePath,
    filename: reactNativePath,
    path: reactNativePath,
    loaded: true,
    exports: reactNativeWeb,
    children: [],
    paths: [],
  };
}

export function installModuleResolution() {
  substituteReactNative();
  register('./loader.mjs', import.meta.url);
}
