# Cinerion installer for Windows. One command from an unzipped folder to a running lab.
#
#   Double-click install.cmd, or run:
#     powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1
#
#   -InstallPrerequisites   install missing Git / Node.js / Docker Desktop with winget
#   -Yes                    don't ask, just say yes (unattended installs)
#   -NoBrowser              don't open the portal at the end
#   -CheckOnly              check the machine and stop; change nothing
#
# What it does, in order: checks the tools, starts Docker if it's asleep, makes sure the
# ports are free, writes local secrets (topping up, never overwriting), builds and starts the
# whole lab, runs the lab's own health check, then tells you where to sign in. Safe to run
# again: every step is idempotent, so re-running is also how you start the lab next time.
#
# It needs the internet exactly once, to pull images and packages on the first install.
# After that everything runs offline. No AI service is involved anywhere.

param(
    [switch]$InstallPrerequisites,
    [switch]$Yes,
    [switch]$NoBrowser,
    [switch]$CheckOnly
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
Set-Location $Root

$Log = Join-Path $Root 'install.log'
try { Start-Transcript -Path $Log -Append | Out-Null } catch { }

function Say([string]$Text) { Write-Host $Text }
function Step([string]$Text) { Write-Host ''; Write-Host "== $Text" -ForegroundColor Cyan }
function Good([string]$Text) { Write-Host "   ok    $Text" -ForegroundColor Green }
function Warn([string]$Text) { Write-Host "   warn  $Text" -ForegroundColor Yellow }
function Bad([string]$Text)  { Write-Host "   FAIL  $Text" -ForegroundColor Red }

function Ask([string]$Question) {
    if ($Yes) { return $true }
    $answer = Read-Host "$Question [y/N]"
    return ($answer -match '^(y|yes)$')
}

function Stop-Install([string]$Why) {
    Write-Host ''
    Bad $Why
    Write-Host "   The full log is in $Log"
    try { Stop-Transcript | Out-Null } catch { }
    exit 1
}

# New installs change PATH in the registry, not in this window. Read it back in.
function Update-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Test-Command([string]$Name) {
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

# The lab scripts are POSIX sh. Git for Windows ships sh, curl and openssl together.
#
# Found by walking up from wherever git.exe really is, because Git doesn't always live in
# "Program Files\Git" - the first machine this ran on had it in "Program Files\Git\Gitd",
# and a fixed list of paths declared a perfectly good Git "missing". The bash.exe in
# System32 is WSL's, a different Linux world, and is deliberately never used.
function Find-Sh {
    $roots = @()
    $git = Get-Command git -ErrorAction SilentlyContinue
    if ($git) {
        $dir = Split-Path $git.Source
        for ($i = 0; $i -lt 3 -and $dir; $i++) { $roots += $dir; $dir = Split-Path $dir }
    }
    $roots += (Join-Path $env:ProgramFiles 'Git'), (Join-Path $env:LOCALAPPDATA 'Programs\Git')
    if (${env:ProgramFiles(x86)}) { $roots += (Join-Path ${env:ProgramFiles(x86)} 'Git') }
    foreach ($root in $roots) {
        foreach ($leaf in 'bin\sh.exe', 'usr\bin\sh.exe') {
            $candidate = Join-Path $root $leaf
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $onPath = Get-Command sh -ErrorAction SilentlyContinue
    if ($onPath -and $onPath.Source -notmatch '\\System32\\') { return $onPath.Source }
    return $null
}

function Get-NodeVersion {
    if (-not (Test-Command node)) { return $null }
    try { return [version]((& node --version).TrimStart('v')) } catch { return $null }
}

function Test-DockerDaemon {
    if (-not (Test-Command docker)) { return $false }
    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    & docker info --format '{{.ServerVersion}}' 2>$null | Out-Null
    $ok = ($LASTEXITCODE -eq 0)
    $ErrorActionPreference = $previous
    return $ok
}

# Runs one of the lab's sh scripts so its output lands in install.log as well as on screen.
# Windows PowerShell 5.1 leaves a native program's output out of the transcript unless it goes
# through the pipeline, and 2>&1 turns every stderr line (docker writes progress there) into
# an error record - which 'Stop' would treat as fatal. So: 'Continue' for the duration, each
# record turned back into plain text, and the exit code read straight from the process.
function Invoke-Sh([string]$Script) {
    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    & $script:sh (Join-Path $Root $Script) 2>&1 | ForEach-Object {
        if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { "$_" }
    } | Out-Host
    $code = $LASTEXITCODE
    $ErrorActionPreference = $previous
    return $code
}

function Install-WithWinget([string]$Id, [string]$Label) {
    if (-not (Test-Command winget)) {
        Stop-Install "winget is not available, so $Label can't be installed automatically. Install it by hand (see INSTALL.md) and run this again."
    }
    Say "   installing $Label with winget..."
    & winget install --id $Id --exact --silent --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) { Stop-Install "winget could not install $Label (exit $LASTEXITCODE)." }
    Update-Path
}

Write-Host ''
Write-Host 'Cinerion - Prototype 2 lab installer' -ForegroundColor White
Write-Host "Folder: $Root"

# --- 1. Tools ------------------------------------------------------------------------------
Step '1/6  Checking the tools this needs'

$missing = @()
$sh = Find-Sh
if ($sh) { Good "Git for Windows (sh): $sh" } else { Warn 'Git for Windows is missing (it provides sh, curl and openssl)'; $missing += 'git' }

$node = Get-NodeVersion
if ($node -and $node -ge [version]'22.13') { Good "Node.js $node" }
elseif ($node) { Warn "Node.js $node is too old; 22.13 or newer is needed"; $missing += 'node' }
else { Warn 'Node.js is missing'; $missing += 'node' }

if (Test-Command docker) {
    $previous = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    & docker compose version 2>$null | Out-Null
    $composeOk = ($LASTEXITCODE -eq 0)
    $ErrorActionPreference = $previous
    if ($composeOk) { Good 'Docker with Compose v2' } else { Warn 'Docker is here but Compose v2 is not'; $missing += 'docker' }
} else { Warn 'Docker Desktop is missing'; $missing += 'docker' }

if ($missing.Count -gt 0) {
    if ($CheckOnly) { Stop-Install "Missing: $($missing -join ', '). Run again with -InstallPrerequisites, or see INSTALL.md." }
    if (-not $InstallPrerequisites -and -not (Ask "Install the missing tools ($($missing -join ', ')) with winget now?")) {
        Stop-Install "Missing: $($missing -join ', '). Install them (see INSTALL.md), or run again with -InstallPrerequisites."
    }
    if ($missing -contains 'git')    { Install-WithWinget 'Git.Git' 'Git for Windows' }
    if ($missing -contains 'node')   { Install-WithWinget 'OpenJS.NodeJS.LTS' 'Node.js LTS' }
    if ($missing -contains 'docker') {
        Install-WithWinget 'Docker.DockerDesktop' 'Docker Desktop'
        Warn 'Docker Desktop was just installed. It usually wants a sign-out or restart and one'
        Warn 'first launch to finish setting up WSL 2. Do that, then run this installer again.'
        Stop-Install 'Stopping here until Docker Desktop has finished its first start.'
    }
    $sh = Find-Sh
    if (-not $sh) { Stop-Install 'Git was installed but sh.exe still is not found. Open a new window and run this again.' }
}

# --- 2. Docker awake? ----------------------------------------------------------------------
Step '2/6  Making sure Docker is running'
if (-not (Test-DockerDaemon)) {
    $desktop = Join-Path $env:ProgramFiles 'Docker\Docker\Docker Desktop.exe'
    if ($CheckOnly) { Stop-Install 'Docker is installed but not running. Start Docker Desktop.' }
    if (Test-Path $desktop) {
        Say '   Docker is asleep; starting Docker Desktop (this can take a minute or two)...'
        Start-Process $desktop | Out-Null
        $deadline = (Get-Date).AddMinutes(4)
        while (-not (Test-DockerDaemon)) {
            if ((Get-Date) -gt $deadline) { Stop-Install 'Docker Desktop did not come up within 4 minutes. Start it by hand, wait for "Engine running", and run this again.' }
            Start-Sleep -Seconds 5
        }
    } else {
        Stop-Install 'The Docker engine is not reachable and Docker Desktop was not found. Start Docker and run this again.'
    }
}
Good 'Docker engine is running'

# --- 3. Ports -----------------------------------------------------------------------------
# A known Windows trap: a leftover wslrelay process can sit on a port with no container
# behind it, and the lab then fails with "ports are not available".
Step '3/6  Checking the ports the lab uses (5080, 8081, 8180, 5085)'
$ours = @()
$previous = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
$published = & docker ps --format '{{.Names}} {{.Ports}}' 2>$null
$ErrorActionPreference = $previous
foreach ($port in 5080, 8081, 8180, 5085) {
    $listener = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $listener) { Good "port $port is free"; continue }
    $byCinerion = $published | Where-Object { $_ -match '^cinerion-' -and $_ -match ":$port->" }
    if ($byCinerion) { Good "port $port is already the lab's own"; continue }
    $owner = Get-Process -Id $listener.OwningProcess -ErrorAction SilentlyContinue
    $ownerName = if ($owner) { $owner.ProcessName } else { 'unknown' }
    if ($ownerName -eq 'wslrelay' -and (Ask "Port $port is held by a stale wslrelay (pid $($listener.OwningProcess)) with no container behind it. Stop it?")) {
        Stop-Process -Id $listener.OwningProcess -Force
        Good "stopped the stale wslrelay on port $port"
        continue
    }
    Stop-Install "Port $port is in use by $ownerName (pid $($listener.OwningProcess)). Free it and run this again."
}

if ($CheckOnly) {
    Write-Host ''
    Good 'This machine is ready. Run install.cmd (without -CheckOnly) to install.'
    try { Stop-Transcript | Out-Null } catch { }
    exit 0
}

# --- 4. Secrets ---------------------------------------------------------------------------
Step '4/6  Local secrets (generated here, never leave this machine)'
# The upgrade trap. A newer version unzipped into a NEW folder has no secrets file, but the
# lab's data volumes from the old folder are still in Docker and were created with the OLD
# secrets. Generating fresh ones here would lock the database and the identity provider out
# of their own data. So if data exists and secrets don't, stop and say what to do.
$project = if ($env:COMPOSE_PROJECT_NAME) { $env:COMPOSE_PROJECT_NAME } else { 'cinerion' }
$secretsFile = Join-Path $Root 'infrastructure\.env.local'
if (-not (Test-Path $secretsFile)) {
    $previous = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $existing = & docker volume ls --format '{{.Name}}' 2>$null | Where-Object { $_ -eq "${project}_cinerion-postgres" -or $_ -eq "${project}_cinerion-identity-db" }
    $ErrorActionPreference = $previous
    if ($existing) {
        Bad 'This machine already has Cinerion lab data, but this folder has no secrets file.'
        Say '   The data was created with the secrets from the folder you installed from before.'
        Say '   Copy infrastructure\.env.local from that folder into this one, then run this again.'
        Say '   (To throw the old data away instead, see INSTALL.md section 4, "Starting over".)'
        Stop-Install 'Stopped before changing anything, so nothing is locked out.'
    }
}
& (Join-Path $Root 'scripts\bootstrap-local.ps1')

# --- 5. The lab ---------------------------------------------------------------------------
Step '5/6  Building and starting the lab (first time: 10-20 minutes, later: about 1)'
$env:MSYS_NO_PATHCONV = '1'
$code = Invoke-Sh 'scripts/lab-up.sh'
if ($code -ne 0) { Stop-Install "Starting the lab failed (exit $code). See the messages above and INSTALL.md > Troubleshooting." }

# --- 6. Is it really up? ------------------------------------------------------------------
Step '6/6  Checking the running lab'
$code = Invoke-Sh 'scripts/check-lab.sh'
if ($code -ne 0) { Stop-Install 'The lab started but its health check failed. See the FAIL lines above.' }

Write-Host ''
Write-Host 'Cinerion is running.' -ForegroundColor Green
Write-Host ''
Write-Host '  Portal         http://localhost:8081'
Write-Host '  Sign in as     ch1-portal-demo      (everyday roles)'
Write-Host '             or  ch1-portal-security  (cybersecurity roles)'
Write-Host '  Password       CINERION_PORTAL_DEMO_PASSWORD in infrastructure\.env.local'
Write-Host '                 (show it:  Select-String CINERION_PORTAL_DEMO_PASSWORD infrastructure\.env.local)'
Write-Host ''
Write-Host '  API health     http://localhost:5080/api/v1/system/health'
Write-Host '  Identity       http://localhost:8180/realms/cinerion'
Write-Host '  Stop the lab   npm run lab:down        (your data is kept)'
Write-Host '  Start again    run install.cmd again'
Write-Host ''
Write-Host '  Everything is simulated. No real machine is connected or can be driven from here.'

if (-not $NoBrowser) { Start-Process 'http://localhost:8081' | Out-Null }
try { Stop-Transcript | Out-Null } catch { }
exit 0
