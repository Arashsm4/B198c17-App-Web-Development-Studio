# Cinerion security policy

Do not report suspected vulnerabilities in public issues, demonstrations, or
social-media material. Preserve logs and evidence without copying reusable
tokens, private keys, PINs, document passwords, or production configuration.

For this private prototype, report findings directly to IR with:

- affected component and controlled identifier;
- reproducible steps using non-sensitive test data;
- observed and expected behaviour;
- credible impact and preconditions;
- suggested containment, if known.

The project targets the highest practical defence-in-depth assurance. It does
not claim literal or permanent “100% security.” Production release requires no
known unresolved critical vulnerability in the tested scope, signed artifacts,
an SBOM, dependency and secret scans, verified recovery, and independent review
of command, identity, cryptography, firmware, PLC, and migration changes.

Never use the development identity mode, simulator credential verifier, or test
keys on a real machine or production network.

