@echo off
rem Double-click me. Runs install.ps1 with the execution policy relaxed for this one run only,
rem so Windows doesn't block a script that arrived inside a zip. Extra options pass through,
rem for example:  install.cmd -InstallPrerequisites -Yes

rem Opening the zip in Explorer and double-clicking this file from there extracts ONLY this
rem file into a temp folder, so the rest of the project isn't next to it. Say so plainly.
if not exist "%~dp0install.ps1" goto :not_extracted
if not exist "%~dp0scripts\lab-up.sh" goto :not_extracted

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
set RESULT=%ERRORLEVEL%
rem Keep the window open so the result can be read, unless nobody is watching (-Yes).
echo %* | findstr /i /c:"-Yes" >nul || pause
exit /b %RESULT%

:not_extracted
echo.
echo  This was started from inside the zip, so the rest of Cinerion isn't here.
echo  Extract the whole archive first: right-click the zip, choose "Extract All...",
echo  then double-click install.cmd in the extracted folder.
echo.
pause
exit /b 1
