// The stand-in controller's guard state and prepare logic. Not the real PLC, just a faithful
// understudy.

using System.Globalization;

namespace Cinerion.PlcGuard;

/// <summary>
/// The controller state this stand-in holds, and the prepare stage of
/// <c>FB_CH1_CommandGuard</c> as the controlled SCL writes it.
/// </summary>
/// <remarks>
/// <para>
/// This is a <em>third</em> expression of the same block. <c>plc/s7-1200-g2/01_Blocks/</c>
/// is the controlled source and stays authoritative; <c>plc/host-model/</c> is the C++
/// translation the eleven PLCSIM scenarios execute against; this is what a controlled
/// protocol profile can reach. The state numbers and reason codes below are the SCL's, not
/// a re-numbering, and <c>scripts/check-plc-model.mjs</c> reads all three so a code that
/// exists in one and not the others fails the build.
/// </para>
/// <para>
/// It lives in its own project because <em>two</em> stand-ins reach the same guard: the OPC
/// UA controller of CH1-COM-IF-0007 and the Modbus map of CH1-COM-IF-0008. Duplicating the
/// translation would create a fourth expression that could drift from the SCL silently,
/// which is the failure the reconciliation gate exists to prevent.
/// </para>
/// <para>
/// <b>Two of the guard's seven prepare checks are deliberately not evaluated here, and the
/// method says so in its answer rather than passing them silently.</b>
/// <c>EXPECTED_STATE_MISMATCH</c> (206) compares the command's expected state hash against
/// <c>CurrentStateHash32</c>, which the CPU computes from its own material state, and
/// <c>PRELIMINARY_PERMISSIVE_INVALID</c> (207) reads <c>UDT_CH1_Permissives</c> from wired
/// inputs. This stand-in has neither material state nor I/O, so it can decide neither. A
/// stand-in that answered "matched" for a hash it never computed, or "all permissives
/// valid" for contacts it cannot see, would be inventing the two answers that decide
/// whether equipment may move. The <c>DeferredChecks</c> output names both, on every reply,
/// accepted or refused.
/// </para>
/// <para>
/// <b>There is no commit and no execute path on either interface at all</b>, which is the
/// point rather than an omission. CH1-AUT-FDS-0001 puts the commit behind a cryptographic
/// credential proof and a physical button edge observed at the cell, and CH1-COM-IF-0022
/// forbids raw writes from a user interface. So <see cref="Prepare"/> advances the guard to
/// <c>Prepared</c> at most, and nothing an OPC UA client or a Modbus master can say will
/// produce an execute permit.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0007, CH1-COM-IF-0022, CH1-AUT-FDS-0001, CH1-CMD-FR-0001, CH1-SAF-FR-0001</requirements>
public sealed class Ch1PlcRuntime(TimeProvider timeProvider)
{
    /// <summary>FB_CH1_CommandGuard states. The values are the SCL's.</summary>
    public static class GuardState
    {
        public const ushort Idle = 0;
        public const ushort Prepared = 10;
        public const ushort Committed = 20;
        public const ushort Executing = 30;
        public const ushort Complete = 40;
        public const ushort FaultLatched = 90;
    }

    /// <summary>Reason codes, exactly as the SCL emits them.</summary>
    public static class Reason
    {
        public const ushort None = 0;
        public const ushort Prepared = 10;
        public const ushort ControllerRestarted = 110;
        public const ushort PrepareExpired = 120;
        public const ushort StateInvalid = 201;
        public const ushort SchemaUnsupported = 202;
        public const ushort ReplayOrDuplicate = 203;
        public const ushort Expired = 204;
        public const ushort RevisionMismatch = 205;
    }

    /// <summary>
    /// Refusals that belong to a protocol profile rather than to the guard.
    /// </summary>
    /// <remarks>
    /// The SCL has no code for "unknown command type" and should not: in
    /// <c>UDT_CH1_Command</c> the command type is an enumerated field that cannot hold an
    /// invalid value, so the case exists only at a text boundary the CPU does not have.
    /// Borrowing one of the guard's numbers for it would make a profile refusal
    /// indistinguishable from a controlled one — over Modbus, where only the number crosses
    /// the wire, that would be the whole message. Profile codes are therefore >= 1000, a
    /// range the SCL never uses, and <c>scripts/check-plc-model.mjs</c> holds them there.
    /// </remarks>
    public static class ProfileReason
    {
        public const ushort CommandTypeNotInCapabilityModel = 1001;
    }

    /// <summary>
    /// The stable names EdgeLink reports. A number is what the CPU emits; a name is what an
    /// operator reads, and the two are kept beside each other so neither has to be guessed.
    /// </summary>
    private static readonly Dictionary<ushort, string> ReasonNames =
        new()
        {
            [Reason.None] = "NONE",
            [Reason.Prepared] = "PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION",
            [Reason.ControllerRestarted] = "CONTROLLER_RESTARTED",
            [Reason.PrepareExpired] = "PREPARE_EXPIRED",
            [Reason.StateInvalid] = "STATE_INVALID",
            [Reason.SchemaUnsupported] = "SCHEMA_UNSUPPORTED",
            [Reason.ReplayOrDuplicate] = "REPLAY_OR_DUPLICATE",
            [Reason.Expired] = "EXPIRED",
            [Reason.RevisionMismatch] = "REVISION_MISMATCH",
            [ProfileReason.CommandTypeNotInCapabilityModel] = "COMMAND_TYPE_NOT_IN_CAPABILITY_MODEL",
        };

    /// <summary>
    /// The two prepare checks the CPU performs against inputs this stand-in does not have.
    /// Reported on every reply so a reader never has to assume they were made.
    /// </summary>
    public static readonly string[] DeferredChecks =
    [
        "206 EXPECTED_STATE_MISMATCH — decided by the CPU against CurrentStateHash32, which is computed from material state this stand-in has none of",
        "207 PRELIMINARY_PERMISSIVE_INVALID — decided by the CPU against UDT_CH1_Permissives, read from wired inputs this stand-in has none of",
    ];

    public const string SchemaVersion = "1.0.0";

    /// <summary>What the ESP32-S3 firmware and the MQTT device end also report.</summary>
    public const string ConfigurationRevision = "CFG-REFAB-P01-R01";

    public const string FirmwareVersion = "S7-1200-G2-STANDIN/0.1.0-prototype.2";

    public const string DeviceType = "S7-1200-G2-CPU1212C-STANDIN";

    public const string SecurityProfile = "OPCUA-SIGNANDENCRYPT-BASIC256SHA256-CERTIFICATE-TRUSTLIST";

    public static readonly string[] SupportedCommands =
    [
        "RUN_TENSION_CALIBRATION",
        "RUN_DIMENSIONAL_TEST",
    ];

    public sealed record Channel(string ChannelId, string Unit, string Description, double Minimum, double Maximum);

    public static readonly Channel[] TelemetryChannels =
    [
        new("temperature", "degC", "Process temperature at the cell", 15, 45),
        new("position", "mm", "Actuator position along the axis", 0, 250),
        new("vibration_rms", "m/s2", "Vibration, RMS over the sample window", 0, 12),
    ];

    private readonly Lock _gate = new();
    private readonly Guid _bootId = Guid.NewGuid();
    private ushort _state = GuardState.Idle;
    private long _lastSequenceNumber;
    private Guid _preparedCommandId;
    private DateTimeOffset _preparedExpiresAt;
    private long _telemetrySequence;

    public string DeviceId { get; init; } = "CH1-DEV-CELL-0001";

    /// <summary>
    /// The scope this controller serves. CH1-COM-ICD-0001 requires project, cell and asset
    /// scope on every controlled message, and a controller is no exception: a gateway that
    /// reached the wrong cell should learn so from the cell rather than from an operator.
    /// The defaults are the seeded laboratory identifiers used throughout this repository.
    /// </summary>
    public Guid ProjectId { get; init; } = Guid.Parse("00000000-0000-4000-8000-000000000101");

    public Guid CellId { get; init; } = Guid.Parse("00000000-0000-4000-8000-000000000103");

    public Guid AssetId { get; init; } = Guid.Parse("00000000-0000-4000-8000-000000000104");

    public Guid BootId => _bootId;

    public ushort State
    {
        get
        {
            lock (_gate)
            {
                Housekeep();
                return _state;
            }
        }
    }

    public long LastSequenceNumber
    {
        get
        {
            lock (_gate)
            {
                return _lastSequenceNumber;
            }
        }
    }

    public sealed record PrepareResult(
        bool Accepted,
        ushort State,
        ushort ReasonCode,
        string ReasonName,
        string ControllerState);

    /// <summary>
    /// One scan of the guard's prepare branch, in the SCL's own order of evaluation.
    /// </summary>
    public PrepareResult Prepare(
        string schemaVersion,
        Guid commandId,
        long sequenceNumber,
        string configurationRevision,
        DateTimeOffset expiresAt,
        string commandType)
    {
        lock (_gate)
        {
            // The SCL runs these at the top of every scan, before the prepare edge is
            // evaluated: a controller restart or a lapsed preparation returns the guard to
            // Idle on its own. Without them a stand-in left in Prepared by an earlier run
            // would refuse everything afterwards for a reason that is not the real one.
            Housekeep();

            if (_state != GuardState.Idle)
            {
                return Refuse(Reason.StateInvalid);
            }

            if (!string.Equals(schemaVersion, SchemaVersion, StringComparison.Ordinal))
            {
                return Refuse(Reason.SchemaUnsupported);
            }

            if (sequenceNumber <= _lastSequenceNumber)
            {
                return Refuse(Reason.ReplayOrDuplicate);
            }

            if (expiresAt <= timeProvider.GetUtcNow())
            {
                return Refuse(Reason.Expired);
            }

            if (!string.Equals(configurationRevision, ConfigurationRevision, StringComparison.Ordinal))
            {
                return Refuse(Reason.RevisionMismatch);
            }

            // Not one of the guard's numbered refusals: the SCL takes a command type from
            // UDT_CH1_Command, which is an enumerated semantic operation rather than free
            // text. A register address arriving as a command type is refused here for the
            // same reason CH1-CMD-FR-0001 gives — a register write is not a semantic
            // command, and a controller that forwarded one would be a controller that
            // could be told to poke an address.
            if (!SupportedCommands.Contains(commandType, StringComparer.Ordinal))
            {
                return new PrepareResult(
                    false,
                    _state,
                    ProfileReason.CommandTypeNotInCapabilityModel,
                    ReasonNames[ProfileReason.CommandTypeNotInCapabilityModel],
                    "Idle");
            }

            _preparedCommandId = commandId;
            _preparedExpiresAt = expiresAt;
            _lastSequenceNumber = sequenceNumber;
            _state = GuardState.Prepared;

            // AwaitingCredential, never Executing and never Complete. The controller has
            // accepted an intent; the credential proof and the button edge that would
            // authorise motion happen at the cell and cannot arrive over this link.
            return new PrepareResult(
                true,
                _state,
                Reason.Prepared,
                ReasonNames[Reason.Prepared],
                "AwaitingCredential");
        }
    }

    private void Housekeep()
    {
        if (_state == GuardState.Prepared && timeProvider.GetUtcNow() >= _preparedExpiresAt)
        {
            _state = GuardState.Idle;
            _preparedCommandId = Guid.Empty;
        }
    }

    private PrepareResult Refuse(ushort reasonCode) =>
        new(false, _state, reasonCode, ReasonNames[reasonCode], _state == GuardState.Prepared ? "AwaitingCredential" : "Idle");

    /// <summary>
    /// A reading per channel, produced from a bounded deterministic function of the sample
    /// number. It is a stand-in for conditioned I/O and every sample says so: the quality
    /// word is <c>Simulated</c>, never <c>Good</c>, so nothing downstream can mistake this
    /// for an instrument reading.
    /// </summary>
    public IReadOnlyList<(Channel Channel, double Value, string Quality, DateTimeOffset SampledAt, long Sequence)> Sample()
    {
        var sequence = Interlocked.Increment(ref _telemetrySequence);
        var now = timeProvider.GetUtcNow();
        return TelemetryChannels.Select(channel =>
        {
            var span = channel.Maximum - channel.Minimum;
            var value = channel.Minimum + (span * (0.5 + (0.25 * Math.Sin((sequence / 20d) + channel.ChannelId.Length))));
            return (channel, Math.Round(value, 3), "Simulated", now, sequence);
        }).ToArray();
    }

    public string Describe() => string.Create(
        CultureInfo.InvariantCulture,
        $"{DeviceId} {DeviceType} firmware {FirmwareVersion} configuration {ConfigurationRevision} boot {_bootId:N}");
}
