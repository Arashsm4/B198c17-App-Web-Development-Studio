// The CH1 cell as a simulation, built from the firmware that would run on the board.
//
// WHAT THIS IS. Every decision here comes from the SAME translation units the ESP32-S3 and
// the Arduino node compile: cinerion::io (the conditioned I/O layer), cinerion::cell (the
// command state machine), cinerion::ch1 (the CBOR envelope) and the RS-485 frame codec.
// Nothing is reimplemented for the simulation. What is replaced is the bottom inch — the
// function that reads a pin — and that is deliberately the only thing, because a simulator
// that reimplements the logic is testing itself.
//
// WHAT THIS IS NOT. It is not hardware and never claims to be. There is no board, no
// isolation, no 24 V, nothing is energised and nothing can be: `OutputPlan` is an intent and
// this program prints it. Every reading it produces is synthetic and the CH1 envelopes it
// encodes carry the controller's real, honest time quality — which, with no provisioned time
// server, is Unsynchronised. CH1-MON-FR-0003 requires live, stale, disconnected, simulated,
// maintenance and unknown to stay distinguishable, and a simulator's whole duty is to be
// distinguishable.
//
// WHY IT EXISTS. The firmware was host-TESTED before this and never host-RUN. A test asserts
// what its author thought to assert; running the thing shows what it does. Twelve seconds of
// this exercises the debounce, the stuck detector, the analogue conditioning on all four
// controlled channels, the indicator and buzzer patterns, the watchdog withdrawing the
// actuator enable, the clock's opinion of itself, the node bus in both directions, and a
// prepared command being refused for a reason — none of which needed a board to be true.
//
// Usage: cell-controller-simulator [--seconds N] [--quiet]

#include "cinerion/cell_state_machine.hpp"
#include "cinerion/ch1_envelope.hpp"
#include "cinerion/conditioned_io.hpp"
#include "cinerion/frame_codec.hpp"
#include "cinerion/node_application.hpp"

#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

namespace {

namespace signals = cinerion::io::signals;
using cinerion::io::Circuit;
using cinerion::io::Conditioning;

bool quiet = false;

void say(const std::string& line) {
    if (!quiet) {
        std::printf("%s\n", line.c_str());
    }
}

/// The synthetic bench.
///
/// This is the ONLY part of the simulation that is not the firmware. It stands where the
/// board driver will: it answers "what is on the pin" and "what did the sensor read", and it
/// answers deterministically, so two runs produce the same trace and a difference means
/// something changed in the firmware rather than in the weather.
struct Bench {
    std::uint64_t now_ms{0};

    // Discrete levels, in the electrical sense the conditioning expects: a normally closed
    // loop reads high while it is intact.
    bool start_enable_level{false};
    bool stop_loop_intact{true};
    bool guard_loop_intact{true};
    bool home_level{true};
    bool confirm_level{false};
    bool reset_level{false};

    /// Deterministic, bounded, and plausible for the quantity. Not random: a trace that
    /// differs run to run cannot be compared against the last one.
    [[nodiscard]] double temperature() const {
        return 21.5 + (1.8 * std::sin(static_cast<double>(now_ms) / 4000.0));
    }
    [[nodiscard]] double humidity() const {
        return 44.0 + (6.0 * std::sin(static_cast<double>(now_ms) / 9000.0));
    }
    [[nodiscard]] double position() const {
        // With one deliberate outlier every few seconds, so the median filter has something
        // to reject rather than a clean signal it cannot be seen to act on.
        const bool outlier = (now_ms / 100) % 47 == 0;
        return outlier ? 900.0 : 128.0 + (0.4 * std::sin(static_cast<double>(now_ms) / 1500.0));
    }
    [[nodiscard]] double vibration() const {
        // Symmetric about zero, so an averaging filter would report no vibration at all and
        // the windowed RMS reports its magnitude. That difference is the point of the choice.
        return 3.0 * std::sin(static_cast<double>(now_ms) / 60.0);
    }
};

/// Names a cell condition for the trace.
[[nodiscard]] std::string_view condition_name(const cinerion::cell::State state) {
    switch (state) {
        case cinerion::cell::State::Idle: return "Idle";
        case cinerion::cell::State::AwaitCredential: return "AwaitCredential";
        case cinerion::cell::State::AwaitButton: return "AwaitButton";
        case cinerion::cell::State::Committed: return "Committed";
        case cinerion::cell::State::Executing: return "Executing";
        case cinerion::cell::State::Complete: return "Complete";
        case cinerion::cell::State::FaultLatched: return "FaultLatched";
        case cinerion::cell::State::Recovery: return "Recovery";
        case cinerion::cell::State::Initialising: break;
    }
    return "Initialising";
}

[[nodiscard]] cinerion::io::CellCondition condition_of(const cinerion::cell::State state) {
    switch (state) {
        case cinerion::cell::State::Idle: return cinerion::io::CellCondition::Idle;
        case cinerion::cell::State::AwaitCredential: return cinerion::io::CellCondition::AwaitCredential;
        case cinerion::cell::State::AwaitButton: return cinerion::io::CellCondition::AwaitButton;
        case cinerion::cell::State::Committed: return cinerion::io::CellCondition::Committed;
        case cinerion::cell::State::Executing: return cinerion::io::CellCondition::Executing;
        case cinerion::cell::State::Complete: return cinerion::io::CellCondition::Complete;
        case cinerion::cell::State::FaultLatched: return cinerion::io::CellCondition::FaultLatched;
        case cinerion::cell::State::Recovery: return cinerion::io::CellCondition::Recovery;
        case cinerion::cell::State::Initialising: break;
    }
    return cinerion::io::CellCondition::Initialising;
}

constexpr std::array<std::uint8_t, 16> project_id{
    0, 0, 0, 0, 0, 0, 0, 0x40, 0x80, 0, 0, 0, 0, 0, 0x01, 0x01};
constexpr std::array<std::uint8_t, 16> cell_id{
    0, 0, 0, 0, 0, 0, 0, 0x40, 0x80, 0, 0, 0, 0, 0, 0x01, 0x03};
constexpr std::array<std::uint8_t, 16> asset_id{
    0, 0, 0, 0, 0, 0, 0, 0x40, 0x80, 0, 0, 0, 0, 0, 0x01, 0x04};

}  // namespace

int main(int argc, char** argv) {
    int seconds = 24;
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument{argv[index]};
        if (argument == "--quiet") {
            quiet = true;
        } else if (argument == "--seconds" && index + 1 < argc) {
            seconds = std::atoi(argv[++index]);
        }
    }

    std::printf("Cinerion cell controller — SIMULATION. No hardware is present and nothing is energised.\n");
    std::printf("Built from the firmware translation units; only the pin reads are synthetic.\n\n");

    Bench bench{};

    // The six conditioned discrete inputs, configured exactly as
    // firmware/pinmap/esp32s3-r01.json declares them.
    cinerion::io::DiscreteInput start_enable{{signals::start_enable, Circuit::NormallyOpen, 20, 0}};
    cinerion::io::DiscreteInput stop_request{{signals::stop_request, Circuit::NormallyClosed, 20, 0}};
    cinerion::io::DiscreteInput local_reset{{signals::local_reset, Circuit::NormallyOpen, 30, 10'000}};
    cinerion::io::DiscreteInput confirmation{{signals::confirmation_button, Circuit::NormallyOpen, 30, 5'000}};
    cinerion::io::DiscreteInput guard{{signals::guard_interlock, Circuit::NormallyClosed, 10, 0}};
    cinerion::io::DiscreteInput actuator_home{{signals::actuator_home, Circuit::NormallyOpen, 20, 0}};

    cinerion::io::AnalogueChannel temperature{{
        signals::temperature, "CH1-IO-AI-0001", "degC", Conditioning::RangeRate,
        -40.0, 125.0, 5.0, 1, 5'000}};
    cinerion::io::AnalogueChannel humidity{{
        signals::relative_humidity, "CH1-IO-AI-0002", "%RH", Conditioning::RangeRate,
        0.0, 100.0, 20.0, 1, 5'000}};
    cinerion::io::AnalogueChannel position{{
        signals::position, "CH1-IO-AI-0003", "mm", Conditioning::Median,
        0.0, 4'000.0, 0.0, 5, 1'000}};
    cinerion::io::AnalogueChannel vibration{{
        signals::vibration, "CH1-IO-AI-0004", "m/s2", Conditioning::WindowedRms,
        -160.0, 160.0, 0.0, 16, 500}};

    cinerion::io::OutputWatchdog watchdog{};
    const auto control_task = watchdog.supervise("control", 500, 0);

    cinerion::io::OutputPlanner planner{};
    cinerion::io::TimeSource clock_source{};
    cinerion::cell::StateMachine machine{{1, 2, 3, 4, 1}, 1};
    cinerion::io::NodeApplication node{};

    std::uint32_t node_minimum_sequence = 1;
    std::size_t node_frames_accepted = 0;
    std::size_t node_frames_refused = 0;
    std::size_t telemetry_published = 0;
    std::size_t telemetry_withheld = 0;
    bool clock_disciplined = false;
    bool watchdog_starved = false;

    // What the run is claimed to exercise. Counted as it happens, asserted at the end: a
    // simulation whose scenario silently stopped reaching a state would otherwise keep
    // printing a confident summary about a run that no longer covered anything.
    bool reached_await_button = false;
    bool reached_executing = false;
    bool reached_complete = false;
    bool reached_recovery = false;
    bool completion_acknowledged = false;
    bool second_procedure_executed = false;
    bool recovery_reconciled = false;
    bool lamp_lit_only_in_await_button = true;
    bool actuator_planned_outside_executing = false;
    bool stuck_detected = false;
    bool watchdog_withheld_the_enable = false;

    const auto sample_bench = [&](const std::uint64_t now) {
        start_enable.sample(bench.start_enable_level, now);
        stop_request.sample(bench.stop_loop_intact, now);
        local_reset.sample(bench.reset_level, now);
        confirmation.sample(bench.confirm_level, now);
        guard.sample(bench.guard_loop_intact, now);
        actuator_home.sample(bench.home_level, now);
    };

    const auto local_inputs = [&]() {
        return cinerion::cell::LocalInputs{
            .start_enable = start_enable.asserted(),
            .stop_circuit_healthy = !stop_request.asserted(),
            .guard_healthy = !guard.asserted(),
            .actuator_home = actuator_home.asserted(),
            .confirmation_button = confirmation.asserted(),
            .reset_button = local_reset.asserted(),
            .fault_cause_active = confirmation.stuck() || local_reset.stuck(),
        };
    };

    const std::uint64_t total_ms = static_cast<std::uint64_t>(seconds) * 1000;

    for (std::uint64_t tick = 0; tick <= total_ms; tick += 10) {
        bench.now_ms = tick;

        // ---- The scripted bench. Each step provokes one behaviour the firmware owns. ----

        if (tick == 500) {
            say("[00.5s] BENCH  start-enable key turned on");
            bench.start_enable_level = true;
        }
        if (tick == 1500) {
            say("[01.5s] BENCH  a control-zone time server answers; the clock is disciplined");
            clock_source.disciplined(1'788'609'600'000, tick);
            clock_disciplined = true;
        }
        if (tick == 3000) {
            say("[03.0s] BENCH  guard opened — a permissive drops");
            bench.guard_loop_intact = false;
        }
        if (tick == 4500) {
            say("[04.5s] BENCH  guard closed again");
            bench.guard_loop_intact = true;
        }
        // A whole command, through the guard, to the one state that grants the enable.
        if (tick == 5000) {
            // Bound to the controller the machine was constructed with: cell 1, asset 2,
            // work order 3, part 4, configuration revision 1, boot identity 1. The first
            // attempt used boot identity 99 and was refused as ControllerRestarted — which
            // is the guard doing exactly its job, and worth leaving in the record.
            const cinerion::cell::PrepareRequest request{
                100, 200, 1, 2, 3, 4, 1, 1, 1, tick + 60'000};
            const auto result = machine.prepare(request, local_inputs(), tick);
            say("[05.0s] GATEWAY prepare -> " + std::string(condition_name(machine.state())) +
                " (result " + std::to_string(static_cast<unsigned>(result)) + ")");
        }
        if (tick == 5500) {
            const cinerion::cell::CredentialProof proof{100, 200, 1, true, true, tick + 20'000};
            const auto result = machine.accept_credential(proof, tick);
            say("[05.5s] LOCAL   credential proof -> " + std::string(condition_name(machine.state())) +
                " (result " + std::to_string(static_cast<unsigned>(result)) + ")");
        }
        if (tick == 6000) {
            say("[06.0s] BENCH  the confirmation button is pressed at the cell");
            bench.confirm_level = true;
        }
        if (tick == 6200) {
            const auto result = machine.sample_physical_confirmation(local_inputs(), tick);
            say("[06.2s] LOCAL   button edge -> " + std::string(condition_name(machine.state())) +
                " (result " + std::to_string(static_cast<unsigned>(result)) + ")");
            if (result == cinerion::cell::Result::Accepted) {
                (void)machine.begin_execution();
                say("[06.2s] STATE  execution begun; THE PLAN now grants the actuator enable — "
                    "and there is no actuator, because this is a simulation");
            }
        }
        // The watchdog is starved WHILE the cell is executing, which is the only moment
        // the withdrawal it exists for can be observed. Starving it in Complete — which is
        // what this scenario did first — proves nothing: there is no enable to withdraw.
        if (tick == 7000) {
            say("[07.0s] BENCH  the control task stops checking in, MID-EXECUTION");
            watchdog_starved = true;
        }
        if (tick == 8000) {
            say("[08.0s] BENCH  the control task resumes");
            watchdog_starved = false;
        }
        if (tick == 9000) {
            (void)machine.complete_execution();
            say("[09.0s] STATE  execution complete");
        }
        if (tick == 9500) {
            say("[09.5s] BENCH  the button is released");
            bench.confirm_level = false;
        }
        if (tick == 10000) {
            say("[10.0s] BENCH  the confirmation button is SHORTED and stays pressed");
            bench.confirm_level = true;
        }
        if (tick == 16000) {
            say("[16.0s] BENCH  the short is cleared");
            bench.confirm_level = false;
        }

        // ---- A SECOND procedure, on the same boot. ----
        //
        // Until CH1-AUT-FDS-0001's Complete --acknowledge completion / new order--> Idle
        // transition existed, everything below was unreachable and this simulator said so
        // in its own summary: "NOT SHOWN: a second command" (defect 66). The exit was read
        // out of the controlled diagram rather than invented - the frozen baseline carries
        // it as an SVG, and `npm run cell:map` parses it as a transition table.
        if (tick == 16600) {
            const auto result = machine.acknowledge_completion(
                cinerion::cell::CompletionAcknowledgement{100, 1});
            completion_acknowledged = result == cinerion::cell::Result::Accepted &&
                                      machine.state() == cinerion::cell::State::Idle;
            say("[16.6s] GATEWAY completion acknowledged -> " +
                std::string(condition_name(machine.state())) + " (result " +
                std::to_string(static_cast<unsigned>(result)) + ")");
        }
        if (tick == 17000) {
            // The sequence the first command used, offered again. The acknowledgement
            // returned the cell to Idle; it did not reset the replay bound.
            const cinerion::cell::PrepareRequest replay{100, 200, 1, 2, 3, 4, 1, 1, 1, tick + 60000};
            const auto result = machine.prepare(replay, local_inputs(), tick);
            say("[17.0s] GATEWAY the sequence just executed, offered again -> result " +
                std::to_string(static_cast<unsigned>(result)) + " (SequenceReplay)");
        }
        if (tick == 17400) {
            const cinerion::cell::PrepareRequest request{
                300, 400, 1, 2, 3, 4, 2, 1, 1, tick + 60000};
            const auto result = machine.prepare(request, local_inputs(), tick);
            say("[17.4s] GATEWAY second prepare -> " + std::string(condition_name(machine.state())) +
                " (result " + std::to_string(static_cast<unsigned>(result)) + ")");
        }
        if (tick == 17800) {
            const cinerion::cell::CredentialProof proof{300, 400, 1, true, true, tick + 20000};
            (void)machine.accept_credential(proof, tick);
            say("[17.8s] LOCAL   second credential proof -> " +
                std::string(condition_name(machine.state())));
        }
        if (tick == 18200) {
            say("[18.2s] BENCH  the confirmation button is pressed again");
            bench.confirm_level = true;
        }
        if (tick == 18500) {
            const auto result = machine.sample_physical_confirmation(local_inputs(), tick);
            say("[18.5s] LOCAL   second button edge -> " +
                std::string(condition_name(machine.state())) + " (result " +
                std::to_string(static_cast<unsigned>(result)) + ")");
            if (result == cinerion::cell::Result::Accepted) {
                second_procedure_executed =
                    machine.begin_execution() == cinerion::cell::Result::Accepted;
            }
        }
        if (tick == 18800) {
            say("[18.8s] BENCH  the button is released");
            bench.confirm_level = false;
        }

        // ---- A critical fault, and the controlled recovery out of it. ----
        //
        // CH1-AUT-FDS-0001: Executing --critical fault--> FaultLatched --local reset-->
        // Recovery --recovery accepted--> Idle. The reset edge establishes three of the
        // four things a recovery must verify; the fourth is the work-order state.
        if (tick == 19200) {
            const auto result = machine.latch_fault();
            say("[19.2s] BENCH  a plausibility fault mid-execution -> " +
                std::string(condition_name(machine.state())) + " (result " +
                std::to_string(static_cast<unsigned>(result)) + ")");
        }
        if (tick == 19600) {
            say("[19.6s] BENCH  the local reset button is pressed");
            bench.reset_level = true;
        }
        if (tick == 19900) {
            const auto result = machine.sample_physical_reset(local_inputs());
            say("[19.9s] LOCAL   reset edge -> " + std::string(condition_name(machine.state())) +
                " (result " + std::to_string(static_cast<unsigned>(result)) +
                ") - Recovery, NOT Idle");
        }
        if (tick == 20100) {
            say("[20.1s] BENCH  the reset button is released");
            bench.reset_level = false;
        }
        if (tick == 20400) {
            // Offered against another work order first: a recovery that reconciled
            // nothing would return this cell to Idle bound to a part nobody had checked.
            const cinerion::cell::RecoveryReconciliation wrong{1, 2, 999, 4, 1, 1};
            const auto refused = machine.accept_recovery(wrong, local_inputs());
            say("[20.4s] GATEWAY recovery offered for ANOTHER work order -> result " +
                std::to_string(static_cast<unsigned>(refused)) +
                " (WorkOrderNotReconciled), still " +
                std::string(condition_name(machine.state())));
        }
        if (tick == 20800) {
            const cinerion::cell::RecoveryReconciliation reconciliation{1, 2, 3, 4, 1, 1};
            const auto result = machine.accept_recovery(reconciliation, local_inputs());
            recovery_reconciled = result == cinerion::cell::Result::Accepted &&
                                  machine.state() == cinerion::cell::State::Idle;
            say("[20.8s] GATEWAY work-order state reconciled -> " +
                std::string(condition_name(machine.state())) + " (result " +
                std::to_string(static_cast<unsigned>(result)) + ")");
        }

        // ---- The firmware. ----

        sample_bench(tick);

        // The same retry the entry point performs. Defect 65: Initialising has no exit but
        // initialise(), and asking once at boot leaves a controller that powered up with the
        // key off stuck there forever. The simulator found it by running for twelve seconds.
        if (machine.state() == cinerion::cell::State::Initialising) {
            if (machine.initialise(local_inputs()) == cinerion::cell::Result::Accepted) {
                say("[" + std::to_string(tick / 1000) + "s] STATE  permissives valid; entered Idle");
            }
        }

        machine.tick(tick);
        if (!watchdog_starved) {
            watchdog.check_in(control_task, tick);
        }

        if (tick == 0) {
            const auto result = machine.initialise(local_inputs());
            say("[00.0s] STATE  initialise -> " + std::string(condition_name(machine.state())) +
                " (result " + std::to_string(static_cast<unsigned>(result)) + ")");
        }

        // Analogue conditioning, at each channel's declared sample period.
        const auto source_time = clock_source.report_clock(tick);
        if (tick % 1000 == 0) {
            temperature.sample(bench.temperature(), source_time, tick);
            humidity.sample(bench.humidity(), source_time, tick);
        }
        if (tick % 100 == 0) {
            position.sample(bench.position(), source_time, tick);
        }
        if (tick % 20 == 0) {
            vibration.sample(bench.vibration(), source_time, tick);
        }

        // The node bus, both directions, through the real codec.
        if (tick % 500 == 0) {
            std::array<std::uint8_t, 64> frame{};
            const cinerion::io::NodeInputs node_inputs{
                bench.guard_loop_intact, true, true, true};
            const std::size_t written = node.compose_input_state(frame, node_inputs);
            if (written > 0 &&
                cinerion::io::validate_frame(
                    std::span<const std::uint8_t>(frame.data(), written), node_minimum_sequence)) {
                node_frames_accepted += 1;
                node_minimum_sequence += 1;
            } else {
                node_frames_refused += 1;
            }
        }

        // The output PLAN. Computed, printed, applied to nothing.
        const cinerion::io::Diagnostics diagnostics{
            .watchdog_healthy = watchdog.healthy(tick),
            .discrete_input_stuck = confirmation.stuck() || local_reset.stuck(),
            .permissive_circuit_open = !stop_request.circuit_healthy() || !guard.circuit_healthy(),
            .detail = watchdog.first_overdue(tick),
        };
        const auto plan = planner.plan(condition_of(machine.state()), diagnostics, tick);

        const auto state = machine.state();
        reached_await_button |= state == cinerion::cell::State::AwaitButton;
        reached_executing |= state == cinerion::cell::State::Executing;
        reached_complete |= state == cinerion::cell::State::Complete;
        reached_recovery |= state == cinerion::cell::State::Recovery;
        stuck_detected |= confirmation.stuck();

        // CH1-IO-DO-0001's controlled diagnostic action is "Only AwaitButton state", and
        // CH1-IO-DO-0006's is "Drops on watchdog/fault". Both are asserted CONTINUOUSLY
        // rather than sampled once a second, because a lamp lit for 40 ms in the wrong state
        // is still a lamp inviting a press the guard would refuse.
        if (plan.confirmation_lamp && state != cinerion::cell::State::AwaitButton) {
            lamp_lit_only_in_await_button = false;
        }
        if (plan.actuator_enable && state != cinerion::cell::State::Executing) {
            actuator_planned_outside_executing = true;
        }
        if (state == cinerion::cell::State::Executing && !plan.actuator_enable &&
            !diagnostics.watchdog_healthy) {
            watchdog_withheld_the_enable = true;
        }

        // ---- Trace, once a second, so the run is readable rather than a firehose. ----

        if (tick % 1000 == 0) {
            const auto t = temperature.read(tick);
            const auto p = position.read(tick);
            const auto v = vibration.read(tick);

            char line[512];
            std::snprintf(
                line, sizeof(line),
                "[%04.1fs] %-15s lamp=%d G=%d A=%d R=%d buzzer=%-10s actuator=%d%s\n"
                "         temp=%7.3f %-4s pos=%8.3f %-4s vib=%6.3f %-5s clock=%s",
                static_cast<double>(tick) / 1000.0,
                std::string(condition_name(machine.state())).c_str(),
                plan.confirmation_lamp, plan.green_indicator, plan.amber_indicator,
                plan.red_indicator,
                std::string(cinerion::io::buzzer_pattern_name(plan.buzzer_pattern)).c_str(),
                plan.actuator_enable,
                plan.inhibit_reason.empty()
                    ? ""
                    : (" withheld=" + std::string(plan.inhibit_reason)).c_str(),
                t.value, std::string(cinerion::io::quality_name(t.quality)).c_str(),
                p.value, std::string(cinerion::io::quality_name(p.quality)).c_str(),
                v.value, std::string(cinerion::io::quality_name(v.quality)).c_str(),
                std::string(cinerion::io::time_quality_name(clock_source.quality(tick))).c_str());
            say(line);

            if (confirmation.stuck()) {
                say("         DIAGNOSTIC  the confirmation input is STUCK; it asserts nothing "
                    "until it is seen to release");
            }

            // One CH1 envelope per second, encoded by the real encoder, carrying the real
            // time quality. Published to nothing: there is no broker here and this program
            // does not pretend there is.
            if (t.publishable) {
                // The declared bound, not a guessed number. This file first used 320 and encoded
                // exactly zero envelopes for the same reason app_main did — defect 64, made
                // twice by the same instinct.
                std::array<std::uint8_t, cinerion::ch1::maximum_envelope_bytes> buffer{};
                std::array<std::uint8_t, 16> message_id{};
                std::array<std::uint8_t, 16> correlation{};
                const cinerion::ch1::Origin origin{
                    .source = "CH1-DEV-CELL-0001",
                    .destination = "ch1-edgelink",
                    .project = cinerion::ch1::Uuid(project_id),
                    .cell = cinerion::ch1::Uuid(cell_id),
                    .asset = cinerion::ch1::Uuid(asset_id),
                };
                const cinerion::ch1::Reading reading{
                    .channel = t.channel_id,
                    .value = t.value,
                    .unit = t.unit,
                    .quality = cinerion::io::quality_name(t.quality),
                    .sampled_at_milliseconds = t.sampled_at_milliseconds,
                };
                const std::size_t written = cinerion::ch1::encode_telemetry(
                    buffer, origin, cinerion::ch1::Uuid(message_id),
                    cinerion::ch1::Uuid(correlation), source_time,
                    static_cast<std::int64_t>(tick / 1000),
                    cinerion::io::time_quality_name(clock_source.quality(tick)), reading);
                if (written > 0) {
                    telemetry_published += 1;
                } else {
                    telemetry_withheld += 1;
                }
            } else {
                telemetry_withheld += 1;
            }
        }
    }

    // ---- What the run showed. Counted, not asserted. ----

    std::printf("\n--- what this run exercised ---\n");
    std::printf("  clock            : %s\n",
                clock_disciplined ? "disciplined once, then reported honestly on every message"
                                  : "never disciplined; every command would be refused");
    std::printf("  node bus         : %zu frames accepted, %zu refused, %u sequences consumed\n",
                node_frames_accepted, node_frames_refused, node_minimum_sequence - 1);
    std::printf("  telemetry        : %zu envelopes encoded, %zu withheld because the channel "
                "had nothing publishable\n",
                telemetry_published, telemetry_withheld);
    std::printf("  confirmation     : stuck detection %s\n",
                confirmation.stuck() ? "LATCHED and not cleared" : "exercised and released");
    std::printf("  watchdog         : %s\n",
                watchdog.healthy(total_ms)
                    ? "healthy"
                    : "unhealthy — the actuator enable is withheld and says why");
    std::printf("  actuator         : never energised. This is a simulation; there is no output.\n");
    std::printf("  second command   : %s\n",
                second_procedure_executed
                    ? "prepared, credentialed, confirmed and executed on the SAME boot"
                    : "NOT executed - the cell did not accept a second procedure");
    std::printf("  recovery         : %s\n",
                recovery_reconciled
                    ? "FaultLatched -> Recovery -> Idle, and a recovery naming another work "
                      "order was refused"
                    : "the controlled recovery path was not exercised");
    // ---- Asserted, not merely printed. ----
    //
    // A simulation that only prints is a demonstration; one that refuses is a gate. These
    // are the properties the run is claimed to exercise, and a scenario that stopped
    // reaching a state would otherwise keep printing a confident summary about nothing.
    int failures = 0;
    const auto require = [&failures](const bool condition, const char* what) {
        if (condition) {
            std::printf("  PASS  %s\n", what);
        } else {
            std::printf("  FAIL  %s\n", what);
            failures += 1;
        }
    };

    std::printf("\n--- asserted ---\n");
    require(reached_await_button, "the run reached AwaitButton, so the lamp rule was exercised");
    require(reached_executing, "and Executing, so the enable rule was exercised");
    require(reached_complete, "and Complete, so the whole guarded sequence ran");
    require(completion_acknowledged,
            "Complete returned to Idle on the controlled acknowledgement (CH1-AUT-FDS-0001)");
    require(second_procedure_executed,
            "a SECOND procedure ran on the same boot, through the whole guard");
    require(reached_recovery, "a critical fault reached Recovery through a local reset edge");
    require(recovery_reconciled,
            "and left Recovery only once the work-order state was reconciled");
    require(lamp_lit_only_in_await_button,
            "the confirmation lamp was lit in AwaitButton and in no other state (CH1-IO-DO-0001)");
    require(!actuator_planned_outside_executing,
            "the actuator enable was planned in no state but Executing (CH1-IO-DO-0006)");
    require(watchdog_withheld_the_enable || !watchdog_starved || !reached_executing,
            "a starved watchdog withheld the enable rather than leaving it granted");
    require(stuck_detected, "the stuck confirmation input was detected");
    require(node_frames_refused == 0, "every node-bus frame the node composed was accepted");
    require(telemetry_published > 0, "telemetry envelopes were actually encoded");
    require(clock_disciplined, "the clock was disciplined and reported honestly");

    if (failures > 0) {
        std::printf("\n%d check(s) failed.\n", failures);
        return EXIT_FAILURE;
    }

    std::printf("\nSIMULATION-COMPLETE\n");
    return EXIT_SUCCESS;
}
