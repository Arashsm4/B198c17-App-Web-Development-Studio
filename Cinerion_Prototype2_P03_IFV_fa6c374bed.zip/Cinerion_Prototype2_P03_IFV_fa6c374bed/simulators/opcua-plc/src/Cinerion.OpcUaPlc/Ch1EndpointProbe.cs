// Attacks the OPC UA endpoint and reports what it couldn't do.

using System.Globalization;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Logging;
using Opc.Ua;
using Opc.Ua.Client;

using Cinerion.PlcGuard;

namespace Cinerion.OpcUaPlc;

/// <summary>
/// Attacks the controlled OPC UA endpoint, and reports what it could not do.
/// </summary>
/// <remarks>
/// <para>
/// This is a verification client, not part of the controller. It exists because a security
/// control nobody attacked is a claim: CH1-COM-IF-0007 says "SignAndEncrypt + certificates"
/// and CH1-COM-IF-0022 says "OPC UA SignAndEncrypt or zoned allowlist; no raw UI writes",
/// and each of those is checked here by trying to do the thing they forbid.
/// </para>
/// <para>
/// Every probe below is designed to leave the controller exactly as it found it. The guard
/// refusals it provokes are all refusals that neither advance the state machine nor spend a
/// sequence number, and the last check asserts precisely that — so the gate can run this
/// against a fresh controller and then hand the same controller to EdgeLink's conformance
/// suite without the two interfering.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0007, CH1-COM-IF-0022, CH1-CYB-CSRS-0001, CH1-CMD-FR-0001</requirements>
internal static class Ch1EndpointProbe
{
    private static int _failures;

    public static async Task<int> RunAsync(string endpointUrl, string secrets, ILoggerFactory loggerFactory)
    {
        var telemetry = new Ch1TelemetryContext(loggerFactory);
        var authority = X509CertificateLoader.LoadCertificateFromFile(Path.Combine(secrets, "ca.crt"));
        using var pem = X509Certificate2.CreateFromPemFile(
            Path.Combine(secrets, "edgelink.crt"), Path.Combine(secrets, "edgelink.key"));
        var trusted = X509CertificateLoader.LoadPkcs12(pem.Export(X509ContentType.Pkcs12), null);

        Console.WriteLine($"CH1 OPC UA endpoint probe against {endpointUrl}");

        // --- 1. What the server offers at all. ---------------------------------------
        var configuration = Configure(authority, trusted, "urn:cinerion:ch1:edgelink");
        await configuration.ValidateAsync(ApplicationType.Client, CancellationToken.None).ConfigureAwait(false);

        EndpointDescriptionCollection offered;
        try
        {
            var channel = await DiscoveryClient.CreateAsync(
                configuration,
                new Uri(endpointUrl),
                EndpointConfiguration.Create(configuration),
                DiagnosticsMasks.NoInnerStatus,
                CancellationToken.None).ConfigureAwait(false);
            offered = await channel.GetEndpointsAsync(null, CancellationToken.None).ConfigureAwait(false);
            await channel.CloseAsync(CancellationToken.None).ConfigureAwait(false);
        }
        catch (ServiceResultException error)
        {
            Report("PROBE-01-ENDPOINTS", false, $"discovery failed: {error.Message}");
            return 1;
        }

        var unsecured = offered
            .Where(endpoint => endpoint.SecurityMode != MessageSecurityMode.SignAndEncrypt)
            .Select(endpoint => $"{endpoint.SecurityMode}/{endpoint.SecurityPolicyUri}")
            .ToArray();
        Report(
            "PROBE-01-NO-UNSECURED-ENDPOINT",
            unsecured.Length == 0 && offered.Count > 0,
            unsecured.Length == 0
                ? $"{offered.Count.ToString(CultureInfo.InvariantCulture)} endpoint(s), all SignAndEncrypt"
                : $"the server also offers {string.Join(", ", unsecured)}");

        var anonymousOffered = offered
            .SelectMany(endpoint => endpoint.UserIdentityTokens)
            .Any(token => token.TokenType == UserTokenType.Anonymous);
        Report(
            "PROBE-02-NO-ANONYMOUS-POLICY",
            !anonymousOffered,
            anonymousOffered ? "an anonymous user token policy is published" : "certificate identities only");

        var description = offered.FirstOrDefault(endpoint =>
            endpoint.SecurityMode == MessageSecurityMode.SignAndEncrypt);
        if (description is null)
        {
            Report("PROBE-03-SESSION", false, "no SignAndEncrypt endpoint to open a session against");
            return 1;
        }

        var configured = new ConfiguredEndpoint(
            null, description, EndpointConfiguration.Create(configuration));

        // --- 2. Anonymous is refused. ------------------------------------------------
        await RefusedAsync(
            "PROBE-03-ANONYMOUS-REFUSED",
            configuration,
            configured,
            new UserIdentity(),
            telemetry,
            "anonymous").ConfigureAwait(false);

        // --- 3. A certificate this authority never signed is refused. ----------------
        // Correct application URI, correct host: identity is not a name a client picks, it
        // is a name this authority attested.
        using var rogueKey = RSA.Create(3072);
        var request = new CertificateRequest(
            "CN=Cinerion CH1 EdgeLink, OU=P03-IFV-LABORATORY-ONLY, O=Cinerion",
            rogueKey,
            HashAlgorithmName.SHA256,
            RSASignaturePadding.Pkcs1);
        var alternatives = new SubjectAlternativeNameBuilder();
        alternatives.AddUri(new Uri("urn:cinerion:ch1:edgelink"));
        alternatives.AddDnsName("edge-link");
        request.CertificateExtensions.Add(alternatives.Build());
        request.CertificateExtensions.Add(new X509KeyUsageExtension(
            X509KeyUsageFlags.DigitalSignature | X509KeyUsageFlags.KeyEncipherment
            | X509KeyUsageFlags.DataEncipherment | X509KeyUsageFlags.NonRepudiation,
            critical: true));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(
            [new Oid("1.3.6.1.5.5.7.3.1"), new Oid("1.3.6.1.5.5.7.3.2")], critical: false));
        using var selfSigned = request.CreateSelfSigned(
            DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(1));
        var rogue = X509CertificateLoader.LoadPkcs12(selfSigned.Export(X509ContentType.Pkcs12), null);

        var rogueConfiguration = Configure(authority, rogue, "urn:cinerion:ch1:edgelink");
        await rogueConfiguration.ValidateAsync(ApplicationType.Client, CancellationToken.None).ConfigureAwait(false);
        await RefusedAsync(
            "PROBE-04-FOREIGN-CERTIFICATE-REFUSED",
            rogueConfiguration,
            new ConfiguredEndpoint(null, description, EndpointConfiguration.Create(rogueConfiguration)),
            new UserIdentity(rogue),
            telemetry,
            "a certificate this authority never signed, carrying the right application URI").ConfigureAwait(false);

        // --- 4. The controls that only a genuine session can be checked against. -----
        ISession session;
        try
        {
            session = await new DefaultSessionFactory(telemetry).CreateAsync(
                configuration,
                configured,
                updateBeforeConnect: false,
                sessionName: "ch1-endpoint-probe",
                sessionTimeout: 60_000,
                identity: new UserIdentity(trusted),
                preferredLocales: null,
                ct: CancellationToken.None).ConfigureAwait(false);
        }
        catch (ServiceResultException error)
        {
            Report("PROBE-05-TRUSTED-SESSION", false, $"the trusted identity was refused too: {error.Message}");
            return 1;
        }

        Report("PROBE-05-TRUSTED-SESSION", session.Connected, "the certificate this authority signed is accepted, so the refusals above are about trust rather than a broken link");

        var namespaceIndex = (ushort)session.NamespaceUris.GetIndex(Ch1PlcNodeManager.NamespaceUri);
        var telemetryFolder = await ResolveAsync(session, namespaceIndex, "CH1", "Telemetry").ConfigureAwait(false);
        var handshake = await ResolveAsync(session, namespaceIndex, "CH1", "Handshake").ConfigureAwait(false);
        var prepare = await ResolveAsync(session, namespaceIndex, "CH1", "Handshake", "Prepare").ConfigureAwait(false);

        // --- 5. No raw writes. -------------------------------------------------------
        var (_, _, channels) = await session.BrowseAsync(
            null, null, telemetryFolder, 0, BrowseDirection.Forward,
            ReferenceTypeIds.HierarchicalReferences, true, (uint)NodeClass.Variable,
            CancellationToken.None).ConfigureAwait(false);

        var firstChannel = ExpandedNodeId.ToNodeId(channels[0].NodeId, session.NamespaceUris);
        var write = await session.WriteAsync(
            null,
            [
                new WriteValue
                {
                    NodeId = firstChannel,
                    AttributeId = Attributes.Value,
                    Value = new DataValue(new Variant(999.0)),
                },
            ],
            CancellationToken.None).ConfigureAwait(false);

        var writeStatus = write.Results[0];
        Report(
            "PROBE-06-NO-RAW-WRITE",
            StatusCode.IsBad(writeStatus),
            StatusCode.IsBad(writeStatus)
                ? $"writing {channels[0].BrowseName.Name} was refused as {writeStatus}"
                : "a telemetry value was overwritten by a client");

        // --- 6. There is no commit and no execute on this interface. -----------------
        var (_, _, methods) = await session.BrowseAsync(
            null, null, handshake, 0, BrowseDirection.Forward,
            ReferenceTypeIds.HasComponent, true, (uint)NodeClass.Method,
            CancellationToken.None).ConfigureAwait(false);

        var names = methods.Select(method => method.BrowseName.Name).OrderBy(name => name, StringComparer.Ordinal).ToArray();
        Report(
            "PROBE-07-NO-COMMIT-METHOD",
            names is ["Prepare"],
            $"the handshake exposes {(names.Length == 0 ? "no methods" : string.Join(", ", names))}");

        // --- 7. The guard refuses, and refusing leaves nothing behind. ---------------
        await GuardRefusesAsync(
            "PROBE-08-REVISION-MISMATCH",
            session, handshake, prepare,
            "1.0.0", 1, "CFG-SOMETHING-ELSE", DateTime.UtcNow.AddMinutes(5), "RUN_DIMENSIONAL_TEST",
            "REVISION_MISMATCH").ConfigureAwait(false);

        await GuardRefusesAsync(
            "PROBE-09-EXPIRED-REFUSED",
            session, handshake, prepare,
            "1.0.0", 2, Ch1PlcRuntime.ConfigurationRevision, DateTime.UtcNow.AddSeconds(-1), "RUN_DIMENSIONAL_TEST",
            "EXPIRED").ConfigureAwait(false);

        await GuardRefusesAsync(
            "PROBE-10-SCHEMA-UNSUPPORTED",
            session, handshake, prepare,
            "9.9.9", 3, Ch1PlcRuntime.ConfigurationRevision, DateTime.UtcNow.AddMinutes(5), "RUN_DIMENSIONAL_TEST",
            "SCHEMA_UNSUPPORTED").ConfigureAwait(false);

        await GuardRefusesAsync(
            "PROBE-11-COMMAND-NOT-IN-CAPABILITY-MODEL",
            session, handshake, prepare,
            "1.0.0", 4, Ch1PlcRuntime.ConfigurationRevision, DateTime.UtcNow.AddMinutes(5), "write:40001",
            "COMMAND_TYPE_NOT_IN_CAPABILITY_MODEL").ConfigureAwait(false);

        var state = await ResolveAsync(session, namespaceIndex, "CH1", "Handshake", "State").ConfigureAwait(false);
        var sequence = await ResolveAsync(session, namespaceIndex, "CH1", "Handshake", "LastSequenceNumber").ConfigureAwait(false);
        var read = await session.ReadAsync(
            null, 0, TimestampsToReturn.Neither,
            [
                new ReadValueId { NodeId = state, AttributeId = Attributes.Value },
                new ReadValueId { NodeId = sequence, AttributeId = Attributes.Value },
            ],
            CancellationToken.None).ConfigureAwait(false);

        var guardState = read.Results[0].Value is ushort value ? value : ushort.MaxValue;
        var lastSequence = read.Results[1].Value is long number ? number : -1;
        Report(
            "PROBE-12-REFUSAL-LEAVES-NOTHING-BEHIND",
            guardState == Ch1PlcRuntime.GuardState.Idle && lastSequence == 0,
            $"after four refused preparations the guard is state {guardState.ToString(CultureInfo.InvariantCulture)} "
            + $"with last sequence {lastSequence.ToString(CultureInfo.InvariantCulture)}");

        await session.CloseAsync(CancellationToken.None).ConfigureAwait(false);
        session.Dispose();

        Console.WriteLine(_failures == 0
            ? "CH1 OPC UA endpoint probe: every control refused what it exists to refuse."
            : $"CH1 OPC UA endpoint probe: {_failures.ToString(CultureInfo.InvariantCulture)} check(s) failed.");
        return _failures == 0 ? 0 : 1;
    }

    // ------------------------------------------------------------------ helpers

    private static async Task RefusedAsync(
        string checkId,
        ApplicationConfiguration configuration,
        ConfiguredEndpoint endpoint,
        IUserIdentity identity,
        ITelemetryContext telemetry,
        string what)
    {
        try
        {
            var session = await new DefaultSessionFactory(telemetry).CreateAsync(
                configuration,
                endpoint,
                updateBeforeConnect: false,
                sessionName: "ch1-endpoint-probe-refused",
                sessionTimeout: 30_000,
                identity: identity,
                preferredLocales: null,
                ct: CancellationToken.None).ConfigureAwait(false);

            await session.CloseAsync(CancellationToken.None).ConfigureAwait(false);
            session.Dispose();
            Report(checkId, false, $"{what} was ACCEPTED");
        }
#pragma warning disable CA1031 // Any failure here is the refusal being checked for; the
        // message is reported rather than swallowed, and narrowing the catch would let one
        // transport-level refusal read as a probe crash.
        catch (Exception error)
#pragma warning restore CA1031
        {
            Report(checkId, true, $"{what} was refused: {First(error.Message)}");
        }
    }

    private static async Task GuardRefusesAsync(
        string checkId,
        ISession session,
        NodeId handshake,
        NodeId prepare,
        string schemaVersion,
        long sequenceNumber,
        string configurationRevision,
        DateTime expiresAt,
        string commandType,
        string expectedReason)
    {
        var outputs = await session.CallAsync(
            handshake,
            prepare,
            CancellationToken.None,
            schemaVersion,
            new Uuid(Guid.NewGuid()),
            sequenceNumber,
            configurationRevision,
            expiresAt,
            commandType).ConfigureAwait(false);

        var accepted = outputs.Count > 0 && outputs[0] is true;
        var reason = outputs.Count > 3 ? outputs[3] as string ?? "?" : "?";
        Report(
            checkId,
            !accepted && string.Equals(reason, expectedReason, StringComparison.Ordinal),
            accepted ? $"ACCEPTED, expected {expectedReason}" : $"refused as {reason}");
    }

    private static async Task<NodeId> ResolveAsync(ISession session, ushort namespaceIndex, params string[] path)
    {
        var browsePath = new BrowsePath
        {
            StartingNode = ObjectIds.ObjectsFolder,
            RelativePath = new RelativePath(),
        };

        foreach (var element in path)
        {
            browsePath.RelativePath.Elements.Add(new RelativePathElement
            {
                ReferenceTypeId = ReferenceTypeIds.HierarchicalReferences,
                // Explicit, and load-bearing: RelativePathElement initialises IsInverse to
                // true, so a path that leaves it alone walks the hierarchy backwards and
                // answers BadNoMatch for a node that is plainly there.
                IsInverse = false,
                IncludeSubtypes = true,
                TargetName = new QualifiedName(element, namespaceIndex),
            });
        }

        var response = await session
            .TranslateBrowsePathsToNodeIdsAsync(null, [browsePath], CancellationToken.None)
            .ConfigureAwait(false);

        var result = response.Results[0];
        return result.Targets.Count > 0
            ? ExpandedNodeId.ToNodeId(result.Targets[0].TargetId, session.NamespaceUris)
            : throw new InvalidOperationException($"/{string.Join('/', path)} is not present on this controller.");
    }

    private static ApplicationConfiguration Configure(
        X509Certificate2 authority,
        X509Certificate2 identity,
        string applicationUri)
    {
        var pki = Path.Combine(Path.GetTempPath(), "ch1-opcua-probe-pki");
        var issuers = Path.Combine(pki, "issuers");
        var peers = Path.Combine(pki, "peers");
        var rejected = Path.Combine(pki, "rejected");
        foreach (var store in new[] { issuers, peers, rejected })
        {
            Directory.CreateDirectory(store);
        }

        return new ApplicationConfiguration
        {
            ApplicationName = "Cinerion CH1 endpoint probe",
            ApplicationUri = applicationUri,
            ProductUri = "urn:cinerion:ch1:probe",
            ApplicationType = ApplicationType.Client,
            ClientConfiguration = new ClientConfiguration { DefaultSessionTimeout = 30_000 },
            SecurityConfiguration = new SecurityConfiguration
            {
                ApplicationCertificate = new CertificateIdentifier(identity),
                TrustedIssuerCertificates = new CertificateTrustList
                {
                    StoreType = CertificateStoreType.Directory,
                    StorePath = issuers,
                    TrustedCertificates = [new CertificateIdentifier(authority)],
                },
                TrustedPeerCertificates = new CertificateTrustList
                {
                    StoreType = CertificateStoreType.Directory,
                    StorePath = peers,
                    TrustedCertificates = [new CertificateIdentifier(authority)],
                },
                RejectedCertificateStore = new CertificateStoreIdentifier
                {
                    StoreType = CertificateStoreType.Directory,
                    StorePath = rejected,
                },
                AutoAcceptUntrustedCertificates = false,
                RejectSHA1SignedCertificates = true,
                RejectUnknownRevocationStatus = false,
                MinimumCertificateKeySize = 2048,
                AddAppCertToTrustedStore = false,
                SendCertificateChain = false,
            },
            TransportConfigurations = [],
            TransportQuotas = new TransportQuotas { OperationTimeout = 15_000 },
            TraceConfiguration = new TraceConfiguration { DeleteOnLoad = false },
            DisableHiResClock = true,
        };
    }

    private static string First(string message) =>
        message.Split('\n')[0].Trim();

    private static void Report(string checkId, bool passed, string observation)
    {
        if (!passed)
        {
            _failures++;
        }

        Console.WriteLine($"PROBE {(passed ? "PASS" : "FAIL")} {checkId}: {observation}");
    }
}
