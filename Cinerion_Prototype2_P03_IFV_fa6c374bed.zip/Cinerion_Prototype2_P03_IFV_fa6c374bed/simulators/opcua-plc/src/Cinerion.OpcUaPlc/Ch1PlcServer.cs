// The stand-in OPC UA server, playing the part of an S7-1200 G2.

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Opc.Ua;
using Opc.Ua.Server;

using Cinerion.PlcGuard;

namespace Cinerion.OpcUaPlc;

/// <summary>
/// The OPC UA server an S7-1200 G2 runtime stands behind on CH1-COM-IF-0007 and
/// CH1-COM-IF-0022.
/// </summary>
/// <remarks>
/// <para>
/// Two identities are checked, and they are different questions. The <em>application</em>
/// certificate is validated by the stack against the trust list this deployment was given,
/// which is what makes the channel mutual. The <em>user</em> identity token is validated
/// here, and anonymous is refused outright: an endpoint that accepted an anonymous session
/// would let anything that could reach the port browse the controller's model and call its
/// handshake, and CH1-COM-IF-0022 puts certificates on this edge for exactly that reason.
/// </para>
/// <para>
/// The endpoint offers one security configuration — <c>Basic256Sha256</c> with
/// <c>SignAndEncrypt</c> — and no <c>None</c> alternative. A server that also published an
/// unsecured endpoint would let a client negotiate the security away, which is the usual
/// way an OPC UA deployment ends up unprotected while its documentation says otherwise.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0007, CH1-COM-IF-0022, CH1-CYB-CSRS-0001</requirements>
public sealed class Ch1PlcServer(Ch1PlcRuntime runtime) : StandardServer
{
    private Ch1PlcNodeManager? _nodeManager;

    public Ch1PlcNodeManager NodeManager => _nodeManager
        ?? throw new InvalidOperationException("The address space has not been created yet.");

    protected override MasterNodeManager CreateMasterNodeManager(
        IServerInternal server,
        ApplicationConfiguration configuration)
    {
        _nodeManager = new Ch1PlcNodeManager(server, configuration, runtime);
        return new MasterNodeManager(server, configuration, dynamicNamespaceUri: null, [_nodeManager]);
    }

    protected override void OnServerStarted(IServerInternal server)
    {
        ArgumentNullException.ThrowIfNull(server);
        base.OnServerStarted(server);
        server.SessionManager.ImpersonateUser += OnImpersonateUser;
    }

    /// <summary>
    /// Refuses anonymous, refuses anything that is not a certificate, and refuses a
    /// certificate this deployment's trust list does not reach.
    /// </summary>
    private void OnImpersonateUser(ISession session, ImpersonateEventArgs args)
    {
        _ = session;
        ArgumentNullException.ThrowIfNull(args);

        switch (args.NewIdentity)
        {
            case null or AnonymousIdentityToken:
                args.IdentityValidationError = new ServiceResult(
                    StatusCodes.BadIdentityTokenRejected,
                    "CH1-COM-IF-0022 requires a certificate identity on this edge. Anonymous sessions are refused.");
                return;

            case X509IdentityToken certificateToken:
            {
                X509Certificate2 certificate;
                try
                {
                    certificate = X509CertificateLoader.LoadCertificate(certificateToken.CertificateData);
                }
                catch (CryptographicException)
                {
                    args.IdentityValidationError = new ServiceResult(
                        StatusCodes.BadIdentityTokenInvalid,
                        "The user identity token did not carry a readable certificate.");
                    return;
                }

                try
                {
                    // The same validator, and therefore the same trust list, that governs
                    // the channel. A second, looser check here would be a way around the
                    // first.
                    CertificateValidator.ValidateAsync(certificate, CancellationToken.None)
                        .GetAwaiter()
                        .GetResult();
                }
                catch (ServiceResultException error)
                {
                    args.IdentityValidationError = new ServiceResult(
                        StatusCodes.BadIdentityTokenRejected,
                        $"The user certificate is not trusted by this controller: {error.Message}");
                    return;
                }
                finally
                {
                    certificate.Dispose();
                }

                args.Identity = new UserIdentity(certificateToken);
                return;
            }

            default:
                args.IdentityValidationError = new ServiceResult(
                    StatusCodes.BadIdentityTokenInvalid,
                    $"{args.NewIdentity.GetType().Name} is not an identity this controller accepts.");
                return;
        }
    }
}
