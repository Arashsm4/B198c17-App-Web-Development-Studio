// Sends the OPC UA stack's own logs into this process's logger.

using Microsoft.Extensions.Logging;
using Opc.Ua;

namespace Cinerion.OpcUaPlc;

/// <summary>
/// Routes the OPC UA stack's own diagnostics into this process's logger, so what the
/// server reports about a refused certificate or a rejected identity token can be read
/// from its log rather than inferred from a client-side failure.
/// </summary>
internal sealed class Ch1TelemetryContext(ILoggerFactory loggerFactory) : TelemetryContextBase(loggerFactory);
