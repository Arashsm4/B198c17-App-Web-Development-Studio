// The S7-1200 G2 OPC UA runtime stand-in.
//
// plc/s7-1200-g2/ holds the controlled Structured Text and cannot be executed here: PLCSIM
// needs TIA Portal, a CPU firmware version and an order code, all of which are procurement
// gates. plc/host-model/ made the eleven controlled scenarios executable against a faithful
// translation. This makes the same handshake reachable over the interface CH1-COM-IF-0007
// and CH1-COM-IF-0022 actually name, so EdgeLink's OPC UA adapter is exercised against a
// real OPC UA server speaking a real information model over a real secure channel.
//
// It is a stand-in and says so everywhere: in its device type, in its firmware string, in
// the quality word on every reading, and in the two prepare checks it reports as deferred
// to the CPU rather than answering itself.

using System.Globalization;
using System.Security.Cryptography.X509Certificates;
using Cinerion.OpcUaPlc;
using Cinerion.PlcGuard;
using Microsoft.Extensions.Logging;
using Opc.Ua;
using Opc.Ua.Configuration;

// Two modes, and the second is not part of the controller: "--probe <endpoint>" runs the
// verification client in Ch1EndpointProbe, which attacks this interface from the outside
// and reports what it could not do.
if (args is ["--probe", var probeEndpoint, ..])
{
    using var probeLoggerFactory = LoggerFactory.Create(builder => builder
        .SetMinimumLevel(LogLevel.Warning)
        .AddSimpleConsole(options => options.SingleLine = true));
    return await Ch1EndpointProbe.RunAsync(
        probeEndpoint,
        Environment.GetEnvironmentVariable("CINERION_OPCUA_SECRETS_DIR") ?? "/run/secrets/opcua",
        probeLoggerFactory).ConfigureAwait(false);
}

var deviceId = Environment.GetEnvironmentVariable("CINERION_OPCUA_DEVICE_ID") ?? "CH1-DEV-CELL-0001";
var port = int.TryParse(
    Environment.GetEnvironmentVariable("CINERION_OPCUA_PORT"),
    CultureInfo.InvariantCulture,
    out var configuredPort)
    ? configuredPort
    : 4840;
var hostName = Environment.GetEnvironmentVariable("CINERION_OPCUA_HOSTNAME") ?? "opcua-plc";
var secrets = Environment.GetEnvironmentVariable("CINERION_OPCUA_SECRETS_DIR") ?? "/run/secrets/opcua";
var applicationUri = $"urn:cinerion:ch1:plc:{deviceId}";
var endpointUrl = $"opc.tcp://{hostName}:{port.ToString(CultureInfo.InvariantCulture)}/ch1";

// All three or none, on the same terms as the MQTT edge. A partially configured secure
// channel is the one case where a helpful default would silently drop mutual
// authentication, so an unconfigured deployment does not start at all.
var certificatePath = Path.Combine(secrets, "plc.crt");
var keyPath = Path.Combine(secrets, "plc.key");
var authorityPath = Path.Combine(secrets, "ca.crt");
foreach (var required in new[] { certificatePath, keyPath, authorityPath })
{
    if (!File.Exists(required))
    {
        Console.Error.WriteLine(
            $"CH1 OPC UA stand-in: {required} is absent. This endpoint is SignAndEncrypt with a "
            + "certificate trust list and has no anonymous or unsecured alternative, so it does "
            + "not start without its key material. Run scripts/bootstrap-opcua-pki.sh.");
        return 2;
    }
}

using var authority = X509CertificateLoader.LoadCertificateFromFile(authorityPath);
using var pemIdentity = X509Certificate2.CreateFromPemFile(certificatePath, keyPath);
// Round-tripped through PKCS#12 so the private key is usable by the TLS/secure-channel
// implementation on every platform. Ephemeral, in memory, never written.
var identity = X509CertificateLoader.LoadPkcs12(pemIdentity.Export(X509ContentType.Pkcs12), null);

// The stack insists every trust list names a store, even when the trust anchors are
// supplied in memory. These directories are created empty and stay empty: nothing is ever
// written into the trusted stores, so the only trust anchor is the controlled CA below and
// a certificate dropped into a directory could not quietly become trusted.
var pki = Path.Combine(Path.GetTempPath(), "ch1-opcua-pki");
var trustedIssuers = Path.Combine(pki, "issuers");
var trustedPeers = Path.Combine(pki, "peers");
var rejected = Path.Combine(pki, "rejected");
foreach (var store in new[] { trustedIssuers, trustedPeers, rejected })
{
    Directory.CreateDirectory(store);
}

var configuration = new ApplicationConfiguration
{
    ApplicationName = "Cinerion CH1 PLC stand-in",
    ApplicationUri = applicationUri,
    ProductUri = "urn:cinerion:ch1:plc",
    ApplicationType = ApplicationType.Server,
    ServerConfiguration = new ServerConfiguration
    {
        BaseAddresses = { endpointUrl },
        // One security configuration and no other. There is deliberately no
        // MessageSecurityMode.None endpoint: a client that could negotiate the security
        // away is a deployment whose security is optional, whatever its documentation says.
        SecurityPolicies =
        [
            new ServerSecurityPolicy
            {
                SecurityMode = MessageSecurityMode.SignAndEncrypt,
                SecurityPolicyUri = SecurityPolicies.Basic256Sha256,
            },
        ],
        // Certificate identities only. Anonymous is not offered by the endpoint and is
        // refused again in Ch1PlcServer, because a control that exists in one place is a
        // control one change removes.
        UserTokenPolicies = [new UserTokenPolicy(UserTokenType.Certificate)],
        DiagnosticsEnabled = false,
        MaxSessionCount = 20,
        MinSessionTimeout = 10_000,
        MaxSessionTimeout = 3_600_000,
        MaxBrowseContinuationPoints = 10,
        MaxQueryContinuationPoints = 10,
        MaxHistoryContinuationPoints = 10,
        MaxRequestAge = 600_000,
        MinPublishingInterval = 100,
        MaxPublishingInterval = 3_600_000,
        PublishingResolution = 50,
        MaxSubscriptionLifetime = 3_600_000,
        MaxMessageQueueSize = 100,
        MaxNotificationQueueSize = 100,
        MaxNotificationsPerPublish = 1_000,
        MinMetadataSamplingInterval = 1_000,
        MaxRegistrationInterval = 0,
    },
    SecurityConfiguration = new SecurityConfiguration
    {
        ApplicationCertificate = new CertificateIdentifier(identity),
        // The laboratory authority, held in memory rather than in a directory store. Any
        // certificate that chains to it is trusted; anything else is not, and there is no
        // callback here that returns true regardless — that single line is what turns a
        // certificate trust list into decoration.
        TrustedIssuerCertificates = new CertificateTrustList
        {
            StoreType = CertificateStoreType.Directory,
            StorePath = trustedIssuers,
            TrustedCertificates = [new CertificateIdentifier(authority)],
        },
        TrustedPeerCertificates = new CertificateTrustList
        {
            StoreType = CertificateStoreType.Directory,
            StorePath = trustedPeers,
            TrustedCertificates = [new CertificateIdentifier(authority)],
        },
        RejectedCertificateStore = new CertificateStoreIdentifier
        {
            StoreType = CertificateStoreType.Directory,
            StorePath = rejected,
        },
        AutoAcceptUntrustedCertificates = false,
        RejectSHA1SignedCertificates = true,
        RejectUnknownRevocationStatus = false,
        MinimumCertificateKeySize = 2048,
        AddAppCertToTrustedStore = false,
        SendCertificateChain = false,
    },
    TransportConfigurations = [],
    TransportQuotas = new TransportQuotas
    {
        OperationTimeout = 15_000,
        MaxStringLength = 1_048_576,
        MaxByteStringLength = 1_048_576,
        MaxArrayLength = 65_535,
        MaxMessageSize = 4_194_304,
        MaxBufferSize = 65_535,
        ChannelLifetime = 300_000,
        SecurityTokenLifetime = 3_600_000,
    },
    TraceConfiguration = new TraceConfiguration { DeleteOnLoad = false },
    DisableHiResClock = true,
};

await configuration.ValidateAsync(ApplicationType.Server, CancellationToken.None).ConfigureAwait(false);

// The scope this controller serves, declared in its own capability model. A gateway
// configured for another project or cell is refused by the gateway on the strength of what
// the controller says about itself, rather than on an assumption about which port it dialled.
static Guid Scope(string name, string fallback) =>
    Guid.TryParse(Environment.GetEnvironmentVariable(name), out var value) ? value : Guid.Parse(fallback);

var runtime = new Ch1PlcRuntime(TimeProvider.System)
{
    DeviceId = deviceId,
    ProjectId = Scope("CINERION_OPCUA_PROJECT_ID", "00000000-0000-4000-8000-000000000101"),
    CellId = Scope("CINERION_OPCUA_CELL_ID", "00000000-0000-4000-8000-000000000103"),
    AssetId = Scope("CINERION_OPCUA_ASSET_ID", "00000000-0000-4000-8000-000000000104"),
};
var server = new Ch1PlcServer(runtime);
// The stack's own diagnostics go to the console, so the commissioning record for this
// edge can be assembled from what the server actually reported rather than from a claim
// about it — the same argument that puts EdgeLink's conformance results in its log.
using var loggerFactory = LoggerFactory.Create(builder => builder
    .SetMinimumLevel(LogLevel.Information)
    .AddSimpleConsole(options => options.SingleLine = true));
var application = new ApplicationInstance(configuration, new Ch1TelemetryContext(loggerFactory))
{
    ApplicationName = configuration.ApplicationName,
    ApplicationType = ApplicationType.Server,
};

try
{
    await application.StartAsync(server).ConfigureAwait(false);
}
catch (ServiceResultException error)
{
    // The stack wraps every startup failure as "Unexpected error starting application",
    // which tells an operator nothing. The inner detail is what says whether a port is
    // taken, a certificate is unusable or a store is unwritable.
    Console.Error.WriteLine($"CH1 OPC UA stand-in failed to start: {error.Result}");
    for (var inner = error.InnerException; inner is not null; inner = inner.InnerException)
    {
        Console.Error.WriteLine($"  caused by {inner.GetType().Name}: {inner.Message}");
    }

    return 3;
}

Console.WriteLine($"CH1 OPC UA stand-in online at {endpointUrl}");
Console.WriteLine($"CH1 OPC UA stand-in identity {runtime.Describe()}");
Console.WriteLine(
    "CH1 OPC UA stand-in security SignAndEncrypt/Basic256Sha256, certificate user identity, anonymous refused");
Console.WriteLine($"CH1 OPC UA stand-in namespace {Ch1PlcNodeManager.NamespaceUri}");
foreach (var deferred in Ch1PlcRuntime.DeferredChecks)
{
    Console.WriteLine($"CH1 OPC UA stand-in deferred check {deferred}");
}

using var shutdown = new CancellationTokenSource();
Console.CancelKeyPress += (_, eventArgs) =>
{
    eventArgs.Cancel = true;
    shutdown.Cancel();
};
AppDomain.CurrentDomain.ProcessExit += (_, _) => shutdown.Cancel();

try
{
    while (!shutdown.IsCancellationRequested)
    {
        server.NodeManager.PublishSample();
        await Task.Delay(TimeSpan.FromSeconds(1), shutdown.Token).ConfigureAwait(false);
    }
}
catch (OperationCanceledException)
{
    // The ordinary way this process ends.
}

await server.StopAsync(CancellationToken.None).ConfigureAwait(false);
identity.Dispose();
return 0;
