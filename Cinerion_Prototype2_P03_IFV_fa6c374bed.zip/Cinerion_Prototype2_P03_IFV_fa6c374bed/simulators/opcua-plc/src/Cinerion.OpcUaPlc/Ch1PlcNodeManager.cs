// The CH1 information model a client browses on the stand-in controller.

using System.Globalization;
using Opc.Ua;
using Opc.Ua.Server;

using Cinerion.PlcGuard;

namespace Cinerion.OpcUaPlc;

/// <summary>
/// The CH1 information model an OPC UA client browses on the controller.
/// </summary>
/// <remarks>
/// <para>
/// CH1-COM-IF-0007 names "OPC UA information model" as the contract on this edge and
/// CH1-COM-IF-0022 names "versioned PLC semantic handshake and capability model". So the
/// capability the gateway reports is <em>read out of this address space</em> rather than
/// composed by the adapter, and the semantic handshake is a method on it rather than a
/// register somebody agreed to interpret a particular way.
/// </para>
/// <para>
/// Everything except the one method is read-only, and read-only in the model rather than
/// by convention: every variable carries <c>AccessLevel = CurrentRead</c> and
/// <c>WriteMask = None</c>, so a client that tries to write is refused by the server's own
/// attribute handling with <c>BadNotWritable</c>. CH1-COM-IF-0022 requires no raw writes on
/// this edge, and a control that depends on nobody trying is not a control.
/// </para>
/// <para>
/// Telemetry channels are <c>AnalogItemType</c> nodes carrying an <c>EngineeringUnits</c>
/// property, which is where the gateway reads the unit from. The alternative — a string
/// list the adapter parses — would put the unit in a second place that could disagree with
/// the value it describes.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0007, CH1-COM-IF-0022, CH1-COM-FR-0001, CH1-CMD-FR-0001</requirements>
public sealed class Ch1PlcNodeManager : CustomNodeManager2
{
    /// <summary>The namespace the CH1 handshake nodes live in. Versioned like an API.</summary>
    public const string NamespaceUri = "urn:cinerion:ch1:plc:handshake:v1";

    private readonly Ch1PlcRuntime _runtime;
    private readonly Dictionary<string, AnalogItemState> _channels = [];
    private BaseDataVariableState? _guardState;
    private BaseDataVariableState? _lastSequence;

    public Ch1PlcNodeManager(IServerInternal server, ApplicationConfiguration configuration, Ch1PlcRuntime runtime)
        : base(server, configuration, NamespaceUri)
    {
        _runtime = runtime;
    }

    public override void CreateAddressSpace(IDictionary<NodeId, IList<IReference>> externalReferences)
    {
        ArgumentNullException.ThrowIfNull(externalReferences);

        lock (Lock)
        {
            if (!externalReferences.TryGetValue(ObjectIds.ObjectsFolder, out var references))
            {
                externalReferences[ObjectIds.ObjectsFolder] = references = [];
            }

            var root = Folder(null, "CH1", "The controlled CH1 interface on this controller.");
            root.AddReference(ReferenceTypeIds.Organizes, true, ObjectIds.ObjectsFolder);
            references.Add(new NodeStateReference(ReferenceTypeIds.Organizes, false, root.NodeId));

            var capability = Folder(root, "Capability", "What this controller is, and what it will accept.");
            Constant(capability, "SchemaVersion", Ch1PlcRuntime.SchemaVersion);
            Constant(capability, "DeviceId", _runtime.DeviceId);
            Constant(capability, "DeviceType", Ch1PlcRuntime.DeviceType);
            Constant(capability, "FirmwareVersion", Ch1PlcRuntime.FirmwareVersion);
            Constant(capability, "ConfigurationRevision", Ch1PlcRuntime.ConfigurationRevision);
            Constant(capability, "SecurityProfile", Ch1PlcRuntime.SecurityProfile);
            Constant(capability, "SupportedCommands", Ch1PlcRuntime.SupportedCommands);
            Constant(capability, "ProtocolProfileVersion", Ch1PlcRuntime.SchemaVersion);
            Constant(capability, "ControllerBootId", _runtime.BootId.ToString("N", CultureInfo.InvariantCulture));
            Constant(capability, "ProjectId", _runtime.ProjectId.ToString("D", CultureInfo.InvariantCulture));
            Constant(capability, "CellId", _runtime.CellId.ToString("D", CultureInfo.InvariantCulture));
            Constant(capability, "AssetId", _runtime.AssetId.ToString("D", CultureInfo.InvariantCulture));

            var handshake = Folder(root, "Handshake", "The semantic command handshake of FB_CH1_CommandGuard.");
            _guardState = Constant(handshake, "State", (ushort)_runtime.State);
            _lastSequence = Constant(handshake, "LastSequenceNumber", _runtime.LastSequenceNumber);
            Constant(
                handshake,
                "DeferredChecks",
                Ch1PlcRuntime.DeferredChecks);
            Constant(
                handshake,
                "LocalConfirmationRequired",
                "An execute permit requires a cryptographic credential proof and a physical "
                + "button edge observed at the cell. Neither can arrive over this interface, "
                + "and this interface offers no method that could produce one.");
            CreatePrepareMethod(handshake);

            var telemetry = Folder(root, "Telemetry", "Live values, read-only, each with its engineering unit.");
            foreach (var channel in Ch1PlcRuntime.TelemetryChannels)
            {
                _channels[channel.ChannelId] = AnalogChannel(telemetry, channel);
            }

            AddPredefinedNode(SystemContext, root);
        }
    }

    /// <summary>Pushes one sampled set of readings into the address space.</summary>
    public void PublishSample()
    {
        lock (Lock)
        {
            foreach (var (channel, value, quality, sampledAt, _) in _runtime.Sample())
            {
                if (!_channels.TryGetValue(channel.ChannelId, out var node))
                {
                    continue;
                }

                node.Value = value;
                node.Timestamp = sampledAt.UtcDateTime;
                // Simulated, never Good. A stand-in that reported Good quality would be
                // indistinguishable from conditioned I/O to everything downstream.
                node.StatusCode = new StatusCode(StatusCodes.GoodLocalOverride);
                _ = quality;
                node.ClearChangeMasks(SystemContext, false);
            }

            if (_guardState is not null)
            {
                _guardState.Value = _runtime.State;
                _guardState.Timestamp = DateTime.UtcNow;
                _guardState.ClearChangeMasks(SystemContext, false);
            }

            if (_lastSequence is not null)
            {
                _lastSequence.Value = _runtime.LastSequenceNumber;
                _lastSequence.Timestamp = DateTime.UtcNow;
                _lastSequence.ClearChangeMasks(SystemContext, false);
            }
        }
    }

    // ------------------------------------------------------------------ address space

    private FolderState Folder(NodeState? parent, string name, string description)
    {
        var folder = new FolderState(parent)
        {
            SymbolicName = name,
            ReferenceTypeId = ReferenceTypes.Organizes,
            TypeDefinitionId = ObjectTypeIds.FolderType,
            NodeId = new NodeId(Path(parent, name), NamespaceIndex),
            BrowseName = new QualifiedName(name, NamespaceIndex),
            DisplayName = new LocalizedText(name),
            Description = new LocalizedText(description),
            WriteMask = AttributeWriteMask.None,
            UserWriteMask = AttributeWriteMask.None,
            EventNotifier = EventNotifiers.None,
        };

        parent?.AddChild(folder);
        return folder;
    }

    private BaseDataVariableState Constant<T>(NodeState parent, string name, T value)
    {
        var variable = new BaseDataVariableState(parent)
        {
            SymbolicName = name,
            ReferenceTypeId = ReferenceTypes.Organizes,
            TypeDefinitionId = VariableTypeIds.BaseDataVariableType,
            NodeId = new NodeId(Path(parent, name), NamespaceIndex),
            BrowseName = new QualifiedName(name, NamespaceIndex),
            DisplayName = new LocalizedText(name),
            DataType = TypeInfo.GetDataTypeId(value),
            ValueRank = value is Array ? ValueRanks.OneDimension : ValueRanks.Scalar,
            // Read-only in the model. A client attempting a write is refused by the
            // server's own attribute handling, not by a convention nobody enforces.
            AccessLevel = AccessLevels.CurrentRead,
            UserAccessLevel = AccessLevels.CurrentRead,
            WriteMask = AttributeWriteMask.None,
            UserWriteMask = AttributeWriteMask.None,
            Historizing = false,
            Value = value,
            Timestamp = DateTime.UtcNow,
        };

        parent.AddChild(variable);
        return variable;
    }

    private AnalogItemState AnalogChannel(NodeState parent, Ch1PlcRuntime.Channel channel)
    {
        var variable = new AnalogItemState(parent)
        {
            SymbolicName = channel.ChannelId,
            ReferenceTypeId = ReferenceTypes.Organizes,
            TypeDefinitionId = VariableTypeIds.AnalogItemType,
            NodeId = new NodeId(Path(parent, channel.ChannelId), NamespaceIndex),
            BrowseName = new QualifiedName(channel.ChannelId, NamespaceIndex),
            DisplayName = new LocalizedText(channel.ChannelId),
            Description = new LocalizedText(channel.Description),
            DataType = DataTypeIds.Double,
            ValueRank = ValueRanks.Scalar,
            AccessLevel = AccessLevels.CurrentRead,
            UserAccessLevel = AccessLevels.CurrentRead,
            WriteMask = AttributeWriteMask.None,
            UserWriteMask = AttributeWriteMask.None,
            Historizing = false,
            Value = channel.Minimum,
            Timestamp = DateTime.UtcNow,
        };

        variable.EngineeringUnits = new PropertyState<EUInformation>(variable)
        {
            NodeId = new NodeId(Path(parent, channel.ChannelId) + ".EngineeringUnits", NamespaceIndex),
            BrowseName = BrowseNames.EngineeringUnits,
            DisplayName = new LocalizedText(BrowseNames.EngineeringUnits),
            TypeDefinitionId = VariableTypeIds.PropertyType,
            ReferenceTypeId = ReferenceTypeIds.HasProperty,
            DataType = DataTypeIds.EUInformation,
            ValueRank = ValueRanks.Scalar,
            AccessLevel = AccessLevels.CurrentRead,
            UserAccessLevel = AccessLevels.CurrentRead,
            Value = new EUInformation
            {
                DisplayName = new LocalizedText(channel.Unit),
                Description = new LocalizedText(channel.Description),
                NamespaceUri = "http://www.opcfoundation.org/UA/units/un/cefact",
                UnitId = -1,
            },
        };

        variable.EURange = new PropertyState<Opc.Ua.Range>(variable)
        {
            NodeId = new NodeId(Path(parent, channel.ChannelId) + ".EURange", NamespaceIndex),
            BrowseName = BrowseNames.EURange,
            DisplayName = new LocalizedText(BrowseNames.EURange),
            TypeDefinitionId = VariableTypeIds.PropertyType,
            ReferenceTypeId = ReferenceTypeIds.HasProperty,
            DataType = DataTypeIds.Range,
            ValueRank = ValueRanks.Scalar,
            AccessLevel = AccessLevels.CurrentRead,
            UserAccessLevel = AccessLevels.CurrentRead,
            Value = new Opc.Ua.Range(channel.Maximum, channel.Minimum),
        };

        // EngineeringUnits and EURange are typed children of AnalogItemState and are
        // already reported by GetChildren; adding them again would list each twice.
        parent.AddChild(variable);
        return variable;
    }

    // ------------------------------------------------------------------ the one method

    private void CreatePrepareMethod(NodeState parent)
    {
        var method = new MethodState(parent)
        {
            SymbolicName = "Prepare",
            ReferenceTypeId = ReferenceTypeIds.HasComponent,
            NodeId = new NodeId(Path(parent, "Prepare"), NamespaceIndex),
            BrowseName = new QualifiedName("Prepare", NamespaceIndex),
            DisplayName = new LocalizedText("Prepare"),
            Description = new LocalizedText(
                "One scan of FB_CH1_CommandGuard's prepare branch. It advances the guard to "
                + "Prepared at most and never produces an execute permit."),
            Executable = true,
            UserExecutable = true,
            WriteMask = AttributeWriteMask.None,
            UserWriteMask = AttributeWriteMask.None,
        };

        method.InputArguments = Arguments(
            method,
            BrowseNames.InputArguments,
            [
                Argument("SchemaVersion", DataTypeIds.String, "The envelope schema the caller speaks."),
                Argument("CommandId", DataTypeIds.Guid, "The controlled command identity."),
                Argument("SequenceNumber", DataTypeIds.Int64, "Monotonic per controller; a repeat is a replay."),
                Argument("ConfigurationRevision", DataTypeIds.String, "The configuration the caller believes is loaded."),
                Argument("ExpiresAt", DataTypeIds.DateTime, "After this the intent is dead and is never replayed."),
                Argument("CommandType", DataTypeIds.String, "A semantic operation from the capability model, never a register address."),
            ]);

        method.OutputArguments = Arguments(
            method,
            BrowseNames.OutputArguments,
            [
                Argument("Accepted", DataTypeIds.Boolean, "Whether the guard took the intent."),
                Argument("State", DataTypeIds.UInt16, "FB_CH1_CommandGuard state, the SCL's own numbering."),
                Argument("ReasonCode", DataTypeIds.UInt16, "The SCL reason code."),
                Argument("ReasonName", DataTypeIds.String, "The stable name of that reason code."),
                Argument("ControllerState", DataTypeIds.String, "Never Executing and never Complete on this interface."),
                Argument(
                    "DeferredChecks",
                    DataTypeIds.String,
                    "Prepare checks the CPU makes that this stand-in cannot.",
                    ValueRanks.OneDimension),
            ]);

        method.OnCallMethod = OnPrepare;
        parent.AddChild(method);
    }

    private ServiceResult OnPrepare(
        ISystemContext context,
        MethodState method,
        IList<object> inputArguments,
        IList<object> outputArguments)
    {
        if (inputArguments is not { Count: 6 } || outputArguments is not { Count: 6 })
        {
            return StatusCodes.BadArgumentsMissing;
        }

        // Every argument is matched rather than cast. A cast that throws is reported by the
        // stack as a bare Bad with no diagnostic, which tells a caller nothing about which
        // argument it got wrong — and OPC UA carries a Guid as Opc.Ua.Uuid on the wire, so
        // the obvious cast is also the wrong one.
        if (inputArguments[0] is not string schemaVersion
            || inputArguments[3] is not string configurationRevision
            || inputArguments[5] is not string commandType
            || inputArguments[4] is not DateTime expiry)
        {
            return StatusCodes.BadInvalidArgument;
        }

        var commandId = inputArguments[1] switch
        {
            Uuid uuid => (Guid)uuid,
            Guid guid => guid,
            _ => Guid.Empty,
        };

        var sequenceNumber = inputArguments[2] switch
        {
            long value => value,
            int value => value,
            _ => -1L,
        };

        if (commandId == Guid.Empty || sequenceNumber < 0)
        {
            return StatusCodes.BadInvalidArgument;
        }

        var result = _runtime.Prepare(
            schemaVersion,
            commandId,
            sequenceNumber,
            configurationRevision,
            new DateTimeOffset(DateTime.SpecifyKind(expiry, DateTimeKind.Utc)),
            commandType);

        outputArguments[0] = result.Accepted;
        outputArguments[1] = result.State;
        outputArguments[2] = result.ReasonCode;
        outputArguments[3] = result.ReasonName;
        outputArguments[4] = result.ControllerState;
        // On every reply, accepted or refused. A caller must never have to assume the two
        // checks this stand-in cannot make were made.
        outputArguments[5] = Ch1PlcRuntime.DeferredChecks;

        _ = context;
        _ = method;
        return ServiceResult.Good;
    }

    private PropertyState<Argument[]> Arguments(NodeState parent, string browseName, Argument[] arguments) =>
        new(parent)
        {
            NodeId = new NodeId(Path(parent, browseName), NamespaceIndex),
            BrowseName = browseName,
            DisplayName = new LocalizedText(browseName),
            TypeDefinitionId = VariableTypeIds.PropertyType,
            ReferenceTypeId = ReferenceTypeIds.HasProperty,
            DataType = DataTypeIds.Argument,
            ValueRank = ValueRanks.OneDimension,
            AccessLevel = AccessLevels.CurrentRead,
            UserAccessLevel = AccessLevels.CurrentRead,
            Value = arguments,
        };

    private static Argument Argument(
        string name,
        NodeId dataType,
        string description,
        int valueRank = ValueRanks.Scalar) => new()
    {
        Name = name,
        DataType = dataType,
        ValueRank = valueRank,
        Description = new LocalizedText(description),
    };

    private static string Path(NodeState? parent, string name) =>
        parent is null ? name : $"{parent.NodeId?.Identifier ?? parent.SymbolicName}.{name}";
}
