// The controlled Modbus zone stand-in for CH1-COM-IF-0008.
//
// Modbus authenticates nothing and encrypts nothing. CH1-COM-ICD-0001 therefore terminates
// it "at EdgeLink or a controlled PLC zone with allowlisted mappings and no general
// routing", and CH1-COM-PRO-0001 states the map's shape: read-only telemetry, read-only
// configuration, and a command handshake, with arbitrary function codes and address ranges
// denied. This serves exactly that map and nothing else.
//
// It reaches the same FB_CH1_CommandGuard translation the OPC UA controller reaches, so a
// refusal reported over one profile is the same refusal reported over the other. The
// execute permit is an input register: no Modbus function code can write one, which is the
// answer to CH1-CYB-TMD-0001's "direct Modbus write bypassing CommandGuard".

using System.Globalization;
using System.Net;
using Cinerion.ModbusPlc;
using Cinerion.PlcGuard;
using FluentModbus;
using Microsoft.Extensions.Logging;

if (args is ["--probe", var probeHost, ..])
{
    return await Ch1ModbusProbe.RunAsync(
        probeHost,
        int.TryParse(
            Environment.GetEnvironmentVariable("CINERION_MODBUS_PORT"),
            CultureInfo.InvariantCulture,
            out var probePort)
            ? probePort
            : 502).ConfigureAwait(false);
}

var deviceId = Environment.GetEnvironmentVariable("CINERION_MODBUS_DEVICE_ID") ?? "CH1-DEV-CELL-0001";
var port = int.TryParse(
    Environment.GetEnvironmentVariable("CINERION_MODBUS_PORT"),
    CultureInfo.InvariantCulture,
    out var configuredPort)
    ? configuredPort
    : 502;

static Guid Scope(string name, string fallback) =>
    Guid.TryParse(Environment.GetEnvironmentVariable(name), out var value) ? value : Guid.Parse(fallback);

var runtime = new Ch1PlcRuntime(TimeProvider.System)
{
    DeviceId = deviceId,
    ProjectId = Scope("CINERION_MODBUS_PROJECT_ID", "00000000-0000-4000-8000-000000000101"),
    CellId = Scope("CINERION_MODBUS_CELL_ID", "00000000-0000-4000-8000-000000000103"),
    AssetId = Scope("CINERION_MODBUS_ASSET_ID", "00000000-0000-4000-8000-000000000104"),
};

using var loggerFactory = LoggerFactory.Create(builder => builder
    .SetMinimumLevel(LogLevel.Warning)
    .AddSimpleConsole(options => options.SingleLine = true));

using var server = new ModbusTcpServer(loggerFactory.CreateLogger<ModbusTcpServer>(), isAsynchronous: true);

// One unit, and not unit 0. The register buffers this library allocates cover the whole
// 16-bit address space whatever the map uses, so the allowlist in Ch1ModbusAllowlist is the
// only thing standing between a request and an address outside the three declared bands —
// which is why it denies by default rather than listing what to refuse.
server.RemoveUnit(0);
server.AddUnit((byte)Ch1ModbusMap.UnitIdentifier);

var controller = new Ch1ModbusController(server, runtime);
server.Start(new IPEndPoint(IPAddress.Any, port));
controller.PublishConfiguration();

Console.WriteLine($"CH1 Modbus stand-in online on tcp/{port.ToString(CultureInfo.InvariantCulture)}, unit {Ch1ModbusMap.UnitIdentifier}");
Console.WriteLine($"CH1 Modbus stand-in identity {runtime.Describe()}");
Console.WriteLine(
    "CH1 Modbus stand-in security zoned allowlist, no general routing; the link authenticates nothing "
    + "and the handshake answer is in input registers no function code can write");
Console.WriteLine(
    $"CH1 Modbus stand-in map version {Ch1ModbusMap.MapVersion.ToString(CultureInfo.InvariantCulture)}, "
    + $"telemetry 0..{(Ch1ModbusMap.TelemetrySampleCounter).ToString(CultureInfo.InvariantCulture)}, "
    + $"configuration {Ch1ModbusMap.ConfigurationBandStart.ToString(CultureInfo.InvariantCulture)}.."
    + $"{Ch1ModbusMap.ConfigurationBandEnd.ToString(CultureInfo.InvariantCulture)}, "
    + $"handshake {Ch1ModbusMap.HandshakeBandStart.ToString(CultureInfo.InvariantCulture)}.."
    + $"{Ch1ModbusMap.HandshakeBandEnd.ToString(CultureInfo.InvariantCulture)}");
foreach (var deferred in Ch1PlcRuntime.DeferredChecks)
{
    Console.WriteLine($"CH1 Modbus stand-in deferred check {deferred}");
}

using var shutdown = new CancellationTokenSource();
Console.CancelKeyPress += (_, eventArgs) =>
{
    eventArgs.Cancel = true;
    shutdown.Cancel();
};
AppDomain.CurrentDomain.ProcessExit += (_, _) => shutdown.Cancel();

try
{
    while (!shutdown.IsCancellationRequested)
    {
        // Every write to the register buffers, here and in the guard scan, is taken under
        // the server's own lock, so a master reading the answer band never sees half of one
        // evaluation and half of the next.
        controller.PublishSample();
        await Task.Delay(TimeSpan.FromSeconds(1), shutdown.Token).ConfigureAwait(false);
    }
}
catch (OperationCanceledException)
{
    // The ordinary way this process ends.
}

server.Stop();
return 0;
