// The controlled Modbus register map, controller side.

namespace Cinerion.ModbusPlc;

/// <summary>
/// The controlled Modbus register map — the controller's half.
/// </summary>
/// <remarks>
/// <para>
/// Every constant below is stated identically in
/// <c>services/edge-link/src/Cinerion.EdgeLink/Protocols/Ch1ModbusMap.cs</c>, and
/// <c>scripts/check-modbus-map.mjs</c> fails the build when any name or value differs. The
/// duplication is deliberate: EdgeLink must not reference a simulator, and a map the two
/// ends merely believe they agree on is exactly the disagreement worth catching. This is
/// the same argument that pins the firmware's CBOR encoding to the gateway's byte for byte.
/// </para>
/// <para>
/// The three bands are the three CH1-COM-PRO-0001 names: read-only telemetry, read-only
/// configuration, and the command handshake. Everything outside them is refused by
/// <c>Ch1ModbusAllowlist</c> with ILLEGAL_DATA_ADDRESS, and every function code outside
/// read-holding, read-input and write-multiple is refused with ILLEGAL_FUNCTION.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0008, CH1-COM-PRO-0001, CH1-CYB-TMD-0001</requirements>
public static class Ch1ModbusMap
{
    // --- Map identity ------------------------------------------------------------------

    public const ushort MapVersion = 1;
    public const ushort UnitIdentifier = 1;

    // --- Input registers: read-only telemetry (function code 4 only) --------------------

    public const ushort TelemetryTemperature = 0;
    public const ushort TelemetryPosition = 1;
    public const ushort TelemetryVibrationRms = 2;
    public const ushort TelemetryQuality = 3;
    public const ushort TelemetrySampleCounter = 4;

    /// <summary>Every telemetry value is a signed hundredth of its engineering unit.</summary>
    public const ushort TelemetryScale = 100;

    public const ushort TelemetryQualityInvalid = 0;
    public const ushort TelemetryQualitySimulated = 1;
    public const ushort TelemetryQualityGood = 2;

    // --- Input registers: the handshake answer, unwritable by any function code ---------

    public const ushort AnswerBandStart = 16;
    public const ushort AnswerState = 16;
    public const ushort AnswerReasonCode = 17;
    public const ushort AnswerAccepted = 18;
    public const ushort AnswerExecutePermit = 19;
    public const ushort AnswerLastSequenceHigh = 20;
    public const ushort AnswerLastSequenceLow = 21;
    public const ushort AnswerCounter = 22;
    public const ushort AnswerDeferredCheckCount = 23;
    public const ushort AnswerDeferredCheckFirst = 24;
    public const ushort AnswerDeferredCheckSecond = 25;
    public const ushort InputRegisterCount = 26;

    // --- Holding registers: read-only configuration and capability (function code 3) ----

    public const ushort ConfigurationBandStart = 0;
    public const ushort ConfigMapVersion = 0;
    public const ushort ConfigSchemaMajor = 1;
    public const ushort ConfigSchemaMinor = 2;
    public const ushort ConfigSchemaPatch = 3;
    public const ushort ConfigControllerBootIdLow = 4;
    public const ushort ConfigSecurityProfileCode = 5;
    public const ushort ConfigSupportedCommandCount = 6;
    public const ushort ConfigTelemetryChannelCount = 7;
    public const ushort ConfigDeviceId = 8;
    public const ushort ConfigDeviceType = 24;
    public const ushort ConfigFirmwareVersion = 40;
    public const ushort ConfigConfigurationRevision = 56;
    public const ushort ConfigSupportedCommand0 = 72;
    public const ushort ConfigSupportedCommand1 = 88;
    public const ushort ConfigChannel0Name = 104;
    public const ushort ConfigChannel1Name = 112;
    public const ushort ConfigChannel2Name = 120;
    public const ushort ConfigChannel0Unit = 128;
    public const ushort ConfigChannel1Unit = 132;
    public const ushort ConfigChannel2Unit = 136;
    public const ushort ConfigurationBandEnd = 139;

    /// <summary>Sixteen registers, so a controlled identifier of up to 32 characters.</summary>
    public const ushort LongTextRegisters = 16;

    /// <summary>Eight registers for a channel name, four for its engineering unit.</summary>
    public const ushort ShortTextRegisters = 8;

    public const ushort UnitTextRegisters = 4;

    /// <summary>
    /// The one security profile this edge can honestly claim. Modbus authenticates nothing,
    /// so the control is the zone and the allowlist, and the name says exactly that rather
    /// than implying a cryptographic one.
    /// </summary>
    public const ushort SecurityProfileZonedAllowlist = 1;

    // --- Holding registers: the command handshake, the only writable window -------------

    public const ushort HandshakeBandStart = 200;
    public const ushort HandshakeSchemaMajor = 200;
    public const ushort HandshakeCommandId = 201;
    public const ushort HandshakeCommandIdRegisters = 8;
    public const ushort HandshakeSequenceHigh = 209;
    public const ushort HandshakeSequenceLow = 210;
    public const ushort HandshakeConfigurationRevision = 211;
    public const ushort HandshakeConfigurationRevisionRegisters = 12;
    public const ushort HandshakeExpiresAtHigh = 223;
    public const ushort HandshakeExpiresAtLow = 224;
    public const ushort HandshakeCommandType = 225;
    public const ushort HandshakeCommandTypeRegisters = 16;
    public const ushort HandshakeTrigger = 241;
    public const ushort HandshakeBandEnd = 241;

    /// <summary>Written to <see cref="HandshakeTrigger"/> to have the guard evaluate one scan.</summary>
    public const ushort HandshakeTriggerEvaluate = 1;

    /// <summary>
    /// <c>207 PRELIMINARY_PERMISSIVE_INVALID</c>, the deferred check that governs this whole
    /// profile: the real S7-1200 G2 reads <c>UDT_CH1_Permissives</c> from wired inputs and a
    /// zone stand-in has none, so this map carries no interlock register at all and a gateway
    /// in front of it reports the permissives as never answered.
    /// </summary>
    public const ushort DeferredPreliminaryPermissiveInvalid = 207;
}
