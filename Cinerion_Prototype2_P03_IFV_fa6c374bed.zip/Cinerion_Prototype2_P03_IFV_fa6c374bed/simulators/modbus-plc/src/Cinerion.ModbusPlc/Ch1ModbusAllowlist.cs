// The zoned allowlist: what this stand-in controller will answer at all.

using FluentModbus;

namespace Cinerion.ModbusPlc;

/// <summary>
/// The zoned allowlist: what this controller will answer at all.
/// </summary>
/// <remarks>
/// <para>
/// CH1-COM-PRO-0001 requires that "arbitrary function codes and address ranges are denied",
/// and CH1-CYB-CSRS-0001 makes the gateway zone "not a general router". Modbus offers no
/// identity to check, so this — a deny-by-default decision taken on every single request,
/// before any register is touched — is the whole of the access control on this link.
/// </para>
/// <para>
/// <b>Deny by default.</b> The method returns <c>IllegalFunction</c> or
/// <c>IllegalDataAddress</c> unless a request falls inside a band that has been named. A new
/// band is a deliberate act; nothing widens by accident.
/// </para>
/// <para>
/// <b>The handshake answer is not in here at all</b>, and that is not an omission. The
/// guard's state, reason and execute permit are input registers, which the Modbus protocol
/// itself gives no function code to write — so the refusal of a forged acknowledgement or a
/// directly asserted execute permit does not depend on this allowlist being correct.
/// CH1-CYB-TMD-0001 names "direct Modbus write bypassing CommandGuard" as a priority threat,
/// and two independent things have to hold for it to be refused: the protocol, and this.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0008, CH1-COM-PRO-0001, CH1-CYB-CSRS-0001, CH1-CYB-TMD-0001</requirements>
public static class Ch1ModbusAllowlist
{
    /// <summary>
    /// Installed as <c>ModbusServer.RequestValidator</c>, so it runs for every request.
    /// </summary>
    public static ModbusExceptionCode Validate(
        byte unit,
        ModbusFunctionCode function,
        ushort address,
        ushort quantity)
    {
        if (unit != Ch1ModbusMap.UnitIdentifier)
        {
            return ModbusExceptionCode.GatewayTargetDeviceFailedToRespond;
        }

        // A zero-length or wrapping request is refused before any range test, because a
        // range test on a wrapped end address is a range test that passes.
        if (quantity == 0 || address + quantity > ushort.MaxValue)
        {
            return ModbusExceptionCode.IllegalDataValue;
        }

        var last = (ushort)(address + quantity - 1);

        return function switch
        {
            // Read-only telemetry and the handshake answer. Input registers cannot be
            // written by any function code, which is why the answer lives here.
            ModbusFunctionCode.ReadInputRegisters =>
                Within(address, last, 0, (ushort)(Ch1ModbusMap.InputRegisterCount - 1)),

            // Configuration and the handshake window are both readable; nothing else is.
            ModbusFunctionCode.ReadHoldingRegisters =>
                Within(address, last, Ch1ModbusMap.ConfigurationBandStart, Ch1ModbusMap.ConfigurationBandEnd) is ModbusExceptionCode.OK
                || Within(address, last, Ch1ModbusMap.HandshakeBandStart, Ch1ModbusMap.HandshakeBandEnd) is ModbusExceptionCode.OK
                    ? ModbusExceptionCode.OK
                    : ModbusExceptionCode.IllegalDataAddress,

            // The one writable window in the whole map. Configuration is read-only, so a
            // client cannot rewrite the map version, the device identity or the capability
            // model and have a gateway believe it.
            ModbusFunctionCode.WriteMultipleRegisters =>
                Within(address, last, Ch1ModbusMap.HandshakeBandStart, Ch1ModbusMap.HandshakeBandEnd),

            // Everything else. Coils, discrete inputs, single-register writes, file records,
            // mask writes, FIFO queues and diagnostics are not part of this profile, and a
            // controller that answered them would be a general router.
            _ => ModbusExceptionCode.IllegalFunction,
        };
    }

    private static ModbusExceptionCode Within(ushort address, ushort last, ushort start, ushort end) =>
        address >= start && last <= end
            ? ModbusExceptionCode.OK
            : ModbusExceptionCode.IllegalDataAddress;
}
