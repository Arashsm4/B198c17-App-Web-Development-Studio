// Attacks the Modbus zone and reports what it couldn't do.

using System.Buffers.Binary;
using System.Globalization;
using System.Net.Sockets;

namespace Cinerion.ModbusPlc;

/// <summary>
/// Attacks the controlled Modbus zone, and reports what it could not do.
/// </summary>
/// <remarks>
/// <para>
/// This is a verification client, not part of the controller, and it speaks Modbus at the
/// byte level on purpose: the point of most of these probes is to send a request no
/// well-behaved library would construct. Arbitrary function codes, addresses outside every
/// band, a write aimed at the configuration the gateway trusts, and — the one that matters
/// most — a direct attempt on the execute permit.
/// </para>
/// <para>
/// CH1-CYB-TMD-0001 names "direct Modbus write bypassing CommandGuard" as a priority threat
/// case. On this map that attempt cannot even be expressed: the permit is an input register,
/// and Modbus has no function code that writes one. <c>PROBE-07</c> tries every write
/// function the protocol defines and reports what each was refused with.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0008, CH1-COM-PRO-0001, CH1-CYB-TMD-0001, CH1-CYB-CSRS-0001</requirements>
internal static class Ch1ModbusProbe
{
    private static int _failures;

    public static async Task<int> RunAsync(string host, int port)
    {
        Console.WriteLine($"CH1 Modbus zone probe against {host}:{port.ToString(CultureInfo.InvariantCulture)}");

        using var socket = new TcpClient { NoDelay = true };
        await socket.ConnectAsync(host, port).ConfigureAwait(false);
        var stream = socket.GetStream();
        ushort transaction = 0;

        // Sends a raw PDU and reports either the answer or the Modbus exception code.
        async Task<(bool Ok, byte Exception, byte[] Body)> SendAsync(byte[] pdu)
        {
            var frame = new byte[7 + pdu.Length];
            BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(0), ++transaction);
            BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(2), 0);
            BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(4), (ushort)(pdu.Length + 1));
            frame[6] = (byte)Ch1ModbusMap.UnitIdentifier;
            pdu.CopyTo(frame.AsSpan(7));

            using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            await stream.WriteAsync(frame, deadline.Token).ConfigureAwait(false);

            var header = new byte[7];
            await stream.ReadExactlyAsync(header, deadline.Token).ConfigureAwait(false);
            var length = BinaryPrimitives.ReadUInt16BigEndian(header.AsSpan(4));
            var body = new byte[length - 1];
            await stream.ReadExactlyAsync(body, deadline.Token).ConfigureAwait(false);

            return (body[0] & 0x80) != 0
                ? (false, body.Length > 1 ? body[1] : (byte)0, body)
                : (true, (byte)0, body);
        }

        static byte[] Read(byte function, ushort address, ushort quantity)
        {
            var pdu = new byte[5];
            pdu[0] = function;
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(1), address);
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(3), quantity);
            return pdu;
        }

        static byte[] WriteMultiple(ushort address, ushort value)
        {
            var pdu = new byte[8];
            pdu[0] = 16;
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(1), address);
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(3), 1);
            pdu[5] = 2;
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(6), value);
            return pdu;
        }

        static byte[] WriteSingle(byte function, ushort address, ushort value)
        {
            var pdu = new byte[5];
            pdu[0] = function;
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(1), address);
            BinaryPrimitives.WriteUInt16BigEndian(pdu.AsSpan(3), value);
            return pdu;
        }

        // --- 1. The map is the version the gateway was written against. --------------
        var mapVersion = await SendAsync(Read(3, Ch1ModbusMap.ConfigMapVersion, 1)).ConfigureAwait(false);
        var published = mapVersion.Ok ? BinaryPrimitives.ReadUInt16BigEndian(mapVersion.Body.AsSpan(2)) : ushort.MaxValue;
        Report(
            "PROBE-01-MAP-VERSION-PUBLISHED",
            published == Ch1ModbusMap.MapVersion,
            $"the controller publishes map version {published.ToString(CultureInfo.InvariantCulture)}");

        // --- 2. Reading inside the bands works, so the refusals below mean something. --
        var telemetry = await SendAsync(Read(4, 0, Ch1ModbusMap.InputRegisterCount)).ConfigureAwait(false);
        // Two requests, because Modbus caps a single read at 125 registers and the
        // configuration band is 140. The cap is the protocol's, not this map's.
        var configurationLow = await SendAsync(Read(3, 0, 120)).ConfigureAwait(false);
        var configurationHigh = await SendAsync(
            Read(3, 120, (ushort)(Ch1ModbusMap.ConfigurationBandEnd - 120 + 1))).ConfigureAwait(false);
        var configuration = configurationLow.Ok && configurationHigh.Ok;
        Report(
            "PROBE-02-DECLARED-BANDS-READABLE",
            telemetry.Ok && configuration,
            telemetry.Ok && configuration
                ? "telemetry and configuration read normally"
                : "a band the map declares could not be read");

        // --- 3. Address ranges outside every band are denied. -------------------------
        var beyondConfiguration = await SendAsync(
            Read(3, (ushort)(Ch1ModbusMap.ConfigurationBandEnd + 1), 1)).ConfigureAwait(false);
        Report(
            "PROBE-03-ADDRESS-OUTSIDE-BANDS-DENIED",
            !beyondConfiguration.Ok && beyondConfiguration.Exception == 2,
            Describe(beyondConfiguration, $"reading {Ch1ModbusMap.ConfigurationBandEnd + 1}"));

        // A read that starts inside a band and runs off its end. A range check applied only
        // to the first address is the usual way an allowlist leaks.
        var straddling = await SendAsync(
            Read(3, (ushort)(Ch1ModbusMap.ConfigurationBandEnd - 1), 8)).ConfigureAwait(false);
        Report(
            "PROBE-04-STRADDLING-READ-DENIED",
            !straddling.Ok && straddling.Exception == 2,
            Describe(straddling, "a read starting inside the configuration band and running past its end"));

        // --- 4. Arbitrary function codes are denied. ----------------------------------
        var coils = await SendAsync(Read(1, 0, 1)).ConfigureAwait(false);
        Report(
            "PROBE-05-COIL-FUNCTION-DENIED",
            !coils.Ok && coils.Exception == 1,
            Describe(coils, "read coils (function 1)"));

        var fileRecord = await SendAsync([20, 0x07, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01]).ConfigureAwait(false);
        Report(
            "PROBE-06-FILE-RECORD-FUNCTION-DENIED",
            !fileRecord.Ok && fileRecord.Exception == 1,
            Describe(fileRecord, "read file record (function 20)"));

        // --- 5. The priority threat case: a direct write at the execute permit. -------
        //
        // CH1-CYB-TMD-0001 names it. Every write function the protocol defines is tried at
        // the permit's address, and each is reported with what refused it. The first two are
        // refused because the permit is an input register and these functions address
        // holding registers or coils; the point is that no combination reaches it.
        var permitAttempts = new List<string>();
        var permitHeld = true;
        foreach (var (name, pdu) in new (string, byte[])[]
                 {
                     ("write single register (6)", WriteSingle(6, Ch1ModbusMap.AnswerExecutePermit, 1)),
                     ("write multiple registers (16)", WriteMultiple(Ch1ModbusMap.AnswerExecutePermit, 1)),
                     ("write single coil (5)", WriteSingle(5, Ch1ModbusMap.AnswerExecutePermit, 0xFF00)),
                     ("mask write register (22)", [22, 0x00, Ch1ModbusMap.AnswerExecutePermit & 0xFF, 0x00, 0x00, 0x00, 0x01]),
                 })
        {
            var attempt = await SendAsync(pdu).ConfigureAwait(false);
            permitAttempts.Add($"{name} -> {(attempt.Ok ? "ACCEPTED" : Exception(attempt.Exception))}");
            permitHeld &= !attempt.Ok;
        }

        var permitAfter = await SendAsync(Read(4, Ch1ModbusMap.AnswerExecutePermit, 1)).ConfigureAwait(false);
        var permitValue = permitAfter.Ok ? BinaryPrimitives.ReadUInt16BigEndian(permitAfter.Body.AsSpan(2)) : ushort.MaxValue;
        Report(
            "PROBE-07-EXECUTE-PERMIT-UNREACHABLE",
            permitHeld && permitValue == 0,
            $"{string.Join("; ", permitAttempts)}; the permit still reads {permitValue.ToString(CultureInfo.InvariantCulture)}");

        // --- 6. The configuration a gateway trusts cannot be rewritten. ---------------
        var rewriteMap = await SendAsync(WriteMultiple(Ch1ModbusMap.ConfigMapVersion, 99)).ConfigureAwait(false);
        var mapAfter = await SendAsync(Read(3, Ch1ModbusMap.ConfigMapVersion, 1)).ConfigureAwait(false);
        var mapValue = mapAfter.Ok ? BinaryPrimitives.ReadUInt16BigEndian(mapAfter.Body.AsSpan(2)) : ushort.MaxValue;
        Report(
            "PROBE-08-CONFIGURATION-READ-ONLY",
            !rewriteMap.Ok && mapValue == Ch1ModbusMap.MapVersion,
            $"{Describe(rewriteMap, "writing the map version")}; it still reads {mapValue.ToString(CultureInfo.InvariantCulture)}");

        var rewriteIdentity = await SendAsync(WriteMultiple(Ch1ModbusMap.ConfigDeviceId, 0x4141)).ConfigureAwait(false);
        Report(
            "PROBE-09-DEVICE-IDENTITY-READ-ONLY",
            !rewriteIdentity.Ok && rewriteIdentity.Exception == 2,
            Describe(rewriteIdentity, "writing the device identity the gateway reports"));

        // --- 7. The handshake window is writable, so the refusals are about scope. ----
        var handshake = await SendAsync(WriteMultiple(Ch1ModbusMap.HandshakeSchemaMajor, 1)).ConfigureAwait(false);
        Report(
            "PROBE-10-HANDSHAKE-WINDOW-WRITABLE",
            handshake.Ok,
            handshake.Ok
                ? "the one declared writable window accepts a write, so the denials above are about scope rather than a dead device"
                : Describe(handshake, "writing the handshake window"));

        // --- 8. Another unit identifier is not this controller. -----------------------
        var otherUnit = new byte[7 + 5];
        BinaryPrimitives.WriteUInt16BigEndian(otherUnit.AsSpan(0), ++transaction);
        BinaryPrimitives.WriteUInt16BigEndian(otherUnit.AsSpan(2), 0);
        BinaryPrimitives.WriteUInt16BigEndian(otherUnit.AsSpan(4), 6);
        otherUnit[6] = (byte)(Ch1ModbusMap.UnitIdentifier + 1);
        Read(3, Ch1ModbusMap.ConfigMapVersion, 1).CopyTo(otherUnit.AsSpan(7));
        using (var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5)))
        {
            try
            {
                await stream.WriteAsync(otherUnit, deadline.Token).ConfigureAwait(false);
                var header = new byte[7];
                await stream.ReadExactlyAsync(header, deadline.Token).ConfigureAwait(false);
                var body = new byte[BinaryPrimitives.ReadUInt16BigEndian(header.AsSpan(4)) - 1];
                await stream.ReadExactlyAsync(body, deadline.Token).ConfigureAwait(false);
                Report(
                    "PROBE-11-FOREIGN-UNIT-DENIED",
                    (body[0] & 0x80) != 0,
                    (body[0] & 0x80) != 0
                        ? $"unit {Ch1ModbusMap.UnitIdentifier + 1} answered {Exception(body[1])}"
                        : "another unit identifier was served by this controller");
            }
            catch (OperationCanceledException)
            {
                // Silence is the other correct answer. A Modbus device may ignore a request
                // addressed to a unit it does not implement rather than answer an exception,
                // and both are refusals; what would fail this probe is being served.
                Report(
                    "PROBE-11-FOREIGN-UNIT-DENIED",
                    true,
                    $"unit {Ch1ModbusMap.UnitIdentifier + 1} was not answered at all");
            }
        }

        Console.WriteLine(_failures == 0
            ? "CH1 Modbus zone probe: every control refused what it exists to refuse."
            : $"CH1 Modbus zone probe: {_failures.ToString(CultureInfo.InvariantCulture)} check(s) failed.");
        return _failures == 0 ? 0 : 1;
    }

    private static string Describe((bool Ok, byte Exception, byte[] Body) result, string what) =>
        result.Ok ? $"{what} was ACCEPTED" : $"{what} was refused as {Exception(result.Exception)}";

    private static string Exception(byte code) => code switch
    {
        1 => "ILLEGAL_FUNCTION",
        2 => "ILLEGAL_DATA_ADDRESS",
        3 => "ILLEGAL_DATA_VALUE",
        11 => "GATEWAY_TARGET_DEVICE_FAILED_TO_RESPOND",
        _ => $"EXCEPTION_{code.ToString(CultureInfo.InvariantCulture)}",
    };

    private static void Report(string checkId, bool passed, string observation)
    {
        if (!passed)
        {
            _failures++;
        }

        Console.WriteLine($"PROBE {(passed ? "PASS" : "FAIL")} {checkId}: {observation}");
    }
}
