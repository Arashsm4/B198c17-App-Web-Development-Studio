// A stand-in Modbus controller serving the controlled register map, fed by the same guard as
// the OPC UA one.

using System.Buffers.Binary;
using System.Globalization;
using Cinerion.PlcGuard;
using FluentModbus;

namespace Cinerion.ModbusPlc;

/// <summary>
/// The controlled Modbus zone stand-in: the register map of CH1-COM-IF-0008, populated from
/// the same guard the OPC UA profile reaches.
/// </summary>
/// <remarks>
/// <para>
/// One guard, two controlled profiles. <see cref="Ch1PlcRuntime"/> is the prepare branch of
/// the controlled <c>FB_CH1_CommandGuard</c>, and it is exactly the same translation the OPC
/// UA controller uses — so a refusal reported here and a refusal reported there are the same
/// refusal, which is what CH1-VVT-TC-0022 means by consistent semantics across adapters.
/// </para>
/// <para>
/// <b>Writing the handshake window does not evaluate anything.</b> Only a write to
/// <see cref="Ch1ModbusMap.HandshakeTrigger"/> runs a guard scan, and the parameters are
/// read at that moment. A controller that evaluated on every register write would act on
/// half an intent whenever a master's frame was split.
/// </para>
/// <para>
/// <b>The answer is written to input registers</b>, which no Modbus function code can reach.
/// The execute permit register is therefore not "refused" to a client — there is no request
/// that could carry the attempt.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0008, CH1-COM-PRO-0001, CH1-AUT-FDS-0001, CH1-CYB-TMD-0001</requirements>
public sealed class Ch1ModbusController
{
    private readonly ModbusTcpServer _server;
    private readonly Ch1PlcRuntime _runtime;
    private ushort _answerCounter;

    public Ch1ModbusController(ModbusTcpServer server, Ch1PlcRuntime runtime)
    {
        _server = server ?? throw new ArgumentNullException(nameof(server));
        _runtime = runtime ?? throw new ArgumentNullException(nameof(runtime));
        _server.RequestValidator = Ch1ModbusAllowlist.Validate;
        _server.EnableRaisingEvents = true;
        _server.RegistersChanged += OnRegistersChanged;
    }

    /// <summary>Writes the read-only configuration band once, at start.</summary>
    public void PublishConfiguration()
    {
        lock (_server.Lock)
        {
            var holding = Holding();
            Write(holding, Ch1ModbusMap.ConfigMapVersion, Ch1ModbusMap.MapVersion);
            Write(holding, Ch1ModbusMap.ConfigSchemaMajor, 1);
            Write(holding, Ch1ModbusMap.ConfigSchemaMinor, 0);
            Write(holding, Ch1ModbusMap.ConfigSchemaPatch, 0);
            Write(holding, Ch1ModbusMap.ConfigControllerBootIdLow, (ushort)(_runtime.BootId.GetHashCode() & 0xFFFF));
            Write(holding, Ch1ModbusMap.ConfigSecurityProfileCode, Ch1ModbusMap.SecurityProfileZonedAllowlist);
            Write(holding, Ch1ModbusMap.ConfigSupportedCommandCount, (ushort)Ch1PlcRuntime.SupportedCommands.Length);
            Write(holding, Ch1ModbusMap.ConfigTelemetryChannelCount, (ushort)Ch1PlcRuntime.TelemetryChannels.Length);

            WriteText(holding, Ch1ModbusMap.ConfigDeviceId, Ch1ModbusMap.LongTextRegisters, _runtime.DeviceId);
            WriteText(holding, Ch1ModbusMap.ConfigDeviceType, Ch1ModbusMap.LongTextRegisters, Ch1PlcRuntime.DeviceType);
            WriteText(holding, Ch1ModbusMap.ConfigFirmwareVersion, Ch1ModbusMap.LongTextRegisters, Ch1PlcRuntime.FirmwareVersion);
            WriteText(holding, Ch1ModbusMap.ConfigConfigurationRevision, Ch1ModbusMap.LongTextRegisters, Ch1PlcRuntime.ConfigurationRevision);
            WriteText(holding, Ch1ModbusMap.ConfigSupportedCommand0, Ch1ModbusMap.LongTextRegisters, Ch1PlcRuntime.SupportedCommands[0]);
            WriteText(holding, Ch1ModbusMap.ConfigSupportedCommand1, Ch1ModbusMap.LongTextRegisters, Ch1PlcRuntime.SupportedCommands[1]);

            ushort[] nameStarts = [Ch1ModbusMap.ConfigChannel0Name, Ch1ModbusMap.ConfigChannel1Name, Ch1ModbusMap.ConfigChannel2Name];
            ushort[] unitStarts = [Ch1ModbusMap.ConfigChannel0Unit, Ch1ModbusMap.ConfigChannel1Unit, Ch1ModbusMap.ConfigChannel2Unit];
            for (var index = 0; index < Ch1PlcRuntime.TelemetryChannels.Length; index++)
            {
                var channel = Ch1PlcRuntime.TelemetryChannels[index];
                WriteText(holding, nameStarts[index], Ch1ModbusMap.ShortTextRegisters, channel.ChannelId);
                WriteText(holding, unitStarts[index], Ch1ModbusMap.UnitTextRegisters, channel.Unit);
            }

            // The guard has answered nothing yet, and the band says so rather than reading
            // as a stale acceptance.
            var input = Input();
            Write(input, Ch1ModbusMap.AnswerState, Ch1PlcRuntime.GuardState.Idle);
            Write(input, Ch1ModbusMap.AnswerReasonCode, Ch1PlcRuntime.Reason.None);
            Write(input, Ch1ModbusMap.AnswerAccepted, 0);
            Write(input, Ch1ModbusMap.AnswerExecutePermit, 0);
            Write(input, Ch1ModbusMap.AnswerCounter, 0);
            Write(input, Ch1ModbusMap.AnswerDeferredCheckCount, 2);
            Write(input, Ch1ModbusMap.AnswerDeferredCheckFirst, 206);
            Write(input, Ch1ModbusMap.AnswerDeferredCheckSecond, 207);
        }
    }

    /// <summary>One sampling cycle into the read-only telemetry band.</summary>
    public void PublishSample()
    {
        lock (_server.Lock)
        {
            var input = Input();
            foreach (var (channel, value, _, _, sequence) in _runtime.Sample())
            {
                var register = channel.ChannelId switch
                {
                    "temperature" => Ch1ModbusMap.TelemetryTemperature,
                    "position" => Ch1ModbusMap.TelemetryPosition,
                    "vibration_rms" => Ch1ModbusMap.TelemetryVibrationRms,
                    _ => ushort.MaxValue,
                };

                if (register != ushort.MaxValue)
                {
                    Write(input, register, unchecked((ushort)(short)Math.Round(value * Ch1ModbusMap.TelemetryScale)));
                }

                Write(input, Ch1ModbusMap.TelemetrySampleCounter, (ushort)(sequence & 0xFFFF));
            }

            // Simulated, never Good. A stand-in that claimed Good quality would be
            // indistinguishable from conditioned I/O to everything downstream.
            Write(input, Ch1ModbusMap.TelemetryQuality, Ch1ModbusMap.TelemetryQualitySimulated);
        }
    }

    private void OnRegistersChanged(object? sender, RegistersChangedEventArgs args)
    {
        if (!args.Registers.Contains(Ch1ModbusMap.HandshakeTrigger))
        {
            return;
        }

        lock (_server.Lock)
        {
            var holding = Holding();
            if (Read(holding, Ch1ModbusMap.HandshakeTrigger) != Ch1ModbusMap.HandshakeTriggerEvaluate)
            {
                return;
            }

            // Consumed immediately, so a trigger left set cannot re-arm anything. The SCL
            // evaluates a rising edge for the same reason: a held input must never re-arm.
            Write(holding, Ch1ModbusMap.HandshakeTrigger, 0);

            var schemaMajor = Read(holding, Ch1ModbusMap.HandshakeSchemaMajor);
            Span<byte> commandId = stackalloc byte[16];
            for (var index = 0; index < Ch1ModbusMap.HandshakeCommandIdRegisters; index++)
            {
                BinaryPrimitives.WriteUInt16BigEndian(
                    commandId[(index * 2)..], Read(holding, (ushort)(Ch1ModbusMap.HandshakeCommandId + index)));
            }

            var sequence = ((long)Read(holding, Ch1ModbusMap.HandshakeSequenceHigh) << 16)
                | Read(holding, Ch1ModbusMap.HandshakeSequenceLow);
            var expiry = ((long)Read(holding, Ch1ModbusMap.HandshakeExpiresAtHigh) << 16)
                | Read(holding, Ch1ModbusMap.HandshakeExpiresAtLow);

            var result = _runtime.Prepare(
                string.Create(CultureInfo.InvariantCulture, $"{schemaMajor}.0.0"),
                new Guid(commandId, bigEndian: true),
                sequence,
                ReadText(holding, Ch1ModbusMap.HandshakeConfigurationRevision, Ch1ModbusMap.HandshakeConfigurationRevisionRegisters),
                DateTimeOffset.FromUnixTimeSeconds(expiry),
                ReadText(holding, Ch1ModbusMap.HandshakeCommandType, Ch1ModbusMap.HandshakeCommandTypeRegisters));

            var input = Input();
            Write(input, Ch1ModbusMap.AnswerState, result.State);
            Write(input, Ch1ModbusMap.AnswerReasonCode, result.ReasonCode);
            Write(input, Ch1ModbusMap.AnswerAccepted, (ushort)(result.Accepted ? 1 : 0));
            // Never anything but zero on this link, and written every time rather than left
            // alone: an execute permit needs a credential proof and a local button edge,
            // neither of which can arrive over Modbus.
            Write(input, Ch1ModbusMap.AnswerExecutePermit, 0);
            Write(input, Ch1ModbusMap.AnswerLastSequenceHigh, (ushort)((_runtime.LastSequenceNumber >> 16) & 0xFFFF));
            Write(input, Ch1ModbusMap.AnswerLastSequenceLow, (ushort)(_runtime.LastSequenceNumber & 0xFFFF));
            Write(input, Ch1ModbusMap.AnswerCounter, ++_answerCounter);
        }
    }

    // ------------------------------------------------------------------ register access

    // The register buffers are addressed as BYTES here and written big-endian, because that
    // is the order Modbus puts on the wire and this library copies its buffer straight
    // there. Writing them as host-order shorts published a map version of 256 for a value of
    // 1 — found by reading the map back over a socket, which is the only way a byte-order
    // fault is ever found.
    private Span<byte> Holding() => _server.GetHoldingRegisterBuffer((byte)Ch1ModbusMap.UnitIdentifier);

    private Span<byte> Input() => _server.GetInputRegisterBuffer((byte)Ch1ModbusMap.UnitIdentifier);

    private static void Write(Span<byte> registers, ushort address, ushort value) =>
        BinaryPrimitives.WriteUInt16BigEndian(registers[(address * 2)..], value);

    private static ushort Read(Span<byte> registers, ushort address) =>
        BinaryPrimitives.ReadUInt16BigEndian(registers[(address * 2)..]);

    private static void WriteText(Span<byte> registers, ushort address, ushort length, string value)
    {
        for (var index = 0; index < length; index++)
        {
            var high = (index * 2) < value.Length ? (byte)value[index * 2] : (byte)0;
            var low = ((index * 2) + 1) < value.Length ? (byte)value[(index * 2) + 1] : (byte)0;
            Write(registers, (ushort)(address + index), (ushort)((high << 8) | low));
        }
    }

    private static string ReadText(Span<byte> registers, ushort address, ushort length)
    {
        Span<char> characters = stackalloc char[length * 2];
        var written = 0;
        for (var index = 0; index < length; index++)
        {
            var register = Read(registers, (ushort)(address + index));
            characters[written++] = (char)(register >> 8);
            characters[written++] = (char)(register & 0xFF);
        }

        var end = characters[..written].IndexOf('\0');
        return new string(characters[..(end < 0 ? written : end)]).TrimEnd();
    }
}
