// The command state machine as an executable TypeScript model.

import { createHash, randomUUID } from 'node:crypto';

export type Uuid = `${string}-${string}-${string}-${string}-${string}`;

export type Role =
  | 'Engineer'
  | 'ProjectManager'
  | 'LocalConfirmer'
  | 'Inspector'
  | 'DeviceController'
  | 'Auditor';

export interface Actor {
  id: string;
  kind: 'Human' | 'Device' | 'Service' | 'System';
  roles: readonly Role[];
  authenticationStrength: 'SingleFactor' | 'Mfa' | 'StepUpPhishingResistant' | 'MutualTls';
  projectId: Uuid;
  cellIds: readonly Uuid[];
}

export interface CellSnapshot {
  projectId: Uuid;
  siteId: Uuid;
  cellId: Uuid;
  assetId: Uuid;
  controllerId: string;
  controllerBootId: Uuid;
  operatingState: 'Initialising' | 'Idle' | 'Prepared' | 'Executing' | 'Complete' | 'FaultLatched';
  configurationRevision: string;
  workOrderId: Uuid;
  partId: Uuid;
  controllerOnline: boolean;
  startEnable: boolean;
  stopCircuitHealthy: boolean;
  guardHealthy: boolean;
  actuatorHome: boolean;
  buttonPressed: boolean;
  faultCauseActive: boolean;
}

export interface PrepareIntent {
  commandType: string;
  projectId: Uuid;
  siteId: Uuid;
  cellId: Uuid;
  assetId: Uuid;
  workOrderId: Uuid;
  partId: Uuid;
  procedureRevision: string;
  configurationRevision: string;
  expectedStateHash: string;
  sequence: number;
  expiresAt: Date;
  idempotencyKey: string;
  parameters: Readonly<Record<string, string | number | boolean>>;
}

export interface CredentialProof {
  proofId: Uuid;
  commandId: Uuid;
  confirmationId: Uuid;
  cellId: Uuid;
  controllerId: string;
  credentialId: Uuid;
  userId: string;
  cryptographicallyVerified: boolean;
  userVerified: boolean;
  verifiedAt: Date;
  expiresAt: Date;
}

export interface LocalButtonObservation {
  commandId: Uuid;
  confirmationId: Uuid;
  cellId: Uuid;
  controllerId: string;
  controllerBootId: Uuid;
  source: 'PhysicalInput' | 'RemoteApi' | 'SimulatorInjection';
  previousState: boolean;
  currentState: boolean;
  observedAt: Date;
}

export type CommandState =
  | 'AwaitingCredential'
  | 'AwaitingButton'
  | 'Committed'
  | 'Executing'
  | 'Completed'
  | 'Cancelled'
  | 'Rejected'
  | 'FaultLatched';

export interface CommandTransaction {
  commandId: Uuid;
  confirmationId: Uuid;
  correlationId: Uuid;
  requesterId: string;
  intent: PrepareIntent;
  preparedAt: Date;
  preparedControllerBootId: Uuid;
  state: CommandState;
  version: number;
  credentialProof?: CredentialProof;
  localCommitId?: Uuid;
  terminalReason?: string;
}

export class RuleViolation extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.code = code;
    this.name = 'RuleViolation';
  }
}

const stableObject = (value: unknown): unknown => {
  if (Array.isArray(value)) return value.map(stableObject);
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, child]) => [key, stableObject(child)]),
    );
  }
  return value;
};

export const sha256 = (value: unknown): string =>
  createHash('sha256').update(JSON.stringify(stableObject(value))).digest('hex');

export const stateHash = (cell: CellSnapshot): string =>
  sha256({
    projectId: cell.projectId,
    siteId: cell.siteId,
    cellId: cell.cellId,
    assetId: cell.assetId,
    controllerId: cell.controllerId,
    controllerBootId: cell.controllerBootId,
    operatingState: cell.operatingState,
    configurationRevision: cell.configurationRevision,
    workOrderId: cell.workOrderId,
    partId: cell.partId,
    controllerOnline: cell.controllerOnline,
    startEnable: cell.startEnable,
    stopCircuitHealthy: cell.stopCircuitHealthy,
    guardHealthy: cell.guardHealthy,
    actuatorHome: cell.actuatorHome,
    faultCauseActive: cell.faultCauseActive,
  });

function assert(condition: boolean, code: string, message: string): asserts condition {
  if (!condition) throw new RuleViolation(code, message);
}

const assertScope = (intent: PrepareIntent, cell: CellSnapshot): void => {
  assert(intent.projectId === cell.projectId, 'CMD_PROJECT_MISMATCH', 'Command project does not match cell.');
  assert(intent.siteId === cell.siteId, 'CMD_SITE_MISMATCH', 'Command site does not match cell.');
  assert(intent.cellId === cell.cellId, 'CMD_CELL_MISMATCH', 'Command cell does not match cell.');
  assert(intent.assetId === cell.assetId, 'CMD_ASSET_MISMATCH', 'Command asset does not match cell.');
  assert(intent.workOrderId === cell.workOrderId, 'CMD_WORK_ORDER_MISMATCH', 'Work order is not active at the cell.');
  assert(intent.partId === cell.partId, 'CMD_PART_MISMATCH', 'Physical part is not active at the cell.');
  assert(
    intent.configurationRevision === cell.configurationRevision,
    'CMD_CONFIGURATION_MISMATCH',
    'Controller configuration revision does not match the command.',
  );
};

const assertPermissives = (cell: CellSnapshot): void => {
  assert(cell.controllerOnline, 'INTERLOCK_CONTROLLER_OFFLINE', 'Cell controller is offline.');
  assert(cell.startEnable, 'INTERLOCK_START_DISABLED', 'Local start-enable input is not active.');
  assert(cell.stopCircuitHealthy, 'INTERLOCK_STOP_UNHEALTHY', 'Local stop circuit is not healthy.');
  assert(cell.guardHealthy, 'INTERLOCK_GUARD_OPEN', 'Guard/interlock input is not healthy.');
  assert(cell.actuatorHome, 'INTERLOCK_NOT_HOME', 'Actuator is not in the required home state.');
  assert(!cell.faultCauseActive, 'INTERLOCK_FAULT_ACTIVE', 'A fault cause is still active.');
  assert(cell.operatingState === 'Idle', 'CMD_STATE_NOT_IDLE', 'Cell is not in Idle.');
};

/** @requirement CH1-CMD-FR-0001 CH1-CMD-FR-0002 CH1-CMD-FR-0004 CH1-CMD-FR-0006 */
export function prepareCommand(
  intent: PrepareIntent,
  actor: Actor,
  cell: CellSnapshot,
  now: Date,
): CommandTransaction {
  assert(actor.kind === 'Human', 'AUTH_HUMAN_REQUIRED', 'A human identity is required to prepare a procedure.');
  assert(
    actor.roles.includes('Engineer') || actor.roles.includes('ProjectManager'),
    'AUTH_ROLE_REQUIRED',
    'Engineer or Project Manager role is required.',
  );
  assert(
    actor.authenticationStrength === 'StepUpPhishingResistant',
    'AUTH_STEP_UP_REQUIRED',
    'A recent phishing-resistant step-up is required.',
  );
  assert(actor.projectId === intent.projectId, 'AUTH_PROJECT_SCOPE', 'Actor is outside the project scope.');
  assert(actor.cellIds.includes(intent.cellId), 'AUTH_CELL_SCOPE', 'Actor is outside the cell scope.');
  assert(/^[A-Z][A-Z0-9_]{2,63}$/.test(intent.commandType), 'CMD_TYPE_INVALID', 'Command type is not semantic.');
  assert(intent.sequence > 0 && Number.isSafeInteger(intent.sequence), 'CMD_SEQUENCE_INVALID', 'Sequence must be a positive integer.');
  assert(intent.idempotencyKey.length >= 16 && intent.idempotencyKey.length <= 128, 'CMD_IDEMPOTENCY_INVALID', 'Idempotency key length is invalid.');
  const ttlMs = intent.expiresAt.getTime() - now.getTime();
  assert(ttlMs >= 5_000 && ttlMs <= 120_000, 'CMD_TTL_INVALID', 'Prepared-command TTL must be between 5 and 120 seconds.');
  assert(!cell.buttonPressed, 'CONFIRM_BUTTON_HELD', 'Confirmation input is already active before arming.');
  assertScope(intent, cell);
  assertPermissives(cell);
  assert(intent.expectedStateHash === stateHash(cell), 'CMD_EXPECTED_STATE_STALE', 'Expected state is stale or altered.');

  return {
    commandId: randomUUID(),
    confirmationId: randomUUID(),
    correlationId: randomUUID(),
    requesterId: actor.id,
    intent,
    preparedAt: now,
    preparedControllerBootId: cell.controllerBootId,
    state: 'AwaitingCredential',
    version: 1,
  };
}

/** @requirement CH1-CMD-FR-0003 CH1-IAM-FR-0005 CH1-IAM-FR-0007 */
export function recordCredentialProof(
  command: CommandTransaction,
  proof: CredentialProof,
  controller: Actor,
  now: Date,
): CommandTransaction {
  assert(command.state === 'AwaitingCredential', 'CMD_STATE_INVALID', 'Command is not awaiting a credential.');
  assert(controller.kind === 'Device', 'AUTH_DEVICE_REQUIRED', 'Only the bound controller may submit presence proof.');
  assert(controller.roles.includes('DeviceController'), 'AUTH_CONTROLLER_ROLE', 'Device lacks controller role.');
  assert(controller.authenticationStrength === 'MutualTls', 'AUTH_MTLS_REQUIRED', 'Controller mTLS identity is required.');
  assert(controller.cellIds.includes(command.intent.cellId), 'AUTH_CELL_SCOPE', 'Controller is outside cell scope.');
  assert(proof.commandId === command.commandId, 'PROOF_COMMAND_MISMATCH', 'Credential proof is for another command.');
  assert(proof.confirmationId === command.confirmationId, 'PROOF_CONFIRMATION_MISMATCH', 'Credential proof challenge is not bound.');
  assert(proof.cellId === command.intent.cellId, 'PROOF_CELL_MISMATCH', 'Credential proof is for another cell.');
  assert(proof.controllerId === controller.id, 'PROOF_CONTROLLER_MISMATCH', 'Credential proof came from another controller.');
  assert(proof.cryptographicallyVerified, 'PROOF_CRYPTOGRAPHY_INVALID', 'Cryptographic challenge-response failed.');
  assert(proof.userVerified, 'PROOF_USER_VERIFICATION_REQUIRED', 'Credential user verification was not satisfied.');
  assert(proof.verifiedAt.getTime() <= now.getTime(), 'PROOF_TIME_INVALID', 'Credential proof is from the future.');
  assert(proof.expiresAt.getTime() > now.getTime(), 'PROOF_EXPIRED', 'Credential proof has expired.');
  assert(command.intent.expiresAt.getTime() > now.getTime(), 'CMD_EXPIRED', 'Prepared command has expired.');

  return { ...command, credentialProof: proof, state: 'AwaitingButton', version: command.version + 1 };
}

/** @requirement CH1-CMD-FR-0003 CH1-CMD-FR-0005 CH1-CMD-FR-0007 CH1-CMD-FR-0008 */
export function localCommit(
  command: CommandTransaction,
  observation: LocalButtonObservation,
  controller: Actor,
  cell: CellSnapshot,
  now: Date,
): CommandTransaction {
  assert(command.state === 'AwaitingButton', 'CMD_STATE_INVALID', 'Command is not awaiting a button edge.');
  assert(command.credentialProof !== undefined, 'PROOF_REQUIRED', 'Credential proof is missing.');
  assert(controller.kind === 'Device' && controller.roles.includes('DeviceController'), 'AUTH_DEVICE_REQUIRED', 'Only the bound controller may commit.');
  assert(controller.authenticationStrength === 'MutualTls', 'AUTH_MTLS_REQUIRED', 'Controller mTLS identity is required.');
  assert(observation.source === 'PhysicalInput', 'REMOTE_CONFIRMATION_FORBIDDEN', 'Remote or simulated input cannot commit this profile.');
  assert(!observation.previousState && observation.currentState, 'CONFIRM_EDGE_REQUIRED', 'A new rising physical edge is required.');
  assert(observation.commandId === command.commandId, 'BUTTON_COMMAND_MISMATCH', 'Button event is for another command.');
  assert(observation.confirmationId === command.confirmationId, 'BUTTON_CONFIRMATION_MISMATCH', 'Button event is not bound to the challenge.');
  assert(observation.cellId === command.intent.cellId, 'BUTTON_CELL_MISMATCH', 'Button event is for another cell.');
  assert(observation.controllerId === controller.id, 'BUTTON_CONTROLLER_MISMATCH', 'Button event came from another controller.');
  assert(observation.controllerBootId === command.preparedControllerBootId, 'CONTROLLER_REBOOTED', 'Controller restarted after preparation.');
  assert(cell.controllerBootId === command.preparedControllerBootId, 'CONTROLLER_REBOOTED', 'Current boot identity changed.');
  assert(command.intent.expiresAt.getTime() > now.getTime(), 'CMD_EXPIRED', 'Prepared command has expired.');
  assert(command.credentialProof.expiresAt.getTime() > now.getTime(), 'PROOF_EXPIRED', 'Credential proof has expired.');
  assertScope(command.intent, cell);
  assertPermissives(cell);
  assert(command.intent.expectedStateHash === stateHash(cell), 'CMD_EXPECTED_STATE_CHANGED', 'Material cell state changed after preparation.');

  return {
    ...command,
    localCommitId: randomUUID(),
    state: 'Committed',
    version: command.version + 1,
  };
}

export function beginExecution(command: CommandTransaction): CommandTransaction {
  assert(command.state === 'Committed', 'CMD_STATE_INVALID', 'Only a locally committed command may execute.');
  return { ...command, state: 'Executing', version: command.version + 1 };
}

export function completeExecution(command: CommandTransaction): CommandTransaction {
  assert(command.state === 'Executing', 'CMD_STATE_INVALID', 'Only an executing command may complete.');
  return { ...command, state: 'Completed', version: command.version + 1 };
}

export function latchFault(command: CommandTransaction, reason: string): CommandTransaction {
  assert(command.state === 'Executing' || command.state === 'Committed', 'CMD_STATE_INVALID', 'Fault can only latch after commit.');
  assert(reason.trim().length > 0, 'FAULT_REASON_REQUIRED', 'Fault reason is required.');
  return { ...command, state: 'FaultLatched', terminalReason: reason, version: command.version + 1 };
}

/** @requirement CH1-CMD-FR-0009 */
export function reconcileRestart(command: CommandTransaction, currentBootId: Uuid): CommandTransaction {
  if (command.state === 'AwaitingCredential' || command.state === 'AwaitingButton') {
    return {
      ...command,
      state: 'Cancelled',
      terminalReason: currentBootId === command.preparedControllerBootId ? 'SERVICE_RESTART' : 'CONTROLLER_RESTART',
      version: command.version + 1,
    };
  }
  return command;
}

/** @requirement CH1-CMD-FR-0010 */
export function recoverFault(
  command: CommandTransaction,
  actor: Actor,
  cell: CellSnapshot,
  reset: { source: 'PhysicalInput' | 'RemoteApi'; previousState: boolean; currentState: boolean },
): CommandTransaction {
  assert(command.state === 'FaultLatched', 'CMD_STATE_INVALID', 'Command is not fault latched.');
  assert(actor.kind === 'Human' && actor.roles.includes('LocalConfirmer'), 'AUTH_LOCAL_CONFIRMER_REQUIRED', 'Local Confirmer role is required.');
  assert(actor.authenticationStrength === 'StepUpPhishingResistant', 'AUTH_STEP_UP_REQUIRED', 'Step-up authentication is required.');
  assert(actor.cellIds.includes(cell.cellId), 'AUTH_CELL_SCOPE', 'Actor is outside the cell scope.');
  assert(reset.source === 'PhysicalInput', 'REMOTE_RESET_FORBIDDEN', 'Fault recovery requires a local reset input.');
  assert(!reset.previousState && reset.currentState, 'RESET_EDGE_REQUIRED', 'A new reset edge is required.');
  assert(!cell.faultCauseActive, 'FAULT_CAUSE_ACTIVE', 'Fault cause is still active.');
  assert(cell.stopCircuitHealthy && cell.guardHealthy, 'RECOVERY_INTERLOCK_INVALID', 'Recovery interlocks are not healthy.');
  return { ...command, state: 'Cancelled', terminalReason: 'FAULT_RECOVERED_LOCALLY', version: command.version + 1 };
}
