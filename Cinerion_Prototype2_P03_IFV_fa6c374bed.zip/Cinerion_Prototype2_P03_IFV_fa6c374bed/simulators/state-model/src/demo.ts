// A scripted demo that walks the command model through its paces.

import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

import { AuditChain } from './audit.ts';
import {
  beginExecution,
  completeExecution,
  localCommit,
  prepareCommand,
  recordCredentialProof,
  stateHash,
  type Actor,
  type CellSnapshot,
  type Uuid,
} from './model.ts';

const id = (): Uuid => randomUUID();
const startedAt = new Date('2026-08-06T12:00:00.000Z');
const projectId = id();
const siteId = id();
const cellId = id();
const assetId = id();
const workOrderId = id();
const partId = id();
const controllerBootId = id();

const cell: CellSnapshot = {
  projectId,
  siteId,
  cellId,
  assetId,
  controllerId: 'CH1-DEV-CELL-0001',
  controllerBootId,
  operatingState: 'Idle',
  configurationRevision: 'CFG-REFAB-P01-R01',
  workOrderId,
  partId,
  controllerOnline: true,
  startEnable: true,
  stopCircuitHealthy: true,
  guardHealthy: true,
  actuatorHome: true,
  buttonPressed: false,
  faultCauseActive: false,
};

const engineer: Actor = {
  id: 'USR-IR-ENGINEER',
  kind: 'Human',
  roles: ['Engineer'],
  authenticationStrength: 'StepUpPhishingResistant',
  projectId,
  cellIds: [cellId],
};
const controller: Actor = {
  id: cell.controllerId,
  kind: 'Device',
  roles: ['DeviceController'],
  authenticationStrength: 'MutualTls',
  projectId,
  cellIds: [cellId],
};

const prepared = prepareCommand({
  commandType: 'RUN_TENSION_CALIBRATION',
  projectId,
  siteId,
  cellId,
  assetId,
  workOrderId,
  partId,
  procedureRevision: 'CH1-REFAB-PROC-0001-R01',
  configurationRevision: cell.configurationRevision,
  expectedStateHash: stateHash(cell),
  sequence: 1,
  expiresAt: new Date(startedAt.getTime() + 60_000),
  idempotencyKey: 'demo-idempotency-0001',
  parameters: { targetTensionN: 1.2, maxTravelMm: 25 },
}, engineer, cell, startedAt);

const credentialled = recordCredentialProof(prepared, {
  proofId: id(),
  commandId: prepared.commandId,
  confirmationId: prepared.confirmationId,
  cellId,
  controllerId: controller.id,
  credentialId: id(),
  userId: 'USR-LOCAL-CONFIRMER-01',
  cryptographicallyVerified: true,
  userVerified: true,
  verifiedAt: new Date(startedAt.getTime() + 2_000),
  expiresAt: new Date(startedAt.getTime() + 22_000),
}, controller, new Date(startedAt.getTime() + 2_000));

const committed = localCommit(credentialled, {
  commandId: prepared.commandId,
  confirmationId: prepared.confirmationId,
  cellId,
  controllerId: controller.id,
  controllerBootId,
  source: 'PhysicalInput',
  previousState: false,
  currentState: true,
  observedAt: new Date(startedAt.getTime() + 4_000),
}, controller, cell, new Date(startedAt.getTime() + 4_000));
const completed = completeExecution(beginExecution(committed));

const audit = new AuditChain();
for (const [index, [eventType, actor, kind, decision, reason]] of [
  ['CommandPrepared', engineer.id, 'Human', 'Allowed', 'POLICY_SATISFIED'],
  ['CredentialProofAccepted', 'USR-LOCAL-CONFIRMER-01', 'Human', 'Allowed', 'CRYPTOGRAPHIC_PRESENCE_VERIFIED'],
  ['LocalCommitAccepted', controller.id, 'Device', 'Allowed', 'PHYSICAL_EDGE_AND_INTERLOCKS_VALID'],
  ['ProcedureCompleted', controller.id, 'Device', 'Completed', 'SEQUENCE_COMPLETE'],
].entries()) {
  audit.append({
    eventType: String(eventType),
    actorId: String(actor),
    actorKind: kind as 'Human' | 'Device',
    projectId,
    objectType: 'CommandTransaction',
    objectId: completed.commandId,
    correlationId: completed.correlationId,
    occurredAt: new Date(startedAt.getTime() + index * 2_000),
    decision: String(decision),
    reasonCode: String(reason),
    payload: { commandState: index === 3 ? completed.state : undefined, partId, workOrderId },
  });
}

const evidence = {
  classification: 'CONFIDENTIAL - PROJECT INTERNAL',
  project: 'Cinerion',
  namespace: 'CH1',
  profile: 'Simulation',
  generatedAt: new Date().toISOString(),
  command: completed,
  cell,
  auditEvents: audit.events(),
  auditVerification: audit.verify(),
};

const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const output = resolve(repoRoot, 'evidence/generated/simulator-demo.json');
mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, `${JSON.stringify(evidence, null, 2)}\n`);
console.log(JSON.stringify({ output, state: completed.state, audit: audit.verify() }, null, 2));

