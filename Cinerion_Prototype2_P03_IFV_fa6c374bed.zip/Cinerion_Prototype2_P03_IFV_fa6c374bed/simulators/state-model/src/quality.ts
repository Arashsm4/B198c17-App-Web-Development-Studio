// The quality rules as an executable TypeScript model.

import { randomUUID } from 'node:crypto';
import { RuleViolation, type Actor, type Uuid } from './model.ts';

export type PartStatus = 'InProcess' | 'Hold' | 'Accepted' | 'Released';

export interface PartRecord {
  projectId: Uuid;
  partId: Uuid;
  workOrderId: Uuid;
  productRevision: string;
  operatorId: string;
  status: PartStatus;
  openNcrIds: Uuid[];
  measurements: Measurement[];
  release?: ReleaseRecord;
}

export interface Measurement {
  measurementId: Uuid;
  characteristic: string;
  value: number;
  unit: string;
  lowerLimit: number;
  upperLimit: number;
  mandatory: boolean;
  sourceDeviceId: string;
  supersedesMeasurementId?: Uuid;
  calibrationValid: boolean;
  measuredAt: string;
  result: 'Pass' | 'Fail';
}

export interface ReleaseRecord {
  releaseId: Uuid;
  inspectorId: string;
  releasedAt: string;
}

/** @requirement CH1-QMS-FR-0002 CH1-QMS-FR-0003 CH1-QMS-FR-0004 CH1-QMS-FR-0006 */
export function recordMeasurement(
  part: PartRecord,
  input: Omit<Measurement, 'measurementId' | 'result' | 'measuredAt'>,
  now: Date,
): PartRecord {
  if (!input.calibrationValid) throw new RuleViolation('INSTRUMENT_CALIBRATION_EXPIRED', 'Instrument calibration is not valid.');
  if (!input.characteristic.trim() || !input.unit.trim() || !input.sourceDeviceId.trim()) {
    throw new RuleViolation('MEASUREMENT_CONTEXT_REQUIRED', 'Characteristic, engineering unit, and source device are required.');
  }
  if (input.supersedesMeasurementId) {
    const source = part.measurements.find((item) => item.measurementId === input.supersedesMeasurementId);
    if (!source) throw new RuleViolation('RETEST_SOURCE_NOT_FOUND', 'Superseded measurement does not belong to this part.');
    if (!source.mandatory || source.result !== 'Fail') {
      throw new RuleViolation('RETEST_SOURCE_NOT_FAILED', 'A retest may supersede only a failed mandatory result.');
    }
    if (source.characteristic !== input.characteristic || source.unit !== input.unit) {
      throw new RuleViolation('RETEST_CHARACTERISTIC_MISMATCH', 'Retest characteristic and unit must match the failed result.');
    }
    if (part.measurements.some((item) => item.supersedesMeasurementId === input.supersedesMeasurementId)) {
      throw new RuleViolation('RETEST_ALREADY_RECORDED', 'The failed measurement already has a controlled retest.');
    }
  }
  if (!Number.isFinite(input.value) || input.lowerLimit > input.upperLimit) {
    throw new RuleViolation('MEASUREMENT_INVALID', 'Measurement or limits are invalid.');
  }
  const result = input.value >= input.lowerLimit && input.value <= input.upperLimit ? 'Pass' : 'Fail';
  const measurement: Measurement = {
    ...input,
    measurementId: randomUUID(),
    measuredAt: now.toISOString(),
    result,
  };
  return {
    ...part,
    measurements: [...part.measurements, measurement],
    status: input.mandatory && result === 'Fail' ? 'Hold' : part.status,
  };
}

export function raiseNcr(part: PartRecord): { part: PartRecord; ncrId: Uuid } {
  if (part.status !== 'Hold') throw new RuleViolation('PART_NOT_ON_HOLD', 'An NCR requires a held part.');
  const ncrId = randomUUID();
  return { part: { ...part, openNcrIds: [...part.openNcrIds, ncrId] }, ncrId };
}

export function closeNcrAfterPassingRetest(part: PartRecord, ncrId: Uuid): PartRecord {
  if (!part.openNcrIds.includes(ncrId)) throw new RuleViolation('NCR_NOT_OPEN', 'NCR is not open for this part.');
  const retest = part.measurements.at(-1);
  if (!retest?.mandatory || retest.result !== 'Pass') {
    throw new RuleViolation('RETEST_NOT_PASSING', 'A passing mandatory retest is required.');
  }
  if (!retest.supersedesMeasurementId) throw new RuleViolation('RETEST_SOURCE_NOT_FOUND', 'Passing retest is not linked to the failed mandatory measurement.');
  const remaining = part.openNcrIds.filter((id) => id !== ncrId);
  return { ...part, openNcrIds: remaining, status: remaining.length === 0 ? 'Accepted' : 'Hold' };
}

/** @requirement CH1-QMS-FR-0005 */
export function releasePart(part: PartRecord, inspector: Actor, now: Date): PartRecord {
  if (inspector.kind !== 'Human' || !inspector.roles.includes('Inspector')) {
    throw new RuleViolation('INSPECTOR_REQUIRED', 'Independent Inspector authority is required.');
  }
  if (inspector.authenticationStrength !== 'StepUpPhishingResistant') {
    throw new RuleViolation('AUTH_STEP_UP_REQUIRED', 'Release requires recent phishing-resistant step-up.');
  }
  if (inspector.projectId !== part.projectId) {
    throw new RuleViolation('AUTH_PROJECT_SCOPE', 'Inspector is outside the part project scope.');
  }
  if (inspector.id === part.operatorId) {
    throw new RuleViolation('SEGREGATION_OF_DUTIES', 'The operation performer cannot release the component.');
  }
  if (part.status !== 'Accepted' || part.openNcrIds.length > 0) {
    throw new RuleViolation('PART_NOT_ACCEPTABLE', 'Part is not accepted or has open NCRs.');
  }
  const currentMandatory = new Map<string, Measurement>();
  for (const measurement of part.measurements) {
    if (measurement.mandatory) currentMandatory.set(`${measurement.characteristic}\u0000${measurement.unit}`, measurement);
  }
  if (currentMandatory.size === 0 || [...currentMandatory.values()].some((item) => item.result !== 'Pass')) {
    throw new RuleViolation('MANDATORY_TESTS_INCOMPLETE', 'The current result for every mandatory characteristic must pass.');
  }
  return {
    ...part,
    status: 'Released',
    release: { releaseId: randomUUID(), inspectorId: inspector.id, releasedAt: now.toISOString() },
  };
}
