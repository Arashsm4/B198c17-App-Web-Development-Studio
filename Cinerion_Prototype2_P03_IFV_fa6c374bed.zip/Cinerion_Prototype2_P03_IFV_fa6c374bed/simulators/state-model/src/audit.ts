// The audit chain as a small executable TypeScript model.

import { randomUUID } from 'node:crypto';
import { sha256, type Uuid } from './model.ts';

export interface AuditInput {
  eventType: string;
  actorId: string;
  actorKind: 'Human' | 'Device' | 'Service' | 'System';
  projectId: Uuid;
  objectType: string;
  objectId: string;
  correlationId: Uuid;
  occurredAt: Date;
  decision: string;
  reasonCode: string;
  payload: unknown;
  timeQuality?: 'Qualified' | 'Unqualified' | 'Simulated';
}

export interface AuditEvent extends Omit<AuditInput, 'payload' | 'occurredAt'> {
  eventId: Uuid;
  sequence: number;
  occurredAt: string;
  timeQuality: 'Qualified' | 'Unqualified' | 'Simulated';
  payloadHash: string;
  previousHash: string;
  eventHash: string;
}

const genesisHash = '0'.repeat(64);

/** @requirement CH1-TRC-FR-0002 CH1-NFR-AUD-0001 */
export class AuditChain {
  readonly #events: AuditEvent[] = [];

  append(input: AuditInput): AuditEvent {
    const eventWithoutHash = {
      eventId: randomUUID(),
      sequence: this.#events.length + 1,
      eventType: input.eventType,
      actorId: input.actorId,
      actorKind: input.actorKind,
      projectId: input.projectId,
      objectType: input.objectType,
      objectId: input.objectId,
      correlationId: input.correlationId,
      occurredAt: input.occurredAt.toISOString(),
      timeQuality: input.timeQuality ?? 'Simulated',
      decision: input.decision,
      reasonCode: input.reasonCode,
      payloadHash: sha256(input.payload),
      previousHash: this.#events.at(-1)?.eventHash ?? genesisHash,
    };
    const event = { ...eventWithoutHash, eventHash: sha256(eventWithoutHash) };
    this.#events.push(event);
    return structuredClone(event);
  }

  events(): readonly AuditEvent[] {
    return structuredClone(this.#events);
  }

  verify(): { valid: boolean; checked: number; failureAt?: number } {
    return verifyEvents(this.#events);
  }
}

/**
 * Verifies a sequence of events that came from somewhere else - a snapshot, a stored
 * record, or an export handed to a reader. CH1-TRC-FR-0002 asks that an altered or
 * deleted event break verification and be reported, which is a property of the events
 * themselves rather than of the object that produced them.
 */
export function verifyEvents(
  events: readonly AuditEvent[],
): { valid: boolean; checked: number; failureAt?: number } {
  let previousHash = genesisHash;
  for (const event of events) {
    if (event.previousHash !== previousHash) return { valid: false, checked: event.sequence - 1, failureAt: event.sequence };
    const { eventHash, ...withoutHash } = event;
    if (sha256(withoutHash) !== eventHash) return { valid: false, checked: event.sequence - 1, failureAt: event.sequence };
    previousHash = eventHash;
  }
  return { valid: true, checked: events.length };
}
