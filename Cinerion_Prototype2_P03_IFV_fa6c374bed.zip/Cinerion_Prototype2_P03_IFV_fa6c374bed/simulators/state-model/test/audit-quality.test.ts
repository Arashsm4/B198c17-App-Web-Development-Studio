// Tests for the audit and quality models.

import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import test from 'node:test';

import { AuditChain, verifyEvents } from '../src/audit.ts';
import { closeNcrAfterPassingRetest, raiseNcr, recordMeasurement, releasePart, type PartRecord } from '../src/quality.ts';
import { RuleViolation, type Actor, type Uuid } from '../src/model.ts';

const id = (): Uuid => randomUUID();

test('CH1-VVT-TC-0051 audit events form a verifiable hash chain that breaks on alteration', () => {
  const chain = new AuditChain();
  const projectId = id();
  const correlationId = id();
  chain.append({
    eventType: 'CommandPrepared',
    actorId: 'USR-ENGINEER-01',
    actorKind: 'Human',
    projectId,
    objectType: 'CommandTransaction',
    objectId: id(),
    correlationId,
    occurredAt: new Date('2026-08-06T10:00:00Z'),
    decision: 'Allowed',
    reasonCode: 'POLICY_SATISFIED',
    payload: { procedure: 'CH1-PROC-0001-R01' },
  });
  chain.append({
    eventType: 'LocalCommitAccepted',
    actorId: 'CH1-DEV-CELL-0001',
    actorKind: 'Device',
    projectId,
    objectType: 'CommandTransaction',
    objectId: id(),
    correlationId,
    occurredAt: new Date('2026-08-06T10:00:02Z'),
    decision: 'Allowed',
    reasonCode: 'LOCAL_COMMIT_VALID',
    payload: { interlocks: 'valid' },
  });
  assert.deepEqual(chain.verify(), { valid: true, checked: 2 });
  assert.equal(chain.events()[1]?.previousHash, chain.events()[0]?.eventHash);

  // The requirement is that an alteration is detected, not merely that a chain nobody
  // touched verifies. A reader holding these events must be able to tell.
  const altered = chain.events().map((event) => ({ ...event }));
  altered[0]!.decision = 'Rejected';
  assert.deepEqual(verifyEvents(altered), { valid: false, checked: 0, failureAt: 1 });

  const deleted = chain.events().slice(1).map((event) => ({ ...event }));
  assert.deepEqual(verifyEvents(deleted), { valid: false, checked: 1, failureAt: 2 });
});

test('CH1-VVT-TC-0042 CH1-VVT-TC-0043 failed mandatory measurement places the part on hold', () => {
  const part: PartRecord = {
    projectId: id(),
    partId: id(),
    workOrderId: id(),
    productRevision: 'PRD-R01',
    operatorId: 'USR-OPERATOR-01',
    status: 'InProcess',
    openNcrIds: [],
    measurements: [],
  };
  const measured = recordMeasurement(
    part,
    {
      characteristic: 'Coating thickness',
      value: 8.2,
      unit: 'um',
      lowerLimit: 9.5,
      upperLimit: 10.5,
      mandatory: true,
      sourceDeviceId: 'CH1-INS-THK-0001',
      calibrationValid: true,
    },
    new Date('2026-08-06T10:10:00Z'),
  );
  assert.equal(measured.status, 'Hold');
  assert.equal(measured.measurements[0]?.result, 'Fail');
  assert.equal(raiseNcr(measured).part.openNcrIds.length, 1);
});

test('CH1-VVT-TC-0045 expired calibration blocks controlled measurement', () => {
  const part: PartRecord = {
    projectId: id(),
    partId: id(),
    workOrderId: id(),
    productRevision: 'PRD-R01',
    operatorId: 'USR-OPERATOR-01',
    status: 'InProcess',
    openNcrIds: [],
    measurements: [],
  };
  assert.throws(
    () => recordMeasurement(part, {
      characteristic: 'Width',
      value: 8,
      unit: 'mm',
      lowerLimit: 7.9,
      upperLimit: 8.1,
      mandatory: true,
      sourceDeviceId: 'CH1-INS-CAL-0001',
      calibrationValid: false,
    }, new Date()),
    (error: unknown) => error instanceof RuleViolation && error.code === 'INSTRUMENT_CALIBRATION_EXPIRED',
  );
});

test('CH1-VVT-TC-0044 operation performer cannot release own part', () => {
  const projectId = id();
  const cellId = id();
  const part: PartRecord = {
    projectId,
    partId: id(),
    workOrderId: id(),
    productRevision: 'PRD-R01',
    operatorId: 'USR-OPERATOR-01',
    status: 'Accepted',
    openNcrIds: [],
    measurements: [{
      measurementId: id(),
      characteristic: 'Width',
      value: 8,
      unit: 'mm',
      lowerLimit: 7.9,
      upperLimit: 8.1,
      mandatory: true,
      sourceDeviceId: 'CH1-INS-CAL-0001',
      calibrationValid: true,
      measuredAt: new Date().toISOString(),
      result: 'Pass',
    }],
  };
  const samePerson: Actor = {
    id: 'USR-OPERATOR-01',
    kind: 'Human',
    roles: ['Inspector'],
    authenticationStrength: 'StepUpPhishingResistant',
    projectId,
    cellIds: [cellId],
  };
  assert.throws(
    () => releasePart(part, samePerson, new Date()),
    (error: unknown) => error instanceof RuleViolation && error.code === 'SEGREGATION_OF_DUTIES',
  );
  const independent = { ...samePerson, id: 'USR-INSPECTOR-02' };
  assert.equal(releasePart(part, independent, new Date()).status, 'Released');
});

test('CH1-VVT-TC-0043 controlled rework and passing retest supersede the failed characteristic', () => {
  const projectId = id();
  const cellId = id();
  const base: PartRecord = {
    projectId,
    partId: id(),
    workOrderId: id(),
    productRevision: 'PRD-R01',
    operatorId: 'USR-OPERATOR-01',
    status: 'InProcess',
    openNcrIds: [],
    measurements: [],
  };
  const failed = recordMeasurement(base, {
    characteristic: 'Coating thickness', value: 8.2, unit: 'um', lowerLimit: 9.5, upperLimit: 10.5,
    mandatory: true, sourceDeviceId: 'CH1-INS-THK-0001', calibrationValid: true,
  }, new Date('2026-08-06T10:00:00Z'));
  const raised = raiseNcr(failed);
  const retested = recordMeasurement(raised.part, {
    characteristic: 'Coating thickness', value: 10.1, unit: 'um', lowerLimit: 9.5, upperLimit: 10.5,
    mandatory: true, sourceDeviceId: 'CH1-INS-THK-0001', calibrationValid: true,
    supersedesMeasurementId: failed.measurements[0]!.measurementId,
  }, new Date('2026-08-06T10:20:00Z'));
  const accepted = closeNcrAfterPassingRetest(retested, raised.ncrId);
  const inspector: Actor = {
    id: 'USR-INSPECTOR-02', kind: 'Human', roles: ['Inspector'],
    authenticationStrength: 'StepUpPhishingResistant', projectId, cellIds: [cellId],
  };
  assert.equal(accepted.status, 'Accepted');
  assert.equal(releasePart(accepted, inspector, new Date('2026-08-06T10:30:00Z')).status, 'Released');
});
