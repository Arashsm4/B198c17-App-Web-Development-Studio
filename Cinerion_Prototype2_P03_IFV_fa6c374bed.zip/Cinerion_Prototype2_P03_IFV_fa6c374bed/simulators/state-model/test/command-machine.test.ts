// Tests for the command state machine model.

import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import test from 'node:test';

import {
  beginExecution,
  completeExecution,
  latchFault,
  localCommit,
  prepareCommand,
  reconcileRestart,
  recordCredentialProof,
  recoverFault,
  RuleViolation,
  stateHash,
  type Actor,
  type CellSnapshot,
  type CredentialProof,
  type LocalButtonObservation,
  type PrepareIntent,
  type Uuid,
} from '../src/model.ts';

const id = (): Uuid => randomUUID();
const now = new Date('2026-08-06T10:00:00.000Z');

const fixture = () => {
  const projectId = id();
  const siteId = id();
  const cellId = id();
  const assetId = id();
  const workOrderId = id();
  const partId = id();
  const bootId = id();
  const cell: CellSnapshot = {
    projectId,
    siteId,
    cellId,
    assetId,
    controllerId: 'CH1-DEV-CELL-0001',
    controllerBootId: bootId,
    operatingState: 'Idle',
    configurationRevision: 'CFG-0001-R01',
    workOrderId,
    partId,
    controllerOnline: true,
    startEnable: true,
    stopCircuitHealthy: true,
    guardHealthy: true,
    actuatorHome: true,
    buttonPressed: false,
    faultCauseActive: false,
  };
  const engineer: Actor = {
    id: 'USR-ENGINEER-01',
    kind: 'Human',
    roles: ['Engineer'],
    authenticationStrength: 'StepUpPhishingResistant',
    projectId,
    cellIds: [cellId],
  };
  const controller: Actor = {
    id: cell.controllerId,
    kind: 'Device',
    roles: ['DeviceController'],
    authenticationStrength: 'MutualTls',
    projectId,
    cellIds: [cellId],
  };
  const intent: PrepareIntent = {
    commandType: 'RUN_DIMENSIONAL_TEST',
    projectId,
    siteId,
    cellId,
    assetId,
    workOrderId,
    partId,
    procedureRevision: 'CH1-PROC-0001-R01',
    configurationRevision: cell.configurationRevision,
    expectedStateHash: stateHash(cell),
    sequence: 101,
    expiresAt: new Date(now.getTime() + 60_000),
    idempotencyKey: 'idem-000000000001',
    parameters: { travelMm: 10, maxSpeedMmS: 2 },
  };
  return { cell, engineer, controller, intent };
};

const proofFor = (command: ReturnType<typeof prepareCommand>, controller: Actor): CredentialProof => ({
  proofId: id(),
  commandId: command.commandId,
  confirmationId: command.confirmationId,
  cellId: command.intent.cellId,
  controllerId: controller.id,
  credentialId: id(),
  userId: 'USR-LOCAL-01',
  cryptographicallyVerified: true,
  userVerified: true,
  verifiedAt: new Date(now.getTime() + 1_000),
  expiresAt: new Date(now.getTime() + 21_000),
});

const buttonFor = (
  command: ReturnType<typeof prepareCommand>,
  controller: Actor,
  source: LocalButtonObservation['source'] = 'PhysicalInput',
): LocalButtonObservation => ({
  commandId: command.commandId,
  confirmationId: command.confirmationId,
  cellId: command.intent.cellId,
  controllerId: controller.id,
  controllerBootId: command.preparedControllerBootId,
  source,
  previousState: false,
  currentState: true,
  observedAt: new Date(now.getTime() + 2_000),
});

test('CH1-VVT-TC-0011 CH1-VVT-TC-0005 CH1-VVT-TC-0012 happy path requires prepare, credential, physical edge and commit', () => {
  const { cell, engineer, controller, intent } = fixture();
  const prepared = prepareCommand(intent, engineer, cell, now);
  const credentialled = recordCredentialProof(prepared, proofFor(prepared, controller), controller, new Date(now.getTime() + 1_000));
  const committed = localCommit(credentialled, buttonFor(prepared, controller), controller, cell, new Date(now.getTime() + 2_000));
  const completed = completeExecution(beginExecution(committed));
  assert.equal(completed.state, 'Completed');
  assert.ok(completed.localCommitId);
});

test('CH1-VVT-TC-0014 remote button emulation is rejected', () => {
  const { cell, engineer, controller, intent } = fixture();
  const prepared = prepareCommand(intent, engineer, cell, now);
  const credentialled = recordCredentialProof(prepared, proofFor(prepared, controller), controller, new Date(now.getTime() + 1_000));
  assert.throws(
    () => localCommit(credentialled, buttonFor(prepared, controller, 'RemoteApi'), controller, cell, new Date(now.getTime() + 2_000)),
    (error: unknown) => error instanceof RuleViolation && error.code === 'REMOTE_CONFIRMATION_FORBIDDEN',
  );
});

test('CH1-VVT-TC-0016 a held button cannot arm or commit', () => {
  const { cell, engineer, intent } = fixture();
  assert.throws(
    () => prepareCommand(intent, engineer, { ...cell, buttonPressed: true }, now),
    (error: unknown) => error instanceof RuleViolation && error.code === 'CONFIRM_BUTTON_HELD',
  );
});

test('CH1-VVT-TC-0017 changed guard blocks final commit', () => {
  const { cell, engineer, controller, intent } = fixture();
  const prepared = prepareCommand(intent, engineer, cell, now);
  const credentialled = recordCredentialProof(prepared, proofFor(prepared, controller), controller, new Date(now.getTime() + 1_000));
  assert.throws(
    () => localCommit(credentialled, buttonFor(prepared, controller), controller, { ...cell, guardHealthy: false }, new Date(now.getTime() + 2_000)),
    (error: unknown) => error instanceof RuleViolation && error.code === 'INTERLOCK_GUARD_OPEN',
  );
});

test('CH1-VVT-TC-0018 CH1-VVT-TC-0072 restart cancels an uncommitted transaction and defaults to a safe state', () => {
  const { cell, engineer, intent } = fixture();
  const prepared = prepareCommand(intent, engineer, cell, now);
  const reconciled = reconcileRestart(prepared, id());
  assert.equal(reconciled.state, 'Cancelled');
  assert.equal(reconciled.terminalReason, 'CONTROLLER_RESTART');
});

test('CH1-VVT-TC-0019 fault latch requires authorised local reset and cleared cause', () => {
  const { cell, engineer, controller, intent } = fixture();
  const prepared = prepareCommand(intent, engineer, cell, now);
  const credentialled = recordCredentialProof(prepared, proofFor(prepared, controller), controller, new Date(now.getTime() + 1_000));
  const committed = localCommit(credentialled, buttonFor(prepared, controller), controller, cell, new Date(now.getTime() + 2_000));
  const faulted = latchFault(beginExecution(committed), 'POSITION_PLAUSIBILITY');
  const localConfirmer: Actor = { ...engineer, id: 'USR-LOCAL-01', roles: ['LocalConfirmer'] };
  assert.throws(
    () => recoverFault(faulted, localConfirmer, { ...cell, faultCauseActive: true }, { source: 'PhysicalInput', previousState: false, currentState: true }),
    (error: unknown) => error instanceof RuleViolation && error.code === 'FAULT_CAUSE_ACTIVE',
  );
  assert.throws(
    () => recoverFault(faulted, localConfirmer, cell, { source: 'RemoteApi', previousState: false, currentState: true }),
    (error: unknown) => error instanceof RuleViolation && error.code === 'REMOTE_RESET_FORBIDDEN',
  );
  assert.equal(
    recoverFault(faulted, localConfirmer, cell, { source: 'PhysicalInput', previousState: false, currentState: true }).terminalReason,
    'FAULT_RECOVERED_LOCALLY',
  );
});

test('CH1-VVT-TC-0015 CH1-VVT-TC-0027 expired command and proof are rejected', () => {
  const { cell, engineer, controller, intent } = fixture();
  const prepared = prepareCommand(intent, engineer, cell, now);
  const proof = proofFor(prepared, controller);
  assert.throws(
    () => recordCredentialProof(prepared, { ...proof, expiresAt: now }, controller, new Date(now.getTime() + 1_000)),
    (error: unknown) => error instanceof RuleViolation && error.code === 'PROOF_EXPIRED',
  );
});

