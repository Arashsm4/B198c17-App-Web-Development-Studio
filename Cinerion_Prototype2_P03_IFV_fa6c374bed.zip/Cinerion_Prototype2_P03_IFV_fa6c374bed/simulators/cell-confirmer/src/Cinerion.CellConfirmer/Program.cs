// A stand-in cell controller that answers a prepared command.
//
// WHAT THIS IS FOR. The controlled sequence in CH1-AUT-FDS-0001 is: the portal prepares
// intent, the cell controller presents a credential proof, the controller observes a new
// button edge, the controller re-samples the interlocks, and only then does the command
// commit locally. Every part of that existed in Control Core and was tested. What did not
// exist was anything that could BE the controller over HTTP: `ValidateController` requires
// an mTLS-authenticated device identity holding DeviceController, and the only way to
// present one was the development identity handler, which is mutually exclusive with OIDC.
// So in a lab serving the portal over OIDC, a prepared command sat at AwaitingCredential
// for ever and nobody could watch the sequence complete.
//
// WHAT THIS IS NOT. It is not the portal, and it is deliberately a separate service with a
// separate identity on a separate network path. `scripts/check-repository-policy.mjs`
// refuses /credential-proofs and /local-commits anywhere under apps/operator-portal/src/,
// and that stays true: the portal asks THIS service to confirm, and this service - holding
// a device certificate the platform enrolled - performs the controller's half. The portal
// gains no route to a commit; it gains a way to ask a simulated cell to do what a real
// cell would do.
//
// It is also not a claim that anything physical happened. The button edge is marked
// `SimulatorInjection`, which `CommandTransaction.LocalCommit` refuses outside the
// Simulation profile and audits as MARKED_SIMULATOR_EDGE rather than as a physical one.
// The credential proof is marked `SimulatedPresence`, which was added for this and is
// refused in exactly the same way - before it existed a stand-in had to name a real
// authenticator class and the audit recorded CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED, which
// asserted that a person had presented a credential at a cell when nobody had.
//
// WHAT IT STILL CANNOT DO. It cannot make a command commit that should not. Every guard in
// `CommandTransaction.LocalCommit` runs against it exactly as against a real controller:
// the interlocks are re-sampled from the cell, the expected state hash must still match,
// the controller boot identity must be the one the command was prepared against, the
// credential proof must not have expired, and the command must not have. A refusal is
// reported verbatim and nothing is retried.
//
//   dotnet run --project simulators/cell-confirmer/src/Cinerion.CellConfirmer

using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

var settings = ConfirmerSettings.FromConfiguration(builder.Configuration);
builder.Services.AddSingleton(settings);
builder.Services.AddSingleton(_ => BuildControlCoreClient(settings));
builder.Services.Configure<Microsoft.AspNetCore.Http.Json.JsonOptions>(options =>
    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase);

var app = builder.Build();

app.MapGet("/health", (ConfirmerSettings configured) => Results.Ok(new
{
    status = "Healthy",
    role = "Simulated cell controller",
    configured.ControllerId,
    configured.CellId,
    controlCore = configured.ControlCoreBaseUrl,
    // Said in the response rather than only in a comment, because a client reads the
    // response and not this file. Every one of these is a statement about what this
    // service is NOT.
    physicalEdge = false,
    personPresent = false,
    notice =
        "A stand-in controller for the Simulation profile. It injects a MARKED simulator " +
        "button edge and a MARKED simulated presence. Nothing physical is observed, no " +
        "person presents a credential, and no equipment is energised.",
}));

/// A prepared command, confirmed the way a cell controller confirms one.
app.MapPost("/confirm", async (
    ConfirmRequest request,
    ConfirmerSettings configured,
    HttpClient controlCore,
    CancellationToken cancellationToken) =>
{
    if (request.CommandId == Guid.Empty)
    {
        return Results.BadRequest(new { code = "COMMAND_ID_REQUIRED", detail = "Name the prepared command to confirm." });
    }

    var steps = new List<object>();

    // STEP 1. Read the command, because the controller must not invent the confirmation it
    // is answering. The confirmation identifier is issued by Control Core at preparation
    // and binds the proof and the edge to THIS preparation; a controller that made one up
    // would be answering a challenge nobody set.
    var read = await controlCore
        .GetAsync(new Uri($"/api/v1/commands/{request.CommandId}", UriKind.Relative), cancellationToken)
        .ConfigureAwait(false);
    var readBody = await read.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
    if (!read.IsSuccessStatusCode)
    {
        return Refused("read the prepared command", read.StatusCode, readBody, steps);
    }

    var command = JsonSerializer.Deserialize<PreparedCommand>(readBody, JsonOptions.Relaxed);
    if (command is null || command.ConfirmationId == Guid.Empty)
    {
        return Results.Json(new { code = "COMMAND_UNREADABLE", detail = "The prepared command could not be read." }, statusCode: 502);
    }
    steps.Add(new { step = "read", state = command.State, command.ConfirmationId });

    if (!string.Equals(command.State, "AwaitingCredential", StringComparison.Ordinal))
    {
        // Reported rather than forced. A command already past the credential, cancelled or
        // committed is not something a controller re-confirms, and a stand-in that tried
        // would be manufacturing a second confirmation for one preparation.
        return Results.Json(
            new
            {
                code = "COMMAND_NOT_AWAITING_CREDENTIAL",
                detail = $"The command is {command.State}, so there is no credential to present.",
                steps,
            },
            statusCode: 409);
    }

    // STEP 2. The nonce. A real controller issues one for this confirmation and the proof
    // carries its SHA-256, which is what binds the proof to user, cell, transaction and
    // nonce rather than to identifiers that appear in the request itself. This stand-in
    // issues a fresh random one per confirmation, for the same reason and with the same
    // effect: two confirmations of the same command cannot share a proof.
    var nonce = RandomNumberGenerator.GetBytes(32);
    var challengeHash = Convert.ToHexStringLower(SHA256.HashData(nonce));

    var now = DateTimeOffset.UtcNow;
    var proof = new
    {
        proofId = Guid.NewGuid(),
        commandId = request.CommandId,
        confirmationId = command.ConfirmationId,
        cellId = configured.CellId,
        controllerId = configured.ControllerId,
        // A well-known identifier that is not a credential. It names the stand-in, so a
        // reader of the audit record can see at once that no enrolled authenticator was
        // involved - and the authenticator class below says the same thing structurally.
        credentialId = ConfirmerSettings.SimulatedCredentialId,
        userId = "SIMULATED-PRESENCE-NO-PERSON",
        authenticatorClass = "SimulatedPresence",
        challengeHash,
        cryptographicallyVerified = true,
        userVerified = true,
        verifiedAt = now,
        // Short, because a local presence is a moment rather than a session. The platform
        // refuses an expired proof at the commit, which is the control this respects
        // rather than works around.
        expiresAt = now.AddSeconds(configured.PresenceValiditySeconds),
    };

    var proved = await controlCore.PostAsJsonAsync(
        new Uri($"/api/v1/confirmations/{command.ConfirmationId}/credential-proofs", UriKind.Relative),
        proof,
        cancellationToken).ConfigureAwait(false);
    var provedBody = await proved.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
    if (!proved.IsSuccessStatusCode)
    {
        return Refused("present the credential proof", proved.StatusCode, provedBody, steps);
    }
    steps.Add(new { step = "credentialProof", accepted = true, authenticatorClass = "SimulatedPresence" });

    // STEP 3. The button edge. `previousState: false` and `currentState: true` is the
    // RISING edge the domain requires - a level that was already high is not a new press,
    // and `CONFIRM_EDGE_REQUIRED` refuses one. The source is marked, and the platform
    // refuses the marking outside the Simulation profile.
    var observation = new
    {
        commandId = request.CommandId,
        confirmationId = command.ConfirmationId,
        cellId = configured.CellId,
        controllerId = configured.ControllerId,
        controllerBootId = configured.ControllerBootId,
        source = "SimulatorInjection",
        previousState = false,
        currentState = true,
        observedAt = DateTimeOffset.UtcNow,
    };

    var committed = await controlCore.PostAsJsonAsync(
        new Uri($"/api/v1/confirmations/{command.ConfirmationId}/local-commits", UriKind.Relative),
        observation,
        cancellationToken).ConfigureAwait(false);
    var committedBody = await committed.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
    if (!committed.IsSuccessStatusCode)
    {
        // The interesting refusals live here: an interlock that is no longer valid, a
        // state hash that moved after preparation, a controller that rebooted. Every one
        // of them is a control working, and every one is reported as the service sent it.
        return Refused("inject the marked button edge", committed.StatusCode, committedBody, steps);
    }

    var outcome = JsonSerializer.Deserialize<PreparedCommand>(committedBody, JsonOptions.Relaxed);
    steps.Add(new { step = "localCommit", accepted = true, state = outcome?.State });

    return Results.Ok(new
    {
        confirmed = true,
        request.CommandId,
        command.ConfirmationId,
        state = outcome?.State,
        steps,
        // Repeated at the end of every successful confirmation, because this is the one
        // response somebody might quote as evidence that something ran.
        notice =
            "Confirmed by a SIMULATED cell controller. The button edge was marked " +
            "SimulatorInjection and the presence was marked SimulatedPresence; the audit " +
            "record says so. No person was present, no credential was read, and no " +
            "equipment moved.",
    });
});

app.Run();

static IResult Refused(string what, System.Net.HttpStatusCode status, string body, List<object> steps)
{
    // The service's own refusal, forwarded rather than rephrased. A stand-in that
    // translated a control's refusal into its own words would put itself between an
    // operator and the reason the platform gave.
    object? detail;
    try
    {
        detail = JsonSerializer.Deserialize<JsonElement>(body);
    }
    catch (JsonException)
    {
        detail = body;
    }

    return Results.Json(
        new
        {
            confirmed = false,
            failedTo = what,
            controlCoreStatus = (int)status,
            controlCoreSaid = detail,
            steps,
        },
        statusCode: 502);
}

/// <summary>
/// The mutually authenticated client this stand-in speaks to Control Core with.
/// <para>
/// The client certificate is the identity: Control Core resolves it to an enrolled device
/// record and takes the project, the cell and the DeviceController role from THAT, not from
/// anything sent here. So this service cannot name its own scope, and a certificate that
/// matches no enrolled device - or one whose device has had its trust withdrawn - is
/// refused at authentication with nothing this code can do about it.
/// </para>
/// </summary>
static HttpClient BuildControlCoreClient(ConfirmerSettings settings)
{
    var handler = new HttpClientHandler
    {
        ClientCertificateOptions = ClientCertificateOption.Manual,
        // The controlled authority is the only trust anchor in this direction too. Mutual
        // means both ways: a Control Core presenting a certificate from a public authority
        // that happens to carry the right name is not the one this deployment configured.
        ServerCertificateCustomValidationCallback = (_, certificate, chain, errors) =>
            IsIssuedByControlledAuthority(settings, certificate, chain, errors),
    };
    handler.ClientCertificates.Add(settings.ClientCertificate);

    return new HttpClient(handler)
    {
        BaseAddress = new Uri(settings.ControlCoreBaseUrl, UriKind.Absolute),
        Timeout = TimeSpan.FromSeconds(20),
        DefaultRequestHeaders = { Accept = { new MediaTypeWithQualityHeaderValue("application/json") } },
    };
}

static bool IsIssuedByControlledAuthority(
    ConfirmerSettings settings,
    X509Certificate2? presented,
    X509Chain? _,
    SslPolicyErrors errors)
{
    if (presented is null || errors.HasFlag(SslPolicyErrors.RemoteCertificateNotAvailable))
    {
        return false;
    }

    using var chain = new X509Chain
    {
        ChainPolicy =
        {
            TrustMode = X509ChainTrustMode.CustomRootTrust,
            RevocationMode = X509RevocationMode.NoCheck,
        },
    };
    chain.ChainPolicy.CustomTrustStore.Add(settings.CertificateAuthority);
    return chain.Build(presented);
}

internal static class JsonOptions
{
    /// <summary>Property names arrive camel-cased from the service; matching is case-insensitive.</summary>
    public static readonly JsonSerializerOptions Relaxed = new(JsonSerializerDefaults.Web);
}

internal sealed record ConfirmRequest(Guid CommandId);

internal sealed record PreparedCommand(
    Guid CommandId,
    Guid ConfirmationId,
    string State,
    [property: JsonPropertyName("physicalConfirmationRequired")] bool PhysicalConfirmationRequired = true);

/// <summary>
/// What this stand-in needs to exist, all of it required.
/// <para>
/// No defaults for the identity or the certificates. A simulator that started with a
/// guessed cell or a missing certificate would fail at the first request with something
/// that reads like a broken service; refusing to start and naming the missing setting is
/// the same fail-closed direction every mutual-TLS surface in this repository takes.
/// </para>
/// </summary>
internal sealed record ConfirmerSettings(
    string ControlCoreBaseUrl,
    string ControllerId,
    Guid CellId,
    Guid ControllerBootId,
    int PresenceValiditySeconds,
    X509Certificate2 ClientCertificate,
    X509Certificate2 CertificateAuthority)
{
    /// <summary>
    /// The identifier a simulated presence is recorded under. Fixed and well known so it
    /// can be searched for in the audit chain, and deliberately not the identifier of any
    /// enrolled credential.
    /// </summary>
    public static readonly Guid SimulatedCredentialId = Guid.Parse("00000000-0000-4000-8000-511151111511");

    public static ConfirmerSettings FromConfiguration(IConfiguration configuration)
    {
        string Required(string name) =>
            configuration[name] is { Length: > 0 } value
                ? value
                : throw new InvalidOperationException($"{name} is required. This stand-in does not guess an identity.");

        Guid RequiredGuid(string name) =>
            Guid.TryParse(Required(name), out var parsed) && parsed != Guid.Empty
                ? parsed
                : throw new InvalidOperationException($"{name} is not an identifier.");

        var certificate = X509Certificate2.CreateFromPemFile(
            Required("CINERION_CONFIRMER_CLIENT_CERT"),
            Required("CINERION_CONFIRMER_CLIENT_KEY"));

        // The same PKCS#12 round trip Control Core performs, and for the same reason:
        // SChannel cannot use the ephemeral key handle CreateFromPemFile produces, and a
        // client configured with one fails at the handshake with an error naming the
        // credential rather than the cause.
        if (OperatingSystem.IsWindows())
        {
            using (certificate)
            {
                return Build(X509CertificateLoader.LoadPkcs12(certificate.Export(X509ContentType.Pkcs12), password: null));
            }
        }

        return Build(certificate);

        ConfirmerSettings Build(X509Certificate2 client) => new(
            Required("CINERION_CONFIRMER_CONTROL_CORE_URL"),
            Required("CINERION_CONFIRMER_CONTROLLER_ID"),
            RequiredGuid("CINERION_CONFIRMER_CELL_ID"),
            RequiredGuid("CINERION_CONFIRMER_CONTROLLER_BOOT_ID"),
            int.TryParse(configuration["CINERION_CONFIRMER_PRESENCE_SECONDS"], out var seconds) && seconds > 0
                ? seconds
                : 60,
            client,
            X509CertificateLoader.LoadCertificateFromFile(Required("CINERION_CONFIRMER_CA_CERT")));
    }
}
