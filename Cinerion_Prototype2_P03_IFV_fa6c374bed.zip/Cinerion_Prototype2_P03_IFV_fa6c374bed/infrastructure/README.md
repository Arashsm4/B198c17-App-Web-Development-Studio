# Cinerion local infrastructure

The default Compose project starts only the simulator-safe vertical slice:

- `control-core` — in-memory C# command, quality, and audit services;
- `edge-link` — loopback simulator adapter only;
- `operator-portal` — static Expo web export.

All host ports bind to loopback. The control network is internal, containers run read-only where practical, and live MQTT/OPC UA/Modbus adapters remain fail-closed.

```bash
./scripts/run-local.sh
```

The portal is available at `http://localhost:8081` and API health at `http://localhost:5080/api/v1/system/health`.

## Optional controlled labs

Generate local secrets first:

```bash
./scripts/bootstrap-local.sh
docker compose --env-file infrastructure/.env.local \
  -f infrastructure/compose.yaml --profile data-lab --profile identity-lab up -d
```

The PostgreSQL service loads the controlled foundation schema. The Keycloak realm has no seed user or reusable password; create the first engineering identity through the local admin console, require WebAuthn, and remove bootstrap credentials after provisioning.

### Required user attributes

Control Core authorises on project and cell scope, not on role alone. A realm user
without these attributes authenticates successfully and is then refused with
`403 AUTH_PROJECT_SCOPE_REQUIRED`, which is the intended fail-closed behaviour.
Set them on each user in the admin console:

| Attribute | Value | Effect |
|---|---|---|
| `ch1_project` | one project UUID | Required. Becomes the `ch1_project` claim and bounds every query and mutation. |
| `ch1_cell` | one or more cell UUIDs | Cells the user may observe or prepare commands against. Absent means no cell access. |
| `ch1_actor_kind` | `Human`, `Service`, `Device` or `System` | Optional; defaults to `Human`. Controlled inspection requires a human identity. |

Realm roles are emitted as a flat `roles` claim and must correspond to
`CinerionRoles` in `services/control-core/src/Cinerion.Domain/Security/ActorContext.cs`.
`npm run policy` reconciles the two lists and fails on drift in either direction.

There is deliberately **no** `ch1_auth_strength` attribute or mapper. Authentication
strength describes how the current session was authenticated; storing it on the user
would grant a permanent step-up and defeat the release and security-administration
gates in CH1-CYB-ACP-0001. The API derives it from the token's `amr`, capped at
`Mfa`. Phishing-resistant step-up requires `POST /api/v1/auth/step-up`, which remains
a controlled `501` until it is implemented with an `auth_time` recency check —
independent part release is therefore not yet reachable over OIDC.

The `protocol-lab` profile additionally requires a private CA, broker certificate, key, and client identities under the configured `CINERION_MQTT_SECRETS_DIR`. It exposes MQTT 5 only through mutual TLS 1.3 and certificate-identity topic ACLs. It is intentionally not auto-bootstrapped because private-key lifecycle and certificate subjects are controlled security decisions.

These profiles are development laboratories. `start-dev`, loopback HTTP, generated local secrets, and the in-memory application store are forbidden for production or hazardous control.
