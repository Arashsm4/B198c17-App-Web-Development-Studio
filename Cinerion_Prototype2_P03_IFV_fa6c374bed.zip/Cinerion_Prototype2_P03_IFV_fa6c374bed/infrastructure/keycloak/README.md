# The controlled realm

`cinerion-realm.json` is imported by Keycloak the first time the identity database is empty.
It declares the realm, its 15 roles, the three clients and the two lab identities. It carries
no passwords: `scripts/provision-portal-identities.sh` sets those from
`infrastructure/.env.local`, and `npm run realm:drift` compares the running realm with this
file in both directions.

## Notes go here, never in the JSON

JSON has no comments, so it's tempting to add a field like `"_note": "..."`. **Don't.**
Keycloak reads this file strictly and refuses any field it doesn't know:

```
ERROR: Unrecognized field "_sessionLifetimeNote" (class org.keycloak.representations.idm.RealmRepresentation)
```

That exact line stopped every fresh install cold: Keycloak never started, so nobody could sign
in. It went unnoticed for two days because a realm that already exists is never re-imported,
so the one lab that existed kept working — until its identity container was recreated. Found
by installing the release package from scratch. `npm run policy` now refuses any key starting
with `_` anywhere in this file.

## Keep text short: 255 characters

Most text Keycloak imports — client and role descriptions, names — goes into database columns
that hold 255 characters. Anything longer and the import dies with
`value too long for type character varying(255)`, and again Keycloak never starts. The
`cinerion-identity-admin` description was 505 characters for six weeks and nobody knew, because
the only lab that existed had imported the realm before that description was written. Found by
the same fresh install. `npm run policy` refuses any string over 255 characters in this file,
except under `components.*.config`, which Keycloak keeps in a text column (its own user-profile
setting is 1,801 characters, and that's fine).

## Users keep their IDs

Each user in the file carries a fixed `id`. Without one, Keycloak invents a random ID on every
fresh install, and that ID is the `sub` in the user's tokens - which is what Control Core
records as the actor. A lab data snapshot moved to another PC (`npm run lab:export`, see
INSTALL.md) would then hold records pointing at users who, on the new PC, have different IDs.
Pinned, `ch1-portal-demo` is `dcde2ba6-…` everywhere. A new user added here gets a new UUID of
its own; never reuse one.

## The identity-admin client, in full

`cinerion-identity-admin` is the service account Control Core uses to read users and change
controlled role assignments. It is deliberately granted `view-users`, `query-users` and
`manage-users` only: `realm-admin`, `manage-realm`, `manage-clients` and
`manage-authorization` are withheld, so this identity carries no security-policy authority,
which is the control `access.json` states for *Manage users*. No secret is declared in the
realm; the deployment assigns its credential from controlled secret storage, as migration 0002
does for the `cinerion_app` database role.

## Session lifetimes

No controlled document states a session lifetime, so these three were once left unset and
Keycloak's own defaults applied — which meant the effective policy for an operations console
with command authority was a product default nobody had decided. They are declared in the realm
at **exactly** those defaults, so behaviour is unchanged and the decision is now reviewable:

| Setting | Value | Meaning |
|---|---|---|
| `accessTokenLifespan` | 300 | 5 minutes |
| `ssoSessionIdleTimeout` | 1800 | 30 minutes idle |
| `ssoSessionMaxLifespan` | 36000 | 10 hours maximum |

The portal renews silently while the SSO session is alive, so `accessTokenLifespan` bounds how
long a revoked identity keeps working, not how long an operator can work. Changing any of these
is an identity-policy change.

## Sign-in strength

The realm doesn't ask for a second factor and doesn't emit the `amr` claim, so Control Core
treats every password sign-in as single-factor, and every step-up (which needs at least
multi-factor) is refused with `AUTH_STRONGER_AUTHENTICATOR_REQUIRED`. Turning on OTP at sign-in
and Keycloak's AMR mapper would open that path. It's an identity-design decision for the
project owner, recorded in the top-level `README.md` under "What remains".
