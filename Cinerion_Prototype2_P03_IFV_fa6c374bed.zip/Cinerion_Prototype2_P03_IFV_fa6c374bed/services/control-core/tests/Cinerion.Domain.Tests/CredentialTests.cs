// Tests for TOTP codes and WebAuthn checks.

using System.Security.Cryptography;
using System.Text;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;
using Xunit;

namespace Cinerion.Domain.Tests;

/// <summary>
/// Authenticator behaviour that must hold whatever the transport or store does.
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-IAM-FR-0007</requirements>
public sealed class TotpTests
{
    /// <summary>
    /// RFC 6238 Appendix B, the published test vectors. The seed is the ASCII string
    /// "12345678901234567890"; each row is a time and the 8-digit code the RFC says the
    /// algorithm must produce. Anything that passes this is RFC 6238, and anything that
    /// does not is a lookalike that would silently reject every authenticator app.
    /// </summary>
    [Theory]
    [InlineData(59L, "94287082", "SHA1")]
    [InlineData(1111111109L, "07081804", "SHA1")]
    [InlineData(1111111111L, "14050471", "SHA1")]
    [InlineData(1234567890L, "89005924", "SHA1")]
    [InlineData(2000000000L, "69279037", "SHA1")]
    [InlineData(20000000000L, "65353130", "SHA1")]
    [VerificationCase("CH1-VVT-TC-0003")]
    public void CH1_IAM_FR_0004_Totp_matches_the_RFC_6238_published_vectors(
        long unixSeconds, string expected, string algorithm)
    {
        var secret = Encoding.ASCII.GetBytes("12345678901234567890");
        var parameters = new TotpParameters(8, TimeSpan.FromSeconds(30), algorithm);

        var code = Totp.Compute(secret, DateTimeOffset.FromUnixTimeSeconds(unixSeconds), parameters);

        Assert.Equal(expected, code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0003")]
    public void CH1_IAM_FR_0004_Totp_accepts_one_step_of_drift_either_side_and_no_more()
    {
        var secret = Totp.GenerateSecret();
        var parameters = TotpParameters.Default;
        var now = DateTimeOffset.UtcNow;

        var previous = Totp.Compute(secret, now - parameters.Period, parameters);
        var next = Totp.Compute(secret, now + parameters.Period, parameters);
        var tooEarly = Totp.Compute(secret, now - (parameters.Period * 3), parameters);

        Assert.True(Totp.Verify(secret, previous, now, parameters));
        Assert.True(Totp.Verify(secret, next, now, parameters));
        Assert.False(Totp.Verify(secret, tooEarly, now, parameters));
    }

    [Fact]
    public void CH1_CYB_IAM_0001_A_totp_enrolment_is_never_marked_phishing_resistant()
    {
        var credential = CredentialRecord.EnrolTotp(
            Guid.CreateVersion7(), Guid.CreateVersion7(), "operator-1", "Authenticator",
            [1, 2, 3, 4], [5, 6, 7], TotpParameters.Default, "admin-1", DateTimeOffset.UtcNow);

        Assert.False(credential.PhishingResistant);
        Assert.False(CredentialRecord.IsPhishingResistant(CredentialKind.Totp));
        Assert.True(CredentialRecord.IsPhishingResistant(CredentialKind.Passkey));
        Assert.True(CredentialRecord.IsPhishingResistant(CredentialKind.SecurityToken));
    }

    [Fact]
    public void CH1_CYB_IAM_0001_A_totp_credential_can_never_raise_phishing_resistant_step_up()
    {
        var projectId = Guid.CreateVersion7();
        var actor = new ActorContext(
            "operator-1", ActorKind.Human, new HashSet<string> { CinerionRoles.Inspector },
            AuthenticationStrength.Mfa, projectId, new HashSet<Guid>(), "session-1", DateTimeOffset.UtcNow);
        var totp = CredentialRecord.EnrolTotp(
            Guid.CreateVersion7(), projectId, "operator-1", "Authenticator",
            [1, 2, 3], [4, 5, 6], TotpParameters.Default, "admin-1", DateTimeOffset.UtcNow);

        var error = Assert.Throws<DomainRuleException>(() =>
            StepUpGrant.IssueFromVerifiedPasskey(
                actor, StepUpPurpose.PartRelease, totp, DateTimeOffset.UtcNow));

        Assert.Equal("AUTH_CREDENTIAL_NOT_PHISHING_RESISTANT", error.Code);
    }

    [Fact]
    public void CH1_IAM_FR_0005_A_verified_passkey_raises_step_up_to_phishing_resistant()
    {
        var projectId = Guid.CreateVersion7();
        var actor = new ActorContext(
            "operator-1", ActorKind.Human, new HashSet<string> { CinerionRoles.Inspector },
            // Deliberately an ordinary multi-factor session: the grant's strength comes
            // from the assertion this platform verified, not from the token.
            AuthenticationStrength.Mfa, projectId, new HashSet<Guid>(), "session-1", DateTimeOffset.UtcNow);
        var passkey = NewPasskey(projectId, "operator-1");

        var grant = StepUpGrant.IssueFromVerifiedPasskey(
            actor, StepUpPurpose.PartRelease, passkey, DateTimeOffset.UtcNow);

        Assert.Equal(AuthenticationStrength.StepUpPhishingResistant, grant.Strength);
        Assert.Equal(StepUpPurpose.PartRelease, grant.Purpose);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public void CH1_IAM_FR_0005_A_passkey_held_by_another_identity_grants_nothing()
    {
        var projectId = Guid.CreateVersion7();
        var actor = new ActorContext(
            "operator-1", ActorKind.Human, new HashSet<string> { CinerionRoles.Inspector },
            AuthenticationStrength.Mfa, projectId, new HashSet<Guid>(), "session-1", DateTimeOffset.UtcNow);
        var someoneElses = NewPasskey(projectId, "operator-2");

        var error = Assert.Throws<DomainRuleException>(() =>
            StepUpGrant.IssueFromVerifiedPasskey(
                actor, StepUpPurpose.PartRelease, someoneElses, DateTimeOffset.UtcNow));

        Assert.Equal("AUTH_CREDENTIAL_NOT_HELD", error.Code);
    }

    /// <summary>
    /// WebAuthn 6.1.1: a signature counter that does not advance is evidence that the
    /// authenticator has been cloned. An authenticator that never counts reports zero,
    /// which is permitted and must not be mistaken for a clone.
    /// </summary>
    [Fact]
    public void CH1_IAM_FR_0007_A_signature_counter_that_did_not_advance_is_refused()
    {
        var credential = NewPasskey(Guid.CreateVersion7(), "operator-1") with { SignCount = 42 };

        var advanced = credential.ObserveAssertion(43, DateTimeOffset.UtcNow);
        Assert.Equal(43, advanced.SignCount);

        var error = Assert.Throws<DomainRuleException>(() =>
            credential.ObserveAssertion(42, DateTimeOffset.UtcNow));
        Assert.Equal("CREDENTIAL_SIGN_COUNT_NOT_ADVANCED", error.Code);

        // Zero means "this authenticator keeps no counter" and leaves the record alone.
        var uncounted = credential.ObserveAssertion(0, DateTimeOffset.UtcNow);
        Assert.Equal(42, uncounted.SignCount);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0007")]
    public void CH1_CYB_IAM_0001_A_cloneable_uid_is_not_accepted_as_a_smart_card()
    {
        var error = Assert.Throws<DomainRuleException>(() =>
            CredentialRecord.EnrolSmartCard(
                Guid.CreateVersion7(), Guid.CreateVersion7(), "operator-1", "Door card",
                // No key: a UID alone.
                [], "SN-0001", null,
                UserVerificationRequirement.Required, "admin-1", DateTimeOffset.UtcNow));

        Assert.Equal("CREDENTIAL_PUBLIC_KEY_REQUIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public void CH1_IAM_FR_0006_Revocation_requires_a_reason_and_an_author_and_keeps_the_record()
    {
        var credential = NewPasskey(Guid.CreateVersion7(), "operator-1");

        Assert.Equal(
            "CREDENTIAL_REVOCATION_REASON_REQUIRED",
            Assert.Throws<DomainRuleException>(() =>
                credential.Revoke("admin-1", "  ", DateTimeOffset.UtcNow)).Code);

        var revoked = credential.Revoke("admin-1", "Reported lost", DateTimeOffset.UtcNow);
        Assert.Equal(CredentialStatus.Revoked, revoked.Status);
        Assert.Equal("Reported lost", revoked.RevocationReason);
        // The public key is retained: a forgotten credential could be presented
        // elsewhere unnoticed.
        Assert.NotNull(revoked.PublicKeySpki);

        Assert.Equal(
            "CREDENTIAL_ALREADY_REVOKED",
            Assert.Throws<DomainRuleException>(() =>
                revoked.Revoke("admin-1", "again", DateTimeOffset.UtcNow)).Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0007")]
    public void CH1_CYB_IAM_0001_An_authenticator_that_only_proves_presence_is_refused()
    {
        var error = Assert.Throws<DomainRuleException>(() =>
            CredentialRecord.EnrolFido(
                Guid.CreateVersion7(), Guid.CreateVersion7(), "operator-1",
                CredentialKind.Passkey, "Laptop", [1, 2, 3], [4, 5, 6], null, "localhost",
                UserVerificationRequirement.Discouraged, "admin-1", DateTimeOffset.UtcNow));

        Assert.Equal("CREDENTIAL_USER_VERIFICATION_REQUIRED", error.Code);
    }

    private static CredentialRecord NewPasskey(Guid projectId, string subjectId)
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        return CredentialRecord.EnrolFido(
            Guid.CreateVersion7(), projectId, subjectId, CredentialKind.Passkey, "Security key",
            key.ExportSubjectPublicKeyInfo(), [9, 8, 7, 6], null, "localhost",
            UserVerificationRequirement.Required, "admin-1", DateTimeOffset.UtcNow);
    }
}

/// <summary>
/// WebAuthn assertion verification. Each test removes exactly one property a genuine
/// assertion has, and asserts the platform refuses for that reason and no other.
/// </summary>
/// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0007, CH1-CYB-IAM-0001</requirements>
public sealed class WebAuthnVerifierTests
{
    private const string RpId = "cinerion.local";
    private const string Origin = "https://cinerion.local";

    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public void CH1_IAM_FR_0005_A_genuine_assertion_verifies()
    {
        var fixture = new AssertionFixture();

        var verification = WebAuthnVerifier.Verify(
            fixture.Assertion(), fixture.Challenge, fixture.Credential, requireUserVerification: true);

        Assert.True(verification.UserPresent);
        Assert.True(verification.UserVerified);
        Assert.Equal(Origin, verification.Origin);
        Assert.Equal(7u, verification.SignCount);
    }

    /// <summary>
    /// The single most important check. A passkey is phishing resistant because the
    /// authenticator signs over the origin the browser actually reached, so an assertion
    /// harvested by a look-alike site must not verify here.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public void CH1_CYB_IAM_0001_An_assertion_produced_for_another_origin_is_refused()
    {
        var fixture = new AssertionFixture { ClientOrigin = "https://cinerion.local.evil.example" };

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.Verify(
            fixture.Assertion(), fixture.Challenge, fixture.Credential, requireUserVerification: true));

        Assert.Equal("PASSKEY_ORIGIN_MISMATCH", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public void CH1_IAM_FR_0005_An_assertion_answering_a_different_challenge_is_refused()
    {
        var fixture = new AssertionFixture { ClientChallenge = RandomNumberGenerator.GetBytes(32) };

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.Verify(
            fixture.Assertion(), fixture.Challenge, fixture.Credential, requireUserVerification: true));

        Assert.Equal("PASSKEY_CHALLENGE_MISMATCH", error.Code);
    }

    [Fact]
    public void CH1_IAM_FR_0005_A_registration_response_cannot_be_replayed_as_an_authentication()
    {
        var fixture = new AssertionFixture { ClientType = "webauthn.create" };

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.Verify(
            fixture.Assertion(), fixture.Challenge, fixture.Credential, requireUserVerification: true));

        Assert.Equal("PASSKEY_CLIENT_DATA_TYPE_INVALID", error.Code);
    }

    [Fact]
    public void CH1_IAM_FR_0005_An_assertion_for_another_relying_party_is_refused()
    {
        var fixture = new AssertionFixture { AuthenticatorRpId = "someone-else.example" };

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.Verify(
            fixture.Assertion(), fixture.Challenge, fixture.Credential, requireUserVerification: true));

        Assert.Equal("PASSKEY_RP_ID_MISMATCH", error.Code);
    }

    [Fact]
    public void CH1_CYB_IAM_0001_Presence_without_user_verification_is_refused_for_a_sensitive_action()
    {
        var fixture = new AssertionFixture { UserVerified = false };

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.Verify(
            fixture.Assertion(), fixture.Challenge, fixture.Credential, requireUserVerification: true));

        Assert.Equal("PASSKEY_USER_NOT_VERIFIED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public void CH1_IAM_FR_0007_A_tampered_signature_is_refused()
    {
        var fixture = new AssertionFixture();
        var assertion = fixture.Assertion();
        assertion.Signature[^1] ^= 0xFF;

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.Verify(
            assertion, fixture.Challenge, fixture.Credential, requireUserVerification: true));

        Assert.Equal("PASSKEY_SIGNATURE_INVALID", error.Code);
    }

    /// <summary>
    /// A COSE_Key from a real authenticator must convert to something the verifier can
    /// use. Round-tripped through a generated P-256 key so the assertion is that the
    /// reader recovers exactly the key that was encoded, not merely that it parses.
    /// </summary>
    [Fact]
    public void CH1_IAM_FR_0005_A_COSE_P256_key_converts_to_the_same_public_key()
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var parameters = key.ExportParameters(includePrivateParameters: false);

        var spki = WebAuthnVerifier.CoseKeyToSpki(AssertionFixture.CoseP256(parameters));

        Assert.Equal(key.ExportSubjectPublicKeyInfo(), spki);
    }

    [Fact]
    public void CH1_IAM_FR_0005_An_unsupported_COSE_key_type_is_refused_rather_than_stored()
    {
        // kty = 4 (symmetric): valid CBOR, not an acceptable authenticator key.
        byte[] cose = [0xA1, 0x01, 0x04];

        var error = Assert.Throws<DomainRuleException>(() => WebAuthnVerifier.CoseKeyToSpki(cose));

        Assert.Equal("PASSKEY_COSE_KEY_TYPE_UNSUPPORTED", error.Code);
    }

    /// <summary>
    /// Builds a genuine assertion with a real signature, then lets each test spoil one
    /// property. Everything the authenticator would produce is produced here, so a test
    /// that passes is evidence about the verifier and not about the fixture.
    /// </summary>
    private sealed class AssertionFixture
    {
        private readonly ECDsa key = ECDsa.Create(ECCurve.NamedCurves.nistP256);

        public AssertionFixture()
        {
            Challenge = new WebAuthnChallenge(
                Guid.CreateVersion7(), Guid.CreateVersion7(), "operator-1",
                RandomNumberGenerator.GetBytes(32), RpId, Origin, StepUpPurpose.PartRelease,
                DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(2), null);

            Credential = CredentialRecord.EnrolFido(
                Guid.CreateVersion7(), Challenge.ProjectId, "operator-1", CredentialKind.Passkey,
                "Security key", key.ExportSubjectPublicKeyInfo(), [1, 2, 3, 4], null, RpId,
                UserVerificationRequirement.Required, "admin-1", DateTimeOffset.UtcNow);
        }

        public WebAuthnChallenge Challenge { get; }

        public CredentialRecord Credential { get; }

        public string ClientType { get; init; } = "webauthn.get";

        public string ClientOrigin { get; init; } = Origin;

        public byte[]? ClientChallenge { get; init; }

        public string AuthenticatorRpId { get; init; } = RpId;

        public bool UserVerified { get; init; } = true;

        public WebAuthnAssertion Assertion()
        {
            var challengeBytes = ClientChallenge ?? Challenge.Challenge;
            var clientDataJson = Encoding.UTF8.GetBytes(
                $$"""
                {"type":"{{ClientType}}","challenge":"{{Base64Url.Encode(challengeBytes)}}","origin":"{{ClientOrigin}}"}
                """);

            var authenticatorData = new byte[37];
            SHA256.HashData(Encoding.UTF8.GetBytes(AuthenticatorRpId)).CopyTo(authenticatorData, 0);
            authenticatorData[32] = (byte)(0x01 | (UserVerified ? 0x04 : 0x00));
            System.Buffers.Binary.BinaryPrimitives.WriteUInt32BigEndian(
                authenticatorData.AsSpan(33, 4), 7);

            var payload = new byte[authenticatorData.Length + 32];
            authenticatorData.CopyTo(payload, 0);
            SHA256.HashData(clientDataJson).CopyTo(payload, authenticatorData.Length);

            var signature = key.SignData(
                payload, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence);

            return new WebAuthnAssertion([1, 2, 3, 4], authenticatorData, clientDataJson, signature);
        }

        /// <summary>Encodes an EC public key exactly as an authenticator would, in COSE.</summary>
        public static byte[] CoseP256(ECParameters parameters)
        {
            // {1: 2, 3: -7, -1: 1, -2: x, -3: y}
            var buffer = new List<byte> { 0xA5, 0x01, 0x02, 0x03, 0x26, 0x20, 0x01 };
            buffer.Add(0x21);
            buffer.Add(0x58);
            buffer.Add((byte)parameters.Q.X!.Length);
            buffer.AddRange(parameters.Q.X!);
            buffer.Add(0x22);
            buffer.Add(0x58);
            buffer.Add((byte)parameters.Q.Y!.Length);
            buffer.AddRange(parameters.Q.Y!);
            return [.. buffer];
        }
    }
}
