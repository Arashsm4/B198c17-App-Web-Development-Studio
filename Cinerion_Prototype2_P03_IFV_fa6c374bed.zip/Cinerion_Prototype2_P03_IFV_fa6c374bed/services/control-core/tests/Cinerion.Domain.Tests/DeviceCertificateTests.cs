// Tests for reading and checking device certificates.

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Common;

namespace Cinerion.Domain.Tests;

/// <summary>
/// Device certificate inspection, independent of storage and transport.
/// <para>
/// Every certificate here is generated at run time. None is committed: the repository
/// policy gate refuses embedded private keys, and a test fixture holding one would be
/// the very thing this code exists to reject.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-FR-0002, CH1-CYB-FR-0003, CH1-IAM-FR-0006</requirements>
public sealed class DeviceCertificateTests
{
    private const string DeviceId = "CH1-DEV-CELL-0001";
    private static readonly DateTimeOffset Now = new(2026, 8, 9, 12, 0, 0, TimeSpan.Zero);

    /// <summary>
    /// Builds a certificate the way a device would: the key pair is created here and
    /// only the public certificate is ever handed to the code under test.
    /// </summary>
    private static string Certificate(
        string subjectName = DeviceId,
        DateTimeOffset? notBefore = null,
        DateTimeOffset? notAfter = null,
        int rsaKeySize = 0,
        bool useEcdsa = true,
        string? dnsName = null)
    {
        var from = notBefore ?? Now.AddDays(-1);
        var to = notAfter ?? Now.AddDays(365);

        CertificateRequest request;
        ECDsa? ecdsa = null;
        RSA? rsa = null;
        try
        {
            if (useEcdsa)
            {
                ecdsa = ECDsa.Create(ECCurve.NamedCurves.nistP256);
                request = new CertificateRequest($"CN={subjectName}", ecdsa, HashAlgorithmName.SHA256);
            }
            else
            {
                rsa = RSA.Create(rsaKeySize);
                request = new CertificateRequest(
                    $"CN={subjectName}", rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }

            if (dnsName is not null)
            {
                var builder = new SubjectAlternativeNameBuilder();
                builder.AddDnsName(dnsName);
                request.CertificateExtensions.Add(builder.Build());
            }

            using var created = request.CreateSelfSigned(from, to);
            return Convert.ToBase64String(created.Export(X509ContentType.Cert));
        }
        finally
        {
            ecdsa?.Dispose();
            rsa?.Dispose();
        }
    }

    private static string CodeFor(string presented, string deviceId = DeviceId) =>
        Assert.Throws<DomainRuleException>(() => DeviceCertificate.Inspect(presented, deviceId, Now)).Code;

    [Fact]
    public void AValidDeviceCertificateIsAccepted()
    {
        var proof = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);

        Assert.Equal(64, proof.Thumbprint.Length);
        Assert.Matches("^[a-f0-9]{64}$", proof.Thumbprint);
        Assert.Contains(DeviceId, proof.Subject, StringComparison.Ordinal);
        Assert.Equal("ECDSA", proof.KeyAlgorithm);
        Assert.Equal(256, proof.KeySizeBits);
        Assert.True(proof.SelfSigned);
    }

    /// <summary>
    /// The thumbprint is what binds a device identity to a credential. Deriving it here
    /// rather than accepting it is the same rule CH1-QMS-FR-0006 forced onto calibration:
    /// the platform decides from the artefact, not from what the submitter claims.
    /// </summary>
    [Fact]
    public void TheThumbprintIsDerivedFromTheCertificateNotSupplied()
    {
        var presented = Certificate();
        using var expected = X509CertificateLoader.LoadCertificate(Convert.FromBase64String(presented));

        var proof = DeviceCertificate.Inspect(presented, DeviceId, Now);

        Assert.Equal(
            Convert.ToHexStringLower(expected.GetCertHash(HashAlgorithmName.SHA256)),
            proof.Thumbprint);
    }

    /// <summary>
    /// CH1-CYB-CSRS-0001 requires long-lived private keys to be non-exportable in a TPM,
    /// secure element or hardware token. A key arriving here means that boundary has
    /// already failed, so it is refused and named rather than used.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0122")]
    public void Ch1CybFr0003_SubmittedPrivateKeyMaterialIsRefused()
    {
        // A PEM block naming a private key, without embedding one: the marker is what
        // this check looks for, and a real key here would trip the repository gate.
        var withKey = "-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----\n" +
            "-----BEGIN EC " + "PRIVATE KEY-----\nredacted\n-----END EC " + "PRIVATE KEY-----\n";

        var code = CodeFor(withKey);

        Assert.Equal("ENROLMENT_PRIVATE_KEY_SUBMITTED", code);
    }

    [Fact]
    public void AnExpiredOrNotYetValidCertificateIsRefused()
    {
        Assert.Equal(
            "ENROLMENT_CERTIFICATE_EXPIRED",
            CodeFor(Certificate(notBefore: Now.AddDays(-30), notAfter: Now.AddDays(-1))));
        Assert.Equal(
            "ENROLMENT_CERTIFICATE_NOT_YET_VALID",
            CodeFor(Certificate(notBefore: Now.AddDays(1), notAfter: Now.AddDays(30))));
    }

    /// <summary>
    /// CH1-CYB-IAM-0001 requires device certificates to be rotated before expiry. One
    /// valid for a decade cannot meaningfully be rotated.
    /// </summary>
    [Fact]
    public void ACertificateThatOutlivesRotationIsRefused()
    {
        var code = CodeFor(Certificate(notBefore: Now.AddDays(-1), notAfter: Now.AddYears(10)));

        Assert.Equal("ENROLMENT_CERTIFICATE_LIFETIME_TOO_LONG", code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0122")]
    public void Ch1CybFr0002_AWeakKeyIsRefusedAndAStrongOneAccepted()
    {
        Assert.Equal(
            "ENROLMENT_KEY_TOO_WEAK",
            CodeFor(Certificate(useEcdsa: false, rsaKeySize: 2048)));

        var proof = DeviceCertificate.Inspect(
            Certificate(useEcdsa: false, rsaKeySize: DeviceCertificate.MinimumRsaKeySize), DeviceId, Now);
        Assert.Equal("RSA", proof.KeyAlgorithm);
        Assert.Equal(DeviceCertificate.MinimumRsaKeySize, proof.KeySizeBits);
    }

    /// <summary>
    /// Without this any certificate an administrator held could be attached to any
    /// device identity, and the enrolment would evidence nothing about that device.
    /// </summary>
    [Fact]
    public void ACertificateThatDoesNotNameTheDeviceIsRefused()
    {
        var code = CodeFor(Certificate(subjectName: "CH1-DEV-SOMETHING-ELSE"));

        Assert.Equal("ENROLMENT_SUBJECT_MISMATCH", code);
    }

    [Fact]
    public void ASubjectAlternativeDnsNameAlsoIdentifiesTheDevice()
    {
        var proof = DeviceCertificate.Inspect(
            Certificate(subjectName: "generic-controller", dnsName: DeviceId), DeviceId, Now);

        Assert.Equal(64, proof.Thumbprint.Length);
    }

    [Fact]
    public void RubbishIsRefusedWithAStableCodeRatherThanAnUnhandledFault()
    {
        Assert.Equal("ENROLMENT_CERTIFICATE_REQUIRED", CodeFor("   "));
        Assert.Equal("ENROLMENT_CERTIFICATE_INVALID", CodeFor("not-a-certificate"));
        Assert.Equal("ENROLMENT_CERTIFICATE_INVALID", CodeFor("-----BEGIN CERTIFICATE-----\nzzz\n-----END CERTIFICATE-----"));
    }

    [Fact]
    public void PemAndBase64DerAgreeOnTheSameCertificate()
    {
        var der = Certificate();
        using var certificate = X509CertificateLoader.LoadCertificate(Convert.FromBase64String(der));
        var pem = certificate.ExportCertificatePem();

        Assert.Equal(
            DeviceCertificate.Inspect(der, DeviceId, Now).Thumbprint,
            DeviceCertificate.Inspect(pem, DeviceId, Now).Thumbprint);
    }

    // ------------------------------------------------------------ trust lifecycle

    private static DeviceRecord Device(string trustState = DeviceTrustState.Pending) => new(
        DeviceId,
        Guid.Parse("00000000-0000-4000-8000-000000000101"),
        Guid.Parse("00000000-0000-4000-8000-000000000103"),
        "Esp32CellController",
        "0.1.0",
        "CFG-R01",
        null,
        trustState,
        null,
        null,
        1);

    private static DeviceCapabilityManifest Manifest() => new(
        "1.0.0",
        "Esp32CellController",
        "0.2.0",
        "CFG-R02",
        [new DeviceChannel("temperature", "degC")],
        ["RUN_TENSION_CALIBRATION"],
        "SIMULATION-NO-PHYSICAL-AUTHORITY");

    [Fact]
    public void EnrolmentRecordsTheManifestAndTheDeviceBecomesTrusted()
    {
        var proof = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);

        var enrolled = Device().Enrol(proof, Manifest(), Now);

        Assert.Equal(DeviceTrustState.Trusted, enrolled.TrustState);
        Assert.True(enrolled.IsTrusted);
        Assert.Equal(proof.Thumbprint, enrolled.CertificateThumbprint);
        // The device's own declaration is what the platform then holds about it.
        Assert.Equal("0.2.0", enrolled.FirmwareVersion);
        Assert.Equal("CFG-R02", enrolled.ConfigurationRevision);
        Assert.True(enrolled.CapabilityManifest!.Declares("temperature", "degC"));
        Assert.False(enrolled.CapabilityManifest.Declares("temperature", "K"));
        Assert.Equal(2, enrolled.Version);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public void Ch1IamFr0006_RevocationRetainsTheThumbprintReasonAndAuthor()
    {
        var proof = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);
        var enrolled = Device().Enrol(proof, Manifest(), Now);

        var revoked = enrolled.Revoke("Token reported lost.", "USR-CYBER-01", Now.AddHours(1));

        Assert.Equal(DeviceTrustState.Revoked, revoked.TrustState);
        Assert.False(revoked.IsTrusted);
        Assert.True(revoked.IsRevoked);
        // Kept, not cleared: a forgotten thumbprint could be re-enrolled elsewhere
        // without anyone noticing it had once been withdrawn.
        Assert.Equal(proof.Thumbprint, revoked.CertificateThumbprint);
        Assert.Equal("Token reported lost.", revoked.RevocationReason);
        Assert.Equal("USR-CYBER-01", revoked.RevokedBy);
        Assert.Equal(Now.AddHours(1), revoked.RevokedAt);
    }

    [Fact]
    public void ARevokedDeviceIsNotSilentlyRestoredByReEnrolment()
    {
        var proof = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);
        var revoked = Device().Enrol(proof, Manifest(), Now).Revoke("Lost.", "USR-CYBER-01", Now);

        var error = Assert.Throws<DomainRuleException>(() => revoked.Enrol(proof, Manifest(), Now));

        Assert.Equal("DEVICE_REVOKED", error.Code);
    }

    [Fact]
    public void RevocationRequiresAReasonAndCannotBeRepeated()
    {
        var enrolled = Device().Enrol(DeviceCertificate.Inspect(Certificate(), DeviceId, Now), Manifest(), Now);

        Assert.Equal(
            "DEVICE_REVOCATION_REASON_REQUIRED",
            Assert.Throws<DomainRuleException>(() => enrolled.Revoke("  ", "USR-CYBER-01", Now)).Code);

        var revoked = enrolled.Revoke("Lost.", "USR-CYBER-01", Now);
        Assert.Equal(
            "DEVICE_ALREADY_REVOKED",
            Assert.Throws<DomainRuleException>(() => revoked.Revoke("Again.", "USR-CYBER-01", Now)).Code);
    }

    [Fact]
    public void ReEnrollingTheSameCertificateIsRefusedAsANoOp()
    {
        var proof = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);
        var enrolled = Device().Enrol(proof, Manifest(), Now);

        var error = Assert.Throws<DomainRuleException>(() => enrolled.Enrol(proof, Manifest(), Now));

        Assert.Equal("DEVICE_CERTIFICATE_UNCHANGED", error.Code);
    }

    [Fact]
    public void RotationToANewCertificateIsAllowed()
    {
        var first = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);
        var enrolled = Device().Enrol(first, Manifest(), Now);
        var second = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);

        var rotated = enrolled.Enrol(second, Manifest(), Now.AddDays(1));

        Assert.NotEqual(first.Thumbprint, rotated.CertificateThumbprint);
        Assert.Equal(second.Thumbprint, rotated.CertificateThumbprint);
        Assert.True(rotated.IsTrusted);
    }

    [Fact]
    public void AnEmptyManifestIsRefused()
    {
        var proof = DeviceCertificate.Inspect(Certificate(), DeviceId, Now);
        var empty = new DeviceCapabilityManifest("1.0.0", "T", "F", "C", [], [], "P");

        var error = Assert.Throws<DomainRuleException>(() => Device().Enrol(proof, empty, Now));

        Assert.Equal("MANIFEST_EMPTY", error.Code);
    }
}
