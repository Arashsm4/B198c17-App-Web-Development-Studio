// Tests for capacity arithmetic. Double-booking doesn't get past these.

using Cinerion.Domain.Common;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

/// <summary>
/// Capacity arithmetic, independent of storage and transport. This is the calculation
/// CH1-VVT-TC-0106 checks: capacity, reservations and conflicts computed correctly and
/// linked to the right order.
/// </summary>
/// <requirements>CH1-MGT-FR-0003, CH1-MGT-FR-0004</requirements>
public sealed class CapacityLedgerTests
{
    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-0000000000b1");
    private static readonly Guid ResourceId = Guid.Parse("00000000-0000-4000-8000-0000000000b2");
    private static readonly Guid WorkOrderId = Guid.Parse("00000000-0000-4000-8000-0000000000b3");
    private static readonly DateTimeOffset Noon = new(2026, 8, 10, 12, 0, 0, TimeSpan.Zero);

    private static ResourceRecord Resource(decimal capacity = 10m) => ResourceRecord.Create(
        ResourceId, ProjectId, "Equipment", "Coating station", capacity, "station",
        ResourceAvailabilityState.Available);

    private static ActorContext Coordinator(string actorId = "USR-COORDINATOR-01") => new(
        actorId,
        ActorKind.Human,
        new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.OperationsCoordinator },
        AuthenticationStrength.Mfa,
        ProjectId,
        new HashSet<Guid>(),
        "session-1");

    private static ResourceAllocation Reserved(decimal quantity, int fromHour, int toHour) =>
        ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), WorkOrderId, null, quantity,
            Noon.AddHours(fromHour), Noon.AddHours(toHour), Coordinator());

    [Fact]
    public void CommittedQuantityIsTheSumOfOverlappingReservations()
    {
        ResourceAllocation[] allocations = [Reserved(3m, 0, 4), Reserved(2m, 2, 6)];

        Assert.Equal(3m, CapacityLedger.CommittedAt(allocations, Noon.AddHours(1)));
        Assert.Equal(5m, CapacityLedger.CommittedAt(allocations, Noon.AddHours(3)));
        Assert.Equal(2m, CapacityLedger.CommittedAt(allocations, Noon.AddHours(5)));
        // Half-open: the instant a reservation ends is no longer committed by it.
        Assert.Equal(0m, CapacityLedger.CommittedAt(allocations, Noon.AddHours(6)));
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0106")]
    public void PeakFindsTheWorstMomentInTheWindow()
    {
        ResourceAllocation[] allocations = [Reserved(3m, 0, 4), Reserved(2m, 2, 6), Reserved(4m, 8, 9)];

        var (peak, at) = CapacityLedger.Peak(allocations, Noon, Noon.AddHours(10));

        Assert.Equal(5m, peak);
        Assert.Equal(Noon.AddHours(2), at);
    }

    [Fact]
    public void ACancelledReservationHoldsNoCapacity()
    {
        var live = Reserved(6m, 0, 4);
        var cancelled = Reserved(6m, 0, 4).Cancel(Coordinator(), "No longer needed.", Noon);

        Assert.Equal(6m, CapacityLedger.CommittedAt([live, cancelled], Noon.AddHours(1)));
    }

    [Fact]
    public void AdmitsAcceptsUpToCapacityAndRefusesBeyondIt()
    {
        ResourceAllocation[] allocations = [Reserved(7m, 0, 4)];

        var exact = CapacityLedger.Admits(allocations, 10m, 3m, Noon, Noon.AddHours(4));
        var over = CapacityLedger.Admits(allocations, 10m, 4m, Noon, Noon.AddHours(4));

        Assert.True(exact.Fits);
        Assert.Equal(10m, exact.PeakWithRequest);
        Assert.False(over.Fits);
        Assert.Equal(11m, over.PeakWithRequest);
    }

    /// <summary>
    /// The check has to look at every moment of the candidate interval, not only its
    /// start. A request that fits when it begins and collides later must be refused.
    /// </summary>
    [Fact]
    public void AdmitsRefusesACollisionThatOnlyHappensLaterInTheInterval()
    {
        ResourceAllocation[] allocations = [Reserved(8m, 3, 6)];

        var result = CapacityLedger.Admits(allocations, 10m, 5m, Noon, Noon.AddHours(6));

        Assert.False(result.Fits);
        Assert.Equal(13m, result.PeakWithRequest);
        Assert.Equal(Noon.AddHours(3), result.At);
    }

    [Fact]
    public void NonOverlappingReservationsDoNotCompete()
    {
        ResourceAllocation[] allocations = [Reserved(10m, 0, 4)];

        var result = CapacityLedger.Admits(allocations, 10m, 10m, Noon.AddHours(4), Noon.AddHours(8));

        Assert.True(result.Fits);
    }

    /// <summary>
    /// Reservations refuse to over-commit, but capacity reduced after the fact can leave
    /// an interval over-committed. CH1-MGT-FR-0004 requires that state to be exposed.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0106")]
    public void ConflictsAreReportedWhenCapacityNoLongerCoversWhatWasReserved()
    {
        ResourceAllocation[] allocations = [Reserved(6m, 0, 4), Reserved(3m, 2, 6)];

        var conflicts = CapacityLedger.Conflicts(allocations, 8m, Noon, Noon.AddHours(8));

        var conflict = Assert.Single(conflicts);
        Assert.Equal(Noon.AddHours(2), conflict.From);
        Assert.Equal(Noon.AddHours(4), conflict.To);
        Assert.Equal(9m, conflict.Committed);
        Assert.Equal(8m, conflict.Capacity);
        Assert.Equal(1m, conflict.OverCommittedBy);
    }

    [Fact]
    public void NoConflictIsReportedWhileCapacityCovers()
    {
        ResourceAllocation[] allocations = [Reserved(6m, 0, 4), Reserved(3m, 2, 6)];

        Assert.Empty(CapacityLedger.Conflicts(allocations, 10m, Noon, Noon.AddHours(8)));
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0106")]
    public void AReservationMustNameExactlyOneOfAWorkOrderOrAnExperiment()
    {
        var neither = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), null, null, 1m, Noon, Noon.AddHours(1), Coordinator()));
        var both = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), WorkOrderId, Guid.NewGuid(), 1m, Noon, Noon.AddHours(1), Coordinator()));

        Assert.Equal("ALLOCATION_LINK_REQUIRED", neither.Code);
        Assert.Equal("ALLOCATION_LINK_REQUIRED", both.Code);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void AReservationQuantityMustBePositive(int quantity)
    {
        var error = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), WorkOrderId, null, quantity, Noon, Noon.AddHours(1), Coordinator()));

        Assert.Equal("ALLOCATION_QUANTITY_INVALID", error.Code);
    }

    [Fact]
    public void AReservationMustEndAfterItBeginsAndStayBounded()
    {
        var inverted = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), WorkOrderId, null, 1m, Noon.AddHours(2), Noon, Coordinator()));
        var endless = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), WorkOrderId, null, 1m, Noon, Noon.AddDays(365), Coordinator()));

        Assert.Equal("ALLOCATION_INTERVAL_INVALID", inverted.Code);
        Assert.Equal("ALLOCATION_INTERVAL_TOO_LONG", endless.Code);
    }

    [Fact]
    public void AResourceUnderMaintenanceAcceptsNoNewReservations()
    {
        var maintenance = Resource() with { AvailabilityState = ResourceAvailabilityState.Maintenance };

        var error = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), maintenance, WorkOrderId, null, 1m, Noon, Noon.AddHours(1), Coordinator()));

        Assert.Equal("RESOURCE_NOT_AVAILABLE", error.Code);
        Assert.False(maintenance.AcceptsReservations);
    }

    [Fact]
    public void ARequestLargerThanTheWholeResourceIsRefusedOutright()
    {
        var error = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(10m), WorkOrderId, null, 11m, Noon, Noon.AddHours(1), Coordinator()));

        Assert.Equal("ALLOCATION_EXCEEDS_CAPACITY", error.Code);
    }

    /// <summary>
    /// A cancelled reservation is kept, not deleted: CH1-MGT-FR-0003 requires assignment
    /// changes to be attributable, revisioned and reversible.
    /// </summary>
    [Fact]
    public void CancellationRetainsWhoWhyAndWhenAndAdvancesTheVersion()
    {
        var reservation = Reserved(4m, 0, 4);

        var cancelled = reservation.Cancel(Coordinator("USR-COORDINATOR-02"), "Work order rescheduled.", Noon.AddHours(1));

        Assert.Equal(AllocationStatus.Cancelled, cancelled.Status);
        Assert.Equal("USR-COORDINATOR-02", cancelled.CancelledBy);
        Assert.Equal("Work order rescheduled.", cancelled.CancellationReason);
        Assert.Equal(Noon.AddHours(1), cancelled.CancelledAt);
        Assert.Equal(reservation.Version + 1, cancelled.Version);
        // The original reservation is still fully described.
        Assert.Equal(reservation.Quantity, cancelled.Quantity);
        Assert.Equal(reservation.StartsAt, cancelled.StartsAt);
        Assert.Equal(reservation.WorkOrderId, cancelled.WorkOrderId);
        Assert.Equal(reservation.RequestedBy, cancelled.RequestedBy);
    }

    [Fact]
    public void CancellationRequiresAReasonAndCannotBeRepeated()
    {
        var reservation = Reserved(4m, 0, 4);

        var noReason = Assert.Throws<DomainRuleException>(() => reservation.Cancel(Coordinator(), "  ", Noon));
        var cancelled = reservation.Cancel(Coordinator(), "Rescheduled.", Noon);
        var twice = Assert.Throws<DomainRuleException>(() => cancelled.Cancel(Coordinator(), "Again.", Noon));

        Assert.Equal("ALLOCATION_CANCELLATION_REASON_REQUIRED", noReason.Code);
        Assert.Equal("ALLOCATION_ALREADY_CANCELLED", twice.Code);
    }

    [Fact]
    public void AnActorFromAnotherProjectCanNeitherReserveNorCancel()
    {
        var outsider = Coordinator() with { ProjectId = Guid.NewGuid() };

        var reserve = Assert.Throws<DomainRuleException>(() => ResourceAllocation.Reserve(
            Guid.NewGuid(), Resource(), WorkOrderId, null, 1m, Noon, Noon.AddHours(1), outsider));
        var cancel = Assert.Throws<DomainRuleException>(() => Reserved(1m, 0, 1).Cancel(outsider, "Probe.", Noon));

        Assert.Equal("AUTH_PROJECT_SCOPE", reserve.Code);
        Assert.Equal("AUTH_PROJECT_SCOPE", cancel.Code);
    }

    [Fact]
    public void TheResourceWindowIsBoundedAndTheCursorRoundTrips()
    {
        var now = Noon;

        var (from, to) = ResourceQuery.Window(null, null, now);
        Assert.Equal(now, from);
        Assert.Equal(ResourceQuery.DefaultWindow, to - from);

        var tooWide = Assert.Throws<DomainRuleException>(
            () => ResourceQuery.Window(now, now.AddDays(365), now));
        Assert.Equal("RESOURCE_WINDOW_TOO_WIDE", tooWide.Code);

        // A resource name may itself contain the cursor separator.
        var cursor = new ResourceCursor("Coating | station 01", ResourceId);
        var decoded = ResourceCursor.Decode(cursor.Encode());
        Assert.Equal(cursor.Name, decoded!.Name);
        Assert.Equal(cursor.ResourceId, decoded.ResourceId);
        Assert.Null(ResourceCursor.Decode(null));
        Assert.Equal(
            "RESOURCE_CURSOR_INVALID",
            Assert.Throws<DomainRuleException>(() => ResourceCursor.Decode("zzzz")).Code);
    }
}
