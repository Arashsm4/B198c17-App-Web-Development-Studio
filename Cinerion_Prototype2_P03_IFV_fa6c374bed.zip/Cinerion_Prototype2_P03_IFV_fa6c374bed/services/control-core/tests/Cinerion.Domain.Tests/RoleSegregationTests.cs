// Tests for which roles aren't allowed to share a desk.

using Cinerion.Domain.Common;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

/// <summary>
/// The segregation rules on role assignment, independent of any identity provider.
/// </summary>
/// <requirements>CH1-CYB-ACP-0001, CH1-IAM-FR-0008</requirements>
public sealed class RoleSegregationTests
{
    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-0000000000c1");

    private static IdentityUser Subject(params string[] roles) => new(
        "kc-user-1",
        "ch1-operator",
        "CH1 Operator",
        true,
        ProjectId,
        [],
        roles,
        ActorKind.Human,
        DateTimeOffset.UnixEpoch);

    private static ActorContext Administrator(string actorId = "USR-SYSADMIN-01") => new(
        actorId,
        ActorKind.Human,
        new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.SystemAdministrator },
        AuthenticationStrength.StepUpPhishingResistant,
        ProjectId,
        new HashSet<Guid>(),
        "session-admin");

    private static string CodeFor(IdentityUser subject, string[] roles, ActorContext administrator) =>
        Assert.Throws<DomainRuleException>(
            () => RoleSegregation.EnsureAssignable(subject, roles, administrator)).Code;

    [Fact]
    public void AnOrdinaryRoleChangeIsAllowed()
    {
        RoleSegregation.EnsureAssignable(
            Subject(CinerionRoles.Viewer),
            [CinerionRoles.Viewer, CinerionRoles.Engineer],
            Administrator());
    }

    /// <summary>
    /// access.json: "Manage users | System Administrator | Hardware-backed MFA |
    /// <em>No security-policy authority</em>". Granting the Cybersecurity Administrator
    /// role would hand over exactly that authority.
    /// </summary>
    [Fact]
    public void Ch1CybAcp0001_AUserAdministratorCannotGrantSecurityPolicyAuthority()
    {
        var granting = CodeFor(
            Subject(CinerionRoles.Viewer),
            [CinerionRoles.Viewer, CinerionRoles.CybersecurityAdministrator],
            Administrator());

        Assert.Equal("ROLE_SECURITY_POLICY_AUTHORITY", granting);
    }

    /// <summary>
    /// Withdrawal is the same authority as grant: an administrator who could strip the
    /// Cybersecurity Administrator role could disable security oversight of themselves.
    /// </summary>
    [Fact]
    public void Ch1CybAcp0001_AUserAdministratorCannotWithdrawSecurityPolicyAuthorityEither()
    {
        var withdrawing = CodeFor(
            Subject(CinerionRoles.Viewer, CinerionRoles.CybersecurityAdministrator),
            [CinerionRoles.Viewer],
            Administrator());

        Assert.Equal("ROLE_SECURITY_POLICY_AUTHORITY", withdrawing);
    }

    [Fact]
    public void Ch1CybAcp0001_IncompatibleRolesCannotBeHeldTogether()
    {
        // "A System Administrator manages general configuration but not root
        // cybersecurity policy." The subject already holds CybersecurityAdministrator and
        // the request keeps it, so nothing security-policy is granted or withdrawn and
        // the incompatible-pair rule is what refuses the combination.
        var administratorPair = CodeFor(
            Subject(CinerionRoles.CybersecurityAdministrator),
            [CinerionRoles.SystemAdministrator, CinerionRoles.CybersecurityAdministrator],
            Administrator());
        Assert.Equal("ROLE_SEGREGATION_CONFLICT", administratorPair);

        // "A Cybersecurity Administrator ... cannot release parts."
        var releasePair = CodeFor(
            Subject(CinerionRoles.CybersecurityAdministrator, CinerionRoles.Inspector),
            [CinerionRoles.CybersecurityAdministrator, CinerionRoles.Inspector, CinerionRoles.Viewer],
            Administrator());
        Assert.Equal("ROLE_SEGREGATION_CONFLICT", releasePair);
    }

    /// <summary>
    /// CH1-IAM-FR-0008 requires separate human, service and device accounts, and
    /// DeviceController is deliberately absent from the human realm.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0008")]
    public void Ch1IamFr0008_ADeviceRoleCannotBeAssignedToAPerson()
    {
        var code = CodeFor(
            Subject(CinerionRoles.Viewer),
            [CinerionRoles.Viewer, CinerionRoles.DeviceController],
            Administrator());

        Assert.Equal("ROLE_NOT_ASSIGNABLE_TO_HUMAN", code);
    }

    /// <summary>
    /// The shortest path to escalation there is, and it would defeat every other rule
    /// here. Checked against both the username and the provider's user identifier,
    /// because either could be what the caller's token carries.
    /// </summary>
    [Fact]
    public void AnAdministratorCannotChangeTheirOwnRoles()
    {
        var byUsername = CodeFor(
            Subject(CinerionRoles.Viewer),
            [CinerionRoles.Viewer, CinerionRoles.Engineer],
            Administrator("ch1-operator"));
        var byUserId = CodeFor(
            Subject(CinerionRoles.Viewer),
            [CinerionRoles.Viewer, CinerionRoles.Engineer],
            Administrator("kc-user-1"));

        Assert.Equal("ROLE_SELF_ASSIGNMENT", byUsername);
        Assert.Equal("ROLE_SELF_ASSIGNMENT", byUserId);
    }

    [Fact]
    public void AnUnknownRoleIsRefused()
    {
        var code = CodeFor(Subject(CinerionRoles.Viewer), [CinerionRoles.Viewer, "Superuser"], Administrator());

        Assert.Equal("ROLE_UNKNOWN", code);
    }

    /// <summary>
    /// Removing every role would leave an account that still authenticates but is
    /// authorised for nothing, which reads as a broken account rather than a disabled
    /// one. Disabling is a different, explicit act.
    /// </summary>
    [Fact]
    public void AnEmptyRoleSetIsRefusedRatherThanSilentlyDisablingTheAccount()
    {
        var code = CodeFor(Subject(CinerionRoles.Viewer), [], Administrator());

        Assert.Equal("ROLE_SET_EMPTY", code);
    }

    [Fact]
    public void EverySegregationRuleQuotesAControlledRole()
    {
        Assert.All(
            RoleSegregation.SecurityPolicyRoles.Concat(RoleSegregation.NonHumanRoles),
            role => Assert.Contains(role, CinerionRoles.All, StringComparer.Ordinal));
        Assert.All(
            RoleSegregation.IncompatiblePairs,
            pair =>
            {
                Assert.Contains(pair.First, CinerionRoles.All, StringComparer.Ordinal);
                Assert.Contains(pair.Second, CinerionRoles.All, StringComparer.Ordinal);
                Assert.False(string.IsNullOrWhiteSpace(pair.Reason));
            });
    }

    [Fact]
    public void TheUserCursorRoundTripsAndRefusesRubbish()
    {
        Assert.Equal(0, UserCursor.Decode(null));
        Assert.Equal(50, UserCursor.Decode(UserCursor.Encode(50)));
        Assert.Equal(
            "USER_CURSOR_INVALID",
            Assert.Throws<DomainRuleException>(() => UserCursor.Decode("zzzz")).Code);
    }

    [Fact]
    public void TheUserQueryClampsItsRowBound()
    {
        var query = UserQuery.Create(ProjectId, "  ", null, 10_000);

        Assert.Equal(UserQuery.MaximumRows, query.Limit);
        Assert.Null(query.Search);
        Assert.Equal(0, query.Offset);
    }
}
