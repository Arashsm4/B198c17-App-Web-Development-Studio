// Tests for step-up: recent, purpose-bound, single use.

using System.Globalization;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

/// <summary>
/// Step-up adds recency, purpose binding and single use to an existing session.
/// These tests assert each of those, and that it can never add authority.
/// </summary>
public sealed class StepUpTests
{
    private static readonly DateTimeOffset Now =
        DateTimeOffset.Parse("2026-08-07T10:00:00Z", CultureInfo.InvariantCulture);

    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-000000000101");

    private static ActorContext Inspector(
        AuthenticationStrength strength = AuthenticationStrength.StepUpPhishingResistant,
        DateTimeOffset? authenticatedAt = null,
        string actorId = "USR-INSPECTOR-01",
        string sessionId = "session-1") =>
        new(
            actorId,
            ActorKind.Human,
            new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.Inspector },
            strength,
            ProjectId,
            new HashSet<Guid>(),
            sessionId,
            authenticatedAt ?? Now);

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public void Ch1IamFr0004_RecentStrongAuthenticationYieldsAPurposeBoundGrant()
    {
        var grant = StepUpGrant.Issue(Inspector(), StepUpPurpose.PartRelease, Now);

        Assert.Equal(StepUpPurpose.PartRelease, grant.Purpose);
        Assert.Equal(Now + StepUpGrant.Lifetime, grant.ExpiresAt);
        Assert.Null(grant.ConsumedAt);
    }

    /// <summary>
    /// The grant copies the strength that was actually proven. A step-up must not be
    /// a way to acquire an authenticator class the identity provider never attested.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public void Ch1IamFr0004_GrantCannotExceedTheProvenAuthenticatorClass()
    {
        var grant = StepUpGrant.Issue(Inspector(AuthenticationStrength.Mfa), StepUpPurpose.PartRelease, Now);

        Assert.Equal(AuthenticationStrength.Mfa, grant.Strength);

        var error = Assert.Throws<DomainRuleException>(() => grant.EnsureUsableBy(
            Inspector(AuthenticationStrength.Mfa),
            StepUpPurpose.PartRelease,
            AuthenticationStrength.StepUpPhishingResistant,
            Now));
        Assert.Equal("AUTH_STRONGER_AUTHENTICATOR_REQUIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public void Ch1IamFr0004_StaleAuthenticationCannotStepUp()
    {
        var stale = Inspector(authenticatedAt: Now - StepUpGrant.MaximumAuthenticationAge - TimeSpan.FromSeconds(1));

        var error = Assert.Throws<DomainRuleException>(
            () => StepUpGrant.Issue(stale, StepUpPurpose.PartRelease, Now));
        Assert.Equal("AUTH_REAUTHENTICATION_REQUIRED", error.Code);
    }

    /// <summary>
    /// An identity provider that does not state auth_time leaves recency unknown.
    /// Unknown must fail closed, not be treated as freshly authenticated.
    /// </summary>
    [Fact]
    public void Ch1IamFr0004_UnknownAuthenticationTimeFailsClosed()
    {
        var noAuthTime = Inspector() with { AuthenticatedAt = null };

        var error = Assert.Throws<DomainRuleException>(
            () => StepUpGrant.Issue(noAuthTime, StepUpPurpose.PartRelease, Now));
        Assert.Equal("AUTH_AUTHENTICATION_TIME_UNKNOWN", error.Code);
    }

    [Fact]
    public void Ch1IamFr0004_SingleFactorSessionCannotStepUp()
    {
        var error = Assert.Throws<DomainRuleException>(() => StepUpGrant.Issue(
            Inspector(AuthenticationStrength.SingleFactor), StepUpPurpose.PartRelease, Now));
        Assert.Equal("AUTH_STRONGER_AUTHENTICATOR_REQUIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0008")]
    public void Ch1IamFr0004_ServiceIdentityCannotStepUp()
    {
        var service = Inspector() with { Kind = ActorKind.Service };

        var error = Assert.Throws<DomainRuleException>(
            () => StepUpGrant.Issue(service, StepUpPurpose.PartRelease, Now));
        Assert.Equal("AUTH_HUMAN_REQUIRED", error.Code);
    }

    [Fact]
    public void Ch1IamFr0004_UnknownPurposeIsRejected()
    {
        var error = Assert.Throws<DomainRuleException>(
            () => StepUpGrant.Issue(Inspector(), "ReleaseEverything", Now));
        Assert.Equal("STEP_UP_PURPOSE_UNKNOWN", error.Code);
    }

    /// <summary>A step-up for one sensitive action must not authorise another.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public void Ch1IamFr0004_GrantForOnePurposeCannotBeUsedForAnother()
    {
        var grant = StepUpGrant.Issue(Inspector(), StepUpPurpose.PartRelease, Now);

        var error = Assert.Throws<DomainRuleException>(() => grant.EnsureUsableBy(
            Inspector(), StepUpPurpose.RoleAssignment, AuthenticationStrength.Mfa, Now));
        Assert.Equal("STEP_UP_PURPOSE_MISMATCH", error.Code);
    }

    [Fact]
    public void Ch1IamFr0004_GrantExpiresAndCannotBeUsedAfterwards()
    {
        var grant = StepUpGrant.Issue(Inspector(), StepUpPurpose.PartRelease, Now);

        var error = Assert.Throws<DomainRuleException>(() => grant.EnsureUsableBy(
            Inspector(), StepUpPurpose.PartRelease, AuthenticationStrength.Mfa, grant.ExpiresAt));
        Assert.Equal("STEP_UP_EXPIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public void Ch1IamFr0004_GrantIsSingleUse()
    {
        var grant = StepUpGrant.Issue(Inspector(), StepUpPurpose.PartRelease, Now);
        var consumed = grant.Consume(Now);

        var reuse = Assert.Throws<DomainRuleException>(() => consumed.EnsureUsableBy(
            Inspector(), StepUpPurpose.PartRelease, AuthenticationStrength.Mfa, Now));
        Assert.Equal("STEP_UP_ALREADY_USED", reuse.Code);

        var doubleConsume = Assert.Throws<DomainRuleException>(() => consumed.Consume(Now));
        Assert.Equal("STEP_UP_ALREADY_USED", doubleConsume.Code);
    }

    [Fact]
    public void Ch1IamFr0004_GrantIsBoundToItsIdentityAndSession()
    {
        var grant = StepUpGrant.Issue(Inspector(), StepUpPurpose.PartRelease, Now);

        var otherActor = Assert.Throws<DomainRuleException>(() => grant.EnsureUsableBy(
            Inspector(actorId: "USR-INSPECTOR-02"), StepUpPurpose.PartRelease, AuthenticationStrength.Mfa, Now));
        Assert.Equal("STEP_UP_ACTOR_MISMATCH", otherActor.Code);

        var otherSession = Assert.Throws<DomainRuleException>(() => grant.EnsureUsableBy(
            Inspector(sessionId: "session-2"), StepUpPurpose.PartRelease, AuthenticationStrength.Mfa, Now));
        Assert.Equal("STEP_UP_SESSION_MISMATCH", otherSession.Code);
    }
}
