// Tests for command state transitions, including the ones that must be refused.

using System.Globalization;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

public sealed class CommandTransactionTests
{
    private static readonly DateTimeOffset Now = DateTimeOffset.Parse("2026-08-06T10:00:00Z", CultureInfo.InvariantCulture);

    [Fact]
    [VerificationCase("CH1-VVT-TC-0011")]
    [VerificationCase("CH1-VVT-TC-0012")]
    [VerificationCase("CH1-VVT-TC-0027")]
    public void Ch1VvtTc0011_HappyPathRequiresEveryAuthorityLayer()
    {
        var fixture = CreateFixture();
        var prepared = CommandTransaction.Prepare(fixture.Intent, fixture.Engineer, fixture.Cell, Now);
        var credentialled = prepared.RecordCredentialProof(
            ProofFor(prepared, fixture.Controller),
            fixture.Controller,
            Now.AddSeconds(1));
        var committed = credentialled.LocalCommit(
            ButtonFor(prepared, fixture.Controller, ButtonEventSource.PhysicalInput),
            fixture.Controller,
            fixture.Cell,
            Now.AddSeconds(2));
        var completed = committed.BeginExecution().CompleteExecution();

        Assert.Equal(CommandState.Completed, completed.State);
        Assert.NotNull(completed.LocalCommitId);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0014")]
    public void Ch1VvtTc0014_RemoteButtonCannotCommit()
    {
        var fixture = CreateFixture();
        var prepared = CommandTransaction.Prepare(fixture.Intent, fixture.Engineer, fixture.Cell, Now);
        var credentialled = prepared.RecordCredentialProof(
            ProofFor(prepared, fixture.Controller),
            fixture.Controller,
            Now.AddSeconds(1));

        var error = Assert.Throws<DomainRuleException>(() => credentialled.LocalCommit(
            ButtonFor(prepared, fixture.Controller, ButtonEventSource.RemoteApi),
            fixture.Controller,
            fixture.Cell,
            Now.AddSeconds(2)));

        Assert.Equal("REMOTE_CONFIRMATION_FORBIDDEN", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0016")]
    public void Ch1VvtTc0016_HeldButtonCannotArm()
    {
        var fixture = CreateFixture();
        var error = Assert.Throws<DomainRuleException>(() => CommandTransaction.Prepare(
            fixture.Intent,
            fixture.Engineer,
            fixture.Cell with { ButtonPressed = true },
            Now));
        Assert.Equal("CONFIRM_BUTTON_HELD", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0017")]
    public void Ch1VvtTc0017_ChangedInterlockBlocksFinalCommit()
    {
        var fixture = CreateFixture();
        var prepared = CommandTransaction.Prepare(fixture.Intent, fixture.Engineer, fixture.Cell, Now);
        var credentialled = prepared.RecordCredentialProof(
            ProofFor(prepared, fixture.Controller),
            fixture.Controller,
            Now.AddSeconds(1));
        var error = Assert.Throws<DomainRuleException>(() => credentialled.LocalCommit(
            ButtonFor(prepared, fixture.Controller, ButtonEventSource.PhysicalInput),
            fixture.Controller,
            fixture.Cell with { GuardHealthy = false },
            Now.AddSeconds(2)));
        Assert.Equal("INTERLOCK_GUARD_OPEN", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0018")]
    [VerificationCase("CH1-VVT-TC-0072")]
    public void Ch1VvtTc0018_RestartCancelsUncommittedPrepare()
    {
        var fixture = CreateFixture();
        var prepared = CommandTransaction.Prepare(fixture.Intent, fixture.Engineer, fixture.Cell, Now);
        var reconciled = prepared.ReconcileRestart(Guid.NewGuid());
        Assert.Equal(CommandState.Cancelled, reconciled.State);
        Assert.Equal("CONTROLLER_RESTART", reconciled.TerminalReason);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0019")]
    public void Ch1VvtTc0019_FaultRecoveryIsLocalAndCauseMustBeClear()
    {
        var fixture = CreateFixture();
        var prepared = CommandTransaction.Prepare(fixture.Intent, fixture.Engineer, fixture.Cell, Now);
        var credentialled = prepared.RecordCredentialProof(
            ProofFor(prepared, fixture.Controller),
            fixture.Controller,
            Now.AddSeconds(1));
        var faulted = credentialled.LocalCommit(
                ButtonFor(prepared, fixture.Controller, ButtonEventSource.PhysicalInput),
                fixture.Controller,
                fixture.Cell,
                Now.AddSeconds(2))
            .BeginExecution()
            .LatchFault("POSITION_PLAUSIBILITY");
        var confirmer = fixture.Engineer with
        {
            ActorId = "USR-LOCAL-01",
            Roles = new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.LocalConfirmer },
        };

        var remoteError = Assert.Throws<DomainRuleException>(() => faulted.RecoverFault(
            confirmer,
            fixture.Cell,
            ButtonEventSource.RemoteApi,
            false,
            true));
        Assert.Equal("REMOTE_RESET_FORBIDDEN", remoteError.Code);

        var activeError = Assert.Throws<DomainRuleException>(() => faulted.RecoverFault(
            confirmer,
            fixture.Cell with { FaultCauseActive = true },
            ButtonEventSource.PhysicalInput,
            false,
            true));
        Assert.Equal("FAULT_CAUSE_ACTIVE", activeError.Code);
    }

    private static Fixture CreateFixture()
    {
        var projectId = Guid.NewGuid();
        var siteId = Guid.NewGuid();
        var cellId = Guid.NewGuid();
        var assetId = Guid.NewGuid();
        var workOrderId = Guid.NewGuid();
        var partId = Guid.NewGuid();
        var bootId = Guid.NewGuid();
        var cell = new CellSnapshot(
            projectId,
            siteId,
            cellId,
            assetId,
            "CH1-DEV-CELL-0001",
            bootId,
            CellOperatingState.Idle,
            "CFG-0001-R01",
            workOrderId,
            partId,
            true,
            true,
            true,
            true,
            true,
            false,
            false);
        var engineer = new ActorContext(
            "USR-ENGINEER-01",
            ActorKind.Human,
            new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.Engineer },
            AuthenticationStrength.StepUpPhishingResistant,
            projectId,
            new HashSet<Guid> { cellId },
            "SESSION-01");
        var controller = new ActorContext(
            cell.ControllerId,
            ActorKind.Device,
            new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.DeviceController },
            AuthenticationStrength.MutualTls,
            projectId,
            new HashSet<Guid> { cellId },
            "DEVICE-SESSION-01");
        var intent = new PrepareIntent(
            "RUN_DIMENSIONAL_TEST",
            projectId,
            siteId,
            cellId,
            assetId,
            workOrderId,
            partId,
            "CH1-PROC-0001-R01",
            cell.ConfigurationRevision,
            cell.StateHash(),
            101,
            Now.AddSeconds(60),
            "idem-000000000001",
            new Dictionary<string, object> { ["travelMm"] = 10 });
        return new Fixture(cell, engineer, controller, intent);
    }

    private static CredentialProof ProofFor(CommandTransaction command, ActorContext controller) => new(
        Guid.NewGuid(),
        command.CommandId,
        command.ConfirmationId,
        command.Intent.CellId,
        controller.ActorId,
        Guid.NewGuid(),
        "USR-LOCAL-01",
        AuthenticatorClass.FidoSecurityKey,
        new string('a', 64),
        true,
        true,
        Now.AddSeconds(1),
        Now.AddSeconds(21));

    private static LocalButtonObservation ButtonFor(
        CommandTransaction command,
        ActorContext controller,
        ButtonEventSource source) => new(
        command.CommandId,
        command.ConfirmationId,
        command.Intent.CellId,
        controller.ActorId,
        command.PreparedControllerBootId,
        source,
        false,
        true,
        Now.AddSeconds(2));

    private sealed record Fixture(
        CellSnapshot Cell,
        ActorContext Engineer,
        ActorContext Controller,
        PrepareIntent Intent);
}
