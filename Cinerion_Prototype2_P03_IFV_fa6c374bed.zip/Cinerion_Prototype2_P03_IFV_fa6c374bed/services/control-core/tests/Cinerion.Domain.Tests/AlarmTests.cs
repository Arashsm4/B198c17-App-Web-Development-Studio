// Tests for the alarm life cycle rules.

using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

/// <summary>
/// The alarm lifecycle rules, independent of transport and storage.
/// </summary>
/// <requirements>CH1-AUT-FDS-0001, CH1-COL-FR-0003</requirements>
public sealed class AlarmTests
{
    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-0000000000a1");
    private static readonly Guid CellId = Guid.Parse("00000000-0000-4000-8000-0000000000a2");
    private static readonly DateTimeOffset ActivatedAt = new(2026, 8, 9, 10, 0, 0, TimeSpan.Zero);

    private static Alarm Raised() => Alarm.Raise(
        Guid.NewGuid(), ProjectId, CellId, "CH1-DEV-CELL-0001", "CH1-ALM-TEMP-HIGH", 3, ActivatedAt);

    private static ActorContext Operator(Guid? projectId = null) => new(
        "USR-OPERATOR-01",
        ActorKind.Human,
        new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.Viewer },
        AuthenticationStrength.SingleFactor,
        projectId ?? ProjectId,
        new HashSet<Guid> { CellId },
        "session-1");

    /// <summary>
    /// The property the whole separation rests on: acknowledgement touches the
    /// acknowledgement columns and nothing else.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0109")]
    public void Ch1ColFr0003_AcknowledgementLeavesTheCauseExactlyAsItWas()
    {
        var alarm = Raised();

        var acknowledged = alarm.Acknowledge(Operator(), "Seen.", ActivatedAt.AddMinutes(1));

        Assert.Equal(AlarmState.Acknowledged, acknowledged.State);
        Assert.Equal("USR-OPERATOR-01", acknowledged.AcknowledgedBy);
        Assert.Equal("Seen.", acknowledged.AcknowledgementComment);

        Assert.False(acknowledged.CauseClear);
        Assert.Null(acknowledged.ClearedAt);
        Assert.Equal(alarm.ActivatedAt, acknowledged.ActivatedAt);
        Assert.Equal(alarm.Priority, acknowledged.Priority);
        Assert.Equal(alarm.AlarmCode, acknowledged.AlarmCode);
        Assert.Equal(alarm.SourceId, acknowledged.SourceId);
        Assert.Equal(alarm.CellId, acknowledged.CellId);
        Assert.True(acknowledged.IsOutstanding);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0042")]
    public void Ch1AutFds0001_CauseClearBeforeAcknowledgementLatchesTheAlarm()
    {
        var returned = Raised().ObserveCauseClear(ActivatedAt.AddMinutes(2));

        Assert.Equal(AlarmState.ReturnedUnacknowledged, returned.State);
        Assert.True(returned.CauseClear);
        Assert.True(returned.IsOutstanding);
        Assert.Null(returned.AcknowledgedAt);

        var cleared = returned.Acknowledge(Operator(), "Transient.", ActivatedAt.AddMinutes(3));
        Assert.Equal(AlarmState.Cleared, cleared.State);
        Assert.False(cleared.IsOutstanding);
        // The clear time stays the moment the equipment stopped reporting the
        // condition; it is not rewritten to the acknowledgement time.
        Assert.Equal(ActivatedAt.AddMinutes(2), cleared.ClearedAt);
    }

    [Fact]
    public void Ch1AutFds0001_CauseClearAfterAcknowledgementClearsTheAlarm()
    {
        var cleared = Raised()
            .Acknowledge(Operator(), "Seen.", ActivatedAt.AddMinutes(1))
            .ObserveCauseClear(ActivatedAt.AddMinutes(2));

        Assert.Equal(AlarmState.Cleared, cleared.State);
        Assert.False(cleared.IsOutstanding);
    }

    [Fact]
    public void AcknowledgingTwiceIsRefusedRatherThanOverwritingTheFirstRecord()
    {
        var acknowledged = Raised().Acknowledge(Operator(), "Seen.", ActivatedAt.AddMinutes(1));

        var error = Assert.Throws<DomainRuleException>(() =>
            acknowledged.Acknowledge(Operator(), "Seen again.", ActivatedAt.AddMinutes(2)));

        Assert.Equal("ALARM_ALREADY_ACKNOWLEDGED", error.Code);
    }

    [Fact]
    public void AcknowledgementRequiresAComment()
    {
        var error = Assert.Throws<DomainRuleException>(() =>
            Raised().Acknowledge(Operator(), "   ", ActivatedAt.AddMinutes(1)));

        Assert.Equal("ALARM_ACKNOWLEDGEMENT_COMMENT_REQUIRED", error.Code);
    }

    [Fact]
    public void Ch1CybFr0001_AnActorFromAnotherProjectCannotAcknowledge()
    {
        var error = Assert.Throws<DomainRuleException>(() =>
            Raised().Acknowledge(Operator(Guid.NewGuid()), "Seen.", ActivatedAt.AddMinutes(1)));

        Assert.Equal("AUTH_PROJECT_SCOPE", error.Code);
    }

    [Fact]
    public void ObservingTheCauseClearTwiceKeepsTheFirstTime()
    {
        var first = Raised().ObserveCauseClear(ActivatedAt.AddMinutes(2));
        var second = first.ObserveCauseClear(ActivatedAt.AddMinutes(5));

        Assert.Equal(first.ClearedAt, second.ClearedAt);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(6)]
    public void AlarmPriorityMatchesTheSchemaConstraint(int priority)
    {
        var error = Assert.Throws<DomainRuleException>(() => Alarm.Raise(
            Guid.NewGuid(), ProjectId, CellId, "src", "CH1-ALM-TEST", priority, ActivatedAt));

        Assert.Equal("ALARM_PRIORITY_INVALID", error.Code);
    }

    [Fact]
    public void TelemetryChannelCatalogueRefusesAnUndeclaredChannel()
    {
        var error = Assert.Throws<DomainRuleException>(() => TelemetryChannelCatalogue.Require("rotor_speed"));

        Assert.Equal("TELEMETRY_CHANNEL_NOT_ALLOWED", error.Code);
        Assert.True(TelemetryChannelCatalogue.IsAllowed("temperature"));
    }

    [Fact]
    public void AlarmCursorSurvivesEncodingAndRefusesRubbish()
    {
        var cursor = new AlarmCursor(3, ActivatedAt, CellId);

        var decoded = AlarmCursor.Decode(cursor.Encode());

        Assert.Equal(cursor.Priority, decoded!.Priority);
        Assert.Equal(cursor.ActivatedAt, decoded.ActivatedAt);
        Assert.Equal(cursor.AlarmId, decoded.AlarmId);
        Assert.Null(AlarmCursor.Decode(null));
        Assert.Equal("ALARM_CURSOR_INVALID", Assert.Throws<DomainRuleException>(() => AlarmCursor.Decode("zzzz")).Code);
    }

    [Fact]
    public void Ch1SwaApi0001_TelemetryQueryClampsItsRowBoundAndRefusesTooWideAWindow()
    {
        var now = ActivatedAt;

        var clamped = TelemetryQuery.Create(ProjectId, null, null, [], null, null, 10_000, now);
        Assert.Equal(TelemetryQuery.MaximumRows, clamped.Limit);
        Assert.Equal(TelemetryQuery.DefaultWindow, clamped.To - clamped.From);

        var error = Assert.Throws<DomainRuleException>(() => TelemetryQuery.Create(
            ProjectId, null, null, [], now.AddDays(-30), now, 10, now));
        Assert.Equal("TELEMETRY_WINDOW_TOO_WIDE", error.Code);
    }
}
