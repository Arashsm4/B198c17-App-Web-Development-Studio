// Tests for the audit chain and the quality rules.

using System.Globalization;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

public sealed class AuditAndQualityTests
{
    [Fact]
    [VerificationCase("CH1-VVT-TC-0051")]
    [VerificationCase("CH1-VVT-TC-0125")]
    public void Ch1TrcFr0002_AuditChainVerifiesEveryLink()
    {
        var chain = new AuditChain();
        var projectId = Guid.NewGuid();
        var correlationId = Guid.NewGuid();
        chain.Append(new AuditInput(
            "CommandPrepared",
            "USR-ENGINEER-01",
            ActorKind.Human,
            projectId,
            "CommandTransaction",
            Guid.NewGuid().ToString(),
            correlationId,
            DateTimeOffset.Parse("2026-08-06T10:00:00Z", CultureInfo.InvariantCulture),
            "Allowed",
            "POLICY_SATISFIED",
            new { Procedure = "CH1-PROC-0001-R01" }));
        chain.Append(new AuditInput(
            "LocalCommitAccepted",
            "CH1-DEV-CELL-0001",
            ActorKind.Device,
            projectId,
            "CommandTransaction",
            Guid.NewGuid().ToString(),
            correlationId,
            DateTimeOffset.Parse("2026-08-06T10:00:02Z", CultureInfo.InvariantCulture),
            "Allowed",
            "LOCAL_COMMIT_VALID",
            new { Interlocks = "Valid" }));

        Assert.Equal(new AuditVerification(true, 2), chain.Verify());
        Assert.Equal(chain.Snapshot()[0].EventHash, chain.Snapshot()[1].PreviousHash);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0042")]
    [VerificationCase("CH1-VVT-TC-0043")]
    public void Ch1QmsFr0004_FailedMandatoryResultPlacesPartOnHold()
    {
        var part = NewPart();
        var measured = part.RecordMeasurement(
            TestRun,
            "Coating thickness",
            8.2m,
            "um",
            9.5m,
            10.5m,
            true,
            "CH1-INS-THK-0001",
            Guid.NewGuid(),
            true,
            DateTimeOffset.UtcNow);

        Assert.Equal(PartStatus.Hold, measured.Status);
        Assert.Equal(MeasurementResult.Fail, measured.Measurements[0].Result);
        Assert.Single(measured.RaiseNcr().Part.OpenNcrIds);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0045")]
    public void Ch1QmsFr0006_ExpiredCalibrationIsBlocked()
    {
        var error = Assert.Throws<DomainRuleException>(() => NewPart().RecordMeasurement(
            TestRun,
            "Width",
            8m,
            "mm",
            7.9m,
            8.1m,
            true,
            "CH1-INS-CAL-0001",
            Guid.NewGuid(),
            false,
            DateTimeOffset.UtcNow));
        Assert.Equal("INSTRUMENT_CALIBRATION_EXPIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0044")]
    public void Ch1QmsFr0005_OperatorCannotReleaseOwnPart()
    {
        var projectId = Guid.NewGuid();
        var cellId = Guid.NewGuid();
        var part = NewPart(projectId).RecordMeasurement(
            TestRun,
            "Width",
            8m,
            "mm",
            7.9m,
            8.1m,
            true,
            "CH1-INS-CAL-0001",
            Guid.NewGuid(),
            true,
            DateTimeOffset.UtcNow) with { Status = PartStatus.Accepted };
        var inspector = new ActorContext(
            part.OperatorId,
            ActorKind.Human,
            new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.Inspector },
            AuthenticationStrength.StepUpPhishingResistant,
            projectId,
            new HashSet<Guid> { cellId },
            "SESSION-02");
        var grant = RedeemedRelease(inspector);
        var error = Assert.Throws<DomainRuleException>(() => part.ReleaseBy(inspector, grant, DateTimeOffset.UtcNow));
        Assert.Equal("SEGREGATION_OF_DUTIES", error.Code);

        var independent = inspector with { ActorId = "USR-INSPECTOR-02" };
        Assert.Equal(
            PartStatus.Released,
            part.ReleaseBy(independent, RedeemedRelease(independent), DateTimeOffset.UtcNow).Status);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0043")]
    public void Ch1QmsFr0004_PassingRetestSupersedesFailedCharacteristicForRelease()
    {
        var projectId = Guid.NewGuid();
        var failed = NewPart(projectId).RecordMeasurement(
            TestRun, "Coating thickness", 8.2m, "um", 9.5m, 10.5m, true,
            "CH1-INS-THK-0001", Guid.NewGuid(), true, DateTimeOffset.UtcNow);
        var raised = failed.RaiseNcr();
        var retested = raised.Part.RecordMeasurement(
            TestRun, "Coating thickness", 10.1m, "um", 9.5m, 10.5m, true,
            "CH1-INS-THK-0001", Guid.NewGuid(), true, DateTimeOffset.UtcNow.AddMinutes(10),
            failed.Measurements[^1].MeasurementId);
        var accepted = retested.CloseNcrAfterPassingRetest(raised.NcrId);
        var inspector = new ActorContext(
            "USR-INSPECTOR-02",
            ActorKind.Human,
            new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.Inspector },
            AuthenticationStrength.StepUpPhishingResistant,
            projectId,
            new HashSet<Guid> { Guid.NewGuid() },
            "SESSION-RELEASE");

        Assert.Equal(PartStatus.Accepted, accepted.Status);
        Assert.Equal(
            PartStatus.Released,
            accepted.ReleaseBy(inspector, RedeemedRelease(inspector), DateTimeOffset.UtcNow.AddMinutes(11)).Status);
    }

    /// <summary>
    /// Each project's chain starts from its own genesis and is independent of any
    /// other project's. This mirrors the row-level security on ch1.audit_events, where
    /// a reader can only ever see its own project's rows and so could not verify a
    /// link that pointed outside them.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0051")]
    [VerificationCase("CH1-VVT-TC-0052")]
    public void Ch1TrcFr0002_EachProjectChainIsLinkedIndependently()
    {
        var chain = new AuditChain();
        var alpha = Guid.NewGuid();
        var beta = Guid.NewGuid();

        var firstAlpha = chain.Append(Input(alpha, "AlphaOne"));
        var firstBeta = chain.Append(Input(beta, "BetaOne"));
        var secondAlpha = chain.Append(Input(alpha, "AlphaTwo"));

        // Both projects begin at genesis rather than one continuing the other.
        Assert.Equal(AuditChain.GenesisHash, firstAlpha.PreviousHash);
        Assert.Equal(AuditChain.GenesisHash, firstBeta.PreviousHash);
        // Alpha's second event links to alpha's first, not to beta's interleaved one.
        Assert.Equal(firstAlpha.EventHash, secondAlpha.PreviousHash);

        // Sequence numbers stay globally monotonic, matching the identity column.
        Assert.Equal([1L, 2L, 3L], new[] { firstAlpha.Sequence, firstBeta.Sequence, secondAlpha.Sequence });
        Assert.True(chain.Verify().Valid);
    }

    private static AuditInput Input(Guid projectId, string eventType) => new(
        eventType,
        "USR-TEST",
        ActorKind.Human,
        projectId,
        "TestObject",
        Guid.NewGuid().ToString(),
        Guid.NewGuid(),
        DateTimeOffset.UtcNow,
        "Allowed",
        "TEST",
        new { });

    /// <summary>Stand-in for the controlled run every acceptance result belongs to.</summary>
    private static readonly Guid TestRun = Guid.Parse("00000000-0000-4000-8000-0000000000aa");

    private static PartRecord NewPart(Guid? projectId = null) => PartRecord.Create(
        projectId ?? Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        $"CH1-PART-{Guid.NewGuid():N}"[..20],
        "USR-OPERATOR-01");

    /// <summary>
    /// A step-up grant as it looks after <c>StepUpService.RedeemAsync</c> has consumed it:
    /// bound to this identity, to the release purpose, at phishing-resistant strength, and
    /// carrying the redemption time that proves it was spent exactly once.
    /// </summary>
    private static StepUpGrant RedeemedRelease(ActorContext inspector)
    {
        var now = DateTimeOffset.UtcNow;
        return new StepUpGrant(
            Guid.NewGuid(),
            inspector.ActorId,
            inspector.SessionId,
            inspector.ProjectId,
            StepUpPurpose.PartRelease,
            AuthenticationStrength.StepUpPhishingResistant,
            now,
            now,
            now + StepUpGrant.Lifetime,
            now);
    }


    /// <summary>
    /// The requirement CH1-VVT-TC-0051 actually states: an altered or deleted event
    /// breaks verification and is reported.
    /// </summary>
    /// <remarks>
    /// Verifying a chain that was never out of the platform's hands only shows that
    /// hashing is self-consistent. What matters is that a reader holding a record can
    /// tell it has been changed, so each case below takes a genuine chain, changes one
    /// thing a forger would want to change, and asserts the position it breaks at.
    /// </remarks>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0051")]
    public void Ch1TrcFr0002_AnAlteredOrDeletedEventBreaksVerificationAndIsReported()
    {
        var chain = new AuditChain();
        var projectId = Guid.NewGuid();
        for (var index = 0; index < 3; index++)
        {
            chain.Append(new AuditInput(
                "CommandPrepared",
                "USR-ENGINEER-01",
                ActorKind.Human,
                projectId,
                "CommandTransaction",
                Guid.NewGuid().ToString(),
                Guid.NewGuid(),
                DateTimeOffset.Parse("2026-08-06T10:00:00Z", CultureInfo.InvariantCulture).AddSeconds(index),
                "Allowed",
                "POLICY_SATISFIED",
                new { Step = index }));
        }

        var genuine = chain.Snapshot();
        Assert.Equal(new AuditVerification(true, 3), AuditChain.Verify(genuine));

        // A refusal rewritten as an approval. Everything else, including both hashes,
        // is left exactly as the platform wrote it.
        var altered = genuine.ToArray();
        altered[1] = altered[1] with { Decision = "Rejected", ReasonCode = "BACKDATED_APPROVAL" };
        var alteredResult = AuditChain.Verify(altered);
        Assert.False(alteredResult.Valid);
        Assert.Equal(altered[1].Sequence, alteredResult.FailureAt);
        Assert.Equal(1, alteredResult.Checked);

        // The event removed altogether, which is the other half of the requirement: the
        // link the next event carries no longer points at anything present.
        var deleted = new[] { genuine[0], genuine[2] };
        var deletedResult = AuditChain.Verify(deleted);
        Assert.False(deletedResult.Valid);
        Assert.Equal(genuine[2].Sequence, deletedResult.FailureAt);

        // Recomputing the altered event's own hash does not help: the next event still
        // carries the hash of what was really there.
        var resealed = genuine.ToArray();
        var target = resealed[1] with { Decision = "Rejected" };
        resealed[1] = target with
        {
            EventHash = AuditChain.ComputeEventHash(
                target.EventId, target.Sequence, target.EventType, target.ActorId, target.ActorKind,
                target.ProjectId, target.ObjectType, target.ObjectId, target.CorrelationId,
                target.OccurredAt, target.TimeQuality, target.Decision, target.ReasonCode,
                target.PayloadHash, target.PreviousHash),
        };
        var resealedResult = AuditChain.Verify(resealed);
        Assert.False(resealedResult.Valid);
        Assert.Equal(genuine[2].Sequence, resealedResult.FailureAt);
    }

}
