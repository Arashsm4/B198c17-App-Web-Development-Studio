// Tests for the project, site and cell rules.

using System.Globalization;
using Cinerion.Domain.Common;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Tests;

/// <summary>
/// Project, site and cell configuration invariants. The code-pattern and identifier
/// rules mirror the CHECK constraints in 0001_ch1_foundation.sql, so the domain and
/// the schema refuse the same values.
/// </summary>
public sealed class ConfigurationRecordsTests
{
    private static readonly DateTimeOffset Now =
        DateTimeOffset.Parse("2026-08-07T10:00:00Z", CultureInfo.InvariantCulture);

    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-000000000101");
    private static readonly Guid SiteId = Guid.Parse("00000000-0000-4000-8000-000000000102");
    private static readonly Guid CellId = Guid.Parse("00000000-0000-4000-8000-000000000103");

    private static ActorContext Manager(
        AuthenticationStrength strength = AuthenticationStrength.Mfa,
        params string[] roles) =>
        new(
            "USR-PM-01",
            ActorKind.Human,
            new HashSet<string>(roles.Length == 0 ? [CinerionRoles.ProjectManager] : roles, StringComparer.Ordinal),
            strength,
            ProjectId,
            new HashSet<Guid>(),
            "session-1",
            Now);

    /// <summary>
    /// CH1-MFG-FR-0002: every physical component receives a permanent unique identity
    /// linked to its work order and product revision. The revision is an identifier so
    /// it resolves back to the controlled revision that governed the part, and the URI
    /// is derived from the serial number so the two cannot disagree.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0031")]
    [VerificationCase("CH1-VVT-TC-0050")]
    public void Ch1MfgFr0002_APartCarriesAPermanentIdentityLinkedToItsOrderAndRevision()
    {
        var workOrder = Guid.NewGuid();
        var revision = Guid.NewGuid();

        var part = Cinerion.Domain.Quality.PartRecord.Create(
            ProjectId, Guid.NewGuid(), workOrder, revision, "CH1-PART-000017-04", "USR-OPERATOR-01");

        Assert.Equal(workOrder, part.WorkOrderId);
        Assert.Equal(revision, part.RevisionId);
        Assert.Equal("CH1-PART-000017-04", part.SerialNumber);
        Assert.Equal("urn:cinerion:ch1:part:CH1-PART-000017-04", part.PermanentIdentityUri);
        Assert.Equal(Cinerion.Domain.Quality.PartStatus.InProcess, part.Status);
    }

    [Theory]
    [InlineData("", "PART_SERIAL_REQUIRED")]
    [InlineData("   ", "PART_SERIAL_REQUIRED")]
    public void Ch1MfgFr0002_APartWithoutASerialNumberIsRejected(string serial, string expected)
    {
        var error = Assert.Throws<DomainRuleException>(() => Cinerion.Domain.Quality.PartRecord.Create(
            ProjectId, Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), serial, "USR-OPERATOR-01"));

        Assert.Equal(expected, error.Code);
    }

    [Fact]
    public void Ch1MfgFr0002_APartWithoutAWorkOrderOrRevisionIsRejected()
    {
        var noOrder = Assert.Throws<DomainRuleException>(() => Cinerion.Domain.Quality.PartRecord.Create(
            ProjectId, Guid.NewGuid(), Guid.Empty, Guid.NewGuid(), "SN-1", "USR-OPERATOR-01"));
        Assert.Equal("PART_WORK_ORDER_REQUIRED", noOrder.Code);

        var noRevision = Assert.Throws<DomainRuleException>(() => Cinerion.Domain.Quality.PartRecord.Create(
            ProjectId, Guid.NewGuid(), Guid.NewGuid(), Guid.Empty, "SN-1", "USR-OPERATOR-01"));
        Assert.Equal("PART_REVISION_REQUIRED", noRevision.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0030")]
    public void Ch1MgtFr0001_ProjectIsCreatedWithAControlledCodeAndInitialVersion()
    {
        var project = ProjectRecord.Create(ProjectId, "CH1-REFAB", "Cinerion", "P03/IFV", Now);

        Assert.Equal("CH1-REFAB", project.ProjectCode);
        Assert.Equal(1, project.Version);
        Assert.Equal(Now, project.CreatedAt);
    }

    [Theory]
    [InlineData("ch1")]
    [InlineData("CH2")]
    [InlineData("CH1-")]
    [InlineData("CH1-refab")]
    [InlineData("")]
    public void Ch1MgtFr0001_ProjectCodeOutsideTheControlledNamespaceIsRejected(string code)
    {
        var error = Assert.Throws<DomainRuleException>(
            () => ProjectRecord.Create(ProjectId, code, "Cinerion", "P03/IFV", Now));
        Assert.Equal("PROJECT_CODE_INVALID", error.Code);
    }

    [Fact]
    public void Ch1MgtFr0001_OnlyAProjectManagerMayEstablishAProject()
    {
        var engineer = Manager(AuthenticationStrength.Mfa, CinerionRoles.Engineer);

        var error = Assert.Throws<DomainRuleException>(() => ProjectRecord.AuthoriseCreation(engineer));
        Assert.Equal("AUTH_PROJECT_MANAGER_REQUIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public void Ch1MgtFr0001_EstablishingAProjectRequiresMultiFactorAuthentication()
    {
        var single = Manager(AuthenticationStrength.SingleFactor);

        var error = Assert.Throws<DomainRuleException>(() => ProjectRecord.AuthoriseCreation(single));
        Assert.Equal("AUTH_MFA_REQUIRED", error.Code);
    }

    [Fact]
    public void Ch1MgtFr0001_ServiceIdentityCannotEstablishAProject()
    {
        var service = Manager() with { Kind = ActorKind.Service };

        var error = Assert.Throws<DomainRuleException>(() => ProjectRecord.AuthoriseCreation(service));
        Assert.Equal("AUTH_HUMAN_REQUIRED", error.Code);
    }

    [Fact]
    public void Ch1MgtFr0001_SiteAndCellMustBelongToAProjectAndSite()
    {
        var site = SiteRecord.Create(SiteId, ProjectId, "ReFab MicroStation", simulated: true);
        Assert.True(site.Simulated);
        Assert.Equal(1, site.Version);

        var orphanSite = Assert.Throws<DomainRuleException>(
            () => SiteRecord.Create(SiteId, Guid.Empty, "Orphan", simulated: true));
        Assert.Equal("SITE_PROJECT_REQUIRED", orphanSite.Code);

        var cell = CellRegistration.Create(CellId, ProjectId, SiteId, "ReFab Cell 01");
        Assert.Equal("ReFab Cell 01", cell.Name);

        var orphanCell = Assert.Throws<DomainRuleException>(
            () => CellRegistration.Create(CellId, ProjectId, Guid.Empty, "Orphan"));
        Assert.Equal("CELL_SITE_REQUIRED", orphanCell.Code);
    }
}
