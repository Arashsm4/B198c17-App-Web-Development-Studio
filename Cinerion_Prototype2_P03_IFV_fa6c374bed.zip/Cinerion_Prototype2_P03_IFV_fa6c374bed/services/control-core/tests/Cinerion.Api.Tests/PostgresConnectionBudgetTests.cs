// Tests that the connection pool stays within what PostgreSQL will actually hand out.

using Cinerion.Infrastructure.Persistence;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// A connection pool entitled to ask for more than the server grants does not degrade
/// under load, it breaks.
/// <para>
/// Npgsql's pool defaults to 100 and PostgreSQL to <c>max_connections = 100</c> with
/// three held back for superusers, so an unconfigured deployment is already over by
/// three. The pool opens connections until the server refuses, and that refusal reaches
/// the caller as a failed request rather than as a wait for one of the connections it
/// could have had. It is invisible until something offers enough load to reach it: the
/// CH1-NFR-PER-0001 rig found it as <c>NpgsqlException: Failed to connect</c> mixed in
/// with genuine pool timeouts, and only after the harness was taught to print what the
/// service was throwing.
/// </para>
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set, on the same terms as the other
/// PostgreSQL tests: a skipped gate is never reported as passed.
/// </para>
/// <para>
/// These claim <b>no controlled verification case</b>, deliberately. CH1-VVT-TC-0090 is
/// the load requirement itself and it is not met; binding a defect found while
/// investigating it to the case it failed would be exactly the overstatement the
/// verification map exists to prevent.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-PER-0001, CH1-DBA-FR-0001</requirements>
public sealed class PostgresConnectionBudgetTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    private static string WithPool(int maximum) =>
        new NpgsqlConnectionStringBuilder(ConnectionString!) { MaxPoolSize = maximum }.ConnectionString;

    /// <summary>
    /// The server is asked what it grants rather than assumed, and the pool size is read
    /// from the connection string the deployment actually supplied.
    /// </summary>
    [Fact]
    public async Task Ch1NfrPer0001_TheConnectionBudgetIsReadFromBothSides()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        await using var source = new CinerionDataSource(WithPool(37), new ProjectScope());

        var budget = await source.DescribeConnectionBudgetAsync(TestContext.Current.CancellationToken);

        Assert.Equal(37, budget.PoolMaximum);
        Assert.True(
            budget.ServerGrants > 0,
            $"the server reported {budget.ServerGrants} usable connections, which cannot be right");

        // The reserved superuser slots are subtracted, so this is what an ordinary role may
        // actually obtain rather than the headline max_connections.
        await using var connection = new NpgsqlConnection(ConnectionString!);
        await connection.OpenAsync(TestContext.Current.CancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT current_setting('max_connections')::int";
        var headline = Convert.ToInt32(
            await command.ExecuteScalarAsync(TestContext.Current.CancellationToken),
            System.Globalization.CultureInfo.InvariantCulture);
        Assert.True(
            budget.ServerGrants < headline,
            $"the reserved superuser connections were not subtracted: {budget.ServerGrants} of {headline}");
    }

    /// <summary>
    /// The comparison the startup check makes, on both sides of the line.
    /// </summary>
    /// <remarks>
    /// Asserted as the inequality rather than by booting the service, because the startup
    /// path refuses on the controlled schema before it reaches this and a test that had to
    /// migrate a database first would be testing the migration.
    /// </remarks>
    [Fact]
    public async Task Ch1NfrPer0001_APoolLargerThanTheServerGrantsIsDetected()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");

        await using var modest = new CinerionDataSource(WithPool(5), new ProjectScope());
        var within = await modest.DescribeConnectionBudgetAsync(TestContext.Current.CancellationToken);
        Assert.True(
            within.PoolMaximum <= within.ServerGrants,
            $"a pool of {within.PoolMaximum} should be within the {within.ServerGrants} the server grants");

        // Deliberately absurd, so the assertion cannot pass because a particular server
        // happens to be generous.
        await using var oversized = new CinerionDataSource(WithPool(5_000), new ProjectScope());
        var over = await oversized.DescribeConnectionBudgetAsync(TestContext.Current.CancellationToken);
        Assert.True(
            over.PoolMaximum > over.ServerGrants,
            $"a pool of {over.PoolMaximum} was not detected as exceeding the {over.ServerGrants} granted");
    }

    /// <summary>
    /// Npgsql's own default is the case that matters, because it is what a deployment
    /// gets by saying nothing at all.
    /// </summary>
    [Fact]
    public void Ch1NfrPer0001_TheUnstatedPoolDefaultIsTheOneThatOvercommits()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");

        // No Maximum Pool Size in the string: whatever Npgsql defaults to is what the
        // deployment would run with, and 100 against a stock PostgreSQL is three too many.
        var stated = new NpgsqlConnectionStringBuilder(ConnectionString!);
        Assert.Equal(100, stated.MaxPoolSize);
    }
}
