// Tests that demo data fills the screens and can't do anything dangerous.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Research;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.InMemory;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// Proves the demonstration dataset actually populates what the declared screens read,
/// and that it does not populate anything it must not.
/// </summary>
/// <remarks>
/// <para>
/// An empty screen and a broken screen look identical. <see cref="PrototypeSeed"/> leaves
/// most of the 22 declared screens showing their empty state, so a reviewer opening the
/// portal has no way to tell which they are looking at. <see cref="DemonstrationSeed"/>
/// exists to remove that ambiguity — and a seed that silently stopped populating something
/// would put it straight back, which is what these assertions are for.
/// </para>
/// <para>
/// Run against the store rather than through the HTTP host, deliberately. The factory sets
/// its environment in a static constructor shared by every test in the assembly, so turning
/// demonstration data on there would leak it into every other test's assertions — an alarm
/// count that is suddenly three, a part with measurements it did not write. The dataset is
/// a property of the seed, so the seed is what is exercised.
/// </para>
/// <para>
/// The negative assertions matter more than the positive ones. A demonstration dataset is
/// the easiest place in a controlled system to accidentally manufacture evidence: a
/// telemetry reading that claims to be Live, a command that claims to have executed, a
/// credential that could authenticate. Each of those is asserted absent.
/// </para>
/// </remarks>
/// <requirements>CH1-UXD-DSG-0001, CH1-MON-FR-0003, CH1-AUT-FDS-0001, CH1-QMS-FR-0002</requirements>
public sealed class DemonstrationSeedTests
{
    private static async ValueTask<ICinerionStore> SeededAsync()
    {
        var store = new InMemoryCinerionStore();
        await PrototypeSeed.ApplyAsync(store, CancellationToken.None);
        await DemonstrationSeed.ApplyAsync(store, CancellationToken.None);
        return store;
    }

    private static Guid Project => PrototypeSeed.Ids.ProjectId;

    // -----------------------------------------------------------------------------------
    // Every screen has something behind it
    // -----------------------------------------------------------------------------------

    [Fact]
    [VerificationCase("CH1-VVT-TC-0100")]
    public async Task Live_control_room_has_alarms_in_three_distinguishable_states()
    {
        var store = await SeededAsync();

        var alarms = await store.ListAlarmsAsync(
            AlarmQuery.Create(Project, null, [], null, null, 100), CancellationToken.None);

        // Three states, not three alarms. The control room's whole subject is keeping cause,
        // acknowledgement and outstanding apart, and a dataset of three outstanding alarms
        // could not show that an acknowledgement is not a clearance.
        Assert.Contains(alarms, alarm => alarm.State == AlarmState.Active);
        Assert.Contains(alarms, alarm => alarm.State == AlarmState.Acknowledged);
        Assert.Contains(alarms, alarm => alarm.State == AlarmState.Cleared);

        var acknowledged = alarms.Single(alarm => alarm.State == AlarmState.Acknowledged);
        Assert.False(acknowledged.CauseClear);
        Assert.Null(acknowledged.ClearedAt);
        Assert.False(string.IsNullOrWhiteSpace(acknowledged.AcknowledgementComment));

        var cleared = alarms.Single(alarm => alarm.State == AlarmState.Cleared);
        Assert.True(cleared.CauseClear);
        Assert.NotNull(cleared.ClearedAt);
    }

    [Fact]
    public async Task Telemetry_covers_every_controlled_channel_with_a_shape_to_plot()
    {
        var store = await SeededAsync();

        var samples = await store.QueryTelemetryAsync(
            new TelemetryQuery(
                Project, PrototypeSeed.Ids.CellId, null, [],
                DateTimeOffset.UtcNow.AddHours(-6), DateTimeOffset.UtcNow.AddMinutes(5), 1000),
            CancellationToken.None);

        // All four channels CH1-SYS-ICD-0001 defines, and no fifth: the catalogue is the
        // catalogue, and a demonstration dataset is exactly where an invented channel would
        // slip in unnoticed.
        var channels = samples.Select(sample => sample.ChannelId).Distinct().Order().ToArray();
        Assert.Equal(
            ["CH1-IO-AI-0001", "CH1-IO-AI-0002", "CH1-IO-AI-0003", "CH1-IO-AI-0004"],
            channels);

        // A trend needs more than a point. Anything less and the screen renders a dot.
        foreach (var channel in channels)
        {
            Assert.True(
                samples.Count(sample => sample.ChannelId == channel) >= 20,
                $"{channel} carries too few samples to show a trend");
        }

        // One reading outside its limit, so the limit rendering has a subject. The portal
        // render gate refuses a telemetry capture with nothing outside its limits.
        Assert.Contains(samples, sample => sample.ChannelId == "CH1-IO-AI-0001" && sample.Value > 40);
    }

    [Fact]
    public async Task Part_history_carries_a_failure_a_rework_and_a_passing_retest()
    {
        var store = await SeededAsync();

        var part = await store.FindPartAsync(PrototypeSeed.Ids.PartId, CancellationToken.None);
        Assert.NotNull(part);

        // CH1-QMS-FR-0004 requires the superseded failing measurement to stay readable, and
        // the portal render gate refuses a history that drops it. A dataset containing only
        // passing results could not exercise either.
        var failed = Assert.Single(part.Measurements, m => m.Result == MeasurementResult.Fail);
        var retest = Assert.Single(part.Measurements, m => m.SupersedesMeasurementId is not null);

        Assert.Equal(failed.MeasurementId, retest.SupersedesMeasurementId);
        Assert.Equal(MeasurementResult.Pass, retest.Result);
        Assert.Equal(failed.Characteristic, retest.Characteristic);

        // Every result names the calibration certificate that makes it admissible.
        // CH1-QMS-FR-0002: a measurement with no calibration context is not evidence.
        Assert.All(part.Measurements, m =>
        {
            Assert.Equal(PrototypeSeed.Ids.CalibrationRecordId, m.CalibrationRecordId);
            Assert.True(m.CalibrationValid);
            Assert.False(string.IsNullOrWhiteSpace(m.SourceDeviceId));
        });
    }

    [Fact]
    public async Task Nonconformity_board_has_one_open_and_one_dispositioned()
    {
        var store = await SeededAsync();

        var open = await store.FindNcrAsync(DemonstrationSeed.NcrOpenId, CancellationToken.None);
        var closed = await store.FindNcrAsync(DemonstrationSeed.NcrClosedId, CancellationToken.None);

        Assert.NotNull(open);
        Assert.NotNull(closed);
        Assert.Equal(NcrStatus.Open, open.Status);
        Assert.Null(open.Disposition);

        // A closed nonconformity carries its whole disposition: who decided, when, why, and
        // the measurement that closed it. Without those the workflow screen renders a status
        // and nothing a reviewer could act on.
        Assert.Equal(NcrStatus.Closed, closed.Status);
        Assert.Equal(NcrDispositionKind.Rework, closed.Disposition);
        Assert.False(string.IsNullOrWhiteSpace(closed.DispositionBy));
        Assert.False(string.IsNullOrWhiteSpace(closed.DispositionJustification));
        Assert.NotNull(closed.DispositionAt);
        Assert.Equal(DemonstrationSeed.MeasurementRetestId, closed.ClosedByMeasurementId);
    }

    [Fact]
    public async Task Collaboration_has_a_thread_a_message_and_a_receipt()
    {
        var store = await SeededAsync();

        var thread = await store.FindContextThreadAsync(DemonstrationSeed.ThreadId, CancellationToken.None);
        Assert.NotNull(thread);

        var acknowledgements = await store.ListMessageAcknowledgementsAsync(
            Project, [DemonstrationSeed.MessageId], CancellationToken.None);
        var acknowledgement = Assert.Single(acknowledgements);

        // The load-bearing field. CH1-COL-FR-0003: reading a message is not acknowledging an
        // alarm, clearing a fault, satisfying an interlock or confirming a physical action.
        Assert.False(acknowledgement.ControlAuthority);
    }

    [Fact]
    public async Task Capacity_board_has_a_live_reservation()
    {
        var store = await SeededAsync();

        var allocations = await store.ListAllocationsAsync(
            Project, [PrototypeSeed.Ids.CoatingStationResourceId],
            DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(1),
            CancellationToken.None);

        var allocation = Assert.Single(allocations);
        Assert.Equal(AllocationStatus.Reserved, allocation.Status);
        Assert.True(allocation.EndsAt > allocation.StartsAt);
        Assert.Equal(PrototypeSeed.Ids.WorkOrderId, allocation.WorkOrderId);
    }

    [Fact]
    public async Task Research_workbench_has_an_experiment_a_run_and_a_promotion_request()
    {
        var store = await SeededAsync();

        var experiment = await store.FindExperimentAsync(DemonstrationSeed.ExperimentId, CancellationToken.None);
        Assert.NotNull(experiment);

        var revisions = await store.ListExperimentRevisionsAsync(
            Project, DemonstrationSeed.ExperimentId, CancellationToken.None);
        var revision = Assert.Single(revisions);

        // R&D isolation, asserted on both records rather than on one. CH1-RND-FR-0001 keeps
        // experiments away from production authority, and migration 0006 holds it with CHECK
        // constraints on each table — so a dataset that set it on either would be refused by
        // PostgreSQL and should be refused here too.
        Assert.False(experiment.ProductionAuthority);
        Assert.False(revision.ProductionAuthority);
        Assert.Equal(ExperimentEnvironment.Simulator, experiment.Environment);
        Assert.Equal(ExperimentEnvironment.Simulator, revision.Environment);

        // A promotion REQUEST carrying what CH1-RND-FR-0003 requires. Nothing approves it:
        // approval lives in configuration control, which is a separate system.
        Assert.False(string.IsNullOrWhiteSpace(experiment.PromotionChangeRecord));
        Assert.False(string.IsNullOrWhiteSpace(experiment.PromotionImpactAnalysis));
        Assert.False(string.IsNullOrWhiteSpace(experiment.PromotionVerification));
    }

    [Fact]
    public async Task Evidence_screens_have_a_report_and_a_resolved_scan()
    {
        var store = await SeededAsync();

        var scans = await store.ListScanEventsAsync(Project, 50, CancellationToken.None);
        var scan = Assert.Single(scans);
        Assert.Equal(ScanResolution.Resolved, scan.Resolution);
        Assert.Equal(PrototypeSeed.Ids.PartId, scan.PartId);

        var report = await store.FindReportByDeterminismKeyAsync(
            Project, DeterminismKey(), CancellationToken.None);
        Assert.NotNull(report);
        Assert.False(string.IsNullOrWhiteSpace(report.ContentSha256));
        Assert.False(string.IsNullOrWhiteSpace(report.DocumentNumber));
    }

    [Fact]
    public async Task Security_administration_has_a_credential_and_a_role_history()
    {
        var store = await SeededAsync();

        var credentials = await store.ListCredentialsAsync(Project, "ch1-portal-demo", CancellationToken.None);
        var credential = Assert.Single(credentials);
        Assert.Equal(CredentialStatus.Active, credential.Status);

        var assignments = await store.ListRoleAssignmentsAsync(
            Project, "ch1-portal-demo", 50, CancellationToken.None);
        var assignment = Assert.Single(assignments);

        // Before and after in full, not a delta. A history of deltas cannot answer "what did
        // this person hold on that date" without replaying every row and trusting none is
        // missing.
        Assert.NotEmpty(assignment.CurrentRoles);
        Assert.NotEmpty(assignment.GrantedRoles);
        Assert.Equal(assignment.AssignedAt.AddYears(7), assignment.RetainUntil);
    }

    [Fact]
    public async Task Publication_package_carries_two_reviewers_in_two_capacities()
    {
        var store = await SeededAsync();

        var package = await store.FindPublicationPackageAsync(
            DemonstrationSeed.PackageId, CancellationToken.None);
        Assert.NotNull(package);

        var approvals = await store.ListPublicationApprovalsAsync(
            Project, DemonstrationSeed.PackageId, CancellationToken.None);

        Assert.Equal(2, approvals.Count);
        Assert.Equal(2, approvals.Select(a => a.Capacity).Distinct().Count());
        Assert.Equal(2, approvals.Select(a => a.ReviewedBy).Distinct().Count());

        // Neither reviewer is the author. The two-person property does not rest on the role
        // mapping conflict 23 records, and a dataset where the author approved their own
        // package would make that untestable.
        Assert.DoesNotContain(approvals, a => a.ReviewedBy == package.CreatedBy);
    }

    // -----------------------------------------------------------------------------------
    // What the dataset must NOT contain
    // -----------------------------------------------------------------------------------

    [Fact]
    [VerificationCase("CH1-VVT-TC-0014")]
    public async Task No_seeded_telemetry_claims_to_be_live()
    {
        var store = await SeededAsync();

        var samples = await store.QueryTelemetryAsync(
            new TelemetryQuery(
                Project, PrototypeSeed.Ids.CellId, null, [],
                DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddMinutes(5), 1000),
            CancellationToken.None);

        Assert.NotEmpty(samples);

        // CH1-MON-FR-0003 requires live, stale, disconnected, simulated, maintenance and
        // unknown to stay distinguishable. A seeded reading is a measurement of nothing, and
        // the one thing it must never do is claim otherwise — the gateway's own contract puts
        // it plainly: Control Core never states Live for a reading a simulator produced.
        Assert.All(samples, sample => Assert.Equal(Freshness.Simulated, sample.Freshness));
    }

    [Fact]
    public async Task No_seeded_command_has_executed_or_committed()
    {
        var store = await SeededAsync();

        // The dataset writes no command at all, and that is the point rather than an
        // omission: a seeded execution would be this service claiming a physical act that
        // never happened. CH1-AUT-FDS-0001 puts physical execution behind a credential proof
        // and a button edge observed at the cell, and AGENTS.md forbids the portal ever
        // claiming one. Asserted by looking, not by trusting the seed's comments.
        var command = await store.FindCommandAsync(DemonstrationSeed.AlarmOutstandingId, CancellationToken.None);
        Assert.Null(command);

        var cell = await store.FindCellAsync(PrototypeSeed.Ids.CellId, CancellationToken.None);
        Assert.NotNull(cell);
        Assert.NotEqual(CellOperatingState.Executing, cell.Snapshot.OperatingState);
    }

    [Fact]
    public async Task No_seeded_credential_carries_secret_material()
    {
        var store = await SeededAsync();

        var credentials = await store.ListCredentialsAsync(Project, "ch1-portal-demo", CancellationToken.None);
        var credential = Assert.Single(credentials);

        // A public key and a label. Nothing that could authenticate anybody, and nothing
        // that would be a committed secret if this file were published.
        Assert.Null(credential.SealedSecret);
        Assert.Null(credential.SealedSecretNonce);
        Assert.Null(credential.TotpAlgorithm);
        Assert.NotNull(credential.PublicKeySpki);
    }

    [Fact]
    public async Task Applying_the_dataset_twice_changes_nothing()
    {
        var store = await SeededAsync();

        var before = await store.FindAlarmAsync(DemonstrationSeed.AlarmAcknowledgedId, CancellationToken.None);
        Assert.NotNull(before);

        // Idempotent for the same reason PrototypeSeed is: re-running would overwrite
        // operational state that has moved on. An acknowledged alarm reset to outstanding
        // discards somebody's decision, which is defect 16's exact shape.
        await DemonstrationSeed.ApplyAsync(store, CancellationToken.None);

        var after = await store.FindAlarmAsync(DemonstrationSeed.AlarmAcknowledgedId, CancellationToken.None);
        Assert.NotNull(after);
        Assert.Equal(before.State, after.State);
        Assert.Equal(before.AcknowledgedBy, after.AcknowledgedBy);
        Assert.Equal(before.AcknowledgementComment, after.AcknowledgementComment);
    }

    private static string DeterminismKey() =>
        Convert.ToHexStringLower(
            System.Security.Cryptography.SHA256.HashData(
                System.Text.Encoding.UTF8.GetBytes(
                    $"{PrototypeSeed.Ids.PartId}|CH1-RPT-TPL-0002|R03")));
}
