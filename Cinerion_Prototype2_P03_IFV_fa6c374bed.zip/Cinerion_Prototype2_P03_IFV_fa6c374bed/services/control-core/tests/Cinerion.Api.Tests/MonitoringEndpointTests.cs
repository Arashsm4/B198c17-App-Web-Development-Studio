// Tests for telemetry and alarms over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Application.Monitoring;
using Cinerion.Domain.Monitoring;
using Cinerion.Infrastructure.Seed;
using Microsoft.Extensions.DependencyInjection;

namespace Cinerion.Api.Tests;

/// <summary>
/// Telemetry query, alarm list and alarm acknowledgement over HTTP.
/// <para>
/// The tests state their own readings through <see cref="MonitoringService.IngestAsync"/>,
/// which is the same path a gateway uses. Nothing here writes an alarm directly: an
/// alarm exists only because a reading breached a limit, so the raise, latch,
/// acknowledge and clear behaviour is exercised rather than assumed.
/// </para>
/// </summary>
/// <requirements>CH1-MON-FR-0001, CH1-MON-FR-0003, CH1-COL-FR-0003, CH1-AUT-FDS-0001</requirements>
public sealed class MonitoringEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid CellId = PrototypeSeed.Ids.CellId;
    private const string DeviceId = "CH1-DEV-CELL-0001";

    private HttpClient Operator()
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OPERATOR-01");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Viewer");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", CellId.ToString());
        return client;
    }

    private HttpClient Engineer()
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-ENGINEER-01");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");
        return client;
    }

    private async Task<TelemetryIngestionResult> IngestAsync(
        double temperature,
        DateTimeOffset sampledAt,
        CancellationToken cancellationToken)
    {
        await using var scope = factory.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();
        return await monitoring.IngestAsync(
            ProjectId,
            [
                new TelemetryReading(
                    CellId, DeviceId, "temperature", temperature, "degC",
                    DataQuality.Good, Freshness.Simulated, sampledAt),
            ],
            cancellationToken);
    }

    /// <summary>
    /// Brings the shared seeded cell back to no outstanding alarm, using only the
    /// ordinary paths: a reading inside the limits to clear the cause, then a real
    /// acknowledgement for anything still latched. Every test in this class starts from
    /// that state, so none of them depends on the order they run in.
    /// </summary>
    private async Task ResetAlarmsAsync(CancellationToken cancellationToken)
    {
        await IngestAsync(22.0, DateTimeOffset.UtcNow, cancellationToken);

        using var engineer = Engineer();
        using var list = await engineer.GetAsync(
            "/api/v1/alarms?state=Active&state=Acknowledged&state=ReturnedUnacknowledged",
            cancellationToken);
        var body = await list.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        foreach (var alarm in body.GetProperty("items").EnumerateArray())
        {
            if (alarm.GetProperty("acknowledgedAt").ValueKind == JsonValueKind.Null)
            {
                using var acknowledge = await engineer.PostAsJsonAsync(
                    $"/api/v1/alarms/{alarm.GetProperty("alarmId").GetGuid()}/acknowledgements",
                    new { comment = "Test fixture reset." },
                    cancellationToken);
                acknowledge.EnsureSuccessStatusCode();
            }
        }
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0100")]
    [VerificationCase("CH1-VVT-TC-0102")]
    public async Task Ch1MonFr0001_TelemetryQueryReturnsStoredSamplesWithQualityAndFreshness()
    {
        var sampledAt = DateTimeOffset.UtcNow;
        await IngestAsync(21.5, sampledAt, TestContext.Current.CancellationToken);

        using var client = Operator();
        using var response = await client.GetAsync(
            "/api/v1/telemetry?channel=temperature&limit=5",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var items = body.GetProperty("items").EnumerateArray().ToArray();
        Assert.NotEmpty(items);
        var sample = items[0];
        Assert.Equal("degC", sample.GetProperty("unit").GetString());
        Assert.Equal("Good", sample.GetProperty("quality").GetString());
        Assert.Equal("Simulated", sample.GetProperty("freshness").GetString());
        // Both times travel with the sample: store-and-forward means they differ, and a
        // reader that saw only one could not tell a delayed sample from a current one.
        Assert.True(sample.TryGetProperty("sampledAt", out _));
        Assert.True(sample.TryGetProperty("receivedAt", out _));
        Assert.False(string.IsNullOrWhiteSpace(sample.GetProperty("timeQuality").GetString()));
    }

    /// <summary>
    /// CH1-SWA-API-0001 makes the channel allowlist the control on this operation. It
    /// has to refuse, not return nothing: an empty page would be indistinguishable from
    /// an allowed channel that happens to have no data.
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_ChannelOutsideTheAllowlistIsRefusedRatherThanEmpty()
    {
        using var client = Operator();
        using var response = await client.GetAsync(
            "/api/v1/telemetry?channel=rotor_speed",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("TELEMETRY_CHANNEL_NOT_ALLOWED", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1SwaApi0001_TelemetryWindowIsBoundedAndTheBoundsAreStated()
    {
        using var client = Operator();
        var from = DateTimeOffset.UtcNow.AddDays(-30).ToString("O", CultureInfo.InvariantCulture);
        using var refused = await client.GetAsync(
            $"/api/v1/telemetry?from={Uri.EscapeDataString(from)}",
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, refused.StatusCode);
        var error = await refused.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("TELEMETRY_WINDOW_TOO_WIDE", error.GetProperty("code").GetString());

        using var accepted = await client.GetAsync("/api/v1/telemetry", TestContext.Current.CancellationToken);
        var body = await accepted.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var bounds = body.GetProperty("bounds");
        Assert.Equal(TelemetryQuery.MaximumRows, bounds.GetProperty("maximumRows").GetInt32());
        Assert.Equal(TelemetryQuery.MaximumWindow.TotalDays, bounds.GetProperty("maximumWindowDays").GetDouble());
        Assert.Equal(
            TelemetryChannelCatalogue.Version,
            body.GetProperty("channelAllowlist").GetProperty("version").GetString());
    }

    /// <summary>
    /// The single most important property in this subsystem. CH1-COL-FR-0003 and
    /// CH1-AUT-FDS-0001 both require that acknowledging changes nothing about the
    /// condition that raised the alarm.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0109")]
    public async Task Ch1ColFr0003_AcknowledgingAnAlarmDoesNotClearItsCause()
    {
        await ResetAlarmsAsync(TestContext.Current.CancellationToken);
        var raised = await IngestAsync(96.0, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);
        var alarm = Assert.Single(raised.Raised);
        Assert.Equal(AlarmState.Active, alarm.State);
        Assert.False(alarm.CauseClear);

        using var client = Operator();
        using var response = await client.PostAsJsonAsync(
            $"/api/v1/alarms/{alarm.AlarmId}/acknowledgements",
            new { comment = "Seen; investigating enclosure ventilation." },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        // Acknowledged, and the cause is untouched.
        Assert.Equal("Acknowledged", body.GetProperty("state").GetString());
        Assert.Equal("USR-OPERATOR-01", body.GetProperty("acknowledgedBy").GetString());
        Assert.False(body.GetProperty("causeClear").GetBoolean());
        Assert.Equal(JsonValueKind.Null, body.GetProperty("clearedAt").ValueKind);
        Assert.Equal(
            "Seen; investigating enclosure ventilation.",
            body.GetProperty("acknowledgementComment").GetString());

        // And the alarm is still outstanding in the list, not filed away as resolved.
        using var list = await client.GetAsync(
            "/api/v1/alarms?state=Acknowledged",
            TestContext.Current.CancellationToken);
        var alarms = await list.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var listed = alarms.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("alarmId").GetGuid() == alarm.AlarmId);
        Assert.True(listed.GetProperty("outstanding").GetBoolean());
        Assert.False(listed.GetProperty("causeClear").GetBoolean());
    }

    /// <summary>
    /// The latching policy: a cause that goes away before anyone acknowledges leaves
    /// the alarm on the list, so a transient fault cannot disappear unseen.
    /// </summary>
    [Fact]
    public async Task Ch1AutFds0001_AlarmLatchesUntilAcknowledgedAfterItsCauseHasGone()
    {
        await ResetAlarmsAsync(TestContext.Current.CancellationToken);
        var raised = await IngestAsync(97.0, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);
        var alarm = Assert.Single(raised.Raised);

        var settled = await IngestAsync(
            22.0, DateTimeOffset.UtcNow.AddSeconds(1), TestContext.Current.CancellationToken);
        var returned = Assert.Single(settled.Cleared);
        Assert.Equal(alarm.AlarmId, returned.AlarmId);
        Assert.True(returned.CauseClear);
        Assert.Equal(AlarmState.ReturnedUnacknowledged, returned.State);
        Assert.True(returned.IsOutstanding);

        using var client = Operator();
        using var response = await client.PostAsJsonAsync(
            $"/api/v1/alarms/{alarm.AlarmId}/acknowledgements",
            new { comment = "Transient over-temperature; cause already returned to normal." },
            TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        Assert.Equal("Cleared", body.GetProperty("state").GetString());
        // The clear time is when the equipment stopped reporting the condition, not
        // when the operator pressed acknowledge.
        Assert.NotEqual(
            body.GetProperty("acknowledgedAt").GetDateTimeOffset(),
            body.GetProperty("clearedAt").GetDateTimeOffset());
    }

    [Fact]
    public async Task Ch1AutFds0001_APersistingConditionKeepsOneAlarmRatherThanRaisingMore()
    {
        await ResetAlarmsAsync(TestContext.Current.CancellationToken);
        var first = await IngestAsync(98.0, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);
        Assert.Single(first.Raised);

        var second = await IngestAsync(
            99.0, DateTimeOffset.UtcNow.AddSeconds(1), TestContext.Current.CancellationToken);

        Assert.Empty(second.Raised);
        Assert.Empty(second.Cleared);
    }

    /// <summary>
    /// A reading the source itself does not vouch for is not evidence that a condition
    /// has gone. Treating a bad sample as a clear would silently remove an alarm on the
    /// strength of a value nobody trusts.
    /// </summary>
    [Fact]
    public async Task Ch1AutFds0001_ASampleOfUncertainQualityNeitherRaisesNorClears()
    {
        await ResetAlarmsAsync(TestContext.Current.CancellationToken);
        var raised = await IngestAsync(93.0, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);
        Assert.Single(raised.Raised);

        await using var scope = factory.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();
        var uncertain = await monitoring.IngestAsync(
            ProjectId,
            [
                new TelemetryReading(
                    CellId, DeviceId, "temperature", 22.0, "degC",
                    DataQuality.Uncertain, Freshness.Simulated, DateTimeOffset.UtcNow.AddSeconds(1)),
            ],
            TestContext.Current.CancellationToken);

        Assert.Equal(1, uncertain.Accepted);
        Assert.Empty(uncertain.Cleared);
        Assert.Empty(uncertain.Raised);
    }

    /// <summary>
    /// api_endpoints.json gives this operation to the assigned operator or an Engineer.
    /// An authenticated identity that is neither must be refused.
    /// </summary>
    [Fact]
    public async Task Ch1CybAcp0001_AcknowledgementRequiresTheAssignedOperatorOrAnEngineer()
    {
        await ResetAlarmsAsync(TestContext.Current.CancellationToken);
        var raised = await IngestAsync(95.5, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);
        var alarm = Assert.Single(raised.Raised);

        using var bystander = factory.CreateClient();
        bystander.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-AUDITOR-01");
        bystander.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        bystander.DefaultRequestHeaders.Add("X-CH1-Roles", "Auditor");

        using var refused = await bystander.PostAsJsonAsync(
            $"/api/v1/alarms/{alarm.AlarmId}/acknowledgements",
            new { comment = "Noted." },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, refused.StatusCode);

        using var engineer = Engineer();
        using var allowed = await engineer.PostAsJsonAsync(
            $"/api/v1/alarms/{alarm.AlarmId}/acknowledgements",
            new { comment = "Engineer acknowledging without a cell assignment." },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, allowed.StatusCode);
    }

    /// <summary>
    /// An alarm in another project must read exactly as one that does not exist, so a
    /// caller cannot probe for the existence of records outside their scope.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0124")]
    public async Task Ch1CybFr0001_AlarmOutsideTheCallerProjectIsIndistinguishableFromAbsent()
    {
        await ResetAlarmsAsync(TestContext.Current.CancellationToken);
        var raised = await IngestAsync(94.0, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);
        var alarm = Assert.Single(raised.Raised);

        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OTHER-PROJECT");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");

        using var existing = await outsider.PostAsJsonAsync(
            $"/api/v1/alarms/{alarm.AlarmId}/acknowledgements",
            new { comment = "Probe." },
            TestContext.Current.CancellationToken);
        using var absent = await outsider.PostAsJsonAsync(
            $"/api/v1/alarms/{Guid.NewGuid()}/acknowledgements",
            new { comment = "Probe." },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, existing.StatusCode);
        Assert.Equal(absent.StatusCode, existing.StatusCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0101")]
    [VerificationCase("CH1-VVT-TC-0102")]
    public async Task Ch1MonFr0003_AlarmListStatesItsOwnFreshness()
    {
        await IngestAsync(23.0, DateTimeOffset.UtcNow, TestContext.Current.CancellationToken);

        using var client = Operator();
        using var response = await client.GetAsync("/api/v1/alarms", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        // Simulated, because that is what the reading declared, and never silently
        // upgraded to Live.
        Assert.Equal("Simulated", body.GetProperty("freshness").GetString());
        Assert.NotEqual(JsonValueKind.Null, body.GetProperty("newestSampleAt").ValueKind);
    }

    [Fact]
    public async Task Ch1SwaApi0001_MalformedAlarmCursorIsRejectedRatherThanSilentlyIgnored()
    {
        using var client = Operator();
        using var response = await client.GetAsync(
            "/api/v1/alarms?cursor=not-a-cursor",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("ALARM_CURSOR_INVALID", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// An identity holding none of the roles access.json grants the dashboard view reads
    /// nothing, and is told the same thing as a caller asking for an absent resource.
    /// </summary>
    [Fact]
    public async Task Ch1CybAcp0001_AnIdentityWithoutADashboardRoleReadsNothing()
    {
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "SVC-NO-ROLE");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());

        using var telemetry = await client.GetAsync("/api/v1/telemetry", TestContext.Current.CancellationToken);
        using var alarms = await client.GetAsync("/api/v1/alarms", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, telemetry.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, alarms.StatusCode);
    }
}
