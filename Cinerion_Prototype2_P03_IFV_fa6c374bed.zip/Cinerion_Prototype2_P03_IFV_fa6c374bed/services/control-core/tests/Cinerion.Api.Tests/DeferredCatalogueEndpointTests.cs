// Tests that deferred operations stay deferred and say so.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// The two controlled operations the baseline itself defers: the secure document vault.
/// </summary>
/// <remarks>
/// <para>
/// AGENTS.md requires an unimplemented capability to remain explicitly unavailable, and
/// CH1-DOC-FR-0002 places these in a later controlled phase - a unique data-encryption key
/// per controlled document behind a separate key-encryption boundary, with CH1-DOC-FR-0003
/// requiring a hardware-backed credential and user verification to decrypt. A vault without
/// those is not a vault. Nothing had ever executed them, so the one thing that must stay
/// true of them - that they say so rather than appearing to work - was unverified. A stub
/// that quietly started answering 200 with an empty body would have passed every other gate
/// in the repository.
/// </para>
/// <para>
/// <b>There were four, and two of them should not have been here.</b> The publication
/// package operations were grouped with the vault, and CH1-DOC-FR-0004 is "Baseline P03"
/// rather than a design target: it asks for a review pipeline - approved redaction profile,
/// content diff, metadata scrub, secret scan, owner approval, checksum - and needs no key
/// boundary at all. They are implemented, and the test below asserts that they have
/// genuinely stopped being gated, because a list that quietly kept refusing something the
/// platform can do is the mirror image of one that stops refusing something it cannot.
/// </para>
/// </remarks>
/// <remarks>
/// These tests deliberately carry no <c>[VerificationCase]</c>. CH1-VVT-TC-0128, 0129
/// and 0130 are about envelope encryption, physical vault access and clean-room
/// redaction; evidence that the operations are gated is not evidence about any of those,
/// and claiming it would be exactly the overstatement the verification map exists to
/// prevent. All three stay recorded as future_controlled_phase with no binding.
/// </remarks>
/// <requirements>CH1-DOC-FR-0002, CH1-DOC-FR-0004, CH1-SWA-API-0001</requirements>
public sealed class DeferredCatalogueEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;

    public static TheoryData<string, string> DeferredOperations() => new()
    {
        { "GET", $"/api/v1/documents/{Guid.Empty}" },
        { "POST", $"/api/v1/documents/{Guid.Empty}/export-requests" },
    };

    /// <summary>
    /// The operations that left this list. Asserted here rather than only where they are
    /// implemented, so that re-adding one to the gated list fails in the place that would
    /// have made it invisible.
    /// </summary>
    public static TheoryData<string, string> NoLongerDeferred() => new()
    {
        { "POST", "/api/v1/publication-packages" },
        { "POST", $"/api/v1/publication-packages/{Guid.Empty}/approvals" },
    };

    [Theory]
    [MemberData(nameof(DeferredOperations))]
    public async Task Ch1DocFr0002_ADeferredCapabilitySaysSoRatherThanAppearingToWork(string method, string path)
    {
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-DOC-READER-01");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");

        using var request = new HttpRequestMessage(new HttpMethod(method), path);
        if (method != "GET")
        {
            request.Content = JsonContent.Create(new { });
        }

        using var response = await client.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotImplemented, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        // A stable code, so a client can distinguish "not built yet" from "you may not"
        // and from "it broke".
        Assert.Equal("CH1_CAPABILITY_NOT_ENABLED", body.GetProperty("code").GetString());
        Assert.Contains("gated", body.GetProperty("detail").GetString(), StringComparison.Ordinal);
        Assert.Equal(
            "Simulation and controlled extra-low-voltage Prototype 1 only",
            body.GetProperty("runtimeAuthority").GetString());
        Assert.NotEqual(Guid.Empty, body.GetProperty("correlationId").GetGuid());
    }

    /// <summary>
    /// CH1-DOC-FR-0004's operations must NOT answer the gated 501 any more. What they
    /// answer instead depends on the request - an authority refusal, a validation refusal,
    /// a created package - and any of those is a platform doing the work. 501 is the one
    /// answer that would mean the implementation is unreachable.
    /// </summary>
    [Theory]
    [MemberData(nameof(NoLongerDeferred))]
    public async Task Ch1DocFr0004_AnImplementedOperationNoLongerAnswersTheGatedRefusal(
        string method,
        string path)
    {
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-DOC-READER-02");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");

        using var request = new HttpRequestMessage(new HttpMethod(method), path);
        request.Content = JsonContent.Create(new { });

        using var response = await client.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.NotEqual(HttpStatusCode.NotImplemented, response.StatusCode);
    }

    /// <summary>
    /// A gated capability is still behind authentication. Answering 501 to an anonymous
    /// caller would disclose the shape of the controlled catalogue to anyone.
    /// </summary>
    [Fact]
    public async Task Ch1CybFr0001_ADeferredCapabilityIsStillBehindAuthentication()
    {
        using var client = factory.CreateClient();

        using var response = await client.GetAsync(
            $"/api/v1/documents/{Guid.Empty}", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
