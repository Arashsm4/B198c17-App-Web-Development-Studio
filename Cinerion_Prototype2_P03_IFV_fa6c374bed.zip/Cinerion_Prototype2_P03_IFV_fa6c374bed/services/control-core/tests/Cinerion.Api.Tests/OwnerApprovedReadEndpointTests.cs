// Tests for the owner-approved extra reads.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// The five reads this deployment serves beyond the P03 catalogue, over HTTP.
/// </summary>
/// <remarks>
/// <para>
/// They exist because <c>screens.json</c> declares operator screens whose subjects the
/// catalogue can write and cannot read back. Each is recorded in
/// <c>traceability/owner-approved-operations.json</c> with the screen it serves, and
/// <c>npm run policy</c> refuses a served route missing from that register and a register
/// entry nothing serves.
/// </para>
/// <para>
/// What these tests are mostly for is the part that is easy to get wrong when a register
/// like that exists: an extension must carry the SAME authority checks and the SAME project
/// scope as a controlled read, and must disclose nothing a controlled read would not. A
/// read added outside the catalogue that quietly answered everyone would be the hole the
/// catalogue was keeping shut.
/// </para>
/// </remarks>
/// <requirements>CH1-QMS-FR-0005, CH1-MFG-FR-0001, CH1-MFG-FR-0002, CH1-RND-FR-0001, CH1-CYB-FR-0001</requirements>
public sealed class OwnerApprovedReadEndpointTests(CinerionApiFactory factory)
    : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;

    private HttpClient Client(string actorId, string roles)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", PrototypeSeed.Ids.CellId.ToString());
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private static async Task<JsonElement> BodyAsync(
        HttpResponseMessage response,
        CancellationToken cancellationToken) =>
        await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);

    /// <summary>
    /// Every one of the five answers an identity that holds the role, and refuses one that
    /// does not. Table-driven so a read added later without an authority check fails here
    /// rather than in front of somebody.
    /// </summary>
    public static TheoryData<string, string, string> ReadsAndTheirRoles() => new()
    {
        { "/api/v1/calibrations", "Inspector", "Viewer" },
        { "/api/v1/parts/scan-events", "Inspector", "Viewer" },
        { "/api/v1/work-orders", "ProjectManager", "Viewer" },
        { "/api/v1/experiments", "RDEngineer", "Viewer" },
    };

    [Theory]
    [MemberData(nameof(ReadsAndTheirRoles))]
    public async Task Ch1CybFr0001_EachApprovedReadAnswersItsRoleAndRefusesAnother(
        string path,
        string permitted,
        string refused)
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        using var allowed = Client("USR-APPROVED-YES", permitted);
        using var granted = await allowed.GetAsync(path, cancellationToken);
        Assert.Equal(HttpStatusCode.OK, granted.StatusCode);

        using var denied = Client("USR-APPROVED-NO", refused);
        using var withheld = await denied.GetAsync(path, cancellationToken);
        Assert.NotEqual(HttpStatusCode.OK, withheld.StatusCode);
    }

    /// <summary>
    /// An anonymous caller learns nothing, including whether the route exists.
    /// </summary>
    [Theory]
    [InlineData("/api/v1/calibrations")]
    [InlineData("/api/v1/parts/scan-events")]
    [InlineData("/api/v1/work-orders")]
    [InlineData("/api/v1/experiments")]
    public async Task Ch1CybFr0001_AnApprovedReadIsStillBehindAuthentication(string path)
    {
        using var anonymous = factory.CreateClient();
        using var response = await anonymous.GetAsync(path, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    /// <summary>
    /// The calibration register answers the question the screen is for: is this certificate
    /// still valid, decided here rather than by whichever screen did the subtraction.
    /// </summary>
    [Fact]
    public async Task Ch1QmsFr0005_TheCalibrationRegisterStatesValidityRatherThanLeavingItToBeComputed()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var inspector = Client("USR-CAL-READER", "Inspector");

        using var response = await inspector.GetAsync("/api/v1/calibrations", cancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await BodyAsync(response, cancellationToken);

        var entry = body.GetProperty("items").EnumerateArray().First();
        Assert.False(string.IsNullOrWhiteSpace(entry.GetProperty("instrumentId").GetString()));
        Assert.False(string.IsNullOrWhiteSpace(entry.GetProperty("certificateNumber").GetString()));
        Assert.True(entry.TryGetProperty("expired", out var expired));
        Assert.True(expired.ValueKind is JsonValueKind.True or JsonValueKind.False);
        Assert.True(entry.TryGetProperty("daysRemaining", out _));
    }

    /// <summary>
    /// The scan register must never hand back the session signature. It is the proof the
    /// device authenticated with, and returning it would be returning the means to forge
    /// the next one.
    /// </summary>
    [Fact]
    public async Task Ch1MfgFr0002_TheScanRegisterDoesNotDiscloseTheSessionSignature()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var inspector = Client("USR-SCAN-READER", "Inspector");

        using var response = await inspector.GetAsync("/api/v1/parts/scan-events", cancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var raw = await response.Content.ReadAsStringAsync(cancellationToken);
        Assert.DoesNotContain("sessionSignature", raw, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("SessionSignatureSha256", raw, StringComparison.Ordinal);
    }

    /// <summary>
    /// The board reports release state and confers none, and says so on its own response.
    /// </summary>
    [Fact]
    public async Task Ch1MfgFr0001_TheWorkOrderBoardReportsReleaseWithoutConferringIt()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var manager = Client("USR-WO-READER", "ProjectManager");

        using var response = await manager.GetAsync("/api/v1/work-orders", cancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await BodyAsync(response, cancellationToken);

        Assert.Contains(
            "conferred nowhere",
            body.GetProperty("releaseAuthority").GetString()!,
            StringComparison.Ordinal);

        // Every row carries a status, so a board cannot render "released" from an absence.
        foreach (var order in body.GetProperty("items").EnumerateArray())
        {
            Assert.False(string.IsNullOrWhiteSpace(order.GetProperty("status").GetString()));
        }
    }

    /// <summary>
    /// The workbench states the isolation on every row and in the response, so a screen
    /// cannot render an experiment as production work.
    /// </summary>
    [Fact]
    public async Task Ch1RndFr0001_TheWorkbenchStatesIsolationOnEveryRow()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var researcher = Client("USR-RND-READER", "RDEngineer");

        using var response = await researcher.GetAsync("/api/v1/experiments", cancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await BodyAsync(response, cancellationToken);

        Assert.Contains(
            "no production authority",
            body.GetProperty("isolationStatement").GetString()!,
            StringComparison.Ordinal);

        foreach (var experiment in body.GetProperty("items").EnumerateArray())
        {
            Assert.True(experiment.TryGetProperty("productionAuthority", out var authority));
            Assert.False(authority.GetBoolean());
        }
    }

    /// <summary>
    /// An experiment in another project is absent, not forbidden — the same answer every
    /// other read gives, so probing cannot tell the two apart.
    /// </summary>
    [Fact]
    public async Task Ch1CybFr0001_AnExperimentOutsideTheProjectIsAbsentRatherThanForbidden()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var researcher = Client("USR-RND-SCOPE", "RDEngineer");

        using var missing = await researcher.GetAsync(
            $"/api/v1/experiments/{Guid.NewGuid()}", cancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, missing.StatusCode);
    }

    /// <summary>
    /// The promotion review reads what CH1-RND-FR-0003 requires a promotion to carry, and
    /// the platform says plainly that it does not approve one.
    /// </summary>
    [Fact]
    public async Task Ch1RndFr0003_ThePromotionReviewShowsAllThreeAndApprovesNothing()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var researcher = Client("USR-RND-PROMOTE", "RDEngineer");

        using var created = await researcher.PostAsJsonAsync(
            "/api/v1/experiments",
            new { Objective = "Coating adhesion under reduced cure time", Environment = "Simulator" },
            cancellationToken);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var experimentId = (await BodyAsync(created, cancellationToken)).GetProperty("experimentId").GetGuid();

        using var read = await researcher.GetAsync($"/api/v1/experiments/{experimentId}", cancellationToken);
        Assert.Equal(HttpStatusCode.OK, read.StatusCode);
        var body = await BodyAsync(read, cancellationToken);

        // No promotion requested yet, and the field says so rather than carrying empty
        // strings that a screen would render as a completed review.
        Assert.Equal(JsonValueKind.Null, body.GetProperty("promotion").ValueKind);
        Assert.False(body.GetProperty("productionAuthority").GetBoolean());
        Assert.Contains(
            "no operation here performs it",
            body.GetProperty("promotionAuthority").GetString()!,
            StringComparison.Ordinal);
    }
}
