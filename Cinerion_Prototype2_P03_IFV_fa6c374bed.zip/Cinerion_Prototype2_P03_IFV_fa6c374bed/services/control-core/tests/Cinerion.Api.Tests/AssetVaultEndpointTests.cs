// Tests for device reads and the calibration rule, over HTTP.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// Device register reads, and the calibration rule that governs whether a measured
/// value may become a controlled acceptance result.
/// </summary>
/// <requirements>CH1-COM-FR-0009, CH1-QMS-FR-0006</requirements>
public sealed class AssetVaultEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private const string Project = "00000000-0000-4000-8000-000000000101";
    private const string Cell = "00000000-0000-4000-8000-000000000103";
    private const string Part = "00000000-0000-4000-8000-000000000106";
    private const string Calibration = "00000000-0000-4000-8000-000000000108";
    private const string Instrument = "CH1-INS-THK-0001";

    private HttpClient Client(string roles, string actor)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actor);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        return client;
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0028")]
    public async Task Ch1ComFr0009_ADeviceReportsItsFirmwareConfigurationAndLastSeen()
    {
        using var engineer = Client("Engineer", "USR-AV-01");

        using var response = await engineer.GetAsync(
            $"/api/v1/devices/{Instrument}",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(Instrument, body.GetProperty("deviceId").GetString());
        Assert.False(string.IsNullOrWhiteSpace(body.GetProperty("firmwareVersion").GetString()));
        Assert.False(string.IsNullOrWhiteSpace(body.GetProperty("configurationRevision").GetString()));
        Assert.Equal("Reported", body.GetProperty("lastSeenQuality").GetString());
        Assert.True(body.GetProperty("trusted").GetBoolean());
    }

    /// <summary>The projection must carry no secret or key material.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0125")]
    public async Task Ch1CybFr0006_TheDeviceProjectionCarriesNoSecretMaterial()
    {
        using var engineer = Client("Engineer", "USR-AV-02");

        using var response = await engineer.GetAsync(
            $"/api/v1/devices/{Instrument}",
            TestContext.Current.CancellationToken);
        var raw = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);

        foreach (var forbidden in new[] { "privateKey", "secret", "password", "enrolmentToken", "BEGIN PRIVATE KEY" })
        {
            Assert.DoesNotContain(forbidden, raw, StringComparison.OrdinalIgnoreCase);
        }
    }

    [Fact]
    public async Task Ch1CybFr0001_AnInspectorMayNotReadTheDeviceRegister()
    {
        using var inspector = Client("Inspector", "USR-AV-03");

        using var response = await inspector.GetAsync(
            $"/api/v1/devices/{Instrument}",
            TestContext.Current.CancellationToken);

        // Reported as absent rather than forbidden, so the register cannot be probed.
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0028")]
    public async Task Ch1ComFr0009_AnUnknownDeviceIsIndistinguishableFromOneOutOfScope()
    {
        using var engineer = Client("Engineer", "USR-AV-04");

        using var response = await engineer.GetAsync(
            "/api/v1/devices/CH1-DEV-DOES-NOT-EXIST",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    /// <summary>
    /// The decisive one. The request body still carries CalibrationValid, but the
    /// server now decides from the stored certificate. Claiming validity for an
    /// instrument whose certificate does not cover it must not produce an acceptance
    /// result.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0045")]
    public async Task Ch1QmsFr0006_AClientCannotAssertItsOwnCalibrationValidity()
    {
        using var inspector = Client("Inspector", "USR-AV-CAL-01");
        using var runResponse = await inspector.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            TestContext.Current.CancellationToken);
        var runId = (await runResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("testRunId").GetGuid();

        using var response = await inspector.PostAsJsonAsync(
            $"/api/v1/test-runs/{runId}/measurements",
            new
            {
                PartId = Part,
                Characteristic = "Coating thickness",
                Value = 10.0m,
                Unit = "um",
                LowerLimit = 9.5m,
                UpperLimit = 10.5m,
                Mandatory = true,
                // A different instrument from the one the certificate covers.
                SourceDeviceId = "CH1-INS-UNCALIBRATED-0001",
                CalibrationRecordId = Calibration,
                // The caller asserts it is calibrated. The server must not believe it.
                CalibrationValid = true,
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("INSTRUMENT_CALIBRATION_EXPIRED", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0045")]
    public async Task Ch1QmsFr0006_AMeasurementCitingAnUnknownCertificateIsRefused()
    {
        using var inspector = Client("Inspector", "USR-AV-CAL-02");
        using var runResponse = await inspector.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            TestContext.Current.CancellationToken);
        var runId = (await runResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("testRunId").GetGuid();

        using var response = await inspector.PostAsJsonAsync(
            $"/api/v1/test-runs/{runId}/measurements",
            new
            {
                PartId = Part,
                Characteristic = "Coating thickness",
                Value = 10.0m,
                Unit = "um",
                LowerLimit = 9.5m,
                UpperLimit = 10.5m,
                Mandatory = true,
                SourceDeviceId = Instrument,
                CalibrationRecordId = Guid.NewGuid(),
                CalibrationValid = true,
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("CALIBRATION_RECORD_NOT_FOUND", body.GetProperty("code").GetString());
    }

    /// <summary>The in-date certificate for the right instrument still admits a result.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0041")]
    public async Task Ch1QmsFr0006_AValidCertificateForTheCitedInstrumentIsAccepted()
    {
        using var inspector = Client("Inspector", "USR-AV-CAL-03");
        using var runResponse = await inspector.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            TestContext.Current.CancellationToken);
        var runId = (await runResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("testRunId").GetGuid();

        using var response = await inspector.PostAsJsonAsync(
            $"/api/v1/test-runs/{runId}/measurements",
            new
            {
                PartId = Part,
                Characteristic = "Coating thickness",
                Value = 10.0m,
                Unit = "um",
                LowerLimit = 9.5m,
                UpperLimit = 10.5m,
                Mandatory = true,
                SourceDeviceId = Instrument,
                CalibrationRecordId = Calibration,
                // Deliberately false: the server's determination governs, in both
                // directions, so an accurate stored certificate still admits the result.
                CalibrationValid = false,
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }
}
