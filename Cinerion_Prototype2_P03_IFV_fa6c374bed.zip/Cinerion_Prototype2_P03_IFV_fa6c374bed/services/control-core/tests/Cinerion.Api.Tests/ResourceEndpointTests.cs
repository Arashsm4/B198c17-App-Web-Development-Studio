// Tests for resource capacity and reservations over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Domain.Resources;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// Resource capacity, reservation and cancellation over HTTP.
/// </summary>
/// <requirements>CH1-MGT-FR-0002, CH1-MGT-FR-0003, CH1-MGT-FR-0004, CH1-VVT-TC-0106</requirements>
public sealed class ResourceEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid WorkOrderId = PrototypeSeed.Ids.WorkOrderId;
    private static readonly Guid Station = PrototypeSeed.Ids.CoatingStationResourceId;
    private static readonly Guid FilmStock = PrototypeSeed.Ids.FilmStockResourceId;

    /// <summary>Far enough ahead that each test picks a window of its own.</summary>
    private static DateTimeOffset Slot(int dayOffset) =>
        new DateTimeOffset(2027, 1, 1, 8, 0, 0, TimeSpan.Zero).AddDays(dayOffset);

    private HttpClient Client(string actorId, string roles)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private HttpClient Coordinator(string actorId = "USR-COORDINATOR-01") =>
        Client(actorId, "OperationsCoordinator");

    /// <summary>
    /// Obtains a fresh step-up grant. access.json requires step-up MFA to manage
    /// resource allocations; the grant is single use, so each reservation needs its own.
    /// </summary>
    private static async Task<string> StepUpAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "ResourceAllocation" }, cancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("grantId").GetGuid().ToString();
    }

    private static async Task<JsonElement> ResourceViewAsync(
        HttpClient client,
        Guid resourceId,
        DateTimeOffset from,
        DateTimeOffset to,
        CancellationToken cancellationToken)
    {
        var url = $"/api/v1/resources?from={Uri.EscapeDataString(from.ToString("O", CultureInfo.InvariantCulture))}" +
            $"&to={Uri.EscapeDataString(to.ToString("O", CultureInfo.InvariantCulture))}";
        using var response = await client.GetAsync(url, cancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("resourceId").GetGuid() == resourceId);
    }

    private static async Task<HttpResponseMessage> ReserveAsync(
        HttpClient client,
        Guid resourceId,
        long resourceVersion,
        object body,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(
            HttpMethod.Post, $"/api/v1/resources/{resourceId}/reservations")
        {
            Content = JsonContent.Create(body),
        };
        request.Headers.TryAddWithoutValidation("If-Match", $"\"{resourceVersion}\"");
        request.Headers.Add("X-CH1-Step-Up", await StepUpAsync(client, cancellationToken));
        return await client.SendAsync(request, cancellationToken);
    }

    [Fact]
    public async Task Ch1MgtFr0004_ResourcesExposeCapacityAvailabilityAndTheirVersion()
    {
        using var client = Coordinator();
        using var response = await client.GetAsync("/api/v1/resources", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var station = body.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("resourceId").GetGuid() == Station);

        Assert.Equal("Equipment", station.GetProperty("resourceType").GetString());
        Assert.Equal(1m, station.GetProperty("capacity").GetDecimal());
        Assert.Equal("station", station.GetProperty("unit").GetString());
        Assert.Equal("Available", station.GetProperty("availabilityState").GetString());
        Assert.True(station.GetProperty("acceptsReservations").GetBoolean());
        Assert.True(station.GetProperty("version").GetInt64() >= 1);
        // The ledger is read from the system of record, not sampled from equipment.
        Assert.Equal("Live", body.GetProperty("freshness").GetString());
    }

    /// <summary>
    /// The core of CH1-VVT-TC-0106 for an indivisible resource: a second overlapping
    /// reservation is a straight double-booking and must be refused.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0106")]
    public async Task Ch1VvtTc0106_AnOverlappingReservationOnAFullResourceIsRefused()
    {
        using var client = Coordinator();
        var from = Slot(10);
        var to = from.AddHours(4);

        var before = await ResourceViewAsync(client, Station, from, to, TestContext.Current.CancellationToken);
        using var first = await ReserveAsync(
            client, Station, before.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = from, endsAt = to, workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);

        var after = await ResourceViewAsync(client, Station, from, to, TestContext.Current.CancellationToken);
        using var second = await ReserveAsync(
            client, Station, after.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = from.AddHours(2), endsAt = to.AddHours(2), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        var refusal = await second.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        // 409, not 400: the request is well formed and conflicts with the resource's
        // current commitments. A client that retries a different interval will succeed.
        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
        Assert.Equal("ALLOCATION_CAPACITY_CONFLICT", refusal.GetProperty("code").GetString());

        // A reservation that does not overlap is accepted, so the refusal was about the
        // interval rather than the resource being unusable.
        var current = await ResourceViewAsync(client, Station, from, to, TestContext.Current.CancellationToken);
        using var adjacent = await ReserveAsync(
            client, Station, current.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = to, endsAt = to.AddHours(2), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, adjacent.StatusCode);
    }

    /// <summary>
    /// For a measured resource the check has to add quantities, not count bookings.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0106")]
    public async Task Ch1VvtTc0106_CapacityIsSummedAcrossOverlappingReservations()
    {
        using var client = Coordinator();
        var from = Slot(20);
        var to = from.AddHours(6);

        var start = await ResourceViewAsync(client, FilmStock, from, to, TestContext.Current.CancellationToken);
        using var first = await ReserveAsync(
            client, FilmStock, start.GetProperty("version").GetInt64(),
            new { quantity = 200m, startsAt = from, endsAt = to, workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);

        var mid = await ResourceViewAsync(client, FilmStock, from, to, TestContext.Current.CancellationToken);
        Assert.Equal(200m, mid.GetProperty("committedPeak").GetDecimal());
        Assert.Equal(50m, mid.GetProperty("availableAtPeak").GetDecimal());

        // 200 + 60 exceeds the 250 m capacity.
        using var over = await ReserveAsync(
            client, FilmStock, mid.GetProperty("version").GetInt64(),
            new { quantity = 60m, startsAt = from.AddHours(1), endsAt = to, workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Conflict, over.StatusCode);

        // 200 + 50 fits exactly.
        var again = await ResourceViewAsync(client, FilmStock, from, to, TestContext.Current.CancellationToken);
        using var exact = await ReserveAsync(
            client, FilmStock, again.GetProperty("version").GetInt64(),
            new { quantity = 50m, startsAt = from.AddHours(1), endsAt = to, workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, exact.StatusCode);

        var full = await ResourceViewAsync(client, FilmStock, from, to, TestContext.Current.CancellationToken);
        Assert.Equal(250m, full.GetProperty("committedPeak").GetDecimal());
        Assert.Equal(0m, full.GetProperty("availableAtPeak").GetDecimal());
        Assert.False(full.GetProperty("conflicted").GetBoolean());
    }

    /// <summary>
    /// Cancelling releases the capacity, and the record of who released it and why is
    /// kept rather than deleted (CH1-MGT-FR-0003).
    /// </summary>
    [Fact]
    public async Task Ch1MgtFr0003_CancellationReleasesCapacityAndRetainsItsEvidence()
    {
        using var client = Coordinator();
        var from = Slot(30);
        var to = from.AddHours(3);

        var before = await ResourceViewAsync(client, Station, from, to, TestContext.Current.CancellationToken);
        using var reserved = await ReserveAsync(
            client, Station, before.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = from, endsAt = to, workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        var allocation = await reserved.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var allocationId = allocation.GetProperty("allocationId").GetGuid();
        Assert.Equal(WorkOrderId, allocation.GetProperty("workOrderId").GetGuid());
        Assert.Equal(JsonValueKind.Null, allocation.GetProperty("experimentId").ValueKind);
        Assert.Contains(
            "starts no equipment",
            allocation.GetProperty("physicalEffect").GetString() ?? string.Empty,
            StringComparison.Ordinal);

        using var cancelRequest = new HttpRequestMessage(
            HttpMethod.Delete,
            $"/api/v1/reservations/{allocationId}?reason={Uri.EscapeDataString("Work order rescheduled.")}");
        cancelRequest.Headers.TryAddWithoutValidation("If-Match", $"\"{allocation.GetProperty("version").GetInt64()}\"");
        cancelRequest.Headers.Add("X-CH1-Step-Up", await StepUpAsync(client, TestContext.Current.CancellationToken));
        using var cancelled = await client.SendAsync(cancelRequest, TestContext.Current.CancellationToken);
        var body = await cancelled.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, cancelled.StatusCode);
        Assert.Equal("Cancelled", body.GetProperty("status").GetString());
        Assert.Equal("Work order rescheduled.", body.GetProperty("cancellationReason").GetString());
        Assert.Equal("USR-COORDINATOR-01", body.GetProperty("cancelledBy").GetString());
        Assert.NotEqual(JsonValueKind.Null, body.GetProperty("cancelledAt").ValueKind);
        // Revisioned, and the original reservation is still fully described.
        Assert.Equal(2, body.GetProperty("version").GetInt64());
        Assert.Equal(1m, body.GetProperty("quantity").GetDecimal());

        // The capacity is free again.
        var after = await ResourceViewAsync(client, Station, from, to, TestContext.Current.CancellationToken);
        Assert.Equal(0m, after.GetProperty("committedPeak").GetDecimal());
        using var reuse = await ReserveAsync(
            client, Station, after.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = from, endsAt = to, workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, reuse.StatusCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1CybAcp0001_ReservingRequiresStepUpAndTheCoordinatorOrManagerRole()
    {
        using var client = Coordinator("USR-COORDINATOR-NOSTEPUP");
        var from = Slot(40);
        var view = await ResourceViewAsync(client, Station, from, from.AddHours(1), TestContext.Current.CancellationToken);

        // No step-up header at all.
        using var withoutStepUp = await client.PostAsJsonAsync(
            $"/api/v1/resources/{Station}/reservations",
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        var refusal = await withoutStepUp.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, withoutStepUp.StatusCode);
        Assert.Equal("STEP_UP_REQUIRED", refusal.GetProperty("code").GetString());

        // Correct step-up, wrong role.
        using var viewer = Client("USR-VIEWER-RES", "Viewer");
        using var wrongRole = await ReserveAsync(
            viewer, Station, view.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        var denied = await wrongRole.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, wrongRole.StatusCode);
        Assert.Equal("AUTH_RESOURCE_ALLOCATION", denied.GetProperty("code").GetString());
    }

    /// <summary>
    /// CH1-SWA-API-0001 requires stale updates to fail explicitly. A reservation decided
    /// against a version that has moved on is refused rather than silently applied.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0105")]
    public async Task Ch1SwaApi0001_AStaleResourceVersionIsRefused()
    {
        using var client = Coordinator();
        var from = Slot(50);
        var view = await ResourceViewAsync(client, Station, from, from.AddHours(2), TestContext.Current.CancellationToken);
        var staleVersion = view.GetProperty("version").GetInt64();

        using var first = await ReserveAsync(
            client, Station, staleVersion,
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);

        // Same version again: the resource has moved on.
        using var stale = await ReserveAsync(
            client, Station, staleVersion,
            new { quantity = 1m, startsAt = from.AddHours(1), endsAt = from.AddHours(2), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        var conflict = await stale.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Conflict, stale.StatusCode);
        Assert.Equal("CONCURRENCY_CONFLICT", conflict.GetProperty("code").GetString());

        // Omitting If-Match is refused too, and told what to send.
        using var request = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/resources/{Station}/reservations")
        {
            Content = JsonContent.Create(
                new { quantity = 1m, startsAt = from.AddHours(3), endsAt = from.AddHours(4), workOrderId = WorkOrderId }),
        };
        request.Headers.Add("X-CH1-Step-Up", await StepUpAsync(client, TestContext.Current.CancellationToken));
        using var missing = await client.SendAsync(request, TestContext.Current.CancellationToken);
        var told = await missing.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RESOURCE_VERSION_REQUIRED", told.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0106")]
    public async Task Ch1MgtFr0004_AReservationMustNameAWorkOrderThatExists()
    {
        using var client = Coordinator();
        var from = Slot(60);
        var view = await ResourceViewAsync(client, Station, from, from.AddHours(1), TestContext.Current.CancellationToken);
        var version = view.GetProperty("version").GetInt64();

        using var unlinked = await ReserveAsync(
            client, Station, version,
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1) },
            TestContext.Current.CancellationToken);
        var unlinkedBody = await unlinked.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("ALLOCATION_LINK_REQUIRED", unlinkedBody.GetProperty("code").GetString());

        using var absent = await ReserveAsync(
            client, Station, version,
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1), workOrderId = Guid.NewGuid() },
            TestContext.Current.CancellationToken);
        var absentBody = await absent.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, absent.StatusCode);
        Assert.Equal("WORK_ORDER_NOT_FOUND", absentBody.GetProperty("code").GetString());

        // ResearchBench is enabled, so capacity may be held for an experiment — but only
        // one that exists. The allowed case is covered in ResearchBenchEndpointTests.
        using var experiment = await ReserveAsync(
            client, Station, version,
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1), experimentId = Guid.NewGuid() },
            TestContext.Current.CancellationToken);
        var experimentBody = await experiment.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, experiment.StatusCode);
        Assert.Equal("EXPERIMENT_NOT_FOUND", experimentBody.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1CybFr0001_ResourcesOutsideTheCallerProjectAreNotVisible()
    {
        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OTHER-PROJECT");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "OperationsCoordinator");

        using var response = await outsider.GetAsync("/api/v1/resources", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(0, body.GetProperty("count").GetInt32());
    }

    [Fact]
    public async Task Ch1CybAcp0001_AnIdentityWithoutADashboardRoleReadsNothing()
    {
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "SVC-NO-ROLE-RES");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());

        using var response = await client.GetAsync("/api/v1/resources", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task FiltersAndBoundsAreEnforcedAndStated()
    {
        using var client = Coordinator();

        using var filtered = await client.GetAsync(
            "/api/v1/resources?resourceType=Consumable", TestContext.Current.CancellationToken);
        var body = await filtered.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.All(
            body.GetProperty("items").EnumerateArray(),
            item => Assert.Equal("Consumable", item.GetProperty("resourceType").GetString()));
        Assert.Equal(
            ResourceQuery.MaximumWindow.TotalDays,
            body.GetProperty("bounds").GetProperty("maximumWindowDays").GetDouble());

        using var badFilter = await client.GetAsync(
            "/api/v1/resources?availabilityState=Bogus", TestContext.Current.CancellationToken);
        var refusal = await badFilter.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, badFilter.StatusCode);
        Assert.Equal("RESOURCE_AVAILABILITY_FILTER_INVALID", refusal.GetProperty("code").GetString());

        var wide = DateTimeOffset.UtcNow;
        using var tooWide = await client.GetAsync(
            $"/api/v1/resources?from={Uri.EscapeDataString(wide.ToString("O", CultureInfo.InvariantCulture))}" +
            $"&to={Uri.EscapeDataString(wide.AddDays(365).ToString("O", CultureInfo.InvariantCulture))}",
            TestContext.Current.CancellationToken);
        var window = await tooWide.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RESOURCE_WINDOW_TOO_WIDE", window.GetProperty("code").GetString());

        using var badCursor = await client.GetAsync(
            "/api/v1/resources?cursor=not-a-cursor", TestContext.Current.CancellationToken);
        var cursor = await badCursor.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RESOURCE_CURSOR_INVALID", cursor.GetProperty("code").GetString());
    }

    [Fact]
    public async Task CancellationRequiresAReasonTheVersionAndTheOwnerOrCoordinator()
    {
        using var owner = Coordinator("USR-COORDINATOR-OWNER");
        var from = Slot(70);
        var view = await ResourceViewAsync(owner, Station, from, from.AddHours(1), TestContext.Current.CancellationToken);
        using var reserved = await ReserveAsync(
            owner, Station, view.GetProperty("version").GetInt64(),
            new { quantity = 1m, startsAt = from, endsAt = from.AddHours(1), workOrderId = WorkOrderId },
            TestContext.Current.CancellationToken);
        var allocation = await reserved.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var allocationId = allocation.GetProperty("allocationId").GetGuid();
        var version = allocation.GetProperty("version").GetInt64();

        // No reason.
        using var noReason = await SendCancelAsync(owner, allocationId, null, version, TestContext.Current.CancellationToken);
        var noReasonBody = await noReason.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("ALLOCATION_CANCELLATION_REASON_REQUIRED", noReasonBody.GetProperty("code").GetString());

        // No version.
        using var noVersion = await SendCancelAsync(owner, allocationId, "Rescheduled.", null, TestContext.Current.CancellationToken);
        var noVersionBody = await noVersion.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RESERVATION_VERSION_REQUIRED", noVersionBody.GetProperty("code").GetString());

        // Neither the owner nor a coordinator.
        using var stranger = Client("USR-ENGINEER-RES", "Engineer");
        using var denied = await SendCancelAsync(stranger, allocationId, "Not mine.", version, TestContext.Current.CancellationToken);
        var deniedBody = await denied.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode);
        Assert.Equal("AUTH_RESERVATION_CANCELLATION", deniedBody.GetProperty("code").GetString());

        // The owner, correctly.
        using var accepted = await SendCancelAsync(owner, allocationId, "Rescheduled.", version, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, accepted.StatusCode);
    }

    private static async Task<HttpResponseMessage> SendCancelAsync(
        HttpClient client,
        Guid allocationId,
        string? reason,
        long? version,
        CancellationToken cancellationToken)
    {
        var url = $"/api/v1/reservations/{allocationId}" +
            (reason is null ? string.Empty : $"?reason={Uri.EscapeDataString(reason)}");
        using var request = new HttpRequestMessage(HttpMethod.Delete, url);
        if (version is not null)
        {
            request.Headers.TryAddWithoutValidation("If-Match", $"\"{version}\"");
        }

        request.Headers.Add("X-CH1-Step-Up", await StepUpAsync(client, cancellationToken));
        return await client.SendAsync(request, cancellationToken);
    }
}
