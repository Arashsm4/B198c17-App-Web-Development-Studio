// Tests for project and site reads over HTTP.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// Project and site reads over HTTP. The seeded project is the one the prototype
/// identity is scoped to, so these also prove the reads come from the store rather
/// than from the caller's own claim.
/// </summary>
public sealed class ProjectEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private const string SeededProject = "00000000-0000-4000-8000-000000000101";
    private const string SeededSite = "00000000-0000-4000-8000-000000000102";
    private const string SeededCell = "00000000-0000-4000-8000-000000000103";

    private static HttpClient Client(
        CinerionApiFactory factory,
        string roles,
        string project = SeededProject,
        string cells = SeededCell,
        string strength = "Mfa")
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", $"USR-{roles.Replace(',', '-')}");
        client.DefaultRequestHeaders.Add("X-CH1-Project", project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        if (cells.Length > 0) client.DefaultRequestHeaders.Add("X-CH1-Cells", cells);
        return client;
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0100")]
    public async Task Ch1MgtFr0001_ProjectsAreReadFromTheStoreNotTheCallerClaim()
    {
        using var client = Client(factory, "Engineer");

        using var response = await client.GetAsync("/api/v1/projects", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var project = Assert.Single(body.EnumerateArray().ToArray());
        Assert.Equal(SeededProject, project.GetProperty("projectId").GetString());
        Assert.Equal("CH1", project.GetProperty("projectCode").GetString());
        Assert.Equal("P03/IFV", project.GetProperty("baseline").GetString());
        Assert.True(project.GetProperty("version").GetInt64() >= 1);
    }

    /// <summary>
    /// A token scoped to a project that was never established must yield nothing. The
    /// endpoint previously echoed the claim, which meant an arbitrary project scope
    /// appeared to name a real governance record.
    /// </summary>
    [Fact]
    public async Task Ch1MgtFr0001_UnknownProjectScopeReturnsNoProject()
    {
        using var client = Client(factory, "Engineer", project: Guid.NewGuid().ToString(), cells: string.Empty);

        using var response = await client.GetAsync("/api/v1/projects", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Empty(body.EnumerateArray().ToArray());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0100")]
    public async Task Ch1MgtFr0001_SiteCellsAreListedForAnAssignedCell()
    {
        using var client = Client(factory, "Engineer");

        using var response = await client.GetAsync(
            $"/api/v1/sites/{SeededSite}/cells",
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var cell = Assert.Single(body.EnumerateArray().ToArray());
        Assert.Equal(SeededCell, cell.GetProperty("cellId").GetString());
        Assert.Equal("ReFab Cell 01", cell.GetProperty("name").GetString());
        Assert.False(string.IsNullOrWhiteSpace(cell.GetProperty("stateHash").GetString()));
    }

    /// <summary>
    /// A site in another project must be indistinguishable from one that does not
    /// exist, so neither can be inferred by probing.
    /// </summary>
    [Fact]
    public async Task Ch1CybFr0001_SiteOutsideTheProjectIsIndistinguishableFromAbsent()
    {
        using var client = Client(factory, "Engineer", project: Guid.NewGuid().ToString(), cells: string.Empty);

        using var foreignSite = await client.GetAsync(
            $"/api/v1/sites/{SeededSite}/cells",
            TestContext.Current.CancellationToken);
        using var absentSite = await client.GetAsync(
            $"/api/v1/sites/{Guid.NewGuid()}/cells",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, foreignSite.StatusCode);
        Assert.Equal(absentSite.StatusCode, foreignSite.StatusCode);
    }

    /// <summary>Cell assignment narrows a project-scoped listing further.</summary>
    [Fact]
    public async Task Ch1MgtFr0001_UnassignedCellIsOmittedFromTheSiteListing()
    {
        using var client = Client(factory, "Engineer", cells: Guid.NewGuid().ToString());

        using var response = await client.GetAsync(
            $"/api/v1/sites/{SeededSite}/cells",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Empty(body.EnumerateArray().ToArray());
    }

    [Fact]
    public async Task Ch1MgtFr0001_EstablishingAProjectRequiresProjectManagerAuthority()
    {
        using var client = Client(factory, "Engineer", project: Guid.NewGuid().ToString(), cells: string.Empty);

        using var response = await client.PostAsJsonAsync(
            "/api/v1/projects",
            new { ProjectCode = "CH1-NEW", Name = "New", Baseline = "P03/IFV" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_PROJECT_MANAGER_REQUIRED", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1MgtFr0001_AnAlreadyEstablishedProjectIsNotRecreated()
    {
        using var client = Client(factory, "ProjectManager");

        using var response = await client.PostAsJsonAsync(
            "/api/v1/projects",
            new { ProjectCode = "CH1-DUPLICATE", Name = "Duplicate", Baseline = "P03/IFV" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("PROJECT_ALREADY_ESTABLISHED", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// A body the binder cannot read is a client fault and must carry a stable code
    /// and correlation identifier, not a bare 500 that blames the server.
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_MalformedRequestBodyIsARejectionNotAServerFault()
    {
        using var client = Client(factory, "ProjectManager", project: Guid.NewGuid().ToString(), cells: string.Empty);
        using var content = new StringContent("not json at all", System.Text.Encoding.UTF8, "application/json");

        using var response = await client.PostAsync("/api/v1/projects", content, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("CH1_REQUEST_BODY_INVALID", body.GetProperty("code").GetString());
        Assert.False(string.IsNullOrWhiteSpace(body.GetProperty("correlationId").GetString()));
    }

    [Fact]
    public async Task Ch1MgtFr0001_ProjectManagerEstablishesTheProjectForTheirOwnScope()
    {
        var scope = Guid.NewGuid().ToString();
        using var client = Client(factory, "ProjectManager", project: scope, cells: string.Empty);

        using var response = await client.PostAsJsonAsync(
            "/api/v1/projects",
            new { ProjectCode = $"CH1-{Guid.NewGuid():N}".ToUpperInvariant()[..12], Name = "Scoped", Baseline = "P03/IFV" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        // The identifier comes from the caller's scope, never from the request body.
        Assert.Equal(scope, body.GetProperty("projectId").GetString());
    }
}
