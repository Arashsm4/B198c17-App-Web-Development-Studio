// Tests that project scope reaches PostgreSQL, and row-level security fails closed without it.

using Cinerion.Infrastructure.Persistence;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// Proves the project scope actually reaches PostgreSQL and that row-level security
/// fails closed without it.
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set, so the ordinary suite stays
/// runnable without a database. CI runs the data-lab profile and therefore executes
/// these; a skipped gate is never reported as passed.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-FR-0001, CH1-DBA-FR-0001</requirements>
public sealed class PostgresRowLevelSecurityTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    private static async Task<CinerionDataSource> ConnectAsync(ProjectScope scope, CancellationToken cancellationToken)
    {
        var source = new CinerionDataSource(ConnectionString!, scope);
        // Every migration in order, not only the foundation. Applying 0001 alone
        // produced a schema the running code does not match, so a first-run test
        // database would fail on the newer columns.
        var migrations = await Task
            .WhenAll(MigrationPaths().Select(path => File.ReadAllTextAsync(path, cancellationToken)))
            .ConfigureAwait(false);
        await source.EnsureSchemaAsync(migrations, cancellationToken).ConfigureAwait(false);
        return source;
    }

    internal static IReadOnlyList<string> MigrationPaths()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !Directory.Exists(Path.Combine(directory.FullName, "docs", "baseline")))
        {
            directory = directory.Parent;
        }

        return [.. Directory
            .GetFiles(
                Path.Combine(directory!.FullName, "services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations"),
                "*.sql")
            .OrderBy(path => path, StringComparer.Ordinal)];
    }

    [Fact]
    public async Task Ch1DbaFr0001_TheControlledSchemaIsPresentAndComplete()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var scope = new ProjectScope();
        await using var source = await ConnectAsync(scope, TestContext.Current.CancellationToken);

        var tables = await source.CountControlledTablesAsync(TestContext.Current.CancellationToken);

        Assert.True(tables >= 26, $"Expected the controlled ch1 schema; found {tables} tables.");
    }

    /// <summary>
    /// A session that never establishes its project scope must read nothing. This is
    /// the property the whole isolation model rests on: a bug that loses the scope
    /// causes an empty result, never an unfiltered one.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0124")]
    public async Task Ch1CybFr0001_WithoutAProjectScopeNoRowsAreVisible()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var project = Guid.NewGuid();

        var writer = new ProjectScope();
        writer.Set(project);
        await using var source = await ConnectAsync(writer, TestContext.Current.CancellationToken);
        await InsertProjectAsync(source, project, TestContext.Current.CancellationToken);

        try
        {
            // Same database, scope deliberately not established.
            var unscoped = new ProjectScope();
            await using var unscopedSource = new CinerionDataSource(ConnectionString!, unscoped);
            await using var connection = await unscopedSource.OpenAsync(TestContext.Current.CancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT count(*) FROM ch1.projects";
            var visible = Convert.ToInt64(
                await command.ExecuteScalarAsync(TestContext.Current.CancellationToken),
                System.Globalization.CultureInfo.InvariantCulture);

            Assert.Equal(0, visible);
        }
        finally
        {
            await DeleteProjectAsync(source, project, TestContext.Current.CancellationToken);
        }
    }

    /// <summary>One project's scope must not reveal another project's rows.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0124")]
    public async Task Ch1CybFr0001_AProjectScopeSeesOnlyItsOwnRows()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var mine = Guid.NewGuid();
        var theirs = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(mine);
        await using var source = await ConnectAsync(scope, TestContext.Current.CancellationToken);
        await InsertProjectAsync(source, mine, TestContext.Current.CancellationToken);
        await InsertProjectAsync(source, theirs, TestContext.Current.CancellationToken);

        try
        {
            await using var connection = await source.OpenAsync(TestContext.Current.CancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT project_id FROM ch1.projects";
            await using var reader = await command.ExecuteReaderAsync(TestContext.Current.CancellationToken);

            var seen = new List<Guid>();
            while (await reader.ReadAsync(TestContext.Current.CancellationToken))
            {
                seen.Add(reader.GetGuid(0));
            }

            Assert.Equal([mine], seen);
        }
        finally
        {
            await DeleteProjectAsync(source, mine, TestContext.Current.CancellationToken);
            await DeleteProjectAsync(source, theirs, TestContext.Current.CancellationToken);
        }
    }

    private static async Task InsertProjectAsync(CinerionDataSource source, Guid projectId, CancellationToken cancellationToken)
    {
        await using var connection = await source.OpenForProjectAsync(projectId, cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText =
            "INSERT INTO ch1.projects(project_id, project_code, name, baseline) VALUES($1, $2, 'Test', 'P03/IFV')";
        command.Parameters.Add(new NpgsqlParameter { Value = projectId });
        command.Parameters.Add(new NpgsqlParameter { Value = $"CH1-T{projectId:N}"[..12].ToUpperInvariant() });
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static async Task DeleteProjectAsync(CinerionDataSource source, Guid projectId, CancellationToken cancellationToken)
    {
        await using var connection = await source.OpenForProjectAsync(projectId, cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM ch1.projects WHERE project_id = $1";
        command.Parameters.Add(new NpgsqlParameter { Value = projectId });
        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
