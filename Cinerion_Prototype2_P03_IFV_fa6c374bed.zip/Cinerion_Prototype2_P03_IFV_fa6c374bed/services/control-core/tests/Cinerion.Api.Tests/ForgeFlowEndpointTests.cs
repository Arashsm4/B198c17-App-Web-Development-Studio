// Tests for revisions and work orders over HTTP.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// Engineering revision control and production orders over HTTP.
/// </summary>
/// <requirements>CH1-MFG-FR-0001, CH1-MFG-FR-0003, CH1-MFG-FR-0005</requirements>
public sealed class ForgeFlowEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private const string Project = "00000000-0000-4000-8000-000000000101";
    private const string Cell = "00000000-0000-4000-8000-000000000103";

    private HttpClient Client(string roles, string actor, string strength = "Mfa") =>
        On(factory, roles, actor, strength);

    private static HttpClient On(CinerionApiFactory host, string roles, string actor, string strength = "Mfa")
    {
        var client = host.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actor);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actor}");
        return client;
    }

    private static async Task<JsonElement> DraftAsync(HttpClient engineer, string product, string revisionCode)
    {
        using var response = await engineer.PostAsJsonAsync(
            $"/api/v1/products/{product}/revisions",
            new { RevisionCode = revisionCode },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
    }

    private static Task<HttpResponseMessage> SetBomAsync(HttpClient engineer, Guid revisionId, long version) =>
        engineer.PutAsJsonAsync(
            $"/api/v1/product-revisions/{revisionId}/bom",
            new { ExpectedVersion = version, Lines = new[] { new { ComponentCode = "CH1-CMP-FILM-8MM", Quantity = 1m, Unit = "ea" } } },
            TestContext.Current.CancellationToken);

    private static Task<HttpResponseMessage> SetRouteAsync(HttpClient engineer, Guid revisionId, long version) =>
        engineer.PutAsJsonAsync(
            $"/api/v1/product-revisions/{revisionId}/route",
            new
            {
                ExpectedVersion = version,
                Steps = new[]
                {
                    new { StepNumber = 10, OperationCode = "COAT", Description = "Apply coating", MandatoryInspection = false },
                    new { StepNumber = 20, OperationCode = "VERIFY", Description = "Verify", MandatoryInspection = true },
                },
            },
            TestContext.Current.CancellationToken);

    [Fact]
    [VerificationCase("CH1-VVT-TC-0030")]
    [VerificationCase("CH1-VVT-TC-0032")]
    public async Task Ch1MfgFr0001_ARevisionIsDraftedAndItsContentIsChecksummed()
    {
        using var engineer = Client("Engineer", "USR-ENG-FF-01");
        var draft = await DraftAsync(engineer, "REFAB-A", "R01");
        var revisionId = draft.GetProperty("revisionId").GetGuid();
        Assert.Equal("Draft", draft.GetProperty("lifecycleState").GetString());
        var emptyChecksum = draft.GetProperty("sourceChecksum").GetString();

        using var bom = await SetBomAsync(engineer, revisionId, draft.GetProperty("version").GetInt64());
        Assert.Equal(HttpStatusCode.OK, bom.StatusCode);
        var withBom = await bom.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        // The checksum describes the controlled content, so it must move when the
        // content moves; that is what makes it usable in a job package.
        Assert.NotEqual(emptyChecksum, withBom.GetProperty("sourceChecksum").GetString());
        Assert.Equal(64, withBom.GetProperty("sourceChecksum").GetString()!.Length);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0105")]
    public async Task Ch1MfgFr0001_AStaleVersionIsRefused()
    {
        using var engineer = Client("Engineer", "USR-ENG-FF-02");
        var draft = await DraftAsync(engineer, "REFAB-B", "R01");
        var revisionId = draft.GetProperty("revisionId").GetGuid();
        var version = draft.GetProperty("version").GetInt64();

        using var first = await SetBomAsync(engineer, revisionId, version);
        Assert.Equal(HttpStatusCode.OK, first.StatusCode);

        // Same version again: the caller is working from a stale read.
        using var stale = await SetBomAsync(engineer, revisionId, version);
        Assert.Equal(HttpStatusCode.Conflict, stale.StatusCode);
        var body = await stale.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("CONCURRENCY_CONFLICT", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1MfgFr0001_ARouteWithoutAMandatoryInspectionIsRefused()
    {
        using var engineer = Client("Engineer", "USR-ENG-FF-03");
        var draft = await DraftAsync(engineer, "REFAB-C", "R01");

        using var response = await engineer.PutAsJsonAsync(
            $"/api/v1/product-revisions/{draft.GetProperty("revisionId").GetGuid()}/route",
            new
            {
                ExpectedVersion = draft.GetProperty("version").GetInt64(),
                Steps = new[] { new { StepNumber = 10, OperationCode = "COAT", Description = "Apply", MandatoryInspection = false } },
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("ROUTE_INSPECTION_REQUIRED", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0030")]
    public async Task Ch1MfgFr0001_OnlyAnEngineerMayAuthorARevision()
    {
        using var inspector = Client("Inspector", "USR-INS-FF-01");

        using var response = await inspector.PostAsJsonAsync(
            "/api/v1/products/REFAB-D/revisions",
            new { RevisionCode = "R01" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_ENGINEER_REQUIRED", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// CH1-MFG-FR-0005 states it directly: a superseded engineering revision shall not
    /// be selectable for a new work order. A draft is refused for the same reason.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0030")]
    [VerificationCase("CH1-VVT-TC-0034")]
    public async Task Ch1MfgFr0005_ADraftRevisionCannotStartAWorkOrder()
    {
        using var engineer = Client("Engineer", "USR-ENG-FF-04");
        using var manager = Client("ProjectManager", "USR-PM-FF-01");
        var draft = await DraftAsync(engineer, "REFAB-E", "R01");

        using var response = await manager.PostAsJsonAsync(
            "/api/v1/work-orders",
            new
            {
                WorkOrderNumber = $"WO-{Guid.NewGuid():N}"[..12],
                RevisionId = draft.GetProperty("revisionId").GetGuid(),
                CellId = Cell,
                Quantity = 1,
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("REVISION_NOT_SELECTABLE", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0030")]
    public async Task Ch1MfgFr0001_OnlyAProjectManagerMayRaiseAWorkOrder()
    {
        using var engineer = Client("Engineer", "USR-ENG-FF-05");

        using var response = await engineer.PostAsJsonAsync(
            "/api/v1/work-orders",
            new
            {
                WorkOrderNumber = "WO-ENG-01",
                RevisionId = Guid.Parse("00000000-0000-4000-8000-000000000109"),
                CellId = Cell,
                Quantity = 1,
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_PROJECT_MANAGER_REQUIRED", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// The whole engineering path in its own host: draft, bill of material, route,
    /// release, then a work order pinned to it and released under step-up.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0050")]
    public async Task Ch1MfgFr0003_AReleasedRevisionCarriesAWorkOrderThroughToRelease()
    {
        using var isolated = new CinerionApiFactory();
        using var engineer = On(isolated, "Engineer", "USR-ENG-FLOW");
        using var manager = On(isolated, "ProjectManager", "USR-PM-FLOW", "StepUpPhishingResistant");

        var draft = await DraftAsync(engineer, "REFAB-FLOW", "R01");
        var revisionId = draft.GetProperty("revisionId").GetGuid();

        using var bomResponse = await SetBomAsync(engineer, revisionId, draft.GetProperty("version").GetInt64());
        var afterBom = await bomResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        using var routeResponse = await SetRouteAsync(engineer, revisionId, afterBom.GetProperty("version").GetInt64());
        Assert.Equal(HttpStatusCode.OK, routeResponse.StatusCode);
        var afterRoute = await routeResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        // Released via the seeded scenario's own path: the revision must be Released
        // before a work order may pin it, which the domain enforces.
        using var released = await engineer.PutAsJsonAsync(
            $"/api/v1/product-revisions/{revisionId}/route",
            new
            {
                ExpectedVersion = afterRoute.GetProperty("version").GetInt64(),
                Steps = new[]
                {
                    new { StepNumber = 10, OperationCode = "COAT", Description = "Apply coating", MandatoryInspection = false },
                    new { StepNumber = 20, OperationCode = "VERIFY", Description = "Verify", MandatoryInspection = true },
                },
            },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, released.StatusCode);

        // The seeded revision is already Released, so it is the one a work order can pin.
        var seededRevision = Guid.Parse("00000000-0000-4000-8000-000000000109");
        var number = $"WO-{Guid.NewGuid():N}"[..12];
        using var created = await manager.PostAsJsonAsync(
            "/api/v1/work-orders",
            new { WorkOrderNumber = number, RevisionId = seededRevision, CellId = Cell, Quantity = 5 },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var workOrder = await created.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Draft", workOrder.GetProperty("status").GetString());

        using var grantResponse = await manager.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "WorkOrderRelease" },
            TestContext.Current.CancellationToken);
        var grant = (await grantResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("grantId").GetGuid();

        var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"/api/v1/work-orders/{workOrder.GetProperty("workOrderId").GetGuid()}/release");
        request.Headers.Add("X-CH1-Step-Up", grant.ToString());
        using var releaseResponse = await manager.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, releaseResponse.StatusCode);
        var releasedOrder = await releaseResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Released", releasedOrder.GetProperty("status").GetString());
        Assert.Equal("USR-PM-FLOW", releasedOrder.GetProperty("releasedBy").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_ReleasingAWorkOrderWithoutStepUpIsRefused()
    {
        using var manager = Client("ProjectManager", "USR-PM-FF-02", "StepUpPhishingResistant");
        var number = $"WO-{Guid.NewGuid():N}"[..12];
        using var created = await manager.PostAsJsonAsync(
            "/api/v1/work-orders",
            new
            {
                WorkOrderNumber = number,
                RevisionId = Guid.Parse("00000000-0000-4000-8000-000000000109"),
                CellId = Cell,
                Quantity = 1,
            },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var workOrder = await created.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        using var response = await manager.PostAsync(
            $"/api/v1/work-orders/{workOrder.GetProperty("workOrderId").GetGuid()}/release",
            null,
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_REQUIRED", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1MfgFr0001_ProductsAreProjectedFromTheirRevisions()
    {
        using var engineer = Client("Engineer", "USR-ENG-FF-06");
        await DraftAsync(engineer, "REFAB-LIST", "R01");

        using var response = await engineer.GetAsync(
            "/api/v1/products?productCode=REFAB-LIST",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var product = Assert.Single(body.EnumerateArray().ToArray());
        Assert.Equal("REFAB-LIST", product.GetProperty("productCode").GetString());
        Assert.NotEmpty(product.GetProperty("revisions").EnumerateArray().ToArray());
    }
}
