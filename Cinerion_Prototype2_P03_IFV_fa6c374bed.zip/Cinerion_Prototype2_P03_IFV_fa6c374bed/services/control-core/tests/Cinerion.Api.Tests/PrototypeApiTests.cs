// Tests that an error never gives away whether a hidden object exists.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Cinerion.Api.Tests;

public sealed class PrototypeApiTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    [Fact]
    public async Task HealthEndpointMakesSimulationAndSafetyBoundaryVisible()
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/v1/system/health", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.True(body.GetProperty("simulation").GetBoolean());
        Assert.Contains("not an E-stop", body.GetProperty("safetyNotice").GetString() ?? string.Empty);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0120")]
    public async Task ProtectedEndpointRejectsImplicitAnonymousTrust()
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/v1/projects", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    /// <summary>
    /// CH1-SWA-API-0001 requires that errors do not reveal whether an inaccessible
    /// object exists. An authenticated actor whose token carries no assignment for the
    /// requested cell must receive the same 404 as for a cell that does not exist.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0120")]
    public async Task Ch1CybFr0001_CellOutsideTokenScopeIsIndistinguishableFromAbsent()
    {
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "scope-test-actor");
        client.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");

        var assignedElsewhere = Guid.NewGuid();
        var neverExisted = Guid.NewGuid();

        using var unassigned = await client.GetAsync(
            $"/api/v1/cells/{assignedElsewhere}/state",
            TestContext.Current.CancellationToken);
        using var absent = await client.GetAsync(
            $"/api/v1/cells/{neverExisted}/state",
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, unassigned.StatusCode);
        Assert.Equal(absent.StatusCode, unassigned.StatusCode);
    }
}

public sealed class CinerionApiFactory : WebApplicationFactory<Program>
{
    /// <summary>
    /// Program.cs evaluates its runtime-profile and development-identity guards in
    /// top-level statements, which execute inside WebApplication.CreateBuilder before
    /// WebApplicationFactory applies ConfigureAppConfiguration / UseEnvironment to the
    /// deferred host builder. Environment variables are the only configuration source
    /// those guards can observe, so the harness sets them here. This reproduces the
    /// Simulation development profile from infrastructure/compose.yaml; it does not
    /// relax or bypass any fail-closed check.
    /// </summary>
    static CinerionApiFactory()
    {
        Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
        Environment.SetEnvironmentVariable("CINERION_RUNTIME_PROFILE", "Simulation");
        Environment.SetEnvironmentVariable("CINERION_ALLOW_DEVELOPMENT_IDENTITY", "true");
        // The simulated telemetry source writes continuously, which would make alarm
        // assertions depend on when a test happened to run. Tests state their own
        // readings through the same ingestion path instead.
        Environment.SetEnvironmentVariable("CINERION_SIMULATED_TELEMETRY", "false");
        // TOTP enrolment seals the seed before storing it and refuses outright when no
        // key is configured, which is the intended fail-closed behaviour and is asserted
        // separately. A key is generated here so the enrolment path itself can be
        // exercised; it is 32 random bytes drawn at host start, never a fixed value, and
        // it exists only for the lifetime of the test process.
        Environment.SetEnvironmentVariable(
            "CINERION_CREDENTIAL_ENCRYPTION_KEY",
            Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32)));
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder) =>
        builder.UseEnvironment("Development");
}
