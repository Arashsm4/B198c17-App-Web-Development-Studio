// Parses every SQL statement we send against a real server, so a typo fails here and not in
// production.

using System.Text.RegularExpressions;
using Cinerion.Infrastructure.Persistence;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// Parses every SQL statement this repository issues against a real PostgreSQL server.
/// <para>
/// A statement that declares a parameter it never references fails at parse time with
/// <c>42P18 could not determine data type of parameter</c>, because PostgreSQL infers a
/// parameter's type from where it is used. That is a runtime 500 on a path the ordinary
/// suite cannot see, since those tests run on the in-memory store: the update branch of
/// <c>SaveCommandAsync</c> carried this defect and every command state transition on
/// PostgreSQL failed because of it.
/// </para>
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set, like the other integration tests.
/// A skipped gate is never reported as passed.
/// </para>
/// </summary>
/// <requirements>CH1-DBA-FR-0001, CH1-NFR-MNT-0001</requirements>
public sealed partial class PostgresStatementShapeTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    /// <summary>Matches a positional parameter reference such as <c>$12</c>.</summary>
    [GeneratedRegex(@"\$(\d+)")]
    private static partial Regex ParameterReference { get; }

    /// <summary>
    /// Reads every SQL literal the store assigns to a command, by reflecting over the
    /// source rather than duplicating it here, so a statement added later is covered
    /// without anyone remembering to add it.
    /// </summary>
    private static IEnumerable<(string Name, string Sql)> Statements()
    {
        var root = new DirectoryInfo(AppContext.BaseDirectory);
        while (root is not null && !Directory.Exists(Path.Combine(root.FullName, "docs", "baseline")))
        {
            root = root.Parent;
        }

        var persistence = Path.Combine(
            root!.FullName, "services/control-core/src/Cinerion.Infrastructure/Persistence");
        foreach (var file in Directory.GetFiles(persistence, "PostgresCinerionStore*.cs"))
        {
            var text = File.ReadAllText(file);
            var index = 0;
            foreach (var match in RawStringLiteral.Matches(text).Cast<Match>())
            {
                var sql = match.Groups[1].Value;
                if (!sql.Contains('$', StringComparison.Ordinal))
                {
                    continue;
                }

                yield return ($"{Path.GetFileName(file)}#{++index}", sql);
            }
        }
    }

    [GeneratedRegex("\"\"\"(.*?)\"\"\"", RegexOptions.Singleline)]
    private static partial Regex RawStringLiteral { get; }

    /// <summary>
    /// Every statement must reference a contiguous run of parameters starting at $1.
    /// A gap means a declared parameter is never used, which PostgreSQL refuses.
    /// </summary>
    [Fact]
    public void EveryStatementReferencesAContiguousParameterRun()
    {
        var gaps = new List<string>();
        foreach (var (name, sql) in Statements())
        {
            var used = ParameterReference.Matches(sql)
                .Select(match => int.Parse(match.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture))
                .ToHashSet();
            if (used.Count == 0)
            {
                continue;
            }

            var highest = used.Max();
            var missing = Enumerable.Range(1, highest).Where(index => !used.Contains(index)).ToArray();
            if (missing.Length > 0)
            {
                gaps.Add($"{name}: declares up to ${highest} but never references ${string.Join(", $", missing)}");
            }
        }

        Assert.True(gaps.Count == 0, string.Join(Environment.NewLine, gaps));
    }

    /// <summary>
    /// The same check, made by the server rather than by inspection: PostgreSQL parses
    /// each statement and reports any parameter whose type it cannot infer.
    /// </summary>
    [Fact]
    public async Task PostgresParsesEveryStatementThisStoreIssues()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");

        var scope = new ProjectScope();
        scope.Set(Guid.NewGuid());
        await using var source = new CinerionDataSource(ConnectionString!, scope);
        await using var connection = await source.OpenAsync(TestContext.Current.CancellationToken);

        var failures = new List<string>();
        var index = 0;
        foreach (var (name, sql) in Statements())
        {
            // PREPARE cannot carry a leading CTE-free fragment, and the projections in
            // this store are concatenated with their WHERE clause at the call site, so
            // only complete statements are checked.
            if (!sql.TrimStart().StartsWith("INSERT", StringComparison.OrdinalIgnoreCase) &&
                !sql.TrimStart().StartsWith("UPDATE", StringComparison.OrdinalIgnoreCase) &&
                !sql.TrimStart().StartsWith("DELETE", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var statementName = $"shape_probe_{++index}";
            await using var command = connection.CreateCommand();
            command.CommandText = $"PREPARE {statementName} AS {sql}";
            try
            {
                await command.ExecuteNonQueryAsync(TestContext.Current.CancellationToken);
                await using var deallocate = connection.CreateCommand();
                deallocate.CommandText = $"DEALLOCATE {statementName}";
                await deallocate.ExecuteNonQueryAsync(TestContext.Current.CancellationToken);
            }
            catch (PostgresException error)
            {
                failures.Add($"{name}: {error.SqlState} {error.MessageText}");
            }
        }

        Assert.True(failures.Count == 0, string.Join(Environment.NewLine, failures));
    }

    /// <summary>
    /// Guards the reflection itself. If the store were renamed or moved, both checks
    /// above would silently pass over nothing.
    /// </summary>
    [Fact]
    public void TheStatementsAreActuallyBeingFound()
    {
        var found = Statements().ToArray();

        Assert.True(found.Length >= 20, $"Expected the store's statements; found {found.Length}.");
        Assert.Contains(found, item => item.Sql.Contains("ch1.command_transactions", StringComparison.Ordinal));
        Assert.Contains(found, item => item.Sql.Contains("ch1.resource_allocations", StringComparison.Ordinal));
    }
}
