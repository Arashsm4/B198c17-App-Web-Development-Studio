// A pretend identity provider for tests, so the happy paths can run at all.

using Cinerion.Application.Identity;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// A configured identity provider, so the success path of the identity operations can be
/// executed at all.
/// </summary>
/// <remarks>
/// <para>
/// The ordinary test host runs with <c>UnconfiguredIdentityDirectory</c> on purpose: an
/// unconfigured directory must refuse rather than answer a security question with
/// invented data, and <see cref="IdentityAdministrationEndpointTests"/> exists to hold
/// exactly that. The cost was that nothing ever exercised what these operations do when a
/// provider *is* present — the live-Keycloak evidence was produced by hand.
/// </para>
/// <para>
/// This replaces the provider and nothing else. Authority, self-versus-administrator
/// ownership, the project-bounded session lookup and the audit event are decided by
/// <c>IdentityAdministrationService</c> in every case, so what a test using this stub
/// observes is the service's own behaviour rather than the stub's. It is registered for
/// one host at a time and never for the shared one.
/// </para>
/// </remarks>
internal sealed class StubIdentityDirectory : IIdentityDirectory
{
    private readonly HashSet<string> _revoked = new(StringComparer.Ordinal);

    public bool IsConfigured => true;

    public string ProviderDescription => "Stub directory (tests only)";

    /// <summary>
    /// Sessions this directory knows about. The key is the session identifier the
    /// development identity scheme derives from <c>X-CH1-Session</c>, so a caller's own
    /// session is findable and anybody else's belongs to a different user.
    /// </summary>
    private static IdentitySession? Known(string sessionId) => sessionId switch
    {
        "session-USR-CONTRACT-SESSION" => new IdentitySession(
            sessionId,
            "USR-CONTRACT-SESSION",
            "ch1-contract-demo",
            "cinerion-operator-portal",
            DateTimeOffset.UtcNow.AddMinutes(-20),
            DateTimeOffset.UtcNow.AddMinutes(-1)),
        "session-someone-else" => new IdentitySession(
            sessionId,
            "USR-SOMEONE-ELSE",
            "ch1-other-demo",
            "cinerion-operator-portal",
            DateTimeOffset.UtcNow.AddMinutes(-40),
            DateTimeOffset.UtcNow.AddMinutes(-2)),
        _ => null,
    };

    public ValueTask<UserPage> ListUsersAsync(UserQuery query, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<IdentityUser> users =
        [
            new IdentityUser(
                "USR-CONTRACT-SESSION",
                "ch1-contract-demo",
                "Contract fixture identity",
                true,
                query.ProjectId,
                [PrototypeSeed.Ids.CellId],
                ["Viewer"],
                ActorKind.Human,
                DateTimeOffset.UtcNow.AddDays(-1)),
        ];
        return ValueTask.FromResult(new UserPage(users, false, 0));
    }

    public ValueTask<IdentityUser?> FindUserAsync(string userId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IdentityUser? user = userId == "USR-CONTRACT-SESSION"
            ? new IdentityUser(
                userId,
                "ch1-contract-demo",
                "Contract fixture identity",
                true,
                PrototypeSeed.Ids.ProjectId,
                [PrototypeSeed.Ids.CellId],
                ["Viewer"],
                ActorKind.Human,
                DateTimeOffset.UtcNow.AddDays(-1))
            : null;
        return ValueTask.FromResult(user);
    }

    public ValueTask ReplaceControlledRolesAsync(
        string userId, IReadOnlyList<string> roles, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.CompletedTask;
    }

    public ValueTask<IdentitySession?> FindSessionAsync(
        Guid projectId, string sessionId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // A revoked session is gone, so a second revocation reports not found rather
        // than succeeding twice — the same answer a provider gives.
        return ValueTask.FromResult(_revoked.Contains(sessionId) ? null : Known(sessionId));
    }

    public ValueTask<bool> RevokeSessionAsync(string sessionId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (Known(sessionId) is null || !_revoked.Add(sessionId)) return ValueTask.FromResult(false);
        return ValueTask.FromResult(true);
    }
}
