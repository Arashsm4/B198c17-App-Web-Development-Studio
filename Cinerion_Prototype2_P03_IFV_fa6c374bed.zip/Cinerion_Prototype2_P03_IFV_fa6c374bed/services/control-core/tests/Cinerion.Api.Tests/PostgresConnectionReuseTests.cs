// Tests that pooled connections really get reused between requests.

using Cinerion.Infrastructure.Persistence;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// A pooled connection is only pooled if the pool outlives the request that borrowed it.
/// <para>
/// <see cref="CinerionDataSource"/> is registered per request, because the project scope
/// it applies is per request. If that per-request object also <i>owns</i> its
/// <see cref="NpgsqlDataSource"/>, then every request builds a private pool, opens fresh
/// physical connections into it, and closes them again when the scope ends - so nothing
/// is ever pooled, and the measured 13.3 ms of TCP, startup and authentication is paid on
/// every store call rather than once per backend. PostgreSQL forks a process per session,
/// so the cost lands on the server as well as on the caller.
/// </para>
/// <para>
/// It also makes the connection budget unenforceable: a cap applied to one request's pool
/// says nothing about how many connections a hundred concurrent requests may open between
/// them, which is precisely the number <c>max_connections</c> governs.
/// </para>
/// <para>
/// These tests measure sessions rather than reasoning about lifetimes, because a lifetime
/// is a declaration and a session is a fact. <c>pg_backend_pid()</c> names the server
/// process actually serving a connection: reusing a pooled connection returns the same
/// pid, and opening a new physical one cannot.
/// </para>
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set, on the same terms as the other
/// PostgreSQL tests: a skipped gate is never reported as passed.
/// </para>
/// <para>
/// These claim <b>no controlled verification case</b>, for the same reason
/// <see cref="PostgresConnectionBudgetTests"/> claims none: CH1-VVT-TC-0090 is the load
/// requirement itself, and binding a defect found while investigating it to the case it
/// failed would overstate what has been verified.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-PER-0001, CH1-DBA-FR-0001</requirements>
public sealed class PostgresConnectionReuseTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    /// <summary>How many request scopes each measurement simulates.</summary>
    private const int Requests = 12;

    private static async Task<int> BackendPidAsync(NpgsqlConnection connection, CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT pg_backend_pid()";
        return Convert.ToInt32(
            await command.ExecuteScalarAsync(cancellationToken),
            System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// The property the fix exists for: request scopes share one pool, so a sequential
    /// run of requests is served by the backend the first one opened.
    /// </summary>
    [Fact]
    public async Task Ch1NfrPer0001_RequestScopesShareOnePoolAndReuseItsConnections()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;

        await using var pool = new CinerionConnectionPool(ConnectionString!);
        var pids = new HashSet<int>();

        for (var request = 0; request < Requests; request++)
        {
            // Exactly what the container does per request: a new scope, a new wrapper,
            // disposed at the end of the request.
            var scope = new ProjectScope();
            await using var perRequest = new CinerionDataSource(pool, scope);
            await using (var connection = await perRequest.OpenAsync(cancellationToken))
            {
                pids.Add(await BackendPidAsync(connection, cancellationToken));
            }
        }

        Assert.True(
            pids.Count == 1,
            $"{Requests} sequential request scopes were served by {pids.Count} distinct backend " +
            "processes; a shared pool serves them all from one, so the pool is not being shared.");
    }

    /// <summary>
    /// The measurement is capable of failing, which is the only reason to trust the one
    /// above.
    /// </summary>
    /// <remarks>
    /// This is the defect, reproduced: a data source built per request owns its pool, and
    /// disposing the request disposes the pool with it. If this ever stops producing a
    /// fresh backend per request, the test above has stopped proving anything and this
    /// one says so first.
    /// </remarks>
    [Fact]
    public async Task Ch1NfrPer0001_APoolOwnedByTheRequestOpensAFreshBackendEveryTime()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;

        var pids = new HashSet<int>();
        for (var request = 0; request < Requests; request++)
        {
            var scope = new ProjectScope();
            await using var perRequest = new CinerionDataSource(ConnectionString!, scope);
            await using (var connection = await perRequest.OpenAsync(cancellationToken))
            {
                pids.Add(await BackendPidAsync(connection, cancellationToken));
            }
        }

        Assert.True(
            pids.Count == Requests,
            $"{Requests} request-owned pools produced only {pids.Count} distinct backends; " +
            "the reuse measurement above cannot distinguish a shared pool from a private one.");
    }

    /// <summary>
    /// A request scope must not take the shared pool down with it when it ends.
    /// </summary>
    [Fact]
    public async Task Ch1NfrPer0001_DisposingARequestScopeLeavesTheSharedPoolUsable()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;

        await using var pool = new CinerionConnectionPool(ConnectionString!);

        int firstPid;
        await using (var first = new CinerionDataSource(pool, new ProjectScope()))
        await using (var connection = await first.OpenAsync(cancellationToken))
        {
            firstPid = await BackendPidAsync(connection, cancellationToken);
        }

        await using var second = new CinerionDataSource(pool, new ProjectScope());
        await using var reused = await second.OpenAsync(cancellationToken);

        Assert.Equal(firstPid, await BackendPidAsync(reused, cancellationToken));
    }

    /// <summary>
    /// Sharing the pool must not share the project scope, which is the reason the wrapper
    /// is per request in the first place.
    /// </summary>
    /// <remarks>
    /// Row-level security reads <c>ch1.project_id</c> from the session, and a pooled
    /// connection carries whatever the previous borrower left on it. The scope is
    /// therefore applied on every open rather than on every physical connect - this
    /// asserts that a connection recycled from the pool answers with the new borrower's
    /// project and not the previous one's.
    /// </remarks>
    [Fact]
    public async Task Ch1CybFr0001_ARecycledConnectionCarriesTheNewRequestsProjectScope()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;

        await using var pool = new CinerionConnectionPool(ConnectionString!);
        var first = Guid.NewGuid();
        var second = Guid.NewGuid();

        int pid;
        var firstScope = new ProjectScope();
        firstScope.Set(first);
        await using (var owner = new CinerionDataSource(pool, firstScope))
        await using (var connection = await owner.OpenAsync(cancellationToken))
        {
            pid = await BackendPidAsync(connection, cancellationToken);
            Assert.Equal(first.ToString(), await CurrentProjectAsync(connection, cancellationToken));
        }

        var secondScope = new ProjectScope();
        secondScope.Set(second);
        await using var next = new CinerionDataSource(pool, secondScope);
        await using var recycled = await next.OpenAsync(cancellationToken);

        Assert.Equal(pid, await BackendPidAsync(recycled, cancellationToken));
        Assert.Equal(second.ToString(), await CurrentProjectAsync(recycled, cancellationToken));
    }

    private static async Task<string> CurrentProjectAsync(
        NpgsqlConnection connection,
        CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT current_setting('ch1.project_id', true)";
        var value = await command.ExecuteScalarAsync(cancellationToken);
        return value as string ?? string.Empty;
    }
}
