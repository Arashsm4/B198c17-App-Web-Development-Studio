// Tests that every role change gets written down when it happens.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Application.Abstractions;
using Cinerion.Application.Identity;
using Cinerion.Infrastructure.Seed;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Cinerion.Api.Tests;

/// <summary>
/// The controlled record of a role change, written when the change is made.
/// <para>
/// entities.json declares RoleAssignment with its own identifier, a Security Sensitive
/// classification and a seven-year retention, and no table existed for it: a role change
/// was evidenced only by <c>ch1.audit_events</c>, which stores a payload <i>hash</i>. The
/// history was therefore verifiable and not readable - an auditor could prove an event had
/// not been altered while being unable to say what it recorded. Migration 0012 adds the
/// table the register declares.
/// </para>
/// <para>
/// These run over HTTP through the real endpoint and service, with only the identity
/// provider replaced, so what is asserted is the platform's behaviour rather than a
/// stub's.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0006, CH1-TRC-FR-0002</requirements>
public sealed class RoleAssignmentHistoryTests(CinerionApiFactory factory)
    : IClassFixture<CinerionApiFactory>
{
    private const string Subject = "USR-CONTRACT-SESSION";
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;

    private WebApplicationFactory<Program> Configured() =>
        factory.WithWebHostBuilder(builder => builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IIdentityDirectory>();
            services.AddSingleton<IIdentityDirectory>(new StubIdentityDirectory());
        }));

    private static HttpClient Administrator(WebApplicationFactory<Program> host)
    {
        var client = host.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-SYSADMIN-HISTORY");
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "SystemAdministrator");
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "StepUpPhishingResistant");
        client.DefaultRequestHeaders.Add("X-CH1-Session", "session-USR-SYSADMIN-HISTORY");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private static async Task<string> StepUpAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "RoleAssignment" }, cancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("grantId").GetGuid().ToString();
    }

    private static async Task<HttpResponseMessage> ReplaceRolesAsync(
        HttpClient client,
        string[] roles,
        CancellationToken cancellationToken)
    {
        var grant = await StepUpAsync(client, cancellationToken);
        using var request = new HttpRequestMessage(
            HttpMethod.Put, $"/api/v1/users/{Subject}/roles")
        {
            Content = JsonContent.Create(new { Roles = roles }),
        };
        request.Headers.Add("X-CH1-Step-Up", grant);
        return await client.SendAsync(request, cancellationToken);
    }

    /// <summary>
    /// The change is recorded, in full: what was held before, what is held now, and both
    /// halves of the difference.
    /// </summary>
    [Fact]
    public async Task Ch1IamFr0004_AChangeOfRolesIsRecordedAsAReadableRecord()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var host = Configured();
        using var administrator = Administrator(host);

        using var response = await ReplaceRolesAsync(
            administrator, ["Viewer", "Inspector"], cancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var store = host.Services.GetRequiredService<ICinerionStore>();
        var history = await store.ListRoleAssignmentsAsync(ProjectId, Subject, 10, cancellationToken);

        var recorded = Assert.Single(
            history,
            entry => entry.CurrentRoles.Contains("Inspector", StringComparer.Ordinal));
        Assert.Equal(Subject, recorded.SubjectUserId);
        Assert.Equal("ch1-contract-demo", recorded.SubjectUsername);
        Assert.Equal("USR-SYSADMIN-HISTORY", recorded.AssignedBy);
        Assert.Equal(["Viewer"], recorded.PreviousRoles);
        Assert.Equal(["Viewer", "Inspector"], recorded.CurrentRoles);
        Assert.Equal(["Inspector"], recorded.GrantedRoles);
        Assert.Empty(recorded.WithdrawnRoles);

        // The provider the change was actually applied to, so the row cannot be read as
        // evidence about a directory it never reached.
        Assert.Equal("Stub directory (tests only)", recorded.Provider);

        // The declared retention, carried on the row rather than left in a policy
        // document. entities.json says seven years.
        Assert.Equal(recorded.AssignedAt.AddYears(7), recorded.RetainUntil);
    }

    /// <summary>
    /// A request that changes nothing writes nothing. A permanent register whose rows
    /// evidence no event is a register nobody can read.
    /// </summary>
    [Fact]
    public async Task Ch1IamFr0004_ARequestThatGrantsAndWithdrawsNothingRecordsNothing()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var host = Configured();
        using var administrator = Administrator(host);
        var store = host.Services.GetRequiredService<ICinerionStore>();

        var before = await store.ListRoleAssignmentsAsync(ProjectId, Subject, 200, cancellationToken);

        // The roles the stub already reports for this subject.
        using var response = await ReplaceRolesAsync(administrator, ["Viewer"], cancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var after = await store.ListRoleAssignmentsAsync(ProjectId, Subject, 200, cancellationToken);
        Assert.Equal(before.Count, after.Count);
    }

    /// <summary>
    /// A refused change records no assignment. The audit chain still carries the attempt -
    /// that is the security event of interest - but the register of who held what must not
    /// gain a row for something that did not happen.
    /// </summary>
    [Fact]
    public async Task Ch1CybAcp0001_ARefusedChangeRecordsNoAssignment()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var host = Configured();
        using var administrator = Administrator(host);
        var store = host.Services.GetRequiredService<ICinerionStore>();

        var before = await store.ListRoleAssignmentsAsync(ProjectId, Subject, 200, cancellationToken);

        // CH1-CYB-ACP-0001: a System Administrator may not grant the cybersecurity
        // authority. RoleSegregation refuses it before it reaches the provider.
        using var response = await ReplaceRolesAsync(
            administrator, ["Viewer", "CybersecurityAdministrator"], cancellationToken);
        Assert.NotEqual(HttpStatusCode.OK, response.StatusCode);

        var after = await store.ListRoleAssignmentsAsync(ProjectId, Subject, 200, cancellationToken);
        Assert.Equal(before.Count, after.Count);
        Assert.DoesNotContain(
            after,
            entry => entry.CurrentRoles.Contains("CybersecurityAdministrator", StringComparer.Ordinal));
    }
}
