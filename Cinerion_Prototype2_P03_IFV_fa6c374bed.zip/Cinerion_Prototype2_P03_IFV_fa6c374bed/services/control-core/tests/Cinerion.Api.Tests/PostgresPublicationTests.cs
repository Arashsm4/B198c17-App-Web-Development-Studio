// The publication pipeline against a real database, then attacked there.

using Cinerion.Domain.Documents;
using Cinerion.Infrastructure.Persistence;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// The publication pipeline against a real database, and then attacked on it.
/// <para>
/// <see cref="PublicationPipelineEndpointTests"/> runs on the in-memory store, so a
/// PostgreSQL-only defect is invisible to it - that is how the SaveCommandAsync parameter
/// defect survived. These exercise the same records through the PostgreSQL store and then
/// attack the guarantees that belong to the schema rather than to the code: the two-review
/// constraint, the immutability of a recorded review, and project isolation.
/// </para>
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set. A skipped gate is never reported as
/// passed.
/// </para>
/// </summary>
/// <requirements>CH1-DOC-FR-0001, CH1-DOC-FR-0004, CH1-CYB-FR-0001</requirements>
public sealed class PostgresPublicationTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    private static async Task<CinerionDataSource> ConnectAsync(
        ProjectScope scope,
        CancellationToken cancellationToken)
    {
        var source = new CinerionDataSource(ConnectionString!, scope);
        var migrations = await Task
            .WhenAll(PostgresRowLevelSecurityTests.MigrationPaths()
                .Select(path => File.ReadAllTextAsync(path, cancellationToken)))
            .ConfigureAwait(false);
        await source.EnsureSchemaAsync(migrations, cancellationToken).ConfigureAwait(false);
        return source;
    }

    private static async Task SeedProjectAsync(
        CinerionDataSource source,
        Guid projectId,
        CancellationToken cancellationToken)
    {
        await using var connection = await source.OpenForProjectAsync(projectId, cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.projects(project_id, project_code, name, baseline, version)
            VALUES($1, $2, 'Publication pipeline test', 'P03/IFV', 1)
            ON CONFLICT (project_id) DO NOTHING
            """;
        command.Parameters.Add(new NpgsqlParameter { Value = projectId });
        command.Parameters.Add(new NpgsqlParameter
        {
            Value = $"CH1-PB{projectId.ToString("N")[..8].ToUpperInvariant()}",
        });
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static PublicationPackage Package(Guid projectId, string content, DateTimeOffset now) =>
        PublicationPackage.Create(
            Guid.CreateVersion7(),
            projectId,
            new RedactionProfile("CH1-DOC-RDP-SHOWCASE", "1.0.0", ["Project Internal"], ["title"]),
            "Round-trip package",
            [new PublicationSource(
                Guid.CreateVersion7(), "CH1-SYS-ARC-0001", "R01", "Project Internal",
                new string('b', 64))],
            content,
            "text/plain; charset=utf-8",
            ["internalReviewer"],
            new Dictionary<string, string>(StringComparer.Ordinal) { ["title"] = "Showcase" },
            PublicationSecretScan.ProfileId,
            PublicationSecretScan.PatternCount,
            "USR-DOCCTRL-PG",
            now);

    /// <summary>
    /// Everything the pipeline recorded survives the round trip - including the two fields
    /// that state what it did NOT do.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_APackageRoundTripsThroughPostgreSql()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var package = Package(project, "A redacted summary for PostgreSQL.", DateTimeOffset.UtcNow);
        await store.SavePublicationPackageAsync(package, cancellationToken);

        var stored = await store.FindPublicationPackageAsync(package.PackageId, cancellationToken);
        Assert.NotNull(stored);
        Assert.Equal(package.ContentSha256, stored!.ContentSha256);
        Assert.Equal(PublicationState.PendingApproval, stored.State);
        Assert.Equal(["internalReviewer"], stored.MetadataRemoved);
        Assert.Equal("Showcase", stored.MetadataRetained["title"]);
        Assert.Single(stored.Sources);
        Assert.False(stored.ContentDiffPerformed);
        Assert.Contains("NOT performed", stored.ContentDiffNote, StringComparison.Ordinal);
        Assert.Null(stored.DecidedAt);
    }

    /// <summary>
    /// The two-review constraint is the schema's, not the service's: a second decision from
    /// the same capacity is refused by the database whatever the code above it does.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_TheDatabaseRefusesASecondDecisionFromOneCapacity()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var package = Package(project, "A package awaiting two reviews.", DateTimeOffset.UtcNow);
        await store.SavePublicationPackageAsync(package, cancellationToken);

        var first = PublicationApproval.Record(
            Guid.CreateVersion7(), package, ReviewerCapacity.ProjectOwner, true,
            "USR-OWNER-PG", "ProjectOwner", package.ContentSha256, "Read in full.",
            [], DateTimeOffset.UtcNow);
        await store.SavePublicationApprovalAsync(first, cancellationToken);

        // Straight at the store, bypassing the domain guard that would also refuse it. The
        // question here is whether the DATABASE refuses, because that is the guarantee that
        // survives a defect in the layer above.
        var second = first with
        {
            ApprovalId = Guid.CreateVersion7(),
            ReviewedBy = "USR-SOMEBODY-ELSE",
        };
        var error = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await store.SavePublicationApprovalAsync(second, cancellationToken));
        Assert.Equal("PUBLICATION_CAPACITY_ALREADY_REVIEWED", error.Code);
    }

    /// <summary>A recorded review cannot be edited or removed afterwards.</summary>
    [Fact]
    public async Task Ch1DocFr0004_ARecordedReviewIsBeyondTheApplicationsReach()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var package = Package(project, "A package with a dissenting review.", DateTimeOffset.UtcNow);
        await store.SavePublicationPackageAsync(package, cancellationToken);

        var rejection = PublicationApproval.Record(
            Guid.CreateVersion7(), package, ReviewerCapacity.DocumentControl, approved: false,
            "USR-DOCCTRL-PG2", "DocumentControl", package.ContentSha256,
            "Names an internal supplier.", [], DateTimeOffset.UtcNow);
        await store.SavePublicationApprovalAsync(rejection, cancellationToken);

        await using var connection = await source.OpenForProjectAsync(project, cancellationToken);

        // Turning a rejection into an approval, and removing it altogether, are the two
        // ways a package could reach publication with its dissent gone.
        await AssertRefusedAsync(
            connection,
            "UPDATE ch1.publication_package_approvals SET decision = 'Approved' WHERE approval_id = $1",
            rejection.ApprovalId, cancellationToken);
        await AssertRefusedAsync(
            connection,
            "DELETE FROM ch1.publication_package_approvals WHERE approval_id = $1",
            rejection.ApprovalId, cancellationToken);
    }

    /// <summary>
    /// A package cannot be deleted either. A published derivative whose record could be
    /// removed would leave an artefact in the world with nothing saying what approved it.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_APackageCannotBeDeletedByTheApplication()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var package = Package(project, "A package nobody may erase.", DateTimeOffset.UtcNow);
        await store.SavePublicationPackageAsync(package, cancellationToken);

        await using var connection = await source.OpenForProjectAsync(project, cancellationToken);
        await AssertRefusedAsync(
            connection, "DELETE FROM ch1.publication_packages WHERE package_id = $1",
            package.PackageId, cancellationToken);
    }

    /// <summary>
    /// A pending package with a decision time, or a decided one without, is half a state.
    /// The database refuses both.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_AHalfExpressedStateIsRefused()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var package = Package(project, "A package about to be given an impossible state.", DateTimeOffset.UtcNow);
        await store.SavePublicationPackageAsync(package, cancellationToken);

        await using var connection = await source.OpenForProjectAsync(project, cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText =
            "UPDATE ch1.publication_packages SET decided_at = now() WHERE package_id = $1";
        command.Parameters.Add(new NpgsqlParameter { Value = package.PackageId });

        var error = await Assert.ThrowsAsync<PostgresException>(
            async () => await command.ExecuteNonQueryAsync(cancellationToken));
        Assert.Equal(PostgresErrorCodes.CheckViolation, error.SqlState);
    }

    /// <summary>One project's publication work is not another's to read.</summary>
    [Fact]
    public async Task Ch1CybFr0001_APackageIsInvisibleOutsideItsProject()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var mine = Guid.NewGuid();
        var theirs = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(mine);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, mine, cancellationToken);
        await SeedProjectAsync(source, theirs, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var package = Package(mine, "A package belonging to one project.", DateTimeOffset.UtcNow);
        await store.SavePublicationPackageAsync(package, cancellationToken);

        Assert.NotNull(await store.FindPublicationPackageAsync(package.PackageId, cancellationToken));

        scope.Set(theirs);
        Assert.Null(await store.FindPublicationPackageAsync(package.PackageId, cancellationToken));
    }

    /// <summary>The controlled document register reads back what CH1-DOC-FR-0001 requires.</summary>
    [Fact]
    public async Task Ch1DocFr0001_TheControlledDocumentRegisterRoundTrips()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var document = new ControlledDocumentRecord(
            Guid.CreateVersion7(), project, "CH1-QMS-PRO-0004", "R01", "IFV", "Controlled",
            new string('c', 64), "cinerion://documents/test", null, DateTimeOffset.UtcNow);
        await store.SaveControlledDocumentAsync(document, cancellationToken);

        var stored = await store.FindControlledDocumentAsync(document.DocumentId, cancellationToken);
        Assert.NotNull(stored);
        Assert.Equal("CH1-QMS-PRO-0004", stored!.DocumentNumber);
        Assert.Equal("Controlled", stored.Classification);
        Assert.Equal(document.ContentSha256, stored.ContentSha256);

        // No wrapped key, and none invented. Resolving one would be CH1-DOC-FR-0002.
        Assert.Null(stored.WrappedKeyReference);
    }

    private static async Task AssertRefusedAsync(
        NpgsqlConnection connection,
        string sql,
        Guid id,
        CancellationToken cancellationToken)
    {
        var error = await Assert.ThrowsAsync<PostgresException>(async () =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = sql;
            command.Parameters.Add(new NpgsqlParameter { Value = id });
            await command.ExecuteNonQueryAsync(cancellationToken);
        });

        Assert.True(
            error.MessageText.Contains("immutable", StringComparison.OrdinalIgnoreCase)
            || error.SqlState == PostgresErrorCodes.InsufficientPrivilege,
            $"'{sql}' was refused with '{error.SqlState}: {error.MessageText}', which is " +
            "neither the immutability trigger nor a missing privilege");
    }
}
