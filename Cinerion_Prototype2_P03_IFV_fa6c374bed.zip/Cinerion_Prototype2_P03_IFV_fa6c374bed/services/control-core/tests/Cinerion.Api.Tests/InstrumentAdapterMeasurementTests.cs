// Tests for an instrument adapter adding its own readings, and all the things it still can't
// do.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// A bound instrument adapter appending a measurement, and everything it still may not do.
/// <para>
/// <c>api_endpoints.json</c> gives <c>POST /test-runs/{testRunId}/measurements</c> to
/// "Bound instrument adapter or Test Engineer". Only the second half was implemented:
/// every measurement went through an authorisation that refuses any actor which is not
/// <c>Human</c>, so the controlled document named a capability this platform did not have
/// and an automatic quality-check machine could not put a result into the system at all.
/// Recorded as a conflict and resolved in favour of the controlled document.
/// </para>
/// <para>
/// These tests are mostly about the refusals, because widening who may write controlled
/// acceptance evidence is only safe if what was widened is exactly one thing. An adapter
/// may append a reading its own instrument produced, and nothing else: it cannot attribute
/// a reading to another instrument, cannot use an instrument whose calibration has lapsed,
/// cannot raise a nonconformity, cannot decide a disposition and cannot release a part.
/// </para>
/// </summary>
/// <requirements>CH1-QMS-FR-0002, CH1-QMS-FR-0006, CH1-IAM-FR-0008</requirements>
public sealed class InstrumentAdapterMeasurementTests(CinerionApiFactory factory)
    : IClassFixture<CinerionApiFactory>
{
    private const string Project = "00000000-0000-4000-8000-000000000101";
    private const string Cell = "00000000-0000-4000-8000-000000000103";
    private const string Part = "00000000-0000-4000-8000-000000000106";
    private const string Calibration = "00000000-0000-4000-8000-000000000108";

    /// <summary>The instrument the seeded calibration certificate actually covers.</summary>
    private const string Instrument = "CH1-INS-THK-0001";

    /// <summary>
    /// A device actor, as the mutual-TLS listener resolves one.
    /// <para>
    /// The development identity handler is standing in for the certificate here and for
    /// nothing else: every claim below is one
    /// <c>DeviceCertificateAuthenticationHandler</c> derives from the ENROLLED device
    /// record rather than from the request, so what these tests exercise is the
    /// authorisation that follows, not the authentication that precedes it.
    /// <c>scripts/check-local-commit-loop.sh</c> exercises the real certificate path.
    /// </para>
    /// </summary>
    private HttpClient Adapter(string instrumentId = Instrument)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", instrumentId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "DeviceController");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Actor-Kind", "Device");
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "MutualTls");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"mtls-{instrumentId}");
        return client;
    }

    private HttpClient Inspector(string actor)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actor);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Inspector");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "StepUpPhishingResistant");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actor}");
        return client;
    }

    /// <summary>
    /// The run is opened by an INSPECTOR, deliberately.
    /// <para>
    /// <c>POST /api/v1/test-runs</c> is authorised to "Inspector or Test Engineer" and the
    /// adapter half belongs to the measurement operation alone. So a machine appends
    /// results to a run a person opened against a controlled procedure revision, which is
    /// what CH1-QMS-FR-0001 describes: the procedure defines the steps, the instruments,
    /// the limits and the acceptance authority.
    /// </para>
    /// </summary>
    private async Task<Guid> OpenRunAsync(string actor)
    {
        using var client = Inspector(actor);
        using var response = await client.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.GetProperty("testRunId").GetGuid();
    }

    private static Task<HttpResponseMessage> MeasureAsync(
        HttpClient client,
        Guid runId,
        string characteristic,
        decimal value,
        string sourceDeviceId = Instrument,
        string calibrationRecordId = Calibration) =>
        client.PostAsJsonAsync(
            $"/api/v1/test-runs/{runId}/measurements",
            new
            {
                PartId = Part,
                Characteristic = characteristic,
                Value = value,
                Unit = "um",
                LowerLimit = 9.50m,
                UpperLimit = 10.50m,
                Mandatory = true,
                SourceDeviceId = sourceDeviceId,
                CalibrationRecordId = calibrationRecordId,
                // Sent and deliberately ignored: CH1-QMS-FR-0006 is decided from the stored
                // certificate, not from a boolean the caller asserts about itself.
                CalibrationValid = true,
                SupersedesMeasurementId = (Guid?)null,
            },
            TestContext.Current.CancellationToken);

    private static async Task<string> CodeOf(HttpResponseMessage response)
    {
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.TryGetProperty("code", out var code) ? code.GetString() ?? string.Empty : string.Empty;
    }

    [Fact]
    public async Task Ch1QmsFr0002_ABoundInstrumentAdapterAppendsItsOwnReading()
    {
        var runId = await OpenRunAsync("USR-INSPECTOR-ADAPTER-01");
        using var adapter = Adapter();

        using var response = await MeasureAsync(adapter, runId, "Coating thickness", 10.10m);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var measurement = body.GetProperty("measurement");

        // CH1-QMS-FR-0002: the value retains its unit, its source device and its
        // calibration context. A machine-fed result is evidence on the same terms as a
        // hand-entered one or it is not evidence.
        Assert.Equal("um", measurement.GetProperty("unit").GetString());
        Assert.Equal(Instrument, measurement.GetProperty("sourceDeviceId").GetString());
        Assert.Equal(Calibration, measurement.GetProperty("calibrationRecordId").GetString());
        Assert.Equal("Pass", measurement.GetProperty("result").GetString());
    }

    [Fact]
    public async Task Ch1QmsFr0002_AnAdapterCannotAttributeAReadingToAnotherInstrument()
    {
        var runId = await OpenRunAsync("USR-INSPECTOR-ADAPTER-02");
        // The adapter IS CH1-INS-THK-0001 and claims the reading came from another
        // instrument. This is the one failure mode machine-fed evidence has that
        // hand-entered evidence does not: a value attributed to equipment that did not
        // produce it, with a calibration certificate that is perfectly valid for it.
        using var adapter = Adapter();

        using var response = await MeasureAsync(
            adapter,
            runId,
            "Coating thickness",
            10.10m,
            sourceDeviceId: "CH1-INS-THK-9999");

        // 403 rather than 400: EndpointResults maps every AUTH_ code to Forbidden, and
        // this is an authorisation refusal rather than a malformed request.
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_INSTRUMENT_NOT_ITS_OWN_READING", await CodeOf(response));
    }

    [Fact]
    public async Task Ch1QmsFr0006_AnAdapterIsStillRefusedByTheCalibrationRecord()
    {
        var runId = await OpenRunAsync("USR-INSPECTOR-ADAPTER-03");
        // An instrument reporting its own reading, and a calibration record that does not
        // exist. The certificate is what decides admissibility, and no amount of device
        // identity substitutes for one.
        using var adapter = Adapter();

        using var response = await MeasureAsync(
            adapter,
            runId,
            "Coating thickness",
            10.10m,
            calibrationRecordId: "00000000-0000-4000-8000-0000000009ff");

        // 404, and deliberately the same answer a record in another project gets: a
        // caller must not be able to tell "no such certificate" from "not yours".
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.Equal("CALIBRATION_RECORD_NOT_FOUND", await CodeOf(response));
    }

    [Fact]
    public async Task Ch1CybAcp0001_AnAdapterCannotRaiseANonconformity()
    {
        using var adapter = Adapter();

        using var response = await adapter.PostAsJsonAsync(
            "/api/v1/ncrs",
            new { PartId = Part, Title = "Machine-raised", Description = "A machine deciding a part is nonconforming." },
            TestContext.Current.CancellationToken);

        // The measurement authority was widened and nothing else was. Raising a
        // nonconformity is authorised to "Inspector or Engineer", both human roles, and a
        // device meets neither.
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_HUMAN_REQUIRED", await CodeOf(response));
    }

    [Fact]
    public async Task Ch1CybAcp0001_AnAdapterCannotReleaseAPart()
    {
        using var adapter = Adapter();

        using var response = await adapter.PostAsJsonAsync(
            "/api/v1/release-records",
            new { PartId = Part, Statement = "Machine-released" },
            TestContext.Current.CancellationToken);

        // Independent release is the Inspector's and is behind a step-up. A machine holds
        // no step-up and is not independent of the operation that produced the part.
        Assert.True(
            response.StatusCode is HttpStatusCode.BadRequest or HttpStatusCode.Forbidden,
            $"a device released a part with {(int)response.StatusCode}");
    }

    [Fact]
    public async Task Ch1IamFr0008_AHumanWithoutAnInspectionRoleIsStillRefused()
    {
        var runId = await OpenRunAsync("USR-INSPECTOR-ADAPTER-04");
        // The adapter path must not have become a route around the human one. A Viewer is
        // a human, holds no inspection role, and is refused exactly as before - the new
        // branch is reached only by a device identity.
        using var viewer = factory.CreateClient();
        viewer.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-VIEWER-ADAPTER");
        viewer.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        viewer.DefaultRequestHeaders.Add("X-CH1-Roles", "Viewer");
        viewer.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        viewer.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        viewer.DefaultRequestHeaders.Add("X-CH1-Session", "session-viewer-adapter");

        using var response = await MeasureAsync(viewer, runId, "Coating thickness", 10.10m);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_INSPECTION_ROLE_REQUIRED", await CodeOf(response));
    }

    [Fact]
    public async Task Ch1IamFr0008_ADeviceOutsideTheProjectIsRefusedAsAnyOtherActorIs()
    {
        var runId = await OpenRunAsync("USR-INSPECTOR-ADAPTER-05");
        // A device identity scoped to another project. It falls through to the human
        // authorisation - which is the correct direction, because being a device in the
        // wrong project is not being a bound adapter - and is refused there.
        using var stranger = factory.CreateClient();
        stranger.DefaultRequestHeaders.Add("X-CH1-Actor", Instrument);
        stranger.DefaultRequestHeaders.Add("X-CH1-Project", "00000000-0000-4000-8000-0000000002ff");
        stranger.DefaultRequestHeaders.Add("X-CH1-Roles", "DeviceController");
        stranger.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        stranger.DefaultRequestHeaders.Add("X-CH1-Actor-Kind", "Device");
        stranger.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "MutualTls");
        stranger.DefaultRequestHeaders.Add("X-CH1-Session", "mtls-stranger");

        using var response = await MeasureAsync(stranger, runId, "Coating thickness", 10.10m);

        Assert.True(
            response.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.NotFound,
            $"a device from another project appended a measurement with {(int)response.StatusCode}");
        // Which refusal it meets depends on whether row-level security hid the part first
        // or the authorisation caught it, and BOTH are correct answers - so the test
        // asserts that it was refused and does not pin which control got there first.
    }

    [Fact]
    public async Task Ch1QmsFr0003_AFailedMandatoryReadingFromAMachineStillHoldsThePart()
    {
        var runId = await OpenRunAsync("USR-INSPECTOR-ADAPTER-06");
        using var adapter = Adapter();

        // Outside the limits the run declared. A machine cannot decide that a part is
        // acceptable any more than it can decide one is not: the SERVER evaluates the
        // value against the limits and holds the part, and that is unchanged by who
        // appended the reading.
        using var response = await MeasureAsync(adapter, runId, "Coating thickness", 4.20m);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Fail", body.GetProperty("measurement").GetProperty("result").GetString());
        Assert.Equal("Hold", body.GetProperty("partStatus").GetString());
    }
}
