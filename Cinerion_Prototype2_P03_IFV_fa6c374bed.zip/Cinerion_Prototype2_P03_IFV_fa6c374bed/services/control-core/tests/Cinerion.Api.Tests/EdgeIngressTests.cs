// Tests for the gRPC edge's decisions. No gateway required.

using Cinerion.Application.Edge;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Monitoring;

namespace Cinerion.Api.Tests;

/// <summary>
/// The decisions behind CH1-COM-IF-0003 that do not need a running gateway to state.
/// <para>
/// The edge itself is verified against two real services by
/// <c>scripts/check-grpc-edge.sh</c>, because mutual TLS, a controlled certificate
/// authority and a live PostgreSQL are not things a test host can stand in for. What is
/// held here is the part that must be true regardless of transport: an unanswered
/// permissive leaves a cell not permissive, a report expires, a replay is refused, and an
/// out-of-order report cannot reinstate a permissive that has gone.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-SAF-FR-0003, CH1-COM-FR-0006, CH1-COM-FR-0010</requirements>
public sealed class EdgeIngressTests
{
    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-000000000101");
    private static readonly Guid SiteId = Guid.Parse("00000000-0000-4000-8000-000000000102");
    private static readonly Guid CellId = Guid.Parse("00000000-0000-4000-8000-000000000103");
    private static readonly Guid AssetId = Guid.Parse("00000000-0000-4000-8000-000000000104");

    /// <summary>
    /// The property the whole edge exists to protect. A controller that did not answer its
    /// permissives leaves the cell not permissive whatever the individual fields say — and
    /// they are deliberately set to the dangerous values here, because a report with
    /// everything false would be refused by the values alone and would prove nothing about
    /// whether the flag is load-bearing. Proto3 leaves an unset boolean false, so a gateway
    /// that populates the interlocks and forgets the flag sends exactly this.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void UnansweredPermissivesLeaveTheCellNotPermissiveHoweverTheFieldsAreSet()
    {
        var report = Report(new ReportedPermissives(
            Reported: false,
            ControllerOnline: true,
            StartEnable: true,
            StopCircuitHealthy: true,
            GuardHealthy: true,
            ActuatorHome: true,
            ButtonPressed: false,
            FaultCauseActive: false,
            DeferredCheckCodes: [206, 207]));

        var cell = report.ToCellState(Stored());

        Assert.False(cell.ControllerOnline);
        Assert.False(cell.StartEnable);
        Assert.False(cell.StopCircuitHealthy);
        Assert.False(cell.GuardHealthy);
        Assert.False(cell.ActuatorHome);

        // A fault cause nobody reported is not evidence that there is none.
        Assert.True(cell.FaultCauseActive);

        var failure = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(
            () => CommandTransaction.Prepare(Intent(cell), Actor(), cell, DateTimeOffset.UtcNow));
        Assert.StartsWith("INTERLOCK_", failure.Code, StringComparison.Ordinal);
    }

    /// <summary>
    /// The assignments are the store's, never the gateway's. A controller observes
    /// equipment; a report that could move a part or a work order between cells would be a
    /// controller rewriting the digital thread.
    /// </summary>
    [Fact]
    public void AReportDoesNotDecideWhichWorkOrderOrPartIsLoaded()
    {
        var stored = Stored();
        var cell = Report(Answered()).ToCellState(stored);

        Assert.Equal(stored.WorkOrderId, cell.WorkOrderId);
        Assert.Equal(stored.PartId, cell.PartId);
        Assert.Equal(stored.AssetId, cell.AssetId);
        Assert.Equal(stored.SiteId, cell.SiteId);
    }

    /// <summary>A permissive expires with the link rather than persisting after it.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void AReportStopsBeingCurrentOnceItsWindowHasPassed()
    {
        var projection = new CellRuntimeProjection();
        var receivedAt = DateTimeOffset.UtcNow;
        projection.Accept(Report(Answered(), receivedAt: receivedAt));

        Assert.NotNull(projection.FindCurrent(CellId, receivedAt));
        Assert.NotNull(projection.FindCurrent(CellId, receivedAt + CellRuntimeProjection.ValidFor));
        Assert.Null(projection.FindCurrent(
            CellId, receivedAt + CellRuntimeProjection.ValidFor + TimeSpan.FromSeconds(1)));

        // The report itself is still held, so a reader can tell "went quiet" from
        // "never spoke". Only its currency expired.
        Assert.NotNull(projection.FindLatest(CellId));
    }

    /// <summary>CH1-COM-FR-0010: duplicate suppression by message identifier.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void AMessageIdentifierIsAcceptedOnceInsideTheWindow()
    {
        var projection = new CellRuntimeProjection();
        var report = Report(Answered());

        projection.Accept(report);

        var failure = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(() => projection.Accept(report));
        Assert.Equal("INGRESS_DUPLICATE_MESSAGE", failure.Code);
    }

    /// <summary>
    /// <b>The same window covers a telemetry publication and a controller event, and until
    /// the gateway buffer existed it covered neither.</b>
    /// <para>
    /// Duplicate suppression was applied to controller state reports alone, which was
    /// sufficient while nothing ever replayed a reading. CH1-NFR-REL-0001's buffer removes
    /// a record only once Control Core has answered for it, so a gateway that dies between
    /// the answer and the removal replays on restart — and without this, that replay is a
    /// second copy of a reading rather than a refusal. The envelope has always demanded a
    /// message identifier "for duplicate suppression"; this is what makes that comment true
    /// of every message kind rather than one.
    /// </para>
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    [VerificationCase("CH1-VVT-TC-0026")]
    public void AReplayedRecordOfAnyKindIsRefusedRatherThanStoredTwice()
    {
        var projection = new CellRuntimeProjection();
        var now = DateTimeOffset.UtcNow;

        projection.RegisterMessage("telemetry-0001", now);
        var replayedTelemetry = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(
            () => projection.RegisterMessage("telemetry-0001", now));
        Assert.Equal("INGRESS_DUPLICATE_MESSAGE", replayedTelemetry.Code);

        projection.RegisterMessage("controller-event-0001", now);
        var replayedEvent = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(
            () => projection.RegisterMessage("controller-event-0001", now));
        Assert.Equal("INGRESS_DUPLICATE_MESSAGE", replayedEvent.Code);

        // One window, not one per kind: a controller report may not reuse an identifier a
        // telemetry publication has already spent, or the suppression would be per-path and
        // a gateway could defeat it by changing message type.
        var acrossKinds = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(
            () => projection.Accept(Report(Answered(), messageId: "telemetry-0001")));
        Assert.Equal("INGRESS_DUPLICATE_MESSAGE", acrossKinds.Code);

        // And a different identifier is still accepted, so the check above is refusing a
        // replay rather than refusing everything.
        projection.RegisterMessage("telemetry-0002", now);
    }

    /// <summary>
    /// <b>The same replay, refused by the ingress rather than by the projection.</b>
    /// <para>
    /// The check above proves the mechanism exists; this proves the telemetry path calls
    /// it. That distinction is not pedantry — deleting the call from
    /// <c>PublishTelemetryAsync</c> leaves every check above passing, which was found by
    /// doing exactly that. A control is only verified by a test that fails when the control
    /// is removed, not when its mechanism is.
    /// </para>
    /// <para>
    /// The count in the store is the assertion, because "refused" and "not stored twice"
    /// are different claims and only the second one is the requirement.
    /// </para>
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0026")]
    [VerificationCase("CH1-VVT-TC-0029")]
    public async Task TheTelemetryPathItselfRefusesAReplayedPublication()
    {
        var store = new Cinerion.Infrastructure.InMemory.InMemoryCinerionStore();
        await Cinerion.Infrastructure.Seed.PrototypeSeed.ApplyAsync(store, TestContext.Current.CancellationToken);

        var clock = new Cinerion.Application.Abstractions.SystemClock();
        var ingress = new EdgeIngressService(
            store,
            new CellRuntimeProjection(),
            new Cinerion.Application.Monitoring.MonitoringService(
                store, clock, new Cinerion.Application.Assets.DevicePkiService(store, clock)),
            clock);

        var peer = new GatewayPeer("ch1-edgelink", "thumbprint");
        var seeded = Cinerion.Infrastructure.Seed.PrototypeSeed.Ids;
        var publication = new TelemetryPublicationInput(
            Envelope("replayed-telemetry-0001", seeded),
            "CH1-DEV-CELL-0001",
            [new TelemetryReadingInput(
                "temperature", 22.5, "degC", DataQuality.Good, Freshness.Simulated,
                DateTimeOffset.UtcNow, 1)]);

        var accepted = await ingress.PublishTelemetryAsync(peer, publication, TestContext.Current.CancellationToken);
        Assert.True(accepted.Accepted > 0);

        var replay = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await ingress.PublishTelemetryAsync(
                peer, publication, TestContext.Current.CancellationToken));
        Assert.Equal("INGRESS_DUPLICATE_MESSAGE", replay.Code);

        // The reading is in the store once, not twice. This is the property the gateway's
        // peek-send-remove buffer depends on: a gateway that dies between Control Core's
        // answer and its own removal replays, and the reading must not be counted again.
        var now = DateTimeOffset.UtcNow;
        var stored = await store.QueryTelemetryAsync(
            new TelemetryQuery(
                seeded.ProjectId,
                seeded.CellId,
                "CH1-DEV-CELL-0001",
                ["temperature"],
                now - TimeSpan.FromHours(1),
                now + TimeSpan.FromHours(1),
                100),
            TestContext.Current.CancellationToken);
        Assert.Single(stored);

        // A different identifier still gets through, so the refusal above is about the
        // replay rather than about the second publication.
        var next = await ingress.PublishTelemetryAsync(
            peer,
            publication with { Envelope = Envelope("replayed-telemetry-0002", seeded) },
            TestContext.Current.CancellationToken);
        Assert.True(next.Accepted > 0);
    }

    private static IngressEnvelope Envelope(string messageId, dynamic seeded) => new(
        SchemaVersion: EdgeIngressService.SchemaVersion,
        MessageType: "Telemetry",
        MessageId: messageId,
        CorrelationId: Guid.NewGuid().ToString(),
        SourceId: "ch1-edgelink",
        DestinationId: EdgeIngressService.ControlCoreIdentity,
        ProjectId: seeded.ProjectId,
        SiteId: seeded.SiteId,
        CellId: seeded.CellId,
        AssetId: Guid.Empty,
        Sequence: 1,
        OccurredAt: DateTimeOffset.UtcNow,
        ExpiresAt: null);

    /// <summary>
    /// The window is bounded, which is CH1-COM-PRO-0001's "flow control caps memory". A
    /// replay outside it is accepted again, and that is the correct trade: an unbounded
    /// dictionary is a memory fault in a service that authorises physical work.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void TheDuplicateWindowIsBoundedInTime()
    {
        var projection = new CellRuntimeProjection();
        var now = DateTimeOffset.UtcNow;

        projection.RegisterMessage("telemetry-0003", now);
        projection.RegisterMessage(
            "telemetry-0003", now + CellRuntimeProjection.DuplicateWindow + TimeSpan.FromSeconds(1));
    }

    /// <summary>
    /// Ordering, which is a different obligation from duplication: a report that left the
    /// gateway before the one already held must not overwrite it, because the older one may
    /// still say the guard was closed after the newer one said it had opened.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void AnOlderReportCannotOverwriteANewerOne()
    {
        var projection = new CellRuntimeProjection();
        var now = DateTimeOffset.UtcNow;
        projection.Accept(Report(Answered(), observedAt: now, receivedAt: now));

        var failure = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(
            () => projection.Accept(Report(
                ReportedPermissives.NotReported,
                observedAt: now - TimeSpan.FromMinutes(1),
                receivedAt: now,
                // A distinct identifier, so this measures ordering rather than duplicate
                // suppression. The two are separate obligations and the earlier check
                // would otherwise answer for both.
                messageId: "message-0002")));
        Assert.Equal("INGRESS_REPORT_SUPERSEDED", failure.Code);

        // And the permissive report is still the one standing.
        Assert.True(projection.FindLatest(CellId)!.Permissives.Reported);
    }

    /// <summary>
    /// A heartbeat every couple of seconds must not become an audit event every couple of
    /// seconds. Only a material change is recorded, and "material" has to compare the
    /// deferred-check list by value — the compiler-generated record equality compares it by
    /// reference, which would make every identical heartbeat look like a change.
    /// </summary>
    [Fact]
    public void AnIdenticalHeartbeatIsNotAMaterialChange()
    {
        var first = Report(Answered());
        var second = Report(Answered(), messageId: Guid.NewGuid().ToString());

        Assert.False(second.IsMateriallyDifferentFrom(first));
        Assert.True(first.IsMateriallyDifferentFrom(null));
        Assert.True(Report(ReportedPermissives.NotReported).IsMateriallyDifferentFrom(first));
        Assert.True((first with { ControllerBootId = Guid.NewGuid() }).IsMateriallyDifferentFrom(first));
    }

    /// <summary>
    /// <b>The correlation identifier is a mandatory controlled field, and is now required.</b>
    /// <para>
    /// CH1-COM-ICD-0001 lists it among the fields every controlled message carries and
    /// CH1-CYB-FR-0006 requires a security event to carry correlation data. It was
    /// decoded and then dropped: every audit row this service wrote was stamped with a
    /// freshly generated GUID. The consequence is the next test, and the two are
    /// separate because a validation that refuses the absence would not by itself make
    /// the present value get used.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COM-FR-0008, CH1-CYB-FR-0006</requirements>
    [Fact]
    public async Task AnEnvelopeWithoutACorrelationIdentityIsRefused()
    {
        var (ingress, _, peer, seeded) = await IngressAsync();
        var publication = new TelemetryPublicationInput(
            Envelope("uncorrelated-telemetry-0001", seeded) with { CorrelationId = "   " },
            "CH1-DEV-CELL-0001",
            [new TelemetryReadingInput(
                "temperature", 22.5, "degC", DataQuality.Good, Freshness.Simulated,
                DateTimeOffset.UtcNow, 1)]);

        var failure = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await ingress.PublishTelemetryAsync(
                peer, publication, TestContext.Current.CancellationToken));
        Assert.Equal("INGRESS_CORRELATION_REQUIRED", failure.Code);

        // A value that is present but not an identifier is refused for the same reason:
        // "correlated" has to mean something a query can join on.
        var nonsense = publication with
        {
            Envelope = Envelope("uncorrelated-telemetry-0002", seeded) with { CorrelationId = "not-a-guid" },
        };
        var second = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await ingress.PublishTelemetryAsync(
                peer, nonsense, TestContext.Current.CancellationToken));
        Assert.Equal("INGRESS_CORRELATION_REQUIRED", second.Code);
    }

    /// <summary>
    /// <b>Defect 76: a controller's answer must be filed under the command's own
    /// correlation identity, or step 7 of the controlled sequence has nothing to
    /// correlate.</b>
    /// <para>
    /// The controlled PREPARE / LOCAL COMMIT diagram ends with CommandGuard correlating
    /// telemetry, result and audit evidence and returning a visible execution outcome.
    /// Every edge-ingress audit row carried <c>Guid.NewGuid()</c>, so the acknowledgement
    /// was reachable from nothing — not from the command, not from the gateway's own
    /// message, not from any query the audit endpoint offers.
    /// </para>
    /// <para>
    /// The assertion is the JOIN, not the row. Asserting that an event was written would
    /// have passed before the fix; asserting that querying the command's correlation
    /// returns it is the property the sequence actually requires.
    /// </para>
    /// </summary>
    /// <requirements>CH1-CYB-FR-0006, CH1-TRC-FR-0002, CH1-COM-FR-0008</requirements>
    [Fact]
    public async Task AControllerAcknowledgementIsFiledUnderTheCommandsOwnCorrelation()
    {
        var (ingress, store, peer, seeded) = await IngressAsync();

        var cell = Permissive();
        var command = CommandTransaction.Prepare(Intent(cell), Actor(), cell, DateTimeOffset.UtcNow);
        await store.SaveCommandAsync(command, null, TestContext.Current.CancellationToken);

        await ingress.AcknowledgeCommandAsync(
            peer,
            new CommandAcknowledgementInput(
                Envelope("acknowledgement-0001", seeded),
                command.CommandId,
                "CH1-DEV-CELL-0001",
                Accepted: true,
                ControllerState: "AwaitCredential",
                ReasonCode: "PREPARE_ACCEPTED",
                ObservedAt: DateTimeOffset.UtcNow,
                AdapterId: "CH1-ADP-SIM-0001"),
            TestContext.Current.CancellationToken);

        var correlated = await store.QueryAuditAsync(
            command.Intent.ProjectId, command.CorrelationId, 50, TestContext.Current.CancellationToken);

        var acknowledgement = Assert.Single(
            correlated, item => item.EventType == "ControllerAcknowledgementRecorded");
        Assert.Equal(command.CorrelationId, acknowledgement.CorrelationId);
        Assert.Equal("Acknowledged", acknowledgement.Decision);

        // Filed against the transaction it answers, not against the cell. An object-typed
        // lookup for this command has to find it too, and "Cell" would have hidden it
        // behind every heartbeat the same controller ever sent.
        Assert.Equal(nameof(CommandTransaction), acknowledgement.ObjectType);
        Assert.Equal(command.CommandId.ToString(), acknowledgement.ObjectId);

        // And it is still not execution authority: the command has not moved.
        var unchanged = await store.FindCommandAsync(command.CommandId, TestContext.Current.CancellationToken);
        Assert.Equal(CommandState.AwaitingCredential, unchanged!.State);
    }

    /// <summary>
    /// <b>Maintenance is carried end to end and is never a path to execution.</b>
    /// <para>
    /// CH1-AUT-FDS-0001 names Maintenance among the states a cell supports and states the
    /// property that matters about it: "Mode and state are distinct: Maintenance changes
    /// permitted diagnostic actions but never removes machine-specific safety."
    /// </para>
    /// <para>
    /// What this repository can hold of that is exactly this test. Nothing here can put a
    /// cell INTO Maintenance — the controller has no such state, no adapter synthesises
    /// one, and how a cell enters and leaves it is an authority over what that cell then
    /// permits, which no controlled document assigns. That gap is reported as conflict 32
    /// and is not closed by inventing an entry. What is not left open is the safety half:
    /// a controller that did report Maintenance is translated, stored and displayed as
    /// Maintenance, and a preparation against it is refused — so if the authority ever
    /// arrives, it arrives on top of a state that already cannot execute rather than one
    /// that silently could.
    /// </para>
    /// </summary>
    /// <requirements>CH1-CMD-FR-0006, CH1-MON-FR-0003</requirements>
    [Fact]
    public void AMaintenanceCellIsDistinguishableAndCannotBePrepared()
    {
        var report = Report(Answered()) with { OperatingState = CellOperatingState.Maintenance };
        var cell = report.ToCellState(Stored());

        // Distinguishable, which is CH1-MON-FR-0003's requirement: not folded into Idle,
        // and not degraded to Unknown either.
        Assert.Equal(CellOperatingState.Maintenance, cell.OperatingState);

        // And refused. Every individual permissive here is healthy, so the refusal is
        // about the state rather than about the interlocks — which is the whole claim.
        Assert.True(cell.StartEnable);
        Assert.True(cell.GuardHealthy);
        var failure = Assert.Throws<Cinerion.Domain.Common.DomainRuleException>(
            () => CommandTransaction.Prepare(Intent(cell), Actor(), cell, DateTimeOffset.UtcNow));
        Assert.Equal("CMD_STATE_NOT_IDLE", failure.Code);
    }

    private static async Task<(EdgeIngressService Ingress, Cinerion.Infrastructure.InMemory.InMemoryCinerionStore Store, GatewayPeer Peer, Cinerion.Infrastructure.Seed.PrototypeSeedIds Seeded)> IngressAsync()
    {
        var store = new Cinerion.Infrastructure.InMemory.InMemoryCinerionStore();
        await Cinerion.Infrastructure.Seed.PrototypeSeed.ApplyAsync(store, TestContext.Current.CancellationToken);
        var clock = new Cinerion.Application.Abstractions.SystemClock();
        var ingress = new EdgeIngressService(
            store,
            new CellRuntimeProjection(),
            new Cinerion.Application.Monitoring.MonitoringService(
                store, clock, new Cinerion.Application.Assets.DevicePkiService(store, clock)),
            clock);
        return (ingress, store, new GatewayPeer("ch1-edgelink", "thumbprint"), Cinerion.Infrastructure.Seed.PrototypeSeed.Ids);
    }

    /// <summary>A cell a preparation can actually pass, unlike <see cref="Stored"/>.</summary>
    private static CellSnapshot Permissive() => new(
        ProjectId,
        SiteId,
        CellId,
        AssetId,
        "CH1-DEV-CELL-0001",
        Guid.Parse("00000000-0000-4000-8000-000000000107"),
        CellOperatingState.Idle,
        "CFG-REFAB-P01-R01",
        Guid.Parse("00000000-0000-4000-8000-000000000105"),
        Guid.Parse("00000000-0000-4000-8000-000000000106"),
        ControllerOnline: true,
        StartEnable: true,
        StopCircuitHealthy: true,
        GuardHealthy: true,
        ActuatorHome: true,
        ButtonPressed: false,
        FaultCauseActive: false);

    private static ReportedPermissives Answered() => new(
        Reported: true,
        ControllerOnline: true,
        StartEnable: true,
        StopCircuitHealthy: true,
        GuardHealthy: true,
        ActuatorHome: true,
        ButtonPressed: false,
        FaultCauseActive: false,
        DeferredCheckCodes: []);

    private static ControllerReport Report(
        ReportedPermissives permissives,
        DateTimeOffset? observedAt = null,
        DateTimeOffset? receivedAt = null,
        string? messageId = null) => new(
        ProjectId,
        SiteId,
        CellId,
        AssetId,
        "CH1-DEV-CELL-0001",
        Guid.Parse("00000000-0000-4000-8000-000000000107"),
        CellOperatingState.Idle,
        "CFG-REFAB-P01-R01",
        permissives,
        "CH1-ADP-SIM-0001",
        "SIMULATOR",
        "SIMULATION-NO-PHYSICAL-AUTHORITY",
        "0.1.0-prototype.1",
        Freshness.Simulated,
        1,
        messageId ?? "message-0001",
        observedAt ?? DateTimeOffset.UtcNow,
        receivedAt ?? DateTimeOffset.UtcNow,
        "ch1-edgelink");

    private static CellSnapshot Stored() => new(
        ProjectId,
        SiteId,
        CellId,
        AssetId,
        "unassigned",
        Guid.Empty,
        CellOperatingState.Initialising,
        "unreported",
        Guid.Parse("00000000-0000-4000-8000-000000000105"),
        Guid.Parse("00000000-0000-4000-8000-000000000106"),
        false, false, false, false, false, false, false);

    private static PrepareIntent Intent(CellSnapshot cell) => new(
        "RUN_TENSION_CALIBRATION",
        cell.ProjectId,
        cell.SiteId,
        cell.CellId,
        cell.AssetId,
        cell.WorkOrderId,
        cell.PartId,
        "R01",
        cell.ConfigurationRevision,
        cell.StateHash(),
        1,
        DateTimeOffset.UtcNow.AddSeconds(60),
        "ch1-edge-ingress-test-key",
        new Dictionary<string, object>());

    private static Cinerion.Domain.Security.ActorContext Actor() => new(
        "USR-EDGE-INGRESS-TEST",
        Cinerion.Domain.Security.ActorKind.Human,
        new HashSet<string>(StringComparer.Ordinal) { Cinerion.Domain.Security.CinerionRoles.Engineer },
        Cinerion.Domain.Security.AuthenticationStrength.StepUpPhishingResistant,
        ProjectId,
        new HashSet<Guid> { CellId },
        "session-edge-ingress-test");
}
