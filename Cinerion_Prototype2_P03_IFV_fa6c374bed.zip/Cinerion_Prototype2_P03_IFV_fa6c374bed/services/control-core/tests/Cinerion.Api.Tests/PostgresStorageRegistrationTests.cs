// Tests the PostgreSQL wiring by running it, not by reading it.

using Cinerion.Application.Abstractions;
using Cinerion.Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// The wiring, executed rather than read.
/// <para>
/// <see cref="PostgresConnectionReuseTests"/> proves that a shared pool reuses its
/// connections. That says nothing about whether the host actually shares one - the
/// registration could regress to a per-request pool and every one of those tests would
/// still pass. This resolves the real service graph and asks PostgreSQL which backend
/// served each request scope.
/// </para>
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set, on the same terms as the other
/// PostgreSQL tests.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-PER-0001, CH1-CYB-FR-0001, CH1-DBA-FR-0001</requirements>
public sealed class PostgresStorageRegistrationTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    private static ServiceProvider Build() =>
        new ServiceCollection()
            .AddCinerionPostgresStorage(ConnectionString!)
            .BuildServiceProvider(new ServiceProviderOptions
            {
                // The container is asked to check what it was given rather than to
                // discover it at the first resolution: a scoped dependency captured by a
                // singleton is exactly the mistake this graph must not contain.
                ValidateScopes = true,
                ValidateOnBuild = true,
            });

    private static async Task<int> BackendPidAsync(
        CinerionDataSource source,
        CancellationToken cancellationToken)
    {
        await using var connection = await source.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT pg_backend_pid()";
        return Convert.ToInt32(
            await command.ExecuteScalarAsync(cancellationToken),
            System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Two request scopes out of the real graph must reach the same backend, and the first
    /// scope ending must not take the pool with it.
    /// </summary>
    [Fact]
    public async Task Ch1NfrPer0001_TheHostSharesOnePoolAcrossRequestScopes()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;

        await using var provider = Build();

        int first;
        await using (var scope = provider.CreateAsyncScope())
        {
            first = await BackendPidAsync(
                scope.ServiceProvider.GetRequiredService<CinerionDataSource>(), cancellationToken);
        }

        await using var later = provider.CreateAsyncScope();
        var second = await BackendPidAsync(
            later.ServiceProvider.GetRequiredService<CinerionDataSource>(), cancellationToken);

        Assert.True(
            first == second,
            $"two request scopes were served by backends {first} and {second}; the host is " +
            "building a connection pool per request rather than sharing one.");
    }

    /// <summary>
    /// The lifetimes themselves, stated as the container understands them.
    /// </summary>
    /// <remarks>
    /// Asserted alongside the behaviour above rather than instead of it. The behaviour is
    /// what matters; the descriptor is what a reviewer changes by accident.
    /// </remarks>
    [Fact]
    public void Ch1CybFr0001_ThePoolIsPerProcessAndTheScopeIsPerRequest()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");

        var services = new ServiceCollection().AddCinerionPostgresStorage(ConnectionString!);

        Assert.Equal(
            ServiceLifetime.Singleton,
            services.Single(d => d.ServiceType == typeof(CinerionConnectionPool)).Lifetime);
        Assert.Equal(
            ServiceLifetime.Scoped,
            services.Single(d => d.ServiceType == typeof(CinerionDataSource)).Lifetime);
        Assert.Equal(
            ServiceLifetime.Scoped,
            services.Single(d => d.ServiceType == typeof(ProjectScope)).Lifetime);
        Assert.Equal(
            ServiceLifetime.Scoped,
            services.Single(d => d.ServiceType == typeof(ICinerionStore)).Lifetime);
    }

    /// <summary>
    /// Sharing the pool must not share the project scope. Two concurrent request scopes
    /// each set their own project, and neither may see the other's.
    /// </summary>
    [Fact]
    public async Task Ch1CybFr0001_EachRequestScopeCarriesItsOwnProject()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;

        await using var provider = Build();
        var left = Guid.NewGuid();
        var right = Guid.NewGuid();

        await using var one = provider.CreateAsyncScope();
        await using var two = provider.CreateAsyncScope();
        one.ServiceProvider.GetRequiredService<ProjectScope>().Set(left);
        two.ServiceProvider.GetRequiredService<ProjectScope>().Set(right);

        Assert.Equal(
            left.ToString(),
            await CurrentProjectAsync(one.ServiceProvider.GetRequiredService<CinerionDataSource>(), cancellationToken));
        Assert.Equal(
            right.ToString(),
            await CurrentProjectAsync(two.ServiceProvider.GetRequiredService<CinerionDataSource>(), cancellationToken));
    }

    private static async Task<string> CurrentProjectAsync(
        CinerionDataSource source,
        CancellationToken cancellationToken)
    {
        await using var connection = await source.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT current_setting('ch1.project_id', true)";
        var value = await command.ExecuteScalarAsync(cancellationToken);
        return value as string ?? string.Empty;
    }
}
