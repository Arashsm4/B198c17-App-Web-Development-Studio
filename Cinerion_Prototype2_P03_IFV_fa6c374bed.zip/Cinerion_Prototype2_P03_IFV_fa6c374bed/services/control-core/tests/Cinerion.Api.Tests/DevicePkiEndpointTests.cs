// Tests for device enrolment and revocation, and what a revoked device can no longer do.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using Cinerion.Application.Monitoring;
using Cinerion.Domain.Monitoring;
using Cinerion.Infrastructure.Seed;
using Microsoft.Extensions.DependencyInjection;

namespace Cinerion.Api.Tests;

/// <summary>
/// Device certificate enrolment and revocation over HTTP, and the effect revocation has
/// on what the device may then publish.
/// </summary>
/// <requirements>CH1-IAM-FR-0006, CH1-CYB-FR-0002, CH1-CYB-FR-0003, CH1-CYB-CSRS-0001</requirements>
public sealed class DevicePkiEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid CellId = PrototypeSeed.Ids.CellId;

    /// <summary>
    /// Each test provisions its own device identity. Trust state is the thing under test,
    /// so tests sharing one device would leak revocations into each other and the class
    /// would pass or fail on the order it happened to run in.
    /// </summary>
    private async Task<string> ProvisionDeviceAsync(string suffix, CancellationToken cancellationToken)
    {
        var deviceId = $"CH1-DEV-PKI-{suffix}";
        await using var scope = factory.Services.CreateAsyncScope();
        scope.ServiceProvider.GetService<Cinerion.Infrastructure.Persistence.ProjectScope>()?.Set(ProjectId);
        var store = scope.ServiceProvider.GetRequiredService<Cinerion.Application.Abstractions.ICinerionStore>();
        await store.SaveDeviceAsync(
            new Cinerion.Domain.Assets.DeviceRecord(
                deviceId, ProjectId, CellId, "Instrument", "1.0.0", "CFG-R01",
                null, Cinerion.Domain.Assets.DeviceTrustState.Pending, null, null, 1),
            cancellationToken);
        return deviceId;
    }

    private HttpClient Client(string actorId, string roles, string strength = "StepUpPhishingResistant")
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Cells", CellId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private HttpClient CyberAdministrator(string actorId = "USR-CYBER-01") =>
        Client(actorId, "CybersecurityAdministrator");

    /// <summary>Generated per call; the key exists only inside this method.</summary>
    private static string Certificate(string subjectName, int days = 365)
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest($"CN={subjectName}", key, HashAlgorithmName.SHA256);
        using var created = request.CreateSelfSigned(
            DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(days));
        return Convert.ToBase64String(created.Export(X509ContentType.Cert));
    }

    private static object EnrolBody(string certificate, params (string Channel, string Unit)[] channels) => new
    {
        certificate,
        schemaVersion = "1.0.0",
        deviceType = "Instrument",
        firmwareVersion = "2.5.0",
        configurationRevision = "CFG-INS-THK-R03",
        telemetryChannels = channels.Length == 0
            ? new[] { new { channelId = "temperature", unit = "degC" } }
            : [.. channels.Select(item => new { channelId = item.Channel, unit = item.Unit })],
        supportedCommands = new[] { "RUN_DIMENSIONAL_TEST" },
        securityProfile = "SIMULATION-NO-PHYSICAL-AUTHORITY",
    };

    private static async Task<string> StepUpAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "DeviceTrust" }, cancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("grantId").GetGuid().ToString();
    }

    private static async Task<HttpResponseMessage> PostAsync(
        HttpClient client,
        string url,
        object body,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, url) { Content = JsonContent.Create(body) };
        request.Headers.Add("X-CH1-Step-Up", await StepUpAsync(client, cancellationToken));
        return await client.SendAsync(request, cancellationToken);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    [VerificationCase("CH1-VVT-TC-0103")]
    public async Task Ch1IamFr0006_EnrolmentRecordsAVerifiedCertificateAndRaisesATrustChangeAlarm()
    {
        var deviceId = await ProvisionDeviceAsync("ENROL", TestContext.Current.CancellationToken);
        using var cyber = CyberAdministrator("USR-CYBER-ENROL");
        using var response = await PostAsync(
            cyber,
            $"/api/v1/devices/{deviceId}/enrolment",
            EnrolBody(Certificate(deviceId)),
            TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var certificate = body.GetProperty("certificate");
        Assert.Matches("^[a-f0-9]{64}$", certificate.GetProperty("thumbprint").GetString() ?? string.Empty);
        Assert.Equal("ECDSA", certificate.GetProperty("keyAlgorithm").GetString());
        Assert.Contains(
            "Computed by Control Core",
            certificate.GetProperty("thumbprintSource").GetString() ?? string.Empty,
            StringComparison.Ordinal);
        Assert.Contains(
            "Never presented, never stored",
            body.GetProperty("privateKey").GetString() ?? string.Empty,
            StringComparison.Ordinal);

        var device = body.GetProperty("device");
        Assert.Equal("Trusted", device.GetProperty("trustState").GetString());
        Assert.True(device.GetProperty("trusted").GetBoolean());
        // The device's own declaration replaces what the platform previously held.
        Assert.Equal("2.5.0", device.GetProperty("firmwareVersion").GetString());

        // CH1-CYB-CSRS-0001 lists trust-list change among the events alerting must cover.
        Assert.Equal(
            "CH1-ALM-DEVICE-TRUST-CHANGED",
            body.GetProperty("alarm").GetProperty("alarmCode").GetString());
    }

    /// <summary>
    /// CH1-CYB-CSRS-0001 requires long-lived private keys to be non-exportable. A key
    /// arriving here means that boundary has already failed.
    /// </summary>
    [Fact]
    public async Task Ch1CybFr0003_SubmittingAPrivateKeyIsRefusedAndNamedAsACompromise()
    {
        var deviceId = await ProvisionDeviceAsync("KEY", TestContext.Current.CancellationToken);
        using var cyber = CyberAdministrator("USR-CYBER-KEY");
        var withKey = "-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----\n" +
            "-----BEGIN EC " + "PRIVATE KEY-----\nredacted\n-----END EC " + "PRIVATE KEY-----\n";

        using var response = await PostAsync(
            cyber, $"/api/v1/devices/{deviceId}/enrolment", EnrolBody(withKey), TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("ENROLMENT_PRIVATE_KEY_SUBMITTED", body.GetProperty("code").GetString());
        Assert.Contains(
            "compromised",
            body.GetProperty("detail").GetString() ?? string.Empty,
            StringComparison.Ordinal);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1CybAcp0001_EnrolmentRequiresTheCybersecurityAdministratorAndAStepUp()
    {
        var deviceId = await ProvisionDeviceAsync("AUTH", TestContext.Current.CancellationToken);
        using var engineer = Client("USR-ENGINEER-PKI", "Engineer");
        using var wrongRole = await PostAsync(
            engineer, $"/api/v1/devices/{deviceId}/enrolment", EnrolBody(Certificate(deviceId)),
            TestContext.Current.CancellationToken);
        var denied = await wrongRole.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, wrongRole.StatusCode);
        Assert.Equal("AUTH_DEVICE_TRUST", denied.GetProperty("code").GetString());

        using var cyber = CyberAdministrator("USR-CYBER-NOSTEP");
        using var noStepUp = await cyber.PostAsJsonAsync(
            $"/api/v1/devices/{deviceId}/enrolment", EnrolBody(Certificate(deviceId)),
            TestContext.Current.CancellationToken);
        var body = await noStepUp.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_REQUIRED", body.GetProperty("code").GetString());

        // access.json asks for hardware-backed MFA here, so an MFA-only step-up is not
        // enough.
        using var weak = Client("USR-CYBER-WEAK", "CybersecurityAdministrator", strength: "Mfa");
        using var weakResponse = await PostAsync(
            weak, $"/api/v1/devices/{deviceId}/enrolment", EnrolBody(Certificate(deviceId)),
            TestContext.Current.CancellationToken);
        var weakBody = await weakResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_STRONGER_AUTHENTICATOR_REQUIRED", weakBody.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0103")]
    public async Task ACertificateNamingAnotherDeviceIsRefused()
    {
        var deviceId = await ProvisionDeviceAsync("SUBJECT", TestContext.Current.CancellationToken);
        using var cyber = CyberAdministrator("USR-CYBER-SUBJECT");

        using var response = await PostAsync(
            cyber,
            $"/api/v1/devices/{deviceId}/enrolment",
            EnrolBody(Certificate("CH1-DEV-IMPOSTOR")),
            TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal("ENROLMENT_SUBJECT_MISMATCH", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1CybFr0001_ADeviceOutsideTheProjectIsIndistinguishableFromAbsent()
    {
        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OTHER-CYBER");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "CybersecurityAdministrator");
        outsider.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "StepUpPhishingResistant");
        outsider.DefaultRequestHeaders.Add("X-CH1-Session", "session-outsider");
        outsider.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time", DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));

        var deviceId = await ProvisionDeviceAsync("SCOPE", TestContext.Current.CancellationToken);
        using var existing = await PostAsync(
            outsider, $"/api/v1/devices/{deviceId}/enrolment", EnrolBody(Certificate(deviceId)),
            TestContext.Current.CancellationToken);
        using var absent = await PostAsync(
            outsider, "/api/v1/devices/CH1-DEV-NEVER-EXISTED/enrolment", EnrolBody(Certificate("CH1-DEV-NEVER-EXISTED")),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, existing.StatusCode);
        Assert.Equal(absent.StatusCode, existing.StatusCode);
    }

    /// <summary>
    /// The point of revocation: the device stops being able to publish. Proven by
    /// offering a reading before and after, and by the security alarm CH1-CYB-CSRS-0001
    /// requires when a revoked device is used.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1IamFr0006_RevocationStopsTheDeviceAndRevokedUseRaisesAnAlarm()
    {
        var deviceId = await ProvisionDeviceAsync("REVOKE", TestContext.Current.CancellationToken);
        using var cyber = CyberAdministrator("USR-CYBER-REVOKE");
        using var enrol = await PostAsync(
            cyber,
            $"/api/v1/devices/{deviceId}/enrolment",
            EnrolBody(Certificate(deviceId), ("temperature", "degC")),
            TestContext.Current.CancellationToken);
        enrol.EnsureSuccessStatusCode();

        // Before: the device may publish a channel it declared.
        var before = await IngestAsync(deviceId, TestContext.Current.CancellationToken);
        Assert.Equal(1, before.Accepted);

        using var revoke = await PostAsync(
            cyber,
            $"/api/v1/devices/{deviceId}/revoke",
            new { reason = "Instrument reported stolen from the calibration bench." },
            TestContext.Current.CancellationToken);
        var body = await revoke.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, revoke.StatusCode);
        var device = body.GetProperty("device");
        Assert.Equal("Revoked", device.GetProperty("trustState").GetString());
        Assert.False(device.GetProperty("trusted").GetBoolean());
        Assert.Equal("USR-CYBER-REVOKE", device.GetProperty("revokedBy").GetString());
        // The thumbprint is retained, not cleared.
        Assert.False(string.IsNullOrEmpty(device.GetProperty("certificateThumbprint").GetString()));

        Assert.Equal("CH1-ALM-DEVICE-REVOKED", body.GetProperty("alarm").GetProperty("alarmCode").GetString());

        // What took effect, and what did not, stated rather than implied.
        var effect = body.GetProperty("effect");
        Assert.True(effect.GetProperty("telemetryRefusedImmediately").GetBoolean());
        Assert.False(effect.GetProperty("brokerTopicAclRevoked").GetBoolean());

        // After: the same reading is refused, and the attempt raises the revoked-use alarm.
        await using var scope = factory.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();
        var error = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await monitoring.IngestAsync(
                ProjectId,
                [Reading(deviceId)],
                TestContext.Current.CancellationToken));
        Assert.Equal("TELEMETRY_DEVICE_NOT_TRUSTED", error.Code);

        using var alarms = await cyber.GetAsync(
            "/api/v1/alarms?state=Active", TestContext.Current.CancellationToken);
        var list = await alarms.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var revokedUse = list.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("alarmCode").GetString() == "CH1-ALM-DEVICE-REVOKED-USE");
        Assert.Equal(1, revokedUse.GetProperty("priority").GetInt32());
        Assert.Contains(
            "revoked device attempted to publish",
            revokedUse.GetProperty("guidance").GetString() ?? string.Empty,
            StringComparison.Ordinal);
    }

    private static TelemetryReading Reading(string deviceId) => new(
        CellId, deviceId, "temperature", 21.0, "degC", DataQuality.Good, Freshness.Simulated, DateTimeOffset.UtcNow);

    private async Task<TelemetryIngestionResult> IngestAsync(string deviceId, CancellationToken cancellationToken)
    {
        await using var scope = factory.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();
        return await monitoring.IngestAsync(ProjectId, [Reading(deviceId)], cancellationToken);
    }

    /// <summary>
    /// The enrolled manifest narrows the baseline catalogue and never widens it: a
    /// channel must be in both.
    /// </summary>
    [Fact]
    public async Task Ch1ComFr0001_AnEnrolledManifestNarrowsWhatTheDeviceMayPublish()
    {
        var deviceId = await ProvisionDeviceAsync("MANIFEST", TestContext.Current.CancellationToken);
        using var cyber = CyberAdministrator("USR-CYBER-MANIFEST");
        using var enrol = await PostAsync(
            cyber,
            $"/api/v1/devices/{deviceId}/enrolment",
            EnrolBody(Certificate(deviceId), ("temperature", "degC")),
            TestContext.Current.CancellationToken);
        enrol.EnsureSuccessStatusCode();

        await using var scope = factory.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();

        // Declared: accepted.
        var declared = await monitoring.IngestAsync(
            ProjectId,
            [new TelemetryReading(
                CellId, deviceId, "temperature", 22.0, "degC",
                DataQuality.Good, Freshness.Simulated, DateTimeOffset.UtcNow)],
            TestContext.Current.CancellationToken);
        Assert.Equal(1, declared.Accepted);

        // In the baseline catalogue but not declared by this device: refused.
        var undeclared = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await monitoring.IngestAsync(
                ProjectId,
                [new TelemetryReading(
                    CellId, deviceId, "humidity", 44.0, "%RH",
                    DataQuality.Good, Freshness.Simulated, DateTimeOffset.UtcNow)],
                TestContext.Current.CancellationToken));
        Assert.Equal("TELEMETRY_CHANNEL_NOT_DECLARED", undeclared.Code);
    }
}
