// Tests for the publication pipeline over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// The CH1-DOC-FR-0004 publication pipeline over HTTP.
/// <para>
/// <em>"Public material shall be generated only from an approved redaction profile and
/// shall pass content diff, metadata scrub, secret scan, owner approval and checksum
/// generation before publication."</em>
/// </para>
/// <para>
/// Both operations answered 501 until now, grouped with the secure document vault. The
/// vault genuinely is a future phase - CH1-DOC-FR-0002 wants a per-document key behind a
/// separate key-encryption boundary - but this requirement is "Baseline P03" and needs
/// none of it. Each control below is exercised and then attacked.
/// </para>
/// </summary>
/// <requirements>CH1-DOC-FR-0001, CH1-DOC-FR-0004, CH1-CYB-FR-0001</requirements>
public sealed class PublicationPipelineEndpointTests(CinerionApiFactory factory)
    : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private const string ShowcaseProfile = "CH1-DOC-RDP-SHOWCASE";

    private HttpClient Client(string actorId, string roles)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "StepUpPhishingResistant");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private HttpClient Controller(string actorId = "USR-DOCCTRL-01") =>
        Client(actorId, "DocumentController,Viewer");

    /// <summary>
    /// IR, the project owner. <c>stakeholders.json</c> declares the role and
    /// <c>access.json</c> names IR in the authority column for approving a redacted
    /// publication; conflict 23 recorded that <c>CinerionRoles</c> had no such role and
    /// that the Project Manager was standing in for it. It does now.
    /// </summary>
    private HttpClient Owner(string actorId = "USR-PROJOWNER-01") =>
        Client(actorId, "ProjectOwner,Viewer");

    private HttpClient ProjectManager(string actorId = "USR-PROJMGR-01") =>
        Client(actorId, "ProjectManager,Viewer");

    private static object Body(
        string? content = null,
        Guid[]? sources = null,
        string profile = ShowcaseProfile,
        IReadOnlyDictionary<string, string>? metadata = null) => new
        {
            RedactionProfileId = profile,
            Title = "ReFab MicroStation showcase",
            SourceDocumentIds = sources ?? new[] { PrototypeSeed.Ids.ProjectInternalDocumentId },
            Content = content ?? $"A redacted public summary. Nonce {Guid.NewGuid()}.",
            MediaType = "text/plain; charset=utf-8",
            Metadata = metadata ?? new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["title"] = "ReFab MicroStation",
                ["internalReviewer"] = "somebody",
                ["sourceRepository"] = "an internal path",
            },
        };

    private static async Task<JsonElement> ReadAsync(
        HttpResponseMessage response,
        CancellationToken cancellationToken) =>
        await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);

    private static async Task<JsonElement> CreateAsync(
        HttpClient client,
        object body,
        CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync("/api/v1/publication-packages", body, cancellationToken);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        return await ReadAsync(response, cancellationToken);
    }

    private static async Task<string> StepUpAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "PublicationApproval" }, cancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("grantId").GetGuid().ToString();
    }

    private static async Task<HttpResponseMessage> ReviewAsync(
        HttpClient client,
        Guid packageId,
        bool approved,
        string checksum,
        CancellationToken cancellationToken,
        string comment = "Read in full; nothing confidential remains.")
    {
        var grant = await StepUpAsync(client, cancellationToken);
        using var request = new HttpRequestMessage(
            HttpMethod.Post, $"/api/v1/publication-packages/{packageId}/approvals")
        {
            Content = JsonContent.Create(new
            {
                Approved = approved,
                ReviewedChecksum = checksum,
                Comment = comment,
            }),
        };
        request.Headers.Add("X-CH1-Step-Up", grant);
        return await client.SendAsync(request, cancellationToken);
    }

    // ------------------------------------------------------------- the happy path

    /// <summary>
    /// The pipeline runs, and every control it performed is on the face of the record -
    /// including the one it did not.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_APackageRecordsWhatThePipelineDidToIt()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller();

        var package = await CreateAsync(controller, Body(), cancellationToken);

        Assert.Equal("PendingApproval", package.GetProperty("state").GetString());
        Assert.Equal(ShowcaseProfile, package.GetProperty("redactionProfile").GetString());
        Assert.Equal("1.0.0", package.GetProperty("profileRevision").GetString());
        Assert.Matches("^[a-f0-9]{64}$", package.GetProperty("contentSha256").GetString()!);

        // Metadata scrub: the permitted key survives and the others are named.
        var removed = package.GetProperty("metadataRemoved").EnumerateArray()
            .Select(item => item.GetString()).ToArray();
        Assert.Contains("internalReviewer", removed);
        Assert.Contains("sourceRepository", removed);
        Assert.DoesNotContain("title", removed);
        Assert.True(package.GetProperty("metadataRetained").TryGetProperty("title", out _));

        // The secret scan ran, and says what it looked for.
        Assert.Equal("CH1-DOC-SCAN-0001", package.GetProperty("secretScan").GetProperty("profile").GetString());
        Assert.True(package.GetProperty("secretScan").GetProperty("patterns").GetInt32() >= 5);

        // The half of the diff control that could not be performed is stated rather than
        // implied by its absence - the same shape as brokerTopicAclRevoked: false.
        Assert.False(package.GetProperty("contentDiffPerformed").GetBoolean());
        Assert.Contains(
            "NOT performed",
            package.GetProperty("contentDiffNote").GetString()!,
            StringComparison.Ordinal);

        // And the platform never claims to publish.
        Assert.Contains(
            "outside this platform",
            package.GetProperty("publicationAuthority").GetString()!,
            StringComparison.Ordinal);
    }

    /// <summary>
    /// Two capacities, two identities, and only then Approved.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_ApprovalNeedsBothCapacitiesAndTwoDifferentPeople()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var author = Controller("USR-DOCCTRL-AUTHOR");
        using var reviewingController = Controller("USR-DOCCTRL-REVIEW");
        using var owner = Owner("USR-PROJMGR-REVIEW");

        var package = await CreateAsync(author, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();
        var checksum = package.GetProperty("contentSha256").GetString()!;

        using var first = await ReviewAsync(owner, packageId, true, checksum, cancellationToken);
        Assert.Equal(HttpStatusCode.OK, first.StatusCode);
        var afterFirst = await ReadAsync(first, cancellationToken);

        // One review is not approval. A package that became Approved here would have been
        // approved by one person.
        Assert.Equal("PendingApproval", afterFirst.GetProperty("state").GetString());

        using var second = await ReviewAsync(reviewingController, packageId, true, checksum, cancellationToken);
        Assert.Equal(HttpStatusCode.OK, second.StatusCode);
        var afterSecond = await ReadAsync(second, cancellationToken);
        Assert.Equal("Approved", afterSecond.GetProperty("state").GetString());
        Assert.True(afterSecond.GetProperty("decidedAt").ValueKind is not JsonValueKind.Null);
    }

    /// <summary>A single rejection decides the package, and it is not reviewed again.</summary>
    [Fact]
    public async Task Ch1DocFr0004_OneRejectionDecidesThePackage()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var author = Controller("USR-DOCCTRL-REJ-AUTHOR");
        using var owner = Owner("USR-PROJMGR-REJ");
        using var other = Controller("USR-DOCCTRL-REJ-OTHER");

        var package = await CreateAsync(author, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();
        var checksum = package.GetProperty("contentSha256").GetString()!;

        using var rejection = await ReviewAsync(
            owner, packageId, false, checksum, cancellationToken, "Still names an internal supplier.");
        Assert.Equal(HttpStatusCode.OK, rejection.StatusCode);
        Assert.Equal("Rejected", (await ReadAsync(rejection, cancellationToken)).GetProperty("state").GetString());

        using var afterwards = await ReviewAsync(other, packageId, true, checksum, cancellationToken);
        Assert.NotEqual(HttpStatusCode.OK, afterwards.StatusCode);
        Assert.Contains(
            "PUBLICATION_ALREADY_DECIDED",
            await afterwards.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    // ----------------------------------------------------------------- the attacks

    /// <summary>A classification the profile does not permit is refused as an input.</summary>
    [Fact]
    public async Task Ch1DocFr0004_ASourceOutsideTheProfilesAllowlistIsRefused()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller();

        using var response = await controller.PostAsJsonAsync(
            "/api/v1/publication-packages",
            Body(sources: [PrototypeSeed.Ids.SecuritySensitiveDocumentId]),
            cancellationToken);

        Assert.NotEqual(HttpStatusCode.Created, response.StatusCode);
        Assert.Contains(
            "PUBLICATION_SOURCE_NOT_ALLOWLISTED",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>
    /// A derivative carrying a credential is refused outright and never recorded. Public
    /// material with a secret in it is the outcome this control exists to prevent, so a
    /// finding is a refusal rather than a note on an accepted package.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_ADerivativeMatchingTheSecretScanIsRefusedAndNotRecorded()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller();

        // Shaped like a credential assignment and containing no credential.
        using var response = await controller.PostAsJsonAsync(
            "/api/v1/publication-packages",
            Body(content: "Overview of the station.\napi_key = not-a-real-value-0123456789\n"),
            cancellationToken);

        Assert.NotEqual(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        Assert.Contains("PUBLICATION_SECRET_SCAN_FAILED", body, StringComparison.Ordinal);

        // The names of the patterns are reported; the matched text is not, because putting
        // it in a response body is the same disclosure by another route.
        Assert.DoesNotContain("not-a-real-value-0123456789", body, StringComparison.Ordinal);
    }

    /// <summary>The metadata that survives is scanned too, not trusted because it is short.</summary>
    [Fact]
    public async Task Ch1DocFr0004_RetainedMetadataIsScannedOnTheSameTerms()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller();

        using var response = await controller.PostAsJsonAsync(
            "/api/v1/publication-packages",
            Body(metadata: new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["title"] = "token = not-a-real-value-9876543210",
            }),
            cancellationToken);

        Assert.NotEqual(HttpStatusCode.Created, response.StatusCode);
        Assert.Contains(
            "PUBLICATION_SECRET_SCAN_FAILED",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>
    /// A reviewer who states a different checksum reviewed different bytes, and has
    /// approved nothing.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0004_AReviewOfDifferentBytesIsRefused()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var author = Controller("USR-DOCCTRL-CHK-AUTHOR");
        using var owner = Owner("USR-PROJMGR-CHK");

        var package = await CreateAsync(author, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();

        using var response = await ReviewAsync(
            owner, packageId, true, new string('a', 64), cancellationToken);

        Assert.NotEqual(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains(
            "PUBLICATION_REVIEWED_CHECKSUM_MISMATCH",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>The identity that built the package may not review it.</summary>
    [Fact]
    public async Task Ch1DocFr0004_TheAuthorMayNotReviewTheirOwnPackage()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var author = Controller("USR-DOCCTRL-SELF");

        var package = await CreateAsync(author, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();
        var checksum = package.GetProperty("contentSha256").GetString()!;

        using var response = await ReviewAsync(author, packageId, true, checksum, cancellationToken);

        Assert.NotEqual(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains(
            "PUBLICATION_REVIEWER_IS_AUTHOR",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>Approval without a phishing-resistant step-up grant is refused.</summary>
    [Fact]
    public async Task Ch1CybAcp0001_ApprovalWithoutAStepUpGrantIsRefused()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var author = Controller("USR-DOCCTRL-NOSTEP-AUTHOR");
        using var owner = Owner("USR-PROJMGR-NOSTEP");

        var package = await CreateAsync(author, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();
        var checksum = package.GetProperty("contentSha256").GetString()!;

        using var response = await owner.PostAsJsonAsync(
            $"/api/v1/publication-packages/{packageId}/approvals",
            new { Approved = true, ReviewedChecksum = checksum, Comment = "Looks fine." },
            cancellationToken);

        Assert.NotEqual(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains(
            "STEP_UP_REQUIRED",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>An identity holding neither review capacity cannot review.</summary>
    [Fact]
    public async Task Ch1CybAcp0001_AnIdentityWithNeitherCapacityCannotReview()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var author = Controller("USR-DOCCTRL-AUTH-AUTHOR");
        using var engineer = Client("USR-ENGINEER-REVIEW", "Engineer,Viewer");

        var package = await CreateAsync(author, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();
        var checksum = package.GetProperty("contentSha256").GetString()!;

        using var response = await ReviewAsync(engineer, packageId, true, checksum, cancellationToken);

        Assert.NotEqual(HttpStatusCode.OK, response.StatusCode);
    }

    /// <summary>Building a package requires the Document Controller role.</summary>
    [Fact]
    public async Task Ch1CybAcp0001_BuildingAPackageRequiresTheDocumentController()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var engineer = Client("USR-ENGINEER-BUILD", "Engineer,Viewer");

        using var response = await engineer.PostAsJsonAsync(
            "/api/v1/publication-packages", Body(), cancellationToken);

        Assert.NotEqual(HttpStatusCode.Created, response.StatusCode);
        Assert.Contains(
            "AUTH_PUBLICATION_PACKAGE",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>A profile the build does not hold is refused, never treated as permissive.</summary>
    [Fact]
    public async Task Ch1DocFr0004_AnUnknownRedactionProfileIsRefused()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller();

        using var response = await controller.PostAsJsonAsync(
            "/api/v1/publication-packages",
            Body(profile: "CH1-DOC-RDP-NOT-A-PROFILE"),
            cancellationToken);

        Assert.NotEqual(HttpStatusCode.Created, response.StatusCode);
        Assert.Contains(
            "PUBLICATION_PROFILE_UNKNOWN",
            await response.Content.ReadAsStringAsync(cancellationToken),
            StringComparison.Ordinal);
    }

    /// <summary>
    /// The two operations no longer answer the controlled 501, and the two that remain
    /// gated still do. Both halves matter: an implemented capability that still refused
    /// would be a gate nobody removed, and a gated one that stopped refusing would be the
    /// fake success the deferred list exists to prevent.
    /// </summary>
    [Fact]
    public async Task Ch1DocFr0002_TheDocumentVaultStaysGatedWhilePublicationDoesNot()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller("USR-DOCCTRL-GATE");

        using var vault = await controller.GetAsync(
            $"/api/v1/documents/{PrototypeSeed.Ids.ControlledDocumentId}", cancellationToken);
        Assert.Equal(HttpStatusCode.NotImplemented, vault.StatusCode);

        using var export = await controller.PostAsJsonAsync(
            $"/api/v1/documents/{PrototypeSeed.Ids.ControlledDocumentId}/export-requests",
            new { Recipient = "somebody", Purpose = "review" },
            cancellationToken);
        Assert.Equal(HttpStatusCode.NotImplemented, export.StatusCode);

        using var created = await controller.PostAsJsonAsync(
            "/api/v1/publication-packages", Body(), cancellationToken);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
    }

    /// <summary>
    /// Conflict 23's resolution, asserted rather than assumed: the Project Manager no
    /// longer holds the owner's capacity.
    /// </summary>
    /// <remarks>
    /// Retaining the old mapping alongside the new role would have meant two roles could
    /// sign the same half of a two-person review, and an authority still reachable through
    /// the mapping it replaced is an authority that was never actually moved. The Project
    /// Manager keeps every other authority the controlled documents give them; what they
    /// lose is a capacity <c>stakeholders.json</c> gives to IR.
    /// </remarks>
    [Fact]
    public async Task Ch1DocFr0004_TheProjectManagerNoLongerHoldsTheOwnersCapacity()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        using var controller = Controller();
        var package = await CreateAsync(controller, Body(), cancellationToken);
        var packageId = package.GetProperty("packageId").GetGuid();
        var checksum = package.GetProperty("contentSha256").GetString()!;

        using var manager = ProjectManager();
        using var refused = await ReviewAsync(manager, packageId, true, checksum, cancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, refused.StatusCode);

        // And the owner, who now exists, can.
        using var owner = Owner();
        using var accepted = await ReviewAsync(owner, packageId, true, checksum, cancellationToken);
        Assert.Equal(HttpStatusCode.OK, accepted.StatusCode);
    }
}
