// Tests for R&D experiments and promotion requests over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Research;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// Isolated R&amp;D experiments, run provenance and promotion requests over HTTP.
/// </summary>
/// <requirements>CH1-RND-FR-0001, CH1-RND-FR-0002, CH1-RND-FR-0003, CH1-VVT-TC-0110, CH1-VVT-TC-0111, CH1-VVT-TC-0112</requirements>
public sealed class ResearchBenchEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid CellId = PrototypeSeed.Ids.CellId;
    private static readonly Guid Station = PrototypeSeed.Ids.CoatingStationResourceId;

    private HttpClient Client(string actorId, string roles)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private HttpClient Researcher(string actorId = "USR-RND-01") => Client(actorId, "RDEngineer");

    private static readonly string[] ResearcherScope = ["RDEngineer"];

    private static string Hash(string value) =>
        Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(value)));

    private static object RunBody(string seed = "baseline") => new
    {
        configurationReference = $"git:cinerion-bench@{seed}",
        configurationSha256 = Hash($"config-{seed}"),
        modelReference = $"model:coating-thickness@{seed}",
        inputReference = $"dataset:coating-trials-{seed}.csv",
        inputSha256 = Hash($"input-{seed}"),
        resultSummary = $"Mean thickness 8.02 um, sigma 0.11 ({seed}).",
        resultSha256 = Hash($"result-{seed}"),
        startedAt = DateTimeOffset.UtcNow.AddMinutes(-30),
        finishedAt = DateTimeOffset.UtcNow.AddMinutes(-5),
    };

    private static async Task<JsonElement> DefineAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/experiments",
            new { objective = "Characterise coating thickness against dwell time." },
            cancellationToken);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
    }

    private static async Task<string> StepUpAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "ConfigurationPromotion" }, cancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("grantId").GetGuid().ToString();
    }

    /// <summary>
    /// CH1-VVT-TC-0110: experiment roles can use simulators but have no implicit
    /// production or real-equipment command authority.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0110")]
    public async Task Ch1VvtTc0110_AnExperimentIsSimulatorOnlyWithNoProductionAuthority()
    {
        using var researcher = Researcher();
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);

        Assert.Equal("Simulator", experiment.GetProperty("environment").GetString());
        Assert.False(experiment.GetProperty("productionAuthority").GetBoolean());
        Assert.Equal("Draft", experiment.GetProperty("status").GetString());
        Assert.Equal("USR-RND-01", experiment.GetProperty("ownerId").GetString());
        Assert.Contains(
            "no production authority",
            experiment.GetProperty("isolation").GetString() ?? string.Empty,
            StringComparison.Ordinal);

        // The bench transition is a separate authorised act with no operation behind it,
        // so an experiment cannot elect into it.
        using var bench = await researcher.PostAsJsonAsync(
            "/api/v1/experiments",
            new { objective = "Run against the real cell.", environment = "ControlledBench" },
            TestContext.Current.CancellationToken);
        var refusal = await bench.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, bench.StatusCode);
        Assert.Equal("EXPERIMENT_BENCH_TRANSITION_NOT_AUTHORISED", refusal.GetProperty("code").GetString());
    }

    /// <summary>
    /// An R&amp;D identity holds no authority over equipment. The command chain and the
    /// alarm chain are unreachable to it, which is the "deny production routes" half of
    /// CH1-COM-IF-0020 and CH1-CYB-ACP-0001.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0110")]
    [VerificationCase("CH1-VVT-TC-0104")]
    public async Task Ch1VvtTc0110_AnRdIdentityCannotReachProductionRoutes()
    {
        using var researcher = Researcher("USR-RND-PROBE");

        // No step-up purpose an R&D role holds can prepare a physical command.
        using var prepare = await researcher.PostAsJsonAsync(
            "/api/v1/commands/prepare",
            new
            {
                commandType = "RUN_TENSION_CALIBRATION",
                projectId = ProjectId,
                siteId = PrototypeSeed.Ids.SiteId,
                cellId = CellId,
                assetId = PrototypeSeed.Ids.AssetId,
                workOrderId = PrototypeSeed.Ids.WorkOrderId,
                partId = PrototypeSeed.Ids.PartId,
                procedureRevision = "R01",
                configurationRevision = "CFG-REFAB-P01-R01",
                expectedStateHash = new string('0', 64),
                sequence = 1L,
                expiresAt = DateTimeOffset.UtcNow.AddSeconds(60),
                parameters = new Dictionary<string, object>(),
            },
            TestContext.Current.CancellationToken);
        Assert.NotEqual(HttpStatusCode.Created, prepare.StatusCode);

        // Reserving capacity is a management authority the R&D role does not hold either.
        using var reserve = await researcher.PostAsJsonAsync(
            $"/api/v1/resources/{Station}/reservations",
            new { quantity = 1m, startsAt = DateTimeOffset.UtcNow, endsAt = DateTimeOffset.UtcNow.AddHours(1) },
            TestContext.Current.CancellationToken);
        Assert.NotEqual(HttpStatusCode.Created, reserve.StatusCode);

        // And the operational view is closed to it, so it cannot even observe the cell.
        using var cell = await researcher.GetAsync(
            $"/api/v1/cells/{CellId}/state", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, cell.StatusCode);
    }

    /// <summary>
    /// CH1-VVT-TC-0111: a second authorised user reproduces the experiment from the
    /// retained version, inputs, environment and evidence records.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0111")]
    public async Task Ch1VvtTc0111_ARunRetainsEverythingNeededToReproduceIt()
    {
        using var researcher = Researcher("USR-RND-REPRO");
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);
        var experimentId = experiment.GetProperty("experimentId").GetGuid();

        using var response = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs",
            RunBody("repro"),
            TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var run = body.GetProperty("run");
        var provenance = run.GetProperty("provenance");

        Assert.Equal(1, run.GetProperty("revisionNumber").GetInt32());
        Assert.Equal("Simulator", run.GetProperty("environment").GetString());
        Assert.Equal("git:cinerion-bench@repro", provenance.GetProperty("configurationReference").GetString());
        Assert.Equal(Hash("config-repro"), provenance.GetProperty("configurationSha256").GetString());
        Assert.Equal("model:coating-thickness@repro", provenance.GetProperty("modelReference").GetString());
        Assert.Equal(Hash("input-repro"), provenance.GetProperty("inputSha256").GetString());
        Assert.Equal(Hash("result-repro"), provenance.GetProperty("resultSha256").GetString());
        Assert.Equal("USR-RND-REPRO", run.GetProperty("requestedBy").GetString());
        Assert.True(run.GetProperty("immutable").GetBoolean());
        Assert.False(run.GetProperty("productionAuthority").GetBoolean());

        // The executor is an isolated bench identity derived from the experiment, never
        // the caller's own identity and never a production account.
        Assert.Equal(
            ExperimentRevision.IsolatedIdentityFor(experimentId),
            run.GetProperty("executedBy").GetString());
        Assert.StartsWith("bench:", run.GetProperty("executedBy").GetString() ?? string.Empty, StringComparison.Ordinal);

        // No fake success: the platform records the run, it does not perform it, and the
        // response says so rather than leaving a reader to assume otherwise.
        Assert.StartsWith(
            "Recorded.",
            run.GetProperty("platformRole").GetString() ?? string.Empty,
            StringComparison.Ordinal);

        // Recording a run moves the experiment on.
        Assert.Equal("Active", body.GetProperty("experiment").GetProperty("status").GetString());
        Assert.Equal(Experiment.MaximumRuns, body.GetProperty("quota").GetProperty("maximum").GetInt32());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0111")]
    public async Task Ch1RndFr0002_ARunWithoutCompleteProvenanceIsRefused()
    {
        using var researcher = Researcher("USR-RND-PROV");
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);
        var experimentId = experiment.GetProperty("experimentId").GetGuid();

        using var noModel = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs",
            new
            {
                configurationReference = "git:x",
                configurationSha256 = Hash("c"),
                modelReference = "  ",
                inputReference = "dataset:x",
                inputSha256 = Hash("i"),
                resultSummary = "ok",
                resultSha256 = Hash("r"),
                startedAt = DateTimeOffset.UtcNow.AddMinutes(-5),
                finishedAt = DateTimeOffset.UtcNow,
            },
            TestContext.Current.CancellationToken);
        var missing = await noModel.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RUN_MODEL_REQUIRED", missing.GetProperty("code").GetString());

        using var badHash = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs",
            new
            {
                configurationReference = "git:x",
                configurationSha256 = "not-a-hash",
                modelReference = "model:x",
                inputReference = "dataset:x",
                inputSha256 = Hash("i"),
                resultSummary = "ok",
                resultSha256 = Hash("r"),
                startedAt = DateTimeOffset.UtcNow.AddMinutes(-5),
                finishedAt = DateTimeOffset.UtcNow,
            },
            TestContext.Current.CancellationToken);
        var invalid = await badHash.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RUN_CONFIGURATION_HASH_INVALID", invalid.GetProperty("code").GetString());

        // A run that finishes before it starts records an interval that never happened.
        using var inverted = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs",
            new
            {
                configurationReference = "git:x",
                configurationSha256 = Hash("c"),
                modelReference = "model:x",
                inputReference = "dataset:x",
                inputSha256 = Hash("i"),
                resultSummary = "ok",
                resultSha256 = Hash("r"),
                startedAt = DateTimeOffset.UtcNow,
                finishedAt = DateTimeOffset.UtcNow.AddMinutes(-5),
            },
            TestContext.Current.CancellationToken);
        var invertedBody = await inverted.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RUN_INTERVAL_INVALID", invertedBody.GetProperty("code").GetString());

        // And a complete, well-ordered run is accepted.
        using var accepted = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs",
            RunBody("complete"),
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, accepted.StatusCode);
    }

    /// <summary>
    /// CH1-VVT-TC-0112: promotion requires approved change and verification records, and
    /// direct experiment-to-hardware attempts are rejected.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0112")]
    public async Task Ch1VvtTc0112_PromotionIsARequestThatGrantsNothing()
    {
        using var researcher = Researcher("USR-RND-PROMOTE");
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);
        var experimentId = experiment.GetProperty("experimentId").GetGuid();

        // Nothing has run yet, so there is no result to promote.
        using var premature = await PromoteAsync(researcher, experimentId, TestContext.Current.CancellationToken);
        var prematureBody = await premature.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("EXPERIMENT_NO_RESULT_TO_PROMOTE", prematureBody.GetProperty("code").GetString());

        using var run = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs", RunBody("promote"), TestContext.Current.CancellationToken);
        run.EnsureSuccessStatusCode();

        // Missing change record, impact analysis or verification is refused.
        using var incomplete = await PromoteAsync(
            researcher, experimentId, TestContext.Current.CancellationToken, impactAnalysis: "  ");
        var incompleteBody = await incomplete.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("PROMOTION_IMPACT_ANALYSIS_REQUIRED", incompleteBody.GetProperty("code").GetString());

        // Step-up is required.
        using var noStepUp = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/promotion-requests",
            new { changeRecord = "CHG-0001", impactAnalysis = "IA-0001", verification = "VER-0001" },
            TestContext.Current.CancellationToken);
        var stepUpBody = await noStepUp.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_REQUIRED", stepUpBody.GetProperty("code").GetString());

        using var accepted = await PromoteAsync(researcher, experimentId, TestContext.Current.CancellationToken);
        var body = await accepted.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, accepted.StatusCode);

        // The request is a request. It approves nothing and grants nothing.
        Assert.Equal("PromotionRequested", body.GetProperty("outcome").GetString());
        Assert.False(body.GetProperty("approved").GetBoolean());
        Assert.Contains(
            "configuration control",
            body.GetProperty("approvalAuthority").GetString() ?? string.Empty,
            StringComparison.Ordinal);

        var promoted = body.GetProperty("experiment");
        Assert.Equal("PromotionRequested", promoted.GetProperty("status").GetString());
        Assert.Equal("CHG-0001", promoted.GetProperty("promotionChangeRecord").GetString());
        Assert.Equal("USR-RND-PROMOTE", promoted.GetProperty("promotionRequestedBy").GetString());
        // Untouched by the request: still a simulator experiment with no authority.
        Assert.Equal("Simulator", promoted.GetProperty("environment").GetString());
        Assert.False(promoted.GetProperty("productionAuthority").GetBoolean());
        Assert.False(promoted.GetProperty("promotionApproved").GetBoolean());

        // A second request while one is outstanding is refused, and no further run is
        // recorded against an experiment awaiting promotion.
        using var again = await PromoteAsync(researcher, experimentId, TestContext.Current.CancellationToken);
        var againBody = await again.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("EXPERIMENT_PROMOTION_ALREADY_REQUESTED", againBody.GetProperty("code").GetString());

        using var afterPromotion = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs", RunBody("late"), TestContext.Current.CancellationToken);
        var closed = await afterPromotion.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("EXPERIMENT_CLOSED_TO_RUNS", closed.GetProperty("code").GetString());
    }

    private static async Task<HttpResponseMessage> PromoteAsync(
        HttpClient client,
        Guid experimentId,
        CancellationToken cancellationToken,
        string changeRecord = "CHG-0001",
        string impactAnalysis = "IA-0001",
        string verification = "VER-0001")
    {
        using var request = new HttpRequestMessage(
            HttpMethod.Post, $"/api/v1/experiments/{experimentId}/promotion-requests")
        {
            Content = JsonContent.Create(new { changeRecord, impactAnalysis, verification }),
        };
        request.Headers.Add("X-CH1-Step-Up", await StepUpAsync(client, cancellationToken));
        return await client.SendAsync(request, cancellationToken);
    }

    [Fact]
    public async Task Ch1CybAcp0001_DefiningAndRunningRequireTheRdEngineerRole()
    {
        using var engineer = Client("USR-ENGINEER-RND", "Engineer");

        using var define = await engineer.PostAsJsonAsync(
            "/api/v1/experiments",
            new { objective = "Not my authority." },
            TestContext.Current.CancellationToken);
        var refusal = await define.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, define.StatusCode);
        Assert.Equal("AUTH_EXPERIMENT_DEFINITION", refusal.GetProperty("code").GetString());

        // An Engineer may still propose a promotion, which is what api_endpoints.json
        // states for that operation.
        using var researcher = Researcher("USR-RND-CROSS");
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);
        var experimentId = experiment.GetProperty("experimentId").GetGuid();
        using var run = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs", RunBody("cross"), TestContext.Current.CancellationToken);
        run.EnsureSuccessStatusCode();

        using var proposed = await PromoteAsync(engineer, experimentId, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, proposed.StatusCode);
    }

    [Fact]
    public async Task Ch1CybFr0001_AnExperimentInAnotherProjectIsIndistinguishableFromAbsent()
    {
        using var researcher = Researcher("USR-RND-SCOPE");
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);
        var experimentId = experiment.GetProperty("experimentId").GetGuid();

        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OTHER-RND");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "RDEngineer");

        using var existing = await outsider.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs", RunBody("probe"), TestContext.Current.CancellationToken);
        using var absent = await outsider.PostAsJsonAsync(
            $"/api/v1/experiments/{Guid.NewGuid()}/runs", RunBody("probe"), TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, existing.StatusCode);
        Assert.Equal(absent.StatusCode, existing.StatusCode);
    }

    /// <summary>
    /// ResearchBench being enabled unblocks the two links that were refused while it was
    /// a controlled 501: a conversation attached to an experiment, and capacity reserved
    /// for one. Neither grants the experiment any authority.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0101")]
    public async Task AnExperimentCanNowCarryAConversationAndHoldCapacity()
    {
        using var researcher = Researcher("USR-RND-LINKS");
        var experiment = await DefineAsync(researcher, TestContext.Current.CancellationToken);
        var experimentId = experiment.GetProperty("experimentId").GetGuid();

        var threadId = ContextThread.DeriveId(
            ProjectId, ContextObjectType.Experiment, experimentId.ToString());
        using var posted = await researcher.PostAsJsonAsync(
            $"/api/v1/context-threads/{threadId}/messages",
            new
            {
                body = "First sweep looks stable; second sweep queued.",
                objectType = "Experiment",
                objectId = experimentId.ToString(),
                scopeRoles = ResearcherScope,
            },
            TestContext.Current.CancellationToken);
        var thread = await posted.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, posted.StatusCode);
        Assert.Equal("Experiment", thread.GetProperty("thread").GetProperty("objectType").GetString());
        Assert.False(thread.GetProperty("message").GetProperty("controlAuthority").GetBoolean());

        // Capacity for an experiment, booked by the authority that holds that power.
        using var coordinator = Client("USR-COORDINATOR-RND", "OperationsCoordinator");
        using var view = await coordinator.GetAsync("/api/v1/resources", TestContext.Current.CancellationToken);
        var resources = await view.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var version = resources.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("resourceId").GetGuid() == Station)
            .GetProperty("version").GetInt64();

        using var request = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/resources/{Station}/reservations")
        {
            Content = JsonContent.Create(new
            {
                quantity = 1m,
                startsAt = new DateTimeOffset(2028, 6, 1, 8, 0, 0, TimeSpan.Zero),
                endsAt = new DateTimeOffset(2028, 6, 1, 12, 0, 0, TimeSpan.Zero),
                experimentId,
            }),
        };
        request.Headers.TryAddWithoutValidation("If-Match", $"\"{version}\"");
        using var grant = await coordinator.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "ResourceAllocation" }, TestContext.Current.CancellationToken);
        var grantBody = await grant.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        request.Headers.Add("X-CH1-Step-Up", grantBody.GetProperty("grantId").GetGuid().ToString());

        using var reserved = await coordinator.SendAsync(request, TestContext.Current.CancellationToken);
        var allocation = await reserved.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, reserved.StatusCode);
        Assert.Equal(experimentId, allocation.GetProperty("experimentId").GetGuid());
        Assert.Equal(JsonValueKind.Null, allocation.GetProperty("workOrderId").ValueKind);
        Assert.Contains(
            "starts no equipment",
            allocation.GetProperty("physicalEffect").GetString() ?? string.Empty,
            StringComparison.Ordinal);
    }
}
