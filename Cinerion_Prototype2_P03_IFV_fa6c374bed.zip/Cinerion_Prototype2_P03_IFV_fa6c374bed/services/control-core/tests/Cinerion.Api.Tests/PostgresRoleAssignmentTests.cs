// The role history table, attacked directly as the app's own database role.

using Cinerion.Domain.Identity;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Persistence;
using Npgsql;

namespace Cinerion.Api.Tests;

/// <summary>
/// The role assignment register, attacked directly as the application role.
/// <para>
/// The point of migration 0012 is not that the service writes a row. It is that once
/// written the row cannot be changed by anything the application can do, cannot be seen
/// from another project, and cannot carry a retention that disagrees with the entity
/// register. Those are properties of the database, so they are asserted against the
/// database rather than against the code that usually talks to it - as
/// <c>cinerion_app</c>, never as the bootstrap owner, because the owner is a superuser and
/// bypasses every row-level security policy.
/// </para>
/// <para>
/// Skipped unless CINERION_POSTGRES_CONNECTION is set, on the same terms as the other
/// PostgreSQL tests: a skipped gate is never reported as passed.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0006, CH1-CYB-FR-0001, CH1-TRC-FR-0002</requirements>
public sealed class PostgresRoleAssignmentTests
{
    private static string? ConnectionString =>
        Environment.GetEnvironmentVariable("CINERION_POSTGRES_CONNECTION");

    private static bool Available => !string.IsNullOrWhiteSpace(ConnectionString);

    private static async Task<CinerionDataSource> ConnectAsync(
        ProjectScope scope,
        CancellationToken cancellationToken)
    {
        var source = new CinerionDataSource(ConnectionString!, scope);
        var migrations = await Task
            .WhenAll(PostgresRowLevelSecurityTests.MigrationPaths()
                .Select(path => File.ReadAllTextAsync(path, cancellationToken)))
            .ConfigureAwait(false);
        await source.EnsureSchemaAsync(migrations, cancellationToken).ConfigureAwait(false);
        return source;
    }

    private static async Task<Guid> SeedProjectAsync(
        CinerionDataSource source,
        Guid projectId,
        CancellationToken cancellationToken)
    {
        await using var connection = await source.OpenForProjectAsync(projectId, cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.projects(project_id, project_code, name, baseline, version)
            VALUES($1, $2, 'Role assignment register test', 'P03/IFV', 1)
            ON CONFLICT (project_id) DO NOTHING
            """;
        command.Parameters.Add(new NpgsqlParameter { Value = projectId });
        command.Parameters.Add(new NpgsqlParameter
        {
            Value = $"CH1-RA{projectId.ToString("N")[..8].ToUpperInvariant()}",
        });
        await command.ExecuteNonQueryAsync(cancellationToken);
        return projectId;
    }

    private static RoleAssignmentRecord Assignment(Guid projectId, string subject, DateTimeOffset now) =>
        RoleAssignmentRecord.Record(
            Guid.CreateVersion7(),
            projectId,
            new IdentityUser(subject, "register-subject", null, true, projectId, [], ["Viewer"],
                ActorKind.Human, now.AddDays(-1)),
            ["Viewer"],
            ["Viewer", "Inspector"],
            "USR-REGISTER-ADMIN",
            "Test directory",
            Guid.CreateVersion7(),
            now);

    /// <summary>
    /// Written, and readable back as what it said - which is the whole difference from the
    /// audit chain, where only a hash of the payload survives.
    /// </summary>
    [Fact]
    public async Task Ch1IamFr0004_TheRegisterIsReadableBackAndNotOnlyVerifiable()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var record = Assignment(project, "USR-REGISTER-01", DateTimeOffset.UtcNow);
        await store.SaveRoleAssignmentAsync(record, cancellationToken);

        var history = await store.ListRoleAssignmentsAsync(project, "USR-REGISTER-01", 10, cancellationToken);
        var stored = Assert.Single(history);
        Assert.Equal(record.AssignmentId, stored.AssignmentId);
        Assert.Equal(["Viewer"], stored.PreviousRoles);
        Assert.Equal(["Viewer", "Inspector"], stored.CurrentRoles);
        Assert.Equal(["Inspector"], stored.GrantedRoles);
        Assert.Empty(stored.WithdrawnRoles);
        Assert.Equal("Test directory", stored.Provider);
    }

    /// <summary>
    /// The same identifier twice is two events, and the second must be refused rather than
    /// overwriting the first.
    /// </summary>
    [Fact]
    public async Task Ch1TrcFr0002_RecordingTheSameAssignmentTwiceIsRefused()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var record = Assignment(project, "USR-REGISTER-02", DateTimeOffset.UtcNow);
        await store.SaveRoleAssignmentAsync(record, cancellationToken);

        var error = await Assert.ThrowsAsync<Cinerion.Domain.Common.DomainRuleException>(
            async () => await store.SaveRoleAssignmentAsync(record, cancellationToken));
        Assert.Equal("ROLE_ASSIGNMENT_ALREADY_RECORDED", error.Code);
    }

    /// <summary>
    /// The attack. As the application role, the register must be beyond changing and
    /// beyond deleting: a security-sensitive record that could be rewritten afterwards
    /// evidences nothing.
    /// </summary>
    [Fact]
    public async Task Ch1IamFr0006_TheApplicationRoleCanNeitherRewriteNorDeleteTheRegister()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        var record = Assignment(project, "USR-REGISTER-03", DateTimeOffset.UtcNow);
        await store.SaveRoleAssignmentAsync(record, cancellationToken);

        await using var connection = await source.OpenForProjectAsync(project, cancellationToken);

        // Two independent refusals stand between the application and this register, and
        // the assertion accepts either, by name. The migration REVOKEs UPDATE and DELETE,
        // so PostgreSQL refuses for want of privilege before a row is ever examined; the
        // immutability trigger refuses the mutation itself if a later migration ever
        // widened the grant again. Demanding one specific refusal would make the test fail
        // when the *stronger* of the two is in force - which is exactly what it did, and
        // is how the missing REVOKE was found: 0002 sets ALTER DEFAULT PRIVILEGES granting
        // all four verbs on every new table in the schema, so 0012's GRANT of two of them
        // changed nothing and only the trigger was holding the line.
        await AssertRefusedAsync(
            connection, "UPDATE ch1.role_assignments SET assigned_by = 'somebody-else' WHERE assignment_id = $1",
            record.AssignmentId, cancellationToken);
        await AssertRefusedAsync(
            connection, "DELETE FROM ch1.role_assignments WHERE assignment_id = $1",
            record.AssignmentId, cancellationToken);

        // And the grant itself, read from the catalogue rather than inferred from the
        // refusals: a privilege the application does not hold is a privilege no defect in
        // the application can misuse, and that is a stronger statement than a trigger.
        await using var privileges = connection.CreateCommand();
        privileges.CommandText = """
            SELECT count(*) FROM information_schema.table_privileges
            WHERE grantee = 'cinerion_app' AND table_schema = 'ch1'
              AND table_name = 'role_assignments' AND privilege_type IN ('UPDATE', 'DELETE')
            """;
        Assert.Equal(
            0L,
            Convert.ToInt64(
                await privileges.ExecuteScalarAsync(cancellationToken),
                System.Globalization.CultureInfo.InvariantCulture));
    }

    private static async Task AssertRefusedAsync(
        NpgsqlConnection connection,
        string sql,
        Guid assignmentId,
        CancellationToken cancellationToken)
    {
        var error = await Assert.ThrowsAsync<PostgresException>(async () =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = sql;
            command.Parameters.Add(new NpgsqlParameter { Value = assignmentId });
            await command.ExecuteNonQueryAsync(cancellationToken);
        });

        Assert.True(
            error.MessageText.Contains("immutable", StringComparison.OrdinalIgnoreCase)
            || error.SqlState == PostgresErrorCodes.InsufficientPrivilege,
            $"'{sql}' was refused with '{error.SqlState}: {error.MessageText}', which is " +
            "neither the immutability trigger nor a missing privilege");
    }

    /// <summary>
    /// A retention that disagrees with the entity register is refused by the database.
    /// entities.json says seven years, and a row saying anything else would make the
    /// declared policy unenforceable by anything that later reads the data.
    /// </summary>
    [Fact]
    public async Task Ch1DbaDd0001_ARetentionThatDisagreesWithTheRegisterIsRefused()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var project = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(project);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, project, cancellationToken);

        await using var connection = await source.OpenForProjectAsync(project, cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.role_assignments(
                assignment_id, project_id, subject_user_id, subject_username,
                previous_roles, current_roles, granted_roles, withdrawn_roles,
                assigned_by, assigned_at, provider, correlation_id, retain_until)
            VALUES($1, $2, 'USR-REGISTER-04', 'register-subject',
                   '[]'::jsonb, '["Viewer"]'::jsonb, '["Viewer"]'::jsonb, '[]'::jsonb,
                   'USR-REGISTER-ADMIN', now(), 'Test directory', $3, now() + interval '1 day')
            """;
        command.Parameters.Add(new NpgsqlParameter { Value = Guid.CreateVersion7() });
        command.Parameters.Add(new NpgsqlParameter { Value = project });
        command.Parameters.Add(new NpgsqlParameter { Value = Guid.CreateVersion7() });

        var error = await Assert.ThrowsAsync<PostgresException>(
            async () => await command.ExecuteNonQueryAsync(cancellationToken));
        Assert.Equal(PostgresErrorCodes.CheckViolation, error.SqlState);
    }

    /// <summary>
    /// Row-level security governs the register like every other controlled table: one
    /// project's role history is not another's to read.
    /// </summary>
    [Fact]
    public async Task Ch1CybFr0001_OneProjectsRoleHistoryIsInvisibleToAnother()
    {
        Assert.SkipUnless(Available, "CINERION_POSTGRES_CONNECTION is not set.");
        var cancellationToken = TestContext.Current.CancellationToken;
        var mine = Guid.NewGuid();
        var theirs = Guid.NewGuid();

        var scope = new ProjectScope();
        scope.Set(mine);
        await using var source = await ConnectAsync(scope, cancellationToken);
        await SeedProjectAsync(source, mine, cancellationToken);
        await SeedProjectAsync(source, theirs, cancellationToken);

        var store = new PostgresCinerionStore(source, new StepUpGrantCache());
        await store.SaveRoleAssignmentAsync(
            Assignment(mine, "USR-REGISTER-05", DateTimeOffset.UtcNow), cancellationToken);

        Assert.Single(await store.ListRoleAssignmentsAsync(mine, "USR-REGISTER-05", 10, cancellationToken));
        Assert.Empty(await store.ListRoleAssignmentsAsync(theirs, "USR-REGISTER-05", 10, cancellationToken));
    }
}
