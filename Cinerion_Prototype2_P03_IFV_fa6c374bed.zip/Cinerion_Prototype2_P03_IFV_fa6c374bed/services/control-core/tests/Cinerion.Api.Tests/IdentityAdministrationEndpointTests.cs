// Tests for user admin and session revocation over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// User administration and session revocation over HTTP.
/// <para>
/// The test host runs with no identity provider configured, which is itself the case
/// worth proving: the development identity scheme has no directory behind it, and these
/// operations must refuse rather than answer a security question with invented data.
/// The live-provider behaviour is verified against the running Keycloak lab and recorded
/// in docs/implementation/PROTOTYPE2_PROGRESS.md.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0008, CH1-CYB-ACP-0001</requirements>
public sealed class IdentityAdministrationEndpointTests(CinerionApiFactory factory)
    : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly string[] ViewerAndEngineer = ["Viewer", "Engineer"];

    private HttpClient Client(string actorId, string roles, string strength = "StepUpPhishingResistant")
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private HttpClient Administrator() => Client("USR-SYSADMIN-01", "SystemAdministrator");

    private static async Task<string> StepUpAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "RoleAssignment" }, cancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("grantId").GetGuid().ToString();
    }

    /// <summary>
    /// The fail-closed property. An unconfigured directory refuses; it never reports an
    /// empty user list, which would read as a project with no people rather than a
    /// service that cannot see any.
    /// </summary>
    [Fact]
    public async Task WithoutAnIdentityProviderEveryOperationRefusesRatherThanAnsweringEmpty()
    {
        using var administrator = Administrator();

        using var list = await administrator.GetAsync("/api/v1/users", TestContext.Current.CancellationToken);
        var body = await list.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, list.StatusCode);
        Assert.Equal("IDENTITY_PROVIDER_NOT_CONFIGURED", body.GetProperty("code").GetString());
        // And specifically not an empty page.
        Assert.False(body.TryGetProperty("items", out _));

        using var revoke = await administrator.DeleteAsync(
            "/api/v1/auth/sessions/whatever", TestContext.Current.CancellationToken);
        var revokeBody = await revoke.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("IDENTITY_PROVIDER_NOT_CONFIGURED", revokeBody.GetProperty("code").GetString());
    }

    /// <summary>
    /// Authority is checked before the provider is consulted, so a caller without the
    /// role is refused for the right reason rather than being told the provider is
    /// missing.
    /// </summary>
    [Fact]
    public async Task Ch1CybAcp0001_ListingUsersRequiresTheSystemAdministratorRole()
    {
        using var engineer = Client("USR-ENGINEER-ID", "Engineer");

        using var response = await engineer.GetAsync("/api/v1/users", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_USER_ADMINISTRATION", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// access.json requires hardware-backed MFA to manage users, which this codebase
    /// maps to the phishing-resistant authenticator class. A step-up proved only at MFA
    /// strength is not enough.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_ChangingRolesRequiresAPhishingResistantStepUp()
    {
        using var administrator = Administrator();

        // No grant at all.
        using var none = await administrator.PutAsJsonAsync(
            "/api/v1/users/kc-user-1/roles",
            new { roles = ViewerAndEngineer },
            TestContext.Current.CancellationToken);
        var noneBody = await none.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_REQUIRED", noneBody.GetProperty("code").GetString());

        // A grant proved only at MFA strength.
        using var weak = Client("USR-SYSADMIN-WEAK", "SystemAdministrator", strength: "Mfa");
        using var request = new HttpRequestMessage(HttpMethod.Put, "/api/v1/users/kc-user-1/roles")
        {
            Content = JsonContent.Create(new { roles = ViewerAndEngineer }),
        };
        request.Headers.Add("X-CH1-Step-Up", await StepUpAsync(weak, TestContext.Current.CancellationToken));
        using var weakResponse = await weak.SendAsync(request, TestContext.Current.CancellationToken);
        var weakBody = await weakResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_STRONGER_AUTHENTICATOR_REQUIRED", weakBody.GetProperty("code").GetString());
    }

    /// <summary>
    /// A step-up granted for one purpose cannot authorise another. Proving recent
    /// authentication to release a part must not also let the same session change roles.
    /// </summary>
    [Fact]
    public async Task Ch1IamFr0004_AStepUpForAnotherPurposeIsRefused()
    {
        using var administrator = Administrator();
        using var grant = await administrator.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "PartRelease" }, TestContext.Current.CancellationToken);
        var grantBody = await grant.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        using var request = new HttpRequestMessage(HttpMethod.Put, "/api/v1/users/kc-user-1/roles")
        {
            Content = JsonContent.Create(new { roles = ViewerAndEngineer }),
        };
        request.Headers.Add("X-CH1-Step-Up", grantBody.GetProperty("grantId").GetGuid().ToString());
        using var response = await administrator.SendAsync(request, TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal("STEP_UP_PURPOSE_MISMATCH", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// api_endpoints.json gives session revocation to the "session owner or Identity
    /// Administrator" and, unlike role assignment, requires no step-up: someone who
    /// believes their session is compromised must be able to end it immediately.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1IamFr0006_RevokingAnotherIdentitySessionRequiresTheAdministratorRole()
    {
        using var viewer = Client("USR-VIEWER-ID", "Viewer");

        using var response = await viewer.DeleteAsync(
            "/api/v1/auth/sessions/someone-elses-session", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_SESSION_REVOCATION", body.GetProperty("code").GetString());

        // Revoking one's own session is not an administrative act, so it passes the
        // authority check and reaches the provider — which, being unconfigured here,
        // refuses for that reason instead.
        using var own = await viewer.DeleteAsync(
            "/api/v1/auth/sessions/session-USR-VIEWER-ID", TestContext.Current.CancellationToken);
        var ownBody = await own.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("IDENTITY_PROVIDER_NOT_CONFIGURED", ownBody.GetProperty("code").GetString());
    }

    [Fact]
    public async Task TheUserListIsStillGatedBehindAuthentication()
    {
        using var anonymous = factory.CreateClient();

        using var response = await anonymous.GetAsync("/api/v1/users", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
