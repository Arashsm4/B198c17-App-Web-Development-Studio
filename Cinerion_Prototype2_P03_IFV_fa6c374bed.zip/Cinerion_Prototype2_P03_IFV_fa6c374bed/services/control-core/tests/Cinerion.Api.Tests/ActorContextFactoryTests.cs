// Tests that both login schemes end up with the same identity shape.

using System.Security.Claims;
using Cinerion.Api.Security;
using Microsoft.Extensions.DependencyInjection;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Tests;

/// <summary>
/// Verifies the CH1 identity claim contract that both authentication schemes must
/// satisfy. These are negative-first: the failure modes here are the ones that would
/// silently widen authority rather than produce a visible error.
/// </summary>
public sealed class ActorContextFactoryTests
{
    private static readonly Guid ProjectId = Guid.Parse("6f5c1f2e-9a11-4f0c-9d6b-1f7a2c3d4e50");
    private static readonly Guid CellId = Guid.Parse("2b8e7d31-45aa-4c19-8f02-7c9e1a5b6d33");

    // No ProjectScope registered: these tests exercise claim interpretation only, and
    // the factory must work whether or not a database scope is present.
    private readonly ActorContextFactory _factory = new(new ServiceCollection().BuildServiceProvider());

    /// <summary>
    /// A Keycloak access token keeps its original claim names because
    /// MapInboundClaims is disabled, and carries roles in the flat "roles" array
    /// produced by the realm role mapper.
    /// </summary>
    private static ClaimsPrincipal KeycloakPrincipal(params Claim[] claims) =>
        new(new ClaimsIdentity(
            claims,
            authenticationType: "Bearer",
            nameType: ActorContextFactory.ClaimNames.Subject,
            roleType: ActorContextFactory.ClaimNames.Role));

    [Fact]
    [VerificationCase("CH1-VVT-TC-0001")]
    [VerificationCase("CH1-VVT-TC-0008")]
    public void Ch1IamFr0008_OidcTokenProducesFullyScopedActorContext()
    {
        var actor = _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Subject, "kc-user-0001"),
            new Claim(ActorContextFactory.ClaimNames.SessionId, "session-abc"),
            new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString()),
            new Claim(ActorContextFactory.ClaimNames.Cell, CellId.ToString()),
            new Claim(ActorContextFactory.ClaimNames.Role, CinerionRoles.Engineer),
            new Claim(ActorContextFactory.ClaimNames.Role, CinerionRoles.Inspector)));

        Assert.Equal("kc-user-0001", actor.ActorId);
        Assert.Equal(ProjectId, actor.ProjectId);
        Assert.Equal("session-abc", actor.SessionId);
        Assert.True(actor.CanAccessCell(CellId));
        Assert.True(actor.HasRole(CinerionRoles.Engineer));
        Assert.True(actor.HasRole(CinerionRoles.Inspector));
        Assert.Equal(ActorKind.Human, actor.Kind);
    }

    /// <summary>
    /// Regression guard for the development scheme, which issues ClaimTypes.Role.
    /// Roles must be read through each identity's own RoleClaimType, not one fixed
    /// claim type, or one of the two schemes silently produces no roles at all.
    /// </summary>
    [Fact]
    public void Ch1IamFr0008_DevelopmentSchemeRolesAreStillRecognised()
    {
        var principal = new ClaimsPrincipal(new ClaimsIdentity(
            [
                new Claim(ClaimTypes.NameIdentifier, "dev-actor"),
                new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString()),
                new Claim(ClaimTypes.Role, CinerionRoles.Auditor),
            ],
            DevelopmentAuthenticationHandler.SchemeName));

        var actor = _factory.Create(principal);

        Assert.True(actor.HasRole(CinerionRoles.Auditor));
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0001")]
    public void Ch1IamFr0001_TokenWithoutProjectScopeIsRejected()
    {
        var error = Assert.Throws<DomainRuleException>(() => _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Subject, "kc-user-0002"),
            new Claim(ActorContextFactory.ClaimNames.Role, CinerionRoles.Engineer))));

        Assert.Equal("AUTH_PROJECT_SCOPE_REQUIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0001")]
    public void Ch1IamFr0001_TokenWithoutSubjectIsRejected()
    {
        var error = Assert.Throws<DomainRuleException>(() => _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString()))));

        Assert.Equal("AUTH_IDENTITY_REQUIRED", error.Code);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0008")]
    public void Ch1IamFr0008_MalformedCellScopeIsRejectedRatherThanIgnored()
    {
        var error = Assert.Throws<DomainRuleException>(() => _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Subject, "kc-user-0003"),
            new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString()),
            new Claim(ActorContextFactory.ClaimNames.Cell, "not-a-uuid"))));

        Assert.Equal("AUTH_CELL_SCOPE_INVALID", error.Code);
    }

    [Fact]
    public void Ch1IamFr0004_OidcSessionDefaultsToSingleFactor()
    {
        var actor = _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Subject, "kc-user-0004"),
            new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString())));

        Assert.Equal(AuthenticationStrength.SingleFactor, actor.AuthenticationStrength);
    }

    [Fact]
    public void Ch1IamFr0004_MultiFactorAuthenticationMethodRaisesStrengthToMfa()
    {
        var actor = _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Subject, "kc-user-0005"),
            new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString()),
            new Claim(ActorContextFactory.ClaimNames.AuthenticationMethods, "otp")));

        Assert.Equal(AuthenticationStrength.Mfa, actor.AuthenticationStrength);
    }

    /// <summary>
    /// The independent-release gate in CH1-QMS-FR-0005 requires phishing-resistant
    /// step-up. A hardware-key authentication method proves the authenticator class
    /// but not recency, so it must not by itself satisfy that gate. Step-up stays a
    /// controlled 501 until it is implemented with an auth_time recency check.
    /// </summary>
    [Fact]
    public void Ch1IamFr0004_HardwareKeyMethodAloneDoesNotGrantStepUp()
    {
        var actor = _factory.Create(KeycloakPrincipal(
            new Claim(ActorContextFactory.ClaimNames.Subject, "kc-user-0006"),
            new Claim(ActorContextFactory.ClaimNames.Project, ProjectId.ToString()),
            new Claim(ActorContextFactory.ClaimNames.AuthenticationMethods, "hwk")));

        Assert.Equal(AuthenticationStrength.Mfa, actor.AuthenticationStrength);
        Assert.True(actor.AuthenticationStrength < AuthenticationStrength.StepUpPhishingResistant);
    }
}
