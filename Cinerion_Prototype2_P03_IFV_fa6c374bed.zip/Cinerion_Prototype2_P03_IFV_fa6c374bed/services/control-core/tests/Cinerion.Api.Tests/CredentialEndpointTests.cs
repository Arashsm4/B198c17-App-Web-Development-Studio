// Tests for passkey and TOTP operations over HTTP.

using System.Buffers.Binary;
using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// The five authenticator operations over HTTP: TOTP enrolment, a passkey challenge,
/// the assertion that answers it, and registering and revoking a physical credential.
/// </summary>
/// <remarks>
/// These were implemented with domain tests only, so the whole HTTP layer above them —
/// authority, step-up redemption, the shape of what is disclosed and what is withheld —
/// had never been executed. The passkey path here is a genuine assertion: a real P-256
/// key signs real authenticator data over the challenge the platform issued, so what
/// passes is evidence about the endpoint rather than about a stub.
/// </remarks>
/// <requirements>CH1-IAM-FR-0003, CH1-IAM-FR-0004, CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-CYB-IAM-0001</requirements>
public sealed class CredentialEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;

    /// <summary>The relying party CredentialEndpoints falls back to when unconfigured.</summary>
    private const string RpId = "localhost";
    private const string Origin = "http://localhost:19006";

    private HttpClient Client(string actorId, string roles, CinerionApiFactory? host = null)
    {
        var client = (host ?? factory).CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(System.Globalization.CultureInfo.InvariantCulture));
        return client;
    }

    private static async Task<Guid> StepUpAsync(HttpClient client) =>
        (await StepUpWithChallengeAsync(client)).GrantId;

    /// <summary>
    /// The grant AND the nonce it binds. api_endpoints.json makes the control on
    /// <c>POST /api/v1/auth/step-up</c> "Purpose-bound challenge, short TTL and audit",
    /// and the challenge is what a registration's proof of possession is made against.
    /// </summary>
    private static async Task<(Guid GrantId, byte[] Challenge, string RpId, string Origin)>
        StepUpWithChallengeAsync(HttpClient client, string? purpose = null)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = purpose ?? StepUpPurpose.CredentialAdministration },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return (
            body.GetProperty("grantId").GetGuid(),
            Base64Url.Decode(body.GetProperty("challenge").GetString()!),
            body.GetProperty("rpId").GetString()!,
            body.GetProperty("origin").GetString()!);
    }

    private static Task<HttpResponseMessage> SendAsync(
        HttpClient client, HttpMethod method, string path, object? payload, Guid? grantId)
    {
        var request = new HttpRequestMessage(method, path);
        if (payload is not null)
        {
            request.Content = JsonContent.Create(payload);
        }

        if (grantId is not null)
        {
            request.Headers.Add("X-CH1-Step-Up", grantId.Value.ToString());
        }

        return client.SendAsync(request, TestContext.Current.CancellationToken);
    }

    private static async Task<JsonElement> BodyAsync(HttpResponseMessage response) =>
        await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

    // ----------------------------------------------------------------- TOTP

    /// <summary>
    /// api_endpoints.json makes "secret shown once and encrypted storage" the control.
    /// The disclosure is asserted here, and so is the consequence of it being the only
    /// one: a second enrolment while the first is live is refused rather than quietly
    /// issuing a seed the holder now has two of.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0003")]
    public async Task Ch1IamFr0003_TotpEnrolmentDisclosesItsSecretOnceAndRefusesASecond()
    {
        using var isolated = new CinerionApiFactory();
        using var operatorClient = Client("USR-TOTP-SELF-01", "Inspector", isolated);

        using var created = await SendAsync(
            operatorClient, HttpMethod.Post, "/api/v1/auth/totp/enrolments",
            new { Label = "Phone authenticator" }, await StepUpAsync(operatorClient));

        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var body = await BodyAsync(created);
        var secret = body.GetProperty("sharedSecret").GetString();

        Assert.False(string.IsNullOrWhiteSpace(secret));
        Assert.Equal("Totp", body.GetProperty("kind").GetString());
        Assert.Equal("USR-TOTP-SELF-01", body.GetProperty("subjectId").GetString());
        // RFC 6238 parameters travel with the seed, because an authenticator cannot be
        // configured from the seed alone.
        Assert.Equal(6, body.GetProperty("digits").GetInt32());
        Assert.Equal(30, body.GetProperty("periodSeconds").GetInt32());
        Assert.StartsWith("otpauth://totp/", body.GetProperty("otpauthUri").GetString(), StringComparison.Ordinal);
        // Said in the response, not left for the caller to discover at a release gate.
        Assert.False(body.GetProperty("phishingResistant").GetBoolean());
        Assert.Contains("shown once", body.GetProperty("disclosure").GetString(), StringComparison.Ordinal);

        using var second = await SendAsync(
            operatorClient, HttpMethod.Post, "/api/v1/auth/totp/enrolments",
            new { Label = "Second phone" }, await StepUpAsync(operatorClient));

        Assert.Equal(HttpStatusCode.BadRequest, second.StatusCode);
        Assert.Equal(
            "CREDENTIAL_TOTP_ALREADY_ENROLLED",
            (await BodyAsync(second)).GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_TotpEnrolmentWithoutAStepUpGrantIsRefused()
    {
        using var operatorClient = Client("USR-TOTP-NOSTEP-01", "Inspector");

        using var response = await SendAsync(
            operatorClient, HttpMethod.Post, "/api/v1/auth/totp/enrolments", new { }, grantId: null);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("STEP_UP_REQUIRED", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    /// <summary>
    /// "Self or Identity Administrator" in the catalogue. An ordinary identity enrolling
    /// a second factor for somebody else would be enrolling an authenticator that person
    /// never saw.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0003")]
    public async Task Ch1IamFr0003_EnrollingForAnotherIdentityRequiresAnAdministrator()
    {
        using var operatorClient = Client("USR-TOTP-OTHER-01", "Inspector");

        using var response = await SendAsync(
            operatorClient, HttpMethod.Post, "/api/v1/auth/totp/enrolments",
            new { SubjectId = "USR-SOMEONE-ELSE-01" }, await StepUpAsync(operatorClient));

        // AUTH_ codes are 403 rather than 400: the request was well formed and the
        // caller simply may not do this.
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_CREDENTIAL_SUBJECT", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    // ------------------------------------------------ registration and revocation

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1IamFr0006_RegisteringACredentialRequiresTheCybersecurityAdministrator()
    {
        using var engineer = Client("USR-CRED-ENGINEER-01", "Engineer");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var step = await StepUpWithChallengeAsync(engineer);
        var registration = NewPasskeyRegistration(
            key, "USR-CRED-ENGINEER-01", step.Challenge, step.RpId, step.Origin);

        using var response = await SendAsync(
            engineer, HttpMethod.Post, "/api/v1/credentials", registration, step.GrantId);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.Equal("AUTH_CREDENTIAL_ADMINISTRATION", (await BodyAsync(response)).GetProperty("code").GetString());

        // The grant was not spent on a request that was always going to be refused, so a
        // caller who then obtains the right role can still use it. Role before step-up.
        using var administrator = Client("USR-CRED-ENGINEER-01", "CybersecurityAdministrator");
        using var retried = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials", registration, step.GrantId);

        Assert.Equal(HttpStatusCode.Created, retried.StatusCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_RegisteringACredentialWithoutAStepUpGrantIsRefused()
    {
        using var administrator = Client("USR-CRED-NOSTEP-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);

        using var response = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-NOSTEP-01", RandomNumberGenerator.GetBytes(32), RpId, Origin),
            grantId: null);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("STEP_UP_REQUIRED", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    /// <summary>
    /// CH1-IAM-FR-0006 requires credentials to be attributable and revocable. The
    /// revocation body is the evidence, which is why this operation answers 200 with a
    /// record rather than 204 with nothing.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1IamFr0006_RevocationRecordsWhoWhenAndWhyAndStatesWhatItDidNotDo()
    {
        using var administrator = Client("USR-CRED-REVOKE-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);

        var enrolment = await StepUpWithChallengeAsync(administrator);
        using var registered = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-HOLDER-01", enrolment.Challenge, enrolment.RpId, enrolment.Origin),
            enrolment.GrantId);
        Assert.Equal(HttpStatusCode.Created, registered.StatusCode);
        var credentialId = (await BodyAsync(registered)).GetProperty("credentialId").GetGuid();

        using var noStepUp = await SendAsync(
            administrator, HttpMethod.Delete,
            $"/api/v1/credentials/{credentialId}?reason=Lost", null, grantId: null);
        Assert.Equal(HttpStatusCode.BadRequest, noStepUp.StatusCode);
        Assert.Equal("STEP_UP_REQUIRED", (await BodyAsync(noStepUp)).GetProperty("code").GetString());

        using var revoked = await SendAsync(
            administrator, HttpMethod.Delete,
            $"/api/v1/credentials/{credentialId}?reason=Reported%20lost%20by%20the%20holder",
            null, await StepUpAsync(administrator));

        Assert.Equal(HttpStatusCode.OK, revoked.StatusCode);
        var body = await BodyAsync(revoked);
        Assert.Equal("Revoked", body.GetProperty("status").GetString());
        Assert.Equal("USR-CRED-REVOKE-01", body.GetProperty("revokedBy").GetString());
        Assert.Equal("Reported lost by the holder", body.GetProperty("revocationReason").GetString());
        Assert.NotEqual(default, body.GetProperty("revokedAt").GetDateTimeOffset());
        // Honest about the half it cannot reach: CH1-COM-IF-0004 puts the reader denylist
        // in the cell controller, which is not enabled.
        Assert.True(body.GetProperty("platformTrustWithdrawn").GetBoolean());
        Assert.False(body.GetProperty("readerDenylistUpdated").GetBoolean());
    }

    /// <summary>
    /// entities.json declares this record as authenticator metadata. The projection is
    /// where that promise is kept, so it is checked field by field rather than assumed.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0125")]
    public async Task Ch1CybFr0006_TheCredentialProjectionCarriesNoSecretMaterial()
    {
        using var administrator = Client("USR-CRED-PROJECTION-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);

        var enrolment = await StepUpWithChallengeAsync(administrator);
        using var registered = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-PROJECTION-02", enrolment.Challenge, enrolment.RpId, enrolment.Origin),
            enrolment.GrantId);

        Assert.Equal(HttpStatusCode.Created, registered.StatusCode);
        var raw = await registered.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);
        foreach (var forbidden in new[] { "privateKey", "secret", "seed", "sharedSecret", "publicKey" })
        {
            Assert.DoesNotContain(forbidden, raw, StringComparison.OrdinalIgnoreCase);
        }
    }

    // --------------------------------------------------------------- passkeys

    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public async Task Ch1IamFr0005_AChallengeIsRefusedForAnIdentityHoldingNoPasskey()
    {
        using var client = Client("USR-PASSKEY-NONE-01", "Inspector");

        using var response = await SendAsync(
            client, HttpMethod.Post, "/api/v1/auth/passkey/options",
            new { Purpose = StepUpPurpose.PartRelease }, grantId: null);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("PASSKEY_NOT_ENROLLED", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    /// <summary>
    /// The relying party is the whole point of a passkey. A caller that could name its
    /// own would obtain a challenge answerable from a site it controls.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public async Task Ch1CybIam0001_TheCallerCannotChooseTheRelyingPartyOrOrigin()
    {
        using var client = Client("USR-PASSKEY-RP-01", "Inspector");

        using var wrongRp = await SendAsync(
            client, HttpMethod.Post, "/api/v1/auth/passkey/options",
            new { Purpose = StepUpPurpose.PartRelease, RpId = "cinerion.evil.example" }, grantId: null);
        using var wrongOrigin = await SendAsync(
            client, HttpMethod.Post, "/api/v1/auth/passkey/options",
            new { Purpose = StepUpPurpose.PartRelease, Origin = "https://cinerion.evil.example" }, grantId: null);

        Assert.Equal("PASSKEY_RP_ID_NOT_PERMITTED", (await BodyAsync(wrongRp)).GetProperty("code").GetString());
        Assert.Equal("PASSKEY_ORIGIN_NOT_PERMITTED", (await BodyAsync(wrongOrigin)).GetProperty("code").GetString());
    }

    // ------------------------------------------------- proof of possession at enrolment

    /// <summary>
    /// api_endpoints.json makes the control on <c>POST /api/v1/credentials</c> "Proof of
    /// possession, unique identity and lifecycle record", and until now only the last two
    /// were implemented: the public key arrived as a request field and was stored. A
    /// Cybersecurity Administrator could therefore enrol any key at all — including one
    /// they held themselves — against any subject, and then use it. The audit event said
    /// <c>PROOF_OF_POSSESSION_RECORDED</c> about a proof nobody had made.
    /// <para>
    /// Recorded as conflict 13, which read the gap as "the catalogue has no passkey
    /// registration operation". It does not need one: CH1-CYB-IAM-0001 makes enrolment a
    /// controlled <em>ceremony</em> — "Enrolment verifies the person, assigns roles
    /// separately, records credential serial/public key and issues recovery material
    /// through a controlled ceremony" — and this operation is that ceremony. What was
    /// missing was the nonce to prove possession against, which is the "purpose-bound
    /// challenge" <c>POST /api/v1/auth/step-up</c> was already declared to issue and did
    /// not.
    /// </para>
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1IamFr0006_ARegistrationWithNoProofOfPossessionIsRefused()
    {
        using var administrator = Client("USR-CRED-NOPROOF-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var step = await StepUpWithChallengeAsync(administrator);

        // The old body shape, exactly: a public key and a handle as request fields.
        using var response = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            new
            {
                SubjectId = "USR-CRED-NOPROOF-02",
                Kind = nameof(CredentialKind.Passkey),
                Label = "Security key",
                PublicKey = Base64Url.Encode(CoseP256(key.ExportParameters(includePrivateParameters: false))),
                CredentialId = Base64Url.Encode(RandomNumberGenerator.GetBytes(16)),
                UserVerification = nameof(UserVerificationRequirement.Required),
            },
            step.GrantId);

        // 400 with a code, not 500 with a trace identifier: a body the operation no longer
        // accepts is an ordinary client mistake and has to say so.
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal(
            "CREDENTIAL_PROOF_OF_POSSESSION_REQUIRED",
            (await BodyAsync(response)).GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1CybIam0001_ARegistrationAnsweringAnotherChallengeIsRefused()
    {
        using var administrator = Client("USR-CRED-NONCE-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var step = await StepUpWithChallengeAsync(administrator);

        // Signed over a nonce this platform never issued. A registration harvested
        // elsewhere and presented here is exactly this shape.
        using var response = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-NONCE-02", RandomNumberGenerator.GetBytes(32), step.RpId, step.Origin),
            step.GrantId);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("PASSKEY_CHALLENGE_MISMATCH", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public async Task Ch1CybIam0001_ARegistrationProducedForAnotherOriginIsRefused()
    {
        using var administrator = Client("USR-CRED-PHISH-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var step = await StepUpWithChallengeAsync(administrator);

        // The challenge is the platform's own; only the origin is the attacker's. This is
        // the enrolment half of what makes a passkey phishing resistant, and it was not
        // checked at all before, because nothing about the enrolment was checked.
        using var response = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-PHISH-02", step.Challenge, step.RpId, "https://cinerion-portal.example"),
            step.GrantId);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("PASSKEY_ORIGIN_MISMATCH", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1CybIam0001_AnAuthenticationAssertionCannotBeReplayedAsAnEnrolment()
    {
        using var administrator = Client("USR-CRED-REPLAY-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var step = await StepUpWithChallengeAsync(administrator);

        var registration = new
        {
            SubjectId = "USR-CRED-REPLAY-02",
            Kind = nameof(CredentialKind.Passkey),
            Label = "Security key",
            AttestationObject = Base64Url.Encode(BuildAttestationObject(
                key, RandomNumberGenerator.GetBytes(16), step.RpId, userVerified: true,
                attestedCredentialData: true)),
            // webauthn.get, not webauthn.create.
            ClientDataJson = Base64Url.Encode(BuildClientData("webauthn.get", step.Challenge, step.Origin)),
            UserVerification = nameof(UserVerificationRequirement.Required),
        };

        using var response = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials", registration, step.GrantId);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal(
            "PASSKEY_CLIENT_DATA_TYPE_INVALID", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1CybIam0001_AnEnrolmentWithoutUserVerificationOrAKeyIsRefused()
    {
        using var administrator = Client("USR-CRED-UV-01", "CybersecurityAdministrator");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);

        // Presence alone. CH1-CYB-IAM-0001: "PIN/user verification is required according
        // to credential capability and risk", and enrolling an authenticator that has not
        // verified the person is enrolling it against a person nobody identified.
        var presenceOnly = await StepUpWithChallengeAsync(administrator);
        using var notVerified = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-UV-02", presenceOnly.Challenge, presenceOnly.RpId, presenceOnly.Origin,
                userVerified: false),
            presenceOnly.GrantId);

        Assert.Equal(HttpStatusCode.BadRequest, notVerified.StatusCode);
        Assert.Equal(
            "PASSKEY_USER_NOT_VERIFIED", (await BodyAsync(notVerified)).GetProperty("code").GetString());

        // And an attestation carrying no attested credential data presents no key at all,
        // which must be refused rather than read past the end of the buffer.
        var noKey = await StepUpWithChallengeAsync(administrator);
        using var empty = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, "USR-CRED-UV-03", noKey.Challenge, noKey.RpId, noKey.Origin,
                attestedCredentialData: false),
            noKey.GrantId);

        Assert.Equal(HttpStatusCode.BadRequest, empty.StatusCode);
        Assert.Equal(
            "PASSKEY_ATTESTED_CREDENTIAL_DATA_MISSING",
            (await BodyAsync(empty)).GetProperty("code").GetString());
    }

    /// <summary>
    /// The key that ends up on record is the one the authenticator minted, not one the
    /// request named — proved by authenticating with the private half afterwards and
    /// reaching a phishing-resistant grant, which only verifies against the enrolled
    /// public key.
    /// <para>
    /// A second registration of the same authenticator is refused, which is the "unique
    /// identity" half of the same control column.
    /// </para>
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task Ch1IamFr0006_TheEnrolledKeyComesFromTheAttestationAndTheHandleIsUniqueForever()
    {
        using var isolated = new CinerionApiFactory();
        var subject = "USR-CRED-ATTEST-01";
        using var administrator = Client("USR-CRED-ATTEST-ADMIN", "CybersecurityAdministrator", isolated);
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var handle = RandomNumberGenerator.GetBytes(16);

        var first = await StepUpWithChallengeAsync(administrator);
        using var registered = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(key, subject, first.Challenge, first.RpId, first.Origin, handle),
            first.GrantId);
        Assert.Equal(HttpStatusCode.Created, registered.StatusCode);

        // The handle the platform recorded is the one inside the attestation, not one the
        // request supplied — the request supplied none.
        var second = await StepUpWithChallengeAsync(administrator);
        using var again = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(key, "USR-CRED-ATTEST-02", second.Challenge, second.RpId,
                second.Origin, handle),
            second.GrantId);

        Assert.NotEqual(HttpStatusCode.Created, again.StatusCode);
        Assert.Equal("CREDENTIAL_ALREADY_ENROLLED", (await BodyAsync(again)).GetProperty("code").GetString());
    }

    /// <summary>
    /// The whole phishing-resistant route end to end over HTTP: a registered passkey, a
    /// challenge bound to the relying party, a genuine assertion signed by the enrolled
    /// key, and the grant that comes back. This is the path that makes an action needing
    /// phishing-resistant step-up reachable at all, and until now nothing executed it.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public async Task Ch1IamFr0005_AGenuineAssertionYieldsAPhishingResistantGrantAndTheChallengeIsSingleUse()
    {
        using var isolated = new CinerionApiFactory();
        var subject = "USR-PASSKEY-HOLDER-01";
        using var administrator = Client("USR-PASSKEY-ADMIN-01", "CybersecurityAdministrator", isolated);
        using var holder = Client(subject, "Inspector", isolated);
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var handle = RandomNumberGenerator.GetBytes(16);

        var enrolment = await StepUpWithChallengeAsync(administrator);
        using var registered = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, subject, enrolment.Challenge, enrolment.RpId, enrolment.Origin, handle),
            enrolment.GrantId);
        Assert.Equal(HttpStatusCode.Created, registered.StatusCode);
        Assert.True((await BodyAsync(registered)).GetProperty("phishingResistant").GetBoolean());

        using var options = await SendAsync(
            holder, HttpMethod.Post, "/api/v1/auth/passkey/options",
            new { Purpose = StepUpPurpose.PartRelease }, grantId: null);
        Assert.Equal(HttpStatusCode.OK, options.StatusCode);
        var challengeBody = await BodyAsync(options);

        Assert.Equal(RpId, challengeBody.GetProperty("rpId").GetString());
        Assert.Equal(Origin, challengeBody.GetProperty("origin").GetString());
        Assert.Equal(StepUpPurpose.PartRelease, challengeBody.GetProperty("purpose").GetString());
        // Required, not preferred: presence alone does not establish who touched the key.
        Assert.Equal("required", challengeBody.GetProperty("userVerification").GetString());
        Assert.True(challengeBody.GetProperty("singleUse").GetBoolean());
        Assert.Contains(
            challengeBody.GetProperty("allowCredentials").EnumerateArray(),
            item => item.GetProperty("id").GetString() == Base64Url.Encode(handle));

        var challengeId = challengeBody.GetProperty("challengeId").GetGuid();
        var challenge = Base64Url.Decode(challengeBody.GetProperty("challenge").GetString()!);

        using var verified = await SendAsync(
            holder, HttpMethod.Post, "/api/v1/auth/passkey/verify",
            Assertion(key, handle, challenge, Origin, RpId), grantId: null);

        Assert.Equal(HttpStatusCode.Created, verified.StatusCode);
        var grantBody = await BodyAsync(verified);
        Assert.Equal("StepUpPhishingResistant", grantBody.GetProperty("grantedStrength").GetString());
        Assert.Equal(StepUpPurpose.PartRelease, grantBody.GetProperty("purpose").GetString());
        Assert.True(grantBody.GetProperty("singleUse").GetBoolean());
        // No second kind of session is minted here; FortressGate owns sessions.
        Assert.Contains("FortressGate owns the session", grantBody.GetProperty("sessionEffect").GetString(), StringComparison.Ordinal);

        // Replay rejection is the control api_endpoints.json names on this operation.
        using var replayed = await SendAsync(
            holder, HttpMethod.Post, "/api/v1/auth/passkey/verify",
            Assertion(key, handle, challenge, Origin, RpId, challengeId), grantId: null);
        Assert.Equal(HttpStatusCode.BadRequest, replayed.StatusCode);
        Assert.Equal("PASSKEY_CHALLENGE_SPENT", (await BodyAsync(replayed)).GetProperty("code").GetString());

        object Assertion(
            ECDsa signer, byte[] credentialHandle, byte[] nonce, string origin, string rpId, Guid? id = null) =>
            BuildAssertion(signer, credentialHandle, nonce, origin, rpId, id ?? challengeId);
    }

    /// <summary>
    /// The same flow with one property spoiled: the browser reached a look-alike site, so
    /// the authenticator signed over that origin. Everything else is genuine.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0002")]
    public async Task Ch1CybIam0001_AnAssertionProducedForAnotherOriginIsRefusedOverHttp()
    {
        using var isolated = new CinerionApiFactory();
        var subject = "USR-PASSKEY-PHISH-01";
        using var administrator = Client("USR-PASSKEY-PHISH-ADMIN", "CybersecurityAdministrator", isolated);
        using var holder = Client(subject, "Inspector", isolated);
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var handle = RandomNumberGenerator.GetBytes(16);

        var enrolment = await StepUpWithChallengeAsync(administrator);
        using var registered = await SendAsync(
            administrator, HttpMethod.Post, "/api/v1/credentials",
            NewPasskeyRegistration(
                key, subject, enrolment.Challenge, enrolment.RpId, enrolment.Origin, handle),
            enrolment.GrantId);
        Assert.Equal(HttpStatusCode.Created, registered.StatusCode);

        using var options = await SendAsync(
            holder, HttpMethod.Post, "/api/v1/auth/passkey/options",
            new { Purpose = StepUpPurpose.PartRelease }, grantId: null);
        var challengeBody = await BodyAsync(options);
        var challengeId = challengeBody.GetProperty("challengeId").GetGuid();
        var challenge = Base64Url.Decode(challengeBody.GetProperty("challenge").GetString()!);

        using var response = await SendAsync(
            holder, HttpMethod.Post, "/api/v1/auth/passkey/verify",
            BuildAssertion(key, handle, challenge, "http://localhost:19006.evil.example", RpId, challengeId),
            grantId: null);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("PASSKEY_ORIGIN_MISMATCH", (await BodyAsync(response)).GetProperty("code").GetString());
    }

    // ---------------------------------------------------------------- fixtures

    /// <summary>
    /// A registration, built the way an authenticator builds one: an attestation object
    /// whose <c>authData</c> carries the relying-party hash, the user-present,
    /// user-verified and attested-credential-data flags, the credential handle and the
    /// COSE public key; and client data naming <c>webauthn.create</c>, the challenge the
    /// platform issued and the origin the browser reached.
    /// <para>
    /// Nothing here sends a public key as a request field, because
    /// <c>POST /api/v1/credentials</c> no longer accepts one. Its declared control is
    /// "Proof of possession", and the key it stores comes out of the attestation.
    /// </para>
    /// </summary>
    private static object NewPasskeyRegistration(
        ECDsa key,
        string subjectId,
        byte[] challenge,
        string rpId,
        string origin,
        byte[]? handle = null,
        bool userVerified = true,
        bool attestedCredentialData = true) => new
    {
        SubjectId = subjectId,
        Kind = nameof(CredentialKind.Passkey),
        Label = "Security key",
        AttestationObject = Base64Url.Encode(BuildAttestationObject(
            key, handle ?? RandomNumberGenerator.GetBytes(16), rpId, userVerified, attestedCredentialData)),
        ClientDataJson = Base64Url.Encode(BuildClientData("webauthn.create", challenge, origin)),
        UserVerification = nameof(UserVerificationRequirement.Required),
    };

    private static byte[] BuildClientData(string type, byte[] challenge, string origin) =>
        Encoding.UTF8.GetBytes(
            $$"""
            {"type":"{{type}}","challenge":"{{Base64Url.Encode(challenge)}}","origin":"{{origin}}"}
            """);

    /// <summary>
    /// The CBOR map <c>{fmt: "none", attStmt: {}, authData: h'...'}</c>. `fmt` and
    /// `attStmt` come first, so the reader under test has to step over a nested map to
    /// reach the entry it wants — which is the case a reader that only handled a fixed
    /// order would get wrong.
    /// </summary>
    private static byte[] BuildAttestationObject(
        ECDsa key, byte[] handle, string rpId, bool userVerified, bool attestedCredentialData)
    {
        var cose = CoseP256(key.ExportParameters(includePrivateParameters: false));

        var authData = new List<byte>();
        authData.AddRange(SHA256.HashData(Encoding.UTF8.GetBytes(rpId)));
        byte flags = 0x01;                                   // UP
        if (userVerified) flags |= 0x04;                     // UV
        if (attestedCredentialData) flags |= 0x40;           // AT
        authData.Add(flags);
        authData.AddRange([0x00, 0x00, 0x00, 0x00]);         // sign count
        if (attestedCredentialData)
        {
            authData.AddRange(new byte[16]);                 // AAGUID
            authData.Add((byte)(handle.Length >> 8));
            authData.Add((byte)(handle.Length & 0xFF));
            authData.AddRange(handle);
            authData.AddRange(cose);
        }

        var attestation = new List<byte> { 0xA3 };           // map of 3
        attestation.AddRange(CborText("fmt"));
        attestation.AddRange(CborText("none"));
        attestation.AddRange(CborText("attStmt"));
        attestation.Add(0xA0);                               // empty map
        attestation.AddRange(CborText("authData"));
        attestation.AddRange(CborByteStringHead(authData.Count));
        attestation.AddRange(authData);
        return [.. attestation];
    }

    private static byte[] CborText(string value)
    {
        var bytes = Encoding.UTF8.GetBytes(value);
        return [(byte)(0x60 | bytes.Length), .. bytes];
    }

    private static byte[] CborByteStringHead(int length) =>
        length < 24 ? [(byte)(0x40 | length)]
        : length < 256 ? [0x58, (byte)length]
        : [0x59, (byte)(length >> 8), (byte)(length & 0xFF)];

    /// <summary>
    /// Everything an authenticator would produce, produced here: client data naming the
    /// type, challenge and origin the browser reached; authenticator data carrying the
    /// relying-party hash, the user-present and user-verified flags and a signature
    /// counter; and a real ECDSA signature over both.
    /// </summary>
    private static object BuildAssertion(
        ECDsa key, byte[] handle, byte[] challenge, string origin, string rpId, Guid challengeId)
    {
        var clientDataJson = Encoding.UTF8.GetBytes(
            $$"""
            {"type":"webauthn.get","challenge":"{{Base64Url.Encode(challenge)}}","origin":"{{origin}}"}
            """);

        var authenticatorData = new byte[37];
        SHA256.HashData(Encoding.UTF8.GetBytes(rpId)).CopyTo(authenticatorData, 0);
        authenticatorData[32] = 0x01 | 0x04;
        BinaryPrimitives.WriteUInt32BigEndian(authenticatorData.AsSpan(33, 4), 1);

        var payload = new byte[authenticatorData.Length + 32];
        authenticatorData.CopyTo(payload, 0);
        SHA256.HashData(clientDataJson).CopyTo(payload, authenticatorData.Length);

        return new
        {
            ChallengeId = challengeId,
            CredentialId = Base64Url.Encode(handle),
            AuthenticatorData = Base64Url.Encode(authenticatorData),
            ClientDataJson = Base64Url.Encode(clientDataJson),
            Signature = Base64Url.Encode(
                key.SignData(payload, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence)),
        };
    }

    /// <summary>
    /// Encodes an EC public key exactly as an authenticator would, in COSE:
    /// <c>{1: 2, 3: -7, -1: 1, -2: x, -3: y}</c>. Registration converts this to
    /// SubjectPublicKeyInfo itself, so sending SPKI here is refused - which is the
    /// point: the platform decides from the artefact rather than from a claim about it.
    /// </summary>
    private static byte[] CoseP256(ECParameters parameters)
    {
        var buffer = new List<byte> { 0xA5, 0x01, 0x02, 0x03, 0x26, 0x20, 0x01, 0x21, 0x58 };
        buffer.Add((byte)parameters.Q.X!.Length);
        buffer.AddRange(parameters.Q.X!);
        buffer.Add(0x22);
        buffer.Add(0x58);
        buffer.Add((byte)parameters.Q.Y!.Length);
        buffer.AddRange(parameters.Q.Y!);
        return [.. buffer];
    }

}
