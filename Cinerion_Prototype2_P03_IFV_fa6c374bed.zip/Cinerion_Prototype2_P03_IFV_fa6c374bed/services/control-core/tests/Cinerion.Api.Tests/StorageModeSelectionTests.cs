// Tests that the storage choice fails closed, whichever way you get it wrong.

using Cinerion.Infrastructure.Persistence;

namespace Cinerion.Api.Tests;

/// <summary>
/// The storage decision is fail-closed in every direction. Volatile storage must
/// never be reached by omission, because losing operational state silently is worse
/// than refusing to start.
/// </summary>
/// <requirements>CH1-OPS-FR-0002, CH1-DBA-FR-0001</requirements>
public sealed class StorageModeSelectionTests
{
    private const string Connection = "Host=localhost;Database=cinerion;Username=cinerion_app;Password=x";

    [Fact]
    public void UnsetModeInDevelopmentUsesInMemory()
    {
        var selection = StorageModeSelection.Resolve(null, null, isDevelopment: true);

        Assert.Equal(CinerionStorageMode.InMemory, selection.Mode);
    }

    /// <summary>
    /// The defect this closes: in-memory was the unconditional default, so a
    /// deployment that simply forgot to configure a database ran on volatile storage
    /// and lost its audit chain on restart without anything saying so.
    /// </summary>
    [Fact]
    public void UnsetModeOutsideDevelopmentIsRefused()
    {
        var error = Assert.Throws<InvalidOperationException>(
            () => StorageModeSelection.Resolve(null, null, isDevelopment: false));

        Assert.Contains("must be set explicitly", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void InMemoryOutsideDevelopmentIsRefusedEvenWhenAskedForExplicitly()
    {
        var error = Assert.Throws<InvalidOperationException>(
            () => StorageModeSelection.Resolve("InMemory", null, isDevelopment: false));

        Assert.Contains("development and test mode", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void PostgresWithoutAConnectionStringIsRefused()
    {
        var error = Assert.Throws<InvalidOperationException>(
            () => StorageModeSelection.Resolve("Postgres", null, isDevelopment: true));

        Assert.Contains("CINERION_POSTGRES_CONNECTION is required", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void AnUnknownModeIsRefusedRatherThanFallingBack()
    {
        var error = Assert.Throws<InvalidOperationException>(
            () => StorageModeSelection.Resolve("Sqlite", Connection, isDevelopment: true));

        Assert.Contains("Unknown CINERION_DATABASE_MODE", error.Message, StringComparison.Ordinal);
    }

    [Theory]
    [InlineData("Postgres")]
    [InlineData("postgres")]
    [InlineData("POSTGRES")]
    public void PostgresIsSelectedRegardlessOfCasing(string configured)
    {
        var selection = StorageModeSelection.Resolve(configured, Connection, isDevelopment: false);

        Assert.Equal(CinerionStorageMode.Postgres, selection.Mode);
        Assert.Equal(Connection, selection.ConnectionString);
    }
}
