// Tests for the audit trail and its chain check, over HTTP.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Tests;

/// <summary>
/// The audit surface over HTTP: the event query and the chain verification that decides
/// whether the record can still be believed.
/// </summary>
/// <remarks>
/// <c>POST /api/v1/audit/chain-verifications</c> is the operation an auditor uses to
/// answer "has anything been altered?", and it had no endpoint test at all — so the one
/// route by which tamper detection is actually reported had never been executed. The
/// chain itself is verified at domain level; what is checked here is that the answer is
/// reachable, deterministic, and reachable only by the two roles the catalogue names.
/// </remarks>
/// <requirements>CH1-TRC-FR-0002, CH1-NFR-AUD-0001, CH1-CYB-FR-0006</requirements>
public sealed class AuditEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;

    private HttpClient Client(string actorId, string roles)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(System.Globalization.CultureInfo.InvariantCulture));
        return client;
    }

    private static async Task<JsonElement> BodyAsync(HttpResponseMessage response) =>
        await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

    /// <summary>
    /// The verification answers from the stored chain, checks every link it holds, and
    /// gives the same answer twice for a chain nobody touched in between. A verification
    /// whose result moved on its own would be worthless as evidence either way.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0051")]
    public async Task Ch1TrcFr0002_ChainVerificationIsDeterministicAndNamesWhoAskedAndWhen()
    {
        using var auditor = Client("USR-AUDIT-VERIFY-01", "Auditor");
        // Something to verify. A step-up request appends both its own event and, on
        // refusal, the rejection, so the chain is never empty by the time this runs.
        using var seeded = await auditor.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);
        Assert.True(seeded.IsSuccessStatusCode || seeded.StatusCode == HttpStatusCode.BadRequest);

        using var first = await auditor.PostAsync(
            "/api/v1/audit/chain-verifications", content: null, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, first.StatusCode);
        var body = await BodyAsync(first);
        Assert.True(body.GetProperty("valid").GetBoolean());
        Assert.True(body.GetProperty("checked").GetInt32() > 0);
        Assert.Equal("USR-AUDIT-VERIFY-01", body.GetProperty("verifiedBy").GetString());
        Assert.NotEqual(default, body.GetProperty("verifiedAt").GetDateTimeOffset());
        // Nothing is reported broken, so there is no failure position to report.
        Assert.Equal(JsonValueKind.Null, body.GetProperty("failureAt").ValueKind);

        using var second = await auditor.PostAsync(
            "/api/v1/audit/chain-verifications", content: null, TestContext.Current.CancellationToken);
        var repeat = await BodyAsync(second);

        Assert.True(repeat.GetProperty("valid").GetBoolean());
        Assert.True(repeat.GetProperty("checked").GetInt32() >= body.GetProperty("checked").GetInt32());
        // Each verification is its own act, so it carries its own identifier even though
        // the answer it gives about an unchanged chain is the same.
        Assert.NotEqual(
            body.GetProperty("verificationId").GetGuid(),
            repeat.GetProperty("verificationId").GetGuid());
    }

    /// <summary>
    /// api_endpoints.json gives this to an Auditor or a Cybersecurity Administrator.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0051")]
    public async Task Ch1CybAcp0001_ChainVerificationIsReachableOnlyByTheTwoRolesTheCatalogueNames()
    {
        using var administrator = Client("USR-AUDIT-CYBER-01", "CybersecurityAdministrator");
        using var engineer = Client("USR-AUDIT-ENGINEER-01", "Engineer");

        using var permitted = await administrator.PostAsync(
            "/api/v1/audit/chain-verifications", content: null, TestContext.Current.CancellationToken);
        using var refused = await engineer.PostAsync(
            "/api/v1/audit/chain-verifications", content: null, TestContext.Current.CancellationToken);
        using var events = await engineer.GetAsync(
            "/api/v1/audit/events", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, permitted.StatusCode);
        // The whole audit surface answers identically to an identity without the role:
        // an engineer learns neither the result nor that there was one to learn.
        Assert.Equal(HttpStatusCode.NotFound, refused.StatusCode);
        Assert.Equal(refused.StatusCode, events.StatusCode);
    }

    /// <summary>
    /// CH1-NFR-AUD-0001 requires critical actions to be attributable. The query is the
    /// route by which that is read back, and a correlation identifier must select one
    /// action's events rather than everything the project has ever done.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0052")]
    public async Task Ch1NfrAud0001_EventsCarryTheirActorProjectAndCorrelation()
    {
        using var auditor = Client("USR-AUDIT-READ-01", "Auditor");
        using var stepUp = await auditor.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);
        Assert.True(stepUp.IsSuccessStatusCode);

        using var response = await auditor.GetAsync(
            "/api/v1/audit/events?limit=1000", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var items = (await BodyAsync(response)).GetProperty("items").EnumerateArray().ToArray();
        Assert.NotEmpty(items);
        var granted = Assert.Single(
            items,
            item => item.GetProperty("actorId").GetString() == "USR-AUDIT-READ-01"
                && item.GetProperty("eventType").GetString() == "StepUpGranted");
        Assert.Equal(ProjectId, granted.GetProperty("projectId").GetGuid());
        Assert.Equal("Allowed", granted.GetProperty("decision").GetString());
        Assert.NotEqual(Guid.Empty, granted.GetProperty("correlationId").GetGuid());
        // The chain records a hash of the payload, never the payload, so nothing an
        // event describes can be read back out of the audit record itself. Each link
        // also carries the previous hash, which is what makes an alteration detectable.
        Assert.Equal(64, granted.GetProperty("payloadHash").GetString()!.Length);
        Assert.Equal(64, granted.GetProperty("eventHash").GetString()!.Length);
        Assert.Equal(64, granted.GetProperty("previousHash").GetString()!.Length);
    }
}
