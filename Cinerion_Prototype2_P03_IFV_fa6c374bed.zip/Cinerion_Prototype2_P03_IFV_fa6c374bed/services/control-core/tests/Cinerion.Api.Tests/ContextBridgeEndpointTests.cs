// Tests for object-linked messages, and that a receipt never counts as an acknowledgement.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Application.Monitoring;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Monitoring;
using Cinerion.Infrastructure.Seed;
using Microsoft.Extensions.DependencyInjection;

namespace Cinerion.Api.Tests;

/// <summary>
/// Contextual communication over HTTP, and the separation between a message receipt and
/// any control action.
/// </summary>
/// <requirements>CH1-COL-FR-0001, CH1-COL-FR-0002, CH1-COL-FR-0003, CH1-UXD-DSG-0001</requirements>
public sealed class ContextBridgeEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid CellId = PrototypeSeed.Ids.CellId;
    private const string DeviceId = "CH1-DEV-CELL-0001";

    private HttpClient Client(string actorId, string roles, bool assignCell = true)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        if (assignCell)
        {
            client.DefaultRequestHeaders.Add("X-CH1-Cells", CellId.ToString());
        }

        return client;
    }

    private static Guid ThreadFor(ContextObjectType type, string objectId) =>
        ContextThread.DeriveId(ProjectId, type, objectId);

    private static readonly string[] EngineerAndViewerScope = ["Engineer", "Viewer"];
    private static readonly string[] InspectorScope = ["Inspector"];
    private static readonly string[] ThreadAuthorScope = ["USR-ENGINEER-CTX"];

    private static async Task<JsonElement> PostAsync(
        HttpClient client,
        Guid threadId,
        object body,
        HttpStatusCode expected,
        CancellationToken cancellationToken)
    {
        using var response = await client.PostAsJsonAsync(
            $"/api/v1/context-threads/{threadId}/messages", body, cancellationToken);
        var payload = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        Assert.Equal(expected, response.StatusCode);
        return payload;
    }

    /// <summary>Raises a real alarm through the ordinary ingestion path.</summary>
    private async Task<Alarm> RaiseAlarmAsync(CancellationToken cancellationToken)
    {
        await using var scope = factory.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();

        // Clear anything a previous test left outstanding, so this alarm is genuinely new.
        await monitoring.IngestAsync(
            ProjectId,
            [new TelemetryReading(CellId, DeviceId, "temperature", 22.0, "degC", DataQuality.Good, Freshness.Simulated, DateTimeOffset.UtcNow)],
            cancellationToken);
        var settled = await monitoring.ListAlarmsAsync(
            null, [AlarmState.Active, AlarmState.ReturnedUnacknowledged], null, null, 100,
            ActorFor("USR-FIXTURE", "Engineer"), cancellationToken);
        foreach (var open in settled)
        {
            await monitoring.AcknowledgeAlarmAsync(
                open.AlarmId, "Fixture reset.", ActorFor("USR-FIXTURE", "Engineer"), Guid.NewGuid(), cancellationToken);
        }

        var raised = await monitoring.IngestAsync(
            ProjectId,
            [new TelemetryReading(CellId, DeviceId, "temperature", 96.0, "degC", DataQuality.Good, Freshness.Simulated, DateTimeOffset.UtcNow.AddSeconds(1))],
            cancellationToken);
        return Assert.Single(raised.Raised);
    }

    private static Cinerion.Domain.Security.ActorContext ActorFor(string actorId, string role) => new(
        actorId,
        Cinerion.Domain.Security.ActorKind.Human,
        new HashSet<string>(StringComparer.Ordinal) { role },
        Cinerion.Domain.Security.AuthenticationStrength.SingleFactor,
        ProjectId,
        new HashSet<Guid> { CellId },
        "fixture-session");

    [Fact]
    [VerificationCase("CH1-VVT-TC-0107")]
    public async Task Ch1ColFr0001_AThreadIsBoundToOneControlledObject()
    {
        var threadId = ThreadFor(ContextObjectType.Cell, CellId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");

        var created = await PostAsync(
            engineer,
            threadId,
            new { body = "Coating step ran long on this cell.", objectType = "Cell", objectId = CellId.ToString() },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);

        var thread = created.GetProperty("thread");
        Assert.Equal("Cell", thread.GetProperty("objectType").GetString());
        Assert.Equal(CellId.ToString(), thread.GetProperty("objectId").GetString());
        Assert.Equal(threadId, thread.GetProperty("threadId").GetGuid());

        // The cell's own page carries the same identifier, which is how a client finds
        // the conversation without an operation that hands thread identifiers out.
        using var state = await engineer.GetAsync(
            $"/api/v1/cells/{CellId}/state", TestContext.Current.CancellationToken);
        var cell = await state.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(threadId, cell.GetProperty("contextThreadId").GetGuid());
    }

    [Fact]
    public async Task Ch1ColFr0001_AThreadCannotBeAttachedToAnObjectThatDoesNotExist()
    {
        var absent = Guid.NewGuid();
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");

        var refused = await PostAsync(
            engineer,
            ThreadFor(ContextObjectType.Part, absent.ToString()),
            new { body = "About a part that was never made.", objectType = "Part", objectId = absent.ToString() },
            HttpStatusCode.NotFound,
            TestContext.Current.CancellationToken);

        Assert.Equal("CONTEXT_OBJECT_NOT_FOUND", refused.GetProperty("code").GetString());
    }

    /// <summary>
    /// A thread identifier is derived from its object, so a caller cannot open a
    /// conversation at an identifier of their choosing. The refusal names the canonical
    /// identifier rather than leaving the caller to guess.
    /// </summary>
    [Fact]
    public async Task ThreadIdentifierIsDerivedFromTheObjectAndCannotBeChosen()
    {
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");

        var refused = await PostAsync(
            engineer,
            Guid.NewGuid(),
            new { body = "Posting to an invented thread.", objectType = "Cell", objectId = CellId.ToString() },
            HttpStatusCode.BadRequest,
            TestContext.Current.CancellationToken);

        Assert.Equal("CONTEXT_THREAD_ID_MISMATCH", refused.GetProperty("code").GetString());
        Assert.Contains(
            ThreadFor(ContextObjectType.Cell, CellId.ToString()).ToString(),
            refused.GetProperty("detail").GetString() ?? string.Empty,
            StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// **The verification case for CH1-VVT-TC-0109.** Both halves of the separation now
    /// exist in the running system: an alarm that can be acknowledged, and a message
    /// attached to that same alarm that can be read. Reading the message must leave the
    /// alarm exactly as it was.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0109")]
    public async Task Ch1VvtTc0109_ReadingAMessageOnAnAlarmThreadAcknowledgesNothingAboutTheAlarm()
    {
        var alarm = await RaiseAlarmAsync(TestContext.Current.CancellationToken);
        var threadId = ThreadFor(ContextObjectType.Alarm, alarm.AlarmId.ToString());

        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        var posted = await PostAsync(
            engineer,
            threadId,
            new
            {
                body = "Over-temperature on the coating cell - who is on site?",
                priority = "Urgent",
                objectType = "Alarm",
                objectId = alarm.AlarmId.ToString(),
                scopeRoles = EngineerAndViewerScope,
            },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);
        var messageId = posted.GetProperty("message").GetProperty("messageId").GetGuid();

        // The state of the alarm before anybody reads the message.
        using var operatorClient = Client("USR-OPERATOR-CTX", "Viewer");
        var before = await AlarmSnapshotAsync(operatorClient, alarm.AlarmId, TestContext.Current.CancellationToken);
        var cellBefore = await CellSnapshotAsync(operatorClient, TestContext.Current.CancellationToken);

        using var read = await operatorClient.PostAsync(
            $"/api/v1/context-messages/{messageId}/acknowledgements",
            content: null,
            TestContext.Current.CancellationToken);
        var receipt = await read.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, read.StatusCode);

        // The receipt says what it is, in a word that is not "Acknowledged".
        Assert.Equal("Read", receipt.GetProperty("kind").GetString());
        Assert.False(receipt.GetProperty("controlAuthority").GetBoolean());
        Assert.Equal("Alarm", receipt.GetProperty("threadObject").GetProperty("type").GetString());

        var after = await AlarmSnapshotAsync(operatorClient, alarm.AlarmId, TestContext.Current.CancellationToken);
        var cellAfter = await CellSnapshotAsync(operatorClient, TestContext.Current.CancellationToken);

        // The alarm is untouched: still unacknowledged, still Active, cause still present.
        Assert.Equal("Active", after.GetProperty("state").GetString());
        Assert.Equal(JsonValueKind.Null, after.GetProperty("acknowledgedBy").ValueKind);
        Assert.Equal(JsonValueKind.Null, after.GetProperty("acknowledgedAt").ValueKind);
        Assert.False(after.GetProperty("causeClear").GetBoolean());
        Assert.Equal(JsonValueKind.Null, after.GetProperty("clearedAt").ValueKind);
        Assert.True(after.GetProperty("outstanding").GetBoolean());
        Assert.Equal(before.GetProperty("state").GetString(), after.GetProperty("state").GetString());

        // And no interlock moved.
        Assert.Equal(
            cellBefore.GetProperty("stateHash").GetString(),
            cellAfter.GetProperty("stateHash").GetString());
        Assert.Equal(
            cellBefore.GetProperty("interlocks").GetRawText(),
            cellAfter.GetProperty("interlocks").GetRawText());
    }

    private static async Task<JsonElement> AlarmSnapshotAsync(
        HttpClient client,
        Guid alarmId,
        CancellationToken cancellationToken)
    {
        using var response = await client.GetAsync("/api/v1/alarms", cancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
        return body.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("alarmId").GetGuid() == alarmId);
    }

    private static async Task<JsonElement> CellSnapshotAsync(HttpClient client, CancellationToken cancellationToken)
    {
        using var response = await client.GetAsync($"/api/v1/cells/{CellId}/state", cancellationToken);
        return await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken);
    }

    /// <summary>
    /// CH1-VVT-TC-0107: messages stay scoped to their object and are unreachable outside
    /// authorised scope, reported identically to a thread that does not exist.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0107")]
    public async Task Ch1VvtTc0107_AThreadOutsideTheCallerScopeIsIndistinguishableFromAbsent()
    {
        var workOrderThread = ThreadFor(ContextObjectType.WorkOrder, PrototypeSeed.Ids.WorkOrderId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        await PostAsync(
            engineer,
            workOrderThread,
            new
            {
                body = "Restricted to inspectors.",
                objectType = "WorkOrder",
                objectId = PrototypeSeed.Ids.WorkOrderId.ToString(),
                scopeRoles = InspectorScope,
                scopeActorIds = ThreadAuthorScope,
            },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);

        using var outsider = Client("USR-MAINTENANCE-CTX", "MaintenanceEngineer");
        using var excluded = await outsider.GetAsync(
            $"/api/v1/context-threads/{workOrderThread}/messages", TestContext.Current.CancellationToken);
        using var absent = await outsider.GetAsync(
            $"/api/v1/context-threads/{Guid.NewGuid()}/messages", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, excluded.StatusCode);
        Assert.Equal(absent.StatusCode, excluded.StatusCode);

        // An inspector inside the scope reads it.
        using var inspector = Client("USR-INSPECTOR-CTX", "Inspector");
        using var allowed = await inspector.GetAsync(
            $"/api/v1/context-threads/{workOrderThread}/messages", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, allowed.StatusCode);
    }

    [Fact]
    public async Task Ch1CybFr0001_AThreadInAnotherProjectIsNotReadable()
    {
        var threadId = ThreadFor(ContextObjectType.Cell, CellId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        await PostAsync(
            engineer,
            threadId,
            new { body = "Project scoped.", objectType = "Cell", objectId = CellId.ToString() },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);

        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OTHER-PROJECT");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");

        using var response = await outsider.GetAsync(
            $"/api/v1/context-threads/{threadId}/messages", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    /// <summary>
    /// CH1-COL-FR-0002: author identity, time, priority, delivery state, acknowledgement
    /// state and access scope are all retained and readable.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0108")]
    public async Task Ch1ColFr0002_EveryMessageRetainsItsProvenanceAndAcknowledgementState()
    {
        var threadId = ThreadFor(ContextObjectType.Asset, PrototypeSeed.Ids.AssetId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        var posted = await PostAsync(
            engineer,
            threadId,
            new
            {
                body = "Tension module needs a look before the next run.",
                priority = "Elevated",
                objectType = "Asset",
                objectId = PrototypeSeed.Ids.AssetId.ToString(),
            },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);
        var messageId = posted.GetProperty("message").GetProperty("messageId").GetGuid();

        using var inspector = Client("USR-INSPECTOR-CTX", "Inspector");
        using var receipt = await inspector.PostAsync(
            $"/api/v1/context-messages/{messageId}/acknowledgements", null, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, receipt.StatusCode);

        using var read = await engineer.GetAsync(
            $"/api/v1/context-threads/{threadId}/messages", TestContext.Current.CancellationToken);
        var page = await read.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var message = page.GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("messageId").GetGuid() == messageId);

        Assert.Equal("USR-ENGINEER-CTX", message.GetProperty("authorId").GetString());
        Assert.Equal("Human", message.GetProperty("authorKind").GetString());
        Assert.Equal("Elevated", message.GetProperty("priority").GetString());
        Assert.Equal("Published", message.GetProperty("deliveryState").GetString());
        Assert.False(message.GetProperty("controlAuthority").GetBoolean());
        Assert.Equal(1, message.GetProperty("readCount").GetInt32());
        var reader = message.GetProperty("readBy").EnumerateArray().Single();
        Assert.Equal("USR-INSPECTOR-CTX", reader.GetProperty("recipientId").GetString());
        Assert.Equal("Read", reader.GetProperty("kind").GetString());

        // Access scope is retained on the thread, and retention is stated with the page.
        Assert.NotEmpty(page.GetProperty("thread").GetProperty("accessScope").GetProperty("roles").EnumerateArray());
        Assert.Equal(
            "Project life + 7 years",
            page.GetProperty("retention").GetProperty("message").GetString());
        Assert.Contains(
            "not a controlled engineering decision",
            page.GetProperty("retention").GetProperty("standing").GetString() ?? string.Empty,
            StringComparison.Ordinal);
    }

    /// <summary>
    /// The author is the authenticated actor. A body that tries to name someone else has
    /// no field to do it in, and the stored author is the caller regardless.
    /// </summary>
    [Fact]
    public async Task TheAuthorIsTheAuthenticatedActorAndNotAnythingTheBodyClaims()
    {
        var threadId = ThreadFor(ContextObjectType.Ncr, PrototypeSeed.Ids.PartId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");

        var posted = await PostAsync(
            engineer,
            ThreadFor(ContextObjectType.Part, PrototypeSeed.Ids.PartId.ToString()),
            new
            {
                body = "Authored by the token, not the payload.",
                objectType = "Part",
                objectId = PrototypeSeed.Ids.PartId.ToString(),
                authorId = "USR-SOMEONE-ELSE",
                controlAuthority = true,
            },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);

        var message = posted.GetProperty("message");
        Assert.Equal("USR-ENGINEER-CTX", message.GetProperty("authorId").GetString());
        Assert.False(message.GetProperty("controlAuthority").GetBoolean());
        Assert.NotEqual(threadId, message.GetProperty("threadId").GetGuid());
    }

    [Fact]
    public async Task ContentLimitsAreEnforced()
    {
        var threadId = ThreadFor(ContextObjectType.Cell, CellId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");

        var empty = await PostAsync(
            engineer,
            threadId,
            new { body = "   ", objectType = "Cell", objectId = CellId.ToString() },
            HttpStatusCode.BadRequest,
            TestContext.Current.CancellationToken);
        Assert.Equal("CONTEXT_MESSAGE_BODY_REQUIRED", empty.GetProperty("code").GetString());

        var tooLong = await PostAsync(
            engineer,
            threadId,
            new
            {
                body = new string('x', ContextMessage.MaximumBodyLength + 1),
                objectType = "Cell",
                objectId = CellId.ToString(),
            },
            HttpStatusCode.BadRequest,
            TestContext.Current.CancellationToken);
        Assert.Equal("CONTEXT_MESSAGE_BODY_TOO_LONG", tooLong.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0108")]
    public async Task AuthorCannotRecordReceiptOfTheirOwnMessageAndNobodyCanDoItTwice()
    {
        var threadId = ThreadFor(ContextObjectType.Cell, CellId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        var posted = await PostAsync(
            engineer,
            threadId,
            new { body = "Receipt rules.", objectType = "Cell", objectId = CellId.ToString() },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);
        var messageId = posted.GetProperty("message").GetProperty("messageId").GetGuid();

        using var ownReceipt = await engineer.PostAsync(
            $"/api/v1/context-messages/{messageId}/acknowledgements", null, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, ownReceipt.StatusCode);

        using var viewer = Client("USR-VIEWER-CTX", "Viewer");
        using var first = await viewer.PostAsync(
            $"/api/v1/context-messages/{messageId}/acknowledgements", null, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);

        using var second = await viewer.PostAsync(
            $"/api/v1/context-messages/{messageId}/acknowledgements", null, TestContext.Current.CancellationToken);
        var conflict = await second.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
        Assert.Equal("CONTEXT_RECEIPT_CONFLICT", conflict.GetProperty("code").GetString());
    }

    /// <summary>
    /// ResearchBench is enabled, so an experiment thread is now allowed — but only
    /// against an experiment that exists. This case was previously refused with
    /// "module not enabled"; the same request is now refused for the honest reason.
    /// The allowed case is covered in <see cref="ResearchBenchEndpointTests"/>.
    /// </summary>
    [Fact]
    public async Task AThreadCannotBeAttachedToAnExperimentThatDoesNotExist()
    {
        var experimentId = Guid.NewGuid();
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");

        var refused = await PostAsync(
            engineer,
            ThreadFor(ContextObjectType.Experiment, experimentId.ToString()),
            new { body = "About an experiment.", objectType = "Experiment", objectId = experimentId.ToString() },
            HttpStatusCode.NotFound,
            TestContext.Current.CancellationToken);

        Assert.Equal("CONTEXT_OBJECT_NOT_FOUND", refused.GetProperty("code").GetString());
    }

    [Fact]
    public async Task MalformedCursorIsRejectedRatherThanSilentlyIgnored()
    {
        var threadId = ThreadFor(ContextObjectType.Cell, CellId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        await PostAsync(
            engineer,
            threadId,
            new { body = "Paging.", objectType = "Cell", objectId = CellId.ToString() },
            HttpStatusCode.Created,
            TestContext.Current.CancellationToken);

        using var response = await engineer.GetAsync(
            $"/api/v1/context-threads/{threadId}/messages?cursor=not-a-cursor",
            TestContext.Current.CancellationToken);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("CONTEXT_CURSOR_INVALID", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task MessagesPageOldestFirstWithoutRepeatingOrSkipping()
    {
        var threadId = ThreadFor(ContextObjectType.WorkOrder, PrototypeSeed.Ids.WorkOrderId.ToString());
        using var engineer = Client("USR-ENGINEER-CTX", "Engineer");
        for (var index = 0; index < 3; index++)
        {
            await PostAsync(
                engineer,
                threadId,
                new
                {
                    body = $"Sequenced message {index}.",
                    objectType = "WorkOrder",
                    objectId = PrototypeSeed.Ids.WorkOrderId.ToString(),
                },
                HttpStatusCode.Created,
                TestContext.Current.CancellationToken);
        }

        var seen = new List<Guid>();
        string? cursor = null;
        for (var page = 0; page < 6; page++)
        {
            var url = $"/api/v1/context-threads/{threadId}/messages?limit=1" +
                (cursor is null ? string.Empty : $"&cursor={Uri.EscapeDataString(cursor)}");
            using var response = await engineer.GetAsync(url, TestContext.Current.CancellationToken);
            var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
            seen.AddRange(body.GetProperty("items").EnumerateArray().Select(item => item.GetProperty("messageId").GetGuid()));
            cursor = body.GetProperty("nextCursor").ValueKind == JsonValueKind.Null
                ? null
                : body.GetProperty("nextCursor").GetString();
            if (cursor is null)
            {
                break;
            }
        }

        Assert.True(seen.Count >= 3, $"Expected at least three messages, walked {seen.Count}.");
        Assert.Equal(seen.Count, seen.Distinct().Count());
    }
}
