// Tests for the step-up endpoint over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// Exercises POST /api/v1/auth/step-up over HTTP through the development identity
/// scheme, which can present a session of stated strength and authentication time.
/// </summary>
public sealed class StepUpEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = Guid.Parse("00000000-0000-4000-8000-000000000101");

    private static HttpClient Authenticated(
        CinerionApiFactory factory,
        string strength = "StepUpPhishingResistant",
        DateTimeOffset? authenticatedAt = null,
        string actor = "USR-INSPECTOR-01")
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actor);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Inspector");
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        client.DefaultRequestHeaders.Add("X-CH1-Session", "session-step-up");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            (authenticatedAt ?? DateTimeOffset.UtcNow).ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_StepUpIssuesAPurposeBoundSingleUseGrant()
    {
        using var client = Authenticated(factory);

        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("PartRelease", body.GetProperty("purpose").GetString());
        Assert.True(body.GetProperty("singleUse").GetBoolean());
        Assert.NotEqual(Guid.Empty, body.GetProperty("grantId").GetGuid());
        Assert.True(body.GetProperty("expiresAt").GetDateTimeOffset() > body.GetProperty("grantedAt").GetDateTimeOffset());
    }

    [Fact]
    public async Task Ch1IamFr0004_StepUpIsRefusedForAStaleSession()
    {
        using var client = Authenticated(factory, authenticatedAt: DateTimeOffset.UtcNow.AddHours(-2));

        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_REAUTHENTICATION_REQUIRED", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1IamFr0004_StepUpIsRefusedForASingleFactorSession()
    {
        using var client = Authenticated(factory, strength: "SingleFactor");

        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_STRONGER_AUTHENTICATOR_REQUIRED", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_UnknownPurposeIsRefused()
    {
        using var client = Authenticated(factory);

        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "ReleaseEverything" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_PURPOSE_UNKNOWN", body.GetProperty("code").GetString());
    }

    [Fact]
    public async Task Ch1IamFr0004_StepUpRequiresAuthentication()
    {
        using var client = factory.CreateClient();

        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    /// <summary>
    /// The step-up is audited whether granted or refused; a refusal is the security
    /// event of interest. Read back through the audit endpoint with Auditor authority.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0052")]
    [VerificationCase("CH1-VVT-TC-0094")]
    public async Task Ch1NfrAud0001_GrantedAndRefusedStepUpsAreBothAudited()
    {
        using var subject = Authenticated(factory, actor: "USR-AUDITED-01");
        using var granted = await subject.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "PartRelease" }, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, granted.StatusCode);

        using var weak = Authenticated(factory, strength: "SingleFactor", actor: "USR-AUDITED-01");
        using var refused = await weak.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = "PartRelease" }, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Forbidden, refused.StatusCode);

        using var auditor = factory.CreateClient();
        auditor.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-AUDITOR-01");
        auditor.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        auditor.DefaultRequestHeaders.Add("X-CH1-Roles", "Auditor");

        using var events = await auditor.GetAsync("/api/v1/audit/events", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, events.StatusCode);
        var body = await events.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var types = body.GetProperty("items").EnumerateArray()
            .Where(item => item.GetProperty("actorId").GetString() == "USR-AUDITED-01")
            .Select(item => item.GetProperty("eventType").GetString())
            .ToArray();

        Assert.Contains("StepUpGranted", types);
        Assert.Contains("StepUpRejected", types);
    }
}
