// Captures a real response for every shape the portal declares, so the portal's expectations
// meet reality.

using System.Buffers.Binary;
using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Cinerion.Application.Abstractions;
using Cinerion.Application.Edge;
using Cinerion.Application.Identity;
using Cinerion.Application.Monitoring;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Seed;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Cinerion.Api.Tests;

/// <summary>
/// Captures a real response for every shape the operator portal declares, so the
/// declaration can be checked against what the service actually sends.
/// </summary>
/// <remarks>
/// <para>
/// The portal's TypeScript contracts are hand-written and nothing reconciled them with
/// the service. A property named wrongly there typechecks perfectly and renders
/// <c>undefined</c> at runtime — which is exactly what happened twice while the
/// work-order and device screens were being written, most recently an alarm field
/// declared as <c>code</c> that the service sends as <c>alarmCode</c>. Both were found
/// by comparing against a running service by hand. This makes that comparison a gate.
/// </para>
/// <para>
/// The fixtures are written by an actual request through the test host, never by hand,
/// for the same reason the verification bindings are read by reflection: a fixture
/// someone typed is a second declaration to keep in step, not evidence about the first.
/// </para>
/// <para>
/// Several shapes exist only after something has happened — an alarm needs a breach, a
/// receipt needs a message, an allocation needs held capacity, a conflict needs capacity
/// withdrawn under a live holding. Each is therefore produced through the ordinary path
/// rather than written into the store, so what is captured is what a portal would see.
/// </para>
/// </remarks>
/// <requirements>CH1-SWA-API-0001, CH1-NFR-MNT-0001, CH1-UXD-DSG-0001</requirements>
public sealed class PortalContractFixtureTests
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid SiteId = PrototypeSeed.Ids.SiteId;
    private static readonly Guid CellId = PrototypeSeed.Ids.CellId;
    private static readonly Guid PartId = PrototypeSeed.Ids.PartId;
    private static readonly Guid RevisionId = PrototypeSeed.Ids.RevisionId;
    private static readonly Guid CalibrationId = PrototypeSeed.Ids.CalibrationRecordId;
    private static readonly Guid StationId = PrototypeSeed.Ids.CoatingStationResourceId;
    private static readonly Guid FilmStockId = PrototypeSeed.Ids.FilmStockResourceId;
    private static readonly Guid WorkOrderId = PrototypeSeed.Ids.WorkOrderId;
    private const string DeviceId = "CH1-DEV-CELL-0001";

    /// <summary>The relying party CredentialEndpoints falls back to when unconfigured.</summary>
    private const string RpId = "localhost";
    private const string Origin = "http://localhost:19006";

    private static readonly string[] AlarmThreadScope = ["Engineer", "Inspector", "Viewer"];

    // ------------------------------------------------------------------ plumbing

    private static DirectoryInfo RepositoryRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !Directory.Exists(Path.Combine(directory.FullName, "docs", "baseline")))
        {
            directory = directory.Parent;
        }

        Assert.NotNull(directory);
        return directory;
    }

    private static string FixtureDirectory()
    {
        var path = Path.Combine(RepositoryRoot().FullName, "artifacts", "contracts");
        Directory.CreateDirectory(path);
        return path;
    }

    private static async Task<JsonElement> ReadAsync(HttpResponseMessage response)
    {
        if (!response.IsSuccessStatusCode)
        {
            var refusal = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);
            Assert.Fail($"{response.RequestMessage?.RequestUri} answered {(int)response.StatusCode}: {refusal}");
        }

        return await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
    }

    /// <summary>
    /// Descends a captured response by a dotted path with optional array indexes, so a
    /// shape that only ever appears nested inside another response can be captured from
    /// the same real request that produced it.
    /// </summary>
    private static JsonElement Select(JsonElement root, string path)
    {
        var current = root;
        foreach (var step in path.Split('.', StringSplitOptions.RemoveEmptyEntries))
        {
            var name = step;
            int? index = null;
            var bracket = step.IndexOf('[', StringComparison.Ordinal);
            if (bracket >= 0)
            {
                name = step[..bracket];
                index = int.Parse(step[(bracket + 1)..^1], CultureInfo.InvariantCulture);
            }

            if (name.Length > 0)
            {
                Assert.True(
                    current.ValueKind == JsonValueKind.Object && current.TryGetProperty(name, out current),
                    $"The response has no property \"{name}\" at \"{path}\".");
            }

            if (index is not null)
            {
                Assert.Equal(JsonValueKind.Array, current.ValueKind);
                var items = current.EnumerateArray().ToArray();
                Assert.True(
                    items.Length > index.Value,
                    $"\"{path}\" has no element {index.Value}. The setup for this fixture produced nothing to capture, " +
                    "and a fixture captured from an empty array would let the gate pass over the shape it exists to check.");
                current = items[index.Value];
            }
        }

        return current;
    }

    /// <summary>
    /// Writes one captured shape. A non-object is refused here rather than written,
    /// because <c>scripts/check-portal-contracts.mjs</c> can only compare properties
    /// against an object and a <c>null</c> fixture would silently be compared to nothing.
    /// </summary>
    private static async Task WriteAsync(string contractName, JsonElement value)
    {
        Assert.Equal(JsonValueKind.Object, value.ValueKind);
        await File.WriteAllTextAsync(
            Path.Combine(FixtureDirectory(), $"{contractName}.json"),
            value.GetRawText(),
            TestContext.Current.CancellationToken);
    }

    private static async Task<JsonElement> CaptureAsync(string contractName, HttpResponseMessage response)
    {
        var body = await ReadAsync(response);
        await WriteAsync(contractName, body);
        return body;
    }

    private static Task CaptureAsync(string contractName, JsonElement root, string path) =>
        WriteAsync(contractName, Select(root, path));

    /// <summary>
    /// The same host with a stub identity provider in place of the unconfigured one.
    /// Only this host: the ordinary test host has no directory on purpose, and
    /// <see cref="IdentityAdministrationEndpointTests"/> exists to hold that.
    /// </summary>
    private static WebApplicationFactory<Program> WithIdentityDirectory(
        CinerionApiFactory host, IIdentityDirectory directory) =>
        host.WithWebHostBuilder(builder => builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IIdentityDirectory>();
            services.AddSingleton(directory);
        }));

    private static HttpClient Client(
        WebApplicationFactory<Program> host,
        string actorId,
        string roles,
        string strength = "Mfa",
        bool assignCell = true)
    {
        var client = host.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        if (assignCell)
        {
            client.DefaultRequestHeaders.Add("X-CH1-Cells", CellId.ToString());
        }

        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    private static byte[] BuildClientData(string type, byte[] challenge, string origin) =>
        Encoding.UTF8.GetBytes(
            $$"""
            {"type":"{{type}}","challenge":"{{Base64Url.Encode(challenge)}}","origin":"{{origin}}"}
            """);

    /// <summary>
    /// The CBOR map <c>{fmt: "none", attStmt: {}, authData: h'...'}</c>, with authData
    /// carrying the relying-party hash, the UP/UV/AT flags, the credential handle and the
    /// COSE public key — exactly what an authenticator returns from
    /// <c>navigator.credentials.create()</c>.
    /// </summary>
    private static byte[] BuildAttestationObject(ECDsa key, byte[] handle, string rpId)
    {
        var cose = CoseP256(key.ExportParameters(includePrivateParameters: false));
        var authData = new List<byte>();
        authData.AddRange(SHA256.HashData(Encoding.UTF8.GetBytes(rpId)));
        authData.Add(0x01 | 0x04 | 0x40);
        authData.AddRange([0x00, 0x00, 0x00, 0x00]);
        authData.AddRange(new byte[16]);
        authData.Add((byte)(handle.Length >> 8));
        authData.Add((byte)(handle.Length & 0xFF));
        authData.AddRange(handle);
        authData.AddRange(cose);

        var attestation = new List<byte> { 0xA3 };
        attestation.AddRange(CborText("fmt"));
        attestation.AddRange(CborText("none"));
        attestation.AddRange(CborText("attStmt"));
        attestation.Add(0xA0);
        attestation.AddRange(CborText("authData"));
        attestation.AddRange(
            authData.Count < 24 ? [(byte)(0x40 | authData.Count)]
            : authData.Count < 256 ? new byte[] { 0x58, (byte)authData.Count }
            : [0x59, (byte)(authData.Count >> 8), (byte)(authData.Count & 0xFF)]);
        attestation.AddRange(authData);
        return [.. attestation];
    }

    private static byte[] CborText(string value)
    {
        var bytes = Encoding.UTF8.GetBytes(value);
        return [(byte)(0x60 | bytes.Length), .. bytes];
    }

    private static async Task<Guid> StepUpAsync(HttpClient client, string purpose) =>
        (await StepUpWithChallengeAsync(client, purpose)).GrantId;

    /// <summary>
    /// The grant and the nonce it binds. api_endpoints.json makes the control on
    /// <c>POST /api/v1/auth/step-up</c> "Purpose-bound challenge, short TTL and audit",
    /// and a registration's proof of possession is made against that challenge.
    /// </summary>
    private static async Task<(Guid GrantId, byte[] Challenge)> StepUpWithChallengeAsync(
        HttpClient client, string purpose)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up", new { Purpose = purpose }, TestContext.Current.CancellationToken);
        var body = await ReadAsync(response);
        return (
            body.GetProperty("grantId").GetGuid(),
            Base64Url.Decode(body.GetProperty("challenge").GetString()!));
    }

    private static Task<HttpResponseMessage> SendAsync(
        HttpClient client, HttpMethod method, string path, object? body, Guid? grant, string? ifMatch = null)
    {
        var request = new HttpRequestMessage(method, path);
        if (body is not null) request.Content = JsonContent.Create(body);
        if (grant is not null) request.Headers.Add("X-CH1-Step-Up", grant.Value.ToString());
        if (ifMatch is not null) request.Headers.TryAddWithoutValidation("If-Match", $"\"{ifMatch}\"");
        return client.SendAsync(request, TestContext.Current.CancellationToken);
    }

    private static Task<HttpResponseMessage> PostAsync(HttpClient client, string path, object? body, Guid? grant) =>
        SendAsync(client, HttpMethod.Post, path, body, grant);

    // ---------------------------------------------------------------- commands

    /// <summary>
    /// <b>The guarded command shapes, captured from a REAL preparation.</b>
    /// <para>
    /// The portal gained a PREPARE control, which is step 1 of the controlled
    /// PREPARE / LOCAL COMMIT sequence and the only step of it that belongs to the
    /// portal. It declares the transaction's shape, so something has to capture one.
    /// </para>
    /// <para>
    /// Prepared through the ordinary operation with a real step-up grant and a real
    /// idempotency key, never written into the store — what is captured has to be what a
    /// portal would actually see. The command stays at <c>AwaitingCredential</c> and that
    /// is the whole point: nothing here presents a credential or a button edge, because
    /// nothing in the portal can, and a fixture that advanced the transaction would be
    /// capturing a state the portal could never reach on its own.
    /// </para>
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_CommandShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        using var engineer = Client(
            host, "USR-CONTRACT-CMD", "Engineer", strength: "StepUpPhishingResistant");

        // The hash the caller must bind to is the cell's own, read through the same
        // operation the portal reads it through. A preparation against a hash nobody read
        // is refused as stale, which is the control working.
        using var cell = await engineer.GetAsync(
            $"/api/v1/cells/{CellId}/state", TestContext.Current.CancellationToken);
        var stateHash = (await ReadAsync(cell)).GetProperty("stateHash").GetString();

        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/commands/prepare")
        {
            Content = JsonContent.Create(new
            {
                CommandType = "RUN_TENSION_CALIBRATION",
                ProjectId = ProjectId,
                SiteId = SiteId,
                CellId = CellId,
                AssetId = PrototypeSeed.Ids.AssetId,
                WorkOrderId = WorkOrderId,
                PartId = PartId,
                ProcedureRevision = "CH1-REFAB-PROC-0001-R01",
                ConfigurationRevision = "CFG-REFAB-P01-R01",
                ExpectedStateHash = stateHash,
                Sequence = 7001L,
                ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(60),
                Parameters = new Dictionary<string, string>(),
            }),
        };
        request.Headers.Add("Idempotency-Key", $"contract-{Guid.NewGuid():N}");
        request.Headers.Add("X-CH1-Step-Up",
            (await StepUpAsync(engineer, StepUpPurpose.PhysicalCommandPreparation)).ToString());

        using var prepared = await engineer.SendAsync(request, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, prepared.StatusCode);
        var commandId = (await ReadAsync(prepared)).GetProperty("commandId").GetGuid();

        // The READ is what the portal declares, and it carries more than the write does:
        // the acknowledgements and the audit links that make the outcome visible.
        using var read = await engineer.GetAsync(
            $"/api/v1/commands/{commandId}", TestContext.Current.CancellationToken);
        var transaction = await CaptureAsync("CommandTransaction", read);
        await CaptureAsync("PrepareIntent", transaction, "intent");
        await CaptureAsync("AuditLink", transaction, "auditLinks[0]");

        // Nothing has acknowledged it yet, so the list is correctly EMPTY — and an empty
        // array is exactly what a fixture must not be captured from, because the gate
        // would then pass over the shape it exists to check.
        Assert.Empty(transaction.GetProperty("acknowledgements").EnumerateArray());
        Assert.False(transaction.GetProperty("remoteStartAvailable").GetBoolean());
        Assert.True(transaction.GetProperty("physicalConfirmationRequired").GetBoolean());
        Assert.True(transaction.GetProperty("acknowledgementIsNotExecution").GetBoolean());

        // So a real one is produced, through the real ingress service rather than by
        // writing a row: a controller answering a command the domain prepared. It is
        // invoked in-process because the transport it normally arrives on is mutual TLS
        // gRPC, which a test host cannot stand in for — but the code path, the audit write
        // and the correlation are the service's own, and the projection that renders it is
        // the same one the portal reads.
        //
        // It changes no command state, which is the property the shape exists to carry:
        // an acknowledgement is evidence about delivery, never authority to execute.
        using (var scope = host.Services.CreateScope())
        {
            var ingress = scope.ServiceProvider.GetRequiredService<EdgeIngressService>();
            await ingress.AcknowledgeCommandAsync(
                new GatewayPeer("ch1-edgelink", "contract-fixture"),
                new CommandAcknowledgementInput(
                    new IngressEnvelope(
                        SchemaVersion: EdgeIngressService.SchemaVersion,
                        MessageType: "CommandAcknowledgement",
                        MessageId: $"contract-ack-{Guid.NewGuid():N}",
                        CorrelationId: Guid.NewGuid().ToString(),
                        SourceId: "ch1-edgelink",
                        DestinationId: EdgeIngressService.ControlCoreIdentity,
                        ProjectId: ProjectId,
                        SiteId: SiteId,
                        CellId: CellId,
                        AssetId: Guid.Empty,
                        Sequence: 1,
                        OccurredAt: DateTimeOffset.UtcNow,
                        ExpiresAt: null),
                    commandId,
                    DeviceId,
                    Accepted: true,
                    ControllerState: "AwaitCredential",
                    ReasonCode: "PREPARE_ACCEPTED",
                    ObservedAt: DateTimeOffset.UtcNow,
                    AdapterId: "CH1-ADP-SIM-0001"),
                TestContext.Current.CancellationToken);
        }

        using var acknowledged = await engineer.GetAsync(
            $"/api/v1/commands/{commandId}", TestContext.Current.CancellationToken);
        var answered = await ReadAsync(acknowledged);
        await CaptureAsync("ControllerAcknowledgement", answered, "acknowledgements[0]");

        // Still awaiting its credential. The acknowledgement did not move it, and the
        // shape says so on its own face.
        Assert.Equal("AwaitingCredential", answered.GetProperty("state").GetString());
    }

    // ------------------------------------------------------------------- reads

    [Fact]
    public async Task Ch1SwaApi0001_ReadShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        using var engineer = Client(host, "USR-CONTRACT-ENG", "Engineer,Inspector,Auditor,MaintenanceEngineer,Viewer");

        // The five owner-approved reads, recorded in
        // traceability/owner-approved-operations.json. Captured on exactly the same terms
        // as a controlled read: a shape the portal declares and nothing captured is a shape
        // compared against nothing, and being outside the P03 catalogue is no reason for a
        // response to escape that.
        using var calibrations = await engineer.GetAsync(
            "/api/v1/calibrations", TestContext.Current.CancellationToken);
        var calibrationPage = await CaptureAsync("CalibrationPage", calibrations);
        await CaptureAsync("CalibrationEntry", calibrationPage, "items[0]");

        // A REAL scan, produced the way a scan is produced: an enrolled Field Companion
        // device with a session key, and a signature computed over the delivery. Seeding a
        // row into ch1.scan_events would have been quicker and would have captured evidence
        // no device ever generated, which is the one thing a scan register must not contain.
        var scannerId = $"CH1-DEV-SCAN-CONTRACT";
        var sessionKey = System.Security.Cryptography.RandomNumberGenerator.GetBytes(32);
        await using (var scope = host.Services.CreateAsyncScope())
        {
            scope.ServiceProvider
                .GetService<Cinerion.Infrastructure.Persistence.ProjectScope>()?.Set(ProjectId);
            var store = scope.ServiceProvider
                .GetRequiredService<Cinerion.Application.Abstractions.ICinerionStore>();
            await store.SaveDeviceAsync(
                new Cinerion.Domain.Assets.DeviceRecord(
                    scannerId, ProjectId, CellId, "FieldCompanion", "1.0.0", "CFG-R01",
                    Convert.ToHexStringLower(sessionKey), "Trusted", null, null, 1),
                TestContext.Current.CancellationToken);
        }

        var scannedAt = DateTimeOffset.UtcNow;
        using var recorded = await engineer.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            new
            {
                deviceId = scannerId,
                stationId = "STATION-01",
                identifierKind = "QR",
                identifierValue = "CH1-PART-000017-04",
                scannedAt,
                sessionSignature = Cinerion.Domain.Evidence.ScanEventRecord.ComputeSessionSignature(
                    scannerId, "STATION-01", "CH1-PART-000017-04", scannedAt, sessionKey),
            },
            TestContext.Current.CancellationToken);
        Assert.True(
            recorded.IsSuccessStatusCode,
            $"the contract fixture could not record a scan: {recorded.StatusCode}");

        using var scans = await engineer.GetAsync(
            "/api/v1/parts/scan-events", TestContext.Current.CancellationToken);
        var scanPage = await CaptureAsync("ScanEventPage", scans);
        await CaptureAsync("ScanEventEntry", scanPage, "items[0]");

        using var workOrders = await engineer.GetAsync(
            "/api/v1/work-orders", TestContext.Current.CancellationToken);
        await CaptureAsync("WorkOrderBoardPage", workOrders);

        // An experiment, defined through the ordinary operation and then read back, so the
        // detail shape is captured from a record the platform actually wrote.
        using var researcher = Client(host, "USR-CONTRACT-RND", "RDEngineer,Engineer,Viewer");
        using var defined = await researcher.PostAsJsonAsync(
            "/api/v1/experiments",
            new { Objective = "Contract fixture experiment", Environment = "Simulator" },
            TestContext.Current.CancellationToken);
        Assert.True(
            defined.IsSuccessStatusCode,
            $"the contract fixture could not define an experiment: {defined.StatusCode}");
        var experimentId = (await ReadAsync(defined)).GetProperty("experimentId").GetGuid();

        // One recorded run, so the revision shape is captured from a record the platform
        // wrote rather than left uncaptured. A run is a RECORDING with provenance, not an
        // execution: CH1-COM-IF-0020 puts the simulators behind a provider interface this
        // deployment does not enable, and the operation says so.
        var hash = new string('a', 64);
        using var run = await researcher.PostAsJsonAsync(
            $"/api/v1/experiments/{experimentId}/runs",
            new
            {
                ConfigurationReference = "cinerion://experiments/contract/config",
                ConfigurationSha256 = hash,
                ModelReference = "cinerion://experiments/contract/model",
                InputReference = "cinerion://experiments/contract/input",
                InputSha256 = hash,
                ResultSummary = "Contract fixture run: recorded, not executed.",
                ResultSha256 = hash,
                StartedAt = DateTimeOffset.UtcNow.AddMinutes(-5),
                FinishedAt = DateTimeOffset.UtcNow,
            },
            TestContext.Current.CancellationToken);
        Assert.True(
            run.IsSuccessStatusCode,
            $"the contract fixture could not record an experiment run: {run.StatusCode}");

        using var experiments = await researcher.GetAsync(
            "/api/v1/experiments", TestContext.Current.CancellationToken);
        var experimentPage = await CaptureAsync("ExperimentPage", experiments);
        await CaptureAsync("ExperimentSummary", experimentPage, "items[0]");

        using var experimentDetail = await researcher.GetAsync(
            $"/api/v1/experiments/{experimentId}", TestContext.Current.CancellationToken);
        var detail = await CaptureAsync("ExperimentDetail", experimentDetail);
        await CaptureAsync("ExperimentRevisionRecord", detail, "revisions[0]");

        using var health = await engineer.GetAsync("/api/v1/system/health", TestContext.Current.CancellationToken);
        await CaptureAsync("SystemHealth", health);

        using var projects = await engineer.GetAsync("/api/v1/projects", TestContext.Current.CancellationToken);
        await CaptureAsync("ProjectSummary", await ReadAsync(projects), "[0]");

        using var cell = await engineer.GetAsync($"/api/v1/cells/{CellId}/state", TestContext.Current.CancellationToken);
        var cellState = await CaptureAsync("CellState", cell);
        await CaptureAsync("CellInterlocks", cellState, "interlocks");

        using var cells = await engineer.GetAsync($"/api/v1/sites/{SiteId}/cells", TestContext.Current.CancellationToken);
        await CaptureAsync("SiteCell", await ReadAsync(cells), "[0]");

        using var device = await engineer.GetAsync(
            $"/api/v1/devices/{DeviceId}", TestContext.Current.CancellationToken);
        await CaptureAsync("DeviceRecord", device);

        // A revision carrying both a bill of materials and a route, so the two line
        // shapes are captured from a response that actually contains them rather than
        // from an empty array.
        using var products = await engineer.GetAsync("/api/v1/products", TestContext.Current.CancellationToken);
        var groups = await ReadAsync(products);
        var group = groups.EnumerateArray().First(item =>
            item.GetProperty("revisions").EnumerateArray().Any(revision =>
                revision.GetProperty("bom").GetArrayLength() > 0 &&
                revision.GetProperty("route").GetArrayLength() > 0));
        await WriteAsync("ProductGroup", group);
        var revisionIndex = group.GetProperty("revisions").EnumerateArray().ToList()
            .FindIndex(revision =>
                revision.GetProperty("bom").GetArrayLength() > 0 &&
                revision.GetProperty("route").GetArrayLength() > 0);
        await CaptureAsync("ProductRevisionSummary", group, $"revisions[{revisionIndex}]");
        await CaptureAsync("BomLine", group, $"revisions[{revisionIndex}].bom[0]");
        await CaptureAsync("RouteStep", group, $"revisions[{revisionIndex}].route[0]");
    }

    // ------------------------------------------------------------------ quality

    /// <summary>
    /// The genealogy shapes, captured after the part has been driven through the whole
    /// controlled path — a failing mandatory result, a nonconformity, a passing retest,
    /// the closing disposition and an independent release. A part with no measurement
    /// and no release would carry an empty array and a null, and the two shapes inside
    /// it would go unchecked.
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_QualityShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        using var inspector = Client(
            host, "USR-CONTRACT-QA", "Inspector,Engineer", strength: "StepUpPhishingResistant");

        using var run = await PostAsync(
            inspector,
            "/api/v1/test-runs",
            new { PartId = PartId, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            null);
        var runId = (await ReadAsync(run)).GetProperty("testRunId").GetGuid();

        using var failing = await MeasureAsync(inspector, runId, 8.2m, null);
        var failedId = (await ReadAsync(failing)).GetProperty("measurement").GetProperty("measurementId").GetGuid();

        using var ncr = await PostAsync(
            inspector,
            "/api/v1/ncrs",
            new { PartId = PartId, Title = "Coating thickness below limit", Description = "8.20 against 9.50-10.50" },
            null);
        var ncrId = (await ReadAsync(ncr)).GetProperty("ncrId").GetGuid();

        using var retest = await MeasureAsync(inspector, runId, 10.1m, failedId);
        Assert.Equal(HttpStatusCode.Created, retest.StatusCode);

        using var closed = await PostAsync(
            inspector,
            $"/api/v1/ncrs/{ncrId}/dispositions",
            new { Disposition = "Close", Justification = "Rework verified" },
            await StepUpAsync(inspector, StepUpPurpose.NcrDisposition));
        Assert.Equal("Accepted", (await ReadAsync(closed)).GetProperty("partStatus").GetString());

        using var released = await PostAsync(
            inspector,
            "/api/v1/release-records",
            new { PartId = PartId },
            await StepUpAsync(inspector, StepUpPurpose.PartRelease));
        Assert.Equal(HttpStatusCode.Created, released.StatusCode);

        using var genealogy = await inspector.GetAsync(
            $"/api/v1/parts/{PartId}/genealogy", TestContext.Current.CancellationToken);
        var evidence = await CaptureAsync("PartGenealogy", genealogy);
        await CaptureAsync("PartRecord", evidence, "part");
        await CaptureAsync("QualityMeasurement", evidence, "part.measurements[0]");

        // The release is an inline shape on PartRecord, so it is only compared when the
        // captured part actually carries one.
        Assert.Equal(JsonValueKind.Object, Select(evidence, "part.release").ValueKind);

        // The owner-approved lookup that reaches the identifier above from the serial
        // number printed on the label. Recorded for conflict 15; it resolves an identity
        // and records no scan event.
        var serial = Select(evidence, "part.serialNumber").GetString()!;
        using var identity = await inspector.GetAsync(
            $"/api/v1/parts?serialNumber={Uri.EscapeDataString(serial)}",
            TestContext.Current.CancellationToken);
        await CaptureAsync("PartIdentity", identity);
    }

    private static Task<HttpResponseMessage> MeasureAsync(
        HttpClient client, Guid runId, decimal value, Guid? supersedes) =>
        client.PostAsJsonAsync(
            $"/api/v1/test-runs/{runId}/measurements",
            new
            {
                PartId = PartId,
                Characteristic = "Coating thickness",
                Value = value,
                Unit = "um",
                LowerLimit = 9.5m,
                UpperLimit = 10.5m,
                Mandatory = true,
                SourceDeviceId = "CH1-INS-THK-0001",
                CalibrationRecordId = CalibrationId,
                CalibrationValid = true,
                SupersedesMeasurementId = supersedes,
            },
            TestContext.Current.CancellationToken);

    // --------------------------------------------------------------- monitoring

    /// <summary>
    /// Telemetry, the alarm a breach raises, and the acknowledgement that does not clear
    /// it. The readings are stated through <see cref="MonitoringService.IngestAsync"/>,
    /// which is the path a gateway uses; nothing here writes an alarm directly.
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_MonitoringShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        // Stamped in the past, and it has to be. A telemetry query's window ends at *now*
        // (TelemetryQuery.Create resolves an absent `to` that way), so a reading stamped a
        // second into the future raises its alarm and is then absent from every query — the
        // capture would hold an alarm whose reading could not be found. The controlled gRPC
        // ingress refuses a gateway whose clock leads, so this is a property of the
        // in-process path used here rather than one an edge could produce.
        var now = DateTimeOffset.UtcNow;
        await IngestAsync(host, "temperature", 21.5, "degC", now.AddSeconds(-30));

        using var engineer = Client(host, "USR-CONTRACT-MON", "Engineer,Viewer");

        // A breach on temperature, acknowledged; then a breach on a second channel that is
        // left outstanding. Both halves matter to the interface and neither could be
        // rendered from a page carrying only one of them: an operator has to be able to see
        // an alarm that was acknowledged while its cause is still present *and* one that
        // nobody has answered yet, and only the second offers an acknowledgement control.
        var raised = await IngestAsync(host, "temperature", 96.0, "degC", now.AddSeconds(-20));
        var alarmId = Assert.Single(raised.Raised).AlarmId;

        using var acknowledged = await PostAsync(
            engineer,
            $"/api/v1/alarms/{alarmId}/acknowledgements",
            new { comment = "Captured for the portal contract fixture." },
            null);
        await CaptureAsync("AlarmAcknowledgement", acknowledged);

        var outstanding = await IngestAsync(host, "vibration_rms", 7.2, "m/s2", now.AddSeconds(-10));
        var outstandingAlarm = Assert.Single(outstanding.Raised);
        Assert.Equal("CH1-ALM-VIBRATION-HIGH", outstandingAlarm.AlarmCode);

        // Captured after both breaches and without a channel filter, so the page carries a
        // reading inside its alarm limits and one outside them. A page holding only the
        // first cannot exercise what a screen does with the second, and inventing an
        // out-of-limit sample would be a fixture somebody typed rather than evidence about
        // the service.
        using var telemetry = await engineer.GetAsync(
            "/api/v1/telemetry?limit=10", TestContext.Current.CancellationToken);
        var page = await CaptureAsync("TelemetryPage", telemetry);
        await CaptureAsync("TelemetrySample", page, "items[0]");
        await CaptureAsync("TelemetryChannel", page, "channelAllowlist.channels[0]");

        var readings = Select(page, "items").EnumerateArray().ToList();
        Assert.Contains(readings, item => Select(item, "channelId").GetString() == "temperature");
        Assert.Contains(readings, item => Select(item, "channelId").GetString() == "vibration_rms");
        Assert.Contains(readings, item => Select(item, "value").GetDouble() > 45.0);

        using var alarms = await engineer.GetAsync(
            "/api/v1/alarms?state=Active&state=Acknowledged&state=ReturnedUnacknowledged",
            TestContext.Current.CancellationToken);
        var alarmPage = await CaptureAsync("AlarmPage", alarms);

        // AlarmRecord is captured from the acknowledged alarm by identifier rather than by
        // position, because the page now holds two and the order is the service's to choose.
        // A positional capture would silently start describing whichever alarm happened to
        // sort first.
        var items = Select(alarmPage, "items").EnumerateArray().ToList();
        var acknowledgedIndex = items.FindIndex(
            item => Select(item, "alarmId").GetString() == alarmId.ToString());
        Assert.True(acknowledgedIndex >= 0, "the acknowledged alarm is absent from the page it was raised on");
        await CaptureAsync("AlarmRecord", alarmPage, $"items[{acknowledgedIndex}]");

        Assert.Contains(items, item => Select(item, "acknowledgedAt").ValueKind == JsonValueKind.Null);
        Assert.Contains(items, item => Select(item, "acknowledgedAt").ValueKind != JsonValueKind.Null);
    }

    private static async Task<TelemetryIngestionResult> IngestAsync(
        WebApplicationFactory<Program> host,
        string channelId,
        double value,
        string unit,
        DateTimeOffset sampledAt)
    {
        await using var scope = host.Services.CreateAsyncScope();
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();
        return await monitoring.IngestAsync(
            ProjectId,
            [
                new TelemetryReading(
                    CellId, DeviceId, channelId, value, unit,
                    DataQuality.Good, Freshness.Simulated, sampledAt),
            ],
            TestContext.Current.CancellationToken);
    }

    // ------------------------------------------------------------ collaboration

    /// <summary>
    /// A thread on a real alarm, a message on it, and a receipt recorded by somebody who
    /// did not write it — an author cannot receipt their own message, so a single actor
    /// could not produce this shape at all.
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_CollaborationShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        var raised = await IngestAsync(host, "temperature", 97.0, "degC", DateTimeOffset.UtcNow);
        var alarmId = Assert.Single(raised.Raised).AlarmId;

        using var engineer = Client(host, "USR-CONTRACT-CTX-ENG", "Engineer");

        // The thread identifier is the server's own, taken from the alarm rather than
        // derived here: the portal reads it from the object page for the same reason.
        using var alarms = await engineer.GetAsync(
            $"/api/v1/alarms?state=Active&cellId={CellId}", TestContext.Current.CancellationToken);
        var alarm = (await ReadAsync(alarms)).GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("alarmId").GetGuid() == alarmId);
        var threadId = alarm.GetProperty("contextThreadId").GetGuid();

        using var posted = await PostAsync(
            engineer,
            $"/api/v1/context-threads/{threadId}/messages",
            new
            {
                body = "Over-temperature on the coating cell — who is on site?",
                priority = "Urgent",
                objectType = "Alarm",
                objectId = alarmId.ToString(),
                scopeRoles = AlarmThreadScope,
            },
            null);
        var message = await CaptureAsync("PostedContextMessage", posted);
        await CaptureAsync("ContextThreadSummary", message, "thread");
        await CaptureAsync("ContextMessage", message, "message");
        var messageId = Select(message, "message.messageId").GetGuid();

        using var inspector = Client(host, "USR-CONTRACT-CTX-INS", "Inspector");
        using var receipt = await PostAsync(
            inspector, $"/api/v1/context-messages/{messageId}/acknowledgements", null, null);
        await CaptureAsync("MessageReadReceipt", receipt);

        using var thread = await engineer.GetAsync(
            $"/api/v1/context-threads/{threadId}/messages", TestContext.Current.CancellationToken);
        var threadPage = await CaptureAsync("ContextThreadPage", thread);
        await CaptureAsync("ContextMessageReceipt", threadPage, "items[0].readBy[0]");
    }

    // ---------------------------------------------------------------- capacity

    /// <summary>
    /// A reservation, and the over-committed interval that only exists once capacity is
    /// withdrawn under a live holding.
    /// </summary>
    /// <remarks>
    /// CH1-MGT-FR-0004 requires conflict state to be exposed, not merely prevented — a
    /// reservation refuses to over-commit, so the only way an interval becomes conflicted
    /// is capacity reduced after the fact. The P03 catalogue contains no operation that
    /// changes a resource's capacity (recorded as the sixth open conflict), so that
    /// administrative change is made through the store here, which is the same act the
    /// direct SQL performed when this behaviour was verified on PostgreSQL.
    /// </remarks>
    [Fact]
    public async Task Ch1SwaApi0001_CapacityShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        using var coordinator = Client(host, "USR-CONTRACT-COORD", "OperationsCoordinator");

        var from = DateTimeOffset.UtcNow.AddDays(1).ToUniversalTime();
        from = new DateTimeOffset(from.Year, from.Month, from.Day, 8, 0, 0, TimeSpan.Zero);
        var to = from.AddHours(8);

        var version = (await ResourceAsync(coordinator, FilmStockId, from, to))
            .GetProperty("version").GetInt64();

        using var reserved = await SendAsync(
            coordinator,
            HttpMethod.Post,
            $"/api/v1/resources/{FilmStockId}/reservations",
            new { quantity = 200m, startsAt = from, endsAt = to, workOrderId = WorkOrderId },
            await StepUpAsync(coordinator, StepUpPurpose.ResourceAllocation),
            version.ToString(CultureInfo.InvariantCulture));
        await CaptureAsync("ReservationReceipt", reserved);

        // Capacity withdrawn out of band, under the holding above: 200 m committed
        // against 150 m, so the interval is over-committed by 50.
        await using (var scope = host.Services.CreateAsyncScope())
        {
            var store = scope.ServiceProvider.GetRequiredService<ICinerionStore>();
            var resource = await store.FindResourceAsync(FilmStockId, TestContext.Current.CancellationToken);
            Assert.NotNull(resource);
            await store.SaveResourceAsync(
                resource with { Capacity = 150m, Version = resource.Version + 1 },
                TestContext.Current.CancellationToken);
        }

        using var response = await coordinator.GetAsync(
            ResourceQuery(from, to), TestContext.Current.CancellationToken);
        var page = await CaptureAsync("ResourcePage", response);
        var index = page.GetProperty("items").EnumerateArray().ToList()
            .FindIndex(item => item.GetProperty("resourceId").GetGuid() == FilmStockId);
        Assert.True(index >= 0, "The reserved resource is absent from the page it was reserved on.");

        await CaptureAsync("ResourceAvailability", page, $"items[{index}]");
        await CaptureAsync("ResourceAllocation", page, $"items[{index}].reservations[0]");
        await CaptureAsync("CapacityConflict", page, $"items[{index}].conflicts[0]");

        Assert.True(Select(page, $"items[{index}].conflicted").GetBoolean());
    }

    private static string ResourceQuery(DateTimeOffset from, DateTimeOffset to) =>
        "/api/v1/resources" +
        $"?from={Uri.EscapeDataString(from.ToString("O", CultureInfo.InvariantCulture))}" +
        $"&to={Uri.EscapeDataString(to.ToString("O", CultureInfo.InvariantCulture))}";

    private static async Task<JsonElement> ResourceAsync(
        HttpClient client, Guid resourceId, DateTimeOffset from, DateTimeOffset to)
    {
        using var response = await client.GetAsync(ResourceQuery(from, to), TestContext.Current.CancellationToken);
        return (await ReadAsync(response)).GetProperty("items").EnumerateArray()
            .Single(item => item.GetProperty("resourceId").GetGuid() == resourceId);
    }

    // ----------------------------------------------------------- authenticators

    /// <summary>
    /// The four authenticator shapes, including a grant produced by a genuine P-256
    /// assertion over the challenge the platform issued.
    /// </summary>
    [Fact]
    public async Task Ch1SwaApi0001_AuthenticatorShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        const string Subject = "USR-CONTRACT-PASSKEY";
        using var administrator = Client(host, "USR-CONTRACT-SECADM", "CybersecurityAdministrator");
        using var holder = Client(host, Subject, "Inspector");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var handle = RandomNumberGenerator.GetBytes(16);

        var ceremony = await StepUpWithChallengeAsync(
            administrator, StepUpPurpose.CredentialAdministration);
        using var registered = await PostAsync(
            administrator,
            "/api/v1/credentials",
            new
            {
                SubjectId = Subject,
                Kind = nameof(CredentialKind.Passkey),
                Label = "Security key",
                // The attestation the authenticator signed over the platform's own
                // challenge. There is no public-key field here any more: proof of
                // possession is the declared control on this operation and the key comes
                // out of the attestation.
                AttestationObject = Base64Url.Encode(BuildAttestationObject(key, handle, RpId)),
                ClientDataJson = Base64Url.Encode(BuildClientData(
                    "webauthn.create", ceremony.Challenge, Origin)),
                UserVerification = nameof(UserVerificationRequirement.Required),
            },
            ceremony.GrantId);
        await CaptureAsync("CredentialSummary", registered);

        using var options = await PostAsync(
            holder, "/api/v1/auth/passkey/options", new { Purpose = StepUpPurpose.PartRelease }, null);
        var challenge = await CaptureAsync("PasskeyOptions", options);

        using var verified = await PostAsync(
            holder,
            "/api/v1/auth/passkey/verify",
            BuildAssertion(
                key,
                handle,
                Base64Url.Decode(challenge.GetProperty("challenge").GetString()!),
                Origin,
                RpId,
                challenge.GetProperty("challengeId").GetGuid()),
            null);
        var grant = await CaptureAsync("PasskeyGrant", verified);
        Assert.Equal("StepUpPhishingResistant", grant.GetProperty("grantedStrength").GetString());

        using var enroller = Client(host, "USR-CONTRACT-TOTP", "Inspector");
        using var enrolment = await PostAsync(
            enroller,
            "/api/v1/auth/totp/enrolments",
            new { Label = "Phone authenticator" },
            await StepUpAsync(enroller, StepUpPurpose.CredentialAdministration));
        await CaptureAsync("TotpEnrolment", enrolment);
    }

    /// <summary>
    /// The audit chain as the explorer reads it, and the tamper-detection answer beside it.
    /// </summary>
    /// <remarks>
    /// Both shapes were declared inside <c>audit.tsx</c> rather than in the portal's
    /// contract source, so <c>npm run contracts:portal</c> never compared either against a
    /// response the service sent - a property named wrongly there would have typechecked
    /// and rendered <c>undefined</c> exactly as it did before that gate existed. They are
    /// declared in <c>contracts.ts</c> now, and captured here.
    /// </remarks>
    [Fact]
    public async Task Ch1AudFr0001_AuditShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();

        // Something has to have happened for the chain to carry anything, and a read is not
        // it: a fresh host's chain is empty. A real breach is raised and acknowledged
        // through the ordinary path, so the captured page carries an event the service
        // wrote rather than one the seed placed.
        var raised = await IngestAsync(
            host, "temperature", 96.0, "degC", DateTimeOffset.UtcNow.AddSeconds(-20));
        var alarmId = Assert.Single(raised.Raised).AlarmId;
        using var engineer = Client(host, "USR-CONTRACT-AUDIT-ENG", "Engineer,Viewer");
        using var acknowledged = await PostAsync(
            engineer,
            $"/api/v1/alarms/{alarmId}/acknowledgements",
            new { comment = "Captured so the audit chain carries a real event." },
            null);
        Assert.Equal(HttpStatusCode.Created, acknowledged.StatusCode);

        using var auditor = Client(host, "USR-CONTRACT-AUDIT", "Auditor,Viewer");
        using var seeded = await auditor.GetAsync(
            "/api/v1/audit/events", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, seeded.StatusCode);

        var page = await CaptureAsync("AuditPage", seeded);
        Assert.True(Select(page, "count").GetInt32() > 0, "the captured audit page carries no events");

        using var verification = await PostAsync(
            auditor, "/api/v1/audit/chain-verifications", new { }, null);
        var verified = await CaptureAsync("ChainVerification", verification);
        Assert.True(verified.GetProperty("valid").GetBoolean(), "the seeded chain does not verify");
    }

    /// <summary>
    /// The project-scoped directory listing the security-administration screen reads.
    /// </summary>
    /// <remarks>
    /// Same story as the audit shapes: declared on the screen, so never reconciled. The
    /// stub directory is registered for this host only, exactly as it is for session
    /// revocation - it replaces the provider, not the decision, and the response captured
    /// here is built by the endpoint rather than by the stub.
    /// </remarks>
    [Fact]
    public async Task Ch1IamFr0008_DirectoryShapeIsCapturedFromARealResponse()
    {
        using var host = new CinerionApiFactory();
        using var configured = WithIdentityDirectory(host, new StubIdentityDirectory());
        using var administrator = Client(configured, "USR-CONTRACT-DIR", "SystemAdministrator,Viewer");

        using var listing = await administrator.GetAsync(
            "/api/v1/users", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, listing.StatusCode);

        var page = await CaptureAsync("DirectoryPage", listing);
        await CaptureAsync("DirectoryUser", page, "items[0]");

        // The projection carries no credential field of any kind, which is the property
        // that matters more than any of the ones the portal reads.
        var user = Select(page, "items[0]");
        foreach (var forbidden in new[] { "password", "secret", "credential", "seed", "privateKey" })
        {
            Assert.False(
                user.TryGetProperty(forbidden, out _),
                $"the directory projection carries a {forbidden} field");
        }
    }

    /// <summary>
    /// Ending one's own session, and the receipt the portal renders from it.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The ordinary test host has **no** identity directory, deliberately: every identity
    /// operation must refuse rather than answer a security question with invented data,
    /// and <c>IdentityAdministrationEndpointTests</c> exists to hold that. The consequence
    /// is that the success path of this operation had never been executed by any test at
    /// all — the live-Keycloak evidence for it was produced by hand.
    /// </para>
    /// <para>
    /// A stub directory is therefore registered **for this host only**, leaving the
    /// fail-closed property intact everywhere else. It replaces the provider, not the
    /// decision: authority, self-versus-administrator ownership, the project-bounded
    /// lookup and the audit event are all the real ones, and the response shape captured
    /// here is built by the endpoint rather than by the stub.
    /// </para>
    /// </remarks>
    [Fact]
    public async Task Ch1IamFr0004_EndingOnesOwnSessionIsRecordedAndItsReceiptCaptured()
    {
        using var host = new CinerionApiFactory();
        using var configured = WithIdentityDirectory(host, new StubIdentityDirectory());
        using var owner = Client(configured, "USR-CONTRACT-SESSION", "Viewer");

        using var revocation = await SendAsync(
            owner,
            HttpMethod.Delete,
            $"/api/v1/auth/sessions/{Uri.EscapeDataString("session-USR-CONTRACT-SESSION")}",
            null,
            null);
        var receipt = await CaptureAsync("SessionRevocation", revocation);

        // The decision the endpoint made, not the stub's: this is the caller's own
        // session, so no administrator role was required and none was held.
        Assert.True(receipt.GetProperty("revoked").GetBoolean());
        Assert.True(receipt.GetProperty("ownSession").GetBoolean());
        Assert.Equal("USR-CONTRACT-SESSION", receipt.GetProperty("revokedBy").GetString());

        // Somebody else's session, from an identity holding no administrator role.
        using var other = await SendAsync(
            owner, HttpMethod.Delete, "/api/v1/auth/sessions/session-someone-else", null, null);
        Assert.Equal(HttpStatusCode.Forbidden, other.StatusCode);
        Assert.Equal(
            "AUTH_SESSION_REVOCATION",
            (await other.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
                .GetProperty("code").GetString());
    }

    /// <summary>
    /// Everything an authenticator would produce, produced here: client data naming the
    /// type, challenge and origin the browser reached; authenticator data carrying the
    /// relying-party hash, the user-present and user-verified flags and a signature
    /// counter; and a real ECDSA signature over both.
    /// </summary>
    private static object BuildAssertion(
        ECDsa key, byte[] handle, byte[] challenge, string origin, string rpId, Guid challengeId)
    {
        var clientDataJson = Encoding.UTF8.GetBytes(
            $$"""
            {"type":"webauthn.get","challenge":"{{Base64Url.Encode(challenge)}}","origin":"{{origin}}"}
            """);

        var authenticatorData = new byte[37];
        SHA256.HashData(Encoding.UTF8.GetBytes(rpId)).CopyTo(authenticatorData, 0);
        authenticatorData[32] = 0x01 | 0x04;
        BinaryPrimitives.WriteUInt32BigEndian(authenticatorData.AsSpan(33, 4), 1);

        var payload = new byte[authenticatorData.Length + 32];
        authenticatorData.CopyTo(payload, 0);
        SHA256.HashData(clientDataJson).CopyTo(payload, authenticatorData.Length);

        return new
        {
            ChallengeId = challengeId,
            CredentialId = Base64Url.Encode(handle),
            AuthenticatorData = Base64Url.Encode(authenticatorData),
            ClientDataJson = Base64Url.Encode(clientDataJson),
            Signature = Base64Url.Encode(
                key.SignData(payload, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence)),
        };
    }

    /// <summary>Encodes an EC public key exactly as an authenticator would, in COSE.</summary>
    private static byte[] CoseP256(ECParameters parameters)
    {
        var buffer = new List<byte> { 0xA5, 0x01, 0x02, 0x03, 0x26, 0x20, 0x01, 0x21, 0x58 };
        buffer.Add((byte)parameters.Q.X!.Length);
        buffer.AddRange(parameters.Q.X!);
        buffer.Add(0x22);
        buffer.Add(0x58);
        buffer.Add((byte)parameters.Q.Y!.Length);
        buffer.AddRange(parameters.Q.Y!);
        return [.. buffer];
    }

    // ------------------------------------------------------------------ writes

    [Fact]
    public async Task Ch1SwaApi0001_WriteShapesAreCapturedFromRealResponses()
    {
        using var host = new CinerionApiFactory();
        using var manager = Client(host, "USR-CONTRACT-PM", "ProjectManager,Engineer");

        using var grant = await PostAsync(
            manager, "/api/v1/auth/step-up", new { Purpose = StepUpPurpose.WorkOrderRelease }, null);
        await CaptureAsync("StepUpGrant", grant);

        using var order = await PostAsync(
            manager,
            "/api/v1/work-orders",
            new { WorkOrderNumber = "WO-CONTRACT-0001", RevisionId = RevisionId, CellId = CellId, Quantity = 1 },
            null);
        await CaptureAsync("WorkOrderRecord", order);

        // The shape that carried the defect this gate exists to prevent: the alarm a
        // revocation raises, whose code field was declared as "code" and is sent as
        // "alarmCode".
        using var security = Client(
            host, "USR-CONTRACT-SEC", "CybersecurityAdministrator,Engineer", strength: "StepUpPhishingResistant");

        using var revocation = await PostAsync(
            security,
            $"/api/v1/devices/{DeviceId}/revoke",
            new { Reason = "Captured for the portal contract fixture" },
            await StepUpAsync(security, StepUpPurpose.DeviceTrust));
        var revoked = await CaptureAsync("DeviceRevocation", revocation);
        await CaptureAsync("RevokedDeviceRecord", revoked, "device");
    }

    // ------------------------------------------------------------------- guard

    /// <summary>
    /// Guards the capture itself, in both directions: every shape the portal declares
    /// must have a fixture written by a real request, and every fixture must be a JSON
    /// object a comparison can actually read.
    /// </summary>
    /// <remarks>
    /// Counting files would not do it. If an endpoint moved, a write silently failed, or
    /// a new interface were added to the portal without a capture, the gate downstream
    /// would compare that shape against nothing and report success — which is the exact
    /// failure mode this whole mechanism exists to remove. The list of shapes is read
    /// from the portal's own declaration, so it cannot drift from it.
    /// </remarks>
    [Fact]
    public async Task Ch1NfrMnt0001_EveryDeclaredPortalShapeIsCapturedFromARealResponse()
    {
        await Ch1SwaApi0001_ReadShapesAreCapturedFromRealResponses();
        await Ch1SwaApi0001_QualityShapesAreCapturedFromRealResponses();
        await Ch1SwaApi0001_MonitoringShapesAreCapturedFromRealResponses();
        await Ch1SwaApi0001_CollaborationShapesAreCapturedFromRealResponses();
        await Ch1SwaApi0001_CapacityShapesAreCapturedFromRealResponses();
        await Ch1SwaApi0001_AuthenticatorShapesAreCapturedFromRealResponses();
        await Ch1IamFr0004_EndingOnesOwnSessionIsRecordedAndItsReceiptCaptured();
        await Ch1SwaApi0001_WriteShapesAreCapturedFromRealResponses();

        var (declared, exempt) = await DeclaredPortalShapesAsync();
        Assert.NotEmpty(declared);

        var captured = Directory.GetFiles(FixtureDirectory(), "*.json")
            .Select(Path.GetFileNameWithoutExtension)
            .ToHashSet(StringComparer.Ordinal);

        var missing = declared.Where(name => !exempt.Contains(name) && !captured.Contains(name)).ToArray();
        Assert.True(
            missing.Length == 0,
            "The portal declares these response shapes and no real request captured one: " +
            string.Join(", ", missing) +
            ". A shape with no captured response is compared against nothing.");

        foreach (var file in Directory.GetFiles(FixtureDirectory(), "*.json"))
        {
            var text = await File.ReadAllTextAsync(file, TestContext.Current.CancellationToken);
            Assert.False(string.IsNullOrWhiteSpace(text), file);
            using var parsed = JsonDocument.Parse(text);
            Assert.Equal(JsonValueKind.Object, parsed.RootElement.ValueKind);
        }
    }

    /// <summary>
    /// The interfaces the portal declares, and those marked as having no Control Core
    /// response behind them. The marker lives in the declaration itself so this side and
    /// <c>scripts/check-portal-contracts.mjs</c> read one statement rather than keeping
    /// two exemption lists in step.
    /// </summary>
    private static async Task<(IReadOnlyList<string> Declared, IReadOnlySet<string> Exempt)> DeclaredPortalShapesAsync()
    {
        var path = Path.Combine(
            RepositoryRoot().FullName, "apps", "operator-portal", "src", "api", "contracts.ts");
        Assert.True(File.Exists(path), $"The portal contract declaration is missing: {path}");
        var source = await File.ReadAllTextAsync(path, TestContext.Current.CancellationToken);

        var declared = Regex.Matches(source, @"export interface (\w+)", RegexOptions.None, TimeSpan.FromSeconds(5))
            .Select(match => match.Groups[1].Value)
            .ToArray();

        var exempt = Regex
            .Matches(
                source,
                @"@noCapturedResponse[\s\S]*?\*/\s*export interface (\w+)",
                RegexOptions.Singleline,
                TimeSpan.FromSeconds(5))
            .Select(match => match.Groups[1].Value)
            .ToHashSet(StringComparer.Ordinal);

        foreach (var name in exempt)
        {
            Assert.Contains(name, declared);
        }

        return (declared, exempt);
    }

    /// <summary>Kept so the unused-field analyser does not flag the seeded identifiers.</summary>
    [Fact]
    public void TheSeededIdentifiersThisSuiteUsesExist()
    {
        Assert.NotEqual(Guid.Empty, StationId);
        Assert.NotEqual(Guid.Empty, WorkOrderId);
    }
}
