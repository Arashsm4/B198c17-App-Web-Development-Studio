// Tests for the guarded command path. Lots of ways to be told no, and every one is checked.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// Exercises the guarded command path over HTTP.
/// <para>
/// The domain aggregate is covered by unit tests; what these add is that the
/// authority separation survives the transport. In particular the portal-facing
/// PREPARE and the controller-facing credential proof and local commit are distinct
/// operations with distinct identities, and no ordering of HTTP calls can collapse
/// them into one.
/// </para>
/// </summary>
/// <requirements>CH1-CMD-FR-0002, CH1-CMD-FR-0003, CH1-CMD-FR-0006, CH1-IAM-FR-0004</requirements>
public sealed class CommandGuardEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private const string Project = "00000000-0000-4000-8000-000000000101";
    private const string Site = "00000000-0000-4000-8000-000000000102";
    private const string Cell = "00000000-0000-4000-8000-000000000103";
    private const string Asset = "00000000-0000-4000-8000-000000000104";
    private const string WorkOrder = "00000000-0000-4000-8000-000000000105";
    private const string Part = "00000000-0000-4000-8000-000000000106";
    private const string ControllerBoot = "00000000-0000-4000-8000-000000000107";
    private const string ControllerId = "CH1-DEV-CELL-0001";

    /// <summary>An engineer able to reach phishing-resistant step-up.</summary>
    private HttpClient Engineer(string actor = "USR-ENGINEER-01")
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actor);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "StepUpPhishingResistant");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actor}");
        return client;
    }

    /// <summary>
    /// The cell controller's own identity. It is a device account, never a browser,
    /// and it is the only identity that may present credential proof or local commit.
    /// </summary>
    private HttpClient Controller()
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", ControllerId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "DeviceController");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Actor-Kind", "Device");
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "MutualTls");
        return client;
    }

    private static async Task<Guid> StepUpAsync(HttpClient client)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PhysicalCommandPreparation" },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.GetProperty("grantId").GetGuid();
    }

    private static async Task<string> ExpectedStateHashAsync(HttpClient client)
    {
        using var response = await client.GetAsync($"/api/v1/cells/{Cell}/state", TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.GetProperty("stateHash").GetString()!;
    }

    private static object Intent(string stateHash, long sequence) => new
    {
        CommandType = "RUN_TENSION_CALIBRATION",
        ProjectId = Project,
        SiteId = Site,
        CellId = Cell,
        AssetId = Asset,
        WorkOrderId = WorkOrder,
        PartId = Part,
        ProcedureRevision = "CH1-REFAB-PROC-0001-R01",
        ConfigurationRevision = "CFG-REFAB-P01-R01",
        ExpectedStateHash = stateHash,
        Sequence = sequence,
        ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(60),
        Parameters = new Dictionary<string, string> { ["targetTensionN"] = "1.20" },
    };

    private static HttpRequestMessage PrepareRequest(object intent, Guid grantId, string idempotencyKey)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/commands/prepare")
        {
            Content = JsonContent.Create(intent),
        };
        request.Headers.Add("Idempotency-Key", idempotencyKey);
        request.Headers.Add("X-CH1-Step-Up", grantId.ToString());
        return request;
    }

    private static string NewKey() => $"idem-{Guid.NewGuid():N}";

    [Fact]
    [VerificationCase("CH1-VVT-TC-0010")]
    public async Task Ch1CmdFr0002_PrepareCreatesATransactionAwaitingLocalCredential()
    {
        using var engineer = Engineer("USR-PREPARE-01");
        var hash = await ExpectedStateHashAsync(engineer);
        var grant = await StepUpAsync(engineer);

        using var request = PrepareRequest(Intent(hash, 9001), grant, NewKey());
        using var response = await engineer.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AwaitingCredential", body.GetProperty("state").GetString());
        // The response must never suggest the portal can complete the transaction.
        Assert.True(body.GetProperty("physicalConfirmationRequired").GetBoolean());
        Assert.False(body.GetProperty("remoteStartAvailable").GetBoolean());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_PrepareWithoutAStepUpGrantIsRefused()
    {
        using var engineer = Engineer("USR-PREPARE-02");
        var hash = await ExpectedStateHashAsync(engineer);

        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/commands/prepare")
        {
            Content = JsonContent.Create(Intent(hash, 9002)),
        };
        request.Headers.Add("Idempotency-Key", NewKey());

        using var response = await engineer.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_REQUIRED", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// One re-authentication must not arm a series of preparations. The grant is
    /// consumed by the first prepare and refused on the second.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0013")]
    public async Task Ch1IamFr0004_AStepUpGrantArmsExactlyOnePreparation()
    {
        using var engineer = Engineer("USR-PREPARE-03");
        var hash = await ExpectedStateHashAsync(engineer);
        var grant = await StepUpAsync(engineer);

        using var first = PrepareRequest(Intent(hash, 9003), grant, NewKey());
        using var firstResponse = await engineer.SendAsync(first, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, firstResponse.StatusCode);

        using var second = PrepareRequest(Intent(hash, 9004), grant, NewKey());
        using var secondResponse = await engineer.SendAsync(second, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, secondResponse.StatusCode);
        var body = await secondResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_ALREADY_USED", body.GetProperty("code").GetString());
    }

    /// <summary>A grant issued for release must not arm a physical preparation.</summary>
    [Fact]
    public async Task Ch1IamFr0004_AGrantForAnotherPurposeCannotArmAPreparation()
    {
        using var engineer = Engineer("USR-PREPARE-04");
        var hash = await ExpectedStateHashAsync(engineer);

        using var releaseGrant = await engineer.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = "PartRelease" },
            TestContext.Current.CancellationToken);
        var grant = (await releaseGrant.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("grantId").GetGuid();

        using var request = PrepareRequest(Intent(hash, 9005), grant, NewKey());
        using var response = await engineer.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_PURPOSE_MISMATCH", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0015")]
    [VerificationCase("CH1-VVT-TC-0027")]
    public async Task Ch1CmdFr0006_StaleExpectedStateIsRefused()
    {
        using var engineer = Engineer("USR-PREPARE-05");
        var grant = await StepUpAsync(engineer);
        var stale = new string('a', 64);

        using var request = PrepareRequest(Intent(stale, 9006), grant, NewKey());
        using var response = await engineer.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("CMD_EXPECTED_STATE_STALE", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// A retried request - byte-for-byte the same intent under the same key - returns
    /// the original transaction rather than arming a second one.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0015")]
    public async Task Ch1CmdFr0006_ARetriedRequestReturnsTheSameTransaction()
    {
        using var engineer = Engineer("USR-PREPARE-06");
        var hash = await ExpectedStateHashAsync(engineer);
        var key = NewKey();
        // One intent, reused. Rebuilding it would change ExpiresAt and make this a
        // different request that legitimately conflicts.
        var intent = Intent(hash, 9007);

        var grantOne = await StepUpAsync(engineer);
        using var first = PrepareRequest(intent, grantOne, key);
        using var firstResponse = await engineer.SendAsync(first, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, firstResponse.StatusCode);
        var firstId = (await firstResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("commandId").GetGuid();

        var grantTwo = await StepUpAsync(engineer);
        using var second = PrepareRequest(intent, grantTwo, key);
        using var secondResponse = await engineer.SendAsync(second, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, secondResponse.StatusCode);
        var secondId = (await secondResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken))
            .GetProperty("commandId").GetGuid();

        Assert.Equal(firstId, secondId);
    }

    /// <summary>
    /// The same key with different content is a different request and must be refused,
    /// so a retry cannot silently arm a command the caller did not ask for.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0015")]
    public async Task Ch1CmdFr0006_TheSameKeyWithDifferentContentConflicts()
    {
        using var engineer = Engineer("USR-PREPARE-09");
        var hash = await ExpectedStateHashAsync(engineer);
        var key = NewKey();

        var grantOne = await StepUpAsync(engineer);
        using var first = PrepareRequest(Intent(hash, 9008), grantOne, key);
        using var firstResponse = await engineer.SendAsync(first, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, firstResponse.StatusCode);

        var grantTwo = await StepUpAsync(engineer);
        using var second = PrepareRequest(Intent(hash, 9009), grantTwo, key);
        using var secondResponse = await engineer.SendAsync(second, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Conflict, secondResponse.StatusCode);
        var body = await secondResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("IDEMPOTENCY_CONFLICT", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// The complete authority chain over HTTP: an engineer prepares, the controller
    /// presents credential proof, and only then does a physical button edge produce
    /// LOCAL COMMIT. Each step is a separate call by a separate identity.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0005")]
    [VerificationCase("CH1-VVT-TC-0012")]
    public async Task Ch1CmdFr0003_TheFullChainReachesLocalCommitOnlyThroughTheController()
    {
        using var engineer = Engineer("USR-CHAIN-01");
        using var controller = Controller();
        var hash = await ExpectedStateHashAsync(engineer);
        var grant = await StepUpAsync(engineer);

        using var prepare = PrepareRequest(Intent(hash, 9100), grant, NewKey());
        using var prepared = await engineer.SendAsync(prepare, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, prepared.StatusCode);
        var command = await prepared.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var commandId = command.GetProperty("commandId").GetGuid();
        var confirmationId = command.GetProperty("confirmationId").GetGuid();

        using var proof = await controller.PostAsJsonAsync(
            $"/api/v1/confirmations/{confirmationId}/credential-proofs",
            new
            {
                ProofId = Guid.NewGuid(),
                CommandId = commandId,
                ConfirmationId = confirmationId,
                CellId = Cell,
                ControllerId,
                CredentialId = Guid.NewGuid(),
                UserId = "USR-LOCAL-CONFIRMER-01",
                AuthenticatorClass = "FidoSecurityKey",
                ChallengeHash = new string('a', 64),
                CryptographicallyVerified = true,
                UserVerified = true,
                VerifiedAt = DateTimeOffset.UtcNow,
                ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(45),
            },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, proof.StatusCode);
        var awaiting = await proof.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AwaitingButton", awaiting.GetProperty("state").GetString());

        using var commit = await controller.PostAsJsonAsync(
            $"/api/v1/confirmations/{confirmationId}/local-commits",
            new
            {
                CommandId = commandId,
                ConfirmationId = confirmationId,
                CellId = Cell,
                ControllerId,
                ControllerBootId = ControllerBoot,
                Source = "PhysicalInput",
                PreviousState = false,
                CurrentState = true,
                ObservedAt = DateTimeOffset.UtcNow,
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, commit.StatusCode);
        var committed = await commit.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Committed", committed.GetProperty("state").GetString());
    }

    /// <summary>
    /// A browser session must not be able to stand in for the cell controller, even
    /// holding a valid prepared command. The portal has no such route at all; this
    /// asserts the server refuses it independently of the client.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0014")]
    [VerificationCase("CH1-VVT-TC-0104")]
    public async Task Ch1CmdFr0005_AHumanSessionCannotSubstituteForTheController()
    {
        using var engineer = Engineer("USR-CHAIN-02");
        var hash = await ExpectedStateHashAsync(engineer);
        var grant = await StepUpAsync(engineer);

        using var prepare = PrepareRequest(Intent(hash, 9200), grant, NewKey());
        using var prepared = await engineer.SendAsync(prepare, TestContext.Current.CancellationToken);
        var command = await prepared.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var commandId = command.GetProperty("commandId").GetGuid();
        var confirmationId = command.GetProperty("confirmationId").GetGuid();

        using var response = await engineer.PostAsJsonAsync(
            $"/api/v1/confirmations/{confirmationId}/credential-proofs",
            new
            {
                ProofId = Guid.NewGuid(),
                CommandId = commandId,
                ConfirmationId = confirmationId,
                CellId = Cell,
                ControllerId,
                CredentialId = Guid.NewGuid(),
                UserId = "USR-CHAIN-02",
                AuthenticatorClass = "FidoSecurityKey",
                ChallengeHash = new string('a', 64),
                CryptographicallyVerified = true,
                UserVerified = true,
                VerifiedAt = DateTimeOffset.UtcNow,
                ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(45),
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.StartsWith("AUTH_", body.GetProperty("code").GetString(), StringComparison.Ordinal);
    }

    /// <summary>
    /// A prepared command names its own cell. Presenting proof from a controller bound
    /// to a different cell must be refused even though the transaction exists.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0005")]
    [VerificationCase("CH1-VVT-TC-0015")]
    public async Task Ch1CmdFr0006_ProofFromAnotherControllerIsRefused()
    {
        using var engineer = Engineer("USR-CHAIN-03");
        var hash = await ExpectedStateHashAsync(engineer);
        var grant = await StepUpAsync(engineer);

        using var prepare = PrepareRequest(Intent(hash, 9300), grant, NewKey());
        using var prepared = await engineer.SendAsync(prepare, TestContext.Current.CancellationToken);
        var command = await prepared.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var commandId = command.GetProperty("commandId").GetGuid();
        var confirmationId = command.GetProperty("confirmationId").GetGuid();

        using var impostor = factory.CreateClient();
        impostor.DefaultRequestHeaders.Add("X-CH1-Actor", "CH1-DEV-CELL-9999");
        impostor.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        impostor.DefaultRequestHeaders.Add("X-CH1-Roles", "DeviceController");
        impostor.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        impostor.DefaultRequestHeaders.Add("X-CH1-Actor-Kind", "Device");

        using var response = await impostor.PostAsJsonAsync(
            $"/api/v1/confirmations/{confirmationId}/credential-proofs",
            new
            {
                ProofId = Guid.NewGuid(),
                CommandId = commandId,
                ConfirmationId = confirmationId,
                CellId = Cell,
                ControllerId,
                CredentialId = Guid.NewGuid(),
                UserId = "USR-LOCAL-CONFIRMER-01",
                AuthenticatorClass = "FidoSecurityKey",
                ChallengeHash = new string('a', 64),
                CryptographicallyVerified = true,
                UserVerified = true,
                VerifiedAt = DateTimeOffset.UtcNow,
                ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(45),
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0013")]
    public async Task Ch1CmdFr0006_PreparingOutsideTheCellScopeIsRefused()
    {
        using var engineer = Engineer("USR-PREPARE-07");
        var hash = await ExpectedStateHashAsync(engineer);

        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OUTSIDE-01");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");
        outsider.DefaultRequestHeaders.Add("X-CH1-Cells", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "StepUpPhishingResistant");
        outsider.DefaultRequestHeaders.Add("X-CH1-Session", "session-outside");

        var grant = await StepUpAsync(outsider);
        using var request = PrepareRequest(Intent(hash, 9400), grant, NewKey());
        using var response = await outsider.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_CELL_SCOPE", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0013")]
    public async Task Ch1CmdFr0006_ATtlOutsideTheControlledWindowIsRefused()
    {
        using var engineer = Engineer("USR-PREPARE-08");
        var hash = await ExpectedStateHashAsync(engineer);
        var grant = await StepUpAsync(engineer);

        var intent = new
        {
            CommandType = "RUN_TENSION_CALIBRATION",
            ProjectId = Project,
            SiteId = Site,
            CellId = Cell,
            AssetId = Asset,
            WorkOrderId = WorkOrder,
            PartId = Part,
            ProcedureRevision = "CH1-REFAB-PROC-0001-R01",
            ConfigurationRevision = "CFG-REFAB-P01-R01",
            ExpectedStateHash = hash,
            Sequence = 9500L,
            // Well beyond the 5-120 second window the aggregate permits.
            ExpiresAt = DateTimeOffset.UtcNow.AddHours(4),
            Parameters = new Dictionary<string, string>(),
        };

        using var request = PrepareRequest(intent, grant, NewKey());
        using var response = await engineer.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("CMD_TTL_INVALID", body.GetProperty("code").GetString());
    }

    /// <summary>Every prepare, granted or refused, must leave an attributable record.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0052")]
    [VerificationCase("CH1-VVT-TC-0094")]
    public async Task Ch1NfrAud0001_PreparedAndRefusedCommandsAreBothAudited()
    {
        using var engineer = Engineer("USR-AUDITED-CMD");
        var hash = await ExpectedStateHashAsync(engineer);

        var grant = await StepUpAsync(engineer);
        using var ok = PrepareRequest(Intent(hash, 9600), grant, NewKey());
        using var okResponse = await engineer.SendAsync(ok, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, okResponse.StatusCode);

        var staleGrant = await StepUpAsync(engineer);
        using var bad = PrepareRequest(Intent(new string('b', 64), 9601), staleGrant, NewKey());
        using var badResponse = await engineer.SendAsync(bad, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, badResponse.StatusCode);

        using var auditor = factory.CreateClient();
        auditor.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-AUDITOR-CMD");
        auditor.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        auditor.DefaultRequestHeaders.Add("X-CH1-Roles", "Auditor");

        using var events = await auditor.GetAsync(
            "/api/v1/audit/events?limit=1000",
            TestContext.Current.CancellationToken);
        var body = await events.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var types = body.GetProperty("items").EnumerateArray()
            .Where(item => item.GetProperty("actorId").GetString() == "USR-AUDITED-CMD")
            .Select(item => item.GetProperty("eventType").GetString())
            .ToArray();

        Assert.Contains("CommandPrepared", types);
        Assert.Contains("CommandPrepareRejected", types);
    }

    /// <summary>Guards against a formatting regression in the seeded state hash.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0027")]
    public async Task Ch1CmdFr0008_TheCellReportsASixtyFourCharacterStateHash()
    {
        using var engineer = Engineer("USR-HASH-01");
        var hash = await ExpectedStateHashAsync(engineer);

        Assert.Equal(64, hash.Length);
        Assert.True(hash.All(Uri.IsHexDigit), FormattableString.Invariant($"State hash is not hexadecimal: {hash}"));
        Assert.Equal(hash.ToLowerInvariant(), hash, StringComparer.Ordinal);
    }

    private static async Task<Guid> PreparedCommandAsync(HttpClient client, long sequence)
    {
        var hash = await ExpectedStateHashAsync(client);
        using var request = PrepareRequest(Intent(hash, sequence), await StepUpAsync(client), NewKey());
        using var response = await client.SendAsync(request, TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await Body(response);
        Assert.Equal("AwaitingCredential", body.GetProperty("state").GetString());
        return body.GetProperty("commandId").GetGuid();
    }

    private static Task<HttpResponseMessage> CancelAsync(HttpClient client, Guid commandId, string reason) =>
        client.PostAsJsonAsync(
            $"/api/v1/commands/{commandId}/cancel",
            new { Reason = reason },
            TestContext.Current.CancellationToken);

    /// <summary>
    /// Cancelling a prepared command, which api_endpoints.json requires to be idempotent
    /// and to carry a reason.
    /// </summary>
    /// <remarks>
    /// Idempotence here is a safety property rather than a convenience. A client whose
    /// first cancel timed out must be able to retry and learn that the command is
    /// cancelled; an error on the retry could be read as "still armed", which is the one
    /// conclusion that must never be reached by accident. The repeat therefore returns
    /// the same terminal state at the same version, carrying the reason first recorded.
    /// </remarks>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0013")]
    public async Task Ch1CmdFr0004_CancellingIsIdempotentAndKeepsTheReasonItRecordedFirst()
    {
        using var engineer = Engineer("USR-CANCEL-01");
        var commandId = await PreparedCommandAsync(engineer, 9401);

        using var missingReason = await CancelAsync(engineer, commandId, "  ");
        Assert.Equal(HttpStatusCode.BadRequest, missingReason.StatusCode);
        Assert.Equal("CANCEL_REASON_REQUIRED", (await Body(missingReason)).GetProperty("code").GetString());

        using var cancelled = await CancelAsync(engineer, commandId, "Operator stood down the cell");
        Assert.Equal(HttpStatusCode.OK, cancelled.StatusCode);
        var first = await Body(cancelled);
        Assert.Equal("Cancelled", first.GetProperty("state").GetString());
        Assert.Equal("Operator stood down the cell", first.GetProperty("terminalReason").GetString());
        var version = first.GetProperty("version").GetInt32();

        using var repeated = await CancelAsync(engineer, commandId, "A different reason on the retry");
        Assert.Equal(HttpStatusCode.OK, repeated.StatusCode);
        var second = await Body(repeated);
        Assert.Equal("Cancelled", second.GetProperty("state").GetString());
        // No second effect: the version did not move, and the reason first recorded stands.
        Assert.Equal(version, second.GetProperty("version").GetInt32());
        Assert.Equal("Operator stood down the cell", second.GetProperty("terminalReason").GetString());
    }

    /// <summary>
    /// "Requester or authorised Engineer" in the catalogue. An identity holding neither
    /// may not stand down somebody else's prepared command.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0013")]
    public async Task Ch1CmdFr0004_OnlyTheRequesterOrAnEngineerMayCancel()
    {
        using var requester = Engineer("USR-CANCEL-OWNER-01");
        var commandId = await PreparedCommandAsync(requester, 9402);

        using var stranger = factory.CreateClient();
        stranger.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-CANCEL-STRANGER-01");
        stranger.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        stranger.DefaultRequestHeaders.Add("X-CH1-Roles", "Viewer");
        stranger.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        stranger.DefaultRequestHeaders.Add("X-CH1-Session", "session-stranger");

        using var refused = await CancelAsync(stranger, commandId, "Not mine to cancel");

        Assert.Equal(HttpStatusCode.Forbidden, refused.StatusCode);
        Assert.Equal("AUTH_COMMAND_CANCEL_FORBIDDEN", (await Body(refused)).GetProperty("code").GetString());

        // And the command is still exactly where it was, awaiting its local credential.
        using var unchanged = await CancelAsync(requester, commandId, "Stood down by the requester");
        Assert.Equal(HttpStatusCode.OK, unchanged.StatusCode);
        Assert.Equal("Cancelled", (await Body(unchanged)).GetProperty("state").GetString());
    }

    /// <summary>
    /// <b>Defect 77: the command read is the visible execution outcome, and carried only
    /// half of it.</b>
    /// <para>
    /// <c>api_endpoints.json</c> controls <c>GET /api/v1/commands/{commandId}</c> as "Read
    /// command lifecycle AND controller acknowledgements", with "object-level
    /// authorisation and immutable audit links". It returned the lifecycle alone — which
    /// is what the domain decided, never what the equipment answered — so the last
    /// message of the controlled PREPARE / LOCAL COMMIT sequence delivered nothing an
    /// engineer could read as an outcome.
    /// </para>
    /// <para>
    /// The audit links are asserted to be correlated and hash-linked rather than merely
    /// present: a list of event identifiers with no join and no hash would satisfy the
    /// field name and none of the control.
    /// </para>
    /// </summary>
    /// <requirements>CH1-CMD-FR-0006, CH1-TRC-FR-0002, CH1-CYB-FR-0006</requirements>
    [Fact]
    public async Task Ch1CmdFr0006_TheCommandReadCarriesAcknowledgementsAndImmutableAuditLinks()
    {
        using var engineer = Engineer("USR-OUTCOME-01");
        var commandId = await PreparedCommandAsync(engineer, 9501);

        using var response = await engineer.GetAsync(
            $"/api/v1/commands/{commandId}", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await Body(response);

        // Both halves are present as distinct fields. Merging them would invite a reader
        // to treat an acknowledgement as execution, which is the one thing the
        // acknowledgement is documented never to be.
        Assert.Equal("AwaitingCredential", body.GetProperty("state").GetString());
        Assert.True(body.GetProperty("acknowledgementIsNotExecution").GetBoolean());
        var acknowledgements = body.GetProperty("acknowledgements");
        Assert.Equal(JsonValueKind.Array, acknowledgements.ValueKind);

        // No controller has answered this command, so the list is empty rather than
        // absent. An absent field and an empty one say different things, and only the
        // second is honest about a transaction nothing has acknowledged yet.
        Assert.Empty(acknowledgements.EnumerateArray());

        // The audit links are the command's own evidence: at least the preparation, each
        // carrying the hash that makes altering it detectable.
        var links = body.GetProperty("auditLinks").EnumerateArray().ToArray();
        Assert.NotEmpty(links);
        Assert.Contains(links, link => link.GetProperty("eventType").GetString() == "CommandPrepared");
        foreach (var link in links)
        {
            Assert.Equal(64, link.GetProperty("eventHash").GetString()!.Length);
            Assert.False(string.IsNullOrWhiteSpace(link.GetProperty("payloadHash").GetString()));
        }

        // Object-level authorisation still decides first. A reader in another project
        // gets nothing, evidence included — the links must not become a side channel
        // into a project the caller cannot read.
        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-OUTCOME-OUTSIDER-01");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", "00000000-0000-4000-8000-0000000009ff");
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "Engineer");
        outsider.DefaultRequestHeaders.Add("X-CH1-Session", "session-outcome-outsider");
        using var refused = await outsider.GetAsync(
            $"/api/v1/commands/{commandId}", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, refused.StatusCode);
    }

    private static async Task<JsonElement> Body(HttpResponseMessage response) =>
        await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

}
