// Tests for reports and scan events over HTTP.

using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Cinerion.Domain.Evidence;
using Cinerion.Infrastructure.Seed;
using Microsoft.Extensions.DependencyInjection;

namespace Cinerion.Api.Tests;

/// <summary>
/// Report generation and field scan events over HTTP.
/// </summary>
/// <requirements>CH1-RPT-FR-0001, CH1-RPT-FR-0002, CH1-MFG-FR-0002, CH1-TRC-FR-0002</requirements>
public sealed class EvidenceEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private static readonly Guid ProjectId = PrototypeSeed.Ids.ProjectId;
    private static readonly Guid CellId = PrototypeSeed.Ids.CellId;
    private static readonly Guid PartId = PrototypeSeed.Ids.PartId;

    private HttpClient Client(string actorId, string roles)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actorId);
        client.DefaultRequestHeaders.Add("X-CH1-Project", ProjectId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Roles", roles);
        client.DefaultRequestHeaders.Add("X-CH1-Cells", CellId.ToString());
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", "Mfa");
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actorId}");
        client.DefaultRequestHeaders.Add(
            "X-CH1-Auth-Time",
            DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture));
        return client;
    }

    // ------------------------------------------------------------------ reports

    [Fact]
    [VerificationCase("CH1-VVT-TC-0060")]
    [VerificationCase("CH1-VVT-TC-0061")]
    public async Task CH1_RPT_FR_0001_A_report_pins_its_template_revision_and_inputs()
    {
        using var inspector = Client("USR-INSPECTOR-RPT-01", "Inspector");

        using var response = await inspector.PostAsJsonAsync(
            "/api/v1/reports",
            new
            {
                templateId = "CH1-RPT-TPL-PART-GENEALOGY",
                reportType = "PartGenealogy",
                inputObjectType = "Part",
                inputObjectIds = new[] { PartId.ToString() },
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var report = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal("1.0.0", report.GetProperty("templateRevision").GetString());
        Assert.Equal("Part", report.GetProperty("inputObjectType").GetString());
        Assert.Equal(64, report.GetProperty("contentSha256").GetString()!.Length);
        Assert.Equal(64, report.GetProperty("determinismKey").GetString()!.Length);
        // CH1-RPT-FR-0002 wants the approval state on the face of the report. The
        // platform generates and does not approve.
        Assert.Equal("Unapproved", report.GetProperty("approvalState").GetString());
        Assert.False(report.GetProperty("alreadyExisted").GetBoolean());
    }

    /// <summary>
    /// The property the operation exists to have. Two requests naming the same records
    /// under the same template must return the same report, whatever order the caller
    /// lists the identifiers in — otherwise a retry after a dropped response produces a
    /// second document with a different checksum covering the same evidence.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0060")]
    public async Task CH1_RPT_FR_0001_The_same_inputs_return_the_same_report_not_a_second_one()
    {
        using var inspector = Client("USR-INSPECTOR-RPT-02", "Inspector");
        var body = new
        {
            templateId = "CH1-RPT-TPL-TEST-SUMMARY",
            reportType = "TestSummary",
            inputObjectType = "Part",
            // Deliberately unordered, and the second request reverses them.
            inputObjectIds = new[] { PartId.ToString(), Guid.Empty.ToString() },
        };

        using var first = await inspector.PostAsJsonAsync("/api/v1/reports", body, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);
        var firstReport = await first.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        using var second = await inspector.PostAsJsonAsync(
            "/api/v1/reports",
            body with { },
            TestContext.Current.CancellationToken);

        // 200, not 201: this request returned the report the first one generated.
        Assert.Equal(HttpStatusCode.OK, second.StatusCode);
        var secondReport = await second.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.True(secondReport.GetProperty("alreadyExisted").GetBoolean());
        Assert.Equal(
            firstReport.GetProperty("reportId").GetGuid(),
            secondReport.GetProperty("reportId").GetGuid());
        Assert.Equal(
            firstReport.GetProperty("contentSha256").GetString(),
            secondReport.GetProperty("contentSha256").GetString());
    }

    [Fact]
    public async Task CH1_RPT_FR_0001_A_template_this_build_does_not_hold_is_refused()
    {
        using var inspector = Client("USR-INSPECTOR-RPT-03", "Inspector");

        using var response = await inspector.PostAsJsonAsync(
            "/api/v1/reports",
            new
            {
                templateId = "CH1-RPT-TPL-INVENTED",
                reportType = "Whatever",
                inputObjectType = "Part",
                inputObjectIds = new[] { PartId.ToString() },
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("REPORT_TEMPLATE_UNKNOWN", problem.GetProperty("code").GetString());
    }

    [Fact]
    public async Task CH1_RPT_FR_0001_A_report_with_no_inputs_is_refused()
    {
        using var inspector = Client("USR-INSPECTOR-RPT-04", "Inspector");

        using var response = await inspector.PostAsJsonAsync(
            "/api/v1/reports",
            new
            {
                templateId = "CH1-RPT-TPL-NCR-REGISTER",
                reportType = "NcrRegister",
                inputObjectType = "Ncr",
                inputObjectIds = Array.Empty<string>(),
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("REPORT_INPUTS_REQUIRED", problem.GetProperty("code").GetString());
    }

    [Fact]
    public async Task CH1_RPT_FR_0001_A_viewer_cannot_generate_a_report()
    {
        using var viewer = Client("USR-VIEWER-RPT-01", "Viewer");

        using var response = await viewer.PostAsJsonAsync(
            "/api/v1/reports",
            new
            {
                templateId = "CH1-RPT-TPL-PART-GENEALOGY",
                reportType = "PartGenealogy",
                inputObjectType = "Part",
                inputObjectIds = new[] { PartId.ToString() },
            },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("AUTH_REPORT_GENERATION", problem.GetProperty("code").GetString());
    }

    // -------------------------------------------------------------- scan events

    /// <summary>
    /// Enrols a device with a certificate thumbprint, which is the material the scan
    /// session signature is computed from. Each test uses its own device so trust and
    /// duplicate state cannot leak between them.
    /// </summary>
    private async Task<(string DeviceId, byte[] SessionKey)> ProvisionScannerAsync(
        string suffix,
        string trustState,
        CancellationToken cancellationToken)
    {
        var deviceId = $"CH1-DEV-SCAN-{suffix}";
        var sessionKey = System.Security.Cryptography.RandomNumberGenerator.GetBytes(32);
        await using var scope = factory.Services.CreateAsyncScope();
        scope.ServiceProvider.GetService<Cinerion.Infrastructure.Persistence.ProjectScope>()?.Set(ProjectId);
        var store = scope.ServiceProvider.GetRequiredService<Cinerion.Application.Abstractions.ICinerionStore>();
        await store.SaveDeviceAsync(
            new Cinerion.Domain.Assets.DeviceRecord(
                deviceId, ProjectId, CellId, "FieldCompanion", "1.0.0", "CFG-R01",
                Convert.ToHexStringLower(sessionKey), trustState, null, null, 1),
            cancellationToken);
        return (deviceId, sessionKey);
    }

    private static object ScanBody(
        string deviceId,
        byte[] sessionKey,
        string identifier,
        DateTimeOffset scannedAt,
        string station = "STATION-01",
        string? forcedSignature = null) => new
        {
            deviceId,
            stationId = station,
            identifierKind = "QR",
            identifierValue = identifier,
            scannedAt,
            sessionSignature = forcedSignature ?? ScanEventRecord.ComputeSessionSignature(
                deviceId, station, identifier, scannedAt, sessionKey),
        };

    [Fact]
    [VerificationCase("CH1-VVT-TC-0031")]
    [VerificationCase("CH1-VVT-TC-0033")]
    public async Task CH1_MFG_FR_0002_A_signed_scan_resolves_the_part_and_confers_no_authority()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "01", Cinerion.Domain.Assets.DeviceTrustState.Trusted, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-01", "Engineer");
        var scannedAt = DateTimeOffset.UtcNow.AddSeconds(-5);

        using var response = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            ScanBody(deviceId, sessionKey, "CH1-PART-000017-04", scannedAt),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var scan = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal("Resolved", scan.GetProperty("resolution").GetString());
        Assert.Equal(PartId, scan.GetProperty("partId").GetGuid());
        Assert.Equal("CH1-PART-000017-04", scan.GetProperty("part").GetProperty("serialNumber").GetString());
        // The whole point of the operation is what it does not do.
        Assert.Contains("starts no equipment", scan.GetProperty("controlSideEffect").GetString());
        Assert.Contains("proves nothing about who is holding the tag", scan.GetProperty("controlSideEffect").GetString());
    }

    [Fact]
    public async Task CH1_TRC_FR_0002_A_forged_session_signature_is_refused()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "02", Cinerion.Domain.Assets.DeviceTrustState.Trusted, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-02", "Engineer");

        using var response = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            ScanBody(
                deviceId, sessionKey, "CH1-PART-000017-04", DateTimeOffset.UtcNow.AddSeconds(-5),
                forcedSignature: new string('a', 64)),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("SCAN_SESSION_SIGNATURE_INVALID", problem.GetProperty("code").GetString());
    }

    /// <summary>
    /// A re-delivered scan is recorded as pointing at the first, never dropped, so a
    /// retry stays visible and a gap in the sequence is not mistaken for a missed scan.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0033")]
    public async Task CH1_TRC_FR_0002_A_redelivered_scan_is_linked_to_the_first_not_dropped()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "03", Cinerion.Domain.Assets.DeviceTrustState.Trusted, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-03", "Engineer");
        var scannedAt = DateTimeOffset.UtcNow.AddSeconds(-5);
        var body = ScanBody(deviceId, sessionKey, "CH1-PART-000017-04", scannedAt);

        using var first = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events", body, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);
        var firstScan = await first.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        using var second = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events", body, TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, second.StatusCode);
        var secondScan = await second.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal("Duplicate", secondScan.GetProperty("resolution").GetString());
        Assert.Equal(
            firstScan.GetProperty("scanEventId").GetGuid(),
            secondScan.GetProperty("duplicateOf").GetGuid());
        // Two distinct records: the retry is evidence in its own right.
        Assert.NotEqual(
            firstScan.GetProperty("scanEventId").GetGuid(),
            secondScan.GetProperty("scanEventId").GetGuid());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0033")]
    public async Task CH1_MFG_FR_0002_An_unknown_identifier_resolves_to_no_part_rather_than_a_guess()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "04", Cinerion.Domain.Assets.DeviceTrustState.Trusted, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-04", "Engineer");

        using var response = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            ScanBody(deviceId, sessionKey, "CH1-PART-NOT-A-REAL-TAG", DateTimeOffset.UtcNow.AddSeconds(-5)),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var scan = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);

        Assert.Equal("UnknownIdentifier", scan.GetProperty("resolution").GetString());
        Assert.Equal(JsonValueKind.Null, scan.GetProperty("partId").ValueKind);
        Assert.Equal(JsonValueKind.Null, scan.GetProperty("part").ValueKind);
    }

    /// <summary>
    /// A revoked device cannot deliver scans any more than it can deliver telemetry.
    /// Revocation that stopped only one of the two would leave a withdrawn device still
    /// writing to the digital thread.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0006")]
    public async Task CH1_IAM_FR_0006_A_revoked_device_cannot_deliver_a_scan()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "05", Cinerion.Domain.Assets.DeviceTrustState.Revoked, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-05", "Engineer");

        using var response = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            ScanBody(deviceId, sessionKey, "CH1-PART-000017-04", DateTimeOffset.UtcNow.AddSeconds(-5)),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("SCAN_DEVICE_NOT_TRUSTED", problem.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0026")]
    public async Task CH1_COM_FR_0007_A_scan_older_than_the_store_and_forward_buffer_is_refused()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "06", Cinerion.Domain.Assets.DeviceTrustState.Trusted, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-06", "Engineer");

        using var response = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            ScanBody(deviceId, sessionKey, "CH1-PART-000017-04", DateTimeOffset.UtcNow.AddHours(-30)),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("SCAN_TOO_OLD_TO_ACCEPT", problem.GetProperty("code").GetString());
    }

    /// <summary>
    /// The signature covers the station, so a scan captured at one station cannot be
    /// replayed as though it happened at another. Station scope is a control on the
    /// operation, not a label on it.
    /// </summary>
    [Fact]
    public async Task CH1_TRC_FR_0002_A_scan_cannot_be_replayed_at_a_different_station()
    {
        var (deviceId, sessionKey) = await ProvisionScannerAsync(
            "07", Cinerion.Domain.Assets.DeviceTrustState.Trusted, TestContext.Current.CancellationToken);
        using var field = Client("USR-FIELD-07", "Engineer");
        var scannedAt = DateTimeOffset.UtcNow.AddSeconds(-5);

        var signedForStationOne = ScanEventRecord.ComputeSessionSignature(
            deviceId, "STATION-01", "CH1-PART-000017-04", scannedAt, sessionKey);

        using var response = await field.PostAsJsonAsync(
            "/api/v1/parts/scan-events",
            ScanBody(
                deviceId, sessionKey, "CH1-PART-000017-04", scannedAt,
                station: "STATION-02", forcedSignature: signedForStationOne),
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var problem = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("SCAN_SESSION_SIGNATURE_INVALID", problem.GetProperty("code").GetString());
    }
}
