// Checks this assembly's verification-case tags against the controlled list.

namespace Cinerion.Api.Tests;

/// <summary>
/// Reconciles this assembly's <c>[VerificationCase]</c> bindings with
/// <c>traceability/verification-map.json</c>, in both directions.
/// </summary>
/// <remarks>
/// The map is a claim about what has executable evidence. Without this it would be a
/// claim nothing checked, which is the failure mode the rest of this suite exists to
/// avoid: a record that reads as verification while verifying nothing. Because the
/// bindings are read from the loaded types, a case cannot be claimed for a test that
/// was renamed, deleted, or never written.
/// </remarks>
/// <requirements>CH1-VVT-VMP-0001, CH1-SYS-RTM-0001</requirements>
public sealed class VerificationBindingTests
{
    private const string Harness = "Cinerion.Api.Tests";

    [Fact]
    public void TheMapAndThisAssemblyAgreeOnEveryControlledCase()
    {
        var failures = VerificationBinding.Reconcile(typeof(VerificationBindingTests).Assembly, Harness);

        Assert.True(failures.Count == 0, string.Join(Environment.NewLine, failures));
    }

    /// <summary>
    /// Guards the reflection itself: if the attribute were removed or the assembly
    /// scanned were the wrong one, the check above would agree with an empty map and
    /// pass over nothing.
    /// </summary>
    [Fact]
    public void TheBindingsAreActuallyBeingFound()
    {
        var observed = VerificationBinding.ObservedIn(typeof(VerificationBindingTests).Assembly);

        Assert.True(observed.Count >= 30, $"Expected this assembly's controlled-case bindings; found {observed.Count}.");
        Assert.Contains("CH1-VVT-TC-0106", observed.Keys);
        Assert.Contains("CH1-VVT-TC-0109", observed.Keys);
    }

    /// <summary>
    /// Records what actually ran, so a verification report cites tests rather than the
    /// map's claim about them.
    /// </summary>
    [Fact]
    public void ObservedBindingsArePublishedAsEvidence()
    {
        var path = VerificationBinding.WriteObservedBindings(typeof(VerificationBindingTests).Assembly, Harness);

        Assert.True(File.Exists(path), path);
    }

    /// <summary>
    /// Every binding this assembly carries must be on something xUnit will run. A
    /// binding on a helper is a claim with no execution behind it.
    /// </summary>
    [Fact]
    public void EveryBindingSitsOnAnExecutableTest()
    {
        var suspect = VerificationBinding.ObservedIn(typeof(VerificationBindingTests).Assembly)
            .SelectMany(pair => pair.Value.Select(test => $"{pair.Key}: {test}"))
            .Where(entry => entry.Contains("(not a test)", StringComparison.Ordinal)
                         || entry.Contains("(no test method)", StringComparison.Ordinal))
            .ToArray();

        Assert.True(suspect.Length == 0, string.Join(Environment.NewLine, suspect));
    }
}
