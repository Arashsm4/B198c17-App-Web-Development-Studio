// Tests for the whole quality loop over HTTP, from test run to release.

using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace Cinerion.Api.Tests;

/// <summary>
/// The quality workflow over HTTP: a controlled run, results against it, hold, the
/// nonconformity, its disposition, and the retest that closes it.
/// </summary>
/// <requirements>CH1-QMS-FR-0001, CH1-QMS-FR-0003, CH1-QMS-FR-0004, CH1-QMS-FR-0006</requirements>
public sealed class QualityWorkflowEndpointTests(CinerionApiFactory factory) : IClassFixture<CinerionApiFactory>
{
    private const string Project = "00000000-0000-4000-8000-000000000101";
    private const string Cell = "00000000-0000-4000-8000-000000000103";
    private const string Part = "00000000-0000-4000-8000-000000000106";
    private const string Calibration = "00000000-0000-4000-8000-000000000108";

    private HttpClient Inspector(string actor, string strength = "StepUpPhishingResistant") =>
        InspectorOn(factory, actor, strength);

    private static HttpClient InspectorOn(
        CinerionApiFactory host,
        string actor,
        string strength = "StepUpPhishingResistant")
    {
        var client = host.CreateClient();
        client.DefaultRequestHeaders.Add("X-CH1-Actor", actor);
        client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        client.DefaultRequestHeaders.Add("X-CH1-Roles", "Inspector");
        client.DefaultRequestHeaders.Add("X-CH1-Cells", Cell);
        client.DefaultRequestHeaders.Add("X-CH1-Auth-Strength", strength);
        client.DefaultRequestHeaders.Add("X-CH1-Session", $"session-{actor}");
        return client;
    }

    private static async Task<Guid> StartRunAsync(HttpClient client)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.GetProperty("testRunId").GetGuid();
    }

    private static Task<HttpResponseMessage> MeasureAsync(
        HttpClient client,
        Guid runId,
        string characteristic,
        decimal value,
        decimal lower,
        decimal upper,
        Guid? supersedes = null) =>
        client.PostAsJsonAsync(
            $"/api/v1/test-runs/{runId}/measurements",
            new
            {
                PartId = Part,
                Characteristic = characteristic,
                Value = value,
                Unit = "um",
                LowerLimit = lower,
                UpperLimit = upper,
                Mandatory = true,
                SourceDeviceId = "CH1-INS-THK-0001",
                CalibrationRecordId = Calibration,
                CalibrationValid = true,
                SupersedesMeasurementId = supersedes,
            },
            TestContext.Current.CancellationToken);

    private static async Task<Guid> StepUpAsync(HttpClient client, string purpose)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/auth/step-up",
            new { Purpose = purpose },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.GetProperty("grantId").GetGuid();
    }

    /// <summary>
    /// The run is a stored record. Previously the endpoint returned a fresh identifier
    /// and stored nothing, so this identifier could not be used for anything.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0040")]
    public async Task Ch1QmsFr0001_ATestRunIsPersistedAndPinsItsProcedureRevision()
    {
        using var inspector = Inspector("USR-QA-RUN-01");

        using var response = await inspector.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "R01" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.NotEqual(Guid.Empty, body.GetProperty("testRunId").GetGuid());
        Assert.Equal("R01", body.GetProperty("procedureRevision").GetString());
        Assert.Equal("InProgress", body.GetProperty("status").GetString());
        Assert.Equal("USR-QA-RUN-01", body.GetProperty("startedBy").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0040")]
    public async Task Ch1QmsFr0001_ATestRunWithoutAPinnedRevisionIsRefused()
    {
        using var inspector = Inspector("USR-QA-RUN-02");

        using var response = await inspector.PostAsJsonAsync(
            "/api/v1/test-runs",
            new { PartId = Part, ProcedureId = "CH1-REFAB-PROC-0001", ProcedureRevision = "" },
            TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("TEST_RUN_PROCEDURE_REVISION_REQUIRED", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// A result must belong to a run that exists. The route identifier used to be
    /// echoed and ignored, so any value at all appeared to produce controlled evidence.
    /// </summary>
    [Fact]
    public async Task Ch1QmsFr0002_AMeasurementAgainstAnUnknownRunIsRefused()
    {
        using var inspector = Inspector("USR-QA-RUN-03");

        using var response = await MeasureAsync(inspector, Guid.NewGuid(), "Coating thickness", 10.0m, 9.5m, 10.5m);

        // A missing object answers 404 by the established convention, so an unknown
        // run and one outside the caller's scope remain indistinguishable.
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("TEST_RUN_NOT_FOUND", body.GetProperty("code").GetString());
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0041")]
    [VerificationCase("CH1-VVT-TC-0050")]
    public async Task Ch1QmsFr0002_AMeasurementCarriesTheRunItWasRecordedUnder()
    {
        using var inspector = Inspector("USR-QA-RUN-04");
        var runId = await StartRunAsync(inspector);

        using var response = await MeasureAsync(inspector, runId, "Web tension", 1.2m, 1.1m, 1.3m);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal(runId, body.GetProperty("measurement").GetProperty("testRunId").GetGuid());
    }

    /// <summary>
    /// The full nonconformity path: a failing mandatory result holds the part, the
    /// nonconformity is a record with its evidence link, a passing retest supersedes
    /// the failure, and a closing disposition releases the hold.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0043")]
    public async Task Ch1QmsFr0004_AFailedResultIsClosedOnlyByDispositionAfterAPassingRetest()
    {
        // This test asserts the whole-part status, which every sibling test in this
        // class also mutates through the shared seeded part and the single in-memory
        // store. It therefore runs against its own host so the transition from Hold to
        // Accepted reflects only what this test did.
        using var isolated = new CinerionApiFactory();
        using var inspector = InspectorOn(isolated, "USR-QA-FLOW-01");
        var runId = await StartRunAsync(inspector);

        using var failing = await MeasureAsync(inspector, runId, "Coating thickness", 8.2m, 9.5m, 10.5m);
        Assert.Equal(HttpStatusCode.Created, failing.StatusCode);
        var failingBody = await failing.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Hold", failingBody.GetProperty("partStatus").GetString());
        var failedId = failingBody.GetProperty("measurement").GetProperty("measurementId").GetGuid();

        using var ncrResponse = await inspector.PostAsJsonAsync(
            "/api/v1/ncrs",
            new { PartId = Part, Title = "Coating thickness below limit", Description = "8.20 against 9.50-10.50" },
            TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.Created, ncrResponse.StatusCode);
        var ncrBody = await ncrResponse.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        var ncrId = ncrBody.GetProperty("ncrId").GetGuid();
        // The evidence link survives into the record.
        Assert.Equal(failedId, ncrBody.GetProperty("sourceMeasurementId").GetGuid());
        Assert.Equal(runId, ncrBody.GetProperty("testRunId").GetGuid());
        Assert.Equal("Open", ncrBody.GetProperty("status").GetString());

        // Closing before a passing retest must be refused.
        var earlyGrant = await StepUpAsync(inspector, "NcrDisposition");
        using var early = await DisposeAsync(inspector, ncrId, earlyGrant, "Close", "No retest yet");
        Assert.Equal(HttpStatusCode.BadRequest, early.StatusCode);
        var earlyBody = await early.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("RETEST_NOT_PASSING", earlyBody.GetProperty("code").GetString());

        using var retest = await MeasureAsync(inspector, runId, "Coating thickness", 10.1m, 9.5m, 10.5m, failedId);
        Assert.Equal(HttpStatusCode.Created, retest.StatusCode);

        var grant = await StepUpAsync(inspector, "NcrDisposition");
        using var closed = await DisposeAsync(inspector, ncrId, grant, "Close", "Rework verified by passing retest");
        Assert.Equal(HttpStatusCode.Created, closed.StatusCode);
        var closedBody = await closed.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Closed", closedBody.GetProperty("status").GetString());
        Assert.Equal("Accepted", closedBody.GetProperty("partStatus").GetString());
        Assert.NotEqual(Guid.Empty, closedBody.GetProperty("closedByMeasurementId").GetGuid());
    }

    private static Task<HttpResponseMessage> DisposeAsync(
        HttpClient client,
        Guid ncrId,
        Guid grantId,
        string disposition,
        string justification)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/ncrs/{ncrId}/dispositions")
        {
            Content = JsonContent.Create(new { Disposition = disposition, Justification = justification }),
        };
        request.Headers.Add("X-CH1-Step-Up", grantId.ToString());
        return client.SendAsync(request, TestContext.Current.CancellationToken);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0004")]
    public async Task Ch1IamFr0004_DispositionWithoutAStepUpGrantIsRefused()
    {
        using var inspector = Inspector("USR-QA-STEP-01");
        var runId = await StartRunAsync(inspector);
        using var _ = await MeasureAsync(inspector, runId, "Coating thickness", 8.2m, 9.5m, 10.5m);
        var ncrId = await RaiseAsync(inspector);

        using var request = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/ncrs/{ncrId}/dispositions")
        {
            Content = JsonContent.Create(new { Disposition = "Scrap", Justification = "Beyond rework" }),
        };
        using var response = await inspector.SendAsync(request, TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("STEP_UP_REQUIRED", body.GetProperty("code").GetString());
    }

    /// <summary>A decision, once made, is not overwritten by a second one.</summary>
    [Fact]
    public async Task Ch1QmsFr0004_ADispositionIsImmutable()
    {
        using var inspector = Inspector("USR-QA-IMMUTABLE-01");
        var runId = await StartRunAsync(inspector);
        using var _ = await MeasureAsync(inspector, runId, "Coating thickness", 8.2m, 9.5m, 10.5m);
        var ncrId = await RaiseAsync(inspector);

        var first = await StepUpAsync(inspector, "NcrDisposition");
        using var scrapped = await DisposeAsync(inspector, ncrId, first, "Scrap", "Beyond rework");
        Assert.Equal(HttpStatusCode.Created, scrapped.StatusCode);

        var second = await StepUpAsync(inspector, "NcrDisposition");
        using var again = await DisposeAsync(inspector, ncrId, second, "UseAsIs", "Changed my mind");

        Assert.Equal(HttpStatusCode.BadRequest, again.StatusCode);
        var body = await again.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("NCR_NOT_OPEN", body.GetProperty("code").GetString());
    }

    /// <summary>
    /// A non-closing disposition decides what happens to a part that is still
    /// nonconforming, so the hold must remain.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0043")]
    public async Task Ch1QmsFr0004_ANonClosingDispositionLeavesThePartOnHold()
    {
        using var inspector = Inspector("USR-QA-HOLD-01");
        var runId = await StartRunAsync(inspector);
        using var _ = await MeasureAsync(inspector, runId, "Coating thickness", 8.2m, 9.5m, 10.5m);
        var ncrId = await RaiseAsync(inspector);

        var grant = await StepUpAsync(inspector, "NcrDisposition");
        using var response = await DisposeAsync(inspector, ncrId, grant, "Rework", "Recoat and retest");

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("Dispositioned", body.GetProperty("status").GetString());
        Assert.Equal("Hold", body.GetProperty("partStatus").GetString());
    }

    /// <summary>
    /// The seeded part records USR-OPERATOR-01 as the operator, so that identity must
    /// not be able to decide the disposition of its own work.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0044")]
    public async Task Ch1QmsFr0005_TheOperatorCannotDispositionTheirOwnWork()
    {
        using var inspector = Inspector("USR-QA-SEG-01");
        var runId = await StartRunAsync(inspector);
        using var _ = await MeasureAsync(inspector, runId, "Coating thickness", 8.2m, 9.5m, 10.5m);
        var ncrId = await RaiseAsync(inspector);

        using var operatorClient = Inspector("USR-OPERATOR-01");
        var grant = await StepUpAsync(operatorClient, "NcrDisposition");
        using var response = await DisposeAsync(operatorClient, ncrId, grant, "UseAsIs", "It is fine");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        Assert.Equal("SEGREGATION_OF_DUTIES", body.GetProperty("code").GetString());
    }

    private static async Task<Guid> RaiseAsync(HttpClient client)
    {
        using var response = await client.PostAsJsonAsync(
            "/api/v1/ncrs",
            new { PartId = Part, Title = "Coating thickness below limit", Description = "Out of tolerance" },
            TestContext.Current.CancellationToken);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);
        return body.GetProperty("ncrId").GetGuid();
    }

    private static Task<HttpResponseMessage> ReleaseAsync(HttpClient client, Guid? grantId)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/release-records")
        {
            Content = JsonContent.Create(new { PartId = Part }),
        };
        if (grantId is not null)
        {
            request.Headers.Add("X-CH1-Step-Up", grantId.Value.ToString());
        }

        return client.SendAsync(request, TestContext.Current.CancellationToken);
    }

    /// <summary>
    /// Independent release, end to end over HTTP for the first time.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The part reaches Accepted only through the controlled path - a failing mandatory
    /// result, a nonconformity, a passing retest and a closing disposition - so what is
    /// released here is a part that genuinely passed, not a fixture set to Accepted.
    /// </para>
    /// <para>
    /// Every refusal on the way is asserted, because the refusals are the requirement: no
    /// step-up, a step-up granted for another purpose, and the operator who performed the
    /// work attempting to release their own part.
    /// </para>
    /// </remarks>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0044")]
    public async Task Ch1QmsFr0005_ReleaseNeedsAnIndependentInspectorAndARedeemedPartReleaseStepUp()
    {
        using var isolated = new CinerionApiFactory();
        using var inspector = InspectorOn(isolated, "USR-QA-RELEASE-01");
        var runId = await StartRunAsync(inspector);

        using var failing = await MeasureAsync(inspector, runId, "Coating thickness", 8.2m, 9.5m, 10.5m);
        var failedId = (await BodyAsync(failing)).GetProperty("measurement").GetProperty("measurementId").GetGuid();
        using var ncrResponse = await inspector.PostAsJsonAsync(
            "/api/v1/ncrs",
            new { PartId = Part, Title = "Coating thickness below limit", Description = "8.20 against 9.50-10.50" },
            TestContext.Current.CancellationToken);
        var ncrId = (await BodyAsync(ncrResponse)).GetProperty("ncrId").GetGuid();
        using var retest = await MeasureAsync(inspector, runId, "Coating thickness", 10.1m, 9.5m, 10.5m, failedId);
        Assert.Equal(HttpStatusCode.Created, retest.StatusCode);
        using var closed = await DisposeAsync(
            inspector, ncrId, await StepUpAsync(inspector, "NcrDisposition"), "Close", "Rework verified");
        Assert.Equal("Accepted", (await BodyAsync(closed)).GetProperty("partStatus").GetString());

        // No step-up at all. A session that merely claims to be strong is not evidence
        // that this person re-authenticated for this release.
        using var bare = await ReleaseAsync(inspector, grantId: null);
        Assert.Equal(HttpStatusCode.BadRequest, bare.StatusCode);
        Assert.Equal("STEP_UP_REQUIRED", (await BodyAsync(bare)).GetProperty("code").GetString());

        // A grant that exists, is unspent, and is for something else.
        using var wrongPurpose = await ReleaseAsync(inspector, await StepUpAsync(inspector, "NcrDisposition"));
        Assert.Equal(HttpStatusCode.BadRequest, wrongPurpose.StatusCode);
        Assert.Equal("STEP_UP_PURPOSE_MISMATCH", (await BodyAsync(wrongPurpose)).GetProperty("code").GetString());

        // The operator who performed the work cannot release it, whatever they hold.
        using var performer = InspectorOn(isolated, "USR-OPERATOR-01");
        using var ownWork = await ReleaseAsync(performer, await StepUpAsync(performer, "PartRelease"));
        Assert.Equal(HttpStatusCode.BadRequest, ownWork.StatusCode);
        Assert.Equal("SEGREGATION_OF_DUTIES", (await BodyAsync(ownWork)).GetProperty("code").GetString());

        var grantId = await StepUpAsync(inspector, "PartRelease");
        using var released = await ReleaseAsync(inspector, grantId);
        Assert.Equal(HttpStatusCode.Created, released.StatusCode);
        var record = await BodyAsync(released);
        Assert.Equal("USR-QA-RELEASE-01", record.GetProperty("inspectorId").GetString());
        Assert.NotEqual(Guid.Empty, record.GetProperty("releaseId").GetGuid());
        Assert.NotEqual(default, record.GetProperty("releasedAt").GetDateTimeOffset());

        // Single use. The same grant cannot be presented a second time.
        using var reused = await ReleaseAsync(inspector, grantId);
        Assert.Equal(HttpStatusCode.BadRequest, reused.StatusCode);
    }

    /// <summary>
    /// CH1-MFG-FR-0002 requires a part to resolve to its work order, revision, operations
    /// and tests. The evidence graph is read here after the workflow has filled it, and
    /// the provenance line must name the store the evidence actually came from.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0031")]
    [VerificationCase("CH1-VVT-TC-0050")]
    public async Task Ch1MfgFr0002_GenealogyResolvesThePartToItsOrderRevisionAndTests()
    {
        using var isolated = new CinerionApiFactory();
        using var inspector = InspectorOn(isolated, "USR-QA-GENEALOGY-01");
        var runId = await StartRunAsync(inspector);
        using var measured = await MeasureAsync(inspector, runId, "Coating thickness", 10.1m, 9.5m, 10.5m);
        Assert.Equal(HttpStatusCode.Created, measured.StatusCode);

        using var response = await inspector.GetAsync(
            $"/api/v1/parts/{Part}/genealogy", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await BodyAsync(response);
        var part = body.GetProperty("part");
        Assert.Equal(Part, part.GetProperty("partId").GetGuid().ToString());
        Assert.NotEqual(Guid.Empty, part.GetProperty("workOrderId").GetGuid());
        Assert.NotEqual(Guid.Empty, part.GetProperty("revisionId").GetGuid());
        Assert.Equal("USR-OPERATOR-01", part.GetProperty("operatorId").GetString());
        var measurement = Assert.Single(part.GetProperty("measurements").EnumerateArray());
        Assert.Equal(runId, measurement.GetProperty("testRunId").GetGuid());
        Assert.Equal("Coating thickness", measurement.GetProperty("characteristic").GetString());
        // Open until a release record exists, and the store is named rather than assumed.
        Assert.Equal("Open", body.GetProperty("evidenceCompleteness").GetString());
        Assert.Equal("Volatile in-memory development store", body.GetProperty("provenance").GetString());
    }

    // ------------------------------------------ resolving a serial number to an identity

    /// <summary>
    /// Conflict 15. screens.json declares CH1-UX-SCR-0007 as "QR/RFID identity and
    /// complete history" for the Engineer and Inspector, and the only operation turning a
    /// scanned code into a part needs a signed session from an enrolled Field Companion
    /// device — correctly, because CH1-IAM-FR-0008 separates human, service and device
    /// accounts. The consequence was that an Engineer holding a printed serial number had
    /// no controlled route to the genealogy at all.
    /// </summary>
    /// <remarks>
    /// This resolves the identity and mints nothing. The assertions below are mostly about
    /// what it does NOT do: no scan event, no history, no enumeration, and no disclosure
    /// to an identity the genealogy itself would refuse.
    /// </remarks>
    [Fact]
    public async Task Ch1MfgFr0002_ASerialNumberResolvesToAnIdentityAndNothingElse()
    {
        using var inspector = Inspector("USR-QA-LOOKUP-01");

        using var response = await inspector.GetAsync(
            "/api/v1/parts?serialNumber=CH1-PART-000017-04", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await BodyAsync(response);
        Assert.Equal(Part, body.GetProperty("partId").GetGuid().ToString());
        Assert.Equal("CH1-PART-000017-04", body.GetProperty("serialNumber").GetString());
        Assert.Equal("urn:cinerion:ch1:part:CH1-PART-000017-04", body.GetProperty("permanentIdentityUri").GetString());
        Assert.Equal($"/api/v1/parts/{Part}/genealogy", body.GetProperty("genealogy").GetString());

        // It is not the evidence path and says so, rather than leaving a caller to assume
        // a lookup that answered was a scan that was recorded.
        Assert.False(body.GetProperty("scanEventRecorded").GetBoolean());

        // And it carries no history: no measurements, no NCRs, no release.
        var raw = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);
        foreach (var absent in new[] { "measurements", "openNcrIds", "release", "operatorId", "status" })
        {
            Assert.DoesNotContain(absent, raw, StringComparison.OrdinalIgnoreCase);
        }
    }

    [Fact]
    public async Task Ch1CybFr0001_TheLookupDisclosesNothingTheGenealogyWouldNot()
    {
        // A Local Confirmer holds neither Engineer, Inspector nor Auditor. Conflict 17
        // records that the genealogy answers them 404, and this lookup must answer
        // identically — a resolver that told them the serial exists would be a disclosure
        // the read it leads to refuses.
        using var confirmer = factory.CreateClient();
        confirmer.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-QA-CONFIRMER-01");
        confirmer.DefaultRequestHeaders.Add("X-CH1-Project", Project);
        confirmer.DefaultRequestHeaders.Add("X-CH1-Roles", "LocalConfirmer");

        using var lookup = await confirmer.GetAsync(
            "/api/v1/parts?serialNumber=CH1-PART-000017-04", TestContext.Current.CancellationToken);
        using var genealogy = await confirmer.GetAsync(
            $"/api/v1/parts/{Part}/genealogy", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, lookup.StatusCode);
        Assert.Equal(genealogy.StatusCode, lookup.StatusCode);

        // Another project's serial is likewise indistinguishable from one that never was.
        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-QA-OUTSIDER-02");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "Inspector");

        using var otherProject = await outsider.GetAsync(
            "/api/v1/parts?serialNumber=CH1-PART-000017-04", TestContext.Current.CancellationToken);
        using var neverExisted = await outsider.GetAsync(
            "/api/v1/parts?serialNumber=CH1-PART-999999-99", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, otherProject.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, neverExisted.StatusCode);
    }

    [Fact]
    public async Task Ch1CybFr0001_TheSerialSpaceCannotBeEnumerated()
    {
        using var inspector = Inspector("USR-QA-ENUM-01");

        // A prefix of a serial that genuinely exists. An operation that answered this
        // would let a caller walk the project's components one character at a time, which
        // is why this takes an identifier rather than a search term.
        using var prefix = await inspector.GetAsync(
            "/api/v1/parts?serialNumber=CH1-PART", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, prefix.StatusCode);

        // And with no serial at all it refuses by name rather than listing anything.
        using var unbounded = await inspector.GetAsync(
            "/api/v1/parts", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.BadRequest, unbounded.StatusCode);
        Assert.Equal("PART_SERIAL_REQUIRED", (await BodyAsync(unbounded)).GetProperty("code").GetString());
    }

    /// <summary>
    /// A part in another project is indistinguishable from one that never existed. The
    /// genealogy is where the whole evidence graph would otherwise leak at once.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0120")]
    public async Task Ch1CybFr0001_GenealogyOutsideTheCallerProjectIsIndistinguishableFromAbsent()
    {
        using var outsider = factory.CreateClient();
        outsider.DefaultRequestHeaders.Add("X-CH1-Actor", "USR-QA-OUTSIDER-01");
        outsider.DefaultRequestHeaders.Add("X-CH1-Project", Guid.NewGuid().ToString());
        outsider.DefaultRequestHeaders.Add("X-CH1-Roles", "Inspector");

        using var otherProject = await outsider.GetAsync(
            $"/api/v1/parts/{Part}/genealogy", TestContext.Current.CancellationToken);
        using var neverExisted = await outsider.GetAsync(
            $"/api/v1/parts/{Guid.NewGuid()}/genealogy", TestContext.Current.CancellationToken);

        Assert.Equal(HttpStatusCode.NotFound, otherProject.StatusCode);
        Assert.Equal(neverExisted.StatusCode, otherProject.StatusCode);
    }

    private static async Task<JsonElement> BodyAsync(HttpResponseMessage response) =>
        await response.Content.ReadFromJsonAsync<JsonElement>(TestContext.Current.CancellationToken);


    /// <summary>
    /// api_endpoints.json gives the genealogy to "Engineer, Inspector or Auditor". A
    /// reader outside those three learns the whole quality history of a part from one
    /// request - every measurement with its value and limits, the instrument and its
    /// calibration, the operator who did the work, open nonconformities and the release.
    /// </summary>
    /// <remarks>
    /// This was not enforced: the endpoint checked project scope and nothing else, so a
    /// Viewer received 200 and the complete evidence graph. Found by asking a running
    /// service rather than by reading the code, which is how every authority gap in this
    /// repository has been found.
    /// </remarks>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0031")]
    [VerificationCase("CH1-VVT-TC-0120")]
    public async Task Ch1CybAcp0001_GenealogyIsReadableOnlyByTheThreeRolesTheCatalogueNames()
    {
        using var inspector = Inspector("USR-QA-GEN-ROLE-01");
        using var permitted = await inspector.GetAsync(
            $"/api/v1/parts/{Part}/genealogy", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.OK, permitted.StatusCode);

        foreach (var role in new[] { "Engineer", "Auditor" })
        {
            using var client = factory.CreateClient();
            client.DefaultRequestHeaders.Add("X-CH1-Actor", $"USR-GEN-{role}");
            client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
            client.DefaultRequestHeaders.Add("X-CH1-Roles", role);
            using var response = await client.GetAsync(
                $"/api/v1/parts/{Part}/genealogy", TestContext.Current.CancellationToken);
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        // Every other role, including one scoped to the right project, is answered
        // exactly as it would be for a part that does not exist.
        foreach (var role in new[] { "Viewer", "OperationsCoordinator", "ProjectManager", "RDEngineer" })
        {
            using var client = factory.CreateClient();
            client.DefaultRequestHeaders.Add("X-CH1-Actor", $"USR-GEN-{role}");
            client.DefaultRequestHeaders.Add("X-CH1-Project", Project);
            client.DefaultRequestHeaders.Add("X-CH1-Roles", role);
            using var response = await client.GetAsync(
                $"/api/v1/parts/{Part}/genealogy", TestContext.Current.CancellationToken);
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }

        using var absent = await inspector.GetAsync(
            $"/api/v1/parts/{Guid.NewGuid()}/genealogy", TestContext.Current.CancellationToken);
        Assert.Equal(HttpStatusCode.NotFound, absent.StatusCode);
    }

}
