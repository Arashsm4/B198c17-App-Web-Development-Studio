// Records for controlled documents and publication packages.

using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Cinerion.Domain.Common;

namespace Cinerion.Domain.Documents;

/// <summary>Which of the two reviews CH1-DOC-FR-0004 requires an approval represents.</summary>
/// <remarks>
/// api_endpoints.json names them "IR plus Document Control review". They are recorded as
/// capacities rather than as whichever platform role a deployment maps them to, so a change
/// to that mapping cannot rewrite what a past approval meant.
/// </remarks>
public enum ReviewerCapacity
{
    /// <summary>
    /// IR, the project owner, who stakeholders.json makes responsible for the
    /// "confidential/publication boundary".
    /// </summary>
    ProjectOwner,

    /// <summary>Document Control.</summary>
    DocumentControl,
}

public enum PublicationState
{
    PendingApproval,
    Approved,
    Rejected,
}

/// <summary>
/// A redaction profile this build holds, with the revision it is pinned at.
/// </summary>
/// <remarks>
/// CH1-DOC-FR-0004 says public material is generated "only from an approved redaction
/// profile". A profile the platform does not hold is refused rather than treated as an
/// empty one: a package produced under a profile nobody defined has been redacted according
/// to nothing.
/// </remarks>
public sealed record RedactionProfile(
    string ProfileId,
    string Revision,
    /// <summary>
    /// The document classifications this profile may draw on. Anything else is refused -
    /// this is the "allowlist inputs" control, and it is an allowlist rather than a
    /// blocklist so that a classification nobody anticipated is excluded by default.
    /// </summary>
    IReadOnlyList<string> PermittedSourceClassifications,
    /// <summary>
    /// The metadata keys a public derivative may carry. Every other key is removed and
    /// named in the record - the "metadata scrub" control.
    /// </summary>
    IReadOnlyList<string> PermittedMetadataKeys);

/// <summary>
/// A controlled document as ch1.controlled_documents holds it
/// (entities.json: Document; classification Controlled, retention Permanent).
/// </summary>
/// <remarks>
/// <para>
/// The table has existed since 0001 and nothing read it: the operations that would have
/// were the gated vault. CH1-DOC-FR-0001 is the part that needs no vault - "a stable
/// identifier, revision, classification, authorisation record and cryptographic checksum
/// independent of its filename or storage location" - and the publication pipeline needs
/// exactly those fields to allowlist its inputs.
/// </para>
/// <para>
/// <see cref="WrappedKeyReference"/> is carried because the schema declares it and is
/// never dereferenced here. Resolving it is CH1-DOC-FR-0002, the declared future phase,
/// and a platform that could turn the reference into a key would already be the vault.
/// </para>
/// </remarks>
/// <requirements>CH1-DOC-FR-0001</requirements>
public sealed record ControlledDocumentRecord(
    Guid DocumentId,
    Guid ProjectId,
    string DocumentNumber,
    string Revision,
    string IssueStatus,
    string Classification,
    string ContentSha256,
    string RepresentationUri,
    string? WrappedKeyReference,
    DateTimeOffset AuthorisedAt);

/// <summary>One controlled document a publication package was derived from.</summary>
public sealed record PublicationSource(
    Guid DocumentId,
    string DocumentNumber,
    string Revision,
    string Classification,
    string ContentSha256);

/// <summary>
/// A clean-room redacted derivative, awaiting the two reviews CH1-DOC-FR-0004 requires
/// (table ch1.publication_packages).
/// </summary>
/// <remarks>
/// <para>
/// This platform does not publish. It builds the derivative, records what the pipeline did
/// to it, and holds it until two named capacities have reviewed the exact bytes. Publication
/// remains an act outside CH1, which is why there is no state beyond Approved.
/// </para>
/// </remarks>
/// <requirements>CH1-DOC-FR-0001, CH1-DOC-FR-0004</requirements>
public sealed record PublicationPackage(
    Guid PackageId,
    Guid ProjectId,
    string RedactionProfile,
    string ProfileRevision,
    string Title,
    IReadOnlyList<PublicationSource> Sources,
    string ContentSha256,
    string MediaType,
    long SizeBytes,
    string StorageUri,
    IReadOnlyList<string> MetadataRemoved,
    IReadOnlyDictionary<string, string> MetadataRetained,
    string SecretScanProfile,
    int SecretScanPatterns,
    bool ContentDiffPerformed,
    string ContentDiffNote,
    PublicationState State,
    string CreatedBy,
    DateTimeOffset CreatedAt,
    DateTimeOffset? DecidedAt,
    long Version)
{
    public const int MaximumSources = 200;

    /// <summary>
    /// Why the diff against the source documents' own text was not performed, stated on the
    /// face of every package rather than left to be discovered.
    /// </summary>
    public const string DiffNotPerformedNote =
        "Content diff against the source documents' text was NOT performed: this platform " +
        "holds each controlled document's checksum and representation URI, not its bytes. " +
        "The vault that would hold them is CH1-DOC-FR-0002, a declared future phase. What " +
        "was checked is the part that needs no bytes: the derivative's checksum differs " +
        "from every source it names, so it is not a source republished unchanged.";

    public static PublicationPackage Create(
        Guid packageId,
        Guid projectId,
        RedactionProfile profile,
        string title,
        IReadOnlyList<PublicationSource> sources,
        string content,
        string mediaType,
        IReadOnlyList<string> metadataRemoved,
        IReadOnlyDictionary<string, string> metadataRetained,
        string secretScanProfile,
        int secretScanPatterns,
        string createdBy,
        DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(profile);
        ArgumentNullException.ThrowIfNull(sources);

        Guard.Against(
            string.IsNullOrWhiteSpace(title),
            "PUBLICATION_TITLE_REQUIRED",
            "A publication package must state what it is.");
        Guard.Against(
            sources.Count == 0,
            "PUBLICATION_SOURCES_REQUIRED",
            "A publication package is derived from controlled documents. Name at least one.");
        Guard.Against(
            sources.Count > MaximumSources,
            "PUBLICATION_SOURCES_TOO_MANY",
            $"A publication package may draw on at most {MaximumSources} documents.");
        Guard.Against(
            string.IsNullOrWhiteSpace(content),
            "PUBLICATION_CONTENT_REQUIRED",
            "A publication package must carry the derivative it proposes to publish.");

        var bytes = Encoding.UTF8.GetBytes(content);
        var checksum = Convert.ToHexStringLower(SHA256.HashData(bytes));

        // The half of the content-diff control that can be performed without holding the
        // source bytes. A "redacted derivative" identical to one of its sources has
        // redacted nothing, and would publish a controlled document under the name of a
        // showcase one.
        var unchanged = sources.FirstOrDefault(
            source => StringComparer.OrdinalIgnoreCase.Equals(source.ContentSha256, checksum));
        Guard.Against(
            unchanged is not null,
            "PUBLICATION_DERIVATIVE_UNCHANGED",
            $"The derivative is byte-identical to source document {unchanged?.DocumentNumber} " +
            $"revision {unchanged?.Revision}. A redaction that changed nothing has redacted nothing.");

        return new PublicationPackage(
            packageId,
            projectId,
            profile.ProfileId,
            profile.Revision,
            title.Trim(),
            sources,
            checksum,
            mediaType,
            bytes.LongLength,
            $"cinerion://publication-packages/{packageId}",
            metadataRemoved,
            metadataRetained,
            secretScanProfile,
            secretScanPatterns,
            // False, deliberately and permanently until the vault exists. Stating it on the
            // record is the difference between a control that was not performed and one
            // that was quietly skipped.
            ContentDiffPerformed: false,
            DiffNotPerformedNote,
            PublicationState.PendingApproval,
            createdBy,
            now,
            DecidedAt: null,
            Version: 1);
    }

    /// <summary>
    /// Applies one review. Approved only when both capacities have approved; a single
    /// rejection decides the package permanently.
    /// </summary>
    public PublicationPackage WithDecision(
        IReadOnlyList<PublicationApproval> approvalsIncludingThisOne,
        DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(approvalsIncludingThisOne);
        Guard.Against(
            State != PublicationState.PendingApproval,
            "PUBLICATION_ALREADY_DECIDED",
            $"This package is already {State}. A decided package is not reviewed again.");

        if (approvalsIncludingThisOne.Any(item => item.Decision == PublicationState.Rejected))
        {
            return this with { State = PublicationState.Rejected, DecidedAt = now, Version = Version + 1 };
        }

        var capacities = approvalsIncludingThisOne
            .Select(item => item.Capacity)
            .Distinct()
            .ToArray();

        return capacities.Length == Enum.GetValues<ReviewerCapacity>().Length
            ? this with { State = PublicationState.Approved, DecidedAt = now, Version = Version + 1 }
            : this;
    }
}

/// <summary>One of the two reviews (table ch1.publication_package_approvals).</summary>
/// <requirements>CH1-DOC-FR-0004</requirements>
public sealed record PublicationApproval(
    Guid ApprovalId,
    Guid ProjectId,
    Guid PackageId,
    ReviewerCapacity Capacity,
    PublicationState Decision,
    string ReviewedBy,
    string ReviewedRole,
    string ReviewedChecksum,
    string Comment,
    DateTimeOffset ReviewedAt)
{
    public static PublicationApproval Record(
        Guid approvalId,
        PublicationPackage package,
        ReviewerCapacity capacity,
        bool approved,
        string reviewedBy,
        string reviewedRole,
        string reviewedChecksum,
        string comment,
        IReadOnlyList<PublicationApproval> existing,
        DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(package);
        ArgumentNullException.ThrowIfNull(existing);

        Guard.Against(
            string.IsNullOrWhiteSpace(comment),
            "PUBLICATION_REVIEW_COMMENT_REQUIRED",
            "A review is a decision somebody made. Say why.");

        // "visual review and checksum". A reviewer states the checksum of what they
        // actually looked at; if it is not this package's, they reviewed something else.
        Guard.Against(
            !StringComparer.OrdinalIgnoreCase.Equals(reviewedChecksum?.Trim(), package.ContentSha256),
            "PUBLICATION_REVIEWED_CHECKSUM_MISMATCH",
            "The checksum reviewed does not match this package. A review of different bytes " +
            "is not a review of this package.");

        // The creator is not one of the two reviewers. CH1-DOC-FR-0004 asks for owner
        // approval of somebody's work, which is not the same as somebody approving it.
        Guard.Against(
            StringComparer.Ordinal.Equals(reviewedBy, package.CreatedBy),
            "PUBLICATION_REVIEWER_IS_AUTHOR",
            "The identity that built this package may not review it.");

        Guard.Against(
            existing.Any(item => item.Capacity == capacity),
            "PUBLICATION_CAPACITY_ALREADY_REVIEWED",
            $"{capacity} has already reviewed this package.");

        // Two reviews by one person are one review. The control is two people, not two
        // form submissions.
        Guard.Against(
            existing.Any(item => StringComparer.Ordinal.Equals(item.ReviewedBy, reviewedBy)),
            "PUBLICATION_REVIEWER_ALREADY_REVIEWED",
            "That identity has already reviewed this package in another capacity.");

        return new PublicationApproval(
            approvalId,
            package.ProjectId,
            package.PackageId,
            capacity,
            approved ? PublicationState.Approved : PublicationState.Rejected,
            reviewedBy,
            reviewedRole,
            package.ContentSha256,
            comment.Trim(),
            now);
    }
}

/// <summary>
/// The secret scan CH1-DOC-FR-0004 requires, applied to a candidate derivative.
/// </summary>
/// <remarks>
/// <para>
/// A finding is a refusal, not a note. Public material carrying a credential is the
/// outcome this control exists to prevent, so a package is never created with one recorded
/// against it - which is why the package table has a column for the scan profile and not
/// for its findings.
/// </para>
/// <para>
/// The patterns are deliberately the shapes of a secret rather than the values of any:
/// nothing here is a credential, and <c>npm run policy</c> scans this file like every
/// other.
/// </para>
/// </remarks>
public static partial class PublicationSecretScan
{
    public const string ProfileId = "CH1-DOC-SCAN-0001";

    [GeneratedRegex(@"-----BEGIN (?:RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----", RegexOptions.IgnoreCase)]
    private static partial Regex PrivateKeyBlock { get; }

    [GeneratedRegex(@"\b(?:password|passwd|secret|api[_-]?key|token|bearer)\s*[:=]\s*\S{6,}", RegexOptions.IgnoreCase)]
    private static partial Regex AssignedCredential { get; }

    [GeneratedRegex(@"\bAKIA[0-9A-Z]{16}\b")]
    private static partial Regex AwsAccessKeyId { get; }

    [GeneratedRegex(@"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")]
    private static partial Regex JsonWebToken { get; }

    [GeneratedRegex(@"\bpostgres(?:ql)?://[^\s:]+:[^\s@]+@", RegexOptions.IgnoreCase)]
    private static partial Regex ConnectionStringWithPassword { get; }

    private static (string Name, Regex Pattern)[] Patterns =>
    [
        ("private key block", PrivateKeyBlock),
        ("assigned credential", AssignedCredential),
        ("cloud access key identifier", AwsAccessKeyId),
        ("JSON web token", JsonWebToken),
        ("connection string carrying a password", ConnectionStringWithPassword),
    ];

    public static int PatternCount => Patterns.Length;

    /// <summary>
    /// The names of the patterns that matched. Names only: reporting the matched text back
    /// would put the secret in an audit payload and a response body, which is the same
    /// disclosure by a different route.
    /// </summary>
    public static IReadOnlyList<string> Scan(string content)
    {
        ArgumentNullException.ThrowIfNull(content);
        return [.. Patterns.Where(entry => entry.Pattern.IsMatch(content)).Select(entry => entry.Name)];
    }
}
