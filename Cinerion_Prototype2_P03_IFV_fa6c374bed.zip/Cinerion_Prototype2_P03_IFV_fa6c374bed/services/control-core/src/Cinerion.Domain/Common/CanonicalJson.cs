// JSON with a fixed key order, so the same data always hashes the same.

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Cinerion.Domain.Common;

public static class CanonicalJson
{
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = false,
    };

    public static string Sha256Hex<T>(T value)
    {
        var node = JsonSerializer.SerializeToNode(value, Options);
        var canonical = Sort(node)?.ToJsonString(Options) ?? "null";
        return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(canonical)));
    }

    private static JsonNode? Sort(JsonNode? node)
    {
        if (node is JsonObject obj)
        {
            var sorted = new JsonObject();
            foreach (var item in obj.OrderBy(item => item.Key, StringComparer.Ordinal))
            {
                sorted[item.Key] = Sort(item.Value);
            }

            return sorted;
        }

        return node is JsonArray array
            ? new JsonArray(array.Select(Sort).ToArray())
            : node?.DeepClone();
    }
}
