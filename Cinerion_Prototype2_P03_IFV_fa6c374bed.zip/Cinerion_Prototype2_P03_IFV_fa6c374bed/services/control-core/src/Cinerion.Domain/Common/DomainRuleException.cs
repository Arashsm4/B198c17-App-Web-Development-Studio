// What gets thrown when a domain rule is broken, plus a tiny guard helper to throw it.

namespace Cinerion.Domain.Common;

public sealed class DomainRuleException(string code, string message) : Exception(message)
{
    public string Code { get; } = code;
}

public static class Guard
{
    public static void Against(bool invalid, string code, string message)
    {
        if (invalid)
        {
            throw new DomainRuleException(code, message);
        }
    }
}

