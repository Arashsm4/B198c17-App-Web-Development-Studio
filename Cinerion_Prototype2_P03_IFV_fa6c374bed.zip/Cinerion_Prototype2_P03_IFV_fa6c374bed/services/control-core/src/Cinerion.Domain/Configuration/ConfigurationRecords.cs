// Records for projects, sites and cells.

using System.Text.RegularExpressions;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Configuration;

/// <summary>
/// Portfolio identity and governance boundary (entities.json: Project).
/// <para>
/// Field names and constraints follow ch1.projects in
/// Persistence/Migrations/0001_ch1_foundation.sql so that the in-memory store and the
/// PostgreSQL repository cannot diverge: the code pattern, the uniqueness rule and
/// the monotonic version are the same obligations in both.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0001, CH1-MGT-FR-0003</requirements>
public sealed partial record ProjectRecord(
    Guid ProjectId,
    string ProjectCode,
    string Name,
    string Baseline,
    long Version,
    DateTimeOffset CreatedAt)
{
    /// <summary>Mirrors the CHECK constraint on ch1.projects.project_code.</summary>
    [GeneratedRegex("^CH1(-[A-Z0-9]+)*$")]
    private static partial Regex ProjectCodePattern { get; }

    public static ProjectRecord Create(
        Guid projectId,
        string projectCode,
        string name,
        string baseline,
        DateTimeOffset now)
    {
        Guard.Against(projectId == Guid.Empty, "PROJECT_ID_REQUIRED", "A project identifier is required.");
        Guard.Against(
            string.IsNullOrWhiteSpace(projectCode) || !ProjectCodePattern.IsMatch(projectCode),
            "PROJECT_CODE_INVALID",
            "Project code must match the controlled CH1 namespace pattern.");
        Guard.Against(string.IsNullOrWhiteSpace(name), "PROJECT_NAME_REQUIRED", "A project name is required.");
        Guard.Against(string.IsNullOrWhiteSpace(baseline), "PROJECT_BASELINE_REQUIRED", "A governing baseline is required.");
        return new ProjectRecord(projectId, projectCode, name, baseline, 1, now);
    }

    /// <summary>
    /// Only a Project Manager may establish a project, per the P03 API catalogue and
    /// the CH1-CYB-ACP-0001 role boundaries. Authentication must be multi-factor;
    /// step-up is not demanded here because the catalogue reserves it for approval,
    /// release, security administration and publication.
    /// </summary>
    public static void AuthoriseCreation(ActorContext actor)
    {
        Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required to establish a project.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.ProjectManager),
            "AUTH_PROJECT_MANAGER_REQUIRED",
            "Project Manager authority is required to establish a project.");
        Guard.Against(
            actor.AuthenticationStrength < AuthenticationStrength.Mfa,
            "AUTH_MFA_REQUIRED",
            "Establishing a project requires multi-factor authentication.");
    }
}

/// <summary>Physical or simulated location (entities.json: Site; table ch1.sites).</summary>
/// <requirements>CH1-MGT-FR-0001</requirements>
public sealed record SiteRecord(
    Guid SiteId,
    Guid ProjectId,
    string Name,
    bool Simulated,
    long Version)
{
    public static SiteRecord Create(Guid siteId, Guid projectId, string name, bool simulated)
    {
        Guard.Against(siteId == Guid.Empty, "SITE_ID_REQUIRED", "A site identifier is required.");
        Guard.Against(projectId == Guid.Empty, "SITE_PROJECT_REQUIRED", "A site must belong to a project.");
        Guard.Against(string.IsNullOrWhiteSpace(name), "SITE_NAME_REQUIRED", "A site name is required.");
        return new SiteRecord(siteId, projectId, name, simulated, 1);
    }
}

/// <summary>
/// The configuration-controlled facet of a cell (table ch1.cells): who it belongs to
/// and what it is called.
/// <para>
/// Deliberately separate from <c>CellSnapshot</c>, which carries the volatile
/// operating state, interlocks and state hash the command aggregate depends on.
/// Keeping registration apart means naming or re-siting a cell cannot perturb the
/// guarded command path.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0001, CH1-MGT-FR-0003</requirements>
public sealed record CellRegistration(
    Guid CellId,
    Guid ProjectId,
    Guid SiteId,
    string Name,
    long Version)
{
    public static CellRegistration Create(Guid cellId, Guid projectId, Guid siteId, string name)
    {
        Guard.Against(cellId == Guid.Empty, "CELL_ID_REQUIRED", "A cell identifier is required.");
        Guard.Against(projectId == Guid.Empty, "CELL_PROJECT_REQUIRED", "A cell must belong to a project.");
        Guard.Against(siteId == Guid.Empty, "CELL_SITE_REQUIRED", "A cell must belong to a site.");
        Guard.Against(string.IsNullOrWhiteSpace(name), "CELL_NAME_REQUIRED", "A cell name is required.");
        return new CellRegistration(cellId, projectId, siteId, name, 1);
    }
}
