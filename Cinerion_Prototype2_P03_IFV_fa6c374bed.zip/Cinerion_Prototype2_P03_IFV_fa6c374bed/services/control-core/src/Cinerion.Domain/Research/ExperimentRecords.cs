// Experiments and their runs, kept well apart from anything production.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Research;

/// <summary>
/// Where an experiment runs.
/// <para>
/// Mirrors <c>CHECK (environment IN ('Simulator', 'ControlledBench'))</c> on
/// ch1.experiments. <see cref="ControlledBench"/> is declared because the schema and
/// CH1-RND-FR-0003 both name it, and is deliberately unreachable: reaching it requires
/// an explicit authorised bench transition, and the P03 catalogue contains no operation
/// that performs one. Until it does, every experiment is a simulator experiment, which
/// is what "Simulator-only unless a separately authorised bench transition exists" in
/// access.json means in practice.
/// </para>
/// </summary>
/// <requirements>CH1-RND-FR-0001, CH1-RND-FR-0003, CH1-CYB-ACP-0001</requirements>
public enum ExperimentEnvironment
{
    Simulator,
    ControlledBench,
}

public enum ExperimentStatus
{
    /// <summary>Defined, nothing run yet.</summary>
    Draft,

    /// <summary>At least one run recorded.</summary>
    Active,

    /// <summary>An outbound promotion package has been submitted to configuration control.</summary>
    PromotionRequested,
}

/// <summary>
/// An isolated R&amp;D objective (entities.json: Experiment; table ch1.experiments).
/// <para>
/// <see cref="ProductionAuthority"/> exists to be false, and ch1.experiments declares it
/// <c>NOT NULL DEFAULT false CHECK (production_authority = false)</c>, so the database
/// refuses to store an experiment that claims any. CH1-CYB-ACP-0001 states the rule this
/// enforces: ResearchBench roles cannot reach production routes unless an approved
/// promotion and bench-mode transition exist. Neither exists here, and requesting
/// promotion does not create one.
/// </para>
/// </summary>
/// <requirements>CH1-RND-FR-0001, CH1-RND-FR-0003</requirements>
public sealed record Experiment(
    Guid ExperimentId,
    Guid ProjectId,
    string OwnerId,
    string Objective,
    ExperimentEnvironment Environment,
    ExperimentStatus Status,
    long Version,
    DateTimeOffset CreatedAt,
    string? PromotionChangeRecord = null,
    string? PromotionImpactAnalysis = null,
    string? PromotionVerification = null,
    string? PromotionRequestedBy = null,
    DateTimeOffset? PromotionRequestedAt = null,
    bool ProductionAuthority = false)
{
    public const int MaximumObjectiveLength = 2_000;

    /// <summary>
    /// How many runs one experiment may record. This is the "resource quota" the API
    /// control column states: an unbounded experiment could accumulate provenance
    /// records without limit, and an experiment that needs more than this is a new
    /// experiment with its own objective rather than a longer one.
    /// </summary>
    public const int MaximumRuns = 500;

    public static Experiment Define(
        Guid experimentId,
        ExperimentEnvironment environment,
        string objective,
        ActorContext owner,
        DateTimeOffset now)
    {
        Guard.Against(experimentId == Guid.Empty, "EXPERIMENT_ID_REQUIRED", "An experiment identifier is required.");
        Guard.Against(
            string.IsNullOrWhiteSpace(objective),
            "EXPERIMENT_OBJECTIVE_REQUIRED",
            "An experiment must state its objective.");
        Guard.Against(
            objective.Length > MaximumObjectiveLength,
            "EXPERIMENT_OBJECTIVE_TOO_LONG",
            $"An experiment objective may be at most {MaximumObjectiveLength} characters.");
        // The bench transition is a separate authorised act with no controlled operation
        // behind it. Accepting ControlledBench here would let an experiment claim an
        // authority nothing granted, which is exactly what CH1-RND-FR-0003 forbids.
        Guard.Against(
            environment != ExperimentEnvironment.Simulator,
            "EXPERIMENT_BENCH_TRANSITION_NOT_AUTHORISED",
            "An experiment starts in the simulator. Controlled bench mode requires a separately " +
            "authorised transition, which is not enabled.");

        return new Experiment(
            experimentId,
            owner.ProjectId,
            owner.ActorId,
            objective.Trim(),
            ExperimentEnvironment.Simulator,
            ExperimentStatus.Draft,
            1,
            now);
    }

    public bool IsPromotionRequested => PromotionRequestedAt is not null;

    /// <summary>Whether this experiment may record another run.</summary>
    public bool AcceptsRuns => !IsPromotionRequested;

    /// <summary>
    /// Records that a run happened, moving a Draft experiment to Active. The version
    /// advances so a caller holding a stale view is refused.
    /// </summary>
    public Experiment WithRunRecorded() => this with
    {
        Status = Status == ExperimentStatus.Draft ? ExperimentStatus.Active : Status,
        Version = Version + 1,
    };

    /// <summary>
    /// Records an outbound promotion request.
    /// <para>
    /// This grants nothing. CH1-COM-IF-0021 makes promotion an outbound request to
    /// configuration control with its own step-up and approval workflow; CH1 emits the
    /// change and evidence package and stops there. <see cref="ProductionAuthority"/> and
    /// <see cref="Environment"/> are carried through untouched, so a requested promotion
    /// leaves the experiment exactly as isolated as it was.
    /// </para>
    /// </summary>
    /// <requirements>CH1-RND-FR-0003, CH1-CYB-ACP-0001</requirements>
    public Experiment RequestPromotion(
        ActorContext proposer,
        string changeRecord,
        string impactAnalysis,
        string verification,
        DateTimeOffset now)
    {
        Guard.Against(
            proposer.ProjectId != ProjectId,
            "AUTH_PROJECT_SCOPE",
            "Actor is outside the experiment project scope.");
        Guard.Against(
            IsPromotionRequested,
            "EXPERIMENT_PROMOTION_ALREADY_REQUESTED",
            "A promotion request is already outstanding for this experiment.");
        Guard.Against(
            Status == ExperimentStatus.Draft,
            "EXPERIMENT_NO_RESULT_TO_PROMOTE",
            "An experiment with no recorded run has no result to promote.");
        // CH1-RND-FR-0003 requires all three. A request carrying only some of them would
        // evidence an assessment that was never made.
        Guard.Against(
            string.IsNullOrWhiteSpace(changeRecord),
            "PROMOTION_CHANGE_RECORD_REQUIRED",
            "Promotion requires an approved change record reference.");
        Guard.Against(
            string.IsNullOrWhiteSpace(impactAnalysis),
            "PROMOTION_IMPACT_ANALYSIS_REQUIRED",
            "Promotion requires an impact assessment reference.");
        Guard.Against(
            string.IsNullOrWhiteSpace(verification),
            "PROMOTION_VERIFICATION_REQUIRED",
            "Promotion requires a verification reference.");

        return this with
        {
            Status = ExperimentStatus.PromotionRequested,
            PromotionChangeRecord = changeRecord.Trim(),
            PromotionImpactAnalysis = impactAnalysis.Trim(),
            PromotionVerification = verification.Trim(),
            PromotionRequestedBy = proposer.ActorId,
            PromotionRequestedAt = now,
            Version = Version + 1,
        };
    }
}

/// <summary>
/// One immutable record of what an experiment ran
/// (entities.json: ExperimentRevision; table ch1.experiment_revisions).
/// <para>
/// CH1-RND-FR-0002 asks for versioned configuration, code or model reference, input
/// data, environment, operator, timestamps, results and evidence provenance sufficient
/// for reproduction, and CH1-VVT-TC-0111 tests exactly that: a second authorised user
/// reproducing the experiment from the retained record. Every artefact reference is
/// therefore paired with a content hash, so a later reader can prove the artefact they
/// found is the artefact that ran.
/// </para>
/// <para>
/// ResearchBench records runs; it does not perform them. The computation happens in the
/// R&amp;D engineer's own simulator, and <see cref="ExecutedBy"/> names the isolated
/// identity it ran under, which CH1-COM-IF-0020 requires to be separate from any
/// production credential.
/// </para>
/// </summary>
/// <requirements>CH1-RND-FR-0002, CH1-VVT-TC-0111</requirements>
public sealed record ExperimentRevision(
    Guid ExperimentRevisionId,
    Guid ProjectId,
    Guid ExperimentId,
    int RevisionNumber,
    ExperimentEnvironment Environment,
    string ConfigurationReference,
    string ConfigurationSha256,
    string ModelReference,
    string InputReference,
    string InputSha256,
    string ResultSummary,
    string ResultSha256,
    string RequestedBy,
    string ExecutedBy,
    DateTimeOffset StartedAt,
    DateTimeOffset FinishedAt,
    bool ProductionAuthority = false)
{
    public const int MaximumResultLength = 4_000;

    /// <summary>
    /// Longest run a single revision may record. Bounded because the operation is "a
    /// bounded experiment run": a record claiming an unbounded execution evidences
    /// nothing reproducible.
    /// </summary>
    public static readonly TimeSpan MaximumDuration = TimeSpan.FromDays(7);

    /// <summary>
    /// The isolated identity a simulator run executes under. Derived from the experiment
    /// rather than supplied, so a caller cannot name a production service account and
    /// have it recorded as the executor.
    /// </summary>
    public static string IsolatedIdentityFor(Guid experimentId) => $"bench:{experimentId:D}";

    public static ExperimentRevision Capture(
        Guid revisionId,
        Experiment experiment,
        int revisionNumber,
        ExperimentRunInput input,
        ActorContext requester,
        DateTimeOffset now)
    {
        Guard.Against(
            requester.ProjectId != experiment.ProjectId,
            "AUTH_PROJECT_SCOPE",
            "Actor is outside the experiment project scope.");
        Guard.Against(
            !experiment.AcceptsRuns,
            "EXPERIMENT_CLOSED_TO_RUNS",
            "A promotion request is outstanding, so this experiment records no further runs.");
        Guard.Against(
            revisionNumber > Experiment.MaximumRuns,
            "EXPERIMENT_RUN_QUOTA_EXCEEDED",
            $"An experiment may record at most {Experiment.MaximumRuns} runs.");

        RequireReference(input.ConfigurationReference, "RUN_CONFIGURATION_REQUIRED", "configuration");
        RequireHash(input.ConfigurationSha256, "RUN_CONFIGURATION_HASH_INVALID", "configuration");
        RequireReference(input.ModelReference, "RUN_MODEL_REQUIRED", "code or model");
        RequireReference(input.InputReference, "RUN_INPUT_REQUIRED", "input data");
        RequireHash(input.InputSha256, "RUN_INPUT_HASH_INVALID", "input data");
        RequireHash(input.ResultSha256, "RUN_RESULT_HASH_INVALID", "result");

        var summary = (input.ResultSummary ?? string.Empty).Trim();
        Guard.Against(summary.Length == 0, "RUN_RESULT_REQUIRED", "A run must record its result.");
        Guard.Against(
            summary.Length > MaximumResultLength,
            "RUN_RESULT_TOO_LONG",
            $"A run result summary may be at most {MaximumResultLength} characters.");

        Guard.Against(
            input.FinishedAt < input.StartedAt,
            "RUN_INTERVAL_INVALID",
            "A run cannot finish before it starts.");
        Guard.Against(
            input.FinishedAt - input.StartedAt > MaximumDuration,
            "RUN_INTERVAL_TOO_LONG",
            $"A recorded run may span at most {MaximumDuration.TotalDays:0} days.");
        Guard.Against(
            input.StartedAt > now,
            "RUN_INTERVAL_IN_FUTURE",
            "A run cannot be recorded before it has started.");

        return new ExperimentRevision(
            revisionId,
            experiment.ProjectId,
            experiment.ExperimentId,
            revisionNumber,
            // Taken from the experiment, never from the request. A run cannot elect to
            // be a bench run.
            experiment.Environment,
            input.ConfigurationReference.Trim(),
            input.ConfigurationSha256.ToLowerInvariant(),
            input.ModelReference.Trim(),
            input.InputReference.Trim(),
            input.InputSha256.ToLowerInvariant(),
            summary,
            input.ResultSha256.ToLowerInvariant(),
            requester.ActorId,
            IsolatedIdentityFor(experiment.ExperimentId),
            input.StartedAt,
            input.FinishedAt);
    }

    private static void RequireReference(string? value, string code, string what) =>
        Guard.Against(
            string.IsNullOrWhiteSpace(value),
            code,
            $"A run must state its {what} reference so the experiment can be reproduced.");

    /// <summary>Mirrors the char(64) hex CHECK constraints on ch1.experiment_revisions.</summary>
    private static void RequireHash(string? value, string code, string what) =>
        Guard.Against(
            value is null ||
            value.Length != 64 ||
            !value.All(character => char.IsAsciiDigit(character) || (character >= 'a' && character <= 'f') || (character >= 'A' && character <= 'F')),
            code,
            $"The {what} content hash must be 64 hexadecimal characters.");
}

/// <summary>What a caller states about a run it has already performed.</summary>
public sealed record ExperimentRunInput(
    string ConfigurationReference,
    string ConfigurationSha256,
    string ModelReference,
    string InputReference,
    string InputSha256,
    string ResultSummary,
    string ResultSha256,
    DateTimeOffset StartedAt,
    DateTimeOffset FinishedAt);
