// The shapes of commands, cell snapshots and button events.

namespace Cinerion.Domain.Commands;

public enum CellOperatingState
{
    Initialising,
    Idle,
    Prepared,
    Executing,
    Complete,
    FaultLatched,
    Maintenance,
}

public enum CommandState
{
    AwaitingCredential,
    AwaitingButton,
    Committed,
    Executing,
    Completed,
    Cancelled,
    Rejected,
    FaultLatched,
}

public enum ButtonEventSource
{
    PhysicalInput,
    RemoteApi,
    SimulatorInjection,
}

/// <summary>
/// The cell as the controller currently reports it.
/// <para>
/// Only part of this is durable. ch1.cells persists identity, name, controller,
/// operating state, configuration revision, state hash, source timestamp, freshness
/// and quality. The interlocks, <see cref="ControllerBootId"/> and
/// <see cref="ButtonPressed"/> are deliberately not stored anywhere: they are sampled
/// from the controller each cycle, and restoring them from a database would present a
/// stale permissive as a current one. CH1-SAF-FR-0003 requires restart to default to
/// a non-energising safe state, so after a restart a cell must read as not permissive
/// until the controller reports again, and a prepared command must be refused until
/// then. The schema having no columns for them is correct, not an omission.
/// </para>
/// <para>
/// <see cref="AssetId"/>, <see cref="WorkOrderId"/> and <see cref="PartId"/> are
/// assignments rather than volatile state, and are resolved from ch1.assets,
/// ch1.work_orders and ch1.physical_parts, each of which already records the cell it
/// belongs to.
/// </para>
/// </summary>
/// <requirements>CH1-SAF-FR-0003, CH1-CMD-FR-0009, CH1-MON-FR-0003</requirements>
public sealed record CellSnapshot(
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    string ControllerId,
    Guid ControllerBootId,
    CellOperatingState OperatingState,
    string ConfigurationRevision,
    Guid WorkOrderId,
    Guid PartId,
    bool ControllerOnline,
    bool StartEnable,
    bool StopCircuitHealthy,
    bool GuardHealthy,
    bool ActuatorHome,
    bool ButtonPressed,
    bool FaultCauseActive)
{
    public string StateHash() => Common.CanonicalJson.Sha256Hex(new
    {
        ProjectId,
        SiteId,
        CellId,
        AssetId,
        ControllerId,
        ControllerBootId,
        OperatingState,
        ConfigurationRevision,
        WorkOrderId,
        PartId,
        ControllerOnline,
        StartEnable,
        StopCircuitHealthy,
        GuardHealthy,
        ActuatorHome,
        FaultCauseActive,
    });
}

/// <summary>
/// How current the stored half of a cell's state is, as the store recorded it.
/// <para>
/// <see cref="SourceTimestamp"/> is when the controller's report was received, not when
/// the row was read. Freshness is judged from it rather than asserted: a cell whose
/// controller stopped reporting an hour ago must not read as <c>Simulated</c> merely
/// because that is what the last report said it was. CH1-MON-FR-0003 requires live,
/// stale, disconnected, simulated, maintenance and unknown to stay distinguishable, and
/// a hardcoded value distinguishes nothing.
/// </para>
/// </summary>
/// <requirements>CH1-MON-FR-0003</requirements>
public sealed record CellObservation(
    Monitoring.Freshness Freshness,
    Monitoring.DataQuality Quality,
    DateTimeOffset? SourceTimestamp)
{
    /// <summary>A cell no controller has ever reported for.</summary>
    public static readonly CellObservation NeverReported = new(
        Monitoring.Freshness.Unknown,
        Monitoring.DataQuality.Uncertain,
        null);
}

/// <summary>The durable half of a cell's state, and how current it is.</summary>
public sealed record StoredCellState(CellSnapshot Snapshot, CellObservation Observation);

public sealed record PrepareIntent(
    string CommandType,
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    Guid WorkOrderId,
    Guid PartId,
    string ProcedureRevision,
    string ConfigurationRevision,
    string ExpectedStateHash,
    long Sequence,
    DateTimeOffset ExpiresAt,
    string IdempotencyKey,
    IReadOnlyDictionary<string, object> Parameters);

/// <summary>
/// Authenticator classes accepted as proof of local human presence.
/// <para>
/// Every member performs cryptographic challenge-response. CH1-IAM-FR-0007 forbids
/// accepting a cloneable NFC UID as proof of human authentication, so there is
/// deliberately no member representing a bare UID read: an unsupported class cannot
/// be named, rather than being named and then rejected.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0007</requirements>
public enum AuthenticatorClass
{
    SmartCard,
    FidoSecurityKey,
    CryptographicNfc,

    /// <summary>
    /// No person was present and no credential was read: a stand-in controller asserting
    /// local presence in the Simulation profile.
    /// <para>
    /// This exists because the two halves of a local confirmation were not equally honest.
    /// <see cref="ButtonEventSource.SimulatorInjection"/> has always marked a simulated
    /// button edge, and <see cref="CommandTransaction.LocalCommit"/> refuses it outside
    /// simulation and audits it as MARKED_SIMULATOR_EDGE rather than as a physical one. The
    /// credential proof had no such member, so a simulated confirmation had to name a real
    /// authenticator class and was then recorded as
    /// CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED - an audit record asserting that a person
    /// presented a credential at a cell when nobody had. This makes the credential half say
    /// what the button half already said.
    /// </para>
    /// <para>
    /// It is <b>refused outside the Simulation profile</b>, by the same guard and in the
    /// same place as the simulated edge, so it cannot become a route around
    /// CH1-IAM-FR-0007 in a real deployment. A confirmation carrying it is not evidence
    /// that anybody was present, and the audit record says so in those words.
    /// </para>
    /// </summary>
    SimulatedPresence,
}

/// <summary>
/// Evidence that a person proved local presence for exactly one transaction.
/// <para>
/// <see cref="ChallengeHash"/> binds the proof to the nonce the controller issued for
/// this confirmation. Without it a proof is bound only to identifiers that appear in
/// the request itself, which is what CH1-CYB-IAM-0001 means by a proof bound to user,
/// cell, transaction and nonce. It is also required by ch1.local_confirmations.
/// </para>
/// </summary>
public sealed record CredentialProof(
    Guid ProofId,
    Guid CommandId,
    Guid ConfirmationId,
    Guid CellId,
    string ControllerId,
    Guid CredentialId,
    string UserId,
    AuthenticatorClass AuthenticatorClass,
    string ChallengeHash,
    bool CryptographicallyVerified,
    bool UserVerified,
    DateTimeOffset VerifiedAt,
    DateTimeOffset ExpiresAt);

public sealed record LocalButtonObservation(
    Guid CommandId,
    Guid ConfirmationId,
    Guid CellId,
    string ControllerId,
    Guid ControllerBootId,
    ButtonEventSource Source,
    bool PreviousState,
    bool CurrentState,
    DateTimeOffset ObservedAt);

