// One command's journey and the rules on what may happen next. No skipping ahead.

using System.Text.RegularExpressions;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Commands;

public sealed record CommandTransaction
{
    private static readonly Regex SemanticCommandPattern = new(
        "^[A-Z][A-Z0-9_]{2,63}$",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public required Guid CommandId { get; init; }
    public required Guid ConfirmationId { get; init; }
    public required Guid CorrelationId { get; init; }
    public required string RequesterId { get; init; }
    public required PrepareIntent Intent { get; init; }
    public required DateTimeOffset PreparedAt { get; init; }
    public required Guid PreparedControllerBootId { get; init; }
    public required CommandState State { get; init; }
    public required int Version { get; init; }
    public CredentialProof? CredentialProof { get; init; }
    public Guid? LocalCommitId { get; init; }
    public string? TerminalReason { get; init; }

    /// <requirements>CH1-CMD-FR-0001, CH1-CMD-FR-0002, CH1-CMD-FR-0004, CH1-CMD-FR-0006</requirements>
    public static CommandTransaction Prepare(
        PrepareIntent intent,
        ActorContext actor,
        CellSnapshot cell,
        DateTimeOffset now)
    {
        Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required to prepare a procedure.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.Engineer) && !actor.HasRole(CinerionRoles.ProjectManager),
            "AUTH_ROLE_REQUIRED",
            "Engineer or Project Manager role is required.");
        Guard.Against(
            actor.AuthenticationStrength < AuthenticationStrength.StepUpPhishingResistant,
            "AUTH_STEP_UP_REQUIRED",
            "Recent phishing-resistant step-up authentication is required.");
        Guard.Against(actor.ProjectId != intent.ProjectId, "AUTH_PROJECT_SCOPE", "Actor is outside the project scope.");
        Guard.Against(!actor.CanAccessCell(intent.CellId), "AUTH_CELL_SCOPE", "Actor is outside the cell scope.");
        Guard.Against(
            intent.ProjectId == Guid.Empty || intent.SiteId == Guid.Empty || intent.CellId == Guid.Empty ||
            intent.AssetId == Guid.Empty || intent.WorkOrderId == Guid.Empty || intent.PartId == Guid.Empty,
            "CMD_SCOPE_ID_REQUIRED",
            "Project, site, cell, asset, work-order, and part identities are required.");
        Guard.Against(string.IsNullOrWhiteSpace(intent.CommandType), "CMD_TYPE_INVALID", "Semantic command type is required.");
        Guard.Against(!SemanticCommandPattern.IsMatch(intent.CommandType), "CMD_TYPE_INVALID", "Command type must be semantic and allowlisted.");
        Guard.Against(intent.Sequence <= 0, "CMD_SEQUENCE_INVALID", "Command sequence must be positive.");
        Guard.Against(
            string.IsNullOrWhiteSpace(intent.IdempotencyKey) || intent.IdempotencyKey.Length is < 16 or > 128,
            "CMD_IDEMPOTENCY_INVALID",
            "Idempotency-key length is invalid.");
        Guard.Against(string.IsNullOrWhiteSpace(intent.ProcedureRevision), "CMD_PROCEDURE_REQUIRED", "Released procedure revision is required.");
        Guard.Against(string.IsNullOrWhiteSpace(intent.ConfigurationRevision), "CMD_CONFIGURATION_REQUIRED", "Controlled configuration revision is required.");
        Guard.Against(
            string.IsNullOrWhiteSpace(intent.ExpectedStateHash) ||
            intent.ExpectedStateHash.Length != 64 ||
            !intent.ExpectedStateHash.All(Uri.IsHexDigit),
            "CMD_EXPECTED_STATE_HASH_INVALID",
            "Expected-state hash must be a SHA-256 hexadecimal value.");
        Guard.Against(intent.Parameters is null || intent.Parameters.Count > 32, "CMD_PARAMETERS_EXCESSIVE", "A semantic command may contain at most 32 parameters.");
        var ttl = intent.ExpiresAt - now;
        Guard.Against(ttl < TimeSpan.FromSeconds(5) || ttl > TimeSpan.FromSeconds(120), "CMD_TTL_INVALID", "Prepared-command TTL must be between 5 and 120 seconds.");
        Guard.Against(cell.ButtonPressed, "CONFIRM_BUTTON_HELD", "Confirmation input is already active before arming.");
        ValidateScope(intent, cell);
        ValidatePermissives(cell);
        Guard.Against(!StringComparer.Ordinal.Equals(intent.ExpectedStateHash, cell.StateHash()), "CMD_EXPECTED_STATE_STALE", "Expected state is stale or altered.");

        return new CommandTransaction
        {
            CommandId = Guid.NewGuid(),
            ConfirmationId = Guid.NewGuid(),
            CorrelationId = Guid.NewGuid(),
            RequesterId = actor.ActorId,
            Intent = intent,
            PreparedAt = now,
            PreparedControllerBootId = cell.ControllerBootId,
            State = CommandState.AwaitingCredential,
            Version = 1,
        };
    }

    /// <requirements>CH1-CMD-FR-0003, CH1-IAM-FR-0005, CH1-IAM-FR-0007</requirements>
    public CommandTransaction RecordCredentialProof(
        CredentialProof proof,
        ActorContext controller,
        DateTimeOffset now,
        bool simulationProfile = false)
    {
        Guard.Against(State != CommandState.AwaitingCredential, "CMD_STATE_INVALID", "Command is not awaiting a credential.");
        ValidateController(controller, Intent.CellId);
        Guard.Against(proof.CommandId != CommandId, "PROOF_COMMAND_MISMATCH", "Credential proof is for another command.");
        Guard.Against(proof.ConfirmationId != ConfirmationId, "PROOF_CONFIRMATION_MISMATCH", "Credential proof is not bound to this challenge.");
        Guard.Against(proof.CellId != Intent.CellId, "PROOF_CELL_MISMATCH", "Credential proof is for another cell.");
        Guard.Against(!StringComparer.Ordinal.Equals(proof.ControllerId, controller.ActorId), "PROOF_CONTROLLER_MISMATCH", "Credential proof came from another controller.");
        Guard.Against(
            !Enum.IsDefined(proof.AuthenticatorClass),
            "PROOF_AUTHENTICATOR_CLASS_INVALID",
            "The authenticator class is not one of the accepted cryptographic classes.");
        // The same rule the simulated button edge obeys, in the same shape. A stand-in
        // asserting local presence is permitted only where a stand-in edge is permitted,
        // so simulation cannot become a route around CH1-IAM-FR-0007 in a real deployment.
        Guard.Against(
            proof.AuthenticatorClass == AuthenticatorClass.SimulatedPresence && !simulationProfile,
            "SIMULATED_PRESENCE_FORBIDDEN",
            "A simulated local presence cannot prove a person was at the cell.");
        // The nonce binding. A proof that does not name the challenge it answers is
        // bound only to identifiers the caller supplied, and is replayable across
        // confirmations for the same command.
        Guard.Against(
            string.IsNullOrWhiteSpace(proof.ChallengeHash) ||
            proof.ChallengeHash.Length != 64 ||
            !proof.ChallengeHash.All(Uri.IsHexDigit),
            "PROOF_CHALLENGE_INVALID",
            "The credential proof must carry the SHA-256 challenge it answers.");
        Guard.Against(!proof.CryptographicallyVerified, "PROOF_CRYPTOGRAPHY_INVALID", "Cryptographic challenge-response failed.");
        Guard.Against(!proof.UserVerified, "PROOF_USER_VERIFICATION_REQUIRED", "Credential user verification was not satisfied.");
        Guard.Against(proof.VerifiedAt > now, "PROOF_TIME_INVALID", "Credential proof is from the future.");
        Guard.Against(proof.ExpiresAt <= now, "PROOF_EXPIRED", "Credential proof has expired.");
        Guard.Against(Intent.ExpiresAt <= now, "CMD_EXPIRED", "Prepared command has expired.");

        return this with
        {
            CredentialProof = proof,
            State = CommandState.AwaitingButton,
            Version = Version + 1,
        };
    }

    /// <requirements>CH1-CMD-FR-0003, CH1-CMD-FR-0005, CH1-CMD-FR-0007, CH1-CMD-FR-0008</requirements>
    public CommandTransaction LocalCommit(
        LocalButtonObservation observation,
        ActorContext controller,
        CellSnapshot cell,
        DateTimeOffset now,
        bool simulationProfile = false)
    {
        Guard.Against(State != CommandState.AwaitingButton, "CMD_STATE_INVALID", "Command is not awaiting a button edge.");
        Guard.Against(CredentialProof is null, "PROOF_REQUIRED", "Credential proof is missing.");
        ValidateController(controller, Intent.CellId);
        var permittedSource = observation.Source == ButtonEventSource.PhysicalInput ||
            (simulationProfile && observation.Source == ButtonEventSource.SimulatorInjection);
        Guard.Against(!permittedSource, "REMOTE_CONFIRMATION_FORBIDDEN", "Remote input cannot commit a procedure.");
        Guard.Against(observation.PreviousState || !observation.CurrentState, "CONFIRM_EDGE_REQUIRED", "A new rising input edge is required.");
        Guard.Against(observation.CommandId != CommandId, "BUTTON_COMMAND_MISMATCH", "Button event is for another command.");
        Guard.Against(observation.ConfirmationId != ConfirmationId, "BUTTON_CONFIRMATION_MISMATCH", "Button event is not bound to this challenge.");
        Guard.Against(observation.CellId != Intent.CellId, "BUTTON_CELL_MISMATCH", "Button event is for another cell.");
        Guard.Against(!StringComparer.Ordinal.Equals(observation.ControllerId, controller.ActorId), "BUTTON_CONTROLLER_MISMATCH", "Button event came from another controller.");
        Guard.Against(observation.ControllerBootId != PreparedControllerBootId, "CONTROLLER_REBOOTED", "Controller restarted after preparation.");
        Guard.Against(cell.ControllerBootId != PreparedControllerBootId, "CONTROLLER_REBOOTED", "Current controller boot identity changed.");
        Guard.Against(Intent.ExpiresAt <= now, "CMD_EXPIRED", "Prepared command has expired.");
        Guard.Against(CredentialProof!.ExpiresAt <= now, "PROOF_EXPIRED", "Credential proof has expired.");
        ValidateScope(Intent, cell);
        ValidatePermissives(cell);
        Guard.Against(!StringComparer.Ordinal.Equals(Intent.ExpectedStateHash, cell.StateHash()), "CMD_EXPECTED_STATE_CHANGED", "Material cell state changed after preparation.");

        return this with
        {
            LocalCommitId = Guid.NewGuid(),
            State = CommandState.Committed,
            Version = Version + 1,
        };
    }

    public CommandTransaction BeginExecution()
    {
        Guard.Against(State != CommandState.Committed, "CMD_STATE_INVALID", "Only a locally committed command may execute.");
        return this with { State = CommandState.Executing, Version = Version + 1 };
    }

    public CommandTransaction CompleteExecution()
    {
        Guard.Against(State != CommandState.Executing, "CMD_STATE_INVALID", "Only an executing command may complete.");
        return this with { State = CommandState.Completed, Version = Version + 1 };
    }

    public CommandTransaction Cancel(string reason)
    {
        Guard.Against(State is not (CommandState.AwaitingCredential or CommandState.AwaitingButton), "CMD_STATE_INVALID", "Only an uncommitted command may be cancelled.");
        Guard.Against(string.IsNullOrWhiteSpace(reason), "CANCEL_REASON_REQUIRED", "Cancellation reason is required.");
        return this with { State = CommandState.Cancelled, TerminalReason = reason.Trim(), Version = Version + 1 };
    }

    public CommandTransaction LatchFault(string reason)
    {
        Guard.Against(State is not (CommandState.Committed or CommandState.Executing), "CMD_STATE_INVALID", "Fault can only latch after local commit.");
        Guard.Against(string.IsNullOrWhiteSpace(reason), "FAULT_REASON_REQUIRED", "Fault reason is required.");
        return this with { State = CommandState.FaultLatched, TerminalReason = reason.Trim(), Version = Version + 1 };
    }

    /// <requirements>CH1-CMD-FR-0009</requirements>
    public CommandTransaction ReconcileRestart(Guid currentControllerBootId)
    {
        if (State is not (CommandState.AwaitingCredential or CommandState.AwaitingButton))
        {
            return this;
        }

        return this with
        {
            State = CommandState.Cancelled,
            TerminalReason = currentControllerBootId == PreparedControllerBootId ? "SERVICE_RESTART" : "CONTROLLER_RESTART",
            Version = Version + 1,
        };
    }

    /// <requirements>CH1-CMD-FR-0010</requirements>
    public CommandTransaction RecoverFault(
        ActorContext actor,
        CellSnapshot cell,
        ButtonEventSource source,
        bool previousResetState,
        bool currentResetState)
    {
        Guard.Against(State != CommandState.FaultLatched, "CMD_STATE_INVALID", "Command is not fault latched.");
        Guard.Against(actor.Kind != ActorKind.Human || !actor.HasRole(CinerionRoles.LocalConfirmer), "AUTH_LOCAL_CONFIRMER_REQUIRED", "Local Confirmer role is required.");
        Guard.Against(actor.AuthenticationStrength < AuthenticationStrength.StepUpPhishingResistant, "AUTH_STEP_UP_REQUIRED", "Step-up authentication is required.");
        Guard.Against(!actor.CanAccessCell(cell.CellId), "AUTH_CELL_SCOPE", "Actor is outside the cell scope.");
        Guard.Against(source != ButtonEventSource.PhysicalInput, "REMOTE_RESET_FORBIDDEN", "Fault recovery requires a local reset input.");
        Guard.Against(previousResetState || !currentResetState, "RESET_EDGE_REQUIRED", "A new reset edge is required.");
        Guard.Against(cell.FaultCauseActive, "FAULT_CAUSE_ACTIVE", "Fault cause is still active.");
        Guard.Against(!cell.StopCircuitHealthy || !cell.GuardHealthy, "RECOVERY_INTERLOCK_INVALID", "Recovery interlocks are not healthy.");
        return this with { State = CommandState.Cancelled, TerminalReason = "FAULT_RECOVERED_LOCALLY", Version = Version + 1 };
    }

    private static void ValidateController(ActorContext controller, Guid cellId)
    {
        Guard.Against(controller.Kind != ActorKind.Device, "AUTH_DEVICE_REQUIRED", "Only a bound device identity may perform this operation.");
        Guard.Against(!controller.HasRole(CinerionRoles.DeviceController), "AUTH_CONTROLLER_ROLE", "Device lacks controller role.");
        Guard.Against(controller.AuthenticationStrength != AuthenticationStrength.MutualTls, "AUTH_MTLS_REQUIRED", "Controller mTLS identity is required.");
        Guard.Against(!controller.CanAccessCell(cellId), "AUTH_CELL_SCOPE", "Controller is outside cell scope.");
    }

    private static void ValidateScope(PrepareIntent intent, CellSnapshot cell)
    {
        Guard.Against(intent.ProjectId != cell.ProjectId, "CMD_PROJECT_MISMATCH", "Command project does not match cell.");
        Guard.Against(intent.SiteId != cell.SiteId, "CMD_SITE_MISMATCH", "Command site does not match cell.");
        Guard.Against(intent.CellId != cell.CellId, "CMD_CELL_MISMATCH", "Command cell does not match cell.");
        Guard.Against(intent.AssetId != cell.AssetId, "CMD_ASSET_MISMATCH", "Command asset does not match cell.");
        Guard.Against(intent.WorkOrderId != cell.WorkOrderId, "CMD_WORK_ORDER_MISMATCH", "Work order is not active at the cell.");
        Guard.Against(intent.PartId != cell.PartId, "CMD_PART_MISMATCH", "Physical part is not active at the cell.");
        Guard.Against(!StringComparer.Ordinal.Equals(intent.ConfigurationRevision, cell.ConfigurationRevision), "CMD_CONFIGURATION_MISMATCH", "Configuration revision does not match.");
    }

    private static void ValidatePermissives(CellSnapshot cell)
    {
        Guard.Against(!cell.ControllerOnline, "INTERLOCK_CONTROLLER_OFFLINE", "Cell controller is offline.");
        Guard.Against(!cell.StartEnable, "INTERLOCK_START_DISABLED", "Local start-enable input is not active.");
        Guard.Against(!cell.StopCircuitHealthy, "INTERLOCK_STOP_UNHEALTHY", "Local stop circuit is not healthy.");
        Guard.Against(!cell.GuardHealthy, "INTERLOCK_GUARD_OPEN", "Guard/interlock input is not healthy.");
        Guard.Against(!cell.ActuatorHome, "INTERLOCK_NOT_HOME", "Actuator is not in the required home state.");
        Guard.Against(cell.FaultCauseActive, "INTERLOCK_FAULT_ACTIVE", "A fault cause is active.");
        Guard.Against(cell.OperatingState != CellOperatingState.Idle, "CMD_STATE_NOT_IDLE", "Cell is not in Idle.");
    }
}
