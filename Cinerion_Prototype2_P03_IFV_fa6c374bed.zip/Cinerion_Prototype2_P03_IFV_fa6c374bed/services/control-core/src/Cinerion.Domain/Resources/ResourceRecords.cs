// Resources, reservations and the capacity maths that keeps bookings honest.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Resources;

/// <summary>
/// Whether a resource may be reserved at all.
/// <para>
/// There is deliberately no <c>Reserved</c> value. Whether a resource is reserved
/// depends on the interval being asked about and is computed from its allocations;
/// storing it as a state would go stale the moment a reservation started or ended, and
/// CH1-MGT-FR-0004 requires availability, capacity, reservation and conflict state to be
/// exposed as they actually are.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0004</requirements>
public enum ResourceAvailabilityState
{
    /// <summary>In service and open to reservation.</summary>
    Available,

    /// <summary>Out of service for maintenance. Existing reservations stand; new ones are refused.</summary>
    Maintenance,

    /// <summary>Decommissioned. No further reservations.</summary>
    Withdrawn,
}

public enum AllocationStatus
{
    Reserved,
    Cancelled,
}

/// <summary>
/// A reservable capacity (table ch1.resources).
/// <para>
/// entities.json names ResourceAllocation but not the resource itself, which is
/// configuration rather than a controlled record of something that happened. The
/// controlled API has no operation that creates one either, so resources arrive through
/// the prototype seed, exactly as projects, sites, cells, assets and devices do.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0001, CH1-MGT-FR-0004</requirements>
public sealed record ResourceRecord(
    Guid ResourceId,
    Guid ProjectId,
    string ResourceType,
    string Name,
    decimal Capacity,
    string Unit,
    ResourceAvailabilityState AvailabilityState,
    long Version)
{
    public static ResourceRecord Create(
        Guid resourceId,
        Guid projectId,
        string resourceType,
        string name,
        decimal capacity,
        string unit,
        ResourceAvailabilityState availabilityState)
    {
        Guard.Against(resourceId == Guid.Empty, "RESOURCE_ID_REQUIRED", "A resource identifier is required.");
        Guard.Against(string.IsNullOrWhiteSpace(resourceType), "RESOURCE_TYPE_REQUIRED", "A resource type is required.");
        Guard.Against(string.IsNullOrWhiteSpace(name), "RESOURCE_NAME_REQUIRED", "A resource name is required.");
        Guard.Against(string.IsNullOrWhiteSpace(unit), "RESOURCE_UNIT_REQUIRED", "A resource unit is required.");
        // Mirrors CHECK (capacity >= 0) on ch1.resources.
        Guard.Against(capacity < 0, "RESOURCE_CAPACITY_INVALID", "Resource capacity cannot be negative.");
        return new ResourceRecord(
            resourceId, projectId, resourceType, name, capacity, unit, availabilityState, 1);
    }

    public bool AcceptsReservations => AvailabilityState == ResourceAvailabilityState.Available;
}

/// <summary>
/// A bounded reservation of part of a resource's capacity
/// (entities.json: ResourceAllocation; table ch1.resource_allocations).
/// <para>
/// Exactly one of <see cref="WorkOrderId"/> and <see cref="ExperimentId"/> is set, which
/// is the schema's own
/// <c>CHECK ((work_order_id IS NOT NULL) &lt;&gt; (experiment_id IS NOT NULL))</c> and
/// the link CH1-MGT-FR-0004 requires. Capacity is never consumed by nothing.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0003, CH1-MGT-FR-0004</requirements>
public sealed record ResourceAllocation(
    Guid AllocationId,
    Guid ProjectId,
    Guid ResourceId,
    Guid? WorkOrderId,
    Guid? ExperimentId,
    decimal Quantity,
    DateTimeOffset StartsAt,
    DateTimeOffset EndsAt,
    AllocationStatus Status,
    string RequestedBy,
    long Version,
    string? CancellationReason = null,
    string? CancelledBy = null,
    DateTimeOffset? CancelledAt = null)
{
    /// <summary>
    /// Longest interval a single reservation may span. Bounded because the API contract
    /// is "reserve a resource for a bounded interval": an open-ended reservation would
    /// hold shared capacity indefinitely with nothing forcing a review.
    /// </summary>
    public static readonly TimeSpan MaximumDuration = TimeSpan.FromDays(90);

    public static ResourceAllocation Reserve(
        Guid allocationId,
        ResourceRecord resource,
        Guid? workOrderId,
        Guid? experimentId,
        decimal quantity,
        DateTimeOffset startsAt,
        DateTimeOffset endsAt,
        ActorContext requester)
    {
        Guard.Against(
            resource.ProjectId != requester.ProjectId,
            "AUTH_PROJECT_SCOPE",
            "Actor is outside the resource project scope.");
        Guard.Against(
            !resource.AcceptsReservations,
            "RESOURCE_NOT_AVAILABLE",
            $"The resource is {resource.AvailabilityState} and is not accepting reservations.");
        // Mirrors CHECK ((work_order_id IS NOT NULL) <> (experiment_id IS NOT NULL)).
        Guard.Against(
            (workOrderId is null) == (experimentId is null),
            "ALLOCATION_LINK_REQUIRED",
            "A reservation must name exactly one of a work order or an experiment.");
        // Mirrors CHECK (quantity > 0).
        Guard.Against(
            quantity <= 0,
            "ALLOCATION_QUANTITY_INVALID",
            "A reservation quantity must be greater than zero.");
        // Mirrors CHECK (ends_at > starts_at).
        Guard.Against(
            endsAt <= startsAt,
            "ALLOCATION_INTERVAL_INVALID",
            "A reservation must end after it begins.");
        Guard.Against(
            endsAt - startsAt > MaximumDuration,
            "ALLOCATION_INTERVAL_TOO_LONG",
            $"A reservation may span at most {MaximumDuration.TotalDays:0} days.");
        Guard.Against(
            quantity > resource.Capacity,
            "ALLOCATION_EXCEEDS_CAPACITY",
            $"The request of {quantity} {resource.Unit} exceeds the resource capacity of {resource.Capacity} {resource.Unit}.");

        return new ResourceAllocation(
            allocationId,
            resource.ProjectId,
            resource.ResourceId,
            workOrderId,
            experimentId,
            quantity,
            startsAt,
            endsAt,
            AllocationStatus.Reserved,
            requester.ActorId,
            1);
    }

    public bool IsActive => Status == AllocationStatus.Reserved;

    /// <summary>Whether this reservation holds capacity at the given moment.</summary>
    public bool CoversInstant(DateTimeOffset instant) =>
        IsActive && instant >= StartsAt && instant < EndsAt;

    public bool Overlaps(DateTimeOffset from, DateTimeOffset to) =>
        IsActive && StartsAt < to && EndsAt > from;

    /// <summary>
    /// Cancels the reservation, releasing its capacity.
    /// <para>
    /// The record is kept rather than deleted: CH1-MGT-FR-0003 requires assignment
    /// changes to be attributable, revisioned and reversible to a known controlled
    /// version, and a deleted row evidences neither who released the capacity nor why.
    /// </para>
    /// </summary>
    /// <requirements>CH1-MGT-FR-0003</requirements>
    public ResourceAllocation Cancel(ActorContext actor, string reason, DateTimeOffset now)
    {
        Guard.Against(
            actor.ProjectId != ProjectId,
            "AUTH_PROJECT_SCOPE",
            "Actor is outside the reservation project scope.");
        Guard.Against(
            Status == AllocationStatus.Cancelled,
            "ALLOCATION_ALREADY_CANCELLED",
            "The reservation has already been cancelled.");
        Guard.Against(
            string.IsNullOrWhiteSpace(reason),
            "ALLOCATION_CANCELLATION_REASON_REQUIRED",
            "A cancellation reason is required.");
        Guard.Against(
            reason.Length > 1_000,
            "ALLOCATION_CANCELLATION_REASON_TOO_LONG",
            "A cancellation reason may be at most 1000 characters.");

        return this with
        {
            Status = AllocationStatus.Cancelled,
            CancellationReason = reason.Trim(),
            CancelledBy = actor.ActorId,
            CancelledAt = now,
            Version = Version + 1,
        };
    }
}

/// <summary>An interval in which committed quantity exceeds the resource capacity.</summary>
public sealed record CapacityConflict(
    DateTimeOffset From,
    DateTimeOffset To,
    decimal Committed,
    decimal Capacity)
{
    public decimal OverCommittedBy => Committed - Capacity;
}

/// <summary>
/// Capacity arithmetic over a set of reservations.
/// <para>
/// Committed quantity only changes where a reservation starts or ends, so both the peak
/// and every over-committed interval can be found exactly by sweeping those boundaries.
/// This is the "conflict check" CH1-CYB-ACP-0001 and CH1-MGT-FR-0004 require, and it is
/// kept here, free of storage and transport, so it can be reasoned about and tested on
/// its own.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0004, CH1-VVT-TC-0106</requirements>
public static class CapacityLedger
{
    /// <summary>Quantity committed by active reservations at one instant.</summary>
    public static decimal CommittedAt(IEnumerable<ResourceAllocation> allocations, DateTimeOffset instant) =>
        allocations.Where(item => item.CoversInstant(instant)).Sum(item => item.Quantity);

    /// <summary>
    /// The highest committed quantity anywhere in the half-open interval, and when it
    /// occurs. Returns zero when nothing is committed.
    /// </summary>
    public static (decimal Peak, DateTimeOffset At) Peak(
        IEnumerable<ResourceAllocation> allocations,
        DateTimeOffset from,
        DateTimeOffset to)
    {
        var relevant = allocations.Where(item => item.Overlaps(from, to)).ToArray();
        var peak = 0m;
        var at = from;
        foreach (var boundary in Boundaries(relevant, from, to))
        {
            var committed = CommittedAt(relevant, boundary);
            if (committed > peak)
            {
                peak = committed;
                at = boundary;
            }
        }

        return (peak, at);
    }

    /// <summary>
    /// Whether adding <paramref name="quantity"/> over the interval would exceed
    /// capacity anywhere within it, and the peak that decided the answer.
    /// </summary>
    public static (bool Fits, decimal PeakWithRequest, DateTimeOffset At) Admits(
        IEnumerable<ResourceAllocation> allocations,
        decimal capacity,
        decimal quantity,
        DateTimeOffset from,
        DateTimeOffset to)
    {
        var (peak, at) = Peak(allocations, from, to);
        return (peak + quantity <= capacity, peak + quantity, at);
    }

    /// <summary>
    /// Every interval within the window where committed quantity exceeds capacity.
    /// <para>
    /// A reservation path that refuses to over-commit does not make this unreachable:
    /// capacity can be reduced administratively after reservations were accepted
    /// against the older, larger figure, and an operations view has to show that
    /// rather than hide it.
    /// </para>
    /// </summary>
    public static IReadOnlyList<CapacityConflict> Conflicts(
        IEnumerable<ResourceAllocation> allocations,
        decimal capacity,
        DateTimeOffset from,
        DateTimeOffset to)
    {
        var relevant = allocations.Where(item => item.Overlaps(from, to)).ToArray();
        if (relevant.Length == 0)
        {
            return [];
        }

        var boundaries = Boundaries(relevant, from, to).ToList();
        // Closing boundary, so the last segment has an end.
        boundaries.Add(to);

        var conflicts = new List<CapacityConflict>();
        for (var index = 0; index < boundaries.Count - 1; index++)
        {
            var segmentStart = boundaries[index];
            var segmentEnd = boundaries[index + 1];
            if (segmentEnd <= segmentStart)
            {
                continue;
            }

            var committed = CommittedAt(relevant, segmentStart);
            if (committed <= capacity)
            {
                continue;
            }

            // Adjacent over-committed segments at the same level are one conflict, not
            // one per boundary, so the report describes the period an operator sees.
            var previous = conflicts.Count > 0 ? conflicts[^1] : null;
            if (previous is not null && previous.To == segmentStart && previous.Committed == committed)
            {
                conflicts[^1] = previous with { To = segmentEnd };
            }
            else
            {
                conflicts.Add(new CapacityConflict(segmentStart, segmentEnd, committed, capacity));
            }
        }

        return conflicts;
    }

    /// <summary>
    /// The instants at which committed quantity can change inside the window: the start
    /// of the window itself, and every reservation edge within it.
    /// </summary>
    private static SortedSet<DateTimeOffset> Boundaries(
        IReadOnlyList<ResourceAllocation> allocations,
        DateTimeOffset from,
        DateTimeOffset to)
    {
        var points = new SortedSet<DateTimeOffset> { from };
        foreach (var allocation in allocations)
        {
            if (allocation.StartsAt > from && allocation.StartsAt < to)
            {
                points.Add(allocation.StartsAt);
            }

            if (allocation.EndsAt > from && allocation.EndsAt < to)
            {
                points.Add(allocation.EndsAt);
            }
        }

        return points;
    }
}

/// <summary>A bounded, cursor-paged resource query.</summary>
public sealed record ResourceQuery(
    Guid ProjectId,
    string? ResourceType,
    ResourceAvailabilityState? AvailabilityState,
    ResourceCursor? After,
    int Limit)
{
    public const int MaximumRows = 200;
    public const int DefaultRows = 50;

    /// <summary>
    /// Window over which reservations and conflicts are reported. Bounded for the same
    /// reason a telemetry query is: an unbounded window would read every allocation a
    /// project has ever held.
    /// </summary>
    public static readonly TimeSpan MaximumWindow = TimeSpan.FromDays(180);

    public static readonly TimeSpan DefaultWindow = TimeSpan.FromDays(30);

    public static ResourceQuery Create(
        Guid projectId,
        string? resourceType,
        ResourceAvailabilityState? availabilityState,
        ResourceCursor? after,
        int? limit) =>
        new(projectId, resourceType, availabilityState, after, Math.Clamp(limit ?? DefaultRows, 1, MaximumRows));

    public static (DateTimeOffset From, DateTimeOffset To) Window(
        DateTimeOffset? from,
        DateTimeOffset? to,
        DateTimeOffset now)
    {
        var resolvedFrom = from ?? now;
        var resolvedTo = to ?? resolvedFrom + DefaultWindow;
        Guard.Against(
            resolvedTo <= resolvedFrom,
            "RESOURCE_WINDOW_INVALID",
            "The resource window must end after it begins.");
        Guard.Against(
            resolvedTo - resolvedFrom > MaximumWindow,
            "RESOURCE_WINDOW_TOO_WIDE",
            $"A resource query may span at most {MaximumWindow.TotalDays:0} days.");
        return (resolvedFrom, resolvedTo);
    }
}

/// <summary>Opaque page position over (name, resource_id).</summary>
public sealed record ResourceCursor(string Name, Guid ResourceId)
{
    public string Encode() =>
        Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"{ResourceId}|{Name}"));

    public static ResourceCursor? Decode(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        try
        {
            // Split once only: a resource name may itself contain the separator.
            var decoded = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(value));
            var separator = decoded.IndexOf('|', StringComparison.Ordinal);
            if (separator > 0 && Guid.TryParse(decoded[..separator], out var resourceId))
            {
                return new ResourceCursor(decoded[(separator + 1)..], resourceId);
            }
        }
        catch (FormatException)
        {
            // Shared rejection below: a malformed cursor is a client fault with a stable
            // code, never a 500 and never a silent jump back to the first page.
        }

        throw new DomainRuleException("RESOURCE_CURSOR_INVALID", "The resource page cursor is not valid.");
    }
}
