// The append-only, hash-linked audit log. Change one event and the whole chain tells on you.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Audit;

public sealed record AuditInput(
    string EventType,
    string ActorId,
    ActorKind ActorKind,
    Guid ProjectId,
    string ObjectType,
    string ObjectId,
    Guid CorrelationId,
    DateTimeOffset OccurredAt,
    string Decision,
    string ReasonCode,
    object Payload,
    string TimeQuality = "Unqualified");

public sealed record AuditEvent(
    Guid EventId,
    long Sequence,
    string EventType,
    string ActorId,
    ActorKind ActorKind,
    Guid ProjectId,
    string ObjectType,
    string ObjectId,
    Guid CorrelationId,
    DateTimeOffset OccurredAt,
    string TimeQuality,
    string Decision,
    string ReasonCode,
    string PayloadHash,
    string PreviousHash,
    string EventHash);

public sealed record AuditVerification(bool Valid, int Checked, long? FailureAt = null);

/// <summary>
/// Append-only hash-linked event log.
/// <para>
/// The chain is linked <em>per project</em>. This follows the controlled schema
/// rather than preference: ch1.audit_events carries a row-level security policy of
/// <c>project_id = ch1.current_project_id()</c>, so a connection can only ever see
/// its own project's rows. A single chain spanning projects would leave each reader
/// holding links that point at rows it cannot see, and therefore cannot verify. The
/// index <c>ix_audit_project_sequence (project_id, sequence_number)</c> reflects the
/// same intent. Sequence numbers remain globally monotonic, matching the
/// GENERATED ALWAYS AS IDENTITY column.
/// </para>
/// <para>
/// Tamper evidence is unaffected within a project: deleting or altering any event
/// still breaks the linkage for that project. What a per-project chain does not
/// evidence is the relative ordering of events across projects, which the schema
/// deliberately isolates anyway.
/// </para>
/// </summary>
/// <requirements>CH1-TRC-FR-0002, CH1-NFR-AUD-0001</requirements>
public sealed class AuditChain
{
    public const string GenesisHash = "0000000000000000000000000000000000000000000000000000000000000000";

    /// <summary>
    /// Normalises an event time to UTC at microsecond resolution.
    /// <para>
    /// The hash covers the timestamp, and PostgreSQL timestamptz keeps microseconds
    /// while .NET keeps 100-nanosecond ticks. Without this the chain verifies in
    /// memory and fails after a round trip through the database, which would look
    /// exactly like tampering. Truncating in the hash makes the value survive storage;
    /// microsecond resolution is far finer than the qualified time the audit record
    /// claims.
    /// </para>
    /// </summary>
    public static DateTimeOffset NormaliseTime(DateTimeOffset value)
    {
        var utc = value.ToUniversalTime();
        return new DateTimeOffset(utc.Ticks - (utc.Ticks % 10), TimeSpan.Zero);
    }

    /// <summary>
    /// The canonical event hash. Shared so that the in-memory and PostgreSQL stores
    /// produce byte-identical chains: a chain written by one must verify under the
    /// other, otherwise switching store would look like tampering.
    /// </summary>
    public static string ComputeEventHash(
        Guid eventId,
        long sequence,
        string eventType,
        string actorId,
        ActorKind actorKind,
        Guid projectId,
        string objectType,
        string objectId,
        Guid correlationId,
        DateTimeOffset occurredAt,
        string timeQuality,
        string decision,
        string reasonCode,
        string payloadHash,
        string previousHash) =>
        CanonicalJson.Sha256Hex(new
        {
            EventId = eventId,
            Sequence = sequence,
            EventType = eventType,
            ActorId = actorId,
            ActorKind = actorKind,
            ProjectId = projectId,
            ObjectType = objectType,
            ObjectId = objectId,
            CorrelationId = correlationId,
            OccurredAt = NormaliseTime(occurredAt),
            TimeQuality = timeQuality,
            Decision = decision,
            ReasonCode = reasonCode,
            PayloadHash = payloadHash,
            PreviousHash = previousHash,
        });

    private readonly List<AuditEvent> _events = [];
    private readonly Dictionary<Guid, string> _headByProject = [];
    private readonly object _gate = new();

    public AuditEvent Append(AuditInput input)
    {
        lock (_gate)
        {
            var sequence = _events.Count + 1L;
            var previousHash = _headByProject.GetValueOrDefault(input.ProjectId, GenesisHash);
            var eventId = Guid.NewGuid();
            var payloadHash = CanonicalJson.Sha256Hex(input.Payload);
            var auditEvent = new AuditEvent(
                eventId,
                sequence,
                input.EventType,
                input.ActorId,
                input.ActorKind,
                input.ProjectId,
                input.ObjectType,
                input.ObjectId,
                input.CorrelationId,
                input.OccurredAt,
                input.TimeQuality,
                input.Decision,
                input.ReasonCode,
                payloadHash,
                previousHash,
                ComputeEventHash(
                    eventId, sequence, input.EventType, input.ActorId, input.ActorKind, input.ProjectId,
                    input.ObjectType, input.ObjectId, input.CorrelationId, input.OccurredAt, input.TimeQuality,
                    input.Decision, input.ReasonCode, payloadHash, previousHash));
            _events.Add(auditEvent);
            _headByProject[input.ProjectId] = auditEvent.EventHash;
            return auditEvent;
        }
    }

    public IReadOnlyList<AuditEvent> Snapshot()
    {
        lock (_gate)
        {
            return _events.ToArray();
        }
    }

    /// <summary>
    /// Verifies every project's chain. Each project is walked from its own genesis,
    /// mirroring what a project-scoped reader can see in PostgreSQL.
    /// </summary>
    public AuditVerification Verify()
    {
        lock (_gate)
        {
            return Verify(_events);
        }
    }

    /// <summary>
    /// Verifies a sequence of events that came from somewhere else — a snapshot, a
    /// database read, or an export handed to a reader.
    /// </summary>
    /// <remarks>
    /// CH1-TRC-FR-0002 asks that an altered or deleted event break verification and be
    /// reported. That is a property of the events, not of the object that produced them,
    /// so it has to be checkable against a list a caller holds; otherwise the only thing
    /// that can be verified is a chain that was never out of the platform's hands, which
    /// is not the situation the requirement is about.
    /// </remarks>
    public static AuditVerification Verify(IReadOnlyList<AuditEvent> events)
    {
        {
            var heads = new Dictionary<Guid, string>();
            foreach (var item in events)
            {
                var previousHash = heads.GetValueOrDefault(item.ProjectId, GenesisHash);
                if (!StringComparer.Ordinal.Equals(item.PreviousHash, previousHash))
                {
                    return new AuditVerification(false, checked((int)item.Sequence - 1), item.Sequence);
                }

                var recomputed = ComputeEventHash(
                    item.EventId, item.Sequence, item.EventType, item.ActorId, item.ActorKind, item.ProjectId,
                    item.ObjectType, item.ObjectId, item.CorrelationId, item.OccurredAt, item.TimeQuality,
                    item.Decision, item.ReasonCode, item.PayloadHash, item.PreviousHash);
                if (!StringComparer.Ordinal.Equals(item.EventHash, recomputed))
                {
                    return new AuditVerification(false, checked((int)item.Sequence - 1), item.Sequence);
                }

                heads[item.ProjectId] = item.EventHash;
            }

            return new AuditVerification(true, events.Count);
        }
    }
}
