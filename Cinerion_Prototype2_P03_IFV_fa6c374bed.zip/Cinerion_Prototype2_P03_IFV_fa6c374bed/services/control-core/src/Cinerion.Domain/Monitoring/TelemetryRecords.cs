// Telemetry samples, channels, data quality and freshness.

using Cinerion.Domain.Common;

namespace Cinerion.Domain.Monitoring;

/// <summary>Mirrors the ch1.data_quality enum.</summary>
public enum DataQuality
{
    Good,
    Uncertain,
    Bad,
    Unknown,
}

/// <summary>
/// Mirrors the ch1.freshness enum. CH1-MON-FR-0003 requires each of these to remain
/// distinguishable in every operational view, so the value travels with the reading
/// rather than being inferred by the reader.
/// </summary>
public enum Freshness
{
    Live,
    Stale,
    Disconnected,
    Simulated,
    Maintenance,
    Unknown,
}

/// <summary>
/// One measured channel value (entities.json: TelemetrySample; table
/// ch1.telemetry_samples).
/// <para>
/// Both times are kept. <paramref name="SampledAt"/> is when the source observed the
/// value and <paramref name="ReceivedAt"/> is when this service stored it; store and
/// forward means the two can differ by hours, and a reader that only saw one of them
/// could not tell a delayed sample from a current one.
/// </para>
/// </summary>
/// <requirements>CH1-MON-FR-0001, CH1-MON-FR-0003, CH1-COM-FR-0007</requirements>
public sealed record TelemetrySample(
    Guid SampleId,
    Guid ProjectId,
    Guid CellId,
    string DeviceId,
    string ChannelId,
    double Value,
    string Unit,
    DataQuality Quality,
    Freshness Freshness,
    DateTimeOffset SampledAt,
    DateTimeOffset ReceivedAt,
    string TimeQuality,
    /// <summary>
    /// What the SOURCE declared about the clock that stamped <paramref name="SampledAt"/>,
    /// carried unchanged. <paramref name="TimeQuality"/> describes this service's own
    /// clock and therefore <paramref name="ReceivedAt"/>; the two are different facts and
    /// storing only the second left a reader unable to tell a disciplined controller from
    /// an undisciplined one. CH1-COM-ICD-0001 requires time quality to be observable "so
    /// audit and TOTP decisions are not silently made on invalid time".
    /// <para>
    /// <c>null</c> means the source declared nothing. It is never resolved to a default:
    /// Control Core does not upgrade what it was told.
    /// </para>
    /// </summary>
    string? SourceTimeQuality = null);

/// <summary>
/// A channel that may be stored and queried, with the unit it is measured in and the
/// limits that raise an alarm.
/// </summary>
public sealed record TelemetryChannel(
    string ChannelId,
    string Unit,
    double LowerAlarmLimit,
    double UpperAlarmLimit,
    int AlarmPriority,
    string AlarmCode,
    string OperatorGuidance);

/// <summary>
/// The controlled set of channels this baseline accepts and serves.
/// <para>
/// CH1-SWA-API-0001 makes a channel allowlist the control on telemetry query, and
/// CH1-COM-FR-0001 requires a versioned common capability model. The catalogue is
/// applied in both directions: a sample naming an undeclared channel, or declaring a
/// unit the channel is not measured in, is refused at ingestion, and a query for an
/// undeclared channel is refused rather than silently returning nothing. Refusing is
/// what makes the allowlist observable — an empty result would be indistinguishable
/// from a channel that simply has no data.
/// </para>
/// <para>
/// The channels and units are those declared by the Prototype 2 cell capability
/// manifest. Deriving them per device from an enrolled device's stored manifest
/// belongs with device enrolment (POST /api/v1/devices/{deviceId}/enrolment), which
/// remains a controlled 501; until a device can present a signed manifest, a
/// baseline-wide catalogue is the honest scope of the allowlist and is stated as such.
/// </para>
/// </summary>
/// <requirements>CH1-COM-FR-0001, CH1-MON-FR-0001, CH1-AUT-FDS-0001</requirements>
public static class TelemetryChannelCatalogue
{
    public const string Version = "1.0.0";

    private static readonly Dictionary<string, TelemetryChannel> Channels =
        new[]
        {
            new TelemetryChannel(
                "temperature", "degC", 15.0, 45.0, 3,
                "CH1-ALM-TEMP-HIGH",
                "Check cell ventilation and enclosure temperature before continuing the work order."),
            new TelemetryChannel(
                "humidity", "%RH", 20.0, 70.0, 4,
                "CH1-ALM-HUMIDITY-RANGE",
                "Coating results are not admissible outside the qualified humidity band."),
            new TelemetryChannel(
                "position", "mm", -1.0, 240.0, 2,
                "CH1-ALM-TRAVEL-RANGE",
                "Travel outside the configured envelope. Inspect the axis before any further motion."),
            new TelemetryChannel(
                "vibration_rms", "m/s2", 0.0, 4.5, 3,
                "CH1-ALM-VIBRATION-HIGH",
                "Vibration above the qualified limit. Inspect fixturing and tool condition."),
        }.ToDictionary(channel => channel.ChannelId, StringComparer.Ordinal);

    public static IReadOnlyCollection<TelemetryChannel> All => Channels.Values;

    public static bool IsAllowed(string channelId) => Channels.ContainsKey(channelId);

    public static TelemetryChannel Require(string channelId)
    {
        Guard.Against(
            !Channels.TryGetValue(channelId, out _),
            "TELEMETRY_CHANNEL_NOT_ALLOWED",
            $"Channel '{channelId}' is not declared in telemetry channel catalogue {Version}.");
        return Channels[channelId];
    }
}

/// <summary>
/// A bounded telemetry query. CH1-SWA-API-0001 requires time and row bounds on the
/// operation, so the bounds are part of the request object and are clamped here
/// rather than being left to whatever a caller happens to send.
/// </summary>
public sealed record TelemetryQuery(
    Guid ProjectId,
    Guid? CellId,
    string? DeviceId,
    IReadOnlyList<string> ChannelIds,
    DateTimeOffset From,
    DateTimeOffset To,
    int Limit)
{
    /// <summary>Largest row count a single query may return.</summary>
    public const int MaximumRows = 1_000;

    /// <summary>Default row count when the caller states none.</summary>
    public const int DefaultRows = 250;

    /// <summary>
    /// Longest window a single query may span. Bounded because the table is
    /// partitioned by time and retained for evidence: an unbounded window would scan
    /// every partition and is not a query any operational view needs.
    /// </summary>
    public static readonly TimeSpan MaximumWindow = TimeSpan.FromDays(7);

    /// <summary>Window applied when the caller states neither end.</summary>
    public static readonly TimeSpan DefaultWindow = TimeSpan.FromHours(1);

    public static TelemetryQuery Create(
        Guid projectId,
        Guid? cellId,
        string? deviceId,
        IReadOnlyList<string> channelIds,
        DateTimeOffset? from,
        DateTimeOffset? to,
        int? limit,
        DateTimeOffset now)
    {
        var resolvedTo = to ?? now;
        var resolvedFrom = from ?? resolvedTo - DefaultWindow;
        Guard.Against(
            resolvedTo <= resolvedFrom,
            "TELEMETRY_WINDOW_INVALID",
            "The telemetry window must end after it begins.");
        Guard.Against(
            resolvedTo - resolvedFrom > MaximumWindow,
            "TELEMETRY_WINDOW_TOO_WIDE",
            $"A telemetry query may span at most {MaximumWindow.TotalDays:0} days.");

        foreach (var channelId in channelIds)
        {
            TelemetryChannelCatalogue.Require(channelId);
        }

        return new TelemetryQuery(
            projectId,
            cellId,
            deviceId,
            channelIds,
            resolvedFrom,
            resolvedTo,
            Math.Clamp(limit ?? DefaultRows, 1, MaximumRows));
    }
}
