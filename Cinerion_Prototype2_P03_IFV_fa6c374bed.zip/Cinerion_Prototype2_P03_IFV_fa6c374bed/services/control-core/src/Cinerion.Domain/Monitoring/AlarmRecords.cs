// Alarms and their life: raised, acknowledged, cleared.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Monitoring;

/// <summary>
/// Alarm lifecycle states.
/// <para>
/// Acknowledgement and cause are tracked separately because CH1-AUT-FDS-0001 makes
/// them independent: an alarm may be acknowledged while its cause is still present,
/// and its cause may go away while acknowledgement is still outstanding. Collapsing
/// them into one flag is exactly the mistake that lets an acknowledgement read as a
/// clearance.
/// </para>
/// </summary>
public enum AlarmState
{
    /// <summary>Cause present, not yet acknowledged.</summary>
    Active,

    /// <summary>Cause still present; an operator has acknowledged seeing it.</summary>
    Acknowledged,

    /// <summary>
    /// Cause has gone but the alarm latches until acknowledged, so it stays on the
    /// list. CH1-AUT-FDS-0001 requires a latching policy; a transient fault that
    /// nobody ever saw must not disappear on its own.
    /// </summary>
    ReturnedUnacknowledged,

    /// <summary>Cause gone and acknowledged. Terminal.</summary>
    Cleared,
}

/// <summary>
/// An alarm and its acknowledgement state (entities.json: Alarm; table ch1.alarms).
/// <para>
/// <see cref="CauseClear"/> and <see cref="ClearedAt"/> both describe the activation
/// condition, not the acknowledgement: they are set together when the condition that
/// raised the alarm is observed to have gone, and never by an operator action.
/// </para>
/// </summary>
/// <requirements>CH1-AUT-FDS-0001, CH1-COL-FR-0003, CH1-MON-FR-0002</requirements>
public sealed record Alarm(
    Guid AlarmId,
    Guid ProjectId,
    Guid CellId,
    string SourceId,
    string AlarmCode,
    int Priority,
    AlarmState State,
    DateTimeOffset ActivatedAt,
    string? AcknowledgedBy,
    DateTimeOffset? AcknowledgedAt,
    string? AcknowledgementComment,
    DateTimeOffset? ClearedAt,
    bool CauseClear)
{
    public static Alarm Raise(
        Guid alarmId,
        Guid projectId,
        Guid cellId,
        string sourceId,
        string alarmCode,
        int priority,
        DateTimeOffset activatedAt)
    {
        Guard.Against(alarmId == Guid.Empty, "ALARM_ID_REQUIRED", "An alarm identifier is required.");
        Guard.Against(string.IsNullOrWhiteSpace(sourceId), "ALARM_SOURCE_REQUIRED", "An alarm source is required.");
        Guard.Against(string.IsNullOrWhiteSpace(alarmCode), "ALARM_CODE_REQUIRED", "An alarm code is required.");
        // Mirrors CHECK (priority BETWEEN 1 AND 5) on ch1.alarms.
        Guard.Against(
            priority is < 1 or > 5,
            "ALARM_PRIORITY_INVALID",
            "Alarm priority must be between 1 and 5.");
        return new Alarm(
            alarmId, projectId, cellId, sourceId, alarmCode, priority,
            AlarmState.Active, activatedAt, null, null, null, null, false);
    }

    public bool IsAcknowledged => AcknowledgedAt is not null;

    /// <summary>
    /// Whether this alarm still demands operator attention. Used by the list
    /// projection so "active" means the same thing to every caller.
    /// </summary>
    public bool IsOutstanding => State != AlarmState.Cleared;

    /// <summary>
    /// Records that an authorised operator has seen the alarm.
    /// <para>
    /// This deliberately changes nothing except acknowledgement identity, time and
    /// comment. <see cref="CauseClear"/>, <see cref="ClearedAt"/>, <see cref="Priority"/>
    /// and <see cref="ActivatedAt"/> are carried through untouched, so an
    /// acknowledgement cannot clear a fault. CH1-COL-FR-0003 and CH1-AUT-FDS-0001 both
    /// require that, and CH1-CYB-ACP-0001 states it again for messages. The only state
    /// change is which acknowledgement column is populated; whether the cause has gone
    /// is decided by the equipment, never by a person pressing acknowledge.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COL-FR-0003, CH1-AUT-FDS-0001, CH1-CYB-ACP-0001</requirements>
    public Alarm Acknowledge(ActorContext actor, string comment, DateTimeOffset now)
    {
        Guard.Against(
            actor.ProjectId != ProjectId,
            "AUTH_PROJECT_SCOPE",
            "Actor is outside the alarm project scope.");
        Guard.Against(
            string.IsNullOrWhiteSpace(comment),
            "ALARM_ACKNOWLEDGEMENT_COMMENT_REQUIRED",
            "An acknowledgement comment is required.");
        Guard.Against(
            comment.Length > 1_000,
            "ALARM_ACKNOWLEDGEMENT_COMMENT_TOO_LONG",
            "An acknowledgement comment may be at most 1000 characters.");
        Guard.Against(
            IsAcknowledged,
            "ALARM_ALREADY_ACKNOWLEDGED",
            "The alarm has already been acknowledged.");

        var next = State switch
        {
            AlarmState.Active => AlarmState.Acknowledged,
            AlarmState.ReturnedUnacknowledged => AlarmState.Cleared,
            _ => throw new DomainRuleException(
                "ALARM_NOT_ACKNOWLEDGEABLE",
                $"An alarm in state {State} cannot be acknowledged."),
        };

        return this with
        {
            State = next,
            AcknowledgedBy = actor.ActorId,
            AcknowledgedAt = now,
            AcknowledgementComment = comment.Trim(),
        };
    }

    /// <summary>
    /// Records that the equipment no longer reports the activation condition. Only an
    /// observation of the source can call this; there is deliberately no operator-facing
    /// route to it.
    /// </summary>
    public Alarm ObserveCauseClear(DateTimeOffset now)
    {
        if (CauseClear)
        {
            return this;
        }

        return this with
        {
            State = IsAcknowledged ? AlarmState.Cleared : AlarmState.ReturnedUnacknowledged,
            CauseClear = true,
            ClearedAt = now,
        };
    }
}

/// <summary>
/// A bounded, cursor-paged alarm query. The cursor is the last alarm seen; PostgreSQL
/// orders by (priority, activated_at DESC, alarm_id) so the page boundary is total and
/// a row cannot be skipped or repeated when alarms are raised during paging.
/// </summary>
/// <param name="MaximumPriority">
/// Severity filter. Priority 1 is the most severe, so a maximum of 2 selects
/// priorities 1 and 2 — the most urgent alarms, not the least.
/// </param>
public sealed record AlarmQuery(
    Guid ProjectId,
    Guid? CellId,
    IReadOnlyList<AlarmState> States,
    int? MaximumPriority,
    AlarmCursor? After,
    int Limit)
{
    public const int MaximumRows = 500;
    public const int DefaultRows = 100;

    public static AlarmQuery Create(
        Guid projectId,
        Guid? cellId,
        IReadOnlyList<AlarmState> states,
        int? maximumPriority,
        AlarmCursor? after,
        int? limit)
    {
        Guard.Against(
            maximumPriority is < 1 or > 5,
            "ALARM_PRIORITY_INVALID",
            "Alarm priority must be between 1 and 5.");
        return new AlarmQuery(
            projectId,
            cellId,
            states,
            maximumPriority,
            after,
            Math.Clamp(limit ?? DefaultRows, 1, MaximumRows));
    }
}

/// <summary>
/// Opaque page position. Carries the whole sort key so paging is keyset-based rather
/// than an offset that shifts as alarms are raised.
/// </summary>
public sealed record AlarmCursor(int Priority, DateTimeOffset ActivatedAt, Guid AlarmId)
{
    public string Encode() =>
        Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(
            $"{Priority}|{ActivatedAt.UtcDateTime:O}|{AlarmId}"));

    public static AlarmCursor? Decode(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        try
        {
            var parts = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(value)).Split('|');
            if (parts.Length == 3 &&
                int.TryParse(parts[0], System.Globalization.CultureInfo.InvariantCulture, out var priority) &&
                DateTimeOffset.TryParse(
                    parts[1],
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.RoundtripKind,
                    out var activatedAt) &&
                Guid.TryParse(parts[2], out var alarmId))
            {
                return new AlarmCursor(priority, activatedAt, alarmId);
            }
        }
        catch (FormatException)
        {
            // Falls through to the shared rejection below: a malformed cursor is a
            // client fault with a stable code, not a 500 and not a silent first page.
        }

        throw new DomainRuleException("ALARM_CURSOR_INVALID", "The alarm page cursor is not valid.");
    }
}
