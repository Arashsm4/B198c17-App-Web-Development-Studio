// Alarms raised by security events rather than by a sensor reading.

namespace Cinerion.Domain.Monitoring;

/// <summary>
/// Alarms raised by security events rather than by a measured channel.
/// <para>
/// CH1-CYB-CSRS-0001 requires alerting to cover, among other things, revoked device use
/// and trust-list change, and api_endpoints.json makes an alarm part of the control on
/// device revocation. These reach the same operator alarm list as a temperature breach,
/// through the same lifecycle, because an operator should not have to know which
/// subsystem noticed something to find out that something was noticed.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-CSRS-0001, CH1-IAM-FR-0006, CH1-AUT-FDS-0001</requirements>
public static class SecurityAlarms
{
    /// <summary>A device certificate was enrolled or rotated: the trust list changed.</summary>
    public const string DeviceTrustChanged = "CH1-ALM-DEVICE-TRUST-CHANGED";

    /// <summary>A device's trust was withdrawn.</summary>
    public const string DeviceRevoked = "CH1-ALM-DEVICE-REVOKED";

    /// <summary>
    /// A device whose trust was withdrawn tried to publish anyway. The most serious of
    /// the three: it is either equipment nobody told, or an attacker holding a
    /// certificate that should no longer work.
    /// </summary>
    public const string RevokedDeviceUse = "CH1-ALM-DEVICE-REVOKED-USE";

    /// <summary>
    /// Priority and operator guidance per code. Priority 1 is the most severe, matching
    /// the 1-5 range on ch1.alarms.
    /// </summary>
    private static readonly Dictionary<string, (int Priority, string Guidance)> Catalogue =
        new(StringComparer.Ordinal)
        {
            [DeviceTrustChanged] = (
                3,
                "A device certificate was enrolled or rotated. Confirm the change was expected and that the " +
                "thumbprint matches the certificate the device actually holds."),
            [DeviceRevoked] = (
                2,
                "A device's trust was withdrawn. It can no longer publish telemetry. Confirm the equipment is " +
                "safe without it and arrange a replacement credential before returning the cell to service."),
            [RevokedDeviceUse] = (
                1,
                "A revoked device attempted to publish. Either equipment is still running with a withdrawn " +
                "credential, or something is presenting one. Isolate the device conduit and investigate before " +
                "re-enrolling anything."),
        };

    public static bool IsSecurityAlarm(string alarmCode) => Catalogue.ContainsKey(alarmCode);

    public static int PriorityOf(string alarmCode) =>
        Catalogue.TryGetValue(alarmCode, out var entry) ? entry.Priority : 3;

    public static string? GuidanceFor(string alarmCode) =>
        Catalogue.TryGetValue(alarmCode, out var entry) ? entry.Guidance : null;
}
