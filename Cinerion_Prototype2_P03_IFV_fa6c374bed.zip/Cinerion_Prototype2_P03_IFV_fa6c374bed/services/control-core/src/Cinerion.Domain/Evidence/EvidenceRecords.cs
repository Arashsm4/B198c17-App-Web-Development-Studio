// Records for reports and scan events.

using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using Cinerion.Domain.Common;

namespace Cinerion.Domain.Evidence;

/// <summary>
/// A report generated from controlled records (table ch1.reports).
/// <para>
/// entities.json declares no Report entity, so this extends the evidence family rather
/// than inventing one — the same resolution the promotion request takes. Reported as a
/// conflict.
/// </para>
/// </summary>
/// <requirements>CH1-RPT-FR-0001, CH1-RPT-FR-0002</requirements>
public sealed record ReportRecord(
    Guid ReportId,
    Guid ProjectId,
    string ReportType,
    string TemplateId,
    string TemplateRevision,
    string InputObjectType,
    IReadOnlyList<string> InputObjectIds,
    string DeterminismKey,
    string ContentSha256,
    string MediaType,
    long SizeBytes,
    string StorageUri,
    string DocumentNumber,
    string IssueStatus,
    string ApprovalState,
    string GeneratedBy,
    DateTimeOffset GeneratedAt)
{
    public const int MaximumInputs = 500;

    /// <summary>
    /// ASCII unit separator. Used to join canonical fields before hashing so a value
    /// containing the delimiter cannot be arranged to collide with a different set of
    /// fields — 0x1F cannot appear in an identifier or a revision string.
    /// </summary>
    internal const char Separator = '';

    /// <summary>
    /// The identity of a generation request: template revision plus the inputs, ordered.
    /// <para>
    /// Two requests naming the same records under the same template revision have the
    /// same key and must return the same report. Ordering the identifiers first means the
    /// order a caller happens to list them in cannot produce a second report of the same
    /// thing — which is the difference between deterministic and merely repeatable.
    /// </para>
    /// </summary>
    public static string ComputeDeterminismKey(
        string templateId,
        string templateRevision,
        string inputObjectType,
        IEnumerable<string> inputObjectIds)
    {
        var canonical = new StringBuilder()
            .Append(templateId).Append(Separator)
            .Append(templateRevision).Append(Separator)
            .Append(inputObjectType).Append(Separator);
        foreach (var id in inputObjectIds.Select(item => item.Trim()).OrderBy(item => item, StringComparer.Ordinal))
        {
            canonical.Append(id).Append(Separator);
        }

        return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(canonical.ToString())));
    }

    public static ReportRecord Generate(
        Guid reportId,
        Guid projectId,
        string reportType,
        string templateId,
        string templateRevision,
        string inputObjectType,
        IReadOnlyList<string> inputObjectIds,
        string renderedContent,
        string mediaType,
        string documentNumber,
        string generatedBy,
        DateTimeOffset now)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(reportType),
            "REPORT_TYPE_REQUIRED",
            "A report must state what kind of report it is.");
        Guard.Against(
            string.IsNullOrWhiteSpace(templateRevision),
            "REPORT_TEMPLATE_REVISION_REQUIRED",
            "A report must pin the template revision it was produced under; without it the " +
            "same inputs could later render differently with nothing to show why.");
        Guard.Against(
            inputObjectIds.Count == 0,
            "REPORT_INPUTS_REQUIRED",
            "A report is generated from controlled records. Name at least one.");
        Guard.Against(
            inputObjectIds.Count > MaximumInputs,
            "REPORT_INPUTS_TOO_MANY",
            $"A report may draw on at most {MaximumInputs} records.");
        Guard.Against(
            inputObjectIds.Any(string.IsNullOrWhiteSpace),
            "REPORT_INPUT_INVALID",
            "Every input identifier must be present.");

        var content = Encoding.UTF8.GetBytes(renderedContent);
        return new ReportRecord(
            reportId, projectId, reportType.Trim(), templateId.Trim(), templateRevision.Trim(),
            inputObjectType, inputObjectIds,
            ComputeDeterminismKey(templateId, templateRevision, inputObjectType, inputObjectIds),
            Convert.ToHexStringLower(SHA256.HashData(content)),
            mediaType, content.LongLength,
            $"cinerion://reports/{reportId}",
            documentNumber,
            // The platform generates; it does not approve. CH1-RPT-FR-0002 wants the
            // approval state on the face of the report, and stating "Unapproved" is the
            // honest value for something no reviewer has seen.
            "IFV",
            "Unapproved",
            generatedBy, now);
    }
}

public enum ScanIdentifierKind
{
    QR,
    DataMatrix,
    RFID,
    NFC,
}

public enum ScanResolution
{
    Resolved,
    UnknownIdentifier,
    Duplicate,
}

/// <summary>
/// One QR or RFID read at a station (table ch1.scan_events).
/// <para>
/// A scan resolves identity and state and confers no authority whatever. Reading a tag
/// has never started equipment, released a part or satisfied a permissive, and there is
/// no field here that could express one.
/// </para>
/// </summary>
/// <requirements>CH1-MFG-FR-0002, CH1-TRC-FR-0002, CH1-CYB-IAM-0001</requirements>
public sealed record ScanEventRecord(
    Guid ScanEventId,
    Guid ProjectId,
    Guid? PartId,
    ScanIdentifierKind IdentifierKind,
    string IdentifierValue,
    string StationId,
    string DeviceId,
    string ScannedBy,
    DateTimeOffset ScannedAt,
    DateTimeOffset ReceivedAt,
    string SessionSignatureSha256,
    Guid? DuplicateOf,
    ScanResolution Resolution)
{
    /// <summary>
    /// How far in the past a store-and-forward delivery may reach. CH1-NFR-REL-0001 gives
    /// a gateway a 24-hour buffer, so a scan older than that arrived from something that
    /// was not simply offline.
    /// </summary>
    public static readonly TimeSpan MaximumDeliveryDelay = TimeSpan.FromHours(24);

    /// <summary>
    /// The signature the device computes over the session and the read. Recomputed here
    /// from the device's session key so a caller cannot present an event it did not scan;
    /// the platform derives it and compares, exactly as it derives a certificate
    /// thumbprint rather than accepting one.
    /// </summary>
    public static string ComputeSessionSignature(
        string deviceId,
        string stationId,
        string identifierValue,
        DateTimeOffset scannedAt,
        ReadOnlySpan<byte> sessionKey)
    {
        var canonical = string.Join(
            ReportRecord.Separator,
            deviceId,
            stationId,
            identifierValue,
            scannedAt.ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture));
        return Convert.ToHexStringLower(
            HMACSHA256.HashData(sessionKey, Encoding.UTF8.GetBytes(canonical)));
    }

    public static ScanEventRecord Record(
        Guid scanEventId,
        Guid projectId,
        Guid? partId,
        ScanIdentifierKind identifierKind,
        string identifierValue,
        string stationId,
        string deviceId,
        string scannedBy,
        DateTimeOffset scannedAt,
        string sessionSignature,
        Guid? duplicateOf,
        DateTimeOffset now)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(identifierValue),
            "SCAN_IDENTIFIER_REQUIRED",
            "A scan must carry the identifier that was read.");
        Guard.Against(
            string.IsNullOrWhiteSpace(stationId),
            "SCAN_STATION_REQUIRED",
            "A scan must name the station it happened at; station scope is a control on this operation.");
        Guard.Against(
            scannedAt > now,
            "SCAN_TIME_IN_FUTURE",
            "A scan cannot have been taken in the future.");
        Guard.Against(
            now - scannedAt > MaximumDeliveryDelay,
            "SCAN_TOO_OLD_TO_ACCEPT",
            $"The scan is older than the {MaximumDeliveryDelay.TotalHours:0} hour store-and-forward " +
            "buffer and is refused rather than recorded as if it were current.");

        var resolution = duplicateOf is not null
            ? ScanResolution.Duplicate
            : partId is not null
                ? ScanResolution.Resolved
                : ScanResolution.UnknownIdentifier;

        return new ScanEventRecord(
            scanEventId, projectId,
            resolution == ScanResolution.Resolved ? partId : null,
            identifierKind, identifierValue.Trim(), stationId.Trim(), deviceId, scannedBy,
            scannedAt, now, sessionSignature, duplicateOf, resolution);
    }
}
