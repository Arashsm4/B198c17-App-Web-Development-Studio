// Records for revisions, BOM lines, routes and work orders.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Manufacturing;

/// <summary>Lifecycle of an engineering revision (ch1.product_revisions.lifecycle_state).</summary>
public enum RevisionLifecycleState
{
    Draft,
    Released,
    Superseded,
    Withdrawn,
}

public enum WorkOrderStatus
{
    Draft,
    Released,
    Complete,
    Cancelled,
}

/// <summary>Physical or logical equipment (entities.json: Asset; table ch1.assets).</summary>
public sealed record AssetRecord(
    Guid AssetId,
    Guid ProjectId,
    Guid? CellId,
    string AssetCode,
    string Name,
    string AssetType,
    string ConfigurationRevision,
    string LifecycleState,
    long Version);

public sealed record BomLine(string ComponentCode, decimal Quantity, string Unit);

public sealed record RouteStep(int StepNumber, string OperationCode, string Description, bool MandatoryInspection);

/// <summary>
/// Immutable released revision (entities.json: ProductRevision; table
/// ch1.product_revisions). The BOM and route are structured content of the revision,
/// matching the bom and route jsonb columns.
/// </summary>
/// <requirements>CH1-MFG-FR-0001, CH1-MFG-FR-0003, CH1-MFG-FR-0005</requirements>
public sealed record ProductRevisionRecord(
    Guid RevisionId,
    Guid ProjectId,
    string ProductCode,
    string RevisionCode,
    RevisionLifecycleState LifecycleState,
    IReadOnlyList<BomLine> Bom,
    IReadOnlyList<RouteStep> Route,
    string SourceChecksum,
    DateTimeOffset? ReleasedAt,
    DateTimeOffset? SupersededAt,
    long Version)
{
    public static ProductRevisionRecord CreateDraft(
        string productCode,
        string revisionCode,
        ActorContext actor)
    {
        AuthoriseEngineering(actor);
        Guard.Against(string.IsNullOrWhiteSpace(productCode), "PRODUCT_CODE_REQUIRED", "A product code is required.");
        Guard.Against(string.IsNullOrWhiteSpace(revisionCode), "REVISION_CODE_REQUIRED", "A revision code is required.");
        return new ProductRevisionRecord(
            Guid.NewGuid(),
            actor.ProjectId,
            productCode,
            revisionCode,
            RevisionLifecycleState.Draft,
            [],
            [],
            // The checksum covers the controlled content, so it is empty until content
            // exists and is recomputed on every change.
            EmptyChecksum,
            null,
            null,
            1);
    }

    public static readonly string EmptyChecksum = CanonicalJson.Sha256Hex(new { Bom = Array.Empty<BomLine>(), Route = Array.Empty<RouteStep>() });

    /// <summary>
    /// Replaces the bill of material. Only a draft may be edited: once released, a
    /// revision is immutable and a change is a new revision, which is what makes the
    /// revision usable as controlled evidence.
    /// </summary>
    public ProductRevisionRecord WithBom(IReadOnlyList<BomLine> bom, long expectedVersion, ActorContext actor)
    {
        AuthoriseEdit(expectedVersion, actor);
        Guard.Against(bom.Count == 0, "BOM_EMPTY", "A bill of material must contain at least one component.");
        Guard.Against(
            bom.Any(line => string.IsNullOrWhiteSpace(line.ComponentCode) || line.Quantity <= 0 || string.IsNullOrWhiteSpace(line.Unit)),
            "BOM_LINE_INVALID",
            "Every component needs an identifier, a positive quantity and a unit.");
        Guard.Against(
            bom.Select(line => line.ComponentCode).Distinct(StringComparer.Ordinal).Count() != bom.Count,
            "BOM_DUPLICATE_COMPONENT",
            "A component may appear once; combine quantities instead.");
        return Recomputed(this with { Bom = [.. bom] });
    }

    /// <summary>Replaces the manufacturing and inspection route.</summary>
    public ProductRevisionRecord WithRoute(IReadOnlyList<RouteStep> route, long expectedVersion, ActorContext actor)
    {
        AuthoriseEdit(expectedVersion, actor);
        Guard.Against(route.Count == 0, "ROUTE_EMPTY", "A route must contain at least one operation.");
        Guard.Against(
            route.Any(step => step.StepNumber <= 0 || string.IsNullOrWhiteSpace(step.OperationCode)),
            "ROUTE_STEP_INVALID",
            "Every route step needs a positive number and an operation code.");
        var ordered = route.OrderBy(step => step.StepNumber).ToArray();
        Guard.Against(
            ordered.Select(step => step.StepNumber).Distinct().Count() != ordered.Length,
            "ROUTE_STEP_DUPLICATE",
            "Route step numbers must be unique.");
        Guard.Against(
            !ordered.Any(step => step.MandatoryInspection),
            "ROUTE_INSPECTION_REQUIRED",
            "A controlled route must contain at least one mandatory inspection step.");
        return Recomputed(this with { Route = ordered });
    }

    /// <summary>
    /// Releases the revision. CH1-MFG-FR-0003 requires a controlled job package with
    /// released content and checksums, so a revision cannot be released until both the
    /// bill of material and the route exist.
    /// </summary>
    public ProductRevisionRecord Release(long expectedVersion, ActorContext actor, DateTimeOffset now)
    {
        AuthoriseEdit(expectedVersion, actor);
        Guard.Against(Bom.Count == 0, "BOM_EMPTY", "A revision cannot be released without a bill of material.");
        Guard.Against(Route.Count == 0, "ROUTE_EMPTY", "A revision cannot be released without a route.");
        return this with
        {
            LifecycleState = RevisionLifecycleState.Released,
            ReleasedAt = now,
            Version = Version + 1,
        };
    }

    /// <summary>Marks this revision superseded so it can no longer start new work.</summary>
    public ProductRevisionRecord Supersede(DateTimeOffset now)
    {
        Guard.Against(
            LifecycleState != RevisionLifecycleState.Released,
            "REVISION_NOT_RELEASED",
            "Only a released revision can be superseded.");
        return this with { LifecycleState = RevisionLifecycleState.Superseded, SupersededAt = now, Version = Version + 1 };
    }

    private void AuthoriseEdit(long expectedVersion, ActorContext actor)
    {
        AuthoriseEngineering(actor);
        Guard.Against(actor.ProjectId != ProjectId, "AUTH_PROJECT_SCOPE", "Actor is outside the revision project scope.");
        Guard.Against(
            LifecycleState != RevisionLifecycleState.Draft,
            "REVISION_NOT_EDITABLE",
            "A released revision is immutable; raise a new revision instead.");
        // Optimistic concurrency, per the P03 catalogue entry for BOM and route.
        Guard.Against(expectedVersion != Version, "CONCURRENCY_CONFLICT", "The revision changed since it was read.");
    }

    private static void AuthoriseEngineering(ActorContext actor)
    {
        Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required for engineering control.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.Engineer),
            "AUTH_ENGINEER_REQUIRED",
            "Engineer authority is required to author a revision.");
        Guard.Against(
            actor.AuthenticationStrength < AuthenticationStrength.Mfa,
            "AUTH_MFA_REQUIRED",
            "Authoring a revision requires multi-factor authentication.");
    }

    /// <summary>The checksum always describes the current controlled content.</summary>
    private static ProductRevisionRecord Recomputed(ProductRevisionRecord revision) =>
        revision with
        {
            SourceChecksum = CanonicalJson.Sha256Hex(new { revision.Bom, revision.Route }),
            Version = revision.Version + 1,
        };
}

/// <summary>Authorised production instance (entities.json: WorkOrder; table ch1.work_orders).</summary>
/// <requirements>CH1-MFG-FR-0001, CH1-MFG-FR-0005</requirements>
public sealed record WorkOrderRecord(
    Guid WorkOrderId,
    Guid ProjectId,
    Guid RevisionId,
    Guid? CellId,
    string WorkOrderNumber,
    int Quantity,
    WorkOrderStatus Status,
    string? ReleasedBy,
    DateTimeOffset? ReleasedAt,
    long Version)
{
    public static WorkOrderRecord Create(
        string workOrderNumber,
        ProductRevisionRecord revision,
        Guid? cellId,
        int quantity,
        ActorContext actor)
    {
        Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required to raise a work order.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.ProjectManager),
            "AUTH_PROJECT_MANAGER_REQUIRED",
            "Project Manager authority is required to raise a work order.");
        Guard.Against(
            actor.AuthenticationStrength < AuthenticationStrength.Mfa,
            "AUTH_MFA_REQUIRED",
            "Raising a work order requires multi-factor authentication.");
        Guard.Against(string.IsNullOrWhiteSpace(workOrderNumber), "WORK_ORDER_NUMBER_REQUIRED", "A work-order number is required.");
        Guard.Against(quantity <= 0, "WORK_ORDER_QUANTITY_INVALID", "Quantity must be positive.");
        Guard.Against(revision.ProjectId != actor.ProjectId, "AUTH_PROJECT_SCOPE", "The revision is outside the caller project scope.");

        // CH1-MFG-FR-0005 states this directly: a superseded engineering revision
        // shall not be selectable for a new work order. Draft and withdrawn are
        // refused for the same reason - only released content may start production.
        Guard.Against(
            revision.LifecycleState != RevisionLifecycleState.Released,
            "REVISION_NOT_SELECTABLE",
            "Only a released engineering revision may start a new work order.");
        Guard.Against(
            actor.CellIds.Count > 0 && cellId is not null && !actor.CanAccessCell(cellId.Value),
            "AUTH_CELL_SCOPE",
            "Actor is outside the target cell scope.");

        return new WorkOrderRecord(
            Guid.NewGuid(),
            actor.ProjectId,
            revision.RevisionId,
            cellId,
            workOrderNumber,
            quantity,
            WorkOrderStatus.Draft,
            null,
            null,
            1);
    }

    /// <summary>
    /// Releases the work order for execution. The catalogue requires step-up and
    /// readiness rules; step-up is redeemed at the endpoint and the readiness rule is
    /// that the pinned revision must still be released when work actually starts, not
    /// merely when the order was raised.
    /// </summary>
    public WorkOrderRecord Release(ProductRevisionRecord revision, ActorContext actor, DateTimeOffset now)
    {
        Guard.Against(
            !actor.HasRole(CinerionRoles.ProjectManager),
            "AUTH_PROJECT_MANAGER_REQUIRED",
            "Project Manager authority is required to release a work order.");
        Guard.Against(
            actor.AuthenticationStrength < AuthenticationStrength.StepUpPhishingResistant,
            "AUTH_STEP_UP_REQUIRED",
            "Releasing a work order requires recent phishing-resistant step-up.");
        Guard.Against(ProjectId != actor.ProjectId, "AUTH_PROJECT_SCOPE", "Actor is outside the work-order project scope.");
        Guard.Against(Status != WorkOrderStatus.Draft, "WORK_ORDER_NOT_DRAFT", "Only a draft work order can be released.");
        Guard.Against(revision.RevisionId != RevisionId, "WORK_ORDER_REVISION_MISMATCH", "The revision does not match the pinned revision.");
        Guard.Against(
            revision.LifecycleState != RevisionLifecycleState.Released,
            "REVISION_NOT_SELECTABLE",
            "The pinned revision is no longer released, so work must not start.");

        return this with
        {
            Status = WorkOrderStatus.Released,
            ReleasedBy = actor.ActorId,
            ReleasedAt = now,
            Version = Version + 1,
        };
    }
}
