// Parts, measurements and release records.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Quality;

public enum PartStatus
{
    InProcess,
    Hold,
    Accepted,
    Released,
}

public enum MeasurementResult
{
    Pass,
    Fail,
}

public sealed record Measurement(
    Guid MeasurementId,
    /// <summary>
    /// The execution instance this result belongs to. Mandatory, mirroring the NOT
    /// NULL ch1.measurements.test_run_id column: an acceptance result that is not
    /// attributable to a controlled run is not evidence.
    /// </summary>
    Guid TestRunId,
    string Characteristic,
    decimal Value,
    string Unit,
    decimal LowerLimit,
    decimal UpperLimit,
    bool Mandatory,
    string SourceDeviceId,
    Guid CalibrationRecordId,
    Guid? SupersedesMeasurementId,
    bool CalibrationValid,
    DateTimeOffset MeasuredAt,
    MeasurementResult Result);

public sealed record ReleaseRecord(Guid ReleaseId, string InspectorId, DateTimeOffset ReleasedAt);

/// <summary>
/// Permanent component genealogy root (entities.json: PhysicalPart; table
/// ch1.physical_parts).
/// <para>
/// CH1-MFG-FR-0002 requires every physical component to receive a permanent unique
/// identity linked to its work order and product revision. That is why the revision
/// is an identifier rather than a text label: a label cannot be resolved back to the
/// controlled revision that governed the part, and the schema reflects this with
/// revision_id as a foreign key. The serial number and permanent identity URI are the
/// identity itself, both unique in ch1.physical_parts.
/// </para>
/// </summary>
/// <requirements>CH1-MFG-FR-0002, CH1-TRC-FR-0001</requirements>
public sealed record PartRecord(
    Guid ProjectId,
    Guid PartId,
    Guid WorkOrderId,
    Guid RevisionId,
    string SerialNumber,
    string PermanentIdentityUri,
    string OperatorId,
    PartStatus Status,
    IReadOnlyList<Guid> OpenNcrIds,
    IReadOnlyList<Measurement> Measurements,
    ReleaseRecord? Release)
{
    /// <summary>
    /// Establishes a component identity. The URI is derived from the serial number so
    /// the two cannot disagree, and is stable for the life of the component.
    /// </summary>
    public static PartRecord Create(
        Guid projectId,
        Guid partId,
        Guid workOrderId,
        Guid revisionId,
        string serialNumber,
        string operatorId)
    {
        Guard.Against(projectId == Guid.Empty, "PART_PROJECT_REQUIRED", "A part must belong to a project.");
        Guard.Against(partId == Guid.Empty, "PART_ID_REQUIRED", "A part identifier is required.");
        Guard.Against(workOrderId == Guid.Empty, "PART_WORK_ORDER_REQUIRED", "A part must be linked to its work order.");
        Guard.Against(revisionId == Guid.Empty, "PART_REVISION_REQUIRED", "A part must be linked to its product revision.");
        Guard.Against(string.IsNullOrWhiteSpace(serialNumber), "PART_SERIAL_REQUIRED", "A permanent serial number is required.");
        Guard.Against(string.IsNullOrWhiteSpace(operatorId), "PART_OPERATOR_REQUIRED", "The performing operator identity is required.");
        return new PartRecord(
            projectId,
            partId,
            workOrderId,
            revisionId,
            serialNumber,
            $"urn:cinerion:ch1:part:{serialNumber}",
            operatorId,
            PartStatus.InProcess,
            [],
            [],
            null);
    }

    /// <requirements>CH1-QMS-FR-0002, CH1-QMS-FR-0003, CH1-QMS-FR-0004, CH1-QMS-FR-0006</requirements>
    public PartRecord RecordMeasurement(
        Guid testRunId,
        string characteristic,
        decimal value,
        string unit,
        decimal lowerLimit,
        decimal upperLimit,
        bool mandatory,
        string sourceDeviceId,
        Guid calibrationRecordId,
        bool calibrationValid,
        DateTimeOffset measuredAt,
        Guid? supersedesMeasurementId = null)
    {
        Guard.Against(testRunId == Guid.Empty, "MEASUREMENT_TEST_RUN_REQUIRED", "A controlled test run is required.");
        Guard.Against(!calibrationValid, "INSTRUMENT_CALIBRATION_EXPIRED", "Instrument calibration is not valid.");
        Guard.Against(lowerLimit > upperLimit, "MEASUREMENT_LIMITS_INVALID", "Measurement limits are invalid.");
        Guard.Against(string.IsNullOrWhiteSpace(characteristic), "MEASUREMENT_CHARACTERISTIC_REQUIRED", "Controlled characteristic is required.");
        Guard.Against(string.IsNullOrWhiteSpace(unit), "MEASUREMENT_UNIT_REQUIRED", "Engineering unit is required.");
        Guard.Against(string.IsNullOrWhiteSpace(sourceDeviceId), "MEASUREMENT_SOURCE_REQUIRED", "Source device identity is required.");
        Guard.Against(calibrationRecordId == Guid.Empty, "CALIBRATION_RECORD_REQUIRED", "Calibration record identity is required.");
        if (supersedesMeasurementId is not null)
        {
            var source = Measurements.SingleOrDefault(item => item.MeasurementId == supersedesMeasurementId.Value);
            Guard.Against(source is null, "RETEST_SOURCE_NOT_FOUND", "Superseded measurement does not belong to this part.");
            Guard.Against(
                source is not null && (!source.Mandatory || source.Result != MeasurementResult.Fail),
                "RETEST_SOURCE_NOT_FAILED",
                "A retest may supersede only a failed mandatory result.");
            Guard.Against(
                source is not null && (!StringComparer.Ordinal.Equals(source.Characteristic, characteristic) || !StringComparer.Ordinal.Equals(source.Unit, unit)),
                "RETEST_CHARACTERISTIC_MISMATCH",
                "Retest characteristic and unit must match the failed result.");
            Guard.Against(
                Measurements.Any(item => item.SupersedesMeasurementId == supersedesMeasurementId),
                "RETEST_ALREADY_RECORDED",
                "The failed measurement already has a controlled retest.");
        }
        var result = value >= lowerLimit && value <= upperLimit ? MeasurementResult.Pass : MeasurementResult.Fail;
        var measurement = new Measurement(
            Guid.NewGuid(),
            testRunId,
            characteristic,
            value,
            unit,
            lowerLimit,
            upperLimit,
            mandatory,
            sourceDeviceId,
            calibrationRecordId,
            supersedesMeasurementId,
            calibrationValid,
            measuredAt,
            result);
        return this with
        {
            Measurements = [.. Measurements, measurement],
            Status = mandatory && result == MeasurementResult.Fail ? PartStatus.Hold : Status,
        };
    }

    public (PartRecord Part, Guid NcrId) RaiseNcr()
    {
        Guard.Against(Status != PartStatus.Hold, "PART_NOT_ON_HOLD", "An NCR requires a held part.");
        var ncrId = Guid.NewGuid();
        return (this with { OpenNcrIds = [.. OpenNcrIds, ncrId] }, ncrId);
    }

    public PartRecord CloseNcrAfterPassingRetest(Guid ncrId)
    {
        Guard.Against(!OpenNcrIds.Contains(ncrId), "NCR_NOT_OPEN", "NCR is not open for this part.");
        Guard.Against(Measurements.Count == 0 || !Measurements[^1].Mandatory || Measurements[^1].Result != MeasurementResult.Pass, "RETEST_NOT_PASSING", "A passing mandatory retest is required.");
        var retest = Measurements[^1];
        Guard.Against(retest.SupersedesMeasurementId is null, "RETEST_SOURCE_NOT_FOUND", "Passing retest is not linked to the failed mandatory measurement.");
        var remaining = OpenNcrIds.Where(item => item != ncrId).ToArray();
        return this with { OpenNcrIds = remaining, Status = remaining.Length == 0 ? PartStatus.Accepted : PartStatus.Hold };
    }

    /// <summary>
    /// Releases an accepted part on the evidence of a redeemed step-up grant.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The grant is passed in rather than read from the session. A session-level strength
    /// claim states how an identity authenticated at some earlier point; it cannot state
    /// that this person re-authenticated <em>for this release</em>, moments ago, once.
    /// CH1-CYB-IAM-0001 asks for phishing-resistant <em>and recent</em>, and the repository
    /// policy gate already forbids the identity provider from carrying
    /// <c>ch1_auth_strength</c> as a stored attribute for exactly that reason — so reading
    /// the same property off the actor here would have re-admitted what that rule excludes.
    /// </para>
    /// <para>
    /// <c>ConsumedAt</c> is required, so the grant must have passed through
    /// <c>StepUpService.RedeemAsync</c> — which is what makes the redemption single-use and
    /// puts it in the audit chain. A grant constructed and handed straight here is refused.
    /// </para>
    /// </remarks>
    /// <requirements>CH1-QMS-FR-0005, CH1-IAM-FR-0004, CH1-CYB-IAM-0001</requirements>
    public PartRecord ReleaseBy(ActorContext inspector, StepUpGrant stepUp, DateTimeOffset now)
    {
        Guard.Against(inspector.Kind != ActorKind.Human || !inspector.HasRole(CinerionRoles.Inspector), "INSPECTOR_REQUIRED", "Independent Inspector authority is required.");
        Guard.Against(inspector.AuthenticationStrength < AuthenticationStrength.Mfa, "AUTH_MFA_REQUIRED", "Controlled release requires at least multi-factor authentication.");
        Guard.Against(!StringComparer.Ordinal.Equals(stepUp.Purpose, StepUpPurpose.PartRelease), "AUTH_STEP_UP_PURPOSE", "The step-up presented was granted for another purpose.");
        Guard.Against(stepUp.Strength < AuthenticationStrength.StepUpPhishingResistant, "AUTH_STEP_UP_REQUIRED", "Release requires recent phishing-resistant step-up.");
        Guard.Against(!StringComparer.Ordinal.Equals(stepUp.ActorId, inspector.ActorId), "AUTH_STEP_UP_NOT_HELD", "The step-up presented was granted to another identity.");
        Guard.Against(stepUp.ProjectId != ProjectId, "AUTH_PROJECT_SCOPE", "The step-up presented is outside the part project scope.");
        Guard.Against(stepUp.ConsumedAt is null, "AUTH_STEP_UP_NOT_REDEEMED", "The step-up presented was never redeemed, so it is not evidence of a single controlled act.");
        Guard.Against(inspector.ProjectId != ProjectId, "AUTH_PROJECT_SCOPE", "Inspector is outside the part project scope.");
        Guard.Against(StringComparer.Ordinal.Equals(inspector.ActorId, OperatorId), "SEGREGATION_OF_DUTIES", "The operation performer cannot release the component.");
        Guard.Against(Status != PartStatus.Accepted || OpenNcrIds.Count > 0, "PART_NOT_ACCEPTABLE", "Part is not accepted or has open NCRs.");
        var currentMandatoryResults = Measurements
            .Where(item => item.Mandatory)
            .GroupBy(item => (item.Characteristic, item.Unit))
            .Select(group => group.Last())
            .ToArray();
        Guard.Against(currentMandatoryResults.Length == 0 || currentMandatoryResults.Any(item => item.Result != MeasurementResult.Pass), "MANDATORY_TESTS_INCOMPLETE", "The current result for every mandatory characteristic must pass.");
        return this with
        {
            Status = PartStatus.Released,
            Release = new ReleaseRecord(Guid.NewGuid(), inspector.ActorId, now),
        };
    }
}
