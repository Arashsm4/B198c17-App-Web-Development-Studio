// Test runs and nonconformities, and what may be decided about each.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Quality;

public enum TestRunStatus
{
    InProgress,
    Completed,
    Abandoned,
}

public enum NcrStatus
{
    Open,
    Dispositioned,
    Closed,
}

/// <summary>
/// Controlled dispositions for a nonconformity. A disposition is a decision about
/// the nonconforming part; only <see cref="Close"/> asserts the nonconformity has
/// been resolved, and it alone requires passing retest evidence.
/// </summary>
public enum NcrDispositionKind
{
    Rework,
    UseAsIs,
    Scrap,
    Close,
}

/// <summary>
/// Execution instance of a controlled test procedure (entities.json: TestRun; table
/// ch1.test_runs). Measurements reference it, so it must exist before a result can
/// be recorded.
/// </summary>
/// <requirements>CH1-QMS-FR-0001, CH1-QMS-FR-0002</requirements>
public sealed record TestRunRecord(
    Guid TestRunId,
    Guid ProjectId,
    Guid PartId,
    string ProcedureId,
    string ProcedureRevision,
    string StartedBy,
    string? WitnessedBy,
    TestRunStatus Status,
    DateTimeOffset StartedAt,
    DateTimeOffset? CompletedAt,
    long Version)
{
    public static TestRunRecord Start(
        Guid partId,
        string procedureId,
        string procedureRevision,
        ActorContext actor,
        DateTimeOffset now)
    {
        Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required to start a controlled test run.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.Inspector) && !actor.HasRole(CinerionRoles.Engineer),
            "AUTH_INSPECTION_ROLE_REQUIRED",
            "Inspector or Engineer role is required to start a controlled test run.");
        Guard.Against(
            actor.AuthenticationStrength < AuthenticationStrength.Mfa,
            "AUTH_MFA_REQUIRED",
            "Starting a controlled test run requires multi-factor authentication.");
        Guard.Against(partId == Guid.Empty, "TEST_RUN_PART_REQUIRED", "A physical part is required.");
        Guard.Against(string.IsNullOrWhiteSpace(procedureId), "TEST_RUN_PROCEDURE_REQUIRED", "A controlled procedure identifier is required.");
        Guard.Against(
            string.IsNullOrWhiteSpace(procedureRevision),
            "TEST_RUN_PROCEDURE_REVISION_REQUIRED",
            "The procedure revision must be pinned so the acceptance limits are traceable.");

        return new TestRunRecord(
            Guid.NewGuid(),
            actor.ProjectId,
            partId,
            procedureId,
            procedureRevision,
            actor.ActorId,
            null,
            TestRunStatus.InProgress,
            now,
            null,
            1);
    }

    /// <summary>A result may only be added to a run that is still open on this part.</summary>
    public void EnsureAcceptsResultsFor(Guid partId, ActorContext actor)
    {
        Guard.Against(Status != TestRunStatus.InProgress, "TEST_RUN_NOT_OPEN", "The test run is no longer accepting results.");
        Guard.Against(PartId != partId, "TEST_RUN_PART_MISMATCH", "The test run belongs to another part.");
        Guard.Against(ProjectId != actor.ProjectId, "AUTH_PROJECT_SCOPE", "The test run is outside the caller project scope.");
    }
}

/// <summary>
/// Nonconformity and its disposition (entities.json: NCR; table ch1.ncrs).
/// </summary>
/// <requirements>CH1-QMS-FR-0004, CH1-QMS-FR-0005</requirements>
public sealed record NcrRecord(
    Guid NcrId,
    Guid ProjectId,
    Guid PartId,
    Guid? TestRunId,
    string Title,
    string Description,
    NcrStatus Status,
    string RaisedBy,
    DateTimeOffset RaisedAt,
    Guid? SourceMeasurementId,
    NcrDispositionKind? Disposition,
    string? DispositionBy,
    DateTimeOffset? DispositionAt,
    string? DispositionJustification,
    Guid? ClosedByMeasurementId,
    long Version)
{
    public static NcrRecord Raise(
        Guid ncrId,
        Guid partId,
        Guid? testRunId,
        Guid? sourceMeasurementId,
        string title,
        string description,
        ActorContext actor,
        DateTimeOffset now)
    {
        Guard.Against(string.IsNullOrWhiteSpace(title), "NCR_TITLE_REQUIRED", "A nonconformity title is required.");
        Guard.Against(string.IsNullOrWhiteSpace(description), "NCR_DESCRIPTION_REQUIRED", "A nonconformity description is required.");
        return new NcrRecord(
            ncrId,
            actor.ProjectId,
            partId,
            testRunId,
            title,
            description,
            NcrStatus.Open,
            actor.ActorId,
            now,
            sourceMeasurementId,
            null,
            null,
            null,
            null,
            null,
            1);
    }

    /// <summary>
    /// Records the controlled decision.
    /// <para>
    /// The decision is immutable once made: CH1-SWA-API-0001 and the P03 catalogue
    /// both require an immutable decision, so a second disposition is refused rather
    /// than overwriting the first. Correcting a wrong decision is a new controlled
    /// record, not an edit.
    /// </para>
    /// <para>
    /// Segregation follows the same principle as release: the person who performed
    /// the operation on the part cannot decide the disposition of their own work.
    /// </para>
    /// </summary>
    public NcrRecord Dispose(
        NcrDispositionKind disposition,
        string justification,
        PartRecord part,
        ActorContext inspector,
        DateTimeOffset now)
    {
        Guard.Against(Status != NcrStatus.Open, "NCR_NOT_OPEN", "This nonconformity has already been dispositioned.");
        Guard.Against(inspector.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required to disposition a nonconformity.");
        Guard.Against(
            !inspector.HasRole(CinerionRoles.Inspector),
            "AUTH_INSPECTOR_REQUIRED",
            "Inspector authority is required to disposition a nonconformity.");
        Guard.Against(
            inspector.AuthenticationStrength < AuthenticationStrength.StepUpPhishingResistant,
            "AUTH_STEP_UP_REQUIRED",
            "Dispositioning a nonconformity requires recent phishing-resistant step-up.");
        Guard.Against(ProjectId != inspector.ProjectId, "AUTH_PROJECT_SCOPE", "Inspector is outside the nonconformity project scope.");
        Guard.Against(PartId != part.PartId, "NCR_PART_MISMATCH", "The nonconformity belongs to another part.");
        Guard.Against(
            StringComparer.Ordinal.Equals(inspector.ActorId, part.OperatorId),
            "SEGREGATION_OF_DUTIES",
            "The operation performer cannot decide the disposition of their own work.");
        Guard.Against(
            string.IsNullOrWhiteSpace(justification),
            "NCR_JUSTIFICATION_REQUIRED",
            "A disposition must record why the decision was made.");

        // Only a closing disposition asserts resolution, and only it demands the
        // passing retest evidence. Rework, use-as-is and scrap are decisions about a
        // part that remains nonconforming, so the part stays on hold.
        Guid? closedBy = null;
        if (disposition == NcrDispositionKind.Close)
        {
            var retest = part.Measurements.Count > 0 ? part.Measurements[^1] : null;
            Guard.Against(
                retest is null || !retest.Mandatory || retest.Result != MeasurementResult.Pass,
                "RETEST_NOT_PASSING",
                "Closing a nonconformity requires a passing mandatory retest.");
            Guard.Against(
                retest!.SupersedesMeasurementId is null,
                "RETEST_SOURCE_NOT_FOUND",
                "The passing retest is not linked to the failed measurement it supersedes.");
            closedBy = retest.MeasurementId;
        }

        return this with
        {
            Status = disposition == NcrDispositionKind.Close ? NcrStatus.Closed : NcrStatus.Dispositioned,
            Disposition = disposition,
            DispositionBy = inspector.ActorId,
            DispositionAt = now,
            DispositionJustification = justification,
            ClosedByMeasurementId = closedBy,
            Version = Version + 1,
        };
    }
}
