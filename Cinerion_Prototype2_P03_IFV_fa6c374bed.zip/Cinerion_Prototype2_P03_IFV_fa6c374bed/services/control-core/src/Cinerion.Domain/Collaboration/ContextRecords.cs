// Threads, messages and receipts attached to controlled objects.

using System.Security.Cryptography;
using System.Text;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Collaboration;

/// <summary>
/// The controlled objects a conversation may be attached to.
/// <para>
/// This is exactly the list in CH1-COL-FR-0001. It is closed on purpose: a thread that
/// could name an arbitrary object type would let a conversation exist against something
/// no authorisation rule knows how to scope.
/// </para>
/// </summary>
/// <requirements>CH1-COL-FR-0001</requirements>
public enum ContextObjectType
{
    Project,
    Cell,
    Asset,
    Device,
    Part,
    WorkOrder,
    Alarm,
    Ncr,
    Experiment,
}

/// <summary>
/// Message urgency.
/// <para>
/// Deliberately worded, not numbered. Alarm priority is 1-5, and CH1-UXD-DSG-0001
/// requires messages and alarms to stay distinguishable so nobody reads one as the
/// other. A message that said "priority 1" would invite exactly that mistake.
/// </para>
/// </summary>
/// <requirements>CH1-UXD-DSG-0001, CH1-COL-FR-0002</requirements>
public enum MessagePriority
{
    Routine,
    Elevated,
    Urgent,
}

/// <summary>
/// How far a message has got towards its audience.
/// <para>
/// One value, because one value is all this checkpoint can honestly assert. A message
/// is stored and readable by everyone in the thread's access scope; nothing pushes it
/// anywhere. Per-recipient distribution and delivery receipts belong to CH1-COM-IF-0018
/// (ContextBridge to the event backbone), which is not enabled, and inventing a
/// "Delivered" state before that exists would claim something reached a person when
/// nothing had been sent.
/// </para>
/// </summary>
/// <requirements>CH1-COL-FR-0002</requirements>
public enum MessageDeliveryState
{
    Published,
}

/// <summary>
/// Who may take part in a thread.
/// <para>
/// Held as declared roles and named actors rather than a copied member list, so a
/// change of role takes effect immediately instead of leaving a stale participant.
/// Project scope is not part of this: row-level security already bounds every thread to
/// one project, and a scope that tried to widen past it would have no effect.
/// </para>
/// </summary>
/// <requirements>CH1-COL-FR-0002, CH1-VVT-TC-0107</requirements>
public sealed record ThreadAccessScope(IReadOnlyList<string> Roles, IReadOnlyList<string> ActorIds)
{
    public static ThreadAccessScope Create(IReadOnlyList<string>? roles, IReadOnlyList<string>? actorIds)
    {
        var declaredRoles = (roles ?? []).Distinct(StringComparer.Ordinal).ToArray();
        foreach (var role in declaredRoles)
        {
            // A misspelled role would silently produce a scope nobody can satisfy, and
            // the thread would look accessible while being unreachable.
            Guard.Against(
                !CinerionRoles.All.Contains(role, StringComparer.Ordinal),
                "CONTEXT_SCOPE_ROLE_UNKNOWN",
                $"'{role}' is not a controlled role.");
        }

        var declaredActors = (actorIds ?? []).Distinct(StringComparer.Ordinal).ToArray();
        Guard.Against(
            declaredRoles.Length == 0 && declaredActors.Length == 0,
            "CONTEXT_SCOPE_EMPTY",
            "A thread access scope must name at least one role or actor.");
        return new ThreadAccessScope(declaredRoles, declaredActors);
    }

    public bool Admits(ActorContext actor) =>
        ActorIds.Contains(actor.ActorId, StringComparer.Ordinal) ||
        Roles.Any(actor.HasRole);
}

/// <summary>
/// A conversation attached to one controlled object
/// (entities.json: ContextThread; table ch1.context_threads).
/// </summary>
/// <requirements>CH1-COL-FR-0001, CH1-COL-FR-0002</requirements>
public sealed record ContextThread(
    Guid ThreadId,
    Guid ProjectId,
    ContextObjectType ObjectType,
    string ObjectId,
    ThreadAccessScope AccessScope,
    string CreatedBy,
    DateTimeOffset CreatedAt)
{
    /// <summary>
    /// Namespace for thread identifiers. Fixed for the CH1 baseline, so the same object
    /// resolves to the same thread on every host and after every restart.
    /// </summary>
    private static readonly Guid Namespace = Guid.Parse("6f2b7e14-3f2a-4a1e-9b2a-c1d0f6a54e00");

    /// <summary>
    /// The thread identifier for a controlled object, derived rather than allocated.
    /// <para>
    /// ch1.context_threads carries UNIQUE (project_id, object_type, object_id): there is
    /// exactly one thread per object. The controlled API has no operation that creates a
    /// thread or hands out its identifier, so deriving it is what makes
    /// GET/POST /api/v1/context-threads/{threadId}/messages reachable without inventing
    /// an operation the P03 catalogue does not contain. Object pages return the derived
    /// value as an additive optional field, which is the compatibility rule
    /// CH1-SWA-API-0001 states.
    /// </para>
    /// <para>
    /// RFC 9562 version 8, from SHA-256 over the namespace and the canonical object
    /// key. Version 5 would mandate SHA-1, which this codebase does not use.
    /// </para>
    /// </summary>
    public static Guid DeriveId(Guid projectId, ContextObjectType objectType, string objectId)
    {
        var key = $"{projectId:D}|{objectType}|{objectId}";
        Span<byte> seed = stackalloc byte[16 + Encoding.UTF8.GetByteCount(key)];
        Namespace.TryWriteBytes(seed[..16], bigEndian: true, out _);
        Encoding.UTF8.GetBytes(key, seed[16..]);

        Span<byte> hash = stackalloc byte[32];
        SHA256.HashData(seed, hash);
        var bytes = hash[..16].ToArray();
        bytes[6] = (byte)((bytes[6] & 0x0F) | 0x80); // version 8
        bytes[8] = (byte)((bytes[8] & 0x3F) | 0x80); // RFC 9562 variant
        return new Guid(bytes, bigEndian: true);
    }

    public static ContextThread Open(
        Guid projectId,
        ContextObjectType objectType,
        string objectId,
        ThreadAccessScope accessScope,
        ActorContext author,
        DateTimeOffset now)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(objectId),
            "CONTEXT_OBJECT_REQUIRED",
            "A contextual thread must name the controlled object it belongs to.");
        return new ContextThread(
            DeriveId(projectId, objectType, objectId),
            projectId,
            objectType,
            objectId.Trim(),
            accessScope,
            author.ActorId,
            now);
    }

    /// <summary>
    /// Whether this actor may read or post. An actor outside the scope is told the
    /// thread does not exist, so scope cannot be probed.
    /// </summary>
    public bool Admits(ActorContext actor) => actor.ProjectId == ProjectId && AccessScope.Admits(actor);
}

/// <summary>
/// One contextual message (entities.json: ContextMessage; table ch1.context_messages).
/// <para>
/// <see cref="ControlAuthority"/> exists to be false. ch1.context_messages declares it
/// as <c>NOT NULL DEFAULT false CHECK (control_authority = false)</c>, so the database
/// refuses to store a message that claims any, and the record says the same thing in
/// the domain. A message is a communication: it approves nothing, commands nothing and
/// confirms nothing.
/// </para>
/// </summary>
/// <requirements>CH1-COL-FR-0002, CH1-COL-FR-0003</requirements>
public sealed record ContextMessage(
    Guid MessageId,
    Guid ProjectId,
    Guid ThreadId,
    string AuthorId,
    ActorKind AuthorKind,
    MessagePriority Priority,
    string Body,
    DateTimeOffset CreatedAt,
    MessageDeliveryState DeliveryState,
    bool ControlAuthority = false)
{
    /// <summary>Mirrors CHECK (length(body) BETWEEN 1 AND 10000) on ch1.context_messages.</summary>
    public const int MaximumBodyLength = 10_000;

    public static ContextMessage Compose(
        Guid messageId,
        ContextThread thread,
        ActorContext author,
        MessagePriority priority,
        string body,
        DateTimeOffset now)
    {
        var trimmed = (body ?? string.Empty).Trim();
        Guard.Against(
            trimmed.Length == 0,
            "CONTEXT_MESSAGE_BODY_REQUIRED",
            "A contextual message must have a body.");
        Guard.Against(
            trimmed.Length > MaximumBodyLength,
            "CONTEXT_MESSAGE_BODY_TOO_LONG",
            $"A contextual message may be at most {MaximumBodyLength} characters.");
        return new ContextMessage(
            messageId,
            thread.ProjectId,
            thread.ThreadId,
            // The author is the authenticated actor. It is never taken from the request
            // body, which is what "immutable author" means for this operation, and there
            // is no path that rewrites it afterwards.
            author.ActorId,
            author.Kind,
            priority,
            trimmed,
            now,
            MessageDeliveryState.Published);
    }
}

/// <summary>
/// Evidence that a recipient saw a message
/// (entities.json: MessageAcknowledgement; table ch1.message_acknowledgements).
/// <para>
/// The word is <em>read</em>, and only read. CH1-UXD-DSG-0001 requires messages and
/// alarms to use different verbs so a user cannot mistake one for the other, and
/// CH1-COL-FR-0003, CH1-CYB-ACP-0001 and CH1-AUT-FDS-0001 all require that this
/// acknowledgement reaches no alarm, fault, interlock or command. There is no field
/// here that could carry such an effect and no method that could apply one: the type
/// has no reference to an alarm, a cell or a command transaction.
/// </para>
/// </summary>
/// <requirements>CH1-COL-FR-0003, CH1-CYB-ACP-0001, CH1-UXD-DSG-0001</requirements>
public sealed record MessageAcknowledgement(
    Guid MessageAckId,
    Guid ProjectId,
    Guid MessageId,
    string RecipientId,
    ActorKind RecipientKind,
    DateTimeOffset AcknowledgedAt,
    bool ControlAuthority = false)
{
    /// <summary>
    /// The only kind of acknowledgement this entity can express. Mirrors
    /// CHECK (acknowledgement_kind = 'Read') on ch1.message_acknowledgements.
    /// </summary>
    public const string Kind = "Read";

    public static MessageAcknowledgement Record(
        Guid messageAckId,
        ContextMessage message,
        ActorContext recipient,
        DateTimeOffset now)
    {
        Guard.Against(
            recipient.ProjectId != message.ProjectId,
            "AUTH_PROJECT_SCOPE",
            "Actor is outside the message project scope.");
        // Reading your own message evidences nothing. access.json gives this operation
        // to the assigned recipient, which the author is not.
        Guard.Against(
            StringComparer.Ordinal.Equals(recipient.ActorId, message.AuthorId),
            "CONTEXT_AUTHOR_CANNOT_ACKNOWLEDGE",
            "The author of a message cannot record receipt of it.");
        return new MessageAcknowledgement(
            messageAckId, message.ProjectId, message.MessageId, recipient.ActorId, recipient.Kind, now);
    }
}

/// <summary>
/// One keyset page of a thread, oldest first so a conversation reads in order.
/// </summary>
public sealed record ContextMessageQuery(
    Guid ProjectId,
    Guid ThreadId,
    ContextMessageCursor? After,
    int Limit)
{
    public const int MaximumRows = 200;
    public const int DefaultRows = 50;

    public static ContextMessageQuery Create(
        Guid projectId,
        Guid threadId,
        ContextMessageCursor? after,
        int? limit) =>
        new(projectId, threadId, after, Math.Clamp(limit ?? DefaultRows, 1, MaximumRows));
}

/// <summary>Opaque page position over (created_at, message_id).</summary>
public sealed record ContextMessageCursor(DateTimeOffset CreatedAt, Guid MessageId)
{
    public string Encode() =>
        Convert.ToBase64String(Encoding.UTF8.GetBytes($"{CreatedAt.UtcDateTime:O}|{MessageId}"));

    public static ContextMessageCursor? Decode(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        try
        {
            var parts = Encoding.UTF8.GetString(Convert.FromBase64String(value)).Split('|');
            if (parts.Length == 2 &&
                DateTimeOffset.TryParse(
                    parts[0],
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.RoundtripKind,
                    out var createdAt) &&
                Guid.TryParse(parts[1], out var messageId))
            {
                return new ContextMessageCursor(createdAt, messageId);
            }
        }
        catch (FormatException)
        {
            // Shared rejection below: a malformed cursor is a client fault with a stable
            // code, never a 500 and never a silent jump back to the first page.
        }

        throw new DomainRuleException("CONTEXT_CURSOR_INVALID", "The message page cursor is not valid.");
    }
}
