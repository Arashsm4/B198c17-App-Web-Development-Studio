// Time-based one-time passwords (RFC 6238). The six digits that change every thirty seconds.

using System.Globalization;
using System.Security.Cryptography;
using Cinerion.Domain.Common;

namespace Cinerion.Domain.Security;

/// <summary>
/// RFC 6238 time-based one-time passwords, over RFC 4226 HOTP.
/// <para>
/// Implemented on the base class library rather than taken from a package: the whole
/// algorithm is a counter, an HMAC and a truncation, and a dependency that generates
/// authentication codes is a dependency with authority over authentication. The repository
/// already treats added packages as a supply-chain decision (see DEPENDENCY_RISK.md).
/// </para>
/// <para>
/// TOTP is a shared symmetric secret. Anyone holding the seed can mint codes, so it is
/// never phishing resistant and never satisfies a phishing-resistant step-up. That is
/// enforced in the schema as well, by ck_credentials_totp_not_phishing_resistant.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-CYB-IAM-0001</requirements>
public static class Totp
{
    /// <summary>Bytes of entropy in a generated seed. RFC 4226 requires at least 128 bits.</summary>
    public const int SecretBytes = 20;

    public static byte[] GenerateSecret() => RandomNumberGenerator.GetBytes(SecretBytes);

    /// <summary>
    /// Computes the code for one time step. Exposed for verification and for tests that
    /// need to assert a known RFC 6238 vector; nothing else should call it directly.
    /// </summary>
    public static string Compute(
        ReadOnlySpan<byte> secret,
        DateTimeOffset at,
        TotpParameters parameters)
    {
        var step = at.ToUnixTimeSeconds() / (long)parameters.Period.TotalSeconds;
        return ComputeForStep(secret, step, parameters);
    }

    private static string ComputeForStep(
        ReadOnlySpan<byte> secret,
        long step,
        TotpParameters parameters)
    {
        Span<byte> counter = stackalloc byte[8];
        System.Buffers.Binary.BinaryPrimitives.WriteInt64BigEndian(counter, step);

        Span<byte> mac = stackalloc byte[64];
        var written = parameters.Algorithm switch
        {
            // CA5350 flags SHA-1 as a weak algorithm, and for a digest it is: SHA-1 is
            // not collision resistant. This is not a digest. HMAC-SHA1 is a keyed message
            // authentication code over an 8-byte counter, and the collision attacks that
            // retired SHA-1 do not apply to HMAC constructions - NIST SP 800-107 Rev 1
            // §5.3.4 still permits HMAC-SHA1, and RFC 6238 §1.2 makes it the default.
            //
            // Kept because every authenticator application interoperates with it, and
            // several ignore the algorithm parameter in an otpauth:// URI altogether: an
            // enrolment declaring SHA-256 to an application that assumes SHA-1 produces
            // codes that never match, with no diagnostic an operator could act on.
            // SHA-256 and SHA-512 are implemented and selectable for a deployment that
            // controls which authenticator is used.
            //
            // Scoped to this expression, with the reasoning above, rather than disabled
            // for the project - the same discipline the one CA1707 suppression follows.
#pragma warning disable CA5350
            "SHA1" => HMACSHA1.HashData(secret, counter, mac),
#pragma warning restore CA5350
            "SHA256" => HMACSHA256.HashData(secret, counter, mac),
            "SHA512" => HMACSHA512.HashData(secret, counter, mac),
            _ => throw new DomainRuleException(
                "TOTP_ALGORITHM_UNSUPPORTED",
                $"'{parameters.Algorithm}' is not an RFC 6238 algorithm."),
        };

        // RFC 4226 section 5.3 dynamic truncation.
        var offset = mac[written - 1] & 0x0F;
        var binary = ((mac[offset] & 0x7F) << 24)
            | ((mac[offset + 1] & 0xFF) << 16)
            | ((mac[offset + 2] & 0xFF) << 8)
            | (mac[offset + 3] & 0xFF);

        var modulus = (int)Math.Pow(10, parameters.Digits);
        // Invariant culture: a one-time password is a fixed sequence of ASCII digits,
        // and a locale that formatted numbers differently would produce a code the
        // authenticator could never match.
        return (binary % modulus).ToString(CultureInfo.InvariantCulture)
            .PadLeft(parameters.Digits, '0');
    }

    /// <summary>
    /// Verifies a presented code against the seed, allowing one step of clock drift
    /// either side.
    /// <para>
    /// The comparison is fixed-time and every candidate step is evaluated, so the number
    /// of HMACs computed does not depend on which step matched. Returning early on the
    /// first match would leak, through timing, how far the authenticator's clock is from
    /// the platform's.
    /// </para>
    /// </summary>
    public static bool Verify(
        ReadOnlySpan<byte> secret,
        string presentedCode,
        DateTimeOffset now,
        TotpParameters parameters)
    {
        if (string.IsNullOrWhiteSpace(presentedCode)) return false;
        var candidate = presentedCode.Trim();
        if (candidate.Length != parameters.Digits) return false;

        var currentStep = now.ToUnixTimeSeconds() / (long)parameters.Period.TotalSeconds;
        var matched = false;
        for (var drift = -TotpParameters.DriftSteps; drift <= TotpParameters.DriftSteps; drift++)
        {
            var expected = ComputeForStep(secret, currentStep + drift, parameters);
            matched |= CryptographicOperations.FixedTimeEquals(
                System.Text.Encoding.ASCII.GetBytes(expected),
                System.Text.Encoding.ASCII.GetBytes(candidate));
        }

        return matched;
    }

    /// <summary>
    /// The otpauth:// URI an authenticator app consumes, per the Key Uri Format.
    /// <para>
    /// This is the one and only disclosure of the seed. It is returned by the enrolment
    /// response and never stored, logged or served again — api_endpoints.json makes
    /// "secret shown once" the control on the operation.
    /// </para>
    /// </summary>
    public static string EnrolmentUri(
        ReadOnlySpan<byte> secret,
        string issuer,
        string accountName,
        TotpParameters parameters)
    {
        var label = Uri.EscapeDataString($"{issuer}:{accountName}");
        return $"otpauth://totp/{label}" +
            $"?secret={Base32.Encode(secret)}" +
            $"&issuer={Uri.EscapeDataString(issuer)}" +
            $"&algorithm={parameters.Algorithm}" +
            $"&digits={parameters.Digits}" +
            $"&period={(int)parameters.Period.TotalSeconds}";
    }
}

/// <summary>
/// RFC 4648 base32 without padding, which is the encoding authenticator applications
/// expect for a TOTP seed. Only the direction enrolment needs is implemented.
/// </summary>
public static class Base32
{
    private const string Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public static string Encode(ReadOnlySpan<byte> data)
    {
        var output = new System.Text.StringBuilder((data.Length * 8 + 4) / 5);
        int buffer = 0, bitsHeld = 0;
        foreach (var value in data)
        {
            buffer = (buffer << 8) | value;
            bitsHeld += 8;
            while (bitsHeld >= 5)
            {
                output.Append(Alphabet[(buffer >> (bitsHeld - 5)) & 31]);
                bitsHeld -= 5;
            }
        }

        if (bitsHeld > 0)
        {
            output.Append(Alphabet[(buffer << (5 - bitsHeld)) & 31]);
        }

        return output.ToString();
    }
}
