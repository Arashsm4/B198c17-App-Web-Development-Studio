// Step-up grants: purpose-bound, short-lived, used once.

using Cinerion.Domain.Common;

namespace Cinerion.Domain.Security;

/// <summary>
/// Purposes for which a step-up may be requested. Taken from the sensitive actions
/// of CH1-CYB-ACP-0001; a grant is bound to exactly one of them so that proving a
/// recent authentication for one sensitive action cannot authorise a different one.
/// </summary>
public static class StepUpPurpose
{
    public const string PartRelease = "PartRelease";
    public const string NcrDisposition = "NcrDisposition";
    public const string WorkOrderRelease = "WorkOrderRelease";
    public const string RoleAssignment = "RoleAssignment";
    public const string CredentialAdministration = "CredentialAdministration";
    public const string DeviceTrust = "DeviceTrust";
    public const string SecurityPolicy = "SecurityPolicy";
    public const string ConfigurationPromotion = "ConfigurationPromotion";
    public const string ResourceAllocation = "ResourceAllocation";
    public const string MaintenanceMode = "MaintenanceMode";
    public const string DocumentExport = "DocumentExport";
    public const string PublicationApproval = "PublicationApproval";
    public const string PhysicalCommandPreparation = "PhysicalCommandPreparation";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.Ordinal)
    {
        PartRelease,
        NcrDisposition,
        WorkOrderRelease,
        RoleAssignment,
        CredentialAdministration,
        DeviceTrust,
        SecurityPolicy,
        ConfigurationPromotion,
        ResourceAllocation,
        MaintenanceMode,
        DocumentExport,
        PublicationApproval,
        PhysicalCommandPreparation,
    };
}

/// <summary>
/// Evidence that a named human identity re-authenticated recently, for one stated
/// purpose, within a short window.
/// <para>
/// A grant never raises authority. <see cref="Strength"/> is copied from the
/// authentication that was actually proven, so a step-up cannot manufacture an
/// authenticator class the identity provider did not attest. What it adds is
/// recency, purpose binding and single use — the three properties an ordinary
/// long-lived session cannot supply.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-CYB-FR-0006</requirements>
public sealed record StepUpGrant(
    Guid GrantId,
    string ActorId,
    string SessionId,
    Guid ProjectId,
    string Purpose,
    AuthenticationStrength Strength,
    DateTimeOffset AuthenticatedAt,
    DateTimeOffset GrantedAt,
    DateTimeOffset ExpiresAt,
    DateTimeOffset? ConsumedAt = null,
    /// <summary>
    /// The nonce this grant binds. api_endpoints.json makes the control on
    /// <c>POST /api/v1/auth/step-up</c> "Purpose-bound <b>challenge</b>, short TTL and
    /// audit", and until this field existed there was no challenge: the grant was an
    /// identifier and nothing an authenticator could sign over.
    /// <para>
    /// That absence is why conflict 13 read as "the catalogue has no passkey registration
    /// operation". It does not need one. CH1-CYB-IAM-0001 makes enrolment a controlled
    /// ceremony — "Enrolment verifies the person, assigns roles separately, records
    /// credential serial/public key and issues recovery material through a controlled
    /// ceremony" — and the catalogue's ceremony is
    /// <c>POST /api/v1/credentials</c>, whose own control column already reads "Proof of
    /// possession". A registration challenge is what that proof is made against, and this
    /// is it: purpose-bound, single-use, five minutes, and audited on issue and on
    /// redemption, all of which the grant already was.
    /// </para>
    /// </summary>
    byte[]? Challenge = null)
{
    /// <summary>
    /// How stale the underlying authentication may be when a grant is requested.
    /// CH1-CYB-IAM-0001 requires high-risk actions to rest on recent authentication;
    /// without this bound a session authenticated days ago would still qualify.
    /// </summary>
    public static readonly TimeSpan MaximumAuthenticationAge = TimeSpan.FromMinutes(5);

    /// <summary>How long an issued grant remains usable.</summary>
    public static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(5);

    /// <summary>Minimum authenticator class that may obtain any grant at all.</summary>
    public const AuthenticationStrength MinimumStrength = AuthenticationStrength.Mfa;

    public static StepUpGrant Issue(ActorContext actor, string purpose, DateTimeOffset now)
    {
        Guard.Against(
            !StepUpPurpose.All.Contains(purpose ?? string.Empty),
            "STEP_UP_PURPOSE_UNKNOWN",
            "Step-up must name a controlled purpose.");
        Guard.Against(
            actor.Kind != ActorKind.Human,
            "AUTH_HUMAN_REQUIRED",
            "Step-up authenticates a person; service and device identities cannot step up.");
        Guard.Against(
            actor.AuthenticatedAt is null,
            "AUTH_AUTHENTICATION_TIME_UNKNOWN",
            "The session does not state when it was authenticated, so recency cannot be established.");
        Guard.Against(
            now - actor.AuthenticatedAt!.Value > MaximumAuthenticationAge,
            "AUTH_REAUTHENTICATION_REQUIRED",
            "The existing authentication is too old for a sensitive action; authenticate again.");
        Guard.Against(
            actor.AuthenticatedAt!.Value > now,
            "AUTH_AUTHENTICATION_TIME_INVALID",
            "The stated authentication time is in the future.");
        Guard.Against(
            actor.AuthenticationStrength < MinimumStrength,
            "AUTH_STRONGER_AUTHENTICATOR_REQUIRED",
            "A sensitive action requires at least multi-factor authentication.");

        return new StepUpGrant(
            Guid.NewGuid(),
            actor.ActorId,
            actor.SessionId,
            actor.ProjectId,
            purpose!,
            actor.AuthenticationStrength,
            actor.AuthenticatedAt.Value,
            now,
            now + Lifetime,
            Challenge: NewChallenge());
    }

    /// <summary>
    /// 32 bytes from the cryptographic generator. Not derived from the grant identifier:
    /// a nonce an attacker can compute from a value the platform hands out is not a nonce,
    /// and <see cref="Guid"/> makes no documented guarantee this could rest on.
    /// </summary>
    private static byte[] NewChallenge() => System.Security.Cryptography.RandomNumberGenerator.GetBytes(32);

    /// <summary>
    /// Issues a grant on the strength of a passkey assertion this platform has just
    /// verified itself.
    /// <para>
    /// This is the only path to <see cref="AuthenticationStrength.StepUpPhishingResistant"/>,
    /// and it does not take the client's word for anything. The caller must have already
    /// checked the assertion against the challenge, the origin, the relying-party
    /// identifier, the signature counter and the enrolled public key; the credential is
    /// passed in so this factory can confirm, once more and at the point of issue, that
    /// the authenticator class really is origin-bound and really belongs to this actor.
    /// It is the same rule device enrolment follows — the platform decides from the
    /// artefact, never from what the submitter claims about it.
    /// </para>
    /// <para>
    /// Recency needs no separate check here. The assertion was produced against a
    /// challenge issued moments ago, so the authentication time <em>is</em> now, which
    /// is stronger evidence than the <c>auth_time</c> of a session established earlier.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0005, CH1-CYB-IAM-0001</requirements>
    public static StepUpGrant IssueFromVerifiedPasskey(
        ActorContext actor,
        string purpose,
        CredentialRecord credential,
        DateTimeOffset verifiedAt)
    {
        Guard.Against(
            !StepUpPurpose.All.Contains(purpose ?? string.Empty),
            "STEP_UP_PURPOSE_UNKNOWN",
            "Step-up must name a controlled purpose.");
        Guard.Against(
            actor.Kind != ActorKind.Human,
            "AUTH_HUMAN_REQUIRED",
            "Step-up authenticates a person; service and device identities cannot step up.");
        Guard.Against(
            !string.Equals(credential.SubjectId, actor.ActorId, StringComparison.Ordinal),
            "AUTH_CREDENTIAL_NOT_HELD",
            "The credential that produced this assertion belongs to another identity.");
        Guard.Against(
            credential.ProjectId != actor.ProjectId,
            "AUTH_PROJECT_SCOPE",
            "The credential is outside the caller's project scope.");
        // A TOTP or smart-card credential is not origin-bound, so an assertion from one
        // can never raise a grant to phishing-resistant however it was verified.
        Guard.Against(
            !credential.PhishingResistant,
            "AUTH_CREDENTIAL_NOT_PHISHING_RESISTANT",
            "Only an origin-bound authenticator can establish phishing-resistant step-up.");

        return new StepUpGrant(
            Guid.NewGuid(),
            actor.ActorId,
            actor.SessionId,
            actor.ProjectId,
            purpose!,
            AuthenticationStrength.StepUpPhishingResistant,
            verifiedAt,
            verifiedAt,
            verifiedAt + Lifetime,
            Challenge: NewChallenge());
    }

    /// <summary>
    /// Checks a registration response against this grant's own challenge, and returns
    /// what the authenticator proved.
    /// <para>
    /// It lives on the grant rather than beside the endpoint so that the nonce is never
    /// copied out of it: a caller cannot pass a challenge alongside a grant and have the
    /// two disagree, because there is only one place the challenge is read from.
    /// </para>
    /// </summary>
    public WebAuthnEnrolment VerifyEnrolment(
        WebAuthnRegistration registration,
        string rpId,
        string origin)
    {
        Guard.Against(
            Challenge is null || Challenge.Length < 16,
            "STEP_UP_CHALLENGE_MISSING",
            "This step-up carries no challenge, so no proof of possession can be made against it.");

        return WebAuthnVerifier.VerifyRegistration(
            registration, Challenge!, rpId, origin, requireUserVerification: true);
    }

    /// <summary>
    /// Rejects a grant that is expired, already used, for another purpose, held by
    /// another identity or session, outside the project, or weaker than the action
    /// demands. Every check fails closed with a distinct code so audit can show which.
    /// </summary>
    public void EnsureUsableBy(
        ActorContext actor,
        string purpose,
        AuthenticationStrength required,
        DateTimeOffset now)
    {
        Guard.Against(ConsumedAt is not null, "STEP_UP_ALREADY_USED", "This step-up has already been used.");
        Guard.Against(now >= ExpiresAt, "STEP_UP_EXPIRED", "This step-up has expired.");
        Guard.Against(
            !StringComparer.Ordinal.Equals(Purpose, purpose),
            "STEP_UP_PURPOSE_MISMATCH",
            "This step-up was granted for a different purpose.");
        Guard.Against(
            !StringComparer.Ordinal.Equals(ActorId, actor.ActorId),
            "STEP_UP_ACTOR_MISMATCH",
            "This step-up belongs to another identity.");
        Guard.Against(
            !StringComparer.Ordinal.Equals(SessionId, actor.SessionId),
            "STEP_UP_SESSION_MISMATCH",
            "This step-up belongs to another session.");
        Guard.Against(ProjectId != actor.ProjectId, "AUTH_PROJECT_SCOPE", "This step-up is outside the project scope.");
        Guard.Against(
            Strength < required,
            "AUTH_STRONGER_AUTHENTICATOR_REQUIRED",
            "This action requires a stronger authenticator than the step-up proved.");
    }

    /// <summary>
    /// Marks the grant used. Single use keeps one re-authentication from silently
    /// authorising a batch of sensitive actions.
    /// </summary>
    public StepUpGrant Consume(DateTimeOffset now)
    {
        Guard.Against(ConsumedAt is not null, "STEP_UP_ALREADY_USED", "This step-up has already been used.");
        return this with { ConsumedAt = now };
    }
}
