// Who is acting: what kind of actor, which roles, what scope and how strongly they proved it.

namespace Cinerion.Domain.Security;

public enum ActorKind
{
    Human,
    Service,
    Device,
    System,
}

public enum AuthenticationStrength
{
    SingleFactor = 1,
    Mfa = 2,
    StepUpPhishingResistant = 3,
    MutualTls = 4,
}

/// <summary>
/// Controlled role names from CH1-CYB-ACP-0001. Every value except
/// <see cref="DeviceController"/> is also declared as a realm role in
/// infrastructure/keycloak/cinerion-realm.json; the two lists must stay aligned so a
/// role granted in the identity provider is recognisable here. Declaring a role does
/// not grant authority: each endpoint and domain rule still evaluates project scope,
/// cell assignment, authentication strength and equipment state.
/// </summary>
public static class CinerionRoles
{
    public const string Viewer = "Viewer";
    public const string Auditor = "Auditor";
    public const string Engineer = "Engineer";
    public const string AutomationEngineer = "AutomationEngineer";
    public const string Inspector = "Inspector";
    public const string LocalConfirmer = "LocalConfirmer";
    public const string MaintenanceEngineer = "MaintenanceEngineer";
    public const string OperationsCoordinator = "OperationsCoordinator";
    public const string ProjectManager = "ProjectManager";
    public const string ConfigurationManager = "ConfigurationManager";
    public const string RDEngineer = "RDEngineer";
    public const string DocumentController = "DocumentController";
    public const string CybersecurityAdministrator = "CybersecurityAdministrator";
    public const string SystemAdministrator = "SystemAdministrator";

    /// <summary>
    /// IR, the project owner. <c>stakeholders.json</c> declares it — "IR - Project Owner
    /// … P03 scope, owner authorisation, confidential/publication boundary and resources
    /// … A: P03 owner decisions and authorisation" — and <c>access.json</c> names IR in
    /// the authority column for approving a redacted publication and for exporting a
    /// confidential document.
    /// <para>
    /// Recorded as conflict 23, and resolved in favour of the controlled documents that
    /// declare it. Until now the owner's capacity was exercised by the Project Manager,
    /// which was a mapping decision nobody had recorded; the two-person property never
    /// rested on that mapping and does not rest on this one either.
    /// </para>
    /// </summary>
    public const string ProjectOwner = "ProjectOwner";

    /// <summary>
    /// Device accounts authenticate with mTLS and workload identity, not through the
    /// human realm, so this role is deliberately absent from cinerion-realm.json.
    /// </summary>
    public const string DeviceController = "DeviceController";

    /// <summary>
    /// Every controlled role name, for the few places that must validate a role the
    /// caller supplied rather than one the code names directly. A misspelled role in a
    /// stored access scope would silently produce a scope nobody can satisfy.
    /// </summary>
    public static readonly string[] All =
    [
        Viewer,
        Auditor,
        Engineer,
        AutomationEngineer,
        Inspector,
        LocalConfirmer,
        MaintenanceEngineer,
        OperationsCoordinator,
        ProjectManager,
        ConfigurationManager,
        RDEngineer,
        DocumentController,
        CybersecurityAdministrator,
        SystemAdministrator,
        ProjectOwner,
        DeviceController,
    ];
}

public sealed record ActorContext(
    string ActorId,
    ActorKind Kind,
    IReadOnlySet<string> Roles,
    AuthenticationStrength AuthenticationStrength,
    Guid ProjectId,
    IReadOnlySet<Guid> CellIds,
    string SessionId,
    /// <summary>
    /// When this session was actually authenticated, from the OIDC <c>auth_time</c>
    /// claim. Null when the identity provider does not state it, in which case
    /// recency cannot be established and step-up fails closed rather than assuming
    /// the session is fresh.
    /// </summary>
    DateTimeOffset? AuthenticatedAt = null)
{
    public bool HasRole(string role) => Roles.Contains(role);

    public bool CanAccessCell(Guid cellId) => CellIds.Contains(cellId);
}

