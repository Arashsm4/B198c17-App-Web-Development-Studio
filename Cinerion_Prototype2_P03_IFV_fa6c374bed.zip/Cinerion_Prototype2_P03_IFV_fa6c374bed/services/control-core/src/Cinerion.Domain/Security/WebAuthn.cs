// WebAuthn registration and assertion checks. Passkeys, verified the long way round.

using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text.Json;
using Cinerion.Domain.Common;

namespace Cinerion.Domain.Security;

/// <summary>
/// The parts of a WebAuthn assertion the platform must check.
/// </summary>
public sealed record WebAuthnAssertion(
    byte[] CredentialId,
    byte[] AuthenticatorData,
    byte[] ClientDataJson,
    byte[] Signature);

/// <summary>
/// The parts of a WebAuthn REGISTRATION the platform must check.
/// <para>
/// There is no field for a public key here, and that is the whole point. Until this
/// existed, <c>POST /api/v1/credentials</c> took a public key as a request field and
/// stored it, so its declared control — "Proof of possession, unique identity and
/// lifecycle record" (api_endpoints.json) — was implemented as far as the lifecycle
/// record and not at all as far as the proof. A Cybersecurity Administrator could enrol
/// any key at all, including one they held themselves, against any subject. The key now
/// comes out of the attestation the authenticator signed.
/// </para>
/// </summary>
public sealed record WebAuthnRegistration(
    byte[] AttestationObject,
    byte[] ClientDataJson);

/// <summary>
/// What an accepted registration established: the credential the authenticator minted,
/// its public key in the form this platform verifies with, and what the authenticator
/// proved about the person in front of it.
/// </summary>
public sealed record WebAuthnEnrolment(
    byte[] CredentialId,
    byte[] PublicKeySpki,
    Guid Aaguid,
    long SignCount,
    bool UserVerified,
    string Origin);

/// <summary>What an accepted assertion established.</summary>
public sealed record WebAuthnVerification(
    long SignCount,
    bool UserPresent,
    bool UserVerified,
    string Origin,
    string Type);

/// <summary>
/// Verification of a FIDO2/WebAuthn assertion, per the Web Authentication Level 2
/// verification procedure (section 7.2).
/// <para>
/// Written against the base class library rather than taken from a package. Every step
/// below is a security check, and the assertion path is short enough to be read and
/// audited in full — which is worth more here than the breadth a general FIDO library
/// would add. Attestation is deliberately <em>not</em> parsed: this platform enrols the
/// public key a registration presents and does not attempt to judge the manufacturer, in
/// the same way it enrols a device certificate without operating a certificate authority.
/// </para>
/// <para>
/// The check that matters most is the origin. A passkey is phishing resistant because the
/// authenticator signs over the origin the browser actually contacted, so an assertion
/// harvested by a look-alike site does not verify here. Relaxing that comparison would
/// remove the only property that distinguishes this class of credential.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0007, CH1-CYB-IAM-0001</requirements>
public static class WebAuthnVerifier
{
    private const byte UserPresentFlag = 0x01;
    private const byte UserVerifiedFlag = 0x04;
    /// <summary>AT: the authenticator data carries attested credential data.</summary>
    private const byte AttestedCredentialDataFlag = 0x40;

    /// <summary>
    /// Checks an assertion against the challenge it answers and the public key on
    /// record. Throws a controlled domain error naming the first check that failed;
    /// no partial acceptance is possible.
    /// </summary>
    public static WebAuthnVerification Verify(
        WebAuthnAssertion assertion,
        WebAuthnChallenge challenge,
        CredentialRecord credential,
        bool requireUserVerification)
    {
        Guard.Against(
            credential.PublicKeySpki is null || credential.PublicKeySpki.Length == 0,
            "PASSKEY_NO_PUBLIC_KEY",
            "The credential on record carries no public key, so no assertion can be verified against it.");

        // --- clientDataJSON (7.2 steps 11-14) -------------------------------------
        ClientData clientData;
        try
        {
            clientData = JsonSerializer.Deserialize<ClientData>(assertion.ClientDataJson)
                ?? throw new JsonException("empty");
        }
        catch (JsonException)
        {
            throw new DomainRuleException(
                "PASSKEY_CLIENT_DATA_INVALID",
                "The client data could not be read as JSON.");
        }

        Guard.Against(
            !string.Equals(clientData.Type, "webauthn.get", StringComparison.Ordinal),
            "PASSKEY_CLIENT_DATA_TYPE_INVALID",
            $"Expected a 'webauthn.get' assertion, not '{clientData.Type}'. A registration " +
            "response cannot be replayed as an authentication.");

        // The challenge is compared in fixed time: it is the anti-replay nonce, and a
        // length-or-prefix comparison would leak how much of a guess was correct.
        var presentedChallenge = FromBase64Url(clientData.Challenge, "PASSKEY_CHALLENGE_INVALID");
        Guard.Against(
            !CryptographicOperations.FixedTimeEquals(presentedChallenge, challenge.Challenge),
            "PASSKEY_CHALLENGE_MISMATCH",
            "The assertion answers a different challenge than the one issued.");

        Guard.Against(
            !string.Equals(clientData.Origin, challenge.Origin, StringComparison.Ordinal),
            "PASSKEY_ORIGIN_MISMATCH",
            $"The assertion was produced for origin '{clientData.Origin}', not '{challenge.Origin}'. " +
            "Origin binding is what makes this credential phishing resistant and is never relaxed.");

        // --- authenticatorData (7.2 steps 15-18) ----------------------------------
        Guard.Against(
            assertion.AuthenticatorData.Length < 37,
            "PASSKEY_AUTHENTICATOR_DATA_INVALID",
            "Authenticator data must be at least 37 bytes: an RP ID hash, flags and a counter.");

        var expectedRpIdHash = SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(challenge.RpId));
        Guard.Against(
            !CryptographicOperations.FixedTimeEquals(
                assertion.AuthenticatorData.AsSpan(0, 32), expectedRpIdHash),
            "PASSKEY_RP_ID_MISMATCH",
            "The assertion was produced for a different relying party.");

        var flags = assertion.AuthenticatorData[32];
        var userPresent = (flags & UserPresentFlag) != 0;
        var userVerified = (flags & UserVerifiedFlag) != 0;

        Guard.Against(
            !userPresent,
            "PASSKEY_USER_NOT_PRESENT",
            "The authenticator did not report user presence.");
        Guard.Against(
            requireUserVerification && !userVerified,
            "PASSKEY_USER_NOT_VERIFIED",
            "This action requires the authenticator to verify the user with a PIN or biometric, " +
            "not merely to report that it was present.");

        var signCount = BinaryPrimitives.ReadUInt32BigEndian(assertion.AuthenticatorData.AsSpan(33, 4));

        // --- signature (7.2 step 19) ----------------------------------------------
        // The authenticator signs authenticatorData || SHA-256(clientDataJSON).
        var clientDataHash = SHA256.HashData(assertion.ClientDataJson);
        var signedPayload = new byte[assertion.AuthenticatorData.Length + clientDataHash.Length];
        assertion.AuthenticatorData.CopyTo(signedPayload, 0);
        clientDataHash.CopyTo(signedPayload, assertion.AuthenticatorData.Length);

        Guard.Against(
            !VerifySignature(credential.PublicKeySpki!, signedPayload, assertion.Signature),
            "PASSKEY_SIGNATURE_INVALID",
            "The assertion signature did not verify against the enrolled public key.");

        return new WebAuthnVerification(
            signCount, userPresent, userVerified, clientData.Origin, clientData.Type);
    }

    /// <summary>
    /// Checks a registration response against the challenge it answers, per the Web
    /// Authentication Level 2 registration procedure (section 7.1).
    /// <para>
    /// Attestation is deliberately not judged: this platform enrols the public key a
    /// registration presents and does not attempt to rule on the manufacturer, in the
    /// same way it enrols a device certificate without operating a certificate authority.
    /// What it does insist on is that the authenticator SIGNED OVER the challenge and the
    /// origin, that a person was present and verified, and that the key comes out of the
    /// attested credential data rather than out of the request body.
    /// </para>
    /// <para>
    /// The origin check is the one that matters, for the same reason it matters on the
    /// assertion path: a registration harvested by a look-alike site does not verify here.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-CYB-IAM-0001</requirements>
    public static WebAuthnEnrolment VerifyRegistration(
        WebAuthnRegistration registration,
        byte[] expectedChallenge,
        string rpId,
        string origin,
        bool requireUserVerification)
    {
        ArgumentNullException.ThrowIfNull(registration);
        ArgumentNullException.ThrowIfNull(expectedChallenge);

        // --- clientDataJSON (7.1 steps 5-9) ---------------------------------------
        ClientData clientData;
        try
        {
            clientData = JsonSerializer.Deserialize<ClientData>(registration.ClientDataJson)
                ?? throw new JsonException("empty");
        }
        catch (JsonException)
        {
            throw new DomainRuleException(
                "PASSKEY_CLIENT_DATA_INVALID",
                "The client data could not be read as JSON.");
        }

        Guard.Against(
            !string.Equals(clientData.Type, "webauthn.create", StringComparison.Ordinal),
            "PASSKEY_CLIENT_DATA_TYPE_INVALID",
            $"Expected a 'webauthn.create' registration, not '{clientData.Type}'. An " +
            "authentication assertion cannot be replayed as an enrolment.");

        var presentedChallenge = FromBase64Url(clientData.Challenge, "PASSKEY_CHALLENGE_INVALID");
        Guard.Against(
            !CryptographicOperations.FixedTimeEquals(presentedChallenge, expectedChallenge),
            "PASSKEY_CHALLENGE_MISMATCH",
            "The registration answers a different challenge than the one issued.");

        Guard.Against(
            !string.Equals(clientData.Origin, origin, StringComparison.Ordinal),
            "PASSKEY_ORIGIN_MISMATCH",
            $"The registration was produced for origin '{clientData.Origin}', not '{origin}'. " +
            "Origin binding is what makes this credential phishing resistant and is never relaxed.");

        // --- attestationObject -> authData (7.1 steps 12-16) ----------------------
        var authenticatorData = AttestedAuthenticatorData(registration.AttestationObject);

        Guard.Against(
            authenticatorData.Length < 37,
            "PASSKEY_AUTHENTICATOR_DATA_INVALID",
            "Authenticator data must be at least 37 bytes: an RP ID hash, flags and a counter.");

        var expectedRpIdHash = SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(rpId));
        Guard.Against(
            !CryptographicOperations.FixedTimeEquals(
                authenticatorData.AsSpan(0, 32), expectedRpIdHash),
            "PASSKEY_RP_ID_MISMATCH",
            "The registration was produced for a different relying party.");

        var flags = authenticatorData[32];
        Guard.Against(
            (flags & UserPresentFlag) == 0,
            "PASSKEY_USER_NOT_PRESENT",
            "The authenticator did not report user presence.");
        Guard.Against(
            requireUserVerification && (flags & UserVerifiedFlag) == 0,
            "PASSKEY_USER_NOT_VERIFIED",
            "Enrolment requires the authenticator to verify the user with a PIN or biometric, " +
            "not merely to report that it was present.");
        Guard.Against(
            (flags & AttestedCredentialDataFlag) == 0,
            "PASSKEY_ATTESTED_CREDENTIAL_DATA_MISSING",
            "The registration carries no attested credential data, so it presents no key to enrol.");

        var signCount = BinaryPrimitives.ReadUInt32BigEndian(authenticatorData.AsSpan(33, 4));

        // --- attested credential data ---------------------------------------------
        // 16 bytes AAGUID, 2 bytes credential id length, the credential id, then the
        // COSE public key. Every length is read from the buffer and bounds-checked
        // against it: a truncated registration must be refused, never read past.
        Guard.Against(
            authenticatorData.Length < 55,
            "PASSKEY_ATTESTED_CREDENTIAL_DATA_INVALID",
            "The attested credential data is truncated.");

        var aaguid = new Guid(authenticatorData.AsSpan(37, 16), bigEndian: true);
        var credentialIdLength = BinaryPrimitives.ReadUInt16BigEndian(authenticatorData.AsSpan(53, 2));
        Guard.Against(
            credentialIdLength == 0 || credentialIdLength > 1023,
            "PASSKEY_CREDENTIAL_ID_INVALID",
            "A credential identifier must be between 1 and 1023 bytes.");
        Guard.Against(
            authenticatorData.Length < 55 + credentialIdLength,
            "PASSKEY_ATTESTED_CREDENTIAL_DATA_INVALID",
            "The attested credential data is truncated.");

        var credentialId = authenticatorData.AsSpan(55, credentialIdLength).ToArray();
        var coseKey = authenticatorData.AsSpan(55 + credentialIdLength);
        Guard.Against(
            coseKey.Length == 0,
            "PASSKEY_COSE_KEY_MISSING",
            "The registration presents no public key.");

        // Refused here rather than stored as material no assertion could ever verify
        // against. CoseKeyToSpki throws a controlled code naming what it could not read.
        var spki = CoseKeyToSpki(coseKey);

        return new WebAuthnEnrolment(
            credentialId, spki, aaguid, signCount, (flags & UserVerifiedFlag) != 0, clientData.Origin);
    }

    /// <summary>
    /// Pulls <c>authData</c> out of an attestation object.
    /// <para>
    /// The object is a CBOR map of <c>fmt</c>, <c>attStmt</c> and <c>authData</c>. Only
    /// the last is read. Written against <see cref="CborCursor"/> rather than a CBOR
    /// package for the same reason the COSE reader below is: this is a security boundary
    /// short enough to read in full, and the shape it accepts is narrow enough to state.
    /// Anything outside that shape is refused rather than guessed at.
    /// </para>
    /// </summary>
    private static byte[] AttestedAuthenticatorData(byte[] attestationObject)
    {
        Guard.Against(
            attestationObject is null || attestationObject.Length == 0,
            "PASSKEY_ATTESTATION_MISSING",
            "A registration must present the attestation object the authenticator produced.");

        var cursor = new CborCursor(attestationObject!);
        var (majorType, entries) = cursor.ReadHead("PASSKEY_ATTESTATION_INVALID");
        if (majorType != 5)
        {
            throw new DomainRuleException(
                "PASSKEY_ATTESTATION_INVALID",
                "The attestation object is not the CBOR map a registration produces.");
        }

        for (var index = 0; index < (int)entries; index++)
        {
            var label = cursor.ReadTextString("PASSKEY_ATTESTATION_INVALID");
            if (string.Equals(label, "authData", StringComparison.Ordinal))
            {
                return cursor.ReadByteString("PASSKEY_ATTESTATION_INVALID");
            }

            cursor.Skip("PASSKEY_ATTESTATION_INVALID");
        }

        throw new DomainRuleException(
            "PASSKEY_ATTESTATION_INVALID",
            "The attestation object carries no authenticator data.");
    }

    /// <summary>
    /// Verifies against whichever key type the SubjectPublicKeyInfo carries. WebAuthn
    /// authenticators in practice sign with ES256 or RS256; both are accepted and
    /// anything else is refused rather than assumed.
    /// </summary>
    private static bool VerifySignature(byte[] spki, byte[] payload, byte[] signature)
    {
        try
        {
            using var ecdsa = ECDsa.Create();
            ecdsa.ImportSubjectPublicKeyInfo(spki, out _);
            // WebAuthn ES256 signatures are DER-encoded, not the raw r||s IEEE P1363 form.
            return ecdsa.VerifyData(payload, signature, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence);
        }
        catch (CryptographicException)
        {
            // Not an EC key, or not a signature this key could have produced.
        }

        try
        {
            using var rsa = RSA.Create();
            rsa.ImportSubjectPublicKeyInfo(spki, out _);
            return rsa.VerifyData(payload, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        }
        catch (CryptographicException)
        {
            return false;
        }
    }

    /// <summary>
    /// Reads a COSE_Key (RFC 8152) as SubjectPublicKeyInfo.
    /// <para>
    /// A WebAuthn registration presents the public key in COSE form, while the platform
    /// stores and verifies with SPKI. Only the two algorithms this verifier accepts are
    /// converted; an unrecognised key type is refused at enrolment rather than stored as
    /// something no assertion could ever verify against.
    /// </para>
    /// </summary>
    public static byte[] CoseKeyToSpki(ReadOnlySpan<byte> coseKey)
    {
        var map = CborMap.Parse(coseKey);
        // COSE label 1 is kty: 2 = EC2, 3 = RSA.
        var keyType = map.GetInteger(1, "PASSKEY_COSE_KEY_TYPE_MISSING");

        if (keyType == 2)
        {
            var curve = map.GetInteger(-1, "PASSKEY_COSE_CURVE_MISSING");
            Guard.Against(
                curve != 1,
                "PASSKEY_COSE_CURVE_UNSUPPORTED",
                "Only the NIST P-256 curve is accepted for an EC2 passkey.");
            var x = map.GetBytes(-2, "PASSKEY_COSE_X_MISSING");
            var y = map.GetBytes(-3, "PASSKEY_COSE_Y_MISSING");
            using var ecdsa = ECDsa.Create(new ECParameters
            {
                Curve = ECCurve.NamedCurves.nistP256,
                Q = new ECPoint { X = x, Y = y },
            });
            return ecdsa.ExportSubjectPublicKeyInfo();
        }

        if (keyType == 3)
        {
            var modulus = map.GetBytes(-1, "PASSKEY_COSE_MODULUS_MISSING");
            var exponent = map.GetBytes(-2, "PASSKEY_COSE_EXPONENT_MISSING");
            Guard.Against(
                modulus.Length * 8 < 2048,
                "PASSKEY_COSE_KEY_TOO_WEAK",
                "An RSA passkey must present a modulus of at least 2048 bits.");
            using var rsa = RSA.Create(new RSAParameters { Modulus = modulus, Exponent = exponent });
            return rsa.ExportSubjectPublicKeyInfo();
        }

        throw new DomainRuleException(
            "PASSKEY_COSE_KEY_TYPE_UNSUPPORTED",
            $"COSE key type {keyType} is not accepted. Enrol an ES256 or RS256 authenticator.");
    }

    public static byte[] FromBase64Url(string value, string errorCode)
    {
        try
        {
            return Base64Url.Decode(value);
        }
        catch (FormatException)
        {
            throw new DomainRuleException(errorCode, "A required value was not valid base64url.");
        }
    }

    private sealed record ClientData
    {
        [System.Text.Json.Serialization.JsonPropertyName("type")]
        public string Type { get; init; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("challenge")]
        public string Challenge { get; init; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("origin")]
        public string Origin { get; init; } = string.Empty;
    }
}

/// <summary>base64url without padding, as WebAuthn encodes every binary field.</summary>
public static class Base64Url
{
    public static string Encode(ReadOnlySpan<byte> data) =>
        Convert.ToBase64String(data).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    public static byte[] Decode(string value)
    {
        var padded = value.Replace('-', '+').Replace('_', '/');
        return Convert.FromBase64String(padded.PadRight(padded.Length + ((4 - (padded.Length % 4)) % 4), '='));
    }
}

/// <summary>
/// A minimal CBOR cursor: enough to walk an attestation object's outer map, read the one
/// entry that matters and step over the rest.
/// <para>
/// It refuses indefinite lengths, refuses to read past the end of the buffer, and bounds
/// how deep it will recurse while skipping — an attestation object is three entries deep
/// and a deliberately nested one is an attack, not a registration.
/// </para>
/// </summary>
internal sealed class CborCursor(byte[] data)
{
    private const int MaximumDepth = 8;
    private int offset;

    public (int MajorType, ulong Value) ReadHead(string errorCode)
    {
        Guard.Against(offset >= data.Length, errorCode, "The CBOR item ended unexpectedly.");
        var initial = data[offset++];
        var majorType = initial >> 5;
        var additional = initial & 0x1F;

        ulong value;
        switch (additional)
        {
            case < 24:
                value = (ulong)additional;
                break;
            case 24:
                Require(1, errorCode);
                value = data[offset++];
                break;
            case 25:
                Require(2, errorCode);
                value = BinaryPrimitives.ReadUInt16BigEndian(data.AsSpan(offset));
                offset += 2;
                break;
            case 26:
                Require(4, errorCode);
                value = BinaryPrimitives.ReadUInt32BigEndian(data.AsSpan(offset));
                offset += 4;
                break;
            case 27:
                Require(8, errorCode);
                value = BinaryPrimitives.ReadUInt64BigEndian(data.AsSpan(offset));
                offset += 8;
                break;
            default:
                throw new DomainRuleException(errorCode, "Indefinite-length CBOR is not accepted.");
        }

        return (majorType, value);
    }

    public string ReadTextString(string errorCode)
    {
        var (majorType, length) = ReadHead(errorCode);
        Guard.Against(majorType != 3, errorCode, "Expected a CBOR text string.");
        Require((int)length, errorCode);
        var text = System.Text.Encoding.UTF8.GetString(data, offset, (int)length);
        offset += (int)length;
        return text;
    }

    public byte[] ReadByteString(string errorCode)
    {
        var (majorType, length) = ReadHead(errorCode);
        Guard.Against(majorType != 2, errorCode, "Expected a CBOR byte string.");
        Require((int)length, errorCode);
        var bytes = data.AsSpan(offset, (int)length).ToArray();
        offset += (int)length;
        return bytes;
    }

    public void Skip(string errorCode, int depth = 0)
    {
        Guard.Against(depth > MaximumDepth, errorCode, "The CBOR item is nested more deeply than a registration is.");
        var (majorType, value) = ReadHead(errorCode);
        switch (majorType)
        {
            case 0 or 1 or 7:
                return;
            case 2 or 3:
                Require((int)value, errorCode);
                offset += (int)value;
                return;
            case 4:
                for (var index = 0; index < (int)value; index++) Skip(errorCode, depth + 1);
                return;
            case 5:
                for (var index = 0; index < (int)value; index++)
                {
                    Skip(errorCode, depth + 1);
                    Skip(errorCode, depth + 1);
                }

                return;
            case 6:
                Skip(errorCode, depth + 1);
                return;
            default:
                throw new DomainRuleException(errorCode, "An unsupported CBOR major type was encountered.");
        }
    }

    private void Require(int bytes, string errorCode) =>
        Guard.Against(
            bytes < 0 || offset + bytes > data.Length,
            errorCode,
            "The CBOR item claims more bytes than it carries.");
}

/// <summary>
/// Just enough CBOR to read a COSE_Key: a definite-length map of integer labels to
/// integers or byte strings. The full CBOR grammar is not implemented, and anything
/// outside this shape is refused rather than guessed at.
/// </summary>
internal sealed class CborMap
{
    private readonly Dictionary<long, object> entries = [];

    public static CborMap Parse(ReadOnlySpan<byte> data)
    {
        var map = new CborMap();
        var offset = 0;
        var (majorType, count) = ReadHead(data, ref offset);
        Guard.Against(majorType != 5, "PASSKEY_COSE_NOT_A_MAP", "The COSE key is not a CBOR map.");

        for (var index = 0; index < (int)count; index++)
        {
            var label = ReadInteger(data, ref offset);
            var (valueType, value) = ReadHead(data, ref offset);
            if (valueType is 0 or 1)
            {
                map.entries[label] = valueType == 0 ? (long)value : -1L - (long)value;
            }
            else if (valueType == 2)
            {
                map.entries[label] = data.Slice(offset, (int)value).ToArray();
                offset += (int)value;
            }
            else
            {
                throw new DomainRuleException(
                    "PASSKEY_COSE_VALUE_UNSUPPORTED",
                    "The COSE key contains a value this reader does not accept.");
            }
        }

        return map;
    }

    public long GetInteger(long label, string missingCode) =>
        entries.TryGetValue(label, out var value) && value is long number
            ? number
            : throw new DomainRuleException(missingCode, $"COSE label {label} is missing or not an integer.");

    public byte[] GetBytes(long label, string missingCode) =>
        entries.TryGetValue(label, out var value) && value is byte[] bytes
            ? bytes
            : throw new DomainRuleException(missingCode, $"COSE label {label} is missing or not a byte string.");

    private static long ReadInteger(ReadOnlySpan<byte> data, ref int offset)
    {
        var (majorType, value) = ReadHead(data, ref offset);
        return majorType switch
        {
            0 => (long)value,
            1 => -1L - (long)value,
            _ => throw new DomainRuleException(
                "PASSKEY_COSE_LABEL_INVALID", "A COSE map label was not an integer."),
        };
    }

    private static (int MajorType, ulong Value) ReadHead(ReadOnlySpan<byte> data, ref int offset)
    {
        Guard.Against(offset >= data.Length, "PASSKEY_COSE_TRUNCATED", "The COSE key ended unexpectedly.");
        var initial = data[offset++];
        var majorType = initial >> 5;
        var additional = initial & 0x1F;

        ulong value;
        switch (additional)
        {
            case < 24:
                value = (ulong)additional;
                break;
            case 24:
                value = data[offset++];
                break;
            case 25:
                value = BinaryPrimitives.ReadUInt16BigEndian(data[offset..]);
                offset += 2;
                break;
            case 26:
                value = BinaryPrimitives.ReadUInt32BigEndian(data[offset..]);
                offset += 4;
                break;
            case 27:
                value = BinaryPrimitives.ReadUInt64BigEndian(data[offset..]);
                offset += 8;
                break;
            default:
                throw new DomainRuleException(
                    "PASSKEY_COSE_INDEFINITE_LENGTH",
                    "Indefinite-length CBOR is not accepted in a COSE key.");
        }

        return (majorType, value);
    }
}
