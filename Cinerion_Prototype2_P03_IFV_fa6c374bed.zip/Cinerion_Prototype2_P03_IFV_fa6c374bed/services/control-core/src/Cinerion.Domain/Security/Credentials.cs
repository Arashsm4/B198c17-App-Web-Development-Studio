// Credential records: passkeys and TOTP, their states, and what counts as strong enough.

using Cinerion.Domain.Common;

namespace Cinerion.Domain.Security;

/// <summary>
/// Authenticator classes CH1-CYB-IAM-0001 recognises. The class fixes what the
/// authenticator can prove, which is why phishing resistance travels with it rather
/// than being decided per request.
/// </summary>
public enum CredentialKind
{
    /// <summary>FIDO2/WebAuthn platform authenticator. Origin-bound.</summary>
    Passkey,

    /// <summary>NFC-enabled FIDO security key. Same protocol, roaming.</summary>
    SecurityToken,

    /// <summary>DESFire-class card with challenge-response, for local presence.</summary>
    SmartCard,

    /// <summary>RFC 6238 time-based one-time password. Never phishing resistant.</summary>
    Totp,
}

public enum CredentialStatus
{
    Active,
    Suspended,
    Revoked,
    Expired,
}

/// <summary>
/// Whether the authenticator verified the person or only its own presence.
/// </summary>
public enum UserVerificationRequirement
{
    Required,
    Preferred,
    Discouraged,
}

/// <summary>
/// One enrolled authenticator (entities.json: Credential; table ch1.credentials).
/// <para>
/// The record holds authenticator <em>metadata</em>. For an asymmetric authenticator it
/// holds the public key and nothing else — CH1-CYB-IAM-0001 makes long-lived private
/// keys non-exportable, so a private key arriving here would mean that boundary had
/// already failed. The one secret it can hold is a TOTP seed, which is symmetric and
/// has nowhere else to live; it is sealed before it reaches the record and this type
/// never sees the plaintext.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-IAM-FR-0007, CH1-CYB-IAM-0001</requirements>
public sealed record CredentialRecord(
    Guid CredentialId,
    Guid ProjectId,
    string SubjectId,
    CredentialKind Kind,
    string Label,
    byte[]? PublicKeySpki,
    byte[]? WebAuthnCredentialId,
    Guid? Aaguid,
    long SignCount,
    string? RpId,
    byte[]? SealedSecret,
    byte[]? SealedSecretNonce,
    int? TotpDigits,
    int? TotpPeriodSeconds,
    string? TotpAlgorithm,
    string? SerialNumber,
    string? AttestationSha256,
    UserVerificationRequirement UserVerification,
    bool PhishingResistant,
    CredentialStatus Status,
    string EnrolledBy,
    DateTimeOffset EnrolledAt,
    DateTimeOffset? LastUsedAt,
    DateTimeOffset? ExpiresAt,
    DateTimeOffset? RevokedAt,
    string? RevokedBy,
    string? RevocationReason,
    long Version)
{
    /// <summary>
    /// Whether an authenticator of this class is origin-bound and therefore resistant
    /// to phishing. Mirrors ck_credentials_totp_not_phishing_resistant and
    /// ck_credentials_fido_is_phishing_resistant, so code and schema cannot disagree.
    /// </summary>
    public static bool IsPhishingResistant(CredentialKind kind) =>
        kind is CredentialKind.Passkey or CredentialKind.SecurityToken;

    public bool IsUsable(DateTimeOffset now) =>
        Status == CredentialStatus.Active && (ExpiresAt is null || ExpiresAt > now);

    /// <summary>
    /// Registers a FIDO2 authenticator from the public half of an attested key pair.
    /// </summary>
    public static CredentialRecord EnrolFido(
        Guid credentialId,
        Guid projectId,
        string subjectId,
        CredentialKind kind,
        string label,
        byte[] publicKeySpki,
        byte[] webAuthnCredentialId,
        Guid? aaguid,
        string rpId,
        UserVerificationRequirement userVerification,
        string enrolledBy,
        DateTimeOffset now,
        DateTimeOffset? expiresAt = null)
    {
        Guard.Against(
            kind is not (CredentialKind.Passkey or CredentialKind.SecurityToken),
            "CREDENTIAL_KIND_NOT_FIDO",
            "Only a passkey or security token is enrolled through the FIDO2 path.");
        Guard.Against(
            string.IsNullOrWhiteSpace(subjectId),
            "CREDENTIAL_SUBJECT_REQUIRED",
            "A credential must name the identity it belongs to.");
        Guard.Against(
            string.IsNullOrWhiteSpace(label),
            "CREDENTIAL_LABEL_REQUIRED",
            "A credential must carry a label so its holder can tell it from another.");
        Guard.Against(
            publicKeySpki.Length == 0,
            "CREDENTIAL_PUBLIC_KEY_REQUIRED",
            "A FIDO2 credential must present its public key.");
        Guard.Against(
            webAuthnCredentialId.Length is 0 or > 1023,
            "CREDENTIAL_HANDLE_INVALID",
            "A WebAuthn credential identifier must be between 1 and 1023 bytes.");
        // CH1-CYB-IAM-0001 requires user verification according to capability and risk,
        // and every action this credential class exists to authorise is sensitive.
        Guard.Against(
            userVerification == UserVerificationRequirement.Discouraged,
            "CREDENTIAL_USER_VERIFICATION_REQUIRED",
            "A credential used for sensitive actions must verify the user, not only its own presence.");
        Guard.Against(
            expiresAt is not null && expiresAt <= now,
            "CREDENTIAL_ALREADY_EXPIRED",
            "A credential cannot be enrolled already expired.");

        return new CredentialRecord(
            credentialId, projectId, subjectId.Trim(), kind, label.Trim(),
            publicKeySpki, webAuthnCredentialId, aaguid, 0, rpId,
            null, null, null, null, null,
            null, null,
            userVerification, IsPhishingResistant(kind), CredentialStatus.Active,
            enrolledBy, now, null, expiresAt, null, null, null, 1);
    }

    /// <summary>
    /// Registers a smart card from the public half of the key pair held in its secure
    /// element. CH1-CYB-IAM-0001 forbids a cloneable UID from standing as proof, so a
    /// serial number alone is never enough: the card must present a key.
    /// </summary>
    public static CredentialRecord EnrolSmartCard(
        Guid credentialId,
        Guid projectId,
        string subjectId,
        string label,
        byte[] publicKeySpki,
        string serialNumber,
        string? attestationSha256,
        UserVerificationRequirement userVerification,
        string enrolledBy,
        DateTimeOffset now,
        DateTimeOffset? expiresAt = null)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(serialNumber),
            "CREDENTIAL_SERIAL_REQUIRED",
            "A physical credential must carry the serial number printed on it.");
        Guard.Against(
            publicKeySpki.Length == 0,
            "CREDENTIAL_PUBLIC_KEY_REQUIRED",
            "A smart card must present the public key of the pair held in its secure element. " +
            "A UID alone is cloneable and is never accepted as proof of a person.");
        Guard.Against(
            userVerification == UserVerificationRequirement.Discouraged,
            "CREDENTIAL_USER_VERIFICATION_REQUIRED",
            "A physical credential used for local presence must require a PIN or biometric.");

        return new CredentialRecord(
            credentialId, projectId, subjectId.Trim(), CredentialKind.SmartCard, label.Trim(),
            publicKeySpki, null, null, 0, null,
            null, null, null, null, null,
            serialNumber.Trim(), attestationSha256,
            userVerification, false, CredentialStatus.Active,
            enrolledBy, now, null, expiresAt, null, null, null, 1);
    }

    /// <summary>
    /// Registers a TOTP enrolment. The seed arrives already sealed; this type is never
    /// given the plaintext, so no future change to it can leak one.
    /// </summary>
    public static CredentialRecord EnrolTotp(
        Guid credentialId,
        Guid projectId,
        string subjectId,
        string label,
        byte[] sealedSecret,
        byte[] sealedSecretNonce,
        TotpParameters parameters,
        string enrolledBy,
        DateTimeOffset now)
    {
        Guard.Against(
            sealedSecret.Length == 0 || sealedSecretNonce.Length == 0,
            "CREDENTIAL_SECRET_NOT_SEALED",
            "A TOTP seed must be sealed before it is recorded.");

        return new CredentialRecord(
            credentialId, projectId, subjectId.Trim(), CredentialKind.Totp, label.Trim(),
            null, null, null, 0, null,
            sealedSecret, sealedSecretNonce,
            parameters.Digits, (int)parameters.Period.TotalSeconds, parameters.Algorithm,
            null, null,
            // A one-time code proves knowledge of a shared secret, not user verification.
            UserVerificationRequirement.Preferred, false, CredentialStatus.Active,
            enrolledBy, now, null, null, null, null, null, 1);
    }

    /// <summary>
    /// Records a successful assertion. The signature counter must advance whenever the
    /// authenticator maintains one: WebAuthn 6.1.1 treats a counter that did not move as
    /// evidence that the credential has been cloned.
    /// </summary>
    public CredentialRecord ObserveAssertion(long presentedSignCount, DateTimeOffset now)
    {
        Guard.Against(
            presentedSignCount != 0 && presentedSignCount <= SignCount,
            "CREDENTIAL_SIGN_COUNT_NOT_ADVANCED",
            $"The authenticator presented signature counter {presentedSignCount}, which did not " +
            $"advance beyond the recorded {SignCount}. This is treated as a cloned credential.");

        return this with
        {
            SignCount = presentedSignCount == 0 ? SignCount : presentedSignCount,
            LastUsedAt = now,
            Version = Version + 1,
        };
    }

    /// <summary>
    /// Withdraws the credential. CH1-CYB-IAM-0001 makes lost-token response revoke
    /// first and issue a replacement afterwards, so this never restores or reissues:
    /// the record is kept, because a forgotten credential could be presented elsewhere
    /// unnoticed.
    /// </summary>
    public CredentialRecord Revoke(string revokedBy, string reason, DateTimeOffset now)
    {
        Guard.Against(
            Status == CredentialStatus.Revoked,
            "CREDENTIAL_ALREADY_REVOKED",
            "The credential has already been revoked.");
        Guard.Against(
            string.IsNullOrWhiteSpace(reason),
            "CREDENTIAL_REVOCATION_REASON_REQUIRED",
            "A revocation must state why, so the decision remains attributable.");
        Guard.Against(
            string.IsNullOrWhiteSpace(revokedBy),
            "CREDENTIAL_REVOCATION_AUTHOR_REQUIRED",
            "A revocation must name its author.");

        return this with
        {
            Status = CredentialStatus.Revoked,
            RevokedAt = now,
            RevokedBy = revokedBy,
            RevocationReason = reason.Trim(),
            Version = Version + 1,
        };
    }
}

/// <summary>
/// A short-lived, single-use WebAuthn challenge (table ch1.webauthn_challenges).
/// <para>
/// Bound to the relying-party identifier and origin it was issued for, so an assertion
/// produced against a different origin cannot be replayed here — which is the property
/// that makes a passkey phishing resistant in the first place.
/// </para>
/// </summary>
public sealed record WebAuthnChallenge(
    Guid ChallengeId,
    Guid ProjectId,
    string SubjectId,
    byte[] Challenge,
    string RpId,
    string Origin,
    string Purpose,
    DateTimeOffset IssuedAt,
    DateTimeOffset ExpiresAt,
    DateTimeOffset? ConsumedAt)
{
    /// <summary>
    /// How long a challenge remains redeemable. Long enough for a person to touch a
    /// key, short enough that a captured challenge is worthless by the time it is
    /// replayed. CH1-SWA-API-0001 makes a short TTL the control on this operation.
    /// </summary>
    public static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(2);

    public bool IsRedeemable(DateTimeOffset now) => ConsumedAt is null && now < ExpiresAt;
}

/// <summary>RFC 6238 parameters. Defaults follow the RFC's recommended profile.</summary>
public sealed record TotpParameters(int Digits, TimeSpan Period, string Algorithm)
{
    public static readonly TotpParameters Default = new(6, TimeSpan.FromSeconds(30), "SHA1");

    /// <summary>
    /// How many periods either side of now are accepted, to tolerate clock skew between
    /// the authenticator and the platform. One step each way is the RFC's guidance; a
    /// wider window multiplies the codes valid at any moment.
    /// </summary>
    public const int DriftSteps = 1;
}
