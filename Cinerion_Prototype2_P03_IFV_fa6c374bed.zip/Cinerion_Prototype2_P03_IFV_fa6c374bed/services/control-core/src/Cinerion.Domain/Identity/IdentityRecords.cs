// Records for users, sessions, role assignments and which roles can't share a desk.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Domain.Identity;

/// <summary>
/// A human identity as the identity provider holds it
/// (entities.json: User; classification Personal/Security).
/// <para>
/// There is no <c>ch1.users</c> table and there should not be one: FortressGate owns
/// identity, and duplicating it into the operational schema would create a second
/// system of record that could disagree with the first. This is a projection of what
/// the provider reports, not a stored record.
/// </para>
/// <para>
/// Every field here is either an identifier, a scope or a lifecycle state. No
/// credential, secret, password hash, token, TOTP seed or public key appears, which is
/// the "no secret fields" control on the read operation and the minimisation
/// CH1-CYB-IAM-0001 requires.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0008, CH1-CYB-IAM-0001</requirements>
public sealed record IdentityUser(
    string UserId,
    string Username,
    string? DisplayName,
    bool Enabled,
    Guid? ProjectId,
    IReadOnlyList<Guid> CellIds,
    IReadOnlyList<string> Roles,
    ActorKind ActorKind,
    DateTimeOffset? CreatedAt);

/// <summary>
/// One controlled change to the roles an identity holds
/// (entities.json: RoleAssignment; classification Security Sensitive, retention 7 years).
/// <para>
/// The register declares this entity and 0001 created no table for it, so until migration
/// 0012 a role change was evidenced only by the audit chain - which stores a payload
/// <i>hash</i> rather than the payload. Who held what, and when, was verifiable and not
/// readable.
/// </para>
/// <para>
/// Before and after are both carried, in full, rather than only the difference: a history
/// of deltas cannot answer "what did this person hold on that date" without replaying
/// every row from the beginning and trusting that none is missing.
/// </para>
/// <para>
/// This is not a second system of record for identity. Keycloak remains the authority on
/// who holds which role; this is CH1's own permanent record of the changes it made, which
/// is what a seven-year controlled retention has to mean. <see cref="Provider"/> names the
/// directory the change was applied to, so a row cannot be read as evidence about one it
/// never reached.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0006, CH1-TRC-FR-0002</requirements>
public sealed record RoleAssignmentRecord(
    Guid AssignmentId,
    Guid ProjectId,
    string SubjectUserId,
    string SubjectUsername,
    IReadOnlyList<string> PreviousRoles,
    IReadOnlyList<string> CurrentRoles,
    IReadOnlyList<string> GrantedRoles,
    IReadOnlyList<string> WithdrawnRoles,
    string AssignedBy,
    DateTimeOffset AssignedAt,
    string Provider,
    Guid CorrelationId,
    DateTimeOffset RetainUntil)
{
    /// <summary>
    /// The retention entities.json declares for this entity, carried on the row rather
    /// than left in a policy document. Migration 0012 CHECKs the relationship, so a row
    /// cannot be written with a retention that disagrees with the register.
    /// </summary>
    public static readonly TimeSpan Retention = TimeSpan.FromDays(365 * 7);

    public static RoleAssignmentRecord Record(
        Guid assignmentId,
        Guid projectId,
        IdentityUser subject,
        IReadOnlyList<string> previousRoles,
        IReadOnlyList<string> currentRoles,
        string assignedBy,
        string provider,
        Guid correlationId,
        DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(subject);
        ArgumentNullException.ThrowIfNull(previousRoles);
        ArgumentNullException.ThrowIfNull(currentRoles);

        var granted = currentRoles.Where(role => !previousRoles.Contains(role, StringComparer.Ordinal)).ToArray();
        var withdrawn = previousRoles.Where(role => !currentRoles.Contains(role, StringComparer.Ordinal)).ToArray();

        Guard.Against(
            granted.Length == 0 && withdrawn.Length == 0,
            "ROLE_ASSIGNMENT_NOT_A_CHANGE",
            "A role assignment record evidences a change. This request granted and withdrew nothing.");

        return new RoleAssignmentRecord(
            assignmentId, projectId, subject.UserId, subject.Username,
            previousRoles, currentRoles, granted, withdrawn,
            assignedBy, now, provider, correlationId,
            // Computed from the timestamp on the row, so the two can never drift apart.
            now.AddYears(7));
    }
}

/// <summary>
/// An active session, as much of it as is needed to decide whether to end it.
/// <para>
/// Deliberately without an IP address or user agent. CH1-CYB-IAM-0001 requires personal
/// data to be minimised, and neither is needed to answer "is this session mine, and
/// should it end".
/// </para>
/// </summary>
/// <requirements>CH1-CYB-IAM-0001</requirements>
public sealed record IdentitySession(
    string SessionId,
    string UserId,
    string Username,
    string ClientId,
    DateTimeOffset StartedAt,
    DateTimeOffset LastAccessedAt);

/// <summary>
/// Which controlled roles may be held together, and who may grant what.
/// <para>
/// Every rule below quotes a controlled document. The point of stating them here rather
/// than in an endpoint is that they are the "segregation check" the API control column
/// requires, and a rule expressed once can be tested once.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-ACP-0001, CH1-IAM-FR-0008</requirements>
public static class RoleSegregation
{
    /// <summary>
    /// Roles a System Administrator may not grant or withdraw.
    /// <para>
    /// access.json: "Manage users | System Administrator | Hardware-backed MFA |
    /// <em>No security-policy authority</em>". CH1-CYB-ACP-0001 says the same in words:
    /// "System Administrator manages general configuration but not root cybersecurity
    /// policy by default." Granting the Cybersecurity Administrator role would hand over
    /// exactly that authority, so an administrator who could do it would hold it in
    /// effect.
    /// </para>
    /// </summary>
    public static readonly IReadOnlySet<string> SecurityPolicyRoles =
        new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.CybersecurityAdministrator };

    /// <summary>
    /// Roles that may never be assigned to a human account at all.
    /// <para>
    /// CH1-IAM-FR-0008 requires separate human, service and device accounts, and
    /// DeviceController is deliberately absent from cinerion-realm.json because device
    /// accounts authenticate with mTLS and workload identity rather than through the
    /// human realm.
    /// </para>
    /// </summary>
    public static readonly IReadOnlySet<string> NonHumanRoles =
        new HashSet<string>(StringComparer.Ordinal) { CinerionRoles.DeviceController };

    /// <summary>
    /// Pairs of roles one person may not hold at once, each with the sentence that says
    /// why. Both come from the role boundaries in CH1-CYB-ACP-0001.
    /// </summary>
    public static readonly IReadOnlyList<(string First, string Second, string Reason)> IncompatiblePairs =
    [
        (CinerionRoles.SystemAdministrator, CinerionRoles.CybersecurityAdministrator,
            "A System Administrator manages general configuration but not root cybersecurity policy."),
        (CinerionRoles.CybersecurityAdministrator, CinerionRoles.Inspector,
            "A Cybersecurity Administrator manages credentials, certificates, trust and revocation but cannot release parts."),
    ];

    /// <summary>
    /// Checks a proposed role set against every rule, refusing with the reason rather
    /// than a bare rejection so an administrator can see which boundary they met.
    /// </summary>
    public static void EnsureAssignable(
        IdentityUser subject,
        IReadOnlyList<string> requestedRoles,
        ActorContext administrator)
    {
        Guard.Against(
            requestedRoles.Count == 0,
            "ROLE_SET_EMPTY",
            "A role assignment must name at least one role. Disable the account instead of removing every role.");

        foreach (var role in requestedRoles)
        {
            Guard.Against(
                !CinerionRoles.All.Contains(role, StringComparer.Ordinal),
                "ROLE_UNKNOWN",
                $"'{role}' is not a controlled role.");
            Guard.Against(
                NonHumanRoles.Contains(role),
                "ROLE_NOT_ASSIGNABLE_TO_HUMAN",
                $"'{role}' belongs to a device or service account and cannot be assigned to a person.");
        }

        // An administrator changing their own roles is the shortest path to escalation
        // there is, and it defeats every other rule here.
        Guard.Against(
            StringComparer.Ordinal.Equals(subject.Username, administrator.ActorId) ||
            StringComparer.Ordinal.Equals(subject.UserId, administrator.ActorId),
            "ROLE_SELF_ASSIGNMENT",
            "An administrator cannot change their own role assignments.");

        var granted = requestedRoles.Where(role => !subject.Roles.Contains(role, StringComparer.Ordinal));
        var withdrawn = subject.Roles.Where(role => !requestedRoles.Contains(role, StringComparer.Ordinal));
        foreach (var role in granted.Concat(withdrawn))
        {
            Guard.Against(
                SecurityPolicyRoles.Contains(role),
                "ROLE_SECURITY_POLICY_AUTHORITY",
                $"'{role}' carries security-policy authority, which user administration does not include. " +
                "A Cybersecurity Administrator holds that authority.");
        }

        foreach (var (first, second, reason) in IncompatiblePairs)
        {
            Guard.Against(
                requestedRoles.Contains(first, StringComparer.Ordinal) &&
                requestedRoles.Contains(second, StringComparer.Ordinal),
                "ROLE_SEGREGATION_CONFLICT",
                $"'{first}' and '{second}' cannot be held by one person. {reason}");
        }
    }
}

/// <summary>A bounded, cursor-paged user query.</summary>
public sealed record UserQuery(Guid ProjectId, string? Search, int Offset, int Limit)
{
    public const int MaximumRows = 200;
    public const int DefaultRows = 50;

    public static UserQuery Create(Guid projectId, string? search, string? cursor, int? limit) =>
        new(projectId, string.IsNullOrWhiteSpace(search) ? null : search.Trim(),
            UserCursor.Decode(cursor), Math.Clamp(limit ?? DefaultRows, 1, MaximumRows));
}

/// <summary>
/// Opaque page position.
/// <para>
/// An offset rather than a keyset, unusually for this codebase, because the identity
/// provider's user search paginates by offset and inventing a keyset on top of it would
/// claim a stability the underlying API does not provide. The directory is small and
/// changes rarely, so the drift an offset can suffer is bounded; the reason it is an
/// offset is stated rather than hidden.
/// </para>
/// </summary>
public static class UserCursor
{
    public static string Encode(int nextOffset) =>
        Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"offset:{nextOffset}"));

    public static int Decode(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return 0;
        }

        try
        {
            var decoded = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(value));
            if (decoded.StartsWith("offset:", StringComparison.Ordinal) &&
                int.TryParse(decoded[7..], System.Globalization.CultureInfo.InvariantCulture, out var offset) &&
                offset >= 0)
            {
                return offset;
            }
        }
        catch (FormatException)
        {
            // Shared rejection below: a malformed cursor is a client fault with a stable
            // code, never a silent jump back to the first page.
        }

        throw new DomainRuleException("USER_CURSOR_INVALID", "The user page cursor is not valid.");
    }
}
