// Device trust states and the rules for moving between them.

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Cinerion.Domain.Common;

namespace Cinerion.Domain.Assets;

/// <summary>Lifecycle states a device identity may hold.</summary>
public static class DeviceTrustState
{
    /// <summary>Known to the project but holding no certificate; publishes nothing.</summary>
    public const string Pending = "Pending";

    /// <summary>Enrolled with a verified certificate.</summary>
    public const string Trusted = "Trusted";

    /// <summary>Trust withdrawn. Terminal for this certificate.</summary>
    public const string Revoked = "Revoked";
}

/// <summary>One channel a device declares it can publish.</summary>
public sealed record DeviceChannel(string ChannelId, string Unit);

/// <summary>
/// What a device says it can do (table column ch1.devices.capability_manifest).
/// <para>
/// CH1-COM-FR-0001 requires a versioned common device capability model. Recorded at
/// enrolment so the platform's view of a device comes from what that device presented
/// under its own certificate, rather than from whatever a later message claims.
/// </para>
/// </summary>
/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0009</requirements>
public sealed record DeviceCapabilityManifest(
    string SchemaVersion,
    string DeviceType,
    string FirmwareVersion,
    string ConfigurationRevision,
    IReadOnlyList<DeviceChannel> TelemetryChannels,
    IReadOnlyList<string> SupportedCommands,
    string SecurityProfile)
{
    public bool Declares(string channelId, string unit) =>
        TelemetryChannels.Any(channel =>
            StringComparer.Ordinal.Equals(channel.ChannelId, channelId) &&
            StringComparer.Ordinal.Equals(channel.Unit, unit));

    public static DeviceCapabilityManifest Validate(DeviceCapabilityManifest manifest)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(manifest.SchemaVersion),
            "MANIFEST_VERSION_REQUIRED",
            "A capability manifest must state its schema version.");
        Guard.Against(
            manifest.TelemetryChannels.Count == 0 && manifest.SupportedCommands.Count == 0,
            "MANIFEST_EMPTY",
            "A capability manifest must declare at least one channel or command.");
        foreach (var channel in manifest.TelemetryChannels)
        {
            Guard.Against(
                string.IsNullOrWhiteSpace(channel.ChannelId) || string.IsNullOrWhiteSpace(channel.Unit),
                "MANIFEST_CHANNEL_INVALID",
                "Every declared channel needs an identifier and an engineering unit.");
        }

        return manifest;
    }
}

/// <summary>
/// The verified facts about a certificate a device presented at enrolment.
/// <para>
/// Every field is derived by this platform from the certificate bytes. Nothing here is
/// taken from the request: a client-asserted thumbprint or validity window would let a
/// device enrol under a fingerprint that is not its own, which is the same mistake the
/// calibration path made before CH1-QMS-FR-0006 was enforced from the stored record.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-FR-0002, CH1-CYB-FR-0003, CH1-IAM-FR-0006</requirements>
public sealed record CertificateProof(
    string Thumbprint,
    string Subject,
    string Issuer,
    string SerialNumber,
    string KeyAlgorithm,
    int KeySizeBits,
    DateTimeOffset NotBefore,
    DateTimeOffset NotAfter,
    bool SelfSigned);

/// <summary>
/// Inspects a presented device certificate.
/// <para>
/// This platform is a trust registry, not a certificate authority. The device generates
/// its own key pair inside its secure element and presents only the certificate;
/// CH1-CYB-CSRS-0001 requires long-lived private keys to be non-exportable in a TPM,
/// secure element or hardware token, so a private key arriving here would mean that
/// boundary had already been broken. It is refused loudly rather than used.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-FR-0002, CH1-CYB-FR-0003, CH1-IAM-FR-0006, CH1-IAM-FR-0008</requirements>
public static class DeviceCertificate
{
    /// <summary>
    /// Smallest RSA modulus accepted. CH1-CYB-FR-0002 requires current approved
    /// cryptography with algorithm agility; 2048 is below the margin a device certificate
    /// with a multi-year life should carry.
    /// </summary>
    public const int MinimumRsaKeySize = 3072;

    /// <summary>Smallest elliptic-curve key accepted.</summary>
    public const int MinimumEcdsaKeySize = 256;

    /// <summary>
    /// Longest device certificate lifetime accepted. CH1-CYB-IAM-0001 requires device
    /// certificates to be rotated before expiry; one that outlives the equipment cannot
    /// meaningfully be rotated.
    /// </summary>
    public static readonly TimeSpan MaximumLifetime = TimeSpan.FromDays(825);

    /// <summary>
    /// Parses and checks a presented certificate, returning only what this platform
    /// derived itself.
    /// </summary>
    public static CertificateProof Inspect(string presented, string deviceId, DateTimeOffset now)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(presented),
            "ENROLMENT_CERTIFICATE_REQUIRED",
            "Enrolment requires the device certificate.");

        // Checked before parsing, because the point is to refuse the material rather than
        // to handle it. A PKCS#12 bundle or a PEM key block means the device's private
        // key has left its hardware boundary, and this platform must never hold one.
        Guard.Against(
            presented.Contains("PRIVATE KEY", StringComparison.OrdinalIgnoreCase),
            "ENROLMENT_PRIVATE_KEY_SUBMITTED",
            "A private key was submitted. Device private keys are non-exportable and never leave the device; " +
            "present the certificate only, and treat the submitted key as compromised.");

        var certificate = Load(presented);
        try
        {
            Guard.Against(
                certificate.HasPrivateKey,
                "ENROLMENT_PRIVATE_KEY_SUBMITTED",
                "The presented material carries a private key. Present the certificate only.");

            var notBefore = new DateTimeOffset(certificate.NotBefore.ToUniversalTime(), TimeSpan.Zero);
            var notAfter = new DateTimeOffset(certificate.NotAfter.ToUniversalTime(), TimeSpan.Zero);
            Guard.Against(
                now < notBefore,
                "ENROLMENT_CERTIFICATE_NOT_YET_VALID",
                $"The certificate is not valid until {notBefore:u}.");
            Guard.Against(
                now >= notAfter,
                "ENROLMENT_CERTIFICATE_EXPIRED",
                $"The certificate expired at {notAfter:u}.");
            Guard.Against(
                notAfter - notBefore > MaximumLifetime,
                "ENROLMENT_CERTIFICATE_LIFETIME_TOO_LONG",
                $"A device certificate may be valid for at most {MaximumLifetime.TotalDays:0} days so that rotation stays possible.");

            var (algorithm, keySize) = KeyOf(certificate);
            Guard.Against(
                StringComparer.Ordinal.Equals(algorithm, "RSA") && keySize < MinimumRsaKeySize,
                "ENROLMENT_KEY_TOO_WEAK",
                $"An RSA device key must be at least {MinimumRsaKeySize} bits; this one is {keySize}.");
            Guard.Against(
                StringComparer.Ordinal.Equals(algorithm, "ECDSA") && keySize < MinimumEcdsaKeySize,
                "ENROLMENT_KEY_TOO_WEAK",
                $"An elliptic-curve device key must be at least {MinimumEcdsaKeySize} bits; this one is {keySize}.");
            Guard.Against(
                !StringComparer.Ordinal.Equals(algorithm, "RSA") && !StringComparer.Ordinal.Equals(algorithm, "ECDSA"),
                "ENROLMENT_KEY_ALGORITHM_NOT_APPROVED",
                $"'{algorithm}' is not an approved device key algorithm.");

            // The certificate must name the device it is being enrolled for. Without this
            // any certificate the administrator held could be attached to any device
            // identity, and the enrolment would evidence nothing about that device.
            Guard.Against(
                !Identifies(certificate, deviceId),
                "ENROLMENT_SUBJECT_MISMATCH",
                $"The certificate does not identify device '{deviceId}' in its subject or subject alternative names.");

            return new CertificateProof(
                // Computed here from the certificate bytes, never accepted from the caller.
                Convert.ToHexStringLower(certificate.GetCertHash(HashAlgorithmName.SHA256)),
                certificate.Subject,
                certificate.Issuer,
                certificate.SerialNumber,
                algorithm,
                keySize,
                notBefore,
                notAfter,
                StringComparer.Ordinal.Equals(certificate.Subject, certificate.Issuer));
        }
        finally
        {
            certificate.Dispose();
        }
    }

    private static X509Certificate2 Load(string presented)
    {
        try
        {
            var trimmed = presented.Trim();
            if (trimmed.StartsWith("-----BEGIN", StringComparison.Ordinal))
            {
                return X509Certificate2.CreateFromPem(trimmed);
            }

            // LoadCertificate, not the general constructor: it refuses PKCS#12, so a
            // bundle carrying a private key cannot be loaded here even by accident.
            return X509CertificateLoader.LoadCertificate(Convert.FromBase64String(trimmed));
        }
        catch (Exception error) when (error is CryptographicException or FormatException or ArgumentException)
        {
            throw new DomainRuleException(
                "ENROLMENT_CERTIFICATE_INVALID",
                "The presented certificate could not be read as PEM or base64 DER.");
        }
    }

    private static (string Algorithm, int KeySize) KeyOf(X509Certificate2 certificate)
    {
        using var rsa = certificate.GetRSAPublicKey();
        if (rsa is not null)
        {
            return ("RSA", rsa.KeySize);
        }

        using var ecdsa = certificate.GetECDsaPublicKey();
        return ecdsa is not null
            ? ("ECDSA", ecdsa.KeySize)
            : (certificate.PublicKey.Oid.FriendlyName ?? certificate.PublicKey.Oid.Value ?? "Unknown", 0);
    }

    /// <summary>
    /// Whether the certificate names this device, in its common name or a subject
    /// alternative DNS name. A URI SAN is not consulted: matching one would mean
    /// deciding how much of a URI has to match, and a common name or DNS name is what a
    /// device certificate carries.
    /// </summary>
    private static bool Identifies(X509Certificate2 certificate, string deviceId)
    {
        if (StringComparer.OrdinalIgnoreCase.Equals(
                certificate.GetNameInfo(X509NameType.SimpleName, forIssuer: false), deviceId))
        {
            return true;
        }

        foreach (var extension in certificate.Extensions)
        {
            if (extension is X509SubjectAlternativeNameExtension alternativeNames &&
                alternativeNames.EnumerateDnsNames()
                    .Any(name => StringComparer.OrdinalIgnoreCase.Equals(name, deviceId)))
            {
                return true;
            }
        }

        return false;
    }
}
