// Records for devices and calibration certificates.

using Cinerion.Domain.Common;

namespace Cinerion.Domain.Assets;

/// <summary>
/// Enrolled controller, gateway, instrument or service identity
/// (entities.json: Device; table ch1.devices).
/// </summary>
/// <requirements>CH1-COM-FR-0009, CH1-CYB-FR-0001</requirements>
public sealed record DeviceRecord(
    string DeviceId,
    Guid ProjectId,
    Guid? CellId,
    string DeviceType,
    string FirmwareVersion,
    string ConfigurationRevision,
    string? CertificateThumbprint,
    string TrustState,
    DateTimeOffset? LastSeenAt,
    DateTimeOffset? RevokedAt,
    long Version,
    DeviceCapabilityManifest? CapabilityManifest = null,
    string? RevocationReason = null,
    string? RevokedBy = null)
{
    /// <summary>A revoked device is never trusted, whatever its recorded trust state.</summary>
    public bool IsTrusted =>
        RevokedAt is null && StringComparer.Ordinal.Equals(TrustState, DeviceTrustState.Trusted);

    public bool IsRevoked =>
        RevokedAt is not null || StringComparer.Ordinal.Equals(TrustState, DeviceTrustState.Revoked);

    /// <summary>
    /// Records a verified certificate against this device.
    /// <para>
    /// The thumbprint comes from <see cref="CertificateProof"/>, which derived it from
    /// the certificate bytes. Re-enrolment is allowed and is how rotation happens, but a
    /// revoked device is not silently restored: CH1-CYB-IAM-0001 makes lost-token
    /// response revoke first and then issue a replacement, which is a new decision rather
    /// than a repeat of the old one.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0006, CH1-CYB-FR-0003</requirements>
    public DeviceRecord Enrol(
        CertificateProof proof,
        DeviceCapabilityManifest manifest,
        DateTimeOffset now)
    {
        Guard.Against(
            IsRevoked,
            "DEVICE_REVOKED",
            "This device's trust was revoked. Restoring it is a separate controlled decision, " +
            "not a re-enrolment of the same identity.");
        Guard.Against(
            StringComparer.Ordinal.Equals(CertificateThumbprint, proof.Thumbprint),
            "DEVICE_CERTIFICATE_UNCHANGED",
            "That certificate is already enrolled for this device.");

        return this with
        {
            CertificateThumbprint = proof.Thumbprint,
            TrustState = DeviceTrustState.Trusted,
            CapabilityManifest = DeviceCapabilityManifest.Validate(manifest),
            // The manifest is what the device declared under its own certificate, so the
            // device's own type, firmware and configuration revision come from it too.
            DeviceType = manifest.DeviceType,
            FirmwareVersion = manifest.FirmwareVersion,
            ConfigurationRevision = manifest.ConfigurationRevision,
            LastSeenAt = now,
            Version = Version + 1,
        };
    }

    /// <summary>
    /// Withdraws trust.
    /// <para>
    /// The certificate thumbprint is kept rather than cleared: CH1-CYB-IAM-0001 requires
    /// credentials to be suspended, revoked, replaced and expired <em>without deleting
    /// history</em>, and a forgotten thumbprint could be re-enrolled elsewhere without
    /// anyone noticing it had once been withdrawn.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0006, CH1-CYB-IAM-0001</requirements>
    public DeviceRecord Revoke(string reason, string revokedBy, DateTimeOffset now)
    {
        Guard.Against(IsRevoked, "DEVICE_ALREADY_REVOKED", "This device's trust has already been revoked.");
        Guard.Against(
            string.IsNullOrWhiteSpace(reason),
            "DEVICE_REVOCATION_REASON_REQUIRED",
            "A revocation reason is required.");
        Guard.Against(
            reason.Length > 1_000,
            "DEVICE_REVOCATION_REASON_TOO_LONG",
            "A revocation reason may be at most 1000 characters.");

        return this with
        {
            TrustState = DeviceTrustState.Revoked,
            RevokedAt = now,
            RevocationReason = reason.Trim(),
            RevokedBy = revokedBy,
            Version = Version + 1,
        };
    }
}

/// <summary>
/// Calibration status and certificate for a measuring instrument
/// (entities.json: CalibrationRecord; table ch1.calibration_records).
/// </summary>
/// <requirements>CH1-QMS-FR-0006</requirements>
public sealed record CalibrationRecord(
    Guid CalibrationId,
    Guid ProjectId,
    string InstrumentId,
    string CertificateNumber,
    DateTimeOffset CalibratedAt,
    DateTimeOffset ValidUntil,
    string Status)
{
    public static CalibrationRecord Create(
        Guid calibrationId,
        Guid projectId,
        string instrumentId,
        string certificateNumber,
        DateTimeOffset calibratedAt,
        DateTimeOffset validUntil,
        string status)
    {
        Guard.Against(calibrationId == Guid.Empty, "CALIBRATION_ID_REQUIRED", "A calibration identifier is required.");
        Guard.Against(string.IsNullOrWhiteSpace(instrumentId), "CALIBRATION_INSTRUMENT_REQUIRED", "An instrument identifier is required.");
        Guard.Against(string.IsNullOrWhiteSpace(certificateNumber), "CALIBRATION_CERTIFICATE_REQUIRED", "A certificate number is required.");
        // Mirrors CHECK (valid_until > calibrated_at) on ch1.calibration_records.
        Guard.Against(validUntil <= calibratedAt, "CALIBRATION_PERIOD_INVALID", "Calibration validity must end after it begins.");
        return new CalibrationRecord(calibrationId, projectId, instrumentId, certificateNumber, calibratedAt, validUntil, status);
    }

    /// <summary>
    /// Whether this calibration may support a controlled acceptance result at the
    /// given moment.
    /// <para>
    /// CH1-QMS-FR-0006 requires calibration-expired instruments to be blocked from
    /// controlled acceptance results. That determination belongs here, on the stored
    /// certificate, and not to whatever the submitting client asserts about itself.
    /// </para>
    /// </summary>
    public bool IsValidAt(DateTimeOffset now, string instrumentId) =>
        StringComparer.Ordinal.Equals(InstrumentId, instrumentId) &&
        StringComparer.Ordinal.Equals(Status, "Valid") &&
        now >= CalibratedAt &&
        now < ValidUntil;
}
