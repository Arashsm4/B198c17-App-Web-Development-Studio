// The starting records every environment needs: the project, its site, its cell.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Documents;
using Cinerion.Domain.Manufacturing;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Resources;

namespace Cinerion.Infrastructure.Seed;

public sealed record PrototypeSeedIds(
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    Guid WorkOrderId,
    Guid PartId,
    Guid ControllerBootId,
    Guid CalibrationRecordId,
    Guid RevisionId,
    Guid CoatingStationResourceId,
    Guid FilmStockResourceId,
    Guid ProjectInternalDocumentId,
    Guid ControlledDocumentId,
    Guid SecuritySensitiveDocumentId);

public static class PrototypeSeed
{
    public static readonly PrototypeSeedIds Ids = new(
        Guid.Parse("00000000-0000-4000-8000-000000000101"),
        Guid.Parse("00000000-0000-4000-8000-000000000102"),
        Guid.Parse("00000000-0000-4000-8000-000000000103"),
        Guid.Parse("00000000-0000-4000-8000-000000000104"),
        Guid.Parse("00000000-0000-4000-8000-000000000105"),
        Guid.Parse("00000000-0000-4000-8000-000000000106"),
        Guid.Parse("00000000-0000-4000-8000-000000000107"),
        Guid.Parse("00000000-0000-4000-8000-000000000108"),
        Guid.Parse("00000000-0000-4000-8000-000000000109"),
        Guid.Parse("00000000-0000-4000-8000-00000000010a"),
        Guid.Parse("00000000-0000-4000-8000-00000000010b"),
        Guid.Parse("00000000-0000-4000-8000-00000000010c"),
        Guid.Parse("00000000-0000-4000-8000-00000000010d"),
        Guid.Parse("00000000-0000-4000-8000-00000000010e"));

    public static async ValueTask ApplyAsync(ICinerionStore store, CancellationToken cancellationToken)
    {
        // Seed once. With a volatile store this runs on every start because the store
        // is always empty; with a persistent one the records already exist, and
        // re-running would overwrite operational state that has moved on since -
        // resetting a part from Hold back to InProcess, for instance, which would
        // discard a quality decision.
        var established = await store.FindProjectAsync(Ids.ProjectId, cancellationToken).ConfigureAwait(false);
        if (established is not null)
        {
            return;
        }

        // The governance records the read endpoints project. Seeded explicitly so that
        // GET /api/v1/projects returns a stored record rather than one synthesised
        // from the caller's own token claim.
        await store.SaveProjectAsync(
            new ProjectRecord(
                Ids.ProjectId,
                "CH1",
                "Cinerion",
                "P03/IFV",
                1,
                DateTimeOffset.UtcNow),
            cancellationToken).ConfigureAwait(false);
        await store.SaveSiteAsync(
            SiteRecord.Create(Ids.SiteId, Ids.ProjectId, "ReFab MicroStation", simulated: true),
            cancellationToken).ConfigureAwait(false);
        await store.SaveCellRegistrationAsync(
            CellRegistration.Create(Ids.CellId, Ids.ProjectId, Ids.SiteId, "ReFab Cell 01"),
            cancellationToken).ConfigureAwait(false);

        // The controlled document register CH1-DOC-FR-0001 requires. ch1.controlled_documents
        // has existed since 0001 with nothing in it and nothing reading it, so the
        // publication pipeline had no inputs to allowlist and its refusals could not be
        // told apart from an empty database.
        //
        // Three classifications, because the allowlist is the control: a redaction profile
        // that permits Project Internal must accept the first, and must refuse the third
        // whatever else is true of it. The checksums are of the descriptive text beside
        // them - the bytes themselves live in the vault that does not exist yet, which is
        // exactly why representation_uri names a place rather than carrying content.
        await SeedDocumentAsync(
            store, Ids.ProjectInternalDocumentId, "CH1-SYS-ARC-0001", "Project Internal",
            "Architecture overview, project internal", cancellationToken).ConfigureAwait(false);
        await SeedDocumentAsync(
            store, Ids.ControlledDocumentId, "CH1-QMS-PRO-0004", "Controlled",
            "Controlled inspection procedure", cancellationToken).ConfigureAwait(false);
        await SeedDocumentAsync(
            store, Ids.SecuritySensitiveDocumentId, "CH1-CYB-TMD-0001", "Security Sensitive",
            "Threat model, security sensitive", cancellationToken).ConfigureAwait(false);

        // The manufacturing records the seeded part depends on. The controlled schema
        // requires a part to reference a work order and a released product revision,
        // and a command to reference an asset, so these must exist for the seeded
        // scenario to be representable in PostgreSQL as well as in memory.
        await store.SaveAssetAsync(
            new AssetRecord(
                Ids.AssetId,
                Ids.ProjectId,
                Ids.CellId,
                "CH1-AST-TENSION-01",
                "Tension module",
                "FabricationModule",
                "CFG-REFAB-P01-R01",
                "InService",
                1),
            cancellationToken).ConfigureAwait(false);

        // Devices and calibration certificates. Measurements and local confirmations
        // both reference a device, and a measurement also references the calibration
        // certificate that makes its result admissible.
        await store.SaveDeviceAsync(
            new DeviceRecord(
                "CH1-DEV-CELL-0001",
                Ids.ProjectId,
                Ids.CellId,
                "Esp32CellController",
                "0.1.0-prototype.1",
                "CFG-REFAB-P01-R01",
                null,
                "Trusted",
                DateTimeOffset.UtcNow,
                null,
                1),
            cancellationToken).ConfigureAwait(false);
        await store.SaveDeviceAsync(
            new DeviceRecord(
                "CH1-INS-THK-0001",
                Ids.ProjectId,
                Ids.CellId,
                "Instrument",
                "2.4.1",
                "CFG-INS-THK-R02",
                null,
                "Trusted",
                DateTimeOffset.UtcNow,
                null,
                1),
            cancellationToken).ConfigureAwait(false);
        await store.SaveCalibrationAsync(
            CalibrationRecord.Create(
                Ids.CalibrationRecordId,
                Ids.ProjectId,
                "CH1-INS-THK-0001",
                "CERT-THK-2026-0041",
                DateTimeOffset.UtcNow.AddDays(-30),
                DateTimeOffset.UtcNow.AddDays(335),
                "Valid"),
            cancellationToken).ConfigureAwait(false);

        var revision = new ProductRevisionRecord(
            Ids.RevisionId,
            Ids.ProjectId,
            "REFAB-CASSETTE",
            "R01",
            RevisionLifecycleState.Released,
            [new BomLine("CH1-CMP-FILM-8MM", 1m, "ea")],
            [
                new RouteStep(10, "COAT", "Apply coating", false),
                new RouteStep(20, "VERIFY-COATING", "Verify coating thickness", true),
            ],
            CanonicalJson.Sha256Hex(new
            {
                Bom = new[] { new BomLine("CH1-CMP-FILM-8MM", 1m, "ea") },
                Route = new[]
                {
                    new RouteStep(10, "COAT", "Apply coating", false),
                    new RouteStep(20, "VERIFY-COATING", "Verify coating thickness", true),
                },
            }),
            DateTimeOffset.UtcNow,
            null,
            2);
        await store.SaveRevisionAsync(revision, cancellationToken).ConfigureAwait(false);

        await store.SaveWorkOrderAsync(
            new WorkOrderRecord(
                Ids.WorkOrderId,
                Ids.ProjectId,
                Ids.RevisionId,
                Ids.CellId,
                "WO-REFAB-00017",
                1,
                WorkOrderStatus.Released,
                "USR-PROJECT-MANAGER-01",
                DateTimeOffset.UtcNow,
                2),
            cancellationToken).ConfigureAwait(false);

        await store.SaveCellAsync(
            new CellSnapshot(
                Ids.ProjectId,
                Ids.SiteId,
                Ids.CellId,
                Ids.AssetId,
                "CH1-DEV-CELL-0001",
                Ids.ControllerBootId,
                CellOperatingState.Idle,
                "CFG-REFAB-P01-R01",
                Ids.WorkOrderId,
                Ids.PartId,
                true,
                true,
                true,
                true,
                true,
                false,
                false),
            // Simulated, never Live, and stamped now. The seed is standing in for a
            // controller here, which is exactly what the development store is for; on
            // PostgreSQL the interlocks above are not persisted at all, so this becomes a
            // stale simulated observation within seconds unless a real controller reports
            // through CH1-COM-IF-0003.
            new CellObservation(Freshness.Simulated, DataQuality.Good, DateTimeOffset.UtcNow),
            cancellationToken).ConfigureAwait(false);
        await store.SavePartAsync(
            PartRecord.Create(
                Ids.ProjectId,
                Ids.PartId,
                Ids.WorkOrderId,
                Ids.RevisionId,
                "CH1-PART-000017-04",
                "USR-OPERATOR-01"),
            cancellationToken).ConfigureAwait(false);

        // Reservable capacity. entities.json names ResourceAllocation but not the
        // resource itself, and the controlled API has no operation that creates one, so
        // resources arrive here exactly as sites, cells, assets and devices do. Two are
        // seeded deliberately: one indivisible station, where a second overlapping
        // reservation is a straight double-booking, and one measured stock, where the
        // conflict check has to add quantities rather than count bookings.
        await store.SaveResourceAsync(
            ResourceRecord.Create(
                Ids.CoatingStationResourceId,
                Ids.ProjectId,
                "Equipment",
                "ReFab coating station 01",
                1m,
                "station",
                ResourceAvailabilityState.Available),
            cancellationToken).ConfigureAwait(false);
        await store.SaveResourceAsync(
            ResourceRecord.Create(
                Ids.FilmStockResourceId,
                Ids.ProjectId,
                "Consumable",
                "8 mm film stock",
                250m,
                "m",
                ResourceAvailabilityState.Available),
            cancellationToken).ConfigureAwait(false);
    }
    /// <summary>
    /// One controlled document in the register. The checksum is of the descriptive text,
    /// so two documents can never share one - which matters, because a derivative whose
    /// checksum equals a source's is refused as having redacted nothing.
    /// </summary>
    private static ValueTask SeedDocumentAsync(
        ICinerionStore store,
        Guid documentId,
        string documentNumber,
        string classification,
        string description,
        CancellationToken cancellationToken) =>
        store.SaveControlledDocumentAsync(
            new ControlledDocumentRecord(
                documentId,
                Ids.ProjectId,
                documentNumber,
                "R01",
                "IFV",
                classification,
                Convert.ToHexStringLower(
                    System.Security.Cryptography.SHA256.HashData(
                        System.Text.Encoding.UTF8.GetBytes(description))),
                $"cinerion://documents/{documentId}",
                // No wrapped key. CH1-DOC-FR-0002's key-encryption boundary is the declared
                // future phase, and a seeded reference to a key nobody holds would be a
                // claim that the vault exists.
                null,
                DateTimeOffset.UtcNow),
            cancellationToken);
}
