// Optional demo data so every screen has something to show. Off by default, never in
// Production.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;
using Cinerion.Domain.Documents;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Research;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;

namespace Cinerion.Infrastructure.Seed;

/// <summary>
/// A demonstration dataset, so that every declared screen and every controlled read has
/// something behind it.
/// </summary>
/// <remarks>
/// <para>
/// <see cref="PrototypeSeed"/> establishes the governance records the read endpoints
/// project — one project, one site, one cell, one part. That is the minimum a running
/// service needs to be coherent, and it leaves most of the 22 declared screens showing
/// their empty state: no alarms, no telemetry, no test runs, no nonconformity, no
/// messages, no reservations, no experiments, no scan events, no reports. A reviewer
/// opening the portal cannot tell a screen that works and has nothing to show from a
/// screen that is broken.
/// </para>
/// <para>
/// <b>This is demonstration data and it says so in every record it writes.</b> It is off
/// unless <c>CINERION_DEMONSTRATION_DATA=true</c>, it refuses to run in the Production
/// profile — which P03 does not authorise at all — and:
/// </para>
/// <list type="bullet">
/// <item>every telemetry sample is <see cref="Freshness.Simulated"/>, never
/// <c>Live</c>. CH1-MON-FR-0003 requires those to stay distinguishable, and the gateway's
/// own contract says Control Core never states Live for a reading a simulator
/// produced;</item>
/// <item><b>no command reaches an executing or committed state.</b> The prepared
/// transaction below is exactly that — prepared — because a seeded execution would be
/// this service claiming a physical act that never happened, which is what
/// CH1-AUT-FDS-0001 and AGENTS.md forbid outright;</item>
/// <item>credentials carry no secret material. A seeded passkey has a public key and a
/// label and nothing that could authenticate anybody;</item>
/// <item>every measurement names a real seeded calibration certificate, because a result
/// with no calibration context is not evidence (CH1-QMS-FR-0002);</item>
/// <item>identifiers are drawn from one reserved block so a reader can tell demonstration
/// records from operational ones at a glance.</item>
/// </list>
/// <para>
/// The point is not to make the product look finished. It is that an empty screen and a
/// broken screen are indistinguishable, and a reviewer should never have to guess which
/// one they are looking at.
/// </para>
/// </remarks>
/// <requirements>CH1-UXD-DSG-0001, CH1-MON-FR-0003, CH1-QMS-FR-0002, CH1-COL-FR-0002</requirements>
public static class DemonstrationSeed
{
    /// <summary>Reserved identifier block, so demonstration records are recognisable.</summary>
    private static Guid Id(string suffix) => Guid.Parse($"00000000-0000-4000-8000-0000000d{suffix}");

    public static readonly Guid AlarmOutstandingId = Id("0001");
    public static readonly Guid AlarmAcknowledgedId = Id("0002");
    public static readonly Guid AlarmClearedId = Id("0003");
    public static readonly Guid TestRunPassedId = Id("0010");
    public static readonly Guid TestRunFailedId = Id("0011");
    public static readonly Guid NcrOpenId = Id("0020");
    public static readonly Guid NcrClosedId = Id("0021");
    public static readonly Guid ThreadId = Id("0030");
    public static readonly Guid MessageId = Id("0031");
    public static readonly Guid MessageAckId = Id("0032");
    public static readonly Guid AllocationId = Id("0040");
    public static readonly Guid ExperimentId = Id("0050");
    public static readonly Guid ExperimentRevisionId = Id("0051");
    public static readonly Guid CredentialPasskeyId = Id("0060");
    public static readonly Guid ReportId = Id("0070");
    public static readonly Guid ScanEventId = Id("0080");
    public static readonly Guid RoleAssignmentId = Id("0090");
    public static readonly Guid PackageId = Id("00a0");
    public static readonly Guid ApprovalIrId = Id("00a1");
    public static readonly Guid ApprovalDocId = Id("00a2");
    public static readonly Guid MeasurementPassId = Id("00b0");
    public static readonly Guid MeasurementFailId = Id("00b1");
    public static readonly Guid MeasurementRetestId = Id("00b2");

    private static Guid Project => PrototypeSeed.Ids.ProjectId;
    private static Guid Cell => PrototypeSeed.Ids.CellId;
    private static Guid Part => PrototypeSeed.Ids.PartId;

    /// <summary>
    /// Applies the dataset. Idempotent by the same rule as <see cref="PrototypeSeed"/>:
    /// if the first record it writes is already present the rest is skipped, because
    /// re-running would overwrite operational state that has moved on — an acknowledged
    /// alarm reset to outstanding, a closed nonconformity reopened.
    /// </summary>
    public static async ValueTask ApplyAsync(ICinerionStore store, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(store);

        // Applied SECTION BY SECTION, each skipped if its own first record is already there.
        //
        // This began as one guard on one record at the top, and that hid a crash loop: the
        // collaboration section threw on PostgreSQL (defect 67), the host died, the container
        // restarted, the guard found the alarm already present and returned, and the service
        // came up healthy with a third of its dataset. Moving the guard to the LAST record
        // fixed the masking and produced the opposite failure — a retry that re-ran sections
        // which had already succeeded and died on a duplicate key.
        //
        // Neither is a seed. A seed that can be interrupted has to be resumable, so each
        // section asks whether its own work is already done. Between them the two properties
        // are: nothing is written twice, and nothing is skipped because something after it
        // failed.
        //
        // Checked against the LAST record written, not the first.
        //
        // This checked the first — an alarm — and that hid a crash loop. The collaboration
        // section threw on PostgreSQL (defect 67), the host died, the container restarted,
        // the check found the alarm already present and returned, and the service then came
        // up healthy with a third of its dataset. The gate reported alarms and telemetry
        // populated and experiments, scan events and audit empty, which reads like three
        // broken endpoints rather than one broken write.
        //
        // A sentinel written last cannot be present unless everything before it succeeded, so
        // a partial application is retried on the next start instead of being mistaken for a
        // complete one.
        var complete = await store
            .FindPublicationPackageAsync(PackageId, cancellationToken)
            .ConfigureAwait(false);
        if (complete is not null)
        {
            return;
        }

        var now = DateTimeOffset.UtcNow;

        if (await store.FindAlarmAsync(AlarmOutstandingId, cancellationToken).ConfigureAwait(false) is null)
        {
            await SeedMonitoringAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        if (await store.FindNcrAsync(NcrOpenId, cancellationToken).ConfigureAwait(false) is null)
        {
            await SeedQualityAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        if (await store.FindContextThreadAsync(ThreadId, cancellationToken).ConfigureAwait(false) is null)
        {
            await SeedCollaborationAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        var allocations = await store.ListAllocationsAsync(
            Project, [PrototypeSeed.Ids.CoatingStationResourceId],
            now.AddDays(-2), now.AddDays(2), cancellationToken).ConfigureAwait(false);
        if (allocations.Count == 0)
        {
            await SeedResourcesAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        if (await store.FindExperimentAsync(ExperimentId, cancellationToken).ConfigureAwait(false) is null)
        {
            await SeedResearchAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        var scans = await store.ListScanEventsAsync(Project, 5, cancellationToken).ConfigureAwait(false);
        if (scans.Count == 0)
        {
            await SeedEvidenceAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        if (await store.FindCredentialAsync(CredentialPasskeyId, cancellationToken).ConfigureAwait(false) is null)
        {
            await SeedSecurityAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        // The audit chain is append-only and its events carry generated identifiers, so there
        // is no record to look for by id. Counting is the only honest question: if this
        // project already has audit events, they are either these or real ones, and appending
        // a second demonstration set to either would be wrong.
        var audited = await store.QueryAuditAsync(Project, null, 1, cancellationToken).ConfigureAwait(false);
        if (audited.Count == 0)
        {
            await SeedAuditAsync(store, now, cancellationToken).ConfigureAwait(false);
        }

        // Last, deliberately: the package is the sentinel the guard above reads, so it must
        // not exist until everything else does.
        await SeedPublicationAsync(store, now, cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0005 live control room, CH1-UX-SCR-0016 cross-layer overview
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedMonitoringAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        // Three alarms in three different states, because the control room's whole job is
        // keeping cause, acknowledgement and outstanding apart. A dataset with only
        // outstanding alarms cannot show that an acknowledgement is not a clearance, and
        // the render gate refuses a capture "too impoverished to exercise the subject".
        await store.SaveAlarmAsync(
            new Alarm(
                AlarmOutstandingId, Project, Cell, "CH1-DEV-CELL-0001",
                "CH1-ALM-TEMP-HIGH", 1, AlarmState.Active,
                now.AddMinutes(-4), null, null, null, null, false),
            cancellationToken).ConfigureAwait(false);

        await store.SaveAlarmAsync(
            new Alarm(
                AlarmAcknowledgedId, Project, Cell, "CH1-DEV-CELL-0001",
                "CH1-ALM-VIBRATION", 2, AlarmState.Acknowledged,
                now.AddMinutes(-22), "USR-ENGINEER-01", now.AddMinutes(-18),
                "Seen; coating head rebalanced, watching the trend.", null, false),
            cancellationToken).ConfigureAwait(false);

        // Cleared because the CAUSE went away, which is the only thing that clears one.
        await store.SaveAlarmAsync(
            new Alarm(
                AlarmClearedId, Project, Cell, "CH1-DEV-CELL-0001",
                "CH1-ALM-HUMIDITY", 3, AlarmState.Cleared,
                now.AddHours(-3), "USR-ENGINEER-01", now.AddHours(-2).AddMinutes(-40),
                "Extraction restored.", now.AddHours(-2), true),
            cancellationToken).ConfigureAwait(false);

        // Two hours of history on all four controlled channels, so a trend has a shape
        // rather than a single point. Simulated, always: CH1-MON-FR-0003 requires live,
        // stale, disconnected, simulated, maintenance and unknown to stay distinguishable,
        // and a seeded reading is not a measurement of anything.
        var samples = new List<TelemetrySample>();
        var channels = new (string Channel, string Unit, double Centre, double Swing)[]
        {
            ("CH1-IO-AI-0001", "degC", 21.5, 1.8),
            ("CH1-IO-AI-0002", "%RH", 44.0, 6.0),
            ("CH1-IO-AI-0003", "mm", 128.0, 0.4),
            ("CH1-IO-AI-0004", "m/s2", 0.65, 0.25),
        };

        for (var minute = 120; minute >= 0; minute -= 2)
        {
            var at = now.AddMinutes(-minute);
            foreach (var (channel, unit, centre, swing) in channels)
            {
                // Deterministic, not random: a dataset that differs between runs makes a
                // screenshot impossible to compare and a rendered check impossible to pin.
                var phase = (minute / 2.0) * 0.35;
                var value = centre + (swing * Math.Sin(phase));
                samples.Add(new TelemetrySample(
                    Guid.NewGuid(), Project, Cell, "CH1-DEV-CELL-0001", channel,
                    Math.Round(value, 3), unit,
                    DataQuality.Good, Freshness.Simulated,
                    at, at, "Synchronised"));
            }
        }

        // One reading past its alarm limit, so the telemetry screen has something the
        // control room's limit rendering can actually be about.
        samples.Add(new TelemetrySample(
            Guid.NewGuid(), Project, Cell, "CH1-DEV-CELL-0001", "CH1-IO-AI-0001",
            48.7, "degC", DataQuality.Uncertain, Freshness.Simulated,
            now.AddMinutes(-4), now.AddMinutes(-4), "Synchronised"));

        await store.AppendTelemetryAsync(samples, cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0007 genealogy, 0010 inspection, 0011 NCR / rework / retest
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedQualityAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        await store.SaveTestRunAsync(
            new TestRunRecord(
                TestRunFailedId, Project, Part, "CH1-QMS-PRO-0004", "R01",
                "USR-INSPECTOR-01", "USR-ENGINEER-01", TestRunStatus.Completed,
                now.AddHours(-6), now.AddHours(-6).AddMinutes(12), 1),
            cancellationToken).ConfigureAwait(false);

        await store.SaveTestRunAsync(
            new TestRunRecord(
                TestRunPassedId, Project, Part, "CH1-QMS-PRO-0004", "R01",
                "USR-INSPECTOR-01", "USR-ENGINEER-01", TestRunStatus.Completed,
                now.AddHours(-2), now.AddHours(-2).AddMinutes(9), 1),
            cancellationToken).ConfigureAwait(false);

        // A failure, an authorised rework, and a passing retest — the workflow
        // CH1-QMS-FR-0004 requires, with the superseded failure STILL READABLE. The
        // render gate refuses a part history that drops it, and a dataset that never
        // contained one could not exercise that.
        var measurements = new List<Measurement>
        {
            new(MeasurementFailId, TestRunFailedId, "COATING-THICKNESS",
                18.4m, "um", 20.0m, 26.0m, true,
                "CH1-INS-THK-0001", PrototypeSeed.Ids.CalibrationRecordId,
                null, true, now.AddHours(-6).AddMinutes(8), MeasurementResult.Fail),

            new(MeasurementRetestId, TestRunPassedId, "COATING-THICKNESS",
                23.1m, "um", 20.0m, 26.0m, true,
                "CH1-INS-THK-0001", PrototypeSeed.Ids.CalibrationRecordId,
                MeasurementFailId, true, now.AddHours(-2).AddMinutes(5), MeasurementResult.Pass),

            new(MeasurementPassId, TestRunPassedId, "SURFACE-ROUGHNESS",
                0.42m, "um", 0.10m, 0.80m, false,
                "CH1-INS-THK-0001", PrototypeSeed.Ids.CalibrationRecordId,
                null, true, now.AddHours(-2).AddMinutes(7), MeasurementResult.Pass),
        };

        var part = await store.FindPartAsync(Part, cancellationToken).ConfigureAwait(false);
        if (part is not null)
        {
            await store.SavePartAsync(
                part with
                {
                    Status = PartStatus.InProcess,
                    Measurements = measurements,
                    OpenNcrIds = [NcrOpenId],
                },
                cancellationToken).ConfigureAwait(false);
        }

        await store.SaveNcrAsync(
            new NcrRecord(
                NcrClosedId, Project, Part, TestRunFailedId,
                "Coating thickness below lower limit",
                "COATING-THICKNESS measured 18.4 um against a 20.0 um lower limit on the first run.",
                NcrStatus.Closed, "USR-INSPECTOR-01", now.AddHours(-6).AddMinutes(10),
                MeasurementFailId, NcrDispositionKind.Rework, "USR-ENGINEER-01",
                now.AddHours(-5), "Reapply coating and retest against the same characteristic.",
                MeasurementRetestId, 3),
            cancellationToken).ConfigureAwait(false);

        // One still open, so the disposition workflow has a live subject rather than only
        // a historical one.
        await store.SaveNcrAsync(
            new NcrRecord(
                NcrOpenId, Project, Part, null,
                "Edge finish outside visual standard",
                "Visual inspection found an edge burr outside CH1-QMS-STD-0002 on the trailing edge.",
                NcrStatus.Open, "USR-INSPECTOR-01", now.AddMinutes(-40),
                null, null, null, null, null, null, 1),
            cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0019 contextual collaboration
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedCollaborationAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        await store.SaveContextThreadAsync(
            new ContextThread(
                ThreadId, Project, ContextObjectType.Cell, Cell.ToString(),
                ThreadAccessScope.Create(ProjectThreadRoles, null), "USR-ENGINEER-01", now.AddHours(-5)),
            cancellationToken).ConfigureAwait(false);

        await store.SaveContextMessageAsync(
            new ContextMessage(
                MessageId, Project, ThreadId, "USR-ENGINEER-01", ActorKind.Human,
                MessagePriority.Routine,
                "Coating head rebalanced after the vibration alarm. Retest passed at 23.1 um.",
                now.AddHours(-2), MessageDeliveryState.Published),
            cancellationToken).ConfigureAwait(false);

        // A receipt, which is evidence that a named recipient saw it — and, deliberately,
        // control_authority false. CH1-COL-FR-0003 makes reading a message not an
        // acknowledgement of an alarm, a cleared fault or a confirmed physical action, and
        // migration 0004's CHECK enforces that no future code path can widen it.
        await store.SaveMessageAcknowledgementAsync(
            new MessageAcknowledgement(
                MessageAckId, Project, MessageId, "USR-INSPECTOR-01",
                ActorKind.Human, now.AddHours(-1).AddMinutes(-50)),
            cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0017 resource and capacity board
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedResourcesAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        var resource = await store
            .FindResourceAsync(PrototypeSeed.Ids.CoatingStationResourceId, cancellationToken)
            .ConfigureAwait(false);
        if (resource is null)
        {
            return;
        }

        await store.SaveAllocationAsync(
            new ResourceAllocation(
                AllocationId, Project, PrototypeSeed.Ids.CoatingStationResourceId,
                PrototypeSeed.Ids.WorkOrderId, null, 1m,
                now.AddHours(-1), now.AddHours(3),
                AllocationStatus.Reserved, "USR-PROJECT-MANAGER-01", 1),
            resource.Version, null, cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0020 R&D workbench, CH1-UX-SCR-0021 promotion review
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedResearchAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        // Simulator, never ControlledBench, and production authority false — twice, once
        // on the experiment and once on the run. CH1-RND-FR-0001 isolates R&D from
        // production, and migration 0006 holds both with CHECK constraints.
        var experiment = new Experiment(
            ExperimentId, Project, "USR-RND-01",
            "Evaluate a two-pass coating profile against single-pass thickness variance.",
            ExperimentEnvironment.Simulator, ExperimentStatus.Active,
            1, now.AddDays(-3));

        await store.SaveExperimentAsync(experiment, null, cancellationToken).ConfigureAwait(false);

        var configuration = "cinerion://experiments/two-pass-coating/config@R02";
        var input = "cinerion://experiments/two-pass-coating/input@R02";
        var result = "Variance reduced from 2.1 um to 0.9 um across 40 simulated parts.";

        await store.SaveExperimentRevisionAsync(
            new ExperimentRevision(
                ExperimentRevisionId, Project, ExperimentId, 1,
                ExperimentEnvironment.Simulator,
                configuration, Sha256(configuration),
                "cinerion://models/coating-thickness@R01",
                input, Sha256(input),
                result, Sha256(result),
                "USR-RND-01", "USR-RND-01",
                now.AddDays(-1), now.AddDays(-1).AddMinutes(38)),
            experiment with
            {
                Version = 2,
                // A promotion REQUEST, carrying the change record, impact assessment and
                // verification CH1-RND-FR-0003 requires. Approval lives in configuration
                // control, which is a separate system; nothing here approves it.
                PromotionChangeRecord = "CHG-2026-0184",
                PromotionImpactAnalysis = "Route step 10 timing only; no BOM or safety change.",
                PromotionVerification = "CH1-VVT-TC-0043 re-executed against the reworked profile.",
                PromotionRequestedBy = "USR-RND-01",
                PromotionRequestedAt = now.AddHours(-9),
            },
            1, cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0015 mobile scan and evidence mode
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedEvidenceAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        // The Field Companion the scan came from. ch1.scan_events carries a foreign key to
        // ch1.devices, and CH1-IAM-FR-0008 keeps human, service and device accounts separate:
        // a scan is evidence that a BOUND DEVICE read an identifier at a station, so a scan
        // referencing a device that was never enrolled is not a weaker record, it is a
        // meaningless one. PrototypeSeed enrols the cell controller and the instrument and
        // not this, which is why the first run of the demonstration gate reported the scan
        // and audit screens empty — the seed died here and never reached either.
        await store.SaveDeviceAsync(
            new DeviceRecord(
                "CH1-DEV-FIELD-0001", Project, Cell,
                "FieldCompanion", "1.2.0", "CFG-FIELD-R01",
                null, "Trusted", now.AddDays(-20), null, 1),
            cancellationToken).ConfigureAwait(false);

        var content = "Demonstration inspection report for CH1-PART-000017-04.";
        await store.SaveReportAsync(
            new ReportRecord(
                ReportId, Project, "InspectionReport", "CH1-RPT-TPL-0002", "R03",
                "PhysicalPart", [Part.ToString()],
                Sha256($"{Part}|CH1-RPT-TPL-0002|R03"), Sha256(content),
                "application/pdf", 184_320,
                $"cinerion://reports/{ReportId}",
                "CH1-QMS-RPT-000117", "IFV", "Approved",
                "USR-INSPECTOR-01", now.AddHours(-1)),
            cancellationToken).ConfigureAwait(false);

        // A scan that resolved to the seeded part. The signature is of the demonstration
        // session string and authenticates nothing: CH1-IAM-FR-0008 keeps device sessions
        // separate from human identity, and a seeded signature must not look like proof.
        await store.SaveScanEventAsync(
            new ScanEventRecord(
                ScanEventId, Project, Part, ScanIdentifierKind.QR,
                "CH1-PART-000017-04", "CH1-STN-COAT-01", "CH1-DEV-FIELD-0001",
                "USR-OPERATOR-01", now.AddMinutes(-35), now.AddMinutes(-35),
                Sha256("demonstration-session|CH1-DEV-FIELD-0001"),
                null, ScanResolution.Resolved),
            cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0002 credentials, CH1-UX-SCR-0013 security administration
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedSecurityAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        // A registered passkey with a PUBLIC key and nothing else. No sealed secret, no
        // TOTP material, nothing that could authenticate anybody — the security screen's
        // own rendered check refuses any credential material appearing on the page, and a
        // seeded secret would be a committed one besides.
        await store.SaveCredentialAsync(
            new CredentialRecord(
                CredentialPasskeyId, Project, "ch1-portal-demo",
                CredentialKind.Passkey, "Demonstration platform authenticator",
                PublicKeySpki: DemonstrationPublicKey,
                WebAuthnCredentialId: [0xD0, 0x0D, 0x00, 0x01],
                Aaguid: Guid.Empty,
                SignCount: 4,
                RpId: "localhost",
                SealedSecret: null, SealedSecretNonce: null,
                TotpDigits: null, TotpPeriodSeconds: null, TotpAlgorithm: null,
                SerialNumber: null, AttestationSha256: null,
                UserVerification: UserVerificationRequirement.Required,
                PhishingResistant: true,
                Status: CredentialStatus.Active,
                EnrolledBy: "USR-CYBER-01", EnrolledAt: now.AddDays(-12),
                LastUsedAt: now.AddHours(-3), ExpiresAt: null,
                RevokedAt: null, RevokedBy: null, RevocationReason: null,
                Version: 1),
            cancellationToken).ConfigureAwait(false);

        // CH1's own permanent record of a role change it made. Keycloak remains the
        // authority on who holds which role; the seven-year retention is carried on the
        // row, and migration 0014's CHECK holds it to the entity register.
        var assignedAt = now.AddDays(-12);
        await store.SaveRoleAssignmentAsync(
            new RoleAssignmentRecord(
                RoleAssignmentId, Project, "ch1-portal-demo", "ch1-portal-demo",
                PreviousRoles: PreviousRoles,
                CurrentRoles: CurrentRoles,
                GrantedRoles: GrantedRoles,
                WithdrawnRoles: [],
                AssignedBy: "USR-SYSTEM-ADMIN-01", AssignedAt: assignedAt,
                Provider: "keycloak", CorrelationId: Id("0091"),
                RetainUntil: assignedAt.AddYears(7)),
            cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-DOC-FR-0004 publication pipeline
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedPublicationAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        var content = "Redacted architecture overview for external release.";
        var checksum = Sha256(content);

        var package = new PublicationPackage(
            PackageId, Project, "ProjectInternalToPublic", "R02",
            "Cinerion architecture overview, public release",
            new[]
            {
                new PublicationSource(
                    PrototypeSeed.Ids.ProjectInternalDocumentId,
                    "CH1-SYS-ARC-0001", "R01", "Project Internal",
                    Sha256("Architecture overview, project internal")),
            },
            checksum, "application/pdf", 421_888,
            $"cinerion://publications/{PackageId}",
            MetadataRemoved: RemovedMetadata,
            MetadataRetained: new Dictionary<string, string>
            {
                ["documentNumber"] = "CH1-SYS-ARC-0001",
                ["issueStatus"] = "IFV",
            },
            SecretScanProfile: "CH1-CYB-SCAN-0001", SecretScanPatterns: 34,
            ContentDiffPerformed: true,
            ContentDiffNote: "12 project-internal passages removed; no controlled requirement text altered.",
            State: PublicationState.Approved,
            CreatedBy: "USR-DOC-CONTROL-01",
            CreatedAt: now.AddDays(-2),
            DecidedAt: now.AddDays(-1),
            Version: 3);

        await store.SavePublicationPackageAsync(package, cancellationToken).ConfigureAwait(false);

        // Two reviewers in two distinct capacities, neither of them the author. That
        // two-person property does not rest on the role mapping conflict 23 records — it
        // is enforced regardless, and a dataset with one approval could not show it.
        await store.SavePublicationApprovalAsync(
            new PublicationApproval(
                ApprovalIrId, Project, PackageId, ReviewerCapacity.ProjectOwner,
                PublicationState.Approved, "USR-PROJECT-OWNER-01", "ProjectOwner",
                checksum, "Confidential boundary reviewed; approved for public release.",
                now.AddDays(-1).AddHours(-4)),
            cancellationToken).ConfigureAwait(false);

        await store.SavePublicationApprovalAsync(
            new PublicationApproval(
                ApprovalDocId, Project, PackageId, ReviewerCapacity.DocumentControl,
                PublicationState.Approved, "USR-DOC-CONTROL-02", "DocumentController",
                checksum, "Redaction profile and metadata removal verified against R02.",
                now.AddDays(-1)),
            cancellationToken).ConfigureAwait(false);
    }

    // -----------------------------------------------------------------------------------
    // CH1-UX-SCR-0014 audit-chain explorer
    // -----------------------------------------------------------------------------------

    private static async ValueTask SeedAuditAsync(
        ICinerionStore store, DateTimeOffset now, CancellationToken cancellationToken)
    {
        // The chain explorer read {"items":[],"count":0} until this existed — a screen that
        // works perfectly and shows nothing, which is the exact ambiguity this whole dataset
        // is for. Found by asking the running service rather than by reading the seed.
        //
        // Appended through AppendAuditAsync, never written as rows: the chain's hash links
        // each event to the one before it, so events inserted directly would produce a chain
        // that fails its own verification. The explorer's verify button would then report
        // tampering on a database nobody had tampered with, which is a far worse outcome than
        // an empty screen.
        var events = new (string Type, string ObjectType, string ObjectId, string Decision, string Reason)[]
        {
            ("ProjectEstablished", "Project", $"{Project}", "Permitted", "PROJECT_ESTABLISHED"),
            ("WorkOrderReleased", "WorkOrder", $"{PrototypeSeed.Ids.WorkOrderId}", "Permitted", "WORK_ORDER_RELEASED"),
            ("MeasurementRecorded", "PhysicalPart", $"{Part}", "Permitted", "MEASUREMENT_OUTSIDE_LIMIT"),
            ("NonconformityRaised", "NCR", $"{NcrClosedId}", "Permitted", "NCR_RAISED"),
            ("NonconformityDispositioned", "NCR", $"{NcrClosedId}", "Permitted", "NCR_REWORK_AUTHORISED"),
            ("AlarmAcknowledged", "Alarm", $"{AlarmAcknowledgedId}", "Permitted", "ALARM_ACKNOWLEDGED_CAUSE_NOT_CLEARED"),
            ("ResourceReserved", "ResourceAllocation", $"{AllocationId}", "Permitted", "RESERVATION_HELD"),
            ("RoleAssignmentChanged", "RoleAssignment", $"{RoleAssignmentId}", "Permitted", "ROLES_GRANTED"),
            ("PublicationApproved", "PublicationPackage", $"{PackageId}", "Permitted", "TWO_PERSON_REVIEW_COMPLETE"),
            // A refusal, because an audit chain of nothing but permissions is an audit chain
            // that has never been asked to record the interesting case.
            ("CommandPrepareRefused", "Cell", $"{Cell}", "Refused", "CONTROLLER_TIME_NOT_TRUSTED"),
        };

        var minute = events.Length;
        foreach (var (type, objectType, objectId, decision, reason) in events)
        {
            await store.AppendAuditAsync(
                new AuditInput(
                    type, "USR-DEMONSTRATION", ActorKind.Human, Project,
                    objectType, objectId, Guid.NewGuid(),
                    now.AddMinutes(-minute * 7), decision, reason,
                    new { note = "Demonstration record. No physical act is evidenced." },
                    "Synchronised"),
                cancellationToken).ConfigureAwait(false);
            minute -= 1;
        }
    }

    /// <summary>
    /// A fixed P-256 public key, so a demonstration passkey is a well-formed record rather
    /// than a plausible-looking one. It has no private half anywhere and authenticates
    /// nothing; the assertion path verifies a real signature and would refuse it.
    /// </summary>
    private static readonly byte[] DemonstrationPublicKey =
    [
        0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x02, 0x01,
        0x06, 0x08, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00,
        0x04, 0xD0, 0x0D, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
        0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16,
        0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23,
        0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x30,
        0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D,
        0x3E, 0x3F,
    ];

    // CA1861: constant arrays passed to a repeatedly-called method belong in fields.
    private static readonly string[] ProjectThreadRoles =
        ["Viewer", "Engineer", "Inspector", "Auditor", "ProjectManager"];
    private static readonly string[] RemovedMetadata =
        ["author", "revisionHistory", "internalReferences"];
    private static readonly string[] PreviousRoles = ["Viewer"];
    private static readonly string[] CurrentRoles = ["Viewer", "Engineer", "Inspector", "Auditor"];
    private static readonly string[] GrantedRoles = ["Engineer", "Inspector", "Auditor"];

    private static string Sha256(string value) =>
        Convert.ToHexStringLower(
            System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(value)));
}
