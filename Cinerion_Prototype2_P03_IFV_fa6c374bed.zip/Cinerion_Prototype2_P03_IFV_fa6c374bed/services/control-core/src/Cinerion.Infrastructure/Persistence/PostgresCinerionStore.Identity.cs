// PostgreSQL storage for the role assignment history.

using System.Text.Json;
using Cinerion.Domain.Identity;
using Npgsql;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// The controlled record of role assignment changes, on the schema migration 0012 adds.
/// <para>
/// entities.json declares RoleAssignment with a Security Sensitive classification and a
/// seven-year retention, and until 0012 there was no table for it: a role change was
/// evidenced only by <c>ch1.audit_events</c>, which stores a payload <i>hash</i>. That
/// makes the history verifiable and not readable - an auditor can prove an event was not
/// altered while being unable to say what it recorded.
/// </para>
/// <para>
/// There is no update path and no delete path here, and 0012 REVOKEs both from the
/// application role - which it has to do explicitly, because 0002 sets ALTER DEFAULT
/// PRIVILEGES granting all four verbs on every table created in the schema. A privilege
/// the application does not hold is one no defect in the application can misuse.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0006, CH1-TRC-FR-0002</requirements>
public sealed partial class PostgresCinerionStore
{
    private const string RoleAssignmentProjection = """
        SELECT assignment_id, project_id, subject_user_id, subject_username,
               previous_roles, current_roles, granted_roles, withdrawn_roles,
               assigned_by, assigned_at, provider, correlation_id, retain_until
        FROM ch1.role_assignments
        """;

    public async ValueTask SaveRoleAssignmentAsync(
        RoleAssignmentRecord assignment,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(assignment);
        await using var connection = await dataSource
            .OpenForProjectAsync(assignment.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();

        // No ON CONFLICT clause, deliberately. Every change is its own row: an assignment
        // identifier that already existed would mean this record is being written twice,
        // and silently overwriting it would lose one of the two events.
        command.CommandText = """
            INSERT INTO ch1.role_assignments(
                assignment_id, project_id, subject_user_id, subject_username,
                previous_roles, current_roles, granted_roles, withdrawn_roles,
                assigned_by, assigned_at, provider, correlation_id, retain_until)
            VALUES($1, $2, $3, $4, $5::jsonb, $6::jsonb, $7::jsonb, $8::jsonb, $9, $10, $11, $12, $13)
            """;
        AddAll(
            command,
            assignment.AssignmentId,
            assignment.ProjectId,
            assignment.SubjectUserId,
            assignment.SubjectUsername,
            JsonSerializer.Serialize(assignment.PreviousRoles, Json),
            JsonSerializer.Serialize(assignment.CurrentRoles, Json),
            JsonSerializer.Serialize(assignment.GrantedRoles, Json),
            JsonSerializer.Serialize(assignment.WithdrawnRoles, Json),
            assignment.AssignedBy,
            assignment.AssignedAt,
            assignment.Provider,
            assignment.CorrelationId,
            assignment.RetainUntil);
        await ExecuteMappingConflictsAsync(
            command,
            "ROLE_ASSIGNMENT_ALREADY_RECORDED",
            "That role assignment has already been recorded.",
            cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<RoleAssignmentRecord>> ListRoleAssignmentsAsync(
        Guid projectId,
        string subjectUserId,
        int limit,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = RoleAssignmentProjection +
            " WHERE subject_user_id = $1 ORDER BY assigned_at DESC, assignment_id DESC LIMIT $2";
        command.Parameters.Add(Param(subjectUserId));
        command.Parameters.Add(Param(Math.Clamp(limit, 1, 200)));
        return await ReadManyAsync(command, ReadRoleAssignment, cancellationToken).ConfigureAwait(false);
    }

    private static RoleAssignmentRecord ReadRoleAssignment(NpgsqlDataReader reader) => new(
        reader.GetGuid(0),
        reader.GetGuid(1),
        reader.GetString(2),
        reader.GetString(3),
        ReadRoles(reader.GetString(4)),
        ReadRoles(reader.GetString(5)),
        ReadRoles(reader.GetString(6)),
        ReadRoles(reader.GetString(7)),
        reader.GetString(8),
        reader.GetFieldValue<DateTimeOffset>(9),
        reader.GetString(10),
        reader.GetGuid(11),
        reader.GetFieldValue<DateTimeOffset>(12));

    private static List<string> ReadRoles(string json) =>
        JsonSerializer.Deserialize<List<string>>(json, Json) ?? [];
}
