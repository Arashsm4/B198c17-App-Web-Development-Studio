// PostgreSQL storage for threads, messages and receipts.

using System.Text.Json;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;
using Npgsql;
using NpgsqlTypes;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Contextual threads, messages and receipts on the controlled schema.
/// </summary>
/// <requirements>CH1-COL-FR-0001, CH1-COL-FR-0002, CH1-COL-FR-0003</requirements>
public sealed partial class PostgresCinerionStore
{
    // ----------------------------------------------------------------- threads

    private const string ThreadProjection = """
        SELECT thread_id, project_id, object_type, object_id, access_scope, created_by, created_at
        FROM ch1.context_threads
        """;

    public async ValueTask<ContextThread?> FindContextThreadAsync(Guid threadId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ThreadProjection + " WHERE thread_id = $1";
        command.Parameters.Add(Param(threadId));
        return await ReadOneAsync(command, ReadThread, cancellationToken).ConfigureAwait(false);
    }

    private static ContextThread ReadThread(NpgsqlDataReader r) => new(
        r.GetGuid(0),
        r.GetGuid(1),
        Enum.Parse<ContextObjectType>(r.GetString(2)),
        r.GetString(3),
        JsonSerializer.Deserialize<ThreadAccessScope>(r.GetString(4), Json)
            ?? new ThreadAccessScope([], []),
        r.GetString(5),
        r.GetFieldValue<DateTimeOffset>(6));

    public async ValueTask SaveContextThreadAsync(ContextThread thread, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(thread.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // The object link is never rewritten. A thread belongs to the object it was
        // opened against; moving it would silently relocate a conversation and every
        // access decision made about it. Only the access scope may change.
        command.CommandText = """
            INSERT INTO ch1.context_threads(thread_id, project_id, object_type, object_id, access_scope, created_by, created_at)
            VALUES($1, $2, $3, $4, $5::jsonb, $6, $7)
            ON CONFLICT (thread_id) DO UPDATE SET access_scope = EXCLUDED.access_scope
            """;
        AddAll(
            command, thread.ThreadId, thread.ProjectId, thread.ObjectType.ToString(), thread.ObjectId,
            JsonSerializer.Serialize(thread.AccessScope, Json), thread.CreatedBy, thread.CreatedAt);
        await ExecuteMappingConflictsAsync(
            command,
            "CONTEXT_THREAD_CONFLICT",
            "A contextual thread already exists for that controlled object.",
            cancellationToken).ConfigureAwait(false);
    }

    // ---------------------------------------------------------------- messages

    private const string MessageProjection = """
        SELECT message_id, project_id, thread_id, author_id, author_kind, priority, body,
               created_at, delivery_state, control_authority
        FROM ch1.context_messages
        """;

    public async ValueTask<ContextMessage?> FindContextMessageAsync(Guid messageId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = MessageProjection + " WHERE message_id = $1";
        command.Parameters.Add(Param(messageId));
        return await ReadOneAsync(command, ReadMessage, cancellationToken).ConfigureAwait(false);
    }

    private static ContextMessage ReadMessage(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetString(3),
        Enum.Parse<ActorKind>(r.GetString(4)),
        Enum.Parse<MessagePriority>(r.GetString(5)),
        r.GetString(6),
        r.GetFieldValue<DateTimeOffset>(7),
        Enum.Parse<MessageDeliveryState>(r.GetString(8)),
        r.GetBoolean(9));

    /// <summary>
    /// Inserts a message. There is deliberately no update branch: the author, body and
    /// time of a contextual message are written once, which is the "immutable author"
    /// control CH1-SWA-API-0001 states for this operation.
    /// </summary>
    public async ValueTask SaveContextMessageAsync(ContextMessage message, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(message.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.context_messages(message_id, project_id, thread_id, author_id, author_kind,
                priority, body, created_at, delivery_state, control_authority)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """;
        AddAll(
            command, message.MessageId, message.ProjectId, message.ThreadId, message.AuthorId,
            message.AuthorKind.ToString(), message.Priority.ToString(), message.Body,
            message.CreatedAt, message.DeliveryState.ToString(), message.ControlAuthority);
        try
        {
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.CheckViolation)
        {
            // ch1.context_messages carries CHECK (control_authority = false) and a body
            // length check. Reported as the domain rule rather than as a database fault,
            // so the caller sees why it was refused.
            throw new DomainRuleException(
                "CONTEXT_MESSAGE_REJECTED",
                "The message violates a controlled constraint on contextual messages.");
        }
    }

    public async ValueTask<IReadOnlyList<ContextMessage>> ListContextMessagesAsync(
        ContextMessageQuery query,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(query.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // Oldest first, so a conversation reads in the order it happened. Keyset paging
        // over the whole sort key: an OFFSET would repeat or skip a message when one is
        // posted mid-page.
        command.CommandText = MessageProjection +
            """
             WHERE thread_id = $1
               AND ($2::timestamptz IS NULL OR (created_at, message_id) > ($2, $3::uuid))
             ORDER BY created_at, message_id
             LIMIT $4
            """;
        command.Parameters.Add(Param(query.ThreadId));
        command.Parameters.Add(Nullable(query.After?.CreatedAt));
        command.Parameters.Add(Nullable(query.After?.MessageId));
        command.Parameters.Add(Param(query.Limit));
        return await ReadManyAsync(command, ReadMessage, cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------ receipts

    public async ValueTask<IReadOnlyList<MessageAcknowledgement>> ListMessageAcknowledgementsAsync(
        Guid projectId,
        IReadOnlyList<Guid> messageIds,
        CancellationToken cancellationToken)
    {
        if (messageIds.Count == 0)
        {
            return [];
        }

        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT message_ack_id, project_id, message_id, recipient_id, recipient_kind,
                   acknowledged_at, control_authority
            FROM ch1.message_acknowledgements
            WHERE message_id = ANY($1)
            ORDER BY acknowledged_at
            """;
        command.Parameters.Add(new NpgsqlParameter
        {
            Value = messageIds.ToArray(),
            NpgsqlDbType = NpgsqlDbType.Array | NpgsqlDbType.Uuid,
        });
        return await ReadManyAsync(
            command,
            r => new MessageAcknowledgement(
                r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetString(3),
                Enum.Parse<ActorKind>(r.GetString(4)),
                r.GetFieldValue<DateTimeOffset>(5),
                r.GetBoolean(6)),
            cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Records a receipt. <c>acknowledgement_kind</c> is written as the single value the
    /// column's CHECK permits, so the database itself refuses to hold a message receipt
    /// that claims to be anything else.
    /// </summary>
    public async ValueTask SaveMessageAcknowledgementAsync(
        MessageAcknowledgement acknowledgement,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(acknowledgement.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // retain_until is computed in SQL from acknowledged_at, not passed in.
        //
        // Migration 0014 added the column NOT NULL with a CHECK tying it to
        // acknowledged_at + 7 years, and this INSERT — written before 0014 existed — did not
        // set it. Every acknowledgement write against PostgreSQL failed from that moment with
        // a bare 23502, and nothing caught it: no test exercises this path on a real
        // database, so the whole suite and the strict pipeline stayed green over a write that
        // could not succeed. CH1-COL-FR-0002 requires acknowledgement state to be retained,
        // and it had become impossible to record any.
        //
        // Computed here rather than in .NET so the value the CHECK tests and the value the
        // row carries are produced by the same expression on the same clock. A caller passing
        // its own would be a second place for the register's declared period to be stated,
        // which is the shape the CHECK exists to prevent.
        command.CommandText = """
            INSERT INTO ch1.message_acknowledgements(message_ack_id, project_id, message_id, recipient_id,
                recipient_kind, acknowledgement_kind, acknowledged_at, control_authority, retain_until)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $7::timestamptz + interval '7 years')
            """;
        AddAll(
            command, acknowledgement.MessageAckId, acknowledgement.ProjectId, acknowledgement.MessageId,
            acknowledgement.RecipientId, acknowledgement.RecipientKind.ToString(),
            MessageAcknowledgement.Kind, acknowledgement.AcknowledgedAt, acknowledgement.ControlAuthority);
        await ExecuteMappingConflictsAsync(
            command,
            "CONTEXT_RECEIPT_CONFLICT",
            "That recipient has already recorded receipt of this message.",
            cancellationToken).ConfigureAwait(false);
    }
}
