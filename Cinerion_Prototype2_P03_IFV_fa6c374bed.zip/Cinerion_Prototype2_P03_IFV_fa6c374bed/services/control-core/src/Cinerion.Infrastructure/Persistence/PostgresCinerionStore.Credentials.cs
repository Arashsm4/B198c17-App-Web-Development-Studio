// PostgreSQL storage for credentials and WebAuthn challenges.

using Cinerion.Domain.Common;
using Cinerion.Domain.Security;
using Npgsql;
using NpgsqlTypes;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Authenticator credentials and WebAuthn challenges on the controlled schema.
/// </summary>
/// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-IAM-FR-0007, CH1-CYB-IAM-0001</requirements>
public sealed partial class PostgresCinerionStore
{
    private const string CredentialProjection = """
        SELECT credential_id, project_id, subject_id, credential_kind, label,
               public_key_spki, webauthn_credential_id, aaguid, sign_count, rp_id,
               sealed_secret, sealed_secret_nonce, totp_digits, totp_period_seconds, totp_algorithm,
               serial_number, attestation_sha256, user_verification, phishing_resistant, status,
               enrolled_by, enrolled_at, last_used_at, expires_at,
               revoked_at, revoked_by, revocation_reason, version
        FROM ch1.credentials
        """;

    public async ValueTask<CredentialRecord?> FindCredentialAsync(
        Guid credentialId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = $"{CredentialProjection} WHERE credential_id = $1";
        command.Parameters.Add(Param(credentialId));
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        return await reader.ReadAsync(cancellationToken).ConfigureAwait(false) ? ReadCredential(reader) : null;
    }

    public async ValueTask<CredentialRecord?> FindCredentialByWebAuthnIdAsync(
        Guid projectId,
        byte[] webAuthnCredentialId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = $"{CredentialProjection} WHERE project_id = $1 AND webauthn_credential_id = $2";
        command.Parameters.Add(Param(projectId));
        command.Parameters.Add(new NpgsqlParameter { Value = webAuthnCredentialId, NpgsqlDbType = NpgsqlDbType.Bytea });
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        return await reader.ReadAsync(cancellationToken).ConfigureAwait(false) ? ReadCredential(reader) : null;
    }

    public async ValueTask<IReadOnlyList<CredentialRecord>> ListCredentialsAsync(
        Guid projectId,
        string subjectId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = $"""
            {CredentialProjection}
            WHERE project_id = $1 AND subject_id = $2
            ORDER BY enrolled_at DESC
            """;
        command.Parameters.Add(Param(projectId));
        command.Parameters.Add(Param(subjectId));

        var found = new List<CredentialRecord>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
        {
            found.Add(ReadCredential(reader));
        }

        return found;
    }

    public async ValueTask SaveCredentialAsync(CredentialRecord credential, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(credential.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.credentials(
                credential_id, project_id, subject_id, credential_kind, label,
                public_key_spki, webauthn_credential_id, aaguid, sign_count, rp_id,
                sealed_secret, sealed_secret_nonce, totp_digits, totp_period_seconds, totp_algorithm,
                serial_number, attestation_sha256, user_verification, phishing_resistant, status,
                enrolled_by, enrolled_at, last_used_at, expires_at,
                revoked_at, revoked_by, revocation_reason, version)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18,
                   $19, $20, $21, $22, $23, $24, $25, $26, $27, $28)
            ON CONFLICT (credential_id) DO UPDATE SET
              label = EXCLUDED.label,
              sign_count = EXCLUDED.sign_count,
              status = EXCLUDED.status,
              last_used_at = EXCLUDED.last_used_at,
              expires_at = EXCLUDED.expires_at,
              revoked_at = EXCLUDED.revoked_at,
              revoked_by = EXCLUDED.revoked_by,
              revocation_reason = EXCLUDED.revocation_reason,
              version = EXCLUDED.version
            """;
        command.Parameters.Add(Param(credential.CredentialId));
        command.Parameters.Add(Param(credential.ProjectId));
        command.Parameters.Add(Param(credential.SubjectId));
        command.Parameters.Add(Param(credential.Kind.ToString()));
        command.Parameters.Add(Param(credential.Label));
        command.Parameters.Add(Bytea(credential.PublicKeySpki));
        command.Parameters.Add(Bytea(credential.WebAuthnCredentialId));
        command.Parameters.Add(Nullable(credential.Aaguid));
        command.Parameters.Add(Param(credential.SignCount));
        command.Parameters.Add(Nullable(credential.RpId));
        command.Parameters.Add(Bytea(credential.SealedSecret));
        command.Parameters.Add(Bytea(credential.SealedSecretNonce));
        command.Parameters.Add(SmallInt(credential.TotpDigits));
        command.Parameters.Add(SmallInt(credential.TotpPeriodSeconds));
        command.Parameters.Add(Nullable(credential.TotpAlgorithm));
        command.Parameters.Add(Nullable(credential.SerialNumber));
        command.Parameters.Add(Nullable(credential.AttestationSha256));
        command.Parameters.Add(Param(credential.UserVerification.ToString()));
        command.Parameters.Add(Param(credential.PhishingResistant));
        command.Parameters.Add(Param(credential.Status.ToString()));
        command.Parameters.Add(Param(credential.EnrolledBy));
        command.Parameters.Add(Param(credential.EnrolledAt));
        command.Parameters.Add(Nullable(credential.LastUsedAt));
        command.Parameters.Add(Nullable(credential.ExpiresAt));
        command.Parameters.Add(Nullable(credential.RevokedAt));
        command.Parameters.Add(Nullable(credential.RevokedBy));
        command.Parameters.Add(Nullable(credential.RevocationReason));
        command.Parameters.Add(Param(credential.Version));

        try
        {
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            // ux_credentials_webauthn_id, ux_credentials_serial or ux_credentials_active_totp.
            // All three say the same thing: this authenticator, or an active enrolment of
            // this class, already exists for the identity.
            throw new DomainRuleException(
                "CREDENTIAL_ALREADY_ENROLLED",
                "An authenticator with this identity is already enrolled in the project.");
        }
    }

    public async ValueTask<WebAuthnChallenge?> FindWebAuthnChallengeAsync(
        Guid challengeId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT challenge_id, project_id, subject_id, challenge, rp_id, origin, purpose,
                   issued_at, expires_at, consumed_at
            FROM ch1.webauthn_challenges
            WHERE challenge_id = $1
            """;
        command.Parameters.Add(Param(challengeId));
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        if (!await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
        {
            return null;
        }

        return new WebAuthnChallenge(
            reader.GetGuid(0),
            reader.GetGuid(1),
            reader.GetString(2),
            (byte[])reader[3],
            reader.GetString(4),
            reader.GetString(5),
            reader.GetString(6),
            reader.GetFieldValue<DateTimeOffset>(7),
            reader.GetFieldValue<DateTimeOffset>(8),
            reader.IsDBNull(9) ? null : reader.GetFieldValue<DateTimeOffset>(9));
    }

    public async ValueTask SaveWebAuthnChallengeAsync(
        WebAuthnChallenge challenge,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(challenge.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // Consumption is conditional: the UPDATE only fires while consumed_at is still
        // null, so two requests racing to answer the same challenge cannot both succeed.
        // Single use is enforced here rather than by reading first and writing after.
        command.CommandText = """
            INSERT INTO ch1.webauthn_challenges(
                challenge_id, project_id, subject_id, challenge, rp_id, origin, purpose,
                issued_at, expires_at, consumed_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            ON CONFLICT (challenge_id) DO UPDATE SET consumed_at = EXCLUDED.consumed_at
            WHERE ch1.webauthn_challenges.consumed_at IS NULL
            """;
        command.Parameters.Add(Param(challenge.ChallengeId));
        command.Parameters.Add(Param(challenge.ProjectId));
        command.Parameters.Add(Param(challenge.SubjectId));
        command.Parameters.Add(new NpgsqlParameter { Value = challenge.Challenge, NpgsqlDbType = NpgsqlDbType.Bytea });
        command.Parameters.Add(Param(challenge.RpId));
        command.Parameters.Add(Param(challenge.Origin));
        command.Parameters.Add(Param(challenge.Purpose));
        command.Parameters.Add(Param(challenge.IssuedAt));
        command.Parameters.Add(Param(challenge.ExpiresAt));
        command.Parameters.Add(Nullable(challenge.ConsumedAt));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    private static CredentialRecord ReadCredential(NpgsqlDataReader reader) => new(
        reader.GetGuid(0),
        reader.GetGuid(1),
        reader.GetString(2),
        Enum.Parse<CredentialKind>(reader.GetString(3)),
        reader.GetString(4),
        reader.IsDBNull(5) ? null : (byte[])reader[5],
        reader.IsDBNull(6) ? null : (byte[])reader[6],
        reader.IsDBNull(7) ? null : reader.GetGuid(7),
        reader.GetInt64(8),
        reader.IsDBNull(9) ? null : reader.GetString(9),
        reader.IsDBNull(10) ? null : (byte[])reader[10],
        reader.IsDBNull(11) ? null : (byte[])reader[11],
        reader.IsDBNull(12) ? null : reader.GetInt16(12),
        reader.IsDBNull(13) ? null : reader.GetInt16(13),
        reader.IsDBNull(14) ? null : reader.GetString(14),
        reader.IsDBNull(15) ? null : reader.GetString(15),
        reader.IsDBNull(16) ? null : reader.GetString(16),
        Enum.Parse<UserVerificationRequirement>(reader.GetString(17)),
        reader.GetBoolean(18),
        Enum.Parse<CredentialStatus>(reader.GetString(19)),
        reader.GetString(20),
        reader.GetFieldValue<DateTimeOffset>(21),
        reader.IsDBNull(22) ? null : reader.GetFieldValue<DateTimeOffset>(22),
        reader.IsDBNull(23) ? null : reader.GetFieldValue<DateTimeOffset>(23),
        reader.IsDBNull(24) ? null : reader.GetFieldValue<DateTimeOffset>(24),
        reader.IsDBNull(25) ? null : reader.GetString(25),
        reader.IsDBNull(26) ? null : reader.GetString(26),
        reader.GetInt64(27));

    private static NpgsqlParameter Bytea(byte[]? value) =>
        new() { Value = (object?)value ?? DBNull.Value, NpgsqlDbType = NpgsqlDbType.Bytea };

    private static NpgsqlParameter SmallInt(int? value) =>
        new() { Value = value.HasValue ? (short)value.Value : DBNull.Value, NpgsqlDbType = NpgsqlDbType.Smallint };
}
