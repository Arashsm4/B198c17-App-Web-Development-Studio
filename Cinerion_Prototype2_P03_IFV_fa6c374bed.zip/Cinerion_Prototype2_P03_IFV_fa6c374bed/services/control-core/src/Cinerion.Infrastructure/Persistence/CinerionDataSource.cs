// Opens PostgreSQL connections carrying the request's project scope, so row-level security has
// something to check.

using System.Data;
using Npgsql;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Carries the project scope of the current request into the database session.
/// <para>
/// Every controlled table enforces row-level security keyed on
/// <c>ch1.current_project_id()</c>, which reads the transaction-local
/// <c>ch1.project_id</c> setting. Nothing is readable or writable until that setting
/// is applied, so a request that fails to establish its scope reads no rows rather
/// than reading everything. That is the intended fail-closed direction.
/// </para>
/// </summary>
public sealed class ProjectScope
{
    private Guid? _projectId;

    public Guid? Current => _projectId;

    public void Set(Guid projectId) => _projectId = projectId;
}

/// <summary>
/// The one connection pool this process uses, held for the lifetime of the process.
/// </summary>
/// <remarks>
/// <para>
/// <see cref="NpgsqlDataSource"/> <i>is</i> the pool. It is thread-safe and intended to be
/// created once and shared, and a pool disposed at the end of a request pools nothing:
/// every request opens fresh physical connections and closes them again. On this
/// workstation a fresh connection measured 13.3 ms of TCP, startup and authentication, and
/// PostgreSQL forks a backend process for each one, so the cost falls on the server as
/// well as on the caller.
/// </para>
/// <para>
/// It is also what makes the connection budget mean anything. <c>max_connections</c>
/// governs the whole server; a maximum applied to one request's private pool says nothing
/// about how many connections a hundred concurrent requests open between them.
/// </para>
/// <para>
/// The <i>scope</i> stays per request. This type holds only the pool, so the two lifetimes
/// are separate rather than accidentally shared.
/// </para>
/// </remarks>
public sealed class CinerionConnectionPool : IAsyncDisposable
{
    public CinerionConnectionPool(string connectionString) =>
        DataSource = NpgsqlDataSource.Create(connectionString);

    public NpgsqlDataSource DataSource { get; }

    public ValueTask DisposeAsync() => DataSource.DisposeAsync();
}

/// <summary>
/// Opens connections with the row-level security scope already applied, and brings a
/// fresh database up to the controlled schema.
/// </summary>
public sealed class CinerionDataSource : IAsyncDisposable
{
    private readonly NpgsqlDataSource _dataSource;
    private readonly ProjectScope _scope;

    /// <summary>Whether disposing this object should take the pool down with it.</summary>
    private readonly bool _ownsDataSource;

    /// <summary>
    /// A data source that owns its pool, for the startup probe and for tests that want a
    /// pool of their own.
    /// </summary>
    /// <remarks>
    /// Not the constructor the request pipeline uses. A per-request object that owns a
    /// pool destroys it at the end of the request; see <see cref="CinerionConnectionPool"/>.
    /// </remarks>
    public CinerionDataSource(string connectionString, ProjectScope scope)
    {
        _dataSource = NpgsqlDataSource.Create(connectionString);
        _scope = scope;
        _ownsDataSource = true;
    }

    /// <summary>
    /// A per-request data source over the process-wide pool: the scope is this request's,
    /// the connections are everyone's.
    /// </summary>
    public CinerionDataSource(CinerionConnectionPool pool, ProjectScope scope)
    {
        _dataSource = pool.DataSource;
        _scope = scope;
        _ownsDataSource = false;
    }

    /// <summary>
    /// Opens a connection and applies the project scope for the session.
    /// <para>
    /// The scope is applied with <c>set_config(..., false)</c> so it persists for the
    /// session rather than only the current transaction, which keeps multi-statement
    /// operations consistent on a pooled connection. It is set on every open, so a
    /// recycled connection can never inherit a previous request's scope.
    /// </para>
    /// </summary>
    public async ValueTask<NpgsqlConnection> OpenAsync(CancellationToken cancellationToken)
    {
        var connection = await _dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT set_config('ch1.project_id', $1, false)";
            command.Parameters.Add(new NpgsqlParameter
            {
                Value = _scope.Current?.ToString() ?? string.Empty,
                NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Text,
            });
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            return connection;
        }
        catch
        {
            await connection.DisposeAsync().ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Opens a connection scoped to an explicit project, for the few operations whose
    /// scope comes from the record rather than the request - appending an audit event
    /// for a project the caller is acting within, and the startup seed.
    /// </summary>
    public async ValueTask<NpgsqlConnection> OpenForProjectAsync(Guid projectId, CancellationToken cancellationToken)
    {
        var connection = await _dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT set_config('ch1.project_id', $1, false)";
            command.Parameters.Add(new NpgsqlParameter { Value = projectId.ToString() });
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            return connection;
        }
        catch
        {
            await connection.DisposeAsync().ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Applies the controlled foundation schema if the ch1 schema is absent.
    /// <para>
    /// Deliberately not a general migration runner. It creates a first-run database
    /// and otherwise does nothing: altering an existing controlled schema is a
    /// reviewed migration, not a startup side effect.
    /// </para>
    /// </summary>
    public ValueTask EnsureSchemaAsync(string migrationSql, CancellationToken cancellationToken) =>
        EnsureSchemaAsync([migrationSql], cancellationToken);

    /// <summary>
    /// Applies the ordered migration set to a first-run database, each migration as its
    /// own statement so that the explicit transaction each one declares is honoured.
    /// </summary>
    public async ValueTask EnsureSchemaAsync(
        IReadOnlyList<string> orderedMigrations,
        CancellationToken cancellationToken)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        await using (var probe = connection.CreateCommand())
        {
            probe.CommandText = "SELECT count(*) FROM information_schema.schemata WHERE schema_name = 'ch1'";
            var present = Convert.ToInt64(await probe.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false), System.Globalization.CultureInfo.InvariantCulture) > 0;
            if (present)
            {
                return;
            }
        }

        foreach (var migrationSql in orderedMigrations)
        {
            await using var apply = connection.CreateCommand();
            apply.CommandText = migrationSql;
            await apply.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
    }

    /// <summary>Confirms the database is reachable and carries the controlled schema.</summary>
    /// <summary>
    /// What this pool may ask for, and what the server will actually grant.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Npgsql's pool defaults to 100 connections and PostgreSQL defaults to
    /// <c>max_connections = 100</c> with three reserved for superusers - so an
    /// unconfigured deployment has a pool entitled to ask for more than the server will
    /// ever give. Under load the pool tries to open its ninety-eighth connection, the
    /// server refuses, and the request fails outright with a connection error rather than
    /// waiting for one of the ninety-seven it could have had. That is the difference
    /// between a service that degrades and one that breaks, and it is invisible until
    /// something offers enough load to reach it: the CH1-NFR-PER-0001 rig found it as
    /// <c>NpgsqlException: Failed to connect</c> mixed in with genuine pool timeouts.
    /// </para>
    /// <para>
    /// Reported rather than corrected here, because the pool size is a deployment
    /// decision and silently shrinking it would be this component overriding one. The
    /// caller decides what to do with the answer.
    /// </para>
    /// </remarks>
    /// <summary>
    /// Whether the deployment stated a pool size, as opposed to inheriting Npgsql's.
    /// </summary>
    /// <remarks>
    /// The difference decides what to do about an oversized pool. A deployment that asked
    /// for more than the server grants has asked for something impossible and should be
    /// told; one that asked for nothing has inherited a default it never chose, and
    /// refusing to start over that would punish every correct-enough deployment for a
    /// number nobody picked.
    /// </remarks>
    public static bool StatesPoolSize(string connectionString) =>
        connectionString.Contains("Pool Size", StringComparison.OrdinalIgnoreCase) ||
        connectionString.Contains("MaxPoolSize", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// The same connection string with a pool the server can actually honour.
    /// </summary>
    public static string WithPoolSize(string connectionString, int maximum) =>
        new NpgsqlConnectionStringBuilder(connectionString) { MaxPoolSize = maximum }.ConnectionString;

    public async ValueTask<(int PoolMaximum, int ServerGrants)> DescribeConnectionBudgetAsync(
        CancellationToken cancellationToken)
    {
        var poolMaximum = new NpgsqlConnectionStringBuilder(_dataSource.ConnectionString).MaxPoolSize;

        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText =
            "SELECT current_setting('max_connections')::int - current_setting('superuser_reserved_connections')::int";
        var granted = await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
        return (poolMaximum, Convert.ToInt32(granted, System.Globalization.CultureInfo.InvariantCulture));
    }

    public async ValueTask<int> CountControlledTablesAsync(CancellationToken cancellationToken)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'ch1'";
        var value = await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
        return Convert.ToInt32(value, System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Schema elements added after 0001 that the store depends on, with the migration
    /// that introduces each. Checked at startup so a database that has had only the
    /// foundation migration applied fails immediately and by name, rather than at the
    /// first alarm acknowledgement an operator attempts.
    /// </summary>
    private static readonly (string Table, string Column, string Migration)[] RequiredColumns =
    [
        ("alarms", "acknowledgement_comment", "0003_alarm_acknowledgement.sql"),
        ("message_acknowledgements", "message_ack_id", "0004_message_acknowledgements.sql"),
        ("resource_allocations", "cancellation_reason", "0005_reservation_cancellation.sql"),
        ("experiment_revisions", "experiment_revision_id", "0006_experiment_revisions.sql"),
        ("experiments", "promotion_change_record", "0006_experiment_revisions.sql"),
        ("devices", "revocation_reason", "0007_device_enrolment.sql"),
        ("credentials", "credential_id", "0008_credentials.sql"),
        ("webauthn_challenges", "challenge_id", "0008_credentials.sql"),
        ("reports", "report_id", "0009_reports_and_scan_events.sql"),
        ("scan_events", "scan_event_id", "0009_reports_and_scan_events.sql"),
        ("telemetry_summaries", "summary_id", "0010_telemetry_retention.sql"),
        ("telemetry_disposals", "disposal_id", "0010_telemetry_retention.sql"),
        ("role_assignments", "assignment_id", "0012_role_assignments.sql"),
        ("publication_packages", "package_id", "0013_publication_packages.sql"),
        ("publication_package_approvals", "approval_id", "0013_publication_packages.sql"),
        ("record_disposals", "disposal_id", "0014_record_retention.sql"),
        ("message_acknowledgements", "retain_until", "0014_record_retention.sql"),
        ("telemetry_samples", "source_time_quality", "0015_source_time_quality.sql"),
    ];

    /// <summary>
    /// Reports which required migrations this database is missing. Empty means the
    /// schema is at the revision the running code expects.
    /// </summary>
    public async ValueTask<IReadOnlyList<string>> FindMissingMigrationsAsync(CancellationToken cancellationToken)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        var missing = new List<string>();
        foreach (var (table, column, migration) in RequiredColumns)
        {
            await using var command = connection.CreateCommand();
            command.CommandText = """
                SELECT count(*) FROM information_schema.columns
                WHERE table_schema = 'ch1' AND table_name = $1 AND column_name = $2
                """;
            command.Parameters.Add(new NpgsqlParameter { Value = table });
            command.Parameters.Add(new NpgsqlParameter { Value = column });
            var present = Convert.ToInt64(
                await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false),
                System.Globalization.CultureInfo.InvariantCulture) > 0;
            if (!present && !missing.Contains(migration, StringComparer.Ordinal))
            {
                missing.Add(migration);
            }
        }

        return missing;
    }

    /// <summary>
    /// Disposes the pool only if this object created it. A per-request data source over
    /// the shared pool must leave it standing for the next request.
    /// </summary>
    public ValueTask DisposeAsync() =>
        _ownsDataSource ? _dataSource.DisposeAsync() : ValueTask.CompletedTask;
}
