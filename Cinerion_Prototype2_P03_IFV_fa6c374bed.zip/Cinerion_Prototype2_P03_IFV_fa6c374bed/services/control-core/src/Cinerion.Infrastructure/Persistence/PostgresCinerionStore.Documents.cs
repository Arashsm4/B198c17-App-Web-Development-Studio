// PostgreSQL storage for the document register and publication packages.

using System.Text.Json;
using Cinerion.Domain.Documents;
using Npgsql;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// The controlled document register and the publication pipeline, on the schema 0001 and
/// 0013 provide.
/// </summary>
/// <remarks>
/// <c>ch1.controlled_documents</c> has existed since 0001 and nothing read it, because the
/// operations that would have were the gated vault. CH1-DOC-FR-0001 is the part that needs
/// no vault, and the publication pipeline needs exactly the fields it declares.
/// <see cref="ControlledDocumentRecord.WrappedKeyReference"/> is read and never
/// dereferenced: resolving it would be CH1-DOC-FR-0002.
/// </remarks>
/// <requirements>CH1-DOC-FR-0001, CH1-DOC-FR-0004</requirements>
public sealed partial class PostgresCinerionStore
{
    private const string ControlledDocumentProjection = """
        SELECT document_id, project_id, document_number, revision, issue_status,
               classification, content_sha256, representation_uri, wrapped_key_reference,
               authorised_at
        FROM ch1.controlled_documents
        """;

    public async ValueTask<ControlledDocumentRecord?> FindControlledDocumentAsync(
        Guid documentId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ControlledDocumentProjection + " WHERE document_id = $1";
        command.Parameters.Add(Param(documentId));
        return await ReadOneAsync(command, ReadControlledDocument, cancellationToken).ConfigureAwait(false);
    }

    private static ControlledDocumentRecord ReadControlledDocument(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3), r.GetString(4),
        r.GetString(5), r.GetString(6), r.GetString(7),
        r.IsDBNull(8) ? null : r.GetString(8),
        r.GetFieldValue<DateTimeOffset>(9));

    public async ValueTask SaveControlledDocumentAsync(
        ControlledDocumentRecord document,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(document);
        await using var connection = await dataSource
            .OpenForProjectAsync(document.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.controlled_documents(
                document_id, project_id, document_number, revision, issue_status,
                classification, content_sha256, representation_uri, wrapped_key_reference,
                authorised_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            ON CONFLICT (document_id) DO UPDATE SET
              issue_status = EXCLUDED.issue_status,
              classification = EXCLUDED.classification,
              content_sha256 = EXCLUDED.content_sha256,
              representation_uri = EXCLUDED.representation_uri,
              wrapped_key_reference = EXCLUDED.wrapped_key_reference
            """;
        AddAll(
            command, document.DocumentId, document.ProjectId, document.DocumentNumber,
            document.Revision, document.IssueStatus, document.Classification,
            document.ContentSha256, document.RepresentationUri);
        command.Parameters.Add(Nullable(document.WrappedKeyReference));
        command.Parameters.Add(Param(document.AuthorisedAt));
        await ExecuteMappingConflictsAsync(
            command,
            "DOCUMENT_REVISION_CONFLICT",
            "That document number, revision and issue status already exist.",
            cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------- publication packages

    private const string PublicationPackageProjection = """
        SELECT package_id, project_id, redaction_profile, profile_revision, title,
               source_documents, content_sha256, media_type, size_bytes, storage_uri,
               metadata_removed, metadata_retained, secret_scan_profile, secret_scan_patterns,
               content_diff_performed, content_diff_note, state, created_by, created_at,
               decided_at, version
        FROM ch1.publication_packages
        """;

    public async ValueTask<PublicationPackage?> FindPublicationPackageAsync(
        Guid packageId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = PublicationPackageProjection + " WHERE package_id = $1";
        command.Parameters.Add(Param(packageId));
        return await ReadOneAsync(command, ReadPublicationPackage, cancellationToken).ConfigureAwait(false);
    }

    private static PublicationPackage ReadPublicationPackage(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3), r.GetString(4),
        JsonSerializer.Deserialize<List<PublicationSource>>(r.GetString(5), Json) ?? [],
        r.GetString(6), r.GetString(7), r.GetInt64(8), r.GetString(9),
        JsonSerializer.Deserialize<List<string>>(r.GetString(10), Json) ?? [],
        JsonSerializer.Deserialize<Dictionary<string, string>>(r.GetString(11), Json) ?? [],
        r.GetString(12), r.GetInt32(13), r.GetBoolean(14), r.GetString(15),
        Enum.Parse<PublicationState>(r.GetString(16)),
        r.GetString(17), r.GetFieldValue<DateTimeOffset>(18),
        r.IsDBNull(19) ? null : r.GetFieldValue<DateTimeOffset>(19),
        r.GetInt64(20));

    public async ValueTask SavePublicationPackageAsync(
        PublicationPackage package,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(package);
        await using var connection = await dataSource
            .OpenForProjectAsync(package.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();

        // The state and the decision time are the only columns an update may move. What the
        // pipeline found - the sources, the checksum, what was scrubbed, what was scanned -
        // is what the reviewers were shown, and a later write that could change it would
        // make an approval evidence for something else.
        command.CommandText = """
            INSERT INTO ch1.publication_packages(
                package_id, project_id, redaction_profile, profile_revision, title,
                source_documents, content_sha256, media_type, size_bytes, storage_uri,
                metadata_removed, metadata_retained, secret_scan_profile, secret_scan_patterns,
                content_diff_performed, content_diff_note, state, created_by, created_at,
                decided_at, version)
            VALUES($1, $2, $3, $4, $5, $6::jsonb, $7, $8, $9, $10, $11::jsonb, $12::jsonb,
                   $13, $14, $15, $16, $17, $18, $19, $20, $21)
            ON CONFLICT (package_id) DO UPDATE SET
              state = EXCLUDED.state,
              decided_at = EXCLUDED.decided_at,
              version = EXCLUDED.version
            """;
        AddAll(
            command, package.PackageId, package.ProjectId, package.RedactionProfile,
            package.ProfileRevision, package.Title,
            JsonSerializer.Serialize(package.Sources, Json),
            package.ContentSha256, package.MediaType, package.SizeBytes, package.StorageUri,
            JsonSerializer.Serialize(package.MetadataRemoved, Json),
            JsonSerializer.Serialize(package.MetadataRetained, Json),
            package.SecretScanProfile, package.SecretScanPatterns,
            package.ContentDiffPerformed, package.ContentDiffNote,
            package.State.ToString(), package.CreatedBy, package.CreatedAt);
        command.Parameters.Add(Nullable(package.DecidedAt));
        command.Parameters.Add(Param(package.Version));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    private const string PublicationApprovalProjection = """
        SELECT approval_id, project_id, package_id, reviewer_capacity, decision,
               reviewed_by, reviewed_role, reviewed_checksum, comment, reviewed_at
        FROM ch1.publication_package_approvals
        """;

    public async ValueTask<IReadOnlyList<PublicationApproval>> ListPublicationApprovalsAsync(
        Guid projectId,
        Guid packageId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = PublicationApprovalProjection +
            " WHERE package_id = $1 ORDER BY reviewed_at, approval_id";
        command.Parameters.Add(Param(packageId));
        return await ReadManyAsync(command, ReadPublicationApproval, cancellationToken).ConfigureAwait(false);
    }

    private static PublicationApproval ReadPublicationApproval(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2),
        Enum.Parse<ReviewerCapacity>(r.GetString(3)),
        Enum.Parse<PublicationState>(r.GetString(4)),
        r.GetString(5), r.GetString(6), r.GetString(7), r.GetString(8),
        r.GetFieldValue<DateTimeOffset>(9));

    public async ValueTask SavePublicationApprovalAsync(
        PublicationApproval approval,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(approval);
        await using var connection = await dataSource
            .OpenForProjectAsync(approval.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();

        // No ON CONFLICT. The UNIQUE (package_id, reviewer_capacity) constraint is the
        // authoritative guard on "one decision per capacity", and an upsert would let a
        // reviewer quietly replace their own recorded decision.
        command.CommandText = """
            INSERT INTO ch1.publication_package_approvals(
                approval_id, project_id, package_id, reviewer_capacity, decision,
                reviewed_by, reviewed_role, reviewed_checksum, comment, reviewed_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """;
        AddAll(
            command, approval.ApprovalId, approval.ProjectId, approval.PackageId,
            approval.Capacity.ToString(), approval.Decision.ToString(),
            approval.ReviewedBy, approval.ReviewedRole, approval.ReviewedChecksum,
            approval.Comment, approval.ReviewedAt);
        await ExecuteMappingConflictsAsync(
            command,
            "PUBLICATION_CAPACITY_ALREADY_REVIEWED",
            "That capacity has already reviewed this package.",
            cancellationToken).ConfigureAwait(false);
    }
}
