// Wires PostgreSQL storage into the host, in one place.

using Cinerion.Application.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// How PostgreSQL storage is wired into a host, in one place.
/// </summary>
/// <remarks>
/// <para>
/// The lifetimes here are the whole point of the type existing. Two of these five
/// registrations are load-bearing and neither announces itself if it is wrong:
/// </para>
/// <list type="bullet">
/// <item><description>
/// <see cref="CinerionConnectionPool"/> is a <b>singleton</b>. It is the connection pool,
/// and a pool that ends with the request pools nothing - every request would open fresh
/// physical connections, at 13.3 ms of TCP, startup and authentication each, and ask
/// PostgreSQL to fork a backend for every one of them. Nothing fails; the service simply
/// cannot carry load, which is how it went unnoticed.
/// </description></item>
/// <item><description>
/// <see cref="ProjectScope"/> and <see cref="CinerionDataSource"/> are <b>scoped</b>,
/// because row-level security is keyed on the project of the request being served. A
/// singleton scope would mean one request's project governing another's reads.
/// </description></item>
/// </list>
/// <para>
/// Program.cs used to hold this inline, where the lifetimes could only be checked by
/// reading them. Here they can be executed: see <c>PostgresStorageRegistrationTests</c>,
/// which resolves two scopes out of this graph and asks PostgreSQL which backend served
/// each.
/// </para>
/// </remarks>
/// <requirements>CH1-DBA-FR-0001, CH1-CYB-FR-0001, CH1-NFR-PER-0001</requirements>
public static class PostgresStorageRegistration
{
    public static IServiceCollection AddCinerionPostgresStorage(
        this IServiceCollection services,
        string connectionString)
    {
        ArgumentNullException.ThrowIfNull(services);
        ArgumentException.ThrowIfNullOrWhiteSpace(connectionString);

        // Per request: populated from the authenticated identity before any store call, so
        // row-level security filters every query for that caller.
        services.AddScoped<ProjectScope>();

        // Per process: the pool.
        services.AddSingleton(new CinerionConnectionPool(connectionString));

        // Per request, over the shared pool. The scope is this request's; the connections
        // are everyone's.
        services.AddScoped(provider => new CinerionDataSource(
            provider.GetRequiredService<CinerionConnectionPool>(),
            provider.GetRequiredService<ProjectScope>()));

        // Per process: a step-up grant issued by one request must still be redeemable by
        // the next, while a restart deliberately forces re-authentication.
        services.AddSingleton<StepUpGrantCache>();

        services.AddScoped<ICinerionStore, PostgresCinerionStore>();
        return services;
    }
}
