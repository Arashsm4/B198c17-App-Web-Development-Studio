// PostgreSQL storage for experiments and their runs.

using Cinerion.Domain.Common;
using Cinerion.Domain.Research;
using Npgsql;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Experiments and their immutable run provenance on the controlled schema.
/// </summary>
/// <requirements>CH1-RND-FR-0001, CH1-RND-FR-0002, CH1-RND-FR-0003</requirements>
public sealed partial class PostgresCinerionStore
{
    // ------------------------------------------------------------- experiments

    private const string ExperimentProjection = """
        SELECT experiment_id, project_id, owner_id, objective, environment, status, version, created_at,
               promotion_change_record, promotion_impact_analysis, promotion_verification,
               promotion_requested_by, promotion_requested_at, production_authority
        FROM ch1.experiments
        """;

    public async ValueTask<Experiment?> FindExperimentAsync(Guid experimentId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ExperimentProjection + " WHERE experiment_id = $1";
        command.Parameters.Add(Param(experimentId));
        return await ReadOneAsync(command, ReadExperiment, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Experiments in one project, newest first.
    /// </summary>
    /// <remarks>
    /// Row-level security is the isolation here, exactly as it is for every other read.
    /// CH1-RND-FR-0001 keeps R&D apart from controlled production, and that separation is a
    /// property of what an experiment may DO - it holds no production authority until an
    /// explicit, authorised transition - not of whether the project's own people may see
    /// that it exists.
    /// </remarks>
    public async ValueTask<IReadOnlyList<Experiment>> ListExperimentsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ExperimentProjection + " ORDER BY created_at DESC, experiment_id DESC LIMIT $1";
        command.Parameters.Add(Param(Math.Clamp(limit, 1, 500)));
        return await ReadManyAsync(command, ReadExperiment, cancellationToken).ConfigureAwait(false);
    }

    private static Experiment ReadExperiment(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3),
        Enum.Parse<ExperimentEnvironment>(r.GetString(4)),
        Enum.Parse<ExperimentStatus>(r.GetString(5)),
        r.GetInt64(6), r.GetFieldValue<DateTimeOffset>(7),
        r.IsDBNull(8) ? null : r.GetString(8),
        r.IsDBNull(9) ? null : r.GetString(9),
        r.IsDBNull(10) ? null : r.GetString(10),
        r.IsDBNull(11) ? null : r.GetString(11),
        r.IsDBNull(12) ? null : r.GetFieldValue<DateTimeOffset>(12),
        r.GetBoolean(13));

    public async ValueTask SaveExperimentAsync(
        Experiment experiment,
        long? expectedVersion,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(experiment.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();

        // Each branch declares only what its own statement references, so PostgreSQL can
        // infer every parameter's type.
        if (expectedVersion is null)
        {
            command.CommandText = """
                INSERT INTO ch1.experiments(experiment_id, project_id, owner_id, objective, environment,
                    production_authority, status, version, created_at)
                VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """;
            AddAll(
                command, experiment.ExperimentId, experiment.ProjectId, experiment.OwnerId, experiment.Objective,
                experiment.Environment.ToString(), experiment.ProductionAuthority, experiment.Status.ToString(),
                experiment.Version, experiment.CreatedAt);
        }
        else
        {
            // The owner, objective, environment and creation time are absent: what was
            // defined is not rewritten, only the lifecycle it reached. Environment in
            // particular is never updated here, so no path through this store can move an
            // experiment into controlled bench mode.
            command.CommandText = """
                UPDATE ch1.experiments SET
                  status = $2, version = $3,
                  promotion_change_record = $4, promotion_impact_analysis = $5,
                  promotion_verification = $6, promotion_requested_by = $7, promotion_requested_at = $8
                WHERE experiment_id = $1 AND version = $9
                """;
            AddAll(command, experiment.ExperimentId, experiment.Status.ToString(), experiment.Version);
            command.Parameters.Add(Nullable(experiment.PromotionChangeRecord));
            command.Parameters.Add(Nullable(experiment.PromotionImpactAnalysis));
            command.Parameters.Add(Nullable(experiment.PromotionVerification));
            command.Parameters.Add(Nullable(experiment.PromotionRequestedBy));
            command.Parameters.Add(Nullable(experiment.PromotionRequestedAt));
            command.Parameters.Add(Param(expectedVersion.Value));
        }

        int affected;
        try
        {
            affected = await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.CheckViolation)
        {
            // ch1.experiments constrains production_authority, the environment set and
            // the promotion columns. Reported as the domain rule rather than a database
            // fault, so a caller sees why it was refused.
            throw new DomainRuleException(
                "EXPERIMENT_REJECTED",
                "The experiment violates a controlled constraint on R&D records.");
        }

        if (expectedVersion is not null && affected == 0)
        {
            throw new DomainRuleException("CONCURRENCY_CONFLICT", "The experiment changed since it was read.");
        }
    }

    // -------------------------------------------------- experiment revisions

    private const string RevisionProvenanceProjection = """
        SELECT experiment_revision_id, project_id, experiment_id, revision_number, environment,
               configuration_reference, configuration_sha256, model_reference, input_reference, input_sha256,
               result_summary, result_sha256, requested_by, executed_by, started_at, finished_at,
               production_authority
        FROM ch1.experiment_revisions
        """;

    private static ExperimentRevision ReadExperimentRevision(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetInt32(3),
        Enum.Parse<ExperimentEnvironment>(r.GetString(4)),
        r.GetString(5), r.GetString(6), r.GetString(7), r.GetString(8), r.GetString(9),
        r.GetString(10), r.GetString(11), r.GetString(12), r.GetString(13),
        r.GetFieldValue<DateTimeOffset>(14), r.GetFieldValue<DateTimeOffset>(15),
        r.GetBoolean(16));

    public async ValueTask<IReadOnlyList<ExperimentRevision>> ListExperimentRevisionsAsync(
        Guid projectId,
        Guid experimentId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = RevisionProvenanceProjection +
            " WHERE experiment_id = $1 ORDER BY revision_number";
        command.Parameters.Add(Param(experimentId));
        return await ReadManyAsync(command, ReadExperimentRevision, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Appends the run and advances the experiment together. The revision table carries
    /// an append-only trigger, so a run written without its experiment moving on could
    /// never be reconciled afterwards.
    /// </summary>
    public async ValueTask SaveExperimentRevisionAsync(
        ExperimentRevision revision,
        Experiment experiment,
        long expectedExperimentVersion,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(revision.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

        await using (var advance = connection.CreateCommand())
        {
            advance.Transaction = transaction;
            advance.CommandText = """
                UPDATE ch1.experiments SET status = $2, version = $3
                WHERE experiment_id = $1 AND version = $4
                """;
            AddAll(
                advance, experiment.ExperimentId, experiment.Status.ToString(),
                experiment.Version, expectedExperimentVersion);
            if (await advance.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false) == 0)
            {
                throw new DomainRuleException("CONCURRENCY_CONFLICT", "The experiment changed since it was read.");
            }
        }

        await using (var write = connection.CreateCommand())
        {
            write.Transaction = transaction;
            write.CommandText = """
                INSERT INTO ch1.experiment_revisions(experiment_revision_id, project_id, experiment_id,
                    revision_number, environment, configuration_reference, configuration_sha256, model_reference,
                    input_reference, input_sha256, result_summary, result_sha256, requested_by, executed_by,
                    started_at, finished_at, production_authority)
                VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
                """;
            AddAll(
                write, revision.ExperimentRevisionId, revision.ProjectId, revision.ExperimentId,
                revision.RevisionNumber, revision.Environment.ToString(), revision.ConfigurationReference,
                revision.ConfigurationSha256, revision.ModelReference, revision.InputReference,
                revision.InputSha256, revision.ResultSummary, revision.ResultSha256, revision.RequestedBy,
                revision.ExecutedBy, revision.StartedAt, revision.FinishedAt, revision.ProductionAuthority);
            try
            {
                await write.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
            {
                throw new DomainRuleException(
                    "EXPERIMENT_REVISION_CONFLICT",
                    "That experiment revision number is already recorded.");
            }
            catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.CheckViolation)
            {
                throw new DomainRuleException(
                    "EXPERIMENT_REVISION_REJECTED",
                    "The run violates a controlled constraint on experiment revisions.");
            }
        }

        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
    }
}
