// Picks in-memory or PostgreSQL, and refuses to guess when nobody said which.

namespace Cinerion.Infrastructure.Persistence;

public enum CinerionStorageMode
{
    /// <summary>Volatile store for development and automated tests only.</summary>
    InMemory,

    /// <summary>Persistent operational state in PostgreSQL.</summary>
    Postgres,
}

public sealed record StorageSelection(CinerionStorageMode Mode, string? ConnectionString);

/// <summary>
/// Resolves which store the service runs on.
/// <para>
/// Separated from startup so the decision can be tested directly, and because every
/// branch of it is a fail-closed rule rather than a convenience default.
/// </para>
/// </summary>
public static class StorageModeSelection
{
    /// <summary>
    /// Chooses the store, or refuses.
    /// </summary>
    /// <param name="configuredMode">CINERION_DATABASE_MODE, if set.</param>
    /// <param name="connectionString">CINERION_POSTGRES_CONNECTION, if set.</param>
    /// <param name="isDevelopment">Whether the host environment is Development.</param>
    public static StorageSelection Resolve(string? configuredMode, string? connectionString, bool isDevelopment)
    {
        // AGENTS.md requires in-memory storage to be an explicit development or test
        // mode. It was previously the unconditional default, which meant a deployment
        // that simply forgot to configure a database ran on volatile storage and lost
        // its audit chain on restart without anything saying so.
        if (string.IsNullOrWhiteSpace(configuredMode))
        {
            if (!isDevelopment)
            {
                throw new InvalidOperationException(
                    "CINERION_DATABASE_MODE must be set explicitly outside Development. " +
                    "Persistent operational state uses PostgreSQL; in-memory storage is a development and test mode only.");
            }

            return new StorageSelection(CinerionStorageMode.InMemory, null);
        }

        if (!Enum.TryParse<CinerionStorageMode>(configuredMode, ignoreCase: true, out var mode))
        {
            throw new InvalidOperationException(
                $"Unknown CINERION_DATABASE_MODE '{configuredMode}'. Valid values are InMemory and Postgres.");
        }

        if (mode == CinerionStorageMode.InMemory && !isDevelopment)
        {
            throw new InvalidOperationException(
                "In-memory storage is a development and test mode and is forbidden outside Development. " +
                "Operational state must be persistent.");
        }

        if (mode == CinerionStorageMode.Postgres && string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                "CINERION_POSTGRES_CONNECTION is required when CINERION_DATABASE_MODE=Postgres.");
        }

        return new StorageSelection(mode, connectionString);
    }
}
