// PostgreSQL storage for telemetry and alarms.

using System.Text;
using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;
using Npgsql;
using NpgsqlTypes;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Telemetry and alarms on the controlled schema.
/// </summary>
/// <requirements>CH1-MON-FR-0001, CH1-MON-FR-0002, CH1-AUT-FDS-0001, CH1-COL-FR-0003</requirements>
public sealed partial class PostgresCinerionStore
{
    // --------------------------------------------------------------- telemetry

    private const string TelemetryProjection = """
        SELECT sample_id, project_id, cell_id, device_id, channel_id, value, unit,
               quality::text, freshness::text, sampled_at, received_at, time_quality,
               source_time_quality
        FROM ch1.telemetry_samples
        """;

    /// <summary>
    /// Writes a burst in one transaction. A partially written burst would leave a gap
    /// that a later reader cannot distinguish from a period with no data.
    /// </summary>
    public async ValueTask AppendTelemetryAsync(
        IReadOnlyList<TelemetrySample> samples,
        CancellationToken cancellationToken)
    {
        if (samples.Count == 0)
        {
            return;
        }

        // Every sample in a burst belongs to one project; the connection carries that
        // project's row-level security scope, so a mixed burst could not be written and
        // must not be attempted silently.
        var projectId = samples[0].ProjectId;
        foreach (var sample in samples)
        {
            if (sample.ProjectId != projectId)
            {
                throw new DomainRuleException(
                    "TELEMETRY_BATCH_PROJECT_MIXED",
                    "A telemetry batch must belong to a single project.");
            }
        }

        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

        // One exchange for the whole burst rather than one per sample.
        //
        // The statement, its ON CONFLICT and the surrounding transaction are unchanged; what
        // changes is that Npgsql writes every INSERT before waiting for any of them to be
        // acknowledged. Sending them one at a time made a burst of four readings cost seven
        // round trips - set_config, BEGIN, four INSERTs and COMMIT - of which four were pure
        // network latency, and the same connection was held out of the pool for all of them.
        // CH1-NFR-PER-0001 asks for 100 messages a second; at four readings each that was
        // 700 round trips a second spent mostly waiting, and the pool has 100 connections.
        await using var batch = new NpgsqlBatch(connection, transaction);
        foreach (var sample in samples)
        {
            var command = new NpgsqlBatchCommand("""
                INSERT INTO ch1.telemetry_samples(sample_id, project_id, cell_id, device_id, channel_id,
                    value, unit, quality, freshness, sampled_at, received_at, time_quality,
                    source_time_quality)
                VALUES($1, $2, $3, $4, $5, $6, $7, $8::ch1.data_quality, $9::ch1.freshness, $10, $11, $12, $13)
                ON CONFLICT (sample_id, sampled_at) DO NOTHING
                """);
            AddAll(
                command, sample.SampleId, sample.ProjectId, sample.CellId, sample.DeviceId, sample.ChannelId,
                sample.Value, sample.Unit, sample.Quality.ToString(), sample.Freshness.ToString(),
                sample.SampledAt, sample.ReceivedAt, sample.TimeQuality);
            // Nullable, and written as NULL rather than as an empty string: "the source
            // declared nothing" and "the source declared nothing in particular" are not
            // the same fact, and only one of them is honest here.
            command.Parameters.Add(new NpgsqlParameter
            {
                Value = (object?)sample.SourceTimeQuality ?? DBNull.Value,
                NpgsqlDbType = NpgsqlDbType.Text,
            });
            batch.BatchCommands.Add(command);
        }

        await batch.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<TelemetrySample>> QueryTelemetryAsync(
        TelemetryQuery query,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(query.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();

        // The window is always present, so every query is bounded in time as well as in
        // rows and can use ix_telemetry_project_time rather than scanning partitions.
        var sql = new StringBuilder(TelemetryProjection)
            .Append(" WHERE sampled_at >= $1 AND sampled_at <= $2")
            .Append(" AND ($3::uuid IS NULL OR cell_id = $3)")
            .Append(" AND ($4::text IS NULL OR device_id = $4)")
            .Append(" AND ($5::text[] IS NULL OR channel_id = ANY($5))")
            .Append(" ORDER BY sampled_at DESC, sample_id LIMIT $6");
        command.CommandText = sql.ToString();
        AddAll(command, query.From, query.To);
        command.Parameters.Add(Nullable(query.CellId));
        command.Parameters.Add(Nullable(query.DeviceId));
        command.Parameters.Add(new NpgsqlParameter
        {
            Value = query.ChannelIds.Count == 0 ? DBNull.Value : query.ChannelIds.ToArray(),
            NpgsqlDbType = NpgsqlDbType.Array | NpgsqlDbType.Text,
        });
        command.Parameters.Add(Param(query.Limit));

        return await ReadManyAsync(command, ReadTelemetry, cancellationToken).ConfigureAwait(false);
    }

    private static TelemetrySample ReadTelemetry(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetString(3), r.GetString(4),
        r.GetDouble(5), r.GetString(6),
        Enum.Parse<DataQuality>(r.GetString(7)),
        Enum.Parse<Freshness>(r.GetString(8)),
        r.GetFieldValue<DateTimeOffset>(9), r.GetFieldValue<DateTimeOffset>(10), r.GetString(11),
        r.IsDBNull(12) ? null : r.GetString(12));

    // ------------------------------------------------------------------ alarms

    private const string AlarmProjection = """
        SELECT alarm_id, project_id, cell_id, source_id, alarm_code, priority, state,
               activated_at, acknowledged_by, acknowledged_at, acknowledgement_comment,
               cleared_at, cause_clear
        FROM ch1.alarms
        """;

    public async ValueTask<Alarm?> FindAlarmAsync(Guid alarmId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = AlarmProjection + " WHERE alarm_id = $1";
        command.Parameters.Add(Param(alarmId));
        return await ReadOneAsync(command, ReadAlarm, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<Alarm?> FindOutstandingAlarmAsync(
        Guid projectId,
        Guid cellId,
        string sourceId,
        string alarmCode,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = AlarmProjection +
            """
             WHERE cell_id = $1 AND source_id = $2 AND alarm_code = $3 AND cause_clear = false
             ORDER BY activated_at DESC LIMIT 1
            """;
        AddAll(command, cellId, sourceId, alarmCode);
        return await ReadOneAsync(command, ReadAlarm, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Every outstanding alarm for one source, in a single exchange.
    /// </summary>
    /// <remarks>
    /// Same predicate as the singular form, without the alarm-code narrowing and without
    /// the LIMIT: a source holds at most one outstanding alarm per code, so the newest per
    /// code is the same row the singular query would have returned for each.
    /// </remarks>
    public async ValueTask<IReadOnlyList<Alarm>> FindOutstandingAlarmsAsync(
        Guid projectId,
        Guid cellId,
        string sourceId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = AlarmProjection +
            """
             WHERE cell_id = $1 AND source_id = $2 AND cause_clear = false
             ORDER BY activated_at DESC
            """;
        AddAll(command, cellId, sourceId);
        return await ReadManyAsync(command, ReadAlarm, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveAlarmAsync(Alarm alarm, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(alarm.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // activated_at, priority, source_id and alarm_code are deliberately absent from
        // the update: the record of what was raised and when is not rewritten by any
        // later event, and acknowledgement in particular must leave the cause columns
        // exactly as the equipment set them.
        command.CommandText = """
            INSERT INTO ch1.alarms(alarm_id, project_id, cell_id, source_id, alarm_code, priority, state,
                activated_at, acknowledged_by, acknowledged_at, acknowledgement_comment, cleared_at, cause_clear)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            ON CONFLICT (alarm_id) DO UPDATE SET
              state = EXCLUDED.state,
              acknowledged_by = EXCLUDED.acknowledged_by,
              acknowledged_at = EXCLUDED.acknowledged_at,
              acknowledgement_comment = EXCLUDED.acknowledgement_comment,
              cleared_at = EXCLUDED.cleared_at,
              cause_clear = EXCLUDED.cause_clear
            """;
        AddAll(
            command, alarm.AlarmId, alarm.ProjectId, alarm.CellId, alarm.SourceId, alarm.AlarmCode,
            alarm.Priority, alarm.State.ToString(), alarm.ActivatedAt);
        command.Parameters.Add(Nullable(alarm.AcknowledgedBy));
        command.Parameters.Add(Nullable(alarm.AcknowledgedAt));
        command.Parameters.Add(Nullable(alarm.AcknowledgementComment));
        command.Parameters.Add(Nullable(alarm.ClearedAt));
        command.Parameters.Add(Param(alarm.CauseClear));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<Alarm>> ListAlarmsAsync(
        AlarmQuery query,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(query.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();

        // Keyset paging over the whole sort key. An OFFSET would skip or repeat rows
        // while alarms are being raised, which on an alarm list means an operator can
        // page past an alarm that was never displayed.
        // The cursor comparison is written out rather than using a row-value comparison,
        // because activated_at is ordered DESC while the other two keys ascend and a
        // single (a, b, c) > (x, y, z) would silently order all three the same way.
        command.CommandText = AlarmProjection +
            """
             WHERE ($1::uuid IS NULL OR cell_id = $1)
               AND ($2::text[] IS NULL OR state = ANY($2))
               AND ($3::int IS NULL OR priority <= $3)
               AND ($4::int IS NULL OR (
                       priority > $4
                    OR (priority = $4 AND activated_at < $5::timestamptz)
                    OR (priority = $4 AND activated_at = $5::timestamptz AND alarm_id > $6::uuid)))
             ORDER BY priority, activated_at DESC, alarm_id
             LIMIT $7
            """;
        command.Parameters.Add(Nullable(query.CellId));
        command.Parameters.Add(new NpgsqlParameter
        {
            Value = query.States.Count == 0
                ? DBNull.Value
                : query.States.Select(state => state.ToString()).ToArray(),
            NpgsqlDbType = NpgsqlDbType.Array | NpgsqlDbType.Text,
        });
        command.Parameters.Add(Nullable(query.MaximumPriority));
        command.Parameters.Add(Nullable(query.After?.Priority));
        command.Parameters.Add(Nullable(query.After?.ActivatedAt));
        command.Parameters.Add(Nullable(query.After?.AlarmId));
        command.Parameters.Add(Param(query.Limit));

        return await ReadManyAsync(command, ReadAlarm, cancellationToken).ConfigureAwait(false);
    }

    private static Alarm ReadAlarm(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetString(3), r.GetString(4), r.GetInt32(5),
        Enum.Parse<AlarmState>(r.GetString(6)),
        r.GetFieldValue<DateTimeOffset>(7),
        r.IsDBNull(8) ? null : r.GetString(8),
        r.IsDBNull(9) ? null : r.GetFieldValue<DateTimeOffset>(9),
        r.IsDBNull(10) ? null : r.GetString(10),
        r.IsDBNull(11) ? null : r.GetFieldValue<DateTimeOffset>(11),
        r.GetBoolean(12));
}
