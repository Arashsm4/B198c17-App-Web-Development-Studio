// The PostgreSQL store's core: connections, scope, and the shared plumbing the partial files
// lean on.

using System.Collections.Concurrent;
using System.Text.Json;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Manufacturing;
using Cinerion.Domain.Security;
using Npgsql;
using NpgsqlTypes;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Persistent operational state in PostgreSQL, mapped onto the controlled schema in
/// 0001_ch1_foundation.sql.
/// <para>
/// Every read and write travels through a connection that has already applied the
/// caller's project scope, so row-level security is the outermost filter rather than
/// something each query has to remember.
/// </para>
/// </summary>
/// <requirements>CH1-DBA-FR-0001, CH1-TRC-FR-0002, CH1-CYB-FR-0001</requirements>
/// <summary>
/// Step-up grants live here rather than in the database.
/// <para>
/// They are five-minute, single-use session artefacts with no controlled entity and
/// no table in the schema, and their issue and redemption are already recorded
/// permanently in the audit chain. The cache is a singleton because the store itself
/// is per request: a grant issued by one request must still be redeemable by the
/// next, while a process restart deliberately forces re-authentication.
/// </para>
/// </summary>
public sealed class StepUpGrantCache
{
    private readonly ConcurrentDictionary<Guid, StepUpGrant> _grants = new();

    public void Save(StepUpGrant grant) => _grants[grant.GrantId] = grant;

    public StepUpGrant? Find(Guid grantId) => _grants.GetValueOrDefault(grantId);
}

public sealed partial class PostgresCinerionStore(CinerionDataSource dataSource, StepUpGrantCache stepUpGrants)
    : ICinerionStore
{

    internal static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    // ---------------------------------------------------------------- projects

    private const string ProjectProjection =
        "SELECT project_id, project_code, name, baseline, version, created_at FROM ch1.projects";

    public async ValueTask<ProjectRecord?> FindProjectAsync(Guid projectId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ProjectProjection + " WHERE project_id = $1";
        command.Parameters.Add(Param(projectId));
        return await ReadOneAsync(command, ReadProject, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Project-code uniqueness spans projects, which row-level security hides. The
    /// authoritative guard is the UNIQUE constraint; this reports only what the caller
    /// may legitimately see.
    /// </summary>
    public async ValueTask<ProjectRecord?> FindProjectByCodeAsync(string projectCode, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ProjectProjection + " WHERE project_code = $1";
        command.Parameters.Add(Param(projectCode));
        return await ReadOneAsync(command, ReadProject, cancellationToken).ConfigureAwait(false);
    }

    private static ProjectRecord ReadProject(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetString(1), r.GetString(2), r.GetString(3), r.GetInt64(4), r.GetFieldValue<DateTimeOffset>(5));

    public async ValueTask SaveProjectAsync(ProjectRecord project, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(project.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.projects(project_id, project_code, name, baseline, version, created_at)
            VALUES($1, $2, $3, $4, $5, $6)
            ON CONFLICT (project_id) DO UPDATE SET
              project_code = EXCLUDED.project_code, name = EXCLUDED.name,
              baseline = EXCLUDED.baseline, version = EXCLUDED.version
            """;
        AddAll(command, project.ProjectId, project.ProjectCode, project.Name, project.Baseline, project.Version, project.CreatedAt);
        await ExecuteMappingConflictsAsync(command, "PROJECT_CODE_CONFLICT", "The project code is already assigned.", cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------------- sites

    public async ValueTask<SiteRecord?> FindSiteAsync(Guid siteId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT site_id, project_id, name, simulated, version FROM ch1.sites WHERE site_id = $1";
        command.Parameters.Add(Param(siteId));
        return await ReadOneAsync(
            command,
            r => new SiteRecord(r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetBoolean(3), r.GetInt64(4)),
            cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveSiteAsync(SiteRecord site, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(site.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.sites(site_id, project_id, name, simulated, version)
            VALUES($1, $2, $3, $4, $5)
            ON CONFLICT (site_id) DO UPDATE SET
              name = EXCLUDED.name, simulated = EXCLUDED.simulated, version = EXCLUDED.version
            """;
        AddAll(command, site.SiteId, site.ProjectId, site.Name, site.Simulated, site.Version);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------------ assets

    public async ValueTask<AssetRecord?> FindAssetAsync(Guid assetId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT asset_id, project_id, cell_id, asset_code, name, asset_type, configuration_revision, lifecycle_state, version
            FROM ch1.assets WHERE asset_id = $1
            """;
        command.Parameters.Add(Param(assetId));
        return await ReadOneAsync(
            command,
            r => new AssetRecord(
                r.GetGuid(0), r.GetGuid(1), r.IsDBNull(2) ? null : r.GetGuid(2), r.GetString(3),
                r.GetString(4), r.GetString(5), r.GetString(6), r.GetString(7), r.GetInt64(8)),
            cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveAssetAsync(AssetRecord asset, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(asset.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.assets(asset_id, project_id, cell_id, asset_code, name, asset_type, configuration_revision, lifecycle_state, version)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9)
            ON CONFLICT (asset_id) DO UPDATE SET
              cell_id = EXCLUDED.cell_id, asset_code = EXCLUDED.asset_code, name = EXCLUDED.name,
              asset_type = EXCLUDED.asset_type, configuration_revision = EXCLUDED.configuration_revision,
              lifecycle_state = EXCLUDED.lifecycle_state, version = EXCLUDED.version
            """;
        command.Parameters.Add(Param(asset.AssetId));
        command.Parameters.Add(Param(asset.ProjectId));
        command.Parameters.Add(Nullable(asset.CellId));
        AddAll(command, asset.AssetCode, asset.Name, asset.AssetType, asset.ConfigurationRevision, asset.LifecycleState, asset.Version);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    // ----------------------------------------------------------------- devices

    public async ValueTask<DeviceRecord?> FindDeviceAsync(string deviceId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = DeviceProjection + " WHERE device_id = $1";
        command.Parameters.Add(Param(deviceId));
        return await ReadOneAsync(command, ReadDevice, cancellationToken).ConfigureAwait(false);
    }

    private const string DeviceProjection = """
        SELECT device_id, project_id, cell_id, device_type, firmware_version, configuration_revision,
               certificate_thumbprint, trust_state, last_seen_at, revoked_at, version,
               capability_manifest, revocation_reason, revoked_by
        FROM ch1.devices
        """;

    private static DeviceRecord ReadDevice(NpgsqlDataReader r) => new(
        r.GetString(0), r.GetGuid(1), r.IsDBNull(2) ? null : r.GetGuid(2), r.GetString(3),
        r.GetString(4), r.GetString(5), r.IsDBNull(6) ? null : r.GetString(6), r.GetString(7),
        r.IsDBNull(8) ? null : r.GetFieldValue<DateTimeOffset>(8),
        r.IsDBNull(9) ? null : r.GetFieldValue<DateTimeOffset>(9), r.GetInt64(10),
        ReadManifest(r.GetString(11)),
        r.IsDBNull(12) ? null : r.GetString(12),
        r.IsDBNull(13) ? null : r.GetString(13));

    /// <summary>
    /// An unenrolled device carries the empty object the column defaults to, which is not
    /// a manifest. Returning null for it keeps "declared nothing" distinct from "declared
    /// an empty set", so the telemetry allowlist can tell them apart.
    /// </summary>
    private static DeviceCapabilityManifest? ReadManifest(string json) =>
        string.IsNullOrWhiteSpace(json) || json == "{}"
            ? null
            : JsonSerializer.Deserialize<DeviceCapabilityManifest>(json, Json);

    /// <summary>Finds the device already holding this certificate, if any.</summary>
    public async ValueTask<DeviceRecord?> FindDeviceByThumbprintAsync(
        Guid projectId,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = DeviceProjection + " WHERE certificate_thumbprint = $1";
        command.Parameters.Add(Param(thumbprint));
        return await ReadOneAsync(command, ReadDevice, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveDeviceAsync(DeviceRecord device, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(device.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.devices(device_id, project_id, cell_id, device_type, firmware_version, configuration_revision,
                                    certificate_thumbprint, trust_state, capability_manifest, last_seen_at, revoked_at, version,
                                    revocation_reason, revoked_by)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, $10, $11, $12, $13, $14)
            ON CONFLICT (device_id) DO UPDATE SET
              cell_id = EXCLUDED.cell_id, device_type = EXCLUDED.device_type,
              firmware_version = EXCLUDED.firmware_version, configuration_revision = EXCLUDED.configuration_revision,
              certificate_thumbprint = EXCLUDED.certificate_thumbprint, trust_state = EXCLUDED.trust_state,
              capability_manifest = EXCLUDED.capability_manifest,
              last_seen_at = EXCLUDED.last_seen_at, revoked_at = EXCLUDED.revoked_at, version = EXCLUDED.version,
              revocation_reason = EXCLUDED.revocation_reason, revoked_by = EXCLUDED.revoked_by
            """;
        command.Parameters.Add(Param(device.DeviceId));
        command.Parameters.Add(Param(device.ProjectId));
        command.Parameters.Add(Nullable(device.CellId));
        AddAll(command, device.DeviceType, device.FirmwareVersion, device.ConfigurationRevision);
        command.Parameters.Add(Nullable(device.CertificateThumbprint));
        command.Parameters.Add(Param(device.TrustState));
        command.Parameters.Add(Param(device.CapabilityManifest is null
            ? "{}"
            : JsonSerializer.Serialize(device.CapabilityManifest, Json)));
        command.Parameters.Add(Nullable(device.LastSeenAt));
        command.Parameters.Add(Nullable(device.RevokedAt));
        command.Parameters.Add(Param(device.Version));
        command.Parameters.Add(Nullable(device.RevocationReason));
        command.Parameters.Add(Nullable(device.RevokedBy));
        try
        {
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            // ux_devices_certificate_thumbprint: one certificate, one device. The same
            // certificate on two identities is a cloned credential.
            throw new DomainRuleException(
                "DEVICE_CERTIFICATE_ALREADY_ENROLLED",
                "That certificate is already enrolled for another device in this project.");
        }
    }

    // ----------------------------------------------------- calibration records

    public async ValueTask<CalibrationRecord?> FindCalibrationAsync(Guid calibrationId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT calibration_id, project_id, instrument_id, certificate_number, calibrated_at, valid_until, status
            FROM ch1.calibration_records WHERE calibration_id = $1
            """;
        command.Parameters.Add(Param(calibrationId));
        return await ReadOneAsync(
            command,
            r => new CalibrationRecord(
                r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3),
                r.GetFieldValue<DateTimeOffset>(4), r.GetFieldValue<DateTimeOffset>(5), r.GetString(6)),
            cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveCalibrationAsync(CalibrationRecord calibration, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(calibration.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.calibration_records(calibration_id, project_id, instrument_id, certificate_number, calibrated_at, valid_until, status)
            VALUES($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT (calibration_id) DO UPDATE SET
              instrument_id = EXCLUDED.instrument_id, certificate_number = EXCLUDED.certificate_number,
              calibrated_at = EXCLUDED.calibrated_at, valid_until = EXCLUDED.valid_until, status = EXCLUDED.status
            """;
        AddAll(
            command, calibration.CalibrationId, calibration.ProjectId, calibration.InstrumentId,
            calibration.CertificateNumber, calibration.CalibratedAt, calibration.ValidUntil, calibration.Status);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    /// <summary>The calibration register, newest certificate first.</summary>
    public async ValueTask<IReadOnlyList<CalibrationRecord>> ListCalibrationsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT calibration_id, project_id, instrument_id, certificate_number, calibrated_at, valid_until, status
            FROM ch1.calibration_records
            ORDER BY calibrated_at DESC, calibration_id DESC
            LIMIT $1
            """;
        command.Parameters.Add(Param(Math.Clamp(limit, 1, 500)));
        return await ReadManyAsync(
            command,
            r => new CalibrationRecord(
                r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3),
                r.GetFieldValue<DateTimeOffset>(4), r.GetFieldValue<DateTimeOffset>(5), r.GetString(6)),
            cancellationToken).ConfigureAwait(false);
    }

    /// <summary>Work orders, newest first.</summary>
    public async ValueTask<IReadOnlyList<WorkOrderRecord>> ListWorkOrdersAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = WorkOrderProjection +
            " ORDER BY released_at DESC NULLS FIRST, work_order_number DESC LIMIT $1";
        command.Parameters.Add(Param(Math.Clamp(limit, 1, 500)));
        return await ReadManyAsync(command, ReadWorkOrder, cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------- product revisions

    private const string RevisionProjection = """
        SELECT revision_id, project_id, product_code, revision_code, lifecycle_state, bom, route,
               source_checksum, released_at, superseded_at, version
        FROM ch1.product_revisions
        """;

    public async ValueTask<ProductRevisionRecord?> FindRevisionAsync(Guid revisionId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = RevisionProjection + " WHERE revision_id = $1";
        command.Parameters.Add(Param(revisionId));
        return await ReadOneAsync(command, ReadRevision, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<ProductRevisionRecord>> ListRevisionsAsync(
        Guid projectId,
        string? productCode,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = RevisionProjection +
            " WHERE ($1::text IS NULL OR product_code = $1) ORDER BY product_code, revision_code";
        command.Parameters.Add(Nullable(productCode));
        return await ReadManyAsync(command, ReadRevision, cancellationToken).ConfigureAwait(false);
    }

    private static ProductRevisionRecord ReadRevision(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3),
        Enum.Parse<RevisionLifecycleState>(r.GetString(4)),
        JsonSerializer.Deserialize<List<BomLine>>(r.GetString(5), Json) ?? [],
        JsonSerializer.Deserialize<List<RouteStep>>(r.GetString(6), Json) ?? [],
        r.GetString(7),
        r.IsDBNull(8) ? null : r.GetFieldValue<DateTimeOffset>(8),
        r.IsDBNull(9) ? null : r.GetFieldValue<DateTimeOffset>(9),
        r.GetInt64(10));

    public async ValueTask SaveRevisionAsync(ProductRevisionRecord revision, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(revision.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.product_revisions(revision_id, project_id, product_code, revision_code, lifecycle_state,
                                              bom, route, source_checksum, released_at, superseded_at, version)
            VALUES($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8, $9, $10, $11)
            ON CONFLICT (revision_id) DO UPDATE SET
              lifecycle_state = EXCLUDED.lifecycle_state, bom = EXCLUDED.bom, route = EXCLUDED.route,
              source_checksum = EXCLUDED.source_checksum, released_at = EXCLUDED.released_at,
              superseded_at = EXCLUDED.superseded_at, version = EXCLUDED.version
            """;
        AddAll(
            command, revision.RevisionId, revision.ProjectId, revision.ProductCode, revision.RevisionCode,
            revision.LifecycleState.ToString(),
            JsonSerializer.Serialize(revision.Bom, Json),
            JsonSerializer.Serialize(revision.Route, Json),
            revision.SourceChecksum);
        command.Parameters.Add(Nullable(revision.ReleasedAt));
        command.Parameters.Add(Nullable(revision.SupersededAt));
        command.Parameters.Add(Param(revision.Version));
        await ExecuteMappingConflictsAsync(command, "REVISION_CODE_CONFLICT", "That product revision code already exists.", cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------- work orders

    private const string WorkOrderProjection = """
        SELECT work_order_id, project_id, revision_id, cell_id, work_order_number, quantity, status, released_by, released_at, version
        FROM ch1.work_orders
        """;

    public async ValueTask<WorkOrderRecord?> FindWorkOrderAsync(Guid workOrderId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = WorkOrderProjection + " WHERE work_order_id = $1";
        command.Parameters.Add(Param(workOrderId));
        return await ReadOneAsync(command, ReadWorkOrder, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<WorkOrderRecord?> FindWorkOrderByNumberAsync(
        Guid projectId,
        string workOrderNumber,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = WorkOrderProjection + " WHERE work_order_number = $1";
        command.Parameters.Add(Param(workOrderNumber));
        return await ReadOneAsync(command, ReadWorkOrder, cancellationToken).ConfigureAwait(false);
    }

    private static WorkOrderRecord ReadWorkOrder(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.IsDBNull(3) ? null : r.GetGuid(3), r.GetString(4),
        r.GetInt32(5), Enum.Parse<WorkOrderStatus>(r.GetString(6)),
        r.IsDBNull(7) ? null : r.GetString(7),
        r.IsDBNull(8) ? null : r.GetFieldValue<DateTimeOffset>(8), r.GetInt64(9));

    public async ValueTask SaveWorkOrderAsync(WorkOrderRecord workOrder, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(workOrder.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.work_orders(work_order_id, project_id, revision_id, cell_id, work_order_number, quantity, status, released_by, released_at, version)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            ON CONFLICT (work_order_id) DO UPDATE SET
              cell_id = EXCLUDED.cell_id, quantity = EXCLUDED.quantity, status = EXCLUDED.status,
              released_by = EXCLUDED.released_by, released_at = EXCLUDED.released_at, version = EXCLUDED.version
            """;
        AddAll(command, workOrder.WorkOrderId, workOrder.ProjectId, workOrder.RevisionId);
        command.Parameters.Add(Nullable(workOrder.CellId));
        AddAll(command, workOrder.WorkOrderNumber, workOrder.Quantity, workOrder.Status.ToString());
        command.Parameters.Add(Nullable(workOrder.ReleasedBy));
        command.Parameters.Add(Nullable(workOrder.ReleasedAt));
        command.Parameters.Add(Param(workOrder.Version));
        await ExecuteMappingConflictsAsync(command, "WORK_ORDER_NUMBER_CONFLICT", "That work-order number already exists.", cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------ step-up (RAM)

    public ValueTask SaveStepUpGrantAsync(StepUpGrant grant, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        stepUpGrants.Save(grant);
        return ValueTask.CompletedTask;
    }

    public ValueTask<StepUpGrant?> FindStepUpGrantAsync(Guid grantId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(stepUpGrants.Find(grantId));
    }

    // ------------------------------------------------------------------ helpers

    internal static NpgsqlParameter Param(object value) => new() { Value = value };

    internal static NpgsqlParameter Nullable<T>(T? value)
        where T : struct =>
        new() { Value = value.HasValue ? value.Value : DBNull.Value };

    internal static NpgsqlParameter Nullable(string? value) =>
        new() { Value = (object?)value ?? DBNull.Value, NpgsqlDbType = NpgsqlDbType.Text };

    internal static void AddAll(NpgsqlCommand command, params object[] values) =>
        AddAll(command.Parameters, values);

    /// <summary>
    /// The same, for a command inside an <see cref="NpgsqlBatch"/>.
    /// </summary>
    /// <remarks>
    /// A batch command carries its own parameter collection and is not an
    /// <see cref="NpgsqlCommand"/>, so the overload takes the collection both share rather
    /// than duplicating the loop.
    /// </remarks>
    internal static void AddAll(NpgsqlBatchCommand command, params object[] values) =>
        AddAll(command.Parameters, values);

    private static void AddAll(NpgsqlParameterCollection parameters, object[] values)
    {
        foreach (var value in values)
        {
            parameters.Add(Param(value));
        }
    }

    internal static async ValueTask<T?> ReadOneAsync<T>(
        NpgsqlCommand command,
        Func<NpgsqlDataReader, T> map,
        CancellationToken cancellationToken)
        where T : class
    {
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        return await reader.ReadAsync(cancellationToken).ConfigureAwait(false) ? map(reader) : null;
    }

    internal static async ValueTask<IReadOnlyList<T>> ReadManyAsync<T>(
        NpgsqlCommand command,
        Func<NpgsqlDataReader, T> map,
        CancellationToken cancellationToken)
    {
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        var items = new List<T>();
        while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
        {
            items.Add(map(reader));
        }

        return items;
    }

    /// <summary>
    /// Turns a unique violation into the same domain error the in-memory store raises,
    /// so callers behave identically whichever store is configured. The database
    /// constraint remains the authoritative guard.
    /// </summary>
    internal static async Task ExecuteMappingConflictsAsync(
        NpgsqlCommand command,
        string code,
        string message,
        CancellationToken cancellationToken)
    {
        try
        {
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            throw new DomainRuleException(code, message);
        }
    }
}
