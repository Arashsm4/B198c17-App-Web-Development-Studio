# PostgreSQL persistence boundary

Migration `0001_ch1_foundation.sql` is the relational baseline for Cinerion
P03/IFV. It covers the vertical digital thread and the bounded modules defined
in `CH1-DBA-DD-0001`.

Prototype 1 starts with `InMemoryCinerionStore` so state-machine verification
does not depend on a database service. This mode is explicitly marked
`Simulation` and is forbidden in the reserved Production profile. The
PostgreSQL adapter will be enabled only after transaction, row-scope,
migration/rollback, backup, and audit-concurrency tests pass.

The SQL migration is nevertheless active in local Compose so constraints,
indexes, RLS policies, and restore tooling can be developed early. Private keys,
document passwords, and reusable bearer tokens are never database columns.

