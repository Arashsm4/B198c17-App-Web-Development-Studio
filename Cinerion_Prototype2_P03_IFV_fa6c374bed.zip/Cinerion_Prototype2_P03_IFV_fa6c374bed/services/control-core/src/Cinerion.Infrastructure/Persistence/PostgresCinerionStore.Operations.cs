// PostgreSQL storage for projects, cells, commands, quality and the audit chain. The busiest
// file in the building.

using System.Text.Json;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Quality;
using Npgsql;

namespace Cinerion.Infrastructure.Persistence;

public sealed partial class PostgresCinerionStore
{
    /// <summary>Placeholder hash for a cell whose controller has not yet reported.</summary>
    private const string UnreportedStateHash = "0000000000000000000000000000000000000000000000000000000000000000";

    // ------------------------------------------------------------------- cells

    public async ValueTask SaveCellRegistrationAsync(CellRegistration cell, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(cell.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // Registration owns identity and name. The operational columns are NOT NULL, so
        // a first insert seeds them as unreported: no controller has spoken yet, and
        // Unknown freshness is the honest value until one does.
        command.CommandText = """
            INSERT INTO ch1.cells(cell_id, project_id, site_id, name, controller_id, operating_state,
                                  configuration_revision, state_hash, source_timestamp, freshness, quality, version)
            VALUES($1, $2, $3, $4, $5, 'Initialising', 'unreported', $6, now(), 'Unknown'::ch1.freshness, 'Unknown'::ch1.data_quality, $7)
            ON CONFLICT (cell_id) DO UPDATE SET
              site_id = EXCLUDED.site_id, name = EXCLUDED.name, version = EXCLUDED.version
            """;
        AddAll(command, cell.CellId, cell.ProjectId, cell.SiteId, cell.Name, $"unassigned:{cell.CellId}", UnreportedStateHash, cell.Version);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<CellRegistration>> ListCellsBySiteAsync(
        Guid projectId,
        Guid siteId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText =
            "SELECT cell_id, project_id, site_id, name, version FROM ch1.cells WHERE site_id = $1 ORDER BY name";
        command.Parameters.Add(Param(siteId));
        return await ReadManyAsync(
            command,
            r => new CellRegistration(r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetString(3), r.GetInt64(4)),
            cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Writes the durable half of the cell state.
    /// <para>
    /// Interlocks, controller boot identity and button state are not written anywhere,
    /// because restoring them would present a stale permissive as a current one.
    /// CH1-SAF-FR-0003 requires restart to default to a non-energising safe state.
    /// </para>
    /// </summary>
    /// <summary>
    /// Writes the durable half of the cell state, and the observation that goes with it.
    /// <para>
    /// Interlocks, controller boot identity and button state are not written anywhere,
    /// because restoring them would present a stale permissive as a current one.
    /// CH1-SAF-FR-0003 requires restart to default to a non-energising safe state.
    /// </para>
    /// <para>
    /// Freshness, quality and the source timestamp are now parameters. They used to be
    /// literals in this statement — <c>'Simulated'</c>, <c>'Good'</c> and <c>now()</c> —
    /// which meant every cell reported itself as a current simulated reading whatever had
    /// or had not happened, and a cell nothing had reported for since a restart weeks ago
    /// was indistinguishable from one reporting right now. CH1-MON-FR-0003 requires live,
    /// stale, disconnected, simulated, maintenance and unknown to stay distinguishable.
    /// </para>
    /// </summary>
    public async ValueTask SaveCellAsync(
        CellSnapshot cell,
        CellObservation observation,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(cell.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.cells(cell_id, project_id, site_id, name, controller_id, operating_state,
                                  configuration_revision, state_hash, source_timestamp, freshness, quality, version)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::ch1.freshness, $11::ch1.data_quality, 1)
            ON CONFLICT (cell_id) DO UPDATE SET
              controller_id = EXCLUDED.controller_id, operating_state = EXCLUDED.operating_state,
              configuration_revision = EXCLUDED.configuration_revision, state_hash = EXCLUDED.state_hash,
              source_timestamp = EXCLUDED.source_timestamp, freshness = EXCLUDED.freshness,
              quality = EXCLUDED.quality
            """;
        AddAll(
            command, cell.CellId, cell.ProjectId, cell.SiteId, $"cell:{cell.CellId}", cell.ControllerId,
            cell.OperatingState.ToString(), cell.ConfigurationRevision, cell.StateHash(),
            observation.SourceTimestamp ?? DateTimeOffset.UtcNow,
            observation.Freshness.ToString(), observation.Quality.ToString());
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Rebuilds the cell state. Assignments are resolved from the records that already
    /// carry the cell; interlocks come back not permissive, so a prepared command is
    /// refused until the controller reports again.
    /// </summary>
    public async ValueTask<StoredCellState?> FindCellAsync(Guid cellId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT c.cell_id, c.project_id, c.site_id, c.controller_id, c.operating_state, c.configuration_revision,
                   (SELECT a.asset_id FROM ch1.assets a WHERE a.cell_id = c.cell_id ORDER BY a.asset_code LIMIT 1),
                   (SELECT w.work_order_id FROM ch1.work_orders w
                     WHERE w.cell_id = c.cell_id AND w.status = 'Released'
                     ORDER BY w.released_at DESC NULLS LAST LIMIT 1),
                   (SELECT p.part_id FROM ch1.physical_parts p
                     JOIN ch1.work_orders w2 ON w2.work_order_id = p.work_order_id
                     WHERE w2.cell_id = c.cell_id ORDER BY p.created_at DESC LIMIT 1),
                   c.source_timestamp, c.freshness, c.quality
            FROM ch1.cells c WHERE c.cell_id = $1
            """;
        command.Parameters.Add(Param(cellId));
        return await ReadOneAsync(
            command,
            r => new StoredCellState(
                new CellSnapshot(
                    r.GetGuid(1),
                    r.GetGuid(2),
                    r.GetGuid(0),
                    r.IsDBNull(6) ? Guid.Empty : r.GetGuid(6),
                    r.GetString(3),
                    // No boot identity is restored: a command prepared before a restart
                    // cannot match a controller that has booted since.
                    Guid.Empty,
                    Enum.Parse<CellOperatingState>(r.GetString(4)),
                    r.GetString(5),
                    r.IsDBNull(7) ? Guid.Empty : r.GetGuid(7),
                    r.IsDBNull(8) ? Guid.Empty : r.GetGuid(8),
                    // Interlocks come back not permissive, so a prepared command is
                    // refused until a controller reports again through CH1-COM-IF-0003.
                    false, false, false, false, false, false, false),
                new CellObservation(
                    Enum.Parse<Domain.Monitoring.Freshness>(r.GetString(10)),
                    Enum.Parse<Domain.Monitoring.DataQuality>(r.GetString(11)),
                    r.IsDBNull(9) ? null : r.GetFieldValue<DateTimeOffset>(9))),
            cancellationToken).ConfigureAwait(false);
    }

    // ---------------------------------------------------------------- commands

    private const string CommandProjection = """
        SELECT t.command_id, t.project_id, t.site_id, t.cell_id, t.asset_id, t.work_order_id, t.part_id,
               t.confirmation_id, t.correlation_id, t.requester_id, t.command_type, t.procedure_revision,
               t.configuration_revision, t.expected_state_hash, t.sequence_number, t.expires_at,
               t.idempotency_key, t.parameters, t.state, t.prepared_at, t.prepared_controller_boot_id,
               t.local_commit_id, t.terminal_reason, t.version,
               c.credential_id, c.user_id, c.authenticator_class, c.challenge_hash,
               c.cryptographically_verified, c.user_verified, c.proof_verified_at, c.proof_expires_at,
               c.controller_id
        FROM ch1.command_transactions t
        LEFT JOIN ch1.local_confirmations c ON c.command_id = t.command_id
        """;

    public async ValueTask<CommandTransaction?> FindCommandAsync(Guid commandId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = CommandProjection + " WHERE t.command_id = $1";
        command.Parameters.Add(Param(commandId));
        return await ReadOneAsync(command, ReadCommand, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<CommandTransaction?> FindCommandByIdempotencyKeyAsync(
        Guid projectId,
        string idempotencyKey,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = CommandProjection + " WHERE t.idempotency_key = $1";
        command.Parameters.Add(Param(idempotencyKey));
        return await ReadOneAsync(command, ReadCommand, cancellationToken).ConfigureAwait(false);
    }

    private static CommandTransaction ReadCommand(NpgsqlDataReader r)
    {
        var intent = new PrepareIntent(
            r.GetString(10), r.GetGuid(1), r.GetGuid(2), r.GetGuid(3), r.GetGuid(4), r.GetGuid(5), r.GetGuid(6),
            r.GetString(11), r.GetString(12), r.GetString(13), r.GetInt64(14), r.GetFieldValue<DateTimeOffset>(15),
            r.GetString(16),
            JsonSerializer.Deserialize<Dictionary<string, object>>(r.GetString(17), Json) ?? []);

        CredentialProof? proof = null;
        if (!r.IsDBNull(24))
        {
            proof = new CredentialProof(
                Guid.Empty,
                r.GetGuid(0),
                r.GetGuid(7),
                r.GetGuid(3),
                r.GetString(32),
                r.GetGuid(24),
                r.GetString(25),
                Enum.Parse<AuthenticatorClass>(r.GetString(26)),
                r.GetString(27),
                r.GetBoolean(28),
                r.GetBoolean(29),
                r.GetFieldValue<DateTimeOffset>(30),
                r.GetFieldValue<DateTimeOffset>(31));
        }

        return new CommandTransaction
        {
            CommandId = r.GetGuid(0),
            ConfirmationId = r.GetGuid(7),
            CorrelationId = r.GetGuid(8),
            RequesterId = r.GetString(9),
            Intent = intent,
            State = Enum.Parse<CommandState>(r.GetString(18)),
            PreparedAt = r.GetFieldValue<DateTimeOffset>(19),
            PreparedControllerBootId = r.GetGuid(20),
            LocalCommitId = r.IsDBNull(21) ? null : r.GetGuid(21),
            TerminalReason = r.IsDBNull(22) ? null : r.GetString(22),
            Version = r.GetInt32(23),
            CredentialProof = proof,
        };
    }

    public async ValueTask SaveCommandAsync(
        CommandTransaction command,
        int? expectedVersion,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(command.Intent.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

        await using (var write = connection.CreateCommand())
        {
            write.Transaction = transaction;
            // Optimistic concurrency is expressed in the WHERE clause so a stale write
            // affects no rows rather than overwriting a newer state.
            //
            // Each branch declares only the parameters its own statement references.
            // The update previously reused the insert's list of 24 and referenced 6 of
            // them, which PostgreSQL rejects at parse time with "could not determine
            // data type of parameter $2": a parameter's type is inferred from where it
            // is used, and one that is never used has no type to infer. Every command
            // state transition on PostgreSQL therefore failed - credential proof, local
            // commit and cancel alike. It was invisible in the suite because those tests
            // run on the in-memory store, and unreachable over HTTP on PostgreSQL
            // because a restored cell correctly reports no permissive, so PREPARE is
            // refused before the update path is ever taken.
            if (expectedVersion is null)
            {
                write.CommandText = """
                    INSERT INTO ch1.command_transactions(command_id, project_id, site_id, cell_id, asset_id, work_order_id, part_id,
                        confirmation_id, correlation_id, requester_id, command_type, procedure_revision, configuration_revision,
                        expected_state_hash, sequence_number, expires_at, idempotency_key, parameters, state, prepared_at,
                        prepared_controller_boot_id, local_commit_id, terminal_reason, version)
                    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18::jsonb,$19::ch1.command_state,$20,$21,$22,$23,$24)
                    """;
                AddAll(
                    write, command.CommandId, command.Intent.ProjectId, command.Intent.SiteId, command.Intent.CellId,
                    command.Intent.AssetId, command.Intent.WorkOrderId, command.Intent.PartId, command.ConfirmationId,
                    command.CorrelationId, command.RequesterId, command.Intent.CommandType, command.Intent.ProcedureRevision,
                    command.Intent.ConfigurationRevision, command.Intent.ExpectedStateHash, command.Intent.Sequence,
                    command.Intent.ExpiresAt, command.Intent.IdempotencyKey,
                    JsonSerializer.Serialize(command.Intent.Parameters, Json), command.State.ToString(),
                    command.PreparedAt, command.PreparedControllerBootId);
                write.Parameters.Add(Nullable(command.LocalCommitId));
                write.Parameters.Add(Nullable(command.TerminalReason));
                write.Parameters.Add(Param(command.Version));
            }
            else
            {
                // The intent is deliberately absent: what was prepared is never
                // rewritten, only the state it reached.
                write.CommandText = """
                    UPDATE ch1.command_transactions SET
                      state = $2::ch1.command_state, local_commit_id = $3, terminal_reason = $4, version = $5
                    WHERE command_id = $1 AND version = $6
                    """;
                AddAll(write, command.CommandId, command.State.ToString());
                write.Parameters.Add(Nullable(command.LocalCommitId));
                write.Parameters.Add(Nullable(command.TerminalReason));
                write.Parameters.Add(Param(command.Version));
                write.Parameters.Add(Param(expectedVersion.Value));
            }

            int affected;
            try
            {
                affected = await write.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
            {
                throw new DomainRuleException("IDEMPOTENCY_CONFLICT", "The idempotency key is already assigned.");
            }

            if (expectedVersion is not null && affected == 0)
            {
                throw new DomainRuleException("CONCURRENCY_CONFLICT", "The command changed since it was read.");
            }
        }

        if (command.CredentialProof is { } proof)
        {
            await using var confirmation = connection.CreateCommand();
            confirmation.Transaction = transaction;
            confirmation.CommandText = """
                INSERT INTO ch1.local_confirmations(confirmation_id, command_id, project_id, cell_id, controller_id,
                    credential_id, user_id, authenticator_class, challenge_hash, cryptographically_verified,
                    user_verified, proof_verified_at, proof_expires_at, controller_boot_id, local_commit_id)
                VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
                ON CONFLICT (confirmation_id) DO UPDATE SET local_commit_id = EXCLUDED.local_commit_id
                """;
            AddAll(
                confirmation, command.ConfirmationId, command.CommandId, command.Intent.ProjectId, command.Intent.CellId,
                proof.ControllerId, proof.CredentialId, proof.UserId, proof.AuthenticatorClass.ToString(),
                proof.ChallengeHash, proof.CryptographicallyVerified, proof.UserVerified, proof.VerifiedAt,
                proof.ExpiresAt, command.PreparedControllerBootId);
            confirmation.Parameters.Add(Nullable(command.LocalCommitId));
            await confirmation.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------------- parts

    public async ValueTask<PartRecord?> FindPartAsync(Guid partId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);

        PartRecord? part;
        await using (var command = connection.CreateCommand())
        {
            command.CommandText = """
                SELECT p.part_id, p.project_id, p.work_order_id, p.revision_id, p.serial_number,
                       p.permanent_identity_uri, p.operator_id, p.status,
                       r.release_id, r.inspector_id, r.released_at
                FROM ch1.physical_parts p
                LEFT JOIN ch1.release_records r ON r.part_id = p.part_id
                WHERE p.part_id = $1
                """;
            command.Parameters.Add(Param(partId));
            part = await ReadOneAsync(
                command,
                r => new PartRecord(
                    r.GetGuid(1), r.GetGuid(0), r.GetGuid(2), r.GetGuid(3), r.GetString(4), r.GetString(5),
                    r.GetString(6), Enum.Parse<PartStatus>(r.GetString(7)), [], [],
                    r.IsDBNull(8) ? null : new ReleaseRecord(r.GetGuid(8), r.GetString(9), r.GetFieldValue<DateTimeOffset>(10))),
                cancellationToken).ConfigureAwait(false);
        }

        if (part is null)
        {
            return null;
        }

        await using (var command = connection.CreateCommand())
        {
            command.CommandText = """
                SELECT measurement_id, test_run_id, characteristic, value, unit, lower_limit, upper_limit,
                       mandatory, source_device_id, calibration_id, supersedes_measurement_id, result, source_sample_time
                FROM ch1.measurements WHERE part_id = $1 ORDER BY source_sample_time, measurement_id
                """;
            command.Parameters.Add(Param(partId));
            var measurements = await ReadManyAsync(
                command,
                r => new Measurement(
                    r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetDecimal(3), r.GetString(4),
                    r.GetDecimal(5), r.GetDecimal(6), r.GetBoolean(7), r.GetString(8), r.GetGuid(9),
                    r.IsDBNull(10) ? null : r.GetGuid(10),
                    // Stored results are admissible by construction: an inadmissible
                    // reading is refused before it is written.
                    true,
                    r.GetFieldValue<DateTimeOffset>(12),
                    Enum.Parse<MeasurementResult>(r.GetString(11))),
                cancellationToken).ConfigureAwait(false);
            part = part with { Measurements = measurements };
        }

        await using (var command = connection.CreateCommand())
        {
            command.CommandText = "SELECT ncr_id FROM ch1.ncrs WHERE part_id = $1 AND status <> 'Closed'";
            command.Parameters.Add(Param(partId));
            var open = await ReadManyAsync(command, r => r.GetGuid(0), cancellationToken).ConfigureAwait(false);
            part = part with { OpenNcrIds = open };
        }

        return part;
    }

    public async ValueTask SavePartAsync(PartRecord part, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(part.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

        await using (var command = connection.CreateCommand())
        {
            command.Transaction = transaction;
            command.CommandText = """
                INSERT INTO ch1.physical_parts(part_id, project_id, work_order_id, revision_id, serial_number,
                    operator_id, status, permanent_identity_uri)
                VALUES($1,$2,$3,$4,$5,$6,$7::ch1.part_status,$8)
                ON CONFLICT (part_id) DO UPDATE SET status = EXCLUDED.status
                """;
            AddAll(
                command, part.PartId, part.ProjectId, part.WorkOrderId, part.RevisionId, part.SerialNumber,
                part.OperatorId, part.Status.ToString(), part.PermanentIdentityUri);
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        // Measurements are immutable evidence: the trigger on ch1.measurements refuses
        // UPDATE and DELETE, so only genuinely new rows are inserted.
        foreach (var measurement in part.Measurements)
        {
            await using var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandText = """
                INSERT INTO ch1.measurements(measurement_id, project_id, test_run_id, part_id, characteristic, value, unit,
                    lower_limit, upper_limit, mandatory, result, quality, source_device_id, calibration_id,
                    supersedes_measurement_id, source_sample_time)
                VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'Good'::ch1.data_quality,$12,$13,$14,$15)
                ON CONFLICT (measurement_id) DO NOTHING
                """;
            AddAll(
                command, measurement.MeasurementId, part.ProjectId, measurement.TestRunId, part.PartId,
                measurement.Characteristic, measurement.Value, measurement.Unit, measurement.LowerLimit,
                measurement.UpperLimit, measurement.Mandatory, measurement.Result.ToString(),
                measurement.SourceDeviceId, measurement.CalibrationRecordId);
            command.Parameters.Add(Nullable(measurement.SupersedesMeasurementId));
            command.Parameters.Add(Param(measurement.MeasuredAt));
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        if (part.Release is { } release)
        {
            await using var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandText = """
                INSERT INTO ch1.release_records(release_id, project_id, part_id, inspector_id, operator_id, released_at, evidence_manifest_hash)
                VALUES($1,$2,$3,$4,$5,$6,$7)
                ON CONFLICT (release_id) DO NOTHING
                """;
            AddAll(
                command, release.ReleaseId, part.ProjectId, part.PartId, release.InspectorId, part.OperatorId,
                release.ReleasedAt, CanonicalJson.Sha256Hex(part.Measurements));
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
    }

    // --------------------------------------------------------- test runs, NCRs

    public async ValueTask<TestRunRecord?> FindTestRunAsync(Guid testRunId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT test_run_id, project_id, part_id, procedure_id, procedure_revision, started_by, witnessed_by,
                   status, started_at, completed_at, version
            FROM ch1.test_runs WHERE test_run_id = $1
            """;
        command.Parameters.Add(Param(testRunId));
        return await ReadOneAsync(
            command,
            r => new TestRunRecord(
                r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.GetString(3), r.GetString(4), r.GetString(5),
                r.IsDBNull(6) ? null : r.GetString(6), Enum.Parse<TestRunStatus>(r.GetString(7)),
                r.GetFieldValue<DateTimeOffset>(8),
                r.IsDBNull(9) ? null : r.GetFieldValue<DateTimeOffset>(9), r.GetInt64(10)),
            cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveTestRunAsync(TestRunRecord testRun, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(testRun.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.test_runs(test_run_id, project_id, part_id, procedure_id, procedure_revision, started_by,
                                      witnessed_by, status, started_at, completed_at, version)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
            ON CONFLICT (test_run_id) DO UPDATE SET
              witnessed_by = EXCLUDED.witnessed_by, status = EXCLUDED.status,
              completed_at = EXCLUDED.completed_at, version = EXCLUDED.version
            """;
        AddAll(command, testRun.TestRunId, testRun.ProjectId, testRun.PartId, testRun.ProcedureId, testRun.ProcedureRevision, testRun.StartedBy);
        command.Parameters.Add(Nullable(testRun.WitnessedBy));
        command.Parameters.Add(Param(testRun.Status.ToString()));
        command.Parameters.Add(Param(testRun.StartedAt));
        command.Parameters.Add(Nullable(testRun.CompletedAt));
        command.Parameters.Add(Param(testRun.Version));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<NcrRecord?> FindNcrAsync(Guid ncrId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT ncr_id, project_id, part_id, test_run_id, title, description, status, raised_by, raised_at,
                   source_measurement_id, disposition, disposition_by, disposition_at, closed_by_measurement_id, version
            FROM ch1.ncrs WHERE ncr_id = $1
            """;
        command.Parameters.Add(Param(ncrId));
        return await ReadOneAsync(
            command,
            r => new NcrRecord(
                r.GetGuid(0), r.GetGuid(1), r.GetGuid(2), r.IsDBNull(3) ? null : r.GetGuid(3),
                r.GetString(4), r.GetString(5), Enum.Parse<NcrStatus>(r.GetString(6)), r.GetString(7),
                r.GetFieldValue<DateTimeOffset>(8), r.IsDBNull(9) ? null : r.GetGuid(9),
                r.IsDBNull(10) ? null : Enum.Parse<NcrDispositionKind>(r.GetString(10)),
                r.IsDBNull(11) ? null : r.GetString(11),
                r.IsDBNull(12) ? null : r.GetFieldValue<DateTimeOffset>(12),
                // The justification has no column in ch1.ncrs; the decision and its
                // reason are preserved in the audit chain, which is the controlled
                // record of who decided what and why.
                null,
                r.IsDBNull(13) ? null : r.GetGuid(13),
                r.GetInt64(14)),
            cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveNcrAsync(NcrRecord ncr, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(ncr.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.ncrs(ncr_id, project_id, part_id, test_run_id, title, description, status, raised_by,
                                 raised_at, source_measurement_id, disposition, disposition_by, disposition_at,
                                 closed_by_measurement_id, version)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
            ON CONFLICT (ncr_id) DO UPDATE SET
              status = EXCLUDED.status, disposition = EXCLUDED.disposition, disposition_by = EXCLUDED.disposition_by,
              disposition_at = EXCLUDED.disposition_at, closed_by_measurement_id = EXCLUDED.closed_by_measurement_id,
              version = EXCLUDED.version
            """;
        AddAll(command, ncr.NcrId, ncr.ProjectId, ncr.PartId);
        command.Parameters.Add(Nullable(ncr.TestRunId));
        AddAll(command, ncr.Title, ncr.Description, ncr.Status.ToString(), ncr.RaisedBy, ncr.RaisedAt);
        command.Parameters.Add(Nullable(ncr.SourceMeasurementId));
        command.Parameters.Add(Nullable(ncr.Disposition?.ToString()));
        command.Parameters.Add(Nullable(ncr.DispositionBy));
        command.Parameters.Add(Nullable(ncr.DispositionAt));
        command.Parameters.Add(Nullable(ncr.ClosedByMeasurementId));
        command.Parameters.Add(Param(ncr.Version));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------------- audit

    /// <summary>
    /// Appends one hash-linked event.
    /// <para>
    /// The advisory lock serialises appends for a project so two concurrent writers
    /// cannot both read the same head and produce a fork. It is transaction scoped, so
    /// it is released whether the insert succeeds or fails.
    /// </para>
    /// </summary>
    public async ValueTask<AuditEvent> AppendAuditAsync(AuditInput input, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(input.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

        await using (var lockCommand = connection.CreateCommand())
        {
            lockCommand.Transaction = transaction;
            lockCommand.CommandText = "SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0))";
            lockCommand.Parameters.Add(Param(input.ProjectId.ToString()));
            await lockCommand.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        string previousHash = AuditChain.GenesisHash;
        await using (var head = connection.CreateCommand())
        {
            head.Transaction = transaction;
            head.CommandText =
                "SELECT event_hash FROM ch1.audit_events WHERE project_id = $1 ORDER BY sequence_number DESC LIMIT 1";
            head.Parameters.Add(Param(input.ProjectId));
            var value = await head.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
            if (value is string existing)
            {
                previousHash = existing;
            }
        }

        var eventId = Guid.NewGuid();
        var payloadHash = CanonicalJson.Sha256Hex(input.Payload);

        // The event hash covers the sequence number, and the immutability trigger
        // refuses UPDATE, so the row must be written once already carrying its final
        // hash. The sequence is therefore reserved first and supplied explicitly with
        // OVERRIDING SYSTEM VALUE, which keeps the hash identical to the in-memory
        // chain rather than inventing a different canonical form for PostgreSQL.
        long sequence;
        await using (var next = connection.CreateCommand())
        {
            next.Transaction = transaction;
            next.CommandText =
                "SELECT nextval(pg_get_serial_sequence('ch1.audit_events', 'sequence_number'))";
            sequence = Convert.ToInt64(
                await next.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false),
                System.Globalization.CultureInfo.InvariantCulture);
        }

        var eventHash = AuditChain.ComputeEventHash(
            eventId, sequence, input.EventType, input.ActorId, input.ActorKind, input.ProjectId,
            input.ObjectType, input.ObjectId, input.CorrelationId, input.OccurredAt, input.TimeQuality,
            input.Decision, input.ReasonCode, payloadHash, previousHash);

        await using (var insert = connection.CreateCommand())
        {
            insert.Transaction = transaction;
            insert.CommandText = """
                INSERT INTO ch1.audit_events(event_id, sequence_number, project_id, event_type, actor_id, actor_kind,
                    object_type, object_id, correlation_id, occurred_at, time_quality, decision, reason_code,
                    payload_hash, previous_hash, event_hash)
                OVERRIDING SYSTEM VALUE
                VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
                """;
            AddAll(
                insert, eventId, sequence, input.ProjectId, input.EventType, input.ActorId, input.ActorKind.ToString(),
                input.ObjectType, input.ObjectId, input.CorrelationId, input.OccurredAt, input.TimeQuality,
                input.Decision, input.ReasonCode, payloadHash, previousHash, eventHash);
            await insert.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
        return new AuditEvent(
            eventId, sequence, input.EventType, input.ActorId, input.ActorKind, input.ProjectId,
            input.ObjectType, input.ObjectId, input.CorrelationId, input.OccurredAt, input.TimeQuality,
            input.Decision, input.ReasonCode, payloadHash, previousHash, eventHash);
    }

    public async ValueTask<IReadOnlyList<AuditEvent>> QueryAuditAsync(
        Guid projectId,
        Guid? correlationId,
        int limit,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT * FROM (
              SELECT event_id, sequence_number, event_type, actor_id, actor_kind, project_id, object_type, object_id,
                     correlation_id, occurred_at, time_quality, decision, reason_code, payload_hash, previous_hash, event_hash
              FROM ch1.audit_events
              WHERE ($1::uuid IS NULL OR correlation_id = $1)
              ORDER BY sequence_number DESC LIMIT $2
            ) recent ORDER BY sequence_number
            """;
        command.Parameters.Add(Nullable(correlationId));
        command.Parameters.Add(Param(Math.Clamp(limit, 1, 1_000)));
        return await ReadManyAsync(command, ReadAuditEvent, cancellationToken).ConfigureAwait(false);
    }

    private static AuditEvent ReadAuditEvent(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetInt64(1), r.GetString(2), r.GetString(3),
        Enum.Parse<Cinerion.Domain.Security.ActorKind>(r.GetString(4)), r.GetGuid(5), r.GetString(6), r.GetString(7),
        r.GetGuid(8), r.GetFieldValue<DateTimeOffset>(9), r.GetString(10), r.GetString(11), r.GetString(12),
        r.GetString(13), r.GetString(14), r.GetString(15));

    /// <summary>
    /// Recomputes every link for the caller's project. Row-level security means this
    /// verifies exactly what a project-scoped reader can see, which is why the chain is
    /// linked per project.
    /// </summary>
    public async ValueTask<AuditVerification> VerifyAuditAsync(CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT event_id, sequence_number, event_type, actor_id, actor_kind, project_id, object_type, object_id,
                   correlation_id, occurred_at, time_quality, decision, reason_code, payload_hash, previous_hash, event_hash
            FROM ch1.audit_events ORDER BY project_id, sequence_number
            """;
        var events = await ReadManyAsync(command, ReadAuditEvent, cancellationToken).ConfigureAwait(false);

        var heads = new Dictionary<Guid, string>();
        var checkedCount = 0;
        foreach (var item in events)
        {
            var expectedPrevious = heads.GetValueOrDefault(item.ProjectId, AuditChain.GenesisHash);
            if (!StringComparer.Ordinal.Equals(item.PreviousHash, expectedPrevious))
            {
                return new AuditVerification(false, checkedCount, item.Sequence);
            }

            var recomputed = AuditChain.ComputeEventHash(
                item.EventId, item.Sequence, item.EventType, item.ActorId, item.ActorKind, item.ProjectId,
                item.ObjectType, item.ObjectId, item.CorrelationId, item.OccurredAt, item.TimeQuality,
                item.Decision, item.ReasonCode, item.PayloadHash, item.PreviousHash);
            if (!StringComparer.Ordinal.Equals(item.EventHash, recomputed))
            {
                return new AuditVerification(false, checkedCount, item.Sequence);
            }

            heads[item.ProjectId] = item.EventHash;
            checkedCount++;
        }

        return new AuditVerification(true, checkedCount);
    }
}
