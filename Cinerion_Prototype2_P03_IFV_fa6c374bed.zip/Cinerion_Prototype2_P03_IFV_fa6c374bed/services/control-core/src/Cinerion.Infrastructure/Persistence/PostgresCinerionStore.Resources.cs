// PostgreSQL storage for resources and reservations.

using Cinerion.Domain.Common;
using Cinerion.Domain.Resources;
using Npgsql;
using NpgsqlTypes;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Resources and reservations on the controlled schema.
/// </summary>
/// <requirements>CH1-MGT-FR-0003, CH1-MGT-FR-0004</requirements>
public sealed partial class PostgresCinerionStore
{
    // --------------------------------------------------------------- resources

    private const string ResourceProjection = """
        SELECT resource_id, project_id, resource_type, name, capacity, unit, availability_state, version
        FROM ch1.resources
        """;

    public async ValueTask<ResourceRecord?> FindResourceAsync(Guid resourceId, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = ResourceProjection + " WHERE resource_id = $1";
        command.Parameters.Add(Param(resourceId));
        return await ReadOneAsync(command, ReadResource, cancellationToken).ConfigureAwait(false);
    }

    private static ResourceRecord ReadResource(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetString(3), r.GetDecimal(4), r.GetString(5),
        Enum.Parse<ResourceAvailabilityState>(r.GetString(6)), r.GetInt64(7));

    public async ValueTask SaveResourceAsync(ResourceRecord resource, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(resource.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.resources(resource_id, project_id, resource_type, name, capacity, unit, availability_state, version)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8)
            ON CONFLICT (resource_id) DO UPDATE SET
              resource_type = EXCLUDED.resource_type, name = EXCLUDED.name, capacity = EXCLUDED.capacity,
              unit = EXCLUDED.unit, availability_state = EXCLUDED.availability_state, version = EXCLUDED.version
            """;
        AddAll(
            command, resource.ResourceId, resource.ProjectId, resource.ResourceType, resource.Name,
            resource.Capacity, resource.Unit, resource.AvailabilityState.ToString(), resource.Version);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<ResourceRecord>> ListResourcesAsync(
        ResourceQuery query,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(query.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // Keyset paging over (name, resource_id), the same order the in-memory store
        // applies, so a page boundary means the same thing in both stores.
        command.CommandText = ResourceProjection +
            """
             WHERE ($1::text IS NULL OR resource_type = $1)
               AND ($2::text IS NULL OR availability_state = $2)
               AND ($3::text IS NULL OR (name, resource_id) > ($3, $4::uuid))
             ORDER BY name, resource_id
             LIMIT $5
            """;
        command.Parameters.Add(Nullable(query.ResourceType));
        command.Parameters.Add(Nullable(query.AvailabilityState?.ToString()));
        command.Parameters.Add(Nullable(query.After?.Name));
        command.Parameters.Add(Nullable(query.After?.ResourceId));
        command.Parameters.Add(Param(query.Limit));
        return await ReadManyAsync(command, ReadResource, cancellationToken).ConfigureAwait(false);
    }

    // ------------------------------------------------------------- allocations

    private const string AllocationProjection = """
        SELECT allocation_id, project_id, resource_id, work_order_id, experiment_id, quantity,
               starts_at, ends_at, status, requested_by, version,
               cancellation_reason, cancelled_by, cancelled_at
        FROM ch1.resource_allocations
        """;

    public async ValueTask<ResourceAllocation?> FindAllocationAsync(
        Guid allocationId,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = AllocationProjection + " WHERE allocation_id = $1";
        command.Parameters.Add(Param(allocationId));
        return await ReadOneAsync(command, ReadAllocation, cancellationToken).ConfigureAwait(false);
    }

    private static ResourceAllocation ReadAllocation(NpgsqlDataReader r) => new(
        r.GetGuid(0), r.GetGuid(1), r.GetGuid(2),
        r.IsDBNull(3) ? null : r.GetGuid(3),
        r.IsDBNull(4) ? null : r.GetGuid(4),
        r.GetDecimal(5), r.GetFieldValue<DateTimeOffset>(6), r.GetFieldValue<DateTimeOffset>(7),
        Enum.Parse<AllocationStatus>(r.GetString(8)), r.GetString(9), r.GetInt64(10),
        r.IsDBNull(11) ? null : r.GetString(11),
        r.IsDBNull(12) ? null : r.GetString(12),
        r.IsDBNull(13) ? null : r.GetFieldValue<DateTimeOffset>(13));

    public async ValueTask<IReadOnlyList<ResourceAllocation>> ListAllocationsAsync(
        Guid projectId,
        IReadOnlyList<Guid> resourceIds,
        DateTimeOffset windowStart,
        DateTimeOffset windowEnd,
        CancellationToken cancellationToken)
    {
        if (resourceIds.Count == 0)
        {
            return [];
        }

        await using var connection = await dataSource.OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // Half-open overlap: a reservation that ends exactly when the window opens does
        // not touch it, and neither does one that starts exactly as it closes.
        command.CommandText = AllocationProjection +
            """
             WHERE resource_id = ANY($1) AND status <> 'Cancelled'
               AND starts_at < $3 AND ends_at > $2
             ORDER BY starts_at, allocation_id
            """;
        command.Parameters.Add(new NpgsqlParameter
        {
            Value = resourceIds.ToArray(),
            NpgsqlDbType = NpgsqlDbType.Array | NpgsqlDbType.Uuid,
        });
        AddAll(command, windowStart, windowEnd);
        return await ReadManyAsync(command, ReadAllocation, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Writes the reservation and bumps the resource version in one transaction, with
    /// the resource row locked for the duration.
    /// <para>
    /// The conflict check reads allocations, decides, then writes. Without the lock two
    /// callers could both read the same committed quantity, both conclude there was room
    /// and both commit, and the resource would end up over-committed by a path that
    /// checked correctly. The version comparison turns that race into an explicit
    /// CONCURRENCY_CONFLICT for the second caller, which is what CH1-SWA-API-0001 means
    /// by stale updates failing explicitly.
    /// </para>
    /// </summary>
    /// <requirements>CH1-MGT-FR-0003, CH1-VVT-TC-0105</requirements>
    public async ValueTask SaveAllocationAsync(
        ResourceAllocation allocation,
        long expectedResourceVersion,
        long? expectedAllocationVersion,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource.OpenForProjectAsync(allocation.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

        await using (var bump = connection.CreateCommand())
        {
            bump.Transaction = transaction;
            bump.CommandText = """
                UPDATE ch1.resources SET version = version + 1
                WHERE resource_id = $1 AND version = $2
                """;
            AddAll(bump, allocation.ResourceId, expectedResourceVersion);
            if (await bump.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false) == 0)
            {
                throw new DomainRuleException(
                    "CONCURRENCY_CONFLICT",
                    "The resource changed since it was read.");
            }
        }

        await using (var write = connection.CreateCommand())
        {
            write.Transaction = transaction;

            // Each branch carries only the parameters its own statement references.
            // Declaring the full insert list for both and letting the update ignore most
            // of them fails at parse time with "could not determine data type of
            // parameter": PostgreSQL infers a parameter's type from where it is used, so
            // one that is never used has no type to infer.
            if (expectedAllocationVersion is null)
            {
                write.CommandText = """
                    INSERT INTO ch1.resource_allocations(allocation_id, project_id, resource_id, work_order_id,
                        experiment_id, quantity, starts_at, ends_at, status, requested_by, version,
                        cancellation_reason, cancelled_by, cancelled_at)
                    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
                    """;
                AddAll(write, allocation.AllocationId, allocation.ProjectId, allocation.ResourceId);
                write.Parameters.Add(Nullable(allocation.WorkOrderId));
                write.Parameters.Add(Nullable(allocation.ExperimentId));
                AddAll(
                    write, allocation.Quantity, allocation.StartsAt, allocation.EndsAt,
                    allocation.Status.ToString(), allocation.RequestedBy, allocation.Version);
                write.Parameters.Add(Nullable(allocation.CancellationReason));
                write.Parameters.Add(Nullable(allocation.CancelledBy));
                write.Parameters.Add(Nullable(allocation.CancelledAt));
            }
            else
            {
                // The interval, quantity and link are deliberately absent: a reservation
                // is cancelled, never rewritten.
                write.CommandText = """
                    UPDATE ch1.resource_allocations SET
                      status = $2, version = $3,
                      cancellation_reason = $4, cancelled_by = $5, cancelled_at = $6
                    WHERE allocation_id = $1 AND version = $7
                    """;
                AddAll(write, allocation.AllocationId, allocation.Status.ToString(), allocation.Version);
                write.Parameters.Add(Nullable(allocation.CancellationReason));
                write.Parameters.Add(Nullable(allocation.CancelledBy));
                write.Parameters.Add(Nullable(allocation.CancelledAt));
                write.Parameters.Add(Param(expectedAllocationVersion.Value));
            }

            int affected;
            try
            {
                affected = await write.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.CheckViolation)
            {
                // ch1.resource_allocations constrains the interval, the quantity, the
                // exactly-one link and the cancellation columns. Reported as the domain
                // rule rather than as a database fault.
                throw new DomainRuleException(
                    "ALLOCATION_REJECTED",
                    "The reservation violates a controlled constraint on resource allocations.");
            }

            if (expectedAllocationVersion is not null && affected == 0)
            {
                throw new DomainRuleException(
                    "CONCURRENCY_CONFLICT",
                    "The reservation changed since it was read.");
            }
        }

        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
    }
}
