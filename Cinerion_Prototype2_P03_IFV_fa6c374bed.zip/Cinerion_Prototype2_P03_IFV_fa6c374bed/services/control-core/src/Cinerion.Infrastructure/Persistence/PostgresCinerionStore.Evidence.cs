// PostgreSQL storage for reports and scan events.

using System.Text.Json;
using Cinerion.Domain.Common;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Quality;
using Npgsql;

namespace Cinerion.Infrastructure.Persistence;

/// <summary>
/// Reports and field scan events on the controlled schema.
/// </summary>
/// <requirements>CH1-RPT-FR-0001, CH1-RPT-FR-0002, CH1-MFG-FR-0002, CH1-TRC-FR-0002</requirements>
public sealed partial class PostgresCinerionStore
{
    private const string ReportProjection = """
        SELECT report_id, project_id, report_type, template_id, template_revision,
               input_object_type, input_object_ids, determinism_key, content_sha256,
               media_type, size_bytes, storage_uri, document_number, issue_status,
               approval_state, generated_by, generated_at
        FROM ch1.reports
        """;

    public async ValueTask<ReportRecord?> FindReportByDeterminismKeyAsync(
        Guid projectId,
        string determinismKey,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = $"{ReportProjection} WHERE project_id = $1 AND determinism_key = $2";
        command.Parameters.Add(Param(projectId));
        command.Parameters.Add(Param(determinismKey));
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        return await reader.ReadAsync(cancellationToken).ConfigureAwait(false) ? ReadReport(reader) : null;
    }

    public async ValueTask SaveReportAsync(ReportRecord report, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(report.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        // No ON CONFLICT DO UPDATE: a report is append-only, and reports_immutable would
        // refuse the update anyway. A clash on the determinism key means another caller
        // generated the same report first, which is a success for both of them.
        command.CommandText = """
            INSERT INTO ch1.reports(
                report_id, project_id, report_type, template_id, template_revision,
                input_object_type, input_object_ids, determinism_key, content_sha256,
                media_type, size_bytes, storage_uri, document_number, issue_status,
                approval_state, generated_by, generated_at)
            VALUES($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
            """;
        command.Parameters.Add(Param(report.ReportId));
        command.Parameters.Add(Param(report.ProjectId));
        AddAll(command, report.ReportType, report.TemplateId, report.TemplateRevision, report.InputObjectType);
        command.Parameters.Add(Param(JsonSerializer.Serialize(report.InputObjectIds, Json)));
        AddAll(command, report.DeterminismKey, report.ContentSha256, report.MediaType);
        command.Parameters.Add(Param(report.SizeBytes));
        AddAll(command, report.StorageUri, report.DocumentNumber, report.IssueStatus, report.ApprovalState, report.GeneratedBy);
        command.Parameters.Add(Param(report.GeneratedAt));

        try
        {
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            throw new DomainRuleException(
                "REPORT_ALREADY_GENERATED",
                "A report for these inputs under this template revision already exists.");
        }
    }

    public async ValueTask<ScanEventRecord?> FindScanEventByDeliveryAsync(
        Guid projectId,
        string deviceId,
        string identifierValue,
        DateTimeOffset scannedAt,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT scan_event_id, project_id, part_id, identifier_kind, identifier_value,
                   station_id, device_id, scanned_by, scanned_at, received_at,
                   session_signature_sha256, duplicate_of, resolution
            FROM ch1.scan_events
            WHERE project_id = $1 AND device_id = $2 AND identifier_value = $3
              AND scanned_at = $4 AND duplicate_of IS NULL
            """;
        command.Parameters.Add(Param(projectId));
        AddAll(command, deviceId, identifierValue);
        command.Parameters.Add(Param(scannedAt));
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        return await reader.ReadAsync(cancellationToken).ConfigureAwait(false) ? ReadScanEvent(reader) : null;
    }

    /// <summary>
    /// The scan register for one project, newest first.
    /// </summary>
    /// <remarks>
    /// Duplicates are included rather than hidden: a re-delivery points at the scan it
    /// repeats, and an evidence screen that silently dropped it would be concealing that the
    /// field device sent the same reading twice.
    /// </remarks>
    public async ValueTask<IReadOnlyList<ScanEventRecord>> ListScanEventsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT scan_event_id, project_id, part_id, identifier_kind, identifier_value,
                   station_id, device_id, scanned_by, scanned_at, received_at,
                   session_signature_sha256, duplicate_of, resolution
            FROM ch1.scan_events
            ORDER BY scanned_at DESC, scan_event_id DESC
            LIMIT $1
            """;
        command.Parameters.Add(Param(Math.Clamp(limit, 1, 500)));
        return await ReadManyAsync(command, ReadScanEvent, cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask SaveScanEventAsync(ScanEventRecord scanEvent, CancellationToken cancellationToken)
    {
        await using var connection = await dataSource
            .OpenForProjectAsync(scanEvent.ProjectId, cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ch1.scan_events(
                scan_event_id, project_id, part_id, identifier_kind, identifier_value,
                station_id, device_id, scanned_by, scanned_at, received_at,
                session_signature_sha256, duplicate_of, resolution)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            """;
        command.Parameters.Add(Param(scanEvent.ScanEventId));
        command.Parameters.Add(Param(scanEvent.ProjectId));
        command.Parameters.Add(Nullable(scanEvent.PartId));
        AddAll(command, scanEvent.IdentifierKind.ToString(), scanEvent.IdentifierValue,
            scanEvent.StationId, scanEvent.DeviceId, scanEvent.ScannedBy);
        command.Parameters.Add(Param(scanEvent.ScannedAt));
        command.Parameters.Add(Param(scanEvent.ReceivedAt));
        command.Parameters.Add(Param(scanEvent.SessionSignatureSha256));
        command.Parameters.Add(Nullable(scanEvent.DuplicateOf));
        command.Parameters.Add(Param(scanEvent.Resolution.ToString()));

        try
        {
            await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            // ux_scan_events_delivery. Two deliveries of the same read raced; the loser
            // is told so rather than silently dropped.
            throw new DomainRuleException(
                "SCAN_ALREADY_DELIVERED",
                "This scan has already been delivered.");
        }
    }


    /// <summary>
    /// Resolves a scanned identifier to a part.
    /// <para>
    /// A tag carries either the permanent identity URI CH1-MFG-FR-0002 assigns or the
    /// serial printed on the part, so both are accepted. The identifier is matched
    /// exactly - a prefix or case-insensitive match could resolve one part's tag to
    /// another part, which is the wrong-object error the interface exists to prevent.
    /// </para>
    /// </summary>
    public async ValueTask<PartRecord?> FindPartByIdentifierAsync(
        Guid projectId,
        string identifierValue,
        CancellationToken cancellationToken)
    {
        Guid partId;
        await using (var connection = await dataSource
            .OpenForProjectAsync(projectId, cancellationToken).ConfigureAwait(false))
        await using (var command = connection.CreateCommand())
        {
            command.CommandText = """
                SELECT part_id FROM ch1.physical_parts
                WHERE project_id = $1 AND (permanent_identity_uri = $2 OR serial_number = $3)
                """;
            command.Parameters.Add(Param(projectId));
            AddAll(command, identifierValue, identifierValue);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
            if (!await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
            {
                return null;
            }

            partId = reader.GetGuid(0);
        }

        // The full record, measurements and release included, comes from the one place
        // that assembles it, so a scan and a genealogy read cannot disagree.
        return await FindPartAsync(partId, cancellationToken).ConfigureAwait(false);
    }

    private static ReportRecord ReadReport(NpgsqlDataReader reader) => new(
        reader.GetGuid(0),
        reader.GetGuid(1),
        reader.GetString(2),
        reader.GetString(3),
        reader.GetString(4),
        reader.GetString(5),
        JsonSerializer.Deserialize<List<string>>(reader.GetString(6), Json) ?? [],
        reader.GetString(7),
        reader.GetString(8),
        reader.GetString(9),
        reader.GetInt64(10),
        reader.GetString(11),
        reader.GetString(12),
        reader.GetString(13),
        reader.GetString(14),
        reader.GetString(15),
        reader.GetFieldValue<DateTimeOffset>(16));

    private static ScanEventRecord ReadScanEvent(NpgsqlDataReader reader) => new(
        reader.GetGuid(0),
        reader.GetGuid(1),
        reader.IsDBNull(2) ? null : reader.GetGuid(2),
        Enum.Parse<ScanIdentifierKind>(reader.GetString(3)),
        reader.GetString(4),
        reader.GetString(5),
        reader.GetString(6),
        reader.GetString(7),
        reader.GetFieldValue<DateTimeOffset>(8),
        reader.GetFieldValue<DateTimeOffset>(9),
        reader.GetString(10),
        reader.IsDBNull(11) ? null : reader.GetGuid(11),
        Enum.Parse<ScanResolution>(reader.GetString(12)));
}
