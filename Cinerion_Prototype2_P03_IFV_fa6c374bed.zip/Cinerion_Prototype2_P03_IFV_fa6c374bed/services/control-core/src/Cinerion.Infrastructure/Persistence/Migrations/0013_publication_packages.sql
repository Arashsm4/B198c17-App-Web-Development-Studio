-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV publication packages and their approvals
-- Copyright © 2026 IR. All rights reserved.

-- CH1-DOC-FR-0004, status "Baseline P03" rather than a design target:
--
--   "Public material shall be generated only from an approved redaction profile and shall
--    pass content diff, metadata scrub, secret scan, owner approval and checksum
--    generation before publication."
--
-- Two controlled operations serve it - POST /api/v1/publication-packages and
-- POST /api/v1/publication-packages/{packageId}/approvals - and both answered 501. They
-- had been grouped with the secure document vault, which genuinely is a future phase:
-- CH1-DOC-FR-0002 wants a unique data-encryption key per document behind a separate
-- key-encryption boundary, and CH1-DOC-FR-0003 wants a hardware-backed credential to
-- decrypt. This requirement needs none of that. It is a review pipeline, and every control
-- it names can be executed today.
--
-- WHAT IS NOT DONE, stated here rather than left to be discovered: the content diff
-- against the source documents' own text. This platform holds each controlled document's
-- checksum and a representation URI, not its bytes - the vault that would hold them is the
-- gated phase - so a derivative cannot be diffed against its sources. What IS checked is
-- the part of that control which does not need the bytes: a "redacted derivative" whose
-- checksum equals a source document's checksum has redacted nothing, and is refused. The
-- package records content_diff_performed = false with its reason, on the same terms as a
-- device revocation reporting brokerTopicAclRevoked = false: the half that did not happen
-- is on the face of the record rather than implied by its absence.

BEGIN;

-- ------------------------------------------------------------------ packages

CREATE TABLE IF NOT EXISTS ch1.publication_packages (
    package_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),

    -- "generated only from an approved redaction profile". The profile and the revision it
    -- was applied at are both pinned: a profile that changed later must not be able to
    -- claim it governed a package produced under an earlier version of itself.
    redaction_profile text NOT NULL CHECK (length(btrim(redaction_profile)) > 0),
    profile_revision text NOT NULL CHECK (length(btrim(profile_revision)) > 0),

    title text NOT NULL CHECK (length(btrim(title)) BETWEEN 1 AND 200),

    -- The allowlisted inputs, by identifier, with the classification each held when the
    -- package was built. Recorded rather than re-read at approval time, because a document
    -- reclassified afterwards must not silently change what a reviewer approved.
    source_documents jsonb NOT NULL DEFAULT '[]'::jsonb,
    CHECK (jsonb_typeof(source_documents) = 'array'),
    CHECK (jsonb_array_length(source_documents) BETWEEN 1 AND 200),

    content_sha256 char(64) NOT NULL CHECK (content_sha256 ~ '^[a-f0-9]{64}$'),
    media_type text NOT NULL,
    size_bytes bigint NOT NULL CHECK (size_bytes > 0),
    storage_uri text NOT NULL,

    -- What the pipeline actually did, recorded rather than asserted. A package that claims
    -- to have been scrubbed and can name nothing it removed is a package nobody can check.
    metadata_removed jsonb NOT NULL DEFAULT '[]'::jsonb,
    CHECK (jsonb_typeof(metadata_removed) = 'array'),
    metadata_retained jsonb NOT NULL DEFAULT '{}'::jsonb,
    CHECK (jsonb_typeof(metadata_retained) = 'object'),

    -- The secret scan is a gate, not a note: a package is never created carrying a
    -- finding, so this column exists to record that the scan ran and what it looked for.
    secret_scan_profile text NOT NULL,
    secret_scan_patterns integer NOT NULL CHECK (secret_scan_patterns > 0),

    -- The half of the diff control that can be performed without the document bytes, and
    -- an explicit statement that the other half was not.
    content_diff_performed boolean NOT NULL,
    content_diff_note text NOT NULL CHECK (length(btrim(content_diff_note)) > 0),

    -- Nothing is published by this platform. The state says whether the reviews CH1
    -- requires have completed, and publication itself remains an act outside it.
    state text NOT NULL CHECK (state IN ('PendingApproval', 'Approved', 'Rejected')),

    created_by text NOT NULL CHECK (length(btrim(created_by)) > 0),
    created_at timestamptz NOT NULL,
    decided_at timestamptz,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),

    -- A decided package has a decision time and a pending one does not. Neither state can
    -- be half-expressed.
    CHECK ((state = 'PendingApproval') = (decided_at IS NULL))
);

CREATE INDEX IF NOT EXISTS ix_publication_packages_project_state
    ON ch1.publication_packages (project_id, state, created_at DESC);

ALTER TABLE ch1.publication_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.publication_packages FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.publication_packages;
CREATE POLICY project_isolation ON ch1.publication_packages
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

-- The package's state advances as reviews arrive, so UPDATE is needed; DELETE is not, and
-- 0002's default privileges would otherwise have granted it. A public derivative that
-- could be removed from the register would leave a published artefact with no record of
-- what approved it.
GRANT SELECT, INSERT, UPDATE ON ch1.publication_packages TO cinerion_app;
REVOKE DELETE ON ch1.publication_packages FROM cinerion_app;

-- -------------------------------------------------------------- the approvals

CREATE TABLE IF NOT EXISTS ch1.publication_package_approvals (
    approval_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    package_id uuid NOT NULL REFERENCES ch1.publication_packages(package_id),

    -- "IR plus Document Control review" - two reviews, by two named capacities. Recorded
    -- as the capacity rather than as whichever role the deployment mapped it to, so a
    -- change to that mapping cannot rewrite what a past approval meant.
    reviewer_capacity text NOT NULL CHECK (reviewer_capacity IN ('ProjectOwner', 'DocumentControl')),

    decision text NOT NULL CHECK (decision IN ('Approved', 'Rejected')),
    reviewed_by text NOT NULL CHECK (length(btrim(reviewed_by)) > 0),
    reviewed_role text NOT NULL CHECK (length(btrim(reviewed_role)) > 0),

    -- "visual review and checksum". The reviewer states the checksum of what they looked
    -- at, and it is compared with the package's own. A reviewer who approved a different
    -- artefact has approved nothing, and this is the only way the platform can tell.
    reviewed_checksum char(64) NOT NULL CHECK (reviewed_checksum ~ '^[a-f0-9]{64}$'),

    comment text NOT NULL CHECK (length(btrim(comment)) BETWEEN 1 AND 2000),
    reviewed_at timestamptz NOT NULL,

    -- One decision per capacity. A reviewer who could approve twice would be both of the
    -- two people the control requires.
    UNIQUE (package_id, reviewer_capacity)
);

CREATE INDEX IF NOT EXISTS ix_publication_approvals_package
    ON ch1.publication_package_approvals (project_id, package_id, reviewed_at);

ALTER TABLE ch1.publication_package_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.publication_package_approvals FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.publication_package_approvals;
CREATE POLICY project_isolation ON ch1.publication_package_approvals
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

GRANT SELECT, INSERT ON ch1.publication_package_approvals TO cinerion_app;
REVOKE UPDATE, DELETE ON ch1.publication_package_approvals FROM cinerion_app;

-- An approval is permanent evidence of a review that happened. One that could be edited
-- afterwards would evidence nothing, and one that could be deleted would let a package
-- reach publication with its dissent removed.
CREATE TRIGGER publication_approvals_immutable
    BEFORE UPDATE OR DELETE ON ch1.publication_package_approvals
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

COMMIT;
