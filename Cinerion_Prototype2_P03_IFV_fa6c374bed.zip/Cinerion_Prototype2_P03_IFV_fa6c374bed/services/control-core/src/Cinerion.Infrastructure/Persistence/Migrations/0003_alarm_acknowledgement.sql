-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV alarm acknowledgement comment
-- Copyright © 2026 IR. All rights reserved.

-- api_endpoints.json makes "Comment, identity, timestamp and no control side effect"
-- the control on POST /api/v1/alarms/{alarmId}/acknowledgements, and CH1-COL-FR-0002
-- requires acknowledgement state to be retained with its author and time. ch1.alarms
-- as defined in 0001 carries acknowledged_by and acknowledged_at but no column for the
-- comment, and ch1.audit_events stores only a payload hash, so an acknowledgement
-- comment recorded solely in the audit chain could be verified but never read back.
--
-- Accepting a required controlled field and then discarding it would be a
-- fake-success response, so the column is added here. This is additive only: no
-- existing column, constraint or semantic changes, which is the compatibility rule
-- CH1-COM-ICD-0001 states for contract evolution.
--
-- Conflict reported to the owner rather than worked around: the P03 data dictionary
-- for ch1.alarms and the P03 API control column disagree, and this migration resolves
-- it in favour of the API control.

BEGIN;

ALTER TABLE ch1.alarms
    ADD COLUMN IF NOT EXISTS acknowledgement_comment text;

-- An acknowledgement is identity, time and comment together. Recording a comment
-- against no acknowledgement, or an acknowledgement with no author, would leave
-- unattributable evidence, so the columns are constrained to move as one.
ALTER TABLE ch1.alarms
    DROP CONSTRAINT IF EXISTS ck_alarms_acknowledgement_complete;
ALTER TABLE ch1.alarms
    ADD CONSTRAINT ck_alarms_acknowledgement_complete CHECK (
        (acknowledged_by IS NULL AND acknowledged_at IS NULL AND acknowledgement_comment IS NULL)
        OR (acknowledged_by IS NOT NULL AND acknowledged_at IS NOT NULL AND acknowledgement_comment IS NOT NULL));

-- The alarm list is served newest-and-most-urgent first, filtered by state. The index
-- from 0001 is (project_id, state, priority), which does not order within a state, so
-- keyset pagination over (priority, activated_at DESC, alarm_id) would sort every
-- matching row on each page.
CREATE INDEX IF NOT EXISTS ix_alarm_project_page
    ON ch1.alarms (project_id, priority, activated_at DESC, alarm_id);

-- Telemetry is queried per project over a bounded window. ix_telemetry_cell_channel_time
-- from 0001 covers a cell-and-channel query but not one scoped only by project and
-- time, which is what the operations view asks for first.
CREATE INDEX IF NOT EXISTS ix_telemetry_project_time
    ON ch1.telemetry_samples (project_id, sampled_at DESC);

COMMIT;
