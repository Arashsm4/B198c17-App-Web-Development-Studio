-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV reports and field scan events
-- Copyright © 2026 IR. All rights reserved.

-- Two subsystems whose operations are in the controlled catalogue but whose records have
-- no table in 0001. entities.json declares Document and Evidence and stops there: there
-- is no Report or ScanEvent entity, exactly as there is none for a promotion request. The same resolution 0006 chose is used here -
-- add the table the operation needs, additively, and report the omission - because the
-- alternative is an operation that accepts a controlled request and keeps no record of it.
--
-- Conflicts reported to the owner rather than worked around.

BEGIN;

-- ----------------------------------------------------------------- reports

-- CH1-RPT-FR-0001 wants a report generated from controlled records that identifies the
-- exact revisions it drew on, and api_endpoints.json makes "template revision, immutable
-- inputs and checksum" the control. determinism_key is the hash of the template revision
-- and the sorted input identifiers together: the same inputs under the same template
-- return the report already generated instead of a second one that might differ. That is
-- what makes generation deterministic rather than merely repeatable.
CREATE TABLE IF NOT EXISTS ch1.reports (
    report_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    report_type text NOT NULL CHECK (length(report_type) BETWEEN 1 AND 80),
    template_id text NOT NULL,
    template_revision text NOT NULL,

    -- What the report was generated from, pinned. A reader can re-fetch each identifier
    -- and confirm the report covers exactly these records and no others.
    input_object_type text NOT NULL,
    input_object_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
    CHECK (jsonb_typeof(input_object_ids) = 'array'),
    CHECK (jsonb_array_length(input_object_ids) BETWEEN 1 AND 500),

    determinism_key char(64) NOT NULL CHECK (determinism_key ~ '^[a-f0-9]{64}$'),
    content_sha256 char(64) NOT NULL CHECK (content_sha256 ~ '^[a-f0-9]{64}$'),
    media_type text NOT NULL,
    size_bytes bigint NOT NULL CHECK (size_bytes >= 0),
    storage_uri text NOT NULL,

    -- The report states the authority it was produced under. CH1-RPT-FR-0002 requires
    -- document number, revision, issue status and approval state to appear on it, and a
    -- report that omitted them could be mistaken for an approved deliverable.
    document_number text NOT NULL,
    issue_status text NOT NULL,
    approval_state text NOT NULL CHECK (approval_state IN ('Unapproved', 'Approved')),

    generated_by text NOT NULL,
    generated_at timestamptz NOT NULL,

    UNIQUE (project_id, determinism_key)
);

ALTER TABLE ch1.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.reports FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.reports;
CREATE POLICY project_isolation ON ch1.reports
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON ch1.reports TO cinerion_app;

-- A generated report is evidence of what the records said at that moment. Editing one
-- afterwards would make the checksum a claim about something that no longer exists.
CREATE TRIGGER reports_immutable
    BEFORE UPDATE OR DELETE ON ch1.reports
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

-- ------------------------------------------------------------- scan events

-- CH1-MFG-FR-0002 gives a physical part a permanent identity, and CH1-COM-IF-0012 has the
-- Field Companion resolve that identity from a QR code or RFID tag. api_endpoints.json
-- makes "signed session, station scope and duplicate handling" the control.
--
-- A scan resolves identity and state. It confers no authority: reading a tag has never
-- started equipment, released a part or satisfied a permissive, and there is deliberately
-- no column here that could express one.
CREATE TABLE IF NOT EXISTS ch1.scan_events (
    scan_event_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    part_id uuid REFERENCES ch1.physical_parts(part_id),

    -- What was read, and how. An RC522-class reader is restricted to part identification
    -- by CH1-CYB-IAM-0001, so the tag class travels with the event and a later reader can
    -- see that a cloneable UID was never treated as proof of a person.
    identifier_kind text NOT NULL CHECK (identifier_kind IN ('QR', 'DataMatrix', 'RFID', 'NFC')),
    identifier_value text NOT NULL CHECK (length(identifier_value) BETWEEN 1 AND 512),

    station_id text NOT NULL,
    device_id text NOT NULL REFERENCES ch1.devices(device_id),
    scanned_by text NOT NULL,

    -- Store and forward: a field device may scan offline and deliver later, so both times
    -- are kept for the same reason ch1.telemetry_samples keeps both.
    scanned_at timestamptz NOT NULL,
    received_at timestamptz NOT NULL,

    -- The signature over the scanning session, so an event cannot be fabricated by
    -- anything that did not hold the device's session key.
    session_signature_sha256 char(64) NOT NULL CHECK (session_signature_sha256 ~ '^[a-f0-9]{64}$'),

    -- Duplicate handling: a re-delivered scan is recorded as pointing at the first one
    -- rather than dropped, so an operator can see that the device retried and a gap in
    -- the sequence is never mistaken for a missed scan.
    duplicate_of uuid REFERENCES ch1.scan_events(scan_event_id),

    resolution text NOT NULL CHECK (resolution IN ('Resolved', 'UnknownIdentifier', 'Duplicate')),

    CHECK (received_at >= scanned_at),
    CHECK ((resolution = 'Duplicate') = (duplicate_of IS NOT NULL)),
    CHECK ((resolution = 'Resolved') = (part_id IS NOT NULL))
);

-- One physical scan, one primary record. The same tag read by the same device at the
-- same instant is the same event however many times it is delivered.
CREATE UNIQUE INDEX IF NOT EXISTS ux_scan_events_delivery
    ON ch1.scan_events (project_id, device_id, identifier_value, scanned_at)
    WHERE duplicate_of IS NULL;

CREATE INDEX IF NOT EXISTS ix_scan_events_part
    ON ch1.scan_events (project_id, part_id, scanned_at DESC);

ALTER TABLE ch1.scan_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.scan_events FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.scan_events;
CREATE POLICY project_isolation ON ch1.scan_events
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON ch1.scan_events TO cinerion_app;

CREATE TRIGGER scan_events_immutable
    BEFORE UPDATE OR DELETE ON ch1.scan_events
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

COMMIT;
