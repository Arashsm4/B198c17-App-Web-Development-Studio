-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV telemetry retention role
-- Copyright © 2026 IR. All rights reserved.

-- Separate from 0010 for the same reason 0002 is separate from 0001, and it is not
-- tidiness. A role is a cluster object and its grants are schema objects: neither is in a
-- schema dump, so a restored database has the retention tables and the disposal procedure
-- with no role permitted to run them - and, worse, cinerion_app's blanket DELETE on
-- telemetry silently back in force, because the REVOKE below is a grant decision that the
-- dump does not carry either. That is defect 13's exact shape: an authorisation decision
-- quietly reinstated by a restore.
--
-- scripts/restore.sh therefore re-asserts this file and 0002 after every restore, and
-- refuses to report success if either role comes back able to bypass row-level security.
-- Everything here is idempotent so that re-asserting it is always safe.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cinerion_retention') THEN
        -- No password, for the same reason cinerion_app has none: a credential in a
        -- committed migration is a published credential. NOLOGIN until the deployment
        -- grants it from controlled secret storage.
        CREATE ROLE cinerion_retention NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE INHERIT;
    END IF;
END $$;

ALTER ROLE cinerion_retention NOSUPERUSER NOBYPASSRLS;

GRANT USAGE ON SCHEMA ch1 TO cinerion_retention;

-- It reads everything it needs to decide what is protected, and writes only its own
-- evidence. The single DELETE grant is the whole of its destructive authority.
GRANT SELECT ON ALL TABLES IN SCHEMA ch1 TO cinerion_retention;
GRANT INSERT ON ch1.telemetry_summaries TO cinerion_retention;
GRANT INSERT ON ch1.telemetry_disposals TO cinerion_retention;
GRANT DELETE ON ch1.telemetry_samples TO cinerion_retention;
GRANT EXECUTE ON FUNCTION ch1.current_project_id() TO cinerion_retention;

-- Tables added later are readable by this role and nothing more; a future table does not
-- silently become disposable.
ALTER DEFAULT PRIVILEGES IN SCHEMA ch1 GRANT SELECT ON TABLES TO cinerion_retention;

-- The application role loses the ability to delete telemetry. Nothing in Control Core
-- issues a DELETE against ch1.telemetry_samples, so this removes authority nobody was
-- using - and it is what makes "deletion is authorised and logged" a property of the
-- database rather than a description of current behaviour.
REVOKE DELETE ON ch1.telemetry_samples FROM cinerion_app;
REVOKE UPDATE, DELETE ON ch1.telemetry_summaries FROM cinerion_app;
REVOKE UPDATE, DELETE ON ch1.telemetry_disposals FROM cinerion_app;

GRANT EXECUTE ON FUNCTION ch1.dispose_telemetry(uuid, integer, text, text) TO cinerion_retention;
-- Deliberately not granted to cinerion_app. The service has no controlled operation that
-- disposes of telemetry, and CH1-DBA-DD-0001 makes this an administrative act.
REVOKE EXECUTE ON FUNCTION ch1.dispose_telemetry(uuid, integer, text, text) FROM PUBLIC;

COMMIT;
