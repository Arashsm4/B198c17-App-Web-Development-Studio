-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV telemetry retention and downsampling
-- Copyright © 2026 IR. All rights reserved.

-- CH1-DBA-DD-0001 states this subsystem in four sentences:
--
--   "High-rate telemetry enters a bounded pipeline with freshness and quality, then is
--    retained raw or aggregated according to declared need. Critical events and acceptance
--    measurements are never lost through telemetry downsampling. Retention is based on
--    evidence, legal and project needs; deletion is authorised, logged and compatible with
--    immutable-release obligations."
--
-- and the entity register states the retention itself: TelemetrySample is Operational,
-- "Configurable; summary permanent". 0001 already carried the intent in a comment beside
-- the immutability triggers - "Retention is a separate controlled administrative process
-- with independent evidence" - and nothing implemented it. Raw samples accumulated forever.
--
-- Three things are added here, and the order of the arguments matters.
--
-- 1. ch1.telemetry_summaries. The permanent half of "configurable; summary permanent": an
--    hourly aggregate per project, cell, device and channel. Immutable, like every other
--    permanent record, so a summary cannot be edited after the raw rows behind it are gone.
--
-- 2. ch1.telemetry_disposals. The "authorised, logged" half. Who authorised it, why, what
--    window, what cutoff and what it actually did - counted, not estimated. Append-only.
--
-- 3. ch1.dispose_telemetry(). SECURITY INVOKER on purpose. It runs with the caller's own
--    privileges, so "this procedure cannot delete an alarm" is a fact about the grants
--    rather than a promise about the SQL. A SECURITY DEFINER function would run as the
--    owner and make every protection below a matter of the body being careful.
--
-- The role those grants belong to is created in 0011, separately and for the same reason
-- cinerion_app is separate from 0001: a role and its grants are cluster and schema objects
-- that a schema dump does not carry, so a restore has to re-assert them from their single
-- definition. Splitting them out is what lets scripts/restore.sh do that without replaying
-- a migration that creates tables.

BEGIN;

-- ---------------------------------------------------------------------------- summaries

CREATE TABLE ch1.telemetry_summaries (
    summary_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid NOT NULL REFERENCES ch1.cells(cell_id),
    device_id text NOT NULL,
    channel_id text NOT NULL,
    unit text NOT NULL,
    bucket_start timestamptz NOT NULL,
    bucket_end timestamptz NOT NULL,
    sample_count bigint NOT NULL CHECK (sample_count > 0),
    minimum double precision NOT NULL,
    maximum double precision NOT NULL,
    average double precision NOT NULL,
    first_sampled_at timestamptz NOT NULL,
    last_sampled_at timestamptz NOT NULL,
    -- The worst quality and freshness seen in the bucket, never the best and never a
    -- default. A summary that reported Good because most of its samples were Good would
    -- launder the ones that were not.
    worst_quality ch1.data_quality NOT NULL,
    worst_freshness ch1.freshness NOT NULL,
    summarised_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (bucket_end > bucket_start),
    CHECK (maximum >= minimum),
    CHECK (average BETWEEN minimum AND maximum),
    CHECK (last_sampled_at >= first_sampled_at),
    -- One summary per bucket. Re-running disposal must not double-count a window, and a
    -- second summary for the same hour is how that would happen.
    UNIQUE (project_id, cell_id, device_id, channel_id, bucket_start)
);

CREATE INDEX ix_telemetry_summaries_lookup
    ON ch1.telemetry_summaries (project_id, cell_id, channel_id, bucket_start DESC);

-- ---------------------------------------------------------------------------- disposals

CREATE TABLE ch1.telemetry_disposals (
    disposal_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    -- Attributable. CH1-DBA-DD-0001 makes deletion authorised, and an authorisation with
    -- nobody's name on it is not one.
    authorised_by text NOT NULL CHECK (length(btrim(authorised_by)) > 0),
    reason text NOT NULL CHECK (length(btrim(reason)) > 0),
    retention_days integer NOT NULL CHECK (retention_days >= 7),
    cutoff timestamptz NOT NULL,
    samples_summarised bigint NOT NULL CHECK (samples_summarised >= 0),
    samples_deleted bigint NOT NULL CHECK (samples_deleted >= 0),
    -- Counted separately, because "nothing was deleted" and "everything older than the
    -- cutoff was evidence for something permanent" are different outcomes and an operator
    -- should not have to guess which happened.
    samples_retained_as_evidence bigint NOT NULL CHECK (samples_retained_as_evidence >= 0),
    buckets_written bigint NOT NULL CHECK (buckets_written >= 0),
    executed_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX ix_telemetry_disposals_project_time
    ON ch1.telemetry_disposals (project_id, executed_at DESC);

-- Both are permanent evidence and neither may be rewritten. A disposal record that could
-- be edited afterwards would evidence nothing at all.
CREATE TRIGGER telemetry_summaries_immutable
    BEFORE UPDATE OR DELETE ON ch1.telemetry_summaries
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();
CREATE TRIGGER telemetry_disposals_immutable
    BEFORE UPDATE OR DELETE ON ch1.telemetry_disposals
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

-- Project isolation, on the same terms as every other controlled table. The retention role
-- is not exempt: it must set ch1.project_id like anything else, so a disposal is scoped to
-- one project by the same mechanism that scopes a read.
ALTER TABLE ch1.telemetry_summaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.telemetry_summaries FORCE ROW LEVEL SECURITY;
CREATE POLICY project_isolation ON ch1.telemetry_summaries
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

ALTER TABLE ch1.telemetry_disposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.telemetry_disposals FORCE ROW LEVEL SECURITY;
CREATE POLICY project_isolation ON ch1.telemetry_disposals
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

-- ------------------------------------------------------------------------ the procedure

CREATE FUNCTION ch1.dispose_telemetry(
    p_project uuid,
    p_retention_days integer,
    p_authorised_by text,
    p_reason text)
RETURNS ch1.telemetry_disposals
LANGUAGE plpgsql
-- SECURITY INVOKER, stated rather than defaulted. This function's safety is the caller's
-- grants: run as cinerion_retention it can delete telemetry and nothing else, and no
-- mistake in the body below can widen that.
SECURITY INVOKER
AS $$
DECLARE
    v_cutoff timestamptz;
    v_buckets bigint := 0;
    v_summarised bigint := 0;
    v_deleted bigint := 0;
    v_protected bigint := 0;
    v_disposal ch1.telemetry_disposals;
BEGIN
    IF p_retention_days IS NULL OR p_retention_days < 7 THEN
        RAISE EXCEPTION 'CH1 retention window must be at least 7 days; % was requested', p_retention_days
            USING ERRCODE = '22023';
    END IF;

    IF p_authorised_by IS NULL OR length(btrim(p_authorised_by)) = 0
       OR p_reason IS NULL OR length(btrim(p_reason)) = 0 THEN
        RAISE EXCEPTION 'CH1 telemetry disposal requires a named authoriser and a reason'
            USING ERRCODE = '22023';
    END IF;

    IF p_project IS DISTINCT FROM ch1.current_project_id() THEN
        RAISE EXCEPTION 'CH1 telemetry disposal is scoped to the session project; % was requested', p_project
            USING ERRCODE = '42501';
    END IF;

    v_cutoff := clock_timestamp() - make_interval(days => p_retention_days);

    -- Every sample older than the cutoff that is NOT evidence for a permanent record.
    -- Both halves of "critical events and acceptance measurements are never lost" are
    -- expressed here, once, and everything below reads from it.
    CREATE TEMP TABLE disposable ON COMMIT DROP AS
    SELECT s.sample_id, s.sampled_at, s.project_id, s.cell_id, s.device_id, s.channel_id,
           s.unit, s.value, s.quality, s.freshness
    FROM ch1.telemetry_samples s
    WHERE s.project_id = p_project
      AND s.sampled_at < v_cutoff
      -- A critical event: the samples that raised an alarm and the ones inside its
      -- activation window on the device that raised it. An alarm with no clear time is
      -- still happening, so everything after its activation is still its evidence.
      AND NOT EXISTS (
          SELECT 1 FROM ch1.alarms a
          WHERE a.project_id = s.project_id
            AND a.cell_id = s.cell_id
            AND a.source_id = s.device_id
            AND s.sampled_at >= a.activated_at
            AND s.sampled_at <= coalesce(a.cleared_at, s.sampled_at))
      -- An acceptance measurement: ch1.measurements records the device and the source
      -- sample time it was taken from, so the sample behind a controlled measurement is
      -- identified exactly rather than approximated by a window.
      AND NOT EXISTS (
          SELECT 1 FROM ch1.measurements m
          WHERE m.project_id = s.project_id
            AND m.source_device_id = s.device_id
            AND m.source_sample_time = s.sampled_at);

    SELECT count(*) INTO v_summarised FROM disposable;

    SELECT count(*) INTO v_protected
    FROM ch1.telemetry_samples s
    WHERE s.project_id = p_project
      AND s.sampled_at < v_cutoff
      AND NOT EXISTS (SELECT 1 FROM disposable d WHERE d.sample_id = s.sample_id AND d.sampled_at = s.sampled_at);

    -- Summarise before deleting, never after. A crash between the two must leave raw rows
    -- that can be summarised again, not a hole with no aggregate over it.
    WITH written AS (
        INSERT INTO ch1.telemetry_summaries (
            project_id, cell_id, device_id, channel_id, unit, bucket_start, bucket_end,
            sample_count, minimum, maximum, average, first_sampled_at, last_sampled_at,
            worst_quality, worst_freshness)
        SELECT d.project_id, d.cell_id, d.device_id, d.channel_id, min(d.unit),
               date_trunc('hour', d.sampled_at),
               date_trunc('hour', d.sampled_at) + interval '1 hour',
               count(*), min(d.value), max(d.value), avg(d.value),
               min(d.sampled_at), max(d.sampled_at),
               -- Worst, by the declared order of each enumeration rather than
               -- alphabetically: an ordering accident here would silently upgrade quality.
               -- Worst first: the enumerations are declared best-first in 0001, so the
               -- order below is the reverse of the type's own and is written out rather
               -- than derived. Every value of both types appears exactly once, and
               -- array_position returns NULL for one that does not - which would fail the
               -- NOT NULL column rather than quietly summarise as something better.
               (ARRAY['Bad', 'Unknown', 'Uncertain', 'Good']::ch1.data_quality[])[
                   min(array_position(ARRAY['Bad', 'Unknown', 'Uncertain', 'Good']::ch1.data_quality[], d.quality))],
               (ARRAY['Disconnected', 'Unknown', 'Maintenance', 'Stale', 'Simulated', 'Live']::ch1.freshness[])[
                   min(array_position(ARRAY['Disconnected', 'Unknown', 'Maintenance', 'Stale', 'Simulated', 'Live']::ch1.freshness[], d.freshness))]
        FROM disposable d
        GROUP BY d.project_id, d.cell_id, d.device_id, d.channel_id, date_trunc('hour', d.sampled_at)
        -- A bucket already summarised by an earlier run is left alone. Its raw rows are
        -- still deletable below, because an aggregate over them already exists.
        ON CONFLICT (project_id, cell_id, device_id, channel_id, bucket_start) DO NOTHING
        RETURNING 1)
    SELECT count(*) INTO v_buckets FROM written;

    -- Only rows whose bucket now has a summary. The join is the guarantee that no raw
    -- sample is removed without an aggregate standing in for it.
    WITH removed AS (
        DELETE FROM ch1.telemetry_samples s
        USING disposable d
        WHERE s.sample_id = d.sample_id
          AND s.sampled_at = d.sampled_at
          AND EXISTS (
              SELECT 1 FROM ch1.telemetry_summaries t
              WHERE t.project_id = d.project_id
                AND t.cell_id = d.cell_id
                AND t.device_id = d.device_id
                AND t.channel_id = d.channel_id
                AND t.bucket_start = date_trunc('hour', d.sampled_at))
        RETURNING 1)
    SELECT count(*) INTO v_deleted FROM removed;

    INSERT INTO ch1.telemetry_disposals (
        project_id, authorised_by, reason, retention_days, cutoff,
        samples_summarised, samples_deleted, samples_retained_as_evidence, buckets_written)
    VALUES (
        p_project, btrim(p_authorised_by), btrim(p_reason), p_retention_days, v_cutoff,
        v_summarised, v_deleted, v_protected, v_buckets)
    RETURNING * INTO v_disposal;

    RETURN v_disposal;
END;
$$;

COMMIT;
