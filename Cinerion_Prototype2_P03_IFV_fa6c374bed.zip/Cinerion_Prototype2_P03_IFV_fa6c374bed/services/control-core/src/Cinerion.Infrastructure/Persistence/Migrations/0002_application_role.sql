-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV application role
-- Copyright © 2026 IR. All rights reserved.

-- 0001 defines row-level security on every controlled table and forces it with
-- FORCE ROW LEVEL SECURITY. That has no effect on a PostgreSQL superuser: superusers
-- and roles with BYPASSRLS ignore every policy. The container bootstrap role
-- (POSTGRES_USER) is a superuser, so an application connecting with it would read and
-- write across every project while appearing to be governed by the policies.
--
-- .env.example already names the intended connection role, cinerion_app, but no
-- migration created it. This adds that role and the grants the schema's own isolation
-- design presupposes. It changes no table, column or constraint.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cinerion_app') THEN
        -- No password here. Credentials are supplied by the deployment from
        -- controlled secret storage; a password in a committed migration would be a
        -- published credential. NOLOGIN until the deployment grants it.
        CREATE ROLE cinerion_app NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE INHERIT;
    END IF;
END $$;

-- Explicitly reassert the two attributes that would silently disable isolation, in
-- case the role already existed with different ones.
ALTER ROLE cinerion_app NOSUPERUSER NOBYPASSRLS;

GRANT USAGE ON SCHEMA ch1 TO cinerion_app;

-- The application reads and writes controlled records. It is deliberately granted no
-- DDL: schema change is a reviewed migration, not something the running service can do.
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA ch1 TO cinerion_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA ch1 TO cinerion_app;
GRANT EXECUTE ON FUNCTION ch1.current_project_id() TO cinerion_app;

-- Tables added by later migrations inherit the same grants rather than being
-- unreachable until someone remembers to grant them.
ALTER DEFAULT PRIVILEGES IN SCHEMA ch1
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO cinerion_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA ch1
    GRANT USAGE, SELECT ON SEQUENCES TO cinerion_app;

-- The immutability triggers on audit_events, measurements and release_records already
-- refuse UPDATE and DELETE for every role, so the DELETE grant above cannot remove
-- controlled evidence. Retention remains a separate administrative process.

COMMIT;
