-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV device enrolment and revocation
-- Copyright © 2026 IR. All rights reserved.

-- ch1.devices already carries certificate_thumbprint, trust_state, capability_manifest
-- and revoked_at, so enrolment needs no new table. What it lacks is a record of why
-- trust was withdrawn and by whom: api_endpoints.json makes revocation a Cybersecurity
-- Administrator action with audit, CH1-IAM-FR-0006 requires credentials to be
-- attributable and auditable, and ch1.audit_events stores a payload hash rather than the
-- payload, so a reason recorded only in the audit chain could be verified but never read
-- back. Same disagreement 0003 and 0005 record for alarms and reservations.
--
-- Additive only: no existing column, constraint or semantic changes.

BEGIN;

ALTER TABLE ch1.devices
    ADD COLUMN IF NOT EXISTS revocation_reason text,
    ADD COLUMN IF NOT EXISTS revoked_by text;

-- A revocation is a time, a reason and an author together. A device marked revoked with
-- no attribution would be unattributable evidence of a security decision.
ALTER TABLE ch1.devices
    DROP CONSTRAINT IF EXISTS ck_devices_revocation_complete;
ALTER TABLE ch1.devices
    ADD CONSTRAINT ck_devices_revocation_complete CHECK (
        (revoked_at IS NULL AND revocation_reason IS NULL AND revoked_by IS NULL)
        OR (revoked_at IS NOT NULL AND revocation_reason IS NOT NULL AND revoked_by IS NOT NULL));

-- One certificate, one device. Without this the same certificate could be enrolled
-- against two device identities, which is precisely a cloned credential going unnoticed;
-- CH1-CYB-CSRS-0001 requires device identities to be unique. Partial, because a device
-- awaiting enrolment legitimately holds no thumbprint.
CREATE UNIQUE INDEX IF NOT EXISTS ux_devices_certificate_thumbprint
    ON ch1.devices (project_id, certificate_thumbprint)
    WHERE certificate_thumbprint IS NOT NULL;

-- The trust state is a closed set. 0001 declared it as free text, so a typo could leave a
-- device in a state nothing recognises — and IsTrusted compares for equality, so an
-- unrecognised value fails closed but silently.
ALTER TABLE ch1.devices
    DROP CONSTRAINT IF EXISTS ck_devices_trust_state;
ALTER TABLE ch1.devices
    ADD CONSTRAINT ck_devices_trust_state
    CHECK (trust_state IN ('Pending', 'Trusted', 'Revoked'));

-- A revoked device is never trusted, enforced by the database and not only by the
-- domain record's IsTrusted property.
ALTER TABLE ch1.devices
    DROP CONSTRAINT IF EXISTS ck_devices_revoked_not_trusted;
ALTER TABLE ch1.devices
    ADD CONSTRAINT ck_devices_revoked_not_trusted
    CHECK (revoked_at IS NULL OR trust_state = 'Revoked');

CREATE INDEX IF NOT EXISTS ix_devices_project_trust
    ON ch1.devices (project_id, trust_state);

COMMIT;
