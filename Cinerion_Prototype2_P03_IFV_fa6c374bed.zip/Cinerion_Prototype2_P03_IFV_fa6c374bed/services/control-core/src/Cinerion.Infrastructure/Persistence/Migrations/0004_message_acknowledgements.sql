-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV contextual message acknowledgement
-- Copyright © 2026 IR. All rights reserved.

-- entities.json declares MessageAcknowledgement as a distinct Controlled entity with
-- its own primary identifier (message_ack_id) and its own retention period (7 years,
-- shorter than the ContextMessage it evidences). 0001 created ch1.context_threads and
-- ch1.context_messages but no table for it, and ch1.context_messages carries no
-- acknowledgement columns, so there was nowhere for the evidence to live.
--
-- Folding it into ch1.context_messages was rejected: the entity register gives it a
-- separate identifier and a separate retention period, and one message addressed to a
-- thread scope needs one acknowledgement per recipient, not one per message.
--
-- Conflict reported to the owner rather than worked around: the P03 data dictionary
-- declares the entity but the foundation schema omits its table.

BEGIN;

-- Needed for the composite (project_id, message_id) foreign key below, which is how
-- every other controlled relationship in this schema keeps a child row from pointing
-- at a parent in a different project.
ALTER TABLE ch1.context_messages
    DROP CONSTRAINT IF EXISTS uq_context_messages_project_id;
ALTER TABLE ch1.context_messages
    ADD CONSTRAINT uq_context_messages_project_id UNIQUE (project_id, message_id);

CREATE TABLE IF NOT EXISTS ch1.message_acknowledgements (
    message_ack_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    message_id uuid NOT NULL REFERENCES ch1.context_messages(message_id),
    recipient_id text NOT NULL,
    recipient_kind text NOT NULL,

    -- The whole point of this entity, enforced by the database and not only by the
    -- application. CH1-COL-FR-0003, CH1-CYB-ACP-0001 and CH1-UXD-DSG-0001 all require
    -- that reading a message is not acknowledging an alarm, clearing a fault,
    -- satisfying an interlock or confirming a physical action. 'Read' is the only kind
    -- of acknowledgement this table can hold, so no future code path can widen it into
    -- a control action without a reviewed migration.
    acknowledgement_kind text NOT NULL DEFAULT 'Read' CHECK (acknowledgement_kind = 'Read'),
    acknowledged_at timestamptz NOT NULL,

    -- Mirrors ch1.context_messages.control_authority for the same reason.
    control_authority boolean NOT NULL DEFAULT false CHECK (control_authority = false),

    -- One receipt per recipient per message. A second attempt is a conflict, not a
    -- silent overwrite of who first confirmed receipt and when.
    UNIQUE (message_id, recipient_id)
);

ALTER TABLE ch1.message_acknowledgements
    ADD CONSTRAINT fk_message_acks_project_message FOREIGN KEY (project_id, message_id)
    REFERENCES ch1.context_messages(project_id, message_id);

-- Same project isolation as every other controlled table in 0001. A session that has
-- not established its scope reads no rows rather than all of them.
ALTER TABLE ch1.message_acknowledgements ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.message_acknowledgements FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.message_acknowledgements;
CREATE POLICY project_isolation ON ch1.message_acknowledgements
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

-- 0002 sets ALTER DEFAULT PRIVILEGES for tables created by this role, which covers the
-- table above. Granted explicitly as well so the grant is visible at the point the
-- table is created rather than inferred from another migration.
GRANT SELECT, INSERT, UPDATE, DELETE ON ch1.message_acknowledgements TO cinerion_app;

CREATE INDEX IF NOT EXISTS ix_message_ack_message ON ch1.message_acknowledgements (message_id);

-- The message list is served oldest first within a thread and paged on
-- (created_at, message_id). ix_context_thread_time from 0001 covers the ordering but
-- not the project predicate row-level security adds to every query.
CREATE INDEX IF NOT EXISTS ix_context_message_project_thread
    ON ch1.context_messages (project_id, thread_id, created_at, message_id);

COMMIT;
