-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV retention for records with an absolute period
-- Copyright © 2026 IR. All rights reserved.

-- CH1-DBA-DD-0001: "Retention is based on evidence, legal and project needs; deletion is
-- authorised, logged and compatible with immutable-release obligations."
--
-- entities.json gives ten entities a finite retention and only three are computable from
-- data CH1 holds. TelemetrySample is configurable and was implemented in 0010/0011. The
-- other two are ABSOLUTE - MessageAcknowledgement and RoleAssignment are both "7 years" -
-- and this is their disposal path. Conflict 25 records why the remaining seven cannot have
-- one: their retention is relative to a lifecycle end ("Project life + 7 years", "Device
-- life + 5 years") that the schema does not record and no controlled operation sets, so a
-- disposal process would have no date to compute from. That is unchanged, and is still the
-- owner's decision.
--
-- The load-bearing design point is the interaction with immutability. Both registers are
-- permanent WITHIN their retention: 0012 put a BEFORE UPDATE OR DELETE trigger on
-- ch1.role_assignments that refuses every deletion, which is correct and which also means
-- the declared 7-year period could never actually end. A retention that cannot be executed
-- is a policy statement, not an obligation.
--
-- So the trigger becomes retention-aware rather than being removed. UPDATE stays refused
-- for everyone, always. DELETE is refused for everyone, always, EXCEPT for the retention
-- role acting on a row whose own retain_until has passed. Both halves of the condition are
-- checked in the database, so neither the application nor a mistake in a procedure can
-- widen it, and "immutable until its retention ends, then disposable by one named role with
-- a logged reason" is expressed once, as data, in the place that enforces it.

BEGIN;

-- --------------------------------------------------- MessageAcknowledgement: retain_until

-- 0012 carries the declared retention on the role_assignments row with a CHECK tying it to
-- the register. ch1.message_acknowledgements had no such column, so its declared 7 years
-- lived only in entities.json and nothing could act on it. Same shape, same CHECK.
ALTER TABLE ch1.message_acknowledgements
    ADD COLUMN IF NOT EXISTS retain_until timestamptz;

UPDATE ch1.message_acknowledgements
    SET retain_until = acknowledged_at + interval '7 years'
    WHERE retain_until IS NULL;

ALTER TABLE ch1.message_acknowledgements
    ALTER COLUMN retain_until SET NOT NULL;

ALTER TABLE ch1.message_acknowledgements
    DROP CONSTRAINT IF EXISTS ck_message_acks_retention;
ALTER TABLE ch1.message_acknowledgements
    ADD CONSTRAINT ck_message_acks_retention
    CHECK (retain_until = acknowledged_at + interval '7 years');

-- ------------------------------------------------------------- the retention-aware refusal

CREATE OR REPLACE FUNCTION ch1.reject_mutation_before_retention_end() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    -- A record that could be rewritten evidences nothing, and no retention period changes
    -- that. There is deliberately no path through this branch.
    IF TG_OP = 'UPDATE' THEN
        RAISE EXCEPTION 'CH1 controlled evidence cannot be updated'
            USING ERRCODE = '42501';
    END IF;

    -- Deletion is an authorised administrative act by one named role, and it is the
    -- retention role's alone. pg_has_role rather than current_user = 'cinerion_retention',
    -- so a deployment that grants the role to a named operator account still works and a
    -- deployment that does not is unaffected.
    IF NOT pg_has_role(current_user, 'cinerion_retention', 'MEMBER') THEN
        RAISE EXCEPTION 'CH1 controlled evidence may be disposed of only by the retention role, not by %', current_user
            USING ERRCODE = '42501';
    END IF;

    -- And only after the period the entity register declares, read from the row itself.
    -- A caller who wanted to dispose of a record early would have to change the row first,
    -- and the UPDATE branch above refuses that.
    IF OLD.retain_until IS NULL OR OLD.retain_until >= clock_timestamp() THEN
        RAISE EXCEPTION 'CH1 controlled evidence is retained until %; disposal was attempted at %',
            OLD.retain_until, clock_timestamp()
            USING ERRCODE = '42501';
    END IF;

    RETURN OLD;
END;
$$;

DROP TRIGGER IF EXISTS role_assignments_immutable ON ch1.role_assignments;
CREATE TRIGGER role_assignments_retained
    BEFORE UPDATE OR DELETE ON ch1.role_assignments
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_mutation_before_retention_end();

-- ch1.message_acknowledgements had NO immutability trigger and 0004 granted cinerion_app
-- all four privileges, so the application could silently rewrite or delete a delivery
-- receipt - a Controlled record whose entire purpose is to evidence that a named recipient
-- saw a message. That is the same shape as conflict 19: an authority nobody had asked for,
-- doing nothing except making an unattributable change possible.
DROP TRIGGER IF EXISTS message_acknowledgements_retained ON ch1.message_acknowledgements;
CREATE TRIGGER message_acknowledgements_retained
    BEFORE UPDATE OR DELETE ON ch1.message_acknowledgements
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_mutation_before_retention_end();

-- THE REVOKE IS THE LOAD-BEARING HALF. 0002 sets ALTER DEFAULT PRIVILEGES granting
-- cinerion_app SELECT, INSERT, UPDATE and DELETE on every table created in ch1 afterwards,
-- so a GRANT here would be a comment and the REVOKE is the control. Defect 53 was exactly
-- this, found because a test attacked the register and met the trigger rather than an
-- absent privilege - the trigger holding a line the grant was supposed to have held first.
REVOKE UPDATE, DELETE ON ch1.message_acknowledgements FROM cinerion_app;

-- ------------------------------------------------------------------------- disposal record

CREATE TABLE IF NOT EXISTS ch1.record_disposals (
    disposal_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),

    -- A closed set. A disposal procedure that could be pointed at any table by passing its
    -- name would be a general-purpose delete with a reason field attached.
    register text NOT NULL CHECK (register IN ('message_acknowledgements', 'role_assignments')),

    -- Attributable. CH1-DBA-DD-0001 makes deletion authorised, and an authorisation with
    -- nobody's name on it is not one.
    authorised_by text NOT NULL CHECK (length(btrim(authorised_by)) > 0),
    reason text NOT NULL CHECK (length(btrim(reason)) > 0),

    -- What the register declares, recorded beside the act so a reader does not have to go
    -- and look it up in order to judge whether the act was correct.
    declared_retention text NOT NULL CHECK (length(btrim(declared_retention)) > 0),
    cutoff timestamptz NOT NULL,

    rows_deleted bigint NOT NULL CHECK (rows_deleted >= 0),
    -- Counted separately: "nothing was expired" and "everything expired was disposed of"
    -- are different outcomes and an operator should not have to guess which happened.
    rows_still_retained bigint NOT NULL CHECK (rows_still_retained >= 0),
    executed_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS ix_record_disposals_project_time
    ON ch1.record_disposals (project_id, executed_at DESC);

-- Permanent evidence, and never disposable itself: a disposal record that could be edited
-- or removed afterwards would evidence nothing. This one keeps the unconditional trigger.
DROP TRIGGER IF EXISTS record_disposals_immutable ON ch1.record_disposals;
CREATE TRIGGER record_disposals_immutable
    BEFORE UPDATE OR DELETE ON ch1.record_disposals
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

ALTER TABLE ch1.record_disposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.record_disposals FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.record_disposals;
CREATE POLICY project_isolation ON ch1.record_disposals
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

REVOKE UPDATE, DELETE ON ch1.record_disposals FROM cinerion_app;

-- ------------------------------------------------------------------------- the procedure

CREATE OR REPLACE FUNCTION ch1.dispose_expired_records(
    p_project uuid,
    p_register text,
    p_authorised_by text,
    p_reason text)
RETURNS ch1.record_disposals
LANGUAGE plpgsql
-- SECURITY INVOKER, stated rather than defaulted, for the same reason
-- ch1.dispose_telemetry states it: this function's safety is the caller's grants and the
-- triggers above, and no mistake in the body can widen either.
SECURITY INVOKER
AS $$
DECLARE
    v_cutoff timestamptz := clock_timestamp();
    v_deleted bigint := 0;
    v_retained bigint := 0;
    v_declared text := '7 years';
    v_disposal ch1.record_disposals;
BEGIN
    IF p_register IS NULL OR p_register NOT IN ('message_acknowledgements', 'role_assignments') THEN
        RAISE EXCEPTION 'CH1 disposal register % is not one this procedure may act on', p_register
            USING ERRCODE = '22023';
    END IF;

    IF p_authorised_by IS NULL OR length(btrim(p_authorised_by)) = 0
       OR p_reason IS NULL OR length(btrim(p_reason)) = 0 THEN
        RAISE EXCEPTION 'CH1 record disposal requires a named authoriser and a reason'
            USING ERRCODE = '22023';
    END IF;

    IF p_project IS DISTINCT FROM ch1.current_project_id() THEN
        RAISE EXCEPTION 'CH1 record disposal is scoped to the session project; % was requested', p_project
            USING ERRCODE = '42501';
    END IF;

    -- Two branches rather than dynamic SQL against a table name. The register is a closed
    -- set already, but building a DELETE from a parameter is the shape that stops being
    -- safe the moment the set is widened by someone who does not read this comment.
    IF p_register = 'message_acknowledgements' THEN
        DELETE FROM ch1.message_acknowledgements
        WHERE project_id = p_project AND retain_until < v_cutoff;
        GET DIAGNOSTICS v_deleted = ROW_COUNT;

        SELECT count(*) INTO v_retained
        FROM ch1.message_acknowledgements
        WHERE project_id = p_project;
    ELSE
        DELETE FROM ch1.role_assignments
        WHERE project_id = p_project AND retain_until < v_cutoff;
        GET DIAGNOSTICS v_deleted = ROW_COUNT;

        SELECT count(*) INTO v_retained
        FROM ch1.role_assignments
        WHERE project_id = p_project;
    END IF;

    INSERT INTO ch1.record_disposals (
        project_id, register, authorised_by, reason, declared_retention,
        cutoff, rows_deleted, rows_still_retained)
    VALUES (
        p_project, p_register, btrim(p_authorised_by), btrim(p_reason), v_declared,
        v_cutoff, v_deleted, v_retained)
    RETURNING * INTO v_disposal;

    RETURN v_disposal;
END;
$$;

-- ------------------------------------------------------------------------------- grants

GRANT SELECT ON ch1.record_disposals TO cinerion_app;
GRANT INSERT ON ch1.record_disposals TO cinerion_retention;
GRANT DELETE ON ch1.message_acknowledgements TO cinerion_retention;
GRANT DELETE ON ch1.role_assignments TO cinerion_retention;

REVOKE EXECUTE ON FUNCTION ch1.dispose_expired_records(uuid, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION ch1.dispose_expired_records(uuid, text, text, text) TO cinerion_retention;
-- Deliberately not granted to cinerion_app. No controlled operation disposes of a record,
-- and CH1-DBA-DD-0001 makes this an administrative act.

COMMIT;
