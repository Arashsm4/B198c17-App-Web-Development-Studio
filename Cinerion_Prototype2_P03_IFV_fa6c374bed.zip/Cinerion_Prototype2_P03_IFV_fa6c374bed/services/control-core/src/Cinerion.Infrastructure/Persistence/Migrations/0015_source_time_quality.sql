-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV source time quality on telemetry
-- Copyright © 2026 IR. All rights reserved.

-- CH1-COM-ICD-0001 requires time quality to travel with a message, and states the reason
-- plainly: "Clock offset and time quality are observable so audit and TOTP decisions are
-- not silently made on invalid time."
--
-- ch1.telemetry_samples carries two times and one time quality, and the quality described
-- the wrong one. `sampled_at` is the SOURCE's observation and `received_at` is this
-- service's; `time_quality` was written from Control Core's own clock, so it described
-- `received_at` and stood beside `sampled_at` as though it described that. A controller
-- honestly reporting an undisciplined clock was stored indistinguishably from one that
-- had been disciplined, and no reader could have told. Recorded as defect 59 and
-- conflict 27.
--
-- This adds the source's own declaration beside it. NULLABLE deliberately, and that is
-- not laziness: it is the difference between "the source declared nothing" and a value
-- this migration would have had to invent for every row already stored. Defect 67 was a
-- NOT NULL column added to a table whose writer lived in another project and never set
-- it; there is exactly one writer of this table
-- (PostgresCinerionStore.AppendTelemetryAsync) and it is updated in the same commit, but
-- the column is nullable regardless, because a retention window's worth of history
-- cannot be given a quality nobody observed.

BEGIN;

ALTER TABLE ch1.telemetry_samples
    ADD COLUMN IF NOT EXISTS source_time_quality text;

COMMENT ON COLUMN ch1.telemetry_samples.source_time_quality IS
    'What the source declared about the clock that stamped sampled_at, carried unchanged. '
    'NULL means the source declared nothing. Control Core never upgrades this.';

-- 0002 granted the application role SELECT, INSERT, UPDATE and DELETE on every table
-- created in ch1 afterwards, through ALTER DEFAULT PRIVILEGES, and a column added to an
-- existing table inherits the table's grants. So there is no GRANT to write here and
-- writing one would be a comment rather than a control (handover item 27). What DOES need
-- stating is that this column changes no authority: the retention role's single-table
-- DELETE and the application role's revoked DELETE on this table both stand unchanged.

COMMIT;
