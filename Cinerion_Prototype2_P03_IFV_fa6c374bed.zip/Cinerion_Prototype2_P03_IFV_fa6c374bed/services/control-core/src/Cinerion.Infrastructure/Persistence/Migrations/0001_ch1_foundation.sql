-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV database foundation
-- Copyright © 2026 IR. All rights reserved.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS ch1;
REVOKE ALL ON SCHEMA ch1 FROM PUBLIC;

CREATE TYPE ch1.part_status AS ENUM ('InProcess', 'Hold', 'Accepted', 'Released');
CREATE TYPE ch1.command_state AS ENUM (
    'AwaitingCredential',
    'AwaitingButton',
    'Committed',
    'Executing',
    'Completed',
    'Cancelled',
    'Rejected',
    'FaultLatched'
);
CREATE TYPE ch1.data_quality AS ENUM ('Good', 'Uncertain', 'Bad', 'Unknown');
CREATE TYPE ch1.freshness AS ENUM ('Live', 'Stale', 'Disconnected', 'Simulated', 'Maintenance', 'Unknown');

CREATE TABLE ch1.projects (
    project_id uuid PRIMARY KEY,
    project_code text NOT NULL UNIQUE CHECK (project_code ~ '^CH1(-[A-Z0-9]+)*$'),
    name text NOT NULL,
    baseline text NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE ch1.sites (
    site_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    name text NOT NULL,
    simulated boolean NOT NULL DEFAULT true,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    UNIQUE (project_id, name)
);

CREATE TABLE ch1.cells (
    cell_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    site_id uuid NOT NULL REFERENCES ch1.sites(site_id),
    name text NOT NULL,
    controller_id text NOT NULL UNIQUE,
    operating_state text NOT NULL,
    configuration_revision text NOT NULL,
    state_hash char(64) NOT NULL CHECK (state_hash ~ '^[a-f0-9]{64}$'),
    source_timestamp timestamptz NOT NULL,
    freshness ch1.freshness NOT NULL,
    quality ch1.data_quality NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE ch1.assets (
    asset_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid REFERENCES ch1.cells(cell_id),
    asset_code text NOT NULL,
    name text NOT NULL,
    asset_type text NOT NULL,
    configuration_revision text NOT NULL,
    lifecycle_state text NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    UNIQUE (project_id, asset_code)
);

CREATE TABLE ch1.devices (
    device_id text PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid REFERENCES ch1.cells(cell_id),
    device_type text NOT NULL,
    firmware_version text NOT NULL,
    configuration_revision text NOT NULL,
    certificate_thumbprint text,
    trust_state text NOT NULL,
    capability_manifest jsonb NOT NULL CHECK (jsonb_typeof(capability_manifest) = 'object'),
    last_seen_at timestamptz,
    revoked_at timestamptz,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE ch1.product_revisions (
    revision_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    product_code text NOT NULL,
    revision_code text NOT NULL,
    lifecycle_state text NOT NULL CHECK (lifecycle_state IN ('Draft', 'Released', 'Superseded', 'Withdrawn')),
    bom jsonb NOT NULL DEFAULT '[]'::jsonb,
    route jsonb NOT NULL DEFAULT '[]'::jsonb,
    source_checksum char(64) NOT NULL CHECK (source_checksum ~ '^[a-f0-9]{64}$'),
    released_at timestamptz,
    superseded_at timestamptz,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    UNIQUE (project_id, product_code, revision_code)
);

CREATE TABLE ch1.work_orders (
    work_order_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    revision_id uuid NOT NULL REFERENCES ch1.product_revisions(revision_id),
    cell_id uuid REFERENCES ch1.cells(cell_id),
    work_order_number text NOT NULL,
    quantity integer NOT NULL CHECK (quantity > 0),
    status text NOT NULL,
    released_by text,
    released_at timestamptz,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    UNIQUE (project_id, work_order_number)
);

CREATE TABLE ch1.physical_parts (
    part_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    work_order_id uuid NOT NULL REFERENCES ch1.work_orders(work_order_id),
    revision_id uuid NOT NULL REFERENCES ch1.product_revisions(revision_id),
    serial_number text NOT NULL,
    operator_id text NOT NULL,
    status ch1.part_status NOT NULL DEFAULT 'InProcess',
    permanent_identity_uri text NOT NULL UNIQUE,
    created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    UNIQUE (project_id, serial_number)
);

CREATE TABLE ch1.command_transactions (
    command_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    site_id uuid NOT NULL REFERENCES ch1.sites(site_id),
    cell_id uuid NOT NULL REFERENCES ch1.cells(cell_id),
    asset_id uuid NOT NULL REFERENCES ch1.assets(asset_id),
    work_order_id uuid NOT NULL REFERENCES ch1.work_orders(work_order_id),
    part_id uuid NOT NULL REFERENCES ch1.physical_parts(part_id),
    confirmation_id uuid NOT NULL UNIQUE,
    correlation_id uuid NOT NULL,
    requester_id text NOT NULL,
    command_type text NOT NULL CHECK (command_type ~ '^[A-Z][A-Z0-9_]{2,63}$'),
    procedure_revision text NOT NULL,
    configuration_revision text NOT NULL,
    expected_state_hash char(64) NOT NULL CHECK (expected_state_hash ~ '^[a-f0-9]{64}$'),
    sequence_number bigint NOT NULL CHECK (sequence_number > 0),
    expires_at timestamptz NOT NULL,
    idempotency_key text NOT NULL CHECK (length(idempotency_key) BETWEEN 16 AND 128),
    parameters jsonb NOT NULL CHECK (jsonb_typeof(parameters) = 'object'),
    state ch1.command_state NOT NULL,
    prepared_at timestamptz NOT NULL,
    prepared_controller_boot_id uuid NOT NULL,
    credential_proof_id uuid,
    local_commit_id uuid,
    terminal_reason text,
    version bigint NOT NULL CHECK (version > 0),
    UNIQUE (project_id, idempotency_key),
    UNIQUE (cell_id, sequence_number)
);

CREATE TABLE ch1.local_confirmations (
    confirmation_id uuid PRIMARY KEY,
    command_id uuid NOT NULL UNIQUE REFERENCES ch1.command_transactions(command_id),
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid NOT NULL REFERENCES ch1.cells(cell_id),
    controller_id text NOT NULL REFERENCES ch1.devices(device_id),
    credential_id uuid NOT NULL,
    user_id text NOT NULL,
    authenticator_class text NOT NULL,
    challenge_hash char(64) NOT NULL CHECK (challenge_hash ~ '^[a-f0-9]{64}$'),
    cryptographically_verified boolean NOT NULL,
    user_verified boolean NOT NULL,
    proof_verified_at timestamptz NOT NULL,
    proof_expires_at timestamptz NOT NULL,
    button_observed_at timestamptz,
    previous_button_state boolean,
    current_button_state boolean,
    button_source text,
    interlock_snapshot_hash char(64),
    controller_boot_id uuid NOT NULL,
    local_commit_id uuid UNIQUE
);

CREATE TABLE ch1.state_transitions (
    transition_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid NOT NULL REFERENCES ch1.cells(cell_id),
    command_id uuid REFERENCES ch1.command_transactions(command_id),
    from_state text NOT NULL,
    to_state text NOT NULL,
    reason_code text NOT NULL,
    source_device_id text NOT NULL,
    occurred_at timestamptz NOT NULL,
    sequence_number bigint NOT NULL,
    UNIQUE (cell_id, sequence_number)
);

CREATE TABLE ch1.calibration_records (
    calibration_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    instrument_id text NOT NULL,
    certificate_number text NOT NULL,
    calibrated_at timestamptz NOT NULL,
    valid_until timestamptz NOT NULL,
    certificate_evidence_id uuid,
    status text NOT NULL,
    CHECK (valid_until > calibrated_at)
);

CREATE TABLE ch1.test_runs (
    test_run_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    part_id uuid NOT NULL REFERENCES ch1.physical_parts(part_id),
    procedure_id text NOT NULL,
    procedure_revision text NOT NULL,
    started_by text NOT NULL,
    witnessed_by text,
    status text NOT NULL,
    started_at timestamptz NOT NULL,
    completed_at timestamptz,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE ch1.measurements (
    measurement_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    test_run_id uuid NOT NULL REFERENCES ch1.test_runs(test_run_id),
    part_id uuid NOT NULL REFERENCES ch1.physical_parts(part_id),
    characteristic text NOT NULL,
    value numeric NOT NULL,
    unit text NOT NULL,
    lower_limit numeric,
    upper_limit numeric,
    mandatory boolean NOT NULL,
    result text NOT NULL CHECK (result IN ('Pass', 'Fail')),
    quality ch1.data_quality NOT NULL,
    source_device_id text NOT NULL,
    calibration_id uuid NOT NULL REFERENCES ch1.calibration_records(calibration_id),
    supersedes_measurement_id uuid,
    source_sample_time timestamptz NOT NULL,
    recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (lower_limit IS NULL OR upper_limit IS NULL OR lower_limit <= upper_limit)
);

CREATE TABLE ch1.ncrs (
    ncr_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    part_id uuid NOT NULL REFERENCES ch1.physical_parts(part_id),
    test_run_id uuid REFERENCES ch1.test_runs(test_run_id),
    title text NOT NULL,
    description text NOT NULL,
    status text NOT NULL,
    raised_by text NOT NULL,
    raised_at timestamptz NOT NULL,
    disposition text,
    disposition_by text,
    disposition_at timestamptz,
    source_measurement_id uuid,
    rework_work_order_id uuid,
    closed_by_measurement_id uuid,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE ch1.release_records (
    release_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    part_id uuid NOT NULL UNIQUE REFERENCES ch1.physical_parts(part_id),
    inspector_id text NOT NULL,
    operator_id text NOT NULL,
    released_at timestamptz NOT NULL,
    evidence_manifest_hash char(64) NOT NULL CHECK (evidence_manifest_hash ~ '^[a-f0-9]{64}$'),
    CHECK (inspector_id <> operator_id)
);

CREATE TABLE ch1.telemetry_samples (
    sample_id uuid NOT NULL,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid NOT NULL REFERENCES ch1.cells(cell_id),
    device_id text NOT NULL REFERENCES ch1.devices(device_id),
    channel_id text NOT NULL,
    value double precision NOT NULL,
    unit text NOT NULL,
    quality ch1.data_quality NOT NULL,
    freshness ch1.freshness NOT NULL,
    sampled_at timestamptz NOT NULL,
    received_at timestamptz NOT NULL,
    time_quality text NOT NULL,
    PRIMARY KEY (sample_id, sampled_at)
) PARTITION BY RANGE (sampled_at);

CREATE TABLE ch1.telemetry_samples_default
    PARTITION OF ch1.telemetry_samples DEFAULT;

CREATE TABLE ch1.alarms (
    alarm_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    cell_id uuid NOT NULL REFERENCES ch1.cells(cell_id),
    source_id text NOT NULL,
    alarm_code text NOT NULL,
    priority integer NOT NULL CHECK (priority BETWEEN 1 AND 5),
    state text NOT NULL,
    activated_at timestamptz NOT NULL,
    acknowledged_by text,
    acknowledged_at timestamptz,
    cleared_at timestamptz,
    cause_clear boolean NOT NULL DEFAULT false
);

CREATE TABLE ch1.resources (
    resource_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    resource_type text NOT NULL,
    name text NOT NULL,
    capacity numeric NOT NULL CHECK (capacity >= 0),
    unit text NOT NULL,
    availability_state text NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE ch1.resource_allocations (
    allocation_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    resource_id uuid NOT NULL REFERENCES ch1.resources(resource_id),
    work_order_id uuid REFERENCES ch1.work_orders(work_order_id),
    experiment_id uuid,
    quantity numeric NOT NULL CHECK (quantity > 0),
    starts_at timestamptz NOT NULL,
    ends_at timestamptz NOT NULL,
    status text NOT NULL,
    requested_by text NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    CHECK (ends_at > starts_at),
    CHECK ((work_order_id IS NOT NULL) <> (experiment_id IS NOT NULL))
);

CREATE TABLE ch1.context_threads (
    thread_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    object_type text NOT NULL,
    object_id text NOT NULL,
    access_scope jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamptz NOT NULL,
    UNIQUE (project_id, object_type, object_id)
);

CREATE TABLE ch1.context_messages (
    message_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    thread_id uuid NOT NULL REFERENCES ch1.context_threads(thread_id),
    author_id text NOT NULL,
    author_kind text NOT NULL,
    priority text NOT NULL,
    body text NOT NULL CHECK (length(body) BETWEEN 1 AND 10000),
    created_at timestamptz NOT NULL,
    delivery_state text NOT NULL,
    control_authority boolean NOT NULL DEFAULT false CHECK (control_authority = false)
);

CREATE TABLE ch1.experiments (
    experiment_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    owner_id text NOT NULL,
    objective text NOT NULL,
    environment text NOT NULL DEFAULT 'Simulator' CHECK (environment IN ('Simulator', 'ControlledBench')),
    production_authority boolean NOT NULL DEFAULT false CHECK (production_authority = false),
    status text NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at timestamptz NOT NULL
);

ALTER TABLE ch1.resource_allocations
    ADD CONSTRAINT resource_allocation_experiment_fk
    FOREIGN KEY (experiment_id) REFERENCES ch1.experiments(experiment_id);

CREATE TABLE ch1.evidence (
    evidence_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    object_type text NOT NULL,
    object_id text NOT NULL,
    media_type text NOT NULL,
    classification text NOT NULL,
    storage_uri text NOT NULL,
    content_sha256 char(64) NOT NULL CHECK (content_sha256 ~ '^[a-f0-9]{64}$'),
    size_bytes bigint NOT NULL CHECK (size_bytes >= 0),
    captured_by text NOT NULL,
    captured_at timestamptz NOT NULL,
    UNIQUE (project_id, content_sha256)
);

CREATE TABLE ch1.controlled_documents (
    document_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    document_number text NOT NULL,
    revision text NOT NULL,
    issue_status text NOT NULL,
    classification text NOT NULL,
    content_sha256 char(64) NOT NULL CHECK (content_sha256 ~ '^[a-f0-9]{64}$'),
    representation_uri text NOT NULL,
    wrapped_key_reference text,
    authorised_at timestamptz NOT NULL,
    UNIQUE (project_id, document_number, revision, issue_status)
);

CREATE TABLE ch1.audit_events (
    event_id uuid PRIMARY KEY,
    sequence_number bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    event_type text NOT NULL,
    actor_id text NOT NULL,
    actor_kind text NOT NULL,
    object_type text NOT NULL,
    object_id text NOT NULL,
    correlation_id uuid NOT NULL,
    occurred_at timestamptz NOT NULL,
    time_quality text NOT NULL,
    decision text NOT NULL,
    reason_code text NOT NULL,
    payload_hash char(64) NOT NULL CHECK (payload_hash ~ '^[a-f0-9]{64}$'),
    previous_hash char(64) NOT NULL CHECK (previous_hash ~ '^[a-f0-9]{64}$'),
    event_hash char(64) NOT NULL UNIQUE CHECK (event_hash ~ '^[a-f0-9]{64}$')
);

-- Tenant identity is repeated in every relationship and enforced by composite
-- foreign keys. A valid UUID from another project must never satisfy a local
-- relationship, even if an application or migration bug bypasses query filters.
ALTER TABLE ch1.sites ADD CONSTRAINT uq_sites_project_id UNIQUE (project_id, site_id);
ALTER TABLE ch1.cells ADD CONSTRAINT uq_cells_project_id UNIQUE (project_id, cell_id);
ALTER TABLE ch1.assets ADD CONSTRAINT uq_assets_project_id UNIQUE (project_id, asset_id);
ALTER TABLE ch1.devices ADD CONSTRAINT uq_devices_project_id UNIQUE (project_id, device_id);
ALTER TABLE ch1.product_revisions ADD CONSTRAINT uq_product_revisions_project_id UNIQUE (project_id, revision_id);
ALTER TABLE ch1.work_orders ADD CONSTRAINT uq_work_orders_project_id UNIQUE (project_id, work_order_id);
ALTER TABLE ch1.physical_parts ADD CONSTRAINT uq_physical_parts_project_id UNIQUE (project_id, part_id);
ALTER TABLE ch1.command_transactions ADD CONSTRAINT uq_commands_project_id UNIQUE (project_id, command_id);
ALTER TABLE ch1.test_runs ADD CONSTRAINT uq_test_runs_project_id UNIQUE (project_id, test_run_id);
ALTER TABLE ch1.calibration_records ADD CONSTRAINT uq_calibration_project_id UNIQUE (project_id, calibration_id);
ALTER TABLE ch1.measurements ADD CONSTRAINT uq_measurements_project_id UNIQUE (project_id, measurement_id);
ALTER TABLE ch1.resources ADD CONSTRAINT uq_resources_project_id UNIQUE (project_id, resource_id);
ALTER TABLE ch1.experiments ADD CONSTRAINT uq_experiments_project_id UNIQUE (project_id, experiment_id);
ALTER TABLE ch1.context_threads ADD CONSTRAINT uq_context_threads_project_id UNIQUE (project_id, thread_id);

ALTER TABLE ch1.cells
    ADD CONSTRAINT fk_cells_project_site FOREIGN KEY (project_id, site_id)
    REFERENCES ch1.sites(project_id, site_id);
ALTER TABLE ch1.assets
    ADD CONSTRAINT fk_assets_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id);
ALTER TABLE ch1.devices
    ADD CONSTRAINT fk_devices_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id);
ALTER TABLE ch1.work_orders
    ADD CONSTRAINT fk_work_orders_project_revision FOREIGN KEY (project_id, revision_id)
    REFERENCES ch1.product_revisions(project_id, revision_id),
    ADD CONSTRAINT fk_work_orders_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id);
ALTER TABLE ch1.physical_parts
    ADD CONSTRAINT fk_parts_project_work_order FOREIGN KEY (project_id, work_order_id)
    REFERENCES ch1.work_orders(project_id, work_order_id),
    ADD CONSTRAINT fk_parts_project_revision FOREIGN KEY (project_id, revision_id)
    REFERENCES ch1.product_revisions(project_id, revision_id);
ALTER TABLE ch1.command_transactions
    ADD CONSTRAINT fk_commands_project_site FOREIGN KEY (project_id, site_id)
    REFERENCES ch1.sites(project_id, site_id),
    ADD CONSTRAINT fk_commands_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id),
    ADD CONSTRAINT fk_commands_project_asset FOREIGN KEY (project_id, asset_id)
    REFERENCES ch1.assets(project_id, asset_id),
    ADD CONSTRAINT fk_commands_project_work_order FOREIGN KEY (project_id, work_order_id)
    REFERENCES ch1.work_orders(project_id, work_order_id),
    ADD CONSTRAINT fk_commands_project_part FOREIGN KEY (project_id, part_id)
    REFERENCES ch1.physical_parts(project_id, part_id);
ALTER TABLE ch1.local_confirmations
    ADD CONSTRAINT fk_confirmations_project_command FOREIGN KEY (project_id, command_id)
    REFERENCES ch1.command_transactions(project_id, command_id),
    ADD CONSTRAINT fk_confirmations_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id),
    ADD CONSTRAINT fk_confirmations_project_controller FOREIGN KEY (project_id, controller_id)
    REFERENCES ch1.devices(project_id, device_id);
ALTER TABLE ch1.state_transitions
    ADD CONSTRAINT fk_transitions_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id),
    ADD CONSTRAINT fk_transitions_project_command FOREIGN KEY (project_id, command_id)
    REFERENCES ch1.command_transactions(project_id, command_id),
    ADD CONSTRAINT fk_transitions_project_source FOREIGN KEY (project_id, source_device_id)
    REFERENCES ch1.devices(project_id, device_id);
ALTER TABLE ch1.test_runs
    ADD CONSTRAINT fk_test_runs_project_part FOREIGN KEY (project_id, part_id)
    REFERENCES ch1.physical_parts(project_id, part_id);
ALTER TABLE ch1.measurements
    ADD CONSTRAINT fk_measurements_project_test_run FOREIGN KEY (project_id, test_run_id)
    REFERENCES ch1.test_runs(project_id, test_run_id),
    ADD CONSTRAINT fk_measurements_project_part FOREIGN KEY (project_id, part_id)
    REFERENCES ch1.physical_parts(project_id, part_id),
    ADD CONSTRAINT fk_measurements_project_calibration FOREIGN KEY (project_id, calibration_id)
    REFERENCES ch1.calibration_records(project_id, calibration_id),
    ADD CONSTRAINT fk_measurements_project_source FOREIGN KEY (project_id, source_device_id)
    REFERENCES ch1.devices(project_id, device_id),
    ADD CONSTRAINT fk_measurements_project_superseded FOREIGN KEY (project_id, supersedes_measurement_id)
    REFERENCES ch1.measurements(project_id, measurement_id),
    ADD CONSTRAINT uq_measurements_one_retest UNIQUE (supersedes_measurement_id);
ALTER TABLE ch1.ncrs
    ADD CONSTRAINT fk_ncrs_project_part FOREIGN KEY (project_id, part_id)
    REFERENCES ch1.physical_parts(project_id, part_id),
    ADD CONSTRAINT fk_ncrs_project_test_run FOREIGN KEY (project_id, test_run_id)
    REFERENCES ch1.test_runs(project_id, test_run_id),
    ADD CONSTRAINT fk_ncrs_project_source_measurement FOREIGN KEY (project_id, source_measurement_id)
    REFERENCES ch1.measurements(project_id, measurement_id),
    ADD CONSTRAINT fk_ncrs_project_rework_order FOREIGN KEY (project_id, rework_work_order_id)
    REFERENCES ch1.work_orders(project_id, work_order_id),
    ADD CONSTRAINT fk_ncrs_project_close_measurement FOREIGN KEY (project_id, closed_by_measurement_id)
    REFERENCES ch1.measurements(project_id, measurement_id);
ALTER TABLE ch1.release_records
    ADD CONSTRAINT fk_release_project_part FOREIGN KEY (project_id, part_id)
    REFERENCES ch1.physical_parts(project_id, part_id);
ALTER TABLE ch1.telemetry_samples
    ADD CONSTRAINT fk_telemetry_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id),
    ADD CONSTRAINT fk_telemetry_project_device FOREIGN KEY (project_id, device_id)
    REFERENCES ch1.devices(project_id, device_id);
ALTER TABLE ch1.alarms
    ADD CONSTRAINT fk_alarms_project_cell FOREIGN KEY (project_id, cell_id)
    REFERENCES ch1.cells(project_id, cell_id);
ALTER TABLE ch1.resource_allocations
    ADD CONSTRAINT fk_allocations_project_resource FOREIGN KEY (project_id, resource_id)
    REFERENCES ch1.resources(project_id, resource_id),
    ADD CONSTRAINT fk_allocations_project_work_order FOREIGN KEY (project_id, work_order_id)
    REFERENCES ch1.work_orders(project_id, work_order_id),
    ADD CONSTRAINT fk_allocations_project_experiment FOREIGN KEY (project_id, experiment_id)
    REFERENCES ch1.experiments(project_id, experiment_id);
ALTER TABLE ch1.context_messages
    ADD CONSTRAINT fk_messages_project_thread FOREIGN KEY (project_id, thread_id)
    REFERENCES ch1.context_threads(project_id, thread_id);

CREATE INDEX ix_command_project_state ON ch1.command_transactions (project_id, state, prepared_at DESC);
CREATE INDEX ix_command_correlation ON ch1.command_transactions (correlation_id);
CREATE INDEX ix_part_work_order ON ch1.physical_parts (work_order_id, status);
CREATE INDEX ix_measurement_part_time ON ch1.measurements (part_id, source_sample_time);
CREATE INDEX ix_ncr_part_status ON ch1.ncrs (part_id, status);
CREATE INDEX ix_telemetry_cell_channel_time ON ch1.telemetry_samples (cell_id, channel_id, sampled_at DESC);
CREATE INDEX ix_alarm_project_state ON ch1.alarms (project_id, state, priority);
CREATE INDEX ix_audit_project_sequence ON ch1.audit_events (project_id, sequence_number);
CREATE INDEX ix_audit_correlation ON ch1.audit_events (correlation_id, sequence_number);
CREATE INDEX ix_context_thread_time ON ch1.context_messages (thread_id, created_at);

-- The application sets this transaction-local claim after authentication.
-- A missing setting produces no authorised rows rather than broad access.
CREATE FUNCTION ch1.current_project_id() RETURNS uuid
LANGUAGE sql STABLE PARALLEL SAFE
AS $$ SELECT nullif(current_setting('ch1.project_id', true), '')::uuid $$;

DO $$
DECLARE
    table_name text;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'projects', 'sites', 'cells', 'assets', 'devices', 'product_revisions', 'work_orders',
        'physical_parts', 'command_transactions', 'local_confirmations',
        'state_transitions', 'calibration_records', 'test_runs', 'measurements',
        'ncrs', 'release_records', 'telemetry_samples', 'alarms', 'resources',
        'resource_allocations', 'context_threads', 'context_messages',
        'experiments', 'evidence', 'controlled_documents', 'audit_events'
    ]
    LOOP
        EXECUTE format('ALTER TABLE ch1.%I ENABLE ROW LEVEL SECURITY', table_name);
        EXECUTE format('ALTER TABLE ch1.%I FORCE ROW LEVEL SECURITY', table_name);
        EXECUTE format(
            'CREATE POLICY project_isolation ON ch1.%I USING (project_id = ch1.current_project_id()) WITH CHECK (project_id = ch1.current_project_id())',
            table_name);
    END LOOP;
END $$;

-- Critical evidence is append-only for the normal application role. Rejecting
-- mutation is explicit; a client must never receive a misleading success after
-- an update/delete was silently discarded. Retention is a separate controlled
-- administrative process with independent evidence.
CREATE FUNCTION ch1.reject_immutable_mutation() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE EXCEPTION 'CH1 immutable evidence cannot be updated or deleted'
        USING ERRCODE = '42501';
END;
$$;

CREATE TRIGGER audit_events_immutable
    BEFORE UPDATE OR DELETE ON ch1.audit_events
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();
CREATE TRIGGER measurements_immutable
    BEFORE UPDATE OR DELETE ON ch1.measurements
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();
CREATE TRIGGER release_records_immutable
    BEFORE UPDATE OR DELETE ON ch1.release_records
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

COMMIT;
