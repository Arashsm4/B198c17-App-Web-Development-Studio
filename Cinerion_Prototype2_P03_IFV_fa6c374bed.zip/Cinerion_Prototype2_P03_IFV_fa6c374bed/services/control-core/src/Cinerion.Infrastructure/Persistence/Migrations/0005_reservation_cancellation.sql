-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV resource reservation cancellation
-- Copyright © 2026 IR. All rights reserved.

-- api_endpoints.json makes "Reason, version match and audit" the control on
-- DELETE /api/v1/reservations/{reservationId}, and CH1-MGT-FR-0003 requires assignment
-- changes to be attributable and revisioned. ch1.resource_allocations as defined in 0001
-- carries only status, with no column for why a reservation was cancelled, by whom or
-- when, and ch1.audit_events stores a payload hash rather than the payload, so a reason
-- recorded solely in the audit chain could be verified but never read back.
--
-- Accepting a required controlled field and then discarding it would be a fake-success
-- response, so the columns are added here. Additive only: no existing column, constraint
-- or semantic changes.
--
-- Conflict reported to the owner rather than worked around: the P03 data dictionary for
-- ch1.resource_allocations and the P03 API control column disagree, and this migration
-- resolves it in favour of the API control. It is the same disagreement as 0003 records
-- for ch1.alarms.

BEGIN;

ALTER TABLE ch1.resource_allocations
    ADD COLUMN IF NOT EXISTS cancellation_reason text,
    ADD COLUMN IF NOT EXISTS cancelled_by text,
    ADD COLUMN IF NOT EXISTS cancelled_at timestamptz;

-- A cancellation is reason, identity and time together, and only a cancelled
-- reservation has one. Recording a reason against a live reservation, or a cancellation
-- with no author, would leave unattributable evidence.
ALTER TABLE ch1.resource_allocations
    DROP CONSTRAINT IF EXISTS ck_allocations_cancellation_complete;
ALTER TABLE ch1.resource_allocations
    ADD CONSTRAINT ck_allocations_cancellation_complete CHECK (
        (status = 'Cancelled'
            AND cancellation_reason IS NOT NULL
            AND cancelled_by IS NOT NULL
            AND cancelled_at IS NOT NULL)
        OR (status <> 'Cancelled'
            AND cancellation_reason IS NULL
            AND cancelled_by IS NULL
            AND cancelled_at IS NULL));

-- The conflict check reads every allocation overlapping a candidate interval for one
-- resource, on every reservation. 0001 declares no index on ch1.resource_allocations at
-- all, so that read was a sequential scan of the whole table.
--
-- Deliberately not listed in the startup schema guard: a database without this index
-- still answers correctly, only more slowly, and the guard exists to refuse a schema
-- that would give wrong answers rather than slow ones.
CREATE INDEX IF NOT EXISTS ix_allocation_resource_window
    ON ch1.resource_allocations (project_id, resource_id, starts_at, ends_at)
    WHERE status <> 'Cancelled';

-- CH1-MGT-FR-0004 requires each allocation to be linked to its work order or experiment,
-- and the operations view asks the question from that direction too.
CREATE INDEX IF NOT EXISTS ix_allocation_work_order
    ON ch1.resource_allocations (project_id, work_order_id)
    WHERE work_order_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS ix_resource_project_name
    ON ch1.resources (project_id, name, resource_id);

COMMIT;
