-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV experiment revisions and promotion requests
-- Copyright © 2026 IR. All rights reserved.

-- entities.json declares ExperimentRevision as a Controlled R&D entity with its own
-- primary identifier (experiment_revision_id), the purpose "Immutable experiment
-- configuration and provenance" and Permanent retention, longer than the Experiment it
-- belongs to. 0001 created ch1.experiments but no table for it, so an experiment run had
-- nowhere to record the versioned configuration, inputs, environment, operator,
-- timestamps and results that CH1-RND-FR-0002 requires for reproduction.
--
-- The promotion request has no declared entity at all, yet
-- POST /api/v1/experiments/{experimentId}/promotion-requests is in the controlled
-- catalogue and CH1-RND-FR-0003 requires it to carry an approved change record, an
-- impact assessment and verification. Rather than invent an entity the register does not
-- contain, the request extends the Experiment it belongs to: CH1 emits one outbound
-- request per experiment (CH1-COM-IF-0021, "Outbound request"), and the approval lives
-- in configuration control, which is a separate system.
--
-- Conflicts reported to the owner rather than worked around.

BEGIN;

CREATE TABLE IF NOT EXISTS ch1.experiment_revisions (
    experiment_revision_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    experiment_id uuid NOT NULL REFERENCES ch1.experiments(experiment_id),
    revision_number integer NOT NULL CHECK (revision_number > 0),

    -- Mirrors the constraint on ch1.experiments. An experiment revision records what ran
    -- in a simulator; ControlledBench is reachable only through an authorised bench
    -- transition, which the P03 catalogue contains no operation for.
    environment text NOT NULL CHECK (environment IN ('Simulator', 'ControlledBench')),

    -- CH1-RND-FR-0002: versioned configuration, code or model reference, input data,
    -- environment, operator, timestamps, results and evidence provenance sufficient for
    -- reproduction. Each reference is paired with a content hash so a later reader can
    -- prove the artefact they found is the artefact that ran.
    configuration_reference text NOT NULL,
    configuration_sha256 char(64) NOT NULL CHECK (configuration_sha256 ~ '^[a-f0-9]{64}$'),
    model_reference text NOT NULL,
    input_reference text NOT NULL,
    input_sha256 char(64) NOT NULL CHECK (input_sha256 ~ '^[a-f0-9]{64}$'),
    result_summary text NOT NULL CHECK (length(result_summary) BETWEEN 1 AND 4000),
    result_sha256 char(64) NOT NULL CHECK (result_sha256 ~ '^[a-f0-9]{64}$'),

    -- Two identities, deliberately. requested_by is the human R&D Engineer; executed_by
    -- is the isolated bench identity the run used, which CH1-COM-IF-0020 requires to be
    -- separate from any production credential.
    requested_by text NOT NULL,
    executed_by text NOT NULL,
    started_at timestamptz NOT NULL,
    finished_at timestamptz NOT NULL,

    -- The same storage-level guarantee ch1.experiments and ch1.context_messages carry.
    -- CH1-CYB-ACP-0001: ResearchBench roles cannot reach production routes unless an
    -- approved promotion and bench-mode transition exist.
    production_authority boolean NOT NULL DEFAULT false CHECK (production_authority = false),

    CHECK (finished_at >= started_at),
    UNIQUE (experiment_id, revision_number)
);

ALTER TABLE ch1.experiment_revisions
    ADD CONSTRAINT fk_experiment_revisions_project_experiment
    FOREIGN KEY (project_id, experiment_id) REFERENCES ch1.experiments(project_id, experiment_id);

ALTER TABLE ch1.experiment_revisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.experiment_revisions FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.experiment_revisions;
CREATE POLICY project_isolation ON ch1.experiment_revisions
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON ch1.experiment_revisions TO cinerion_app;

-- Declared Permanent and "Immutable" in the entity register, so it joins audit_events,
-- measurements and release_records under the append-only trigger from 0001. A run that
-- could be edited afterwards would not evidence what actually ran.
CREATE TRIGGER experiment_revisions_immutable
    BEFORE UPDATE OR DELETE ON ch1.experiment_revisions
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

CREATE INDEX IF NOT EXISTS ix_experiment_revision_experiment
    ON ch1.experiment_revisions (project_id, experiment_id, revision_number);

-- ---------------------------------------------------------------- promotion

ALTER TABLE ch1.experiments
    ADD COLUMN IF NOT EXISTS promotion_change_record text,
    ADD COLUMN IF NOT EXISTS promotion_impact_analysis text,
    ADD COLUMN IF NOT EXISTS promotion_verification text,
    ADD COLUMN IF NOT EXISTS promotion_requested_by text,
    ADD COLUMN IF NOT EXISTS promotion_requested_at timestamptz;

-- A promotion request is a change record, an impact assessment, verification, an author
-- and a time, together or not at all. CH1-RND-FR-0003 requires all of the first three;
-- a request holding some of them would evidence an assessment that was never made.
ALTER TABLE ch1.experiments
    DROP CONSTRAINT IF EXISTS ck_experiments_promotion_complete;
ALTER TABLE ch1.experiments
    ADD CONSTRAINT ck_experiments_promotion_complete CHECK (
        (promotion_change_record IS NULL
            AND promotion_impact_analysis IS NULL
            AND promotion_verification IS NULL
            AND promotion_requested_by IS NULL
            AND promotion_requested_at IS NULL)
        OR (promotion_change_record IS NOT NULL
            AND promotion_impact_analysis IS NOT NULL
            AND promotion_verification IS NOT NULL
            AND promotion_requested_by IS NOT NULL
            AND promotion_requested_at IS NOT NULL));

CREATE INDEX IF NOT EXISTS ix_experiment_project_status
    ON ch1.experiments (project_id, status, created_at DESC);

COMMIT;
