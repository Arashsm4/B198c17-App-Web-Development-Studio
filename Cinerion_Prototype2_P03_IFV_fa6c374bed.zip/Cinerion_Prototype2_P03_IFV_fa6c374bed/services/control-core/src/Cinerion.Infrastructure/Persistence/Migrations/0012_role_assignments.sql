-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV role assignment history
-- Copyright © 2026 IR. All rights reserved.

-- entities.json declares RoleAssignment with its own identifier (assignment_id), a
-- Security Sensitive classification and a retention of 7 years. 0001 created no table for
-- it, so role changes were evidenced only by ch1.audit_events - which stores a payload
-- HASH rather than the payload. Who held what, and when, was therefore verifiable and not
-- readable: an auditor could prove an event had not been altered while being unable to say
-- what it recorded.
--
-- The same class as conflicts 3 and 7 - a declared entity with no table - and resolved the
-- same way: add the table the register declares, additively, and change nothing about the
-- authority that writes it.
--
-- WHAT THIS IS NOT. Keycloak remains the authority on who holds which role; this is CH1's
-- own permanent record of the changes IT made, which is what a 7-year controlled retention
-- of a security-sensitive record has to mean. A role changed directly in the identity
-- provider does not appear here, and the register's row says as much by naming the
-- provider each change was applied to.

BEGIN;

CREATE TABLE IF NOT EXISTS ch1.role_assignments (
    assignment_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),

    -- The subject, by the identity provider's own identifier and by the name a reader
    -- will recognise. Both, because an identifier alone is unreadable to a human auditor
    -- and a name alone is not stable.
    subject_user_id text NOT NULL CHECK (length(btrim(subject_user_id)) > 0),
    subject_username text NOT NULL CHECK (length(btrim(subject_username)) > 0),

    -- Before and after, in full, rather than only the difference. A history of deltas
    -- cannot answer "what did this person hold on that date" without replaying every row
    -- from the beginning and trusting that none is missing.
    previous_roles jsonb NOT NULL DEFAULT '[]'::jsonb,
    current_roles jsonb NOT NULL DEFAULT '[]'::jsonb,
    granted_roles jsonb NOT NULL DEFAULT '[]'::jsonb,
    withdrawn_roles jsonb NOT NULL DEFAULT '[]'::jsonb,
    CHECK (jsonb_typeof(previous_roles) = 'array'),
    CHECK (jsonb_typeof(current_roles) = 'array'),
    CHECK (jsonb_typeof(granted_roles) = 'array'),
    CHECK (jsonb_typeof(withdrawn_roles) = 'array'),

    -- A change that granted and withdrew nothing is not a change. Recording one would put
    -- rows in a permanent register that evidence no event.
    CHECK (jsonb_array_length(granted_roles) + jsonb_array_length(withdrawn_roles) > 0),

    assigned_by text NOT NULL CHECK (length(btrim(assigned_by)) > 0),
    assigned_at timestamptz NOT NULL,

    -- Which provider the change was actually applied to, so a row cannot be read as
    -- evidence about a directory it never reached.
    provider text NOT NULL CHECK (length(btrim(provider)) > 0),

    -- The request this change belonged to, so the row and its audit event can be put
    -- beside each other.
    correlation_id uuid NOT NULL,

    -- The declared retention, carried on the row rather than held in a policy document
    -- somewhere else. entities.json says 7 years; a disposal process can then act on the
    -- data instead of on a reading of a page, and the CHECK means the row cannot be
    -- written with a retention that disagrees with the register.
    retain_until timestamptz NOT NULL,
    CHECK (retain_until = assigned_at + interval '7 years')
);

CREATE INDEX IF NOT EXISTS ix_role_assignments_subject
    ON ch1.role_assignments (project_id, subject_user_id, assigned_at DESC);
CREATE INDEX IF NOT EXISTS ix_role_assignments_time
    ON ch1.role_assignments (project_id, assigned_at DESC);

ALTER TABLE ch1.role_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.role_assignments FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.role_assignments;
CREATE POLICY project_isolation ON ch1.role_assignments
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

-- INSERT and SELECT only. The application has no reason to change a role assignment that
-- has already happened, and a grant it does not hold is a grant no defect can misuse.
-- Deletion after the retention period is a separate authorised administrative act, on the
-- same terms as telemetry disposal, and is deliberately not the application's to perform.
--
-- THE REVOKE IS THE LOAD-BEARING HALF, and the GRANT on its own would have been a comment
-- rather than a control. 0002 sets ALTER DEFAULT PRIVILEGES IN SCHEMA ch1 GRANT SELECT,
-- INSERT, UPDATE, DELETE ON TABLES, so cinerion_app receives all four on every table
-- created here from the moment it exists. Granting two of them again changes nothing. This
-- was caught by the test that attacks the register directly, which found the UPDATE being
-- refused by the immutability trigger rather than by an absent privilege - the trigger
-- holding a line the grant was supposed to have held first.
GRANT SELECT, INSERT ON ch1.role_assignments TO cinerion_app;
REVOKE UPDATE, DELETE ON ch1.role_assignments FROM cinerion_app;

-- Permanent within its retention: a security-sensitive record that could be rewritten
-- afterwards evidences nothing.
CREATE TRIGGER role_assignments_immutable
    BEFORE UPDATE OR DELETE ON ch1.role_assignments
    FOR EACH ROW EXECUTE FUNCTION ch1.reject_immutable_mutation();

COMMIT;
