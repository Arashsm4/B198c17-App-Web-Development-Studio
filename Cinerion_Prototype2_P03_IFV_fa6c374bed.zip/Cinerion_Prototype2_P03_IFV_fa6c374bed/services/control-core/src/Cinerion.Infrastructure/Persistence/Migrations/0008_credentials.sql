-- CONFIDENTIAL - PROJECT INTERNAL
-- Cinerion CH1 P03/IFV authenticator credentials
-- Copyright © 2026 IR. All rights reserved.

-- entities.json declares Credential as a Security Sensitive entity with its own primary
-- identifier (credential_id), the purpose "Authenticator metadata, never raw secret" and
-- "Credential life + 7 years" retention. 0001 created no table for it, so
-- POST /api/v1/credentials and DELETE /api/v1/credentials/{credentialId} had nowhere to
-- record the lifecycle CH1-IAM-FR-0006 requires to be individually enrolled,
-- attributable, auditable, expirable and revocable.
--
-- There is deliberately no column into which a private key could be written. CH1-CYB-
-- IAM-0001 makes long-lived private keys non-exportable in a token or secure element, so
-- for a passkey or security token the platform holds the public half and nothing else,
-- exactly as ch1.devices holds a certificate and never a device key. The one secret this
-- table does hold is a TOTP seed, which is symmetric and has nowhere else to live; it is
-- sealed with AES-256-GCM before it arrives here and the sealing key is supplied by the
-- deployment, never by this schema.
--
-- No ch1.users table is referenced, and that is the settled decision: FortressGate owns
-- identity, so subject_id is the provider's identifier and is not a foreign key here.
-- Duplicating the directory would create a second system of record that could disagree
-- with the first.

BEGIN;

CREATE TABLE IF NOT EXISTS ch1.credentials (
    credential_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),

    -- The FortressGate identity this authenticator belongs to. CH1-CYB-IAM-0001
    -- prohibits shared human accounts, so one credential has exactly one subject.
    subject_id text NOT NULL CHECK (length(subject_id) BETWEEN 1 AND 255),

    -- Passkey     - FIDO2/WebAuthn, origin-bound, phishing resistant.
    -- SecurityToken - NFC-enabled FIDO token; same protocol, roaming authenticator.
    -- SmartCard   - DESFire-class card with challenge-response, for local presence.
    -- Totp        - RFC 6238, permitted only inside the approved recovery/assurance
    --               policy and never counted as phishing resistant.
    credential_kind text NOT NULL
        CHECK (credential_kind IN ('Passkey', 'SecurityToken', 'SmartCard', 'Totp')),

    label text NOT NULL CHECK (length(label) BETWEEN 1 AND 120),

    -- The public half of an asymmetric authenticator, SubjectPublicKeyInfo encoded.
    public_key_spki bytea,
    -- The authenticator's own credential handle, echoed in an assertion.
    webauthn_credential_id bytea,
    aaguid uuid,
    -- Monotonic clone-detection counter (WebAuthn 6.1.1). An assertion presenting a
    -- counter that did not advance is evidence of a cloned authenticator.
    sign_count bigint NOT NULL DEFAULT 0 CHECK (sign_count >= 0),
    rp_id text,

    -- Sealed TOTP seed. Never returned by any operation after enrolment; the enrolment
    -- response is the only time the shared secret is disclosed.
    sealed_secret bytea,
    sealed_secret_nonce bytea,
    totp_digits smallint CHECK (totp_digits IS NULL OR totp_digits BETWEEN 6 AND 8),
    totp_period_seconds smallint CHECK (totp_period_seconds IS NULL OR totp_period_seconds BETWEEN 15 AND 120),
    totp_algorithm text CHECK (totp_algorithm IS NULL OR totp_algorithm IN ('SHA1', 'SHA256', 'SHA512')),

    -- Physical credential identity, for the smart-card and token classes.
    serial_number text,
    attestation_sha256 char(64) CHECK (attestation_sha256 IS NULL OR attestation_sha256 ~ '^[a-f0-9]{64}$'),

    -- Whether the authenticator verified the *user* (PIN or biometric) and not merely
    -- that it was present. CH1-CYB-IAM-0001 requires user verification according to
    -- credential capability and risk.
    user_verification text NOT NULL
        CHECK (user_verification IN ('Required', 'Preferred', 'Discouraged')),

    -- Recorded rather than inferred at read time, so a change in how the platform
    -- classifies an authenticator cannot silently reclassify one already enrolled.
    phishing_resistant boolean NOT NULL,

    status text NOT NULL CHECK (status IN ('Active', 'Suspended', 'Revoked', 'Expired')),

    enrolled_by text NOT NULL,
    enrolled_at timestamptz NOT NULL,
    last_used_at timestamptz,
    expires_at timestamptz,

    revoked_at timestamptz,
    revoked_by text,
    revocation_reason text,

    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),

    -- A TOTP secret is a shared symmetric key: whoever holds it can mint codes, so it is
    -- not proof of possession of anything unclonable and must never be credited as
    -- phishing resistant. A passkey or FIDO token is origin-bound by the protocol and
    -- always is. Encoding both here means no future code path can promote TOTP to a
    -- strength it does not have without a reviewed migration.
    CONSTRAINT ck_credentials_totp_not_phishing_resistant
        CHECK (credential_kind <> 'Totp' OR phishing_resistant = false),
    CONSTRAINT ck_credentials_fido_is_phishing_resistant
        CHECK (credential_kind NOT IN ('Passkey', 'SecurityToken') OR phishing_resistant = true),

    -- An asymmetric authenticator without its public key could never verify an
    -- assertion; a TOTP credential without a sealed seed could never verify a code.
    CONSTRAINT ck_credentials_material_present CHECK (
        (credential_kind IN ('Passkey', 'SecurityToken')
            AND public_key_spki IS NOT NULL AND webauthn_credential_id IS NOT NULL
            AND sealed_secret IS NULL)
        OR (credential_kind = 'Totp'
            AND sealed_secret IS NOT NULL AND sealed_secret_nonce IS NOT NULL
            AND totp_digits IS NOT NULL AND totp_period_seconds IS NOT NULL
            AND totp_algorithm IS NOT NULL
            AND public_key_spki IS NULL)
        OR (credential_kind = 'SmartCard'
            AND public_key_spki IS NOT NULL AND serial_number IS NOT NULL
            AND sealed_secret IS NULL)),

    -- The same rule ch1.devices carries: a revocation is a time, an author and a reason
    -- together, or it is unattributable evidence of a security decision.
    CONSTRAINT ck_credentials_revocation_complete CHECK (
        (revoked_at IS NULL AND revoked_by IS NULL AND revocation_reason IS NULL)
        OR (revoked_at IS NOT NULL AND revoked_by IS NOT NULL AND revocation_reason IS NOT NULL)),

    CONSTRAINT ck_credentials_revoked_status CHECK (
        (status = 'Revoked') = (revoked_at IS NOT NULL))
);

-- One authenticator handle belongs to one credential record. Without this the same
-- passkey could be enrolled twice, which is a cloned credential going unnoticed - the
-- same reasoning as ux_devices_certificate_thumbprint in 0007.
CREATE UNIQUE INDEX IF NOT EXISTS ux_credentials_webauthn_id
    ON ch1.credentials (project_id, webauthn_credential_id)
    WHERE webauthn_credential_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_credentials_serial
    ON ch1.credentials (project_id, credential_kind, serial_number)
    WHERE serial_number IS NOT NULL;

-- One active TOTP enrolment per identity. A second would leave two valid seeds with no
-- way for the holder to know which one an attacker had.
CREATE UNIQUE INDEX IF NOT EXISTS ux_credentials_active_totp
    ON ch1.credentials (project_id, subject_id)
    WHERE credential_kind = 'Totp' AND status = 'Active';

CREATE INDEX IF NOT EXISTS ix_credentials_subject
    ON ch1.credentials (project_id, subject_id, status);

ALTER TABLE ch1.credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.credentials FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.credentials;
CREATE POLICY project_isolation ON ch1.credentials
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON ch1.credentials TO cinerion_app;

-- ------------------------------------------------------------ passkey challenges

-- A WebAuthn challenge is a short-lived, single-use nonce. It is stored rather than held
-- in memory because CH1-SWA-API-0001 permits more than one Control Core instance and a
-- challenge issued by one must be redeemable at another; an in-memory challenge would
-- fail intermittently behind a load balancer and look like a client fault.
--
-- It is not a controlled entity and carries no retention obligation: the row is consumed
-- on verification and swept when it expires. What survives is the audit event.
CREATE TABLE IF NOT EXISTS ch1.webauthn_challenges (
    challenge_id uuid PRIMARY KEY,
    project_id uuid NOT NULL REFERENCES ch1.projects(project_id),
    subject_id text NOT NULL,
    challenge bytea NOT NULL CHECK (octet_length(challenge) >= 16),
    rp_id text NOT NULL,
    origin text NOT NULL,
    purpose text NOT NULL,
    issued_at timestamptz NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    CHECK (expires_at > issued_at)
);

CREATE INDEX IF NOT EXISTS ix_webauthn_challenge_expiry
    ON ch1.webauthn_challenges (expires_at);

ALTER TABLE ch1.webauthn_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE ch1.webauthn_challenges FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS project_isolation ON ch1.webauthn_challenges;
CREATE POLICY project_isolation ON ch1.webauthn_challenges
    USING (project_id = ch1.current_project_id())
    WITH CHECK (project_id = ch1.current_project_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON ch1.webauthn_challenges TO cinerion_app;

COMMIT;
