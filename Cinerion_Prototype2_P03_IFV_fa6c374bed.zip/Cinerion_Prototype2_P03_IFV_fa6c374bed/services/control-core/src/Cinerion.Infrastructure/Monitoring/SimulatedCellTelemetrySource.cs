// Pretend telemetry for the Simulation profile, clearly marked as simulated.

using Cinerion.Application.Monitoring;
using Cinerion.Domain.Monitoring;
using Cinerion.Infrastructure.Persistence;
using Cinerion.Infrastructure.Seed;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Cinerion.Infrastructure.Monitoring;

/// <summary>
/// Feeds the telemetry pipeline in the Simulation runtime profile.
/// <para>
/// The device path that CH1-COM-IF-0004 and CH1-COM-IF-0005 describe — MQTT over TLS
/// with per-device certificates, through EdgeLink — is hardware and PKI gated and is
/// not enabled at this checkpoint. Until it is, telemetry has to come from somewhere
/// for the ingestion, alarm and query path to be real rather than asserted.
/// </para>
/// <para>
/// What this source is, and is not, is stated in the data itself: every sample it
/// produces carries <see cref="Freshness.Simulated"/>, which CH1-MON-FR-0003 requires
/// to stay distinguishable from a live reading in every view. It runs only in the
/// Simulation profile and refuses to start in any other. It writes through exactly the
/// same ingestion path a gateway would use, so nothing here is a shortcut around the
/// device trust, channel allowlist or unit checks.
/// </para>
/// </summary>
/// <requirements>CH1-MON-FR-0003, CH1-COM-FR-0007, CH1-AUT-FDS-0001</requirements>
public sealed partial class SimulatedCellTelemetrySource(
    IServiceScopeFactory scopeFactory,
    ILogger<SimulatedCellTelemetrySource> logger,
    TimeProvider? timeProvider = null) : BackgroundService
{
    private readonly TimeProvider _timeProvider = timeProvider ?? TimeProvider.System;

    /// <summary>
    /// One sample per channel per interval. Chosen so an alarm can be raised, seen,
    /// acknowledged and cleared inside an operator's attention span, and so the volume
    /// stays far below the CH1-NFR-PER-0001 baseline of 100 messages per second.
    /// </summary>
    public static readonly TimeSpan Interval = TimeSpan.FromSeconds(5);

    /// <summary>The device the seeded cell reports through.</summary>
    private const string DeviceId = "CH1-DEV-CELL-0001";

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        LogSourceStarted(logger, Interval.TotalSeconds, TelemetryChannelCatalogue.Version);
        var step = 0L;
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PublishAsync(step, stoppingToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                return;
            }
#pragma warning disable CA1031 // A simulation source must never take the service down.
            catch (Exception error)
#pragma warning restore CA1031
            {
                LogPublishFailed(logger, error);
            }

            step++;
            try
            {
                await Task.Delay(Interval, _timeProvider, stoppingToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                return;
            }
        }
    }

    private async Task PublishAsync(long step, CancellationToken cancellationToken)
    {
        // The store and its project scope are per request when running on PostgreSQL,
        // so each cycle takes its own scope and establishes the seeded project's scope
        // before touching the database. Without that, row-level security would
        // correctly refuse every write.
        await using var scope = scopeFactory.CreateAsyncScope();
        scope.ServiceProvider.GetService<ProjectScope>()?.Set(PrototypeSeed.Ids.ProjectId);
        var monitoring = scope.ServiceProvider.GetRequiredService<MonitoringService>();

        var sampledAt = _timeProvider.GetUtcNow();
        var readings = new List<TelemetryReading>();
        foreach (var channel in TelemetryChannelCatalogue.All)
        {
            readings.Add(new TelemetryReading(
                PrototypeSeed.Ids.CellId,
                DeviceId,
                channel.ChannelId,
                ValueFor(channel, step),
                channel.Unit,
                DataQuality.Good,
                Freshness.Simulated,
                sampledAt));
        }

        var result = await monitoring
            .IngestAsync(PrototypeSeed.Ids.ProjectId, readings, cancellationToken)
            .ConfigureAwait(false);

        foreach (var alarm in result.Raised)
        {
            LogAlarmRaised(logger, alarm.AlarmCode, alarm.Priority, alarm.AlarmId);
        }

        foreach (var alarm in result.Cleared)
        {
            LogAlarmCauseCleared(logger, alarm.AlarmCode, alarm.State, alarm.AlarmId);
        }
    }

    /// <summary>
    /// A deterministic profile per channel. Temperature drifts slowly above its upper
    /// limit and back, so the raise, acknowledge and clear path is exercised end to end
    /// on a running system rather than only in a test double. The other channels stay
    /// inside their limits, so a breach on one channel does not mask the others.
    /// </summary>
    private static double ValueFor(TelemetryChannel channel, long step) => channel.ChannelId switch
    {
        // Period of 40 steps: roughly 200 seconds at the default interval, of which
        // about a quarter is spent above the 45 degC limit.
        "temperature" => 38.0 + (9.0 * Math.Sin(step * Math.PI / 20.0)),
        "humidity" => 44.0 + (6.0 * Math.Sin(step * Math.PI / 13.0)),
        "position" => 120.0 + (40.0 * Math.Sin(step * Math.PI / 7.0)),
        "vibration_rms" => 1.2 + (0.6 * Math.Abs(Math.Sin(step * Math.PI / 11.0))),
        _ => (channel.LowerAlarmLimit + channel.UpperAlarmLimit) / 2.0,
    };

    [LoggerMessage(
        EventId = 2000,
        Level = LogLevel.Information,
        Message = "Simulated telemetry source started: every {IntervalSeconds}s across channel catalogue {CatalogueVersion}. Samples are marked Simulated and carry no physical authority.")]
    private static partial void LogSourceStarted(ILogger logger, double intervalSeconds, string catalogueVersion);

    [LoggerMessage(
        EventId = 2001,
        Level = LogLevel.Warning,
        Message = "Alarm {AlarmCode} raised at priority {Priority} ({AlarmId})")]
    private static partial void LogAlarmRaised(ILogger logger, string alarmCode, int priority, Guid alarmId);

    [LoggerMessage(
        EventId = 2002,
        Level = LogLevel.Information,
        Message = "Alarm {AlarmCode} cause cleared; state is now {State} ({AlarmId})")]
    private static partial void LogAlarmCauseCleared(ILogger logger, string alarmCode, AlarmState state, Guid alarmId);

    [LoggerMessage(
        EventId = 2003,
        Level = LogLevel.Error,
        Message = "Simulated telemetry cycle failed; the source continues and no sample was stored for this cycle.")]
    private static partial void LogPublishFailed(ILogger logger, Exception error);
}
