// Seals secrets with AES-256-GCM before they go anywhere near the database.

using System.Security.Cryptography;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Common;

namespace Cinerion.Infrastructure.Security;

/// <summary>
/// AES-256-GCM sealing for the one symmetric secret the platform stores.
/// <para>
/// The key is supplied by the deployment through
/// <c>CINERION_CREDENTIAL_ENCRYPTION_KEY</c> as 32 base64 bytes and is never generated,
/// derived from anything guessable, or defaulted. With no key configured the sealer
/// reports itself unconfigured and TOTP enrolment refuses — the same fail-closed
/// direction the identity directory takes without its client secret, and for the same
/// reason: a service that quietly stored seeds in the clear would satisfy the operation
/// and defeat the control.
/// </para>
/// <para>
/// GCM is used with a fresh 96-bit nonce per seal and the credential identifier as
/// associated data, so a ciphertext is bound to the row it belongs to and cannot be
/// moved to another identity's credential and still open.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-IAM-0001, CH1-CYB-CSRS-0001</requirements>
public sealed class AesGcmCredentialSealer : ICredentialSealer, IDisposable
{
    private const int KeyBytes = 32;
    private const int NonceBytes = 12;
    private const int TagBytes = 16;

    private readonly AesGcm? cipher;

    public AesGcmCredentialSealer(string? base64Key)
    {
        if (string.IsNullOrWhiteSpace(base64Key))
        {
            cipher = null;
            return;
        }

        byte[] key;
        try
        {
            key = Convert.FromBase64String(base64Key);
        }
        catch (FormatException)
        {
            throw new InvalidOperationException(
                "CINERION_CREDENTIAL_ENCRYPTION_KEY is not valid base64. Supply 32 random bytes, " +
                "base64 encoded, from controlled secret storage.");
        }

        if (key.Length != KeyBytes)
        {
            throw new InvalidOperationException(
                $"CINERION_CREDENTIAL_ENCRYPTION_KEY must decode to {KeyBytes} bytes, not {key.Length}. " +
                "A short key would weaken every sealed secret at once.");
        }

        cipher = new AesGcm(key, TagBytes);
        CryptographicOperations.ZeroMemory(key);
    }

    public bool IsConfigured => cipher is not null;

    public SealedSecret Seal(ReadOnlySpan<byte> plaintext, ReadOnlySpan<byte> associatedData)
    {
        Guard.Against(
            cipher is null,
            "CREDENTIAL_SEALING_NOT_CONFIGURED",
            "No credential encryption key is configured, so a secret cannot be stored. " +
            "Set CINERION_CREDENTIAL_ENCRYPTION_KEY from controlled secret storage.");

        var nonce = RandomNumberGenerator.GetBytes(NonceBytes);
        // Tag appended to the ciphertext so one column holds a complete sealed value.
        var sealedBytes = new byte[plaintext.Length + TagBytes];
        cipher!.Encrypt(
            nonce,
            plaintext,
            sealedBytes.AsSpan(0, plaintext.Length),
            sealedBytes.AsSpan(plaintext.Length, TagBytes),
            associatedData);

        return new SealedSecret(sealedBytes, nonce);
    }

    public byte[] Open(SealedSecret sealedSecret, ReadOnlySpan<byte> associatedData)
    {
        Guard.Against(
            cipher is null,
            "CREDENTIAL_SEALING_NOT_CONFIGURED",
            "No credential encryption key is configured, so a stored secret cannot be opened.");
        Guard.Against(
            sealedSecret.Ciphertext.Length <= TagBytes || sealedSecret.Nonce.Length != NonceBytes,
            "CREDENTIAL_SEALED_VALUE_MALFORMED",
            "The stored secret is not a well-formed sealed value.");

        var plaintextLength = sealedSecret.Ciphertext.Length - TagBytes;
        var plaintext = new byte[plaintextLength];
        try
        {
            cipher!.Decrypt(
                sealedSecret.Nonce,
                sealedSecret.Ciphertext.AsSpan(0, plaintextLength),
                sealedSecret.Ciphertext.AsSpan(plaintextLength, TagBytes),
                plaintext,
                associatedData);
        }
        catch (CryptographicException)
        {
            // Authentication failure: wrong key, altered ciphertext, or a value moved
            // from another record. All three are the same answer — this did not open.
            throw new DomainRuleException(
                "CREDENTIAL_SEALED_VALUE_NOT_AUTHENTIC",
                "The stored secret did not authenticate under the configured key.");
        }

        return plaintext;
    }

    public void Dispose() => cipher?.Dispose();
}
