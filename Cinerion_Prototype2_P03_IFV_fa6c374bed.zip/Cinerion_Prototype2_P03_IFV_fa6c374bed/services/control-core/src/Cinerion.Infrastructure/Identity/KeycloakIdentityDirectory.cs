// Talks to Keycloak's admin API about users and roles. The only outbound HTTP call in this
// whole service.

using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Cinerion.Application.Identity;
using Cinerion.Domain.Common;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Security;

namespace Cinerion.Infrastructure.Identity;

/// <summary>
/// How Control Core reaches the identity provider's administration API.
/// <para>
/// The secret is read from configuration and never appears in source, a realm export or
/// a log. An absent secret is not an error at startup: it means user administration is
/// not enabled, and the endpoints refuse rather than the service failing to start.
/// </para>
/// </summary>
public sealed record IdentityAdminOptions(
    string? Authority,
    string? ClientId,
    string? ClientSecret,
    string PortalClientId = "cinerion-operator-portal")
{
    public bool IsConfigured =>
        !string.IsNullOrWhiteSpace(Authority) &&
        !string.IsNullOrWhiteSpace(ClientId) &&
        !string.IsNullOrWhiteSpace(ClientSecret);

    /// <summary>
    /// The realm name and admin base, derived from the OIDC authority
    /// (<c>http://host/realms/{realm}</c>) so there is one place to configure and no way
    /// for the two to disagree.
    /// </summary>
    public (string AdminBase, string Realm) Resolve()
    {
        var authority = Authority!.TrimEnd('/');
        var marker = authority.LastIndexOf("/realms/", StringComparison.Ordinal);
        if (marker < 0)
        {
            throw new DomainRuleException(
                "IDENTITY_AUTHORITY_INVALID",
                "CINERION_OIDC_AUTHORITY must be of the form https://host/realms/{realm}.");
        }

        return ($"{authority[..marker]}/admin/realms/{authority[(marker + 8)..]}", authority[(marker + 8)..]);
    }
}

/// <summary>
/// The identity directory when none is configured.
/// <para>
/// Every operation throws. This exists so that the development identity scheme, which
/// has no directory behind it, cannot silently answer a security question with invented
/// data — an empty user list would look like a project with no people rather than a
/// service that cannot see any.
/// </para>
/// </summary>
public sealed class UnconfiguredIdentityDirectory(string reason) : IIdentityDirectory
{
    public bool IsConfigured => false;

    public string ProviderDescription => $"No identity provider configured: {reason}";

    public ValueTask<UserPage> ListUsersAsync(UserQuery query, CancellationToken cancellationToken) => throw Refuse();

    public ValueTask<IdentityUser?> FindUserAsync(string userId, CancellationToken cancellationToken) => throw Refuse();

    public ValueTask ReplaceControlledRolesAsync(
        string userId,
        IReadOnlyList<string> roles,
        CancellationToken cancellationToken) => throw Refuse();

    public ValueTask<IdentitySession?> FindSessionAsync(
        Guid projectId,
        string sessionId,
        CancellationToken cancellationToken) => throw Refuse();

    public ValueTask<bool> RevokeSessionAsync(string sessionId, CancellationToken cancellationToken) => throw Refuse();

    private DomainRuleException Refuse() => new("IDENTITY_PROVIDER_NOT_CONFIGURED", ProviderDescription);
}

/// <summary>
/// Keycloak Admin REST API adapter.
/// <para>
/// The service account behind it is granted <c>view-users</c>, <c>query-users</c> and
/// <c>manage-users</c> only. <c>realm-admin</c>, <c>manage-realm</c>,
/// <c>manage-clients</c> and <c>manage-authorization</c> are deliberately withheld, so
/// the "no security-policy authority" control on user administration holds at the
/// identity provider as well as in this code: even a defect here could not reach realm
/// policy, because the token would not carry the permission.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0006, CH1-IAM-FR-0008, CH1-CYB-ACP-0001</requirements>
public sealed class KeycloakIdentityDirectory(
    HttpClient http,
    IdentityAdminOptions options,
    TimeProvider timeProvider) : IIdentityDirectory, IDisposable
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private readonly SemaphoreSlim _tokenGate = new(1, 1);
    private string? _accessToken;
    private DateTimeOffset _tokenExpiresAt = DateTimeOffset.MinValue;

    public void Dispose() => _tokenGate.Dispose();

    public bool IsConfigured => options.IsConfigured;

    public string ProviderDescription =>
        $"Keycloak admin API, realm {options.Resolve().Realm}, client {options.ClientId}";

    public async ValueTask<UserPage> ListUsersAsync(UserQuery query, CancellationToken cancellationToken)
    {
        var (adminBase, _) = options.Resolve();
        // One extra row is requested so the caller can be told whether another page
        // exists without a second round trip or a count query.
        var url = $"{adminBase}/users?first={query.Offset}&max={query.Limit + 1}" +
            (query.Search is null ? string.Empty : $"&search={Uri.EscapeDataString(query.Search)}");
        var users = await SendAsync<List<KeycloakUser>>(HttpMethod.Get, url, null, cancellationToken)
            .ConfigureAwait(false) ?? [];

        // The project filter is re-applied here rather than trusted to the provider's
        // search. Keycloak cannot filter on an unmanaged attribute reliably, and a
        // directory that quietly returned every project's people would be a scope leak
        // that looks like a working page.
        var scoped = users
            .Select(Map)
            .Where(user => user.ProjectId == query.ProjectId)
            .ToList();

        var hasMore = users.Count > query.Limit;
        if (scoped.Count > query.Limit)
        {
            scoped.RemoveRange(query.Limit, scoped.Count - query.Limit);
        }

        return new UserPage(scoped, hasMore, query.Offset + query.Limit);
    }

    public async ValueTask<IdentityUser?> FindUserAsync(string userId, CancellationToken cancellationToken)
    {
        var (adminBase, _) = options.Resolve();
        var user = await SendAsync<KeycloakUser>(
            HttpMethod.Get, $"{adminBase}/users/{Uri.EscapeDataString(userId)}", null, cancellationToken)
            .ConfigureAwait(false);
        if (user is null)
        {
            return null;
        }

        var roles = await SendAsync<List<KeycloakRole>>(
            HttpMethod.Get,
            $"{adminBase}/users/{Uri.EscapeDataString(userId)}/role-mappings/realm",
            null,
            cancellationToken).ConfigureAwait(false) ?? [];
        return Map(user) with
        {
            Roles = [.. roles.Select(role => role.Name)
                .Where(name => CinerionRoles.All.Contains(name, StringComparer.Ordinal))
                .OrderBy(name => name, StringComparer.Ordinal)],
        };
    }

    /// <summary>
    /// Applies the difference between the held and requested controlled roles.
    /// <para>
    /// Realm roles Cinerion does not control — Keycloak's own <c>default-roles-*</c>, for
    /// instance — are left untouched. Replacing the whole mapping would strip them and
    /// break the account in ways nothing in the controlled documents asked for.
    /// </para>
    /// </summary>
    public async ValueTask ReplaceControlledRolesAsync(
        string userId,
        IReadOnlyList<string> roles,
        CancellationToken cancellationToken)
    {
        var (adminBase, _) = options.Resolve();
        var path = $"{adminBase}/users/{Uri.EscapeDataString(userId)}/role-mappings/realm";

        // "Which realm roles may this user be given" rather than "list every realm role".
        // Both answer the question, but the realm-wide listing needs view-realm, which
        // this service account is deliberately not granted — asking the narrower question
        // is what keeps the grant to view-users, query-users and manage-users.
        var held = await SendAsync<List<KeycloakRole>>(HttpMethod.Get, path, null, cancellationToken)
            .ConfigureAwait(false) ?? [];
        var assignable = await SendAsync<List<KeycloakRole>>(
            HttpMethod.Get, $"{path}/available", null, cancellationToken).ConfigureAwait(false) ?? [];

        var byName = held.Concat(assignable)
            .GroupBy(role => role.Name, StringComparer.Ordinal)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.Ordinal);
        var heldControlled = held
            .Where(role => CinerionRoles.All.Contains(role.Name, StringComparer.Ordinal))
            .ToList();

        var toAdd = roles
            .Where(name => !heldControlled.Any(role => StringComparer.Ordinal.Equals(role.Name, name)))
            .Select(name => byName.TryGetValue(name, out var role)
                ? role
                : throw new DomainRuleException(
                    "ROLE_NOT_DEFINED_IN_REALM",
                    $"'{name}' is a controlled role but is not defined in the identity provider's realm."))
            .ToList();
        var toRemove = heldControlled
            .Where(role => !roles.Contains(role.Name, StringComparer.Ordinal))
            .ToList();

        // Withdrawals go first. If the second call failed, the account is left with
        // fewer authorities than intended rather than more, which is the safe direction.
        if (toRemove.Count > 0)
        {
            await SendAsync<object>(HttpMethod.Delete, path, toRemove, cancellationToken).ConfigureAwait(false);
        }

        if (toAdd.Count > 0)
        {
            await SendAsync<object>(HttpMethod.Post, path, toAdd, cancellationToken).ConfigureAwait(false);
        }
    }

    /// <summary>
    /// Finds a session by identifier, within one project's users.
    /// <para>
    /// Keycloak has no "get session by identifier" endpoint. The obvious alternative,
    /// enumerating a client's sessions, needs <c>view-clients</c>, which this service
    /// account is deliberately not granted — and it would also return sessions belonging
    /// to every project. Walking the caller's own project users instead uses only
    /// <c>view-users</c> and makes project scope structural: a session outside the
    /// project is not found rather than found and then filtered.
    /// </para>
    /// <para>
    /// One request per user in the project. That is bounded work at this deployment's
    /// scale; a directory large enough for it to matter would want the identity provider
    /// to expose the lookup directly.
    /// </para>
    /// </summary>
    public async ValueTask<IdentitySession?> FindSessionAsync(
        Guid projectId,
        string sessionId,
        CancellationToken cancellationToken)
    {
        var (adminBase, _) = options.Resolve();
        var scoped = await ListUsersAsync(
            UserQuery.Create(projectId, null, null, UserQuery.MaximumRows), cancellationToken)
            .ConfigureAwait(false);

        foreach (var user in scoped.Users)
        {
            var sessions = await SendAsync<List<KeycloakSession>>(
                HttpMethod.Get,
                $"{adminBase}/users/{Uri.EscapeDataString(user.UserId)}/sessions",
                null,
                cancellationToken).ConfigureAwait(false) ?? [];
            var match = sessions.Find(session => StringComparer.Ordinal.Equals(session.Id, sessionId));
            if (match is not null)
            {
                return new IdentitySession(
                    match.Id,
                    user.UserId,
                    user.Username,
                    options.PortalClientId,
                    FromUnixMilliseconds(match.Start),
                    FromUnixMilliseconds(match.LastAccess));
            }
        }

        return null;
    }

    public async ValueTask<bool> RevokeSessionAsync(string sessionId, CancellationToken cancellationToken)
    {
        var (adminBase, _) = options.Resolve();
        using var request = new HttpRequestMessage(
            HttpMethod.Delete, $"{adminBase}/sessions/{Uri.EscapeDataString(sessionId)}");
        request.Headers.Authorization = new AuthenticationHeaderValue(
            "Bearer", await AccessTokenAsync(cancellationToken).ConfigureAwait(false));
        using var response = await http.SendAsync(request, cancellationToken).ConfigureAwait(false);
        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            return false;
        }

        EnsureSuccess(response);
        return true;
    }

    // ------------------------------------------------------------------ helpers

    private static DateTimeOffset FromUnixMilliseconds(long value) =>
        value <= 0 ? DateTimeOffset.UnixEpoch : DateTimeOffset.FromUnixTimeMilliseconds(value);

    private static IdentityUser Map(KeycloakUser user) => new(
        user.Id,
        user.Username,
        string.Join(' ', new[] { user.FirstName, user.LastName }.Where(part => !string.IsNullOrWhiteSpace(part))) is { Length: > 0 } name
            ? name
            : null,
        user.Enabled,
        SingleGuid(user.Attributes, "ch1_project"),
        [.. AllGuids(user.Attributes, "ch1_cell")],
        // Role mappings are a separate call; the list projection leaves this empty
        // rather than making one request per user.
        [],
        SingleEnum(user.Attributes, "ch1_actor_kind", ActorKind.Human),
        user.CreatedTimestamp > 0 ? DateTimeOffset.FromUnixTimeMilliseconds(user.CreatedTimestamp) : null);

    private static Guid? SingleGuid(Dictionary<string, List<string>>? attributes, string key) =>
        attributes is not null &&
        attributes.TryGetValue(key, out var values) &&
        values.Count > 0 &&
        Guid.TryParse(values[0], out var parsed)
            ? parsed
            : null;

    private static IEnumerable<Guid> AllGuids(Dictionary<string, List<string>>? attributes, string key) =>
        attributes is not null && attributes.TryGetValue(key, out var values)
            ? values.Select(value => Guid.TryParse(value, out var parsed) ? parsed : Guid.Empty)
                .Where(value => value != Guid.Empty)
            : [];

    private static ActorKind SingleEnum(Dictionary<string, List<string>>? attributes, string key, ActorKind fallback) =>
        attributes is not null &&
        attributes.TryGetValue(key, out var values) &&
        values.Count > 0 &&
        Enum.TryParse<ActorKind>(values[0], ignoreCase: true, out var parsed)
            ? parsed
            : fallback;

    private async ValueTask<T?> SendAsync<T>(
        HttpMethod method,
        string url,
        object? body,
        CancellationToken cancellationToken)
        where T : class
    {
        using var request = new HttpRequestMessage(method, url);
        request.Headers.Authorization = new AuthenticationHeaderValue(
            "Bearer", await AccessTokenAsync(cancellationToken).ConfigureAwait(false));
        if (body is not null)
        {
            request.Content = JsonContent.Create(body, options: Json);
        }

        using var response = await http.SendAsync(request, cancellationToken).ConfigureAwait(false);
        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }

        EnsureSuccess(response);
        if (response.StatusCode == HttpStatusCode.NoContent || typeof(T) == typeof(object))
        {
            return null;
        }

        return await response.Content.ReadFromJsonAsync<T>(Json, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Turns a provider failure into a domain error carrying the status but never the
    /// response body: an identity provider's error text can echo request content, and
    /// this path carries administrative requests.
    /// </summary>
    private static void EnsureSuccess(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode)
        {
            return;
        }

        var code = response.StatusCode == HttpStatusCode.Forbidden
            ? "IDENTITY_PROVIDER_FORBADE"
            : "IDENTITY_PROVIDER_FAILED";
        throw new DomainRuleException(
            code,
            $"The identity provider refused the request with status {(int)response.StatusCode}.");
    }

    /// <summary>
    /// A client-credentials token, cached until shortly before it expires so that a
    /// token is never used in the moment it lapses.
    /// </summary>
    private async ValueTask<string> AccessTokenAsync(CancellationToken cancellationToken)
    {
        if (_accessToken is not null && timeProvider.GetUtcNow() < _tokenExpiresAt)
        {
            return _accessToken;
        }

        await _tokenGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (_accessToken is not null && timeProvider.GetUtcNow() < _tokenExpiresAt)
            {
                return _accessToken;
            }

            using var request = new HttpRequestMessage(
                HttpMethod.Post, $"{options.Authority!.TrimEnd('/')}/protocol/openid-connect/token")
            {
                Content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"] = "client_credentials",
                    ["client_id"] = options.ClientId!,
                    ["client_secret"] = options.ClientSecret!,
                }),
            };
            using var response = await http.SendAsync(request, cancellationToken).ConfigureAwait(false);
            if (!response.IsSuccessStatusCode)
            {
                throw new DomainRuleException(
                    "IDENTITY_PROVIDER_UNAUTHENTICATED",
                    $"Control Core could not authenticate to the identity provider (status {(int)response.StatusCode}).");
            }

            var token = await response.Content
                .ReadFromJsonAsync<KeycloakToken>(Json, cancellationToken).ConfigureAwait(false)
                ?? throw new DomainRuleException(
                    "IDENTITY_PROVIDER_UNAUTHENTICATED",
                    "The identity provider returned no token.");

            _accessToken = token.AccessToken;
            // Thirty seconds of headroom, matching the clock skew the bearer handler
            // tolerates elsewhere.
            _tokenExpiresAt = timeProvider.GetUtcNow().AddSeconds(Math.Max(token.ExpiresIn - 30, 5));
            return _accessToken;
        }
        finally
        {
            _tokenGate.Release();
        }
    }

    private sealed record KeycloakToken(
        [property: JsonPropertyName("access_token")] string AccessToken,
        [property: JsonPropertyName("expires_in")] int ExpiresIn);

    private sealed record KeycloakUser(
        string Id,
        string Username,
        bool Enabled,
        string? FirstName,
        string? LastName,
        long CreatedTimestamp,
        Dictionary<string, List<string>>? Attributes);

    private sealed record KeycloakRole(string Id, string Name);

    private sealed record KeycloakClient(string Id, string ClientId);

    private sealed record KeycloakSession(
        string Id,
        [property: JsonPropertyName("userId")] string UserId,
        string? Username,
        long Start,
        long LastAccess);
}
