// An in-memory store for development and tests. Quick, handy, and forgets everything on
// restart.

using System.Collections.Concurrent;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Common;
using Cinerion.Domain.Documents;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Manufacturing;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Research;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;

namespace Cinerion.Infrastructure.InMemory;

public sealed class InMemoryCinerionStore : ICinerionStore
{
    private readonly List<RoleAssignmentRecord> _roleAssignments = [];

    private readonly ConcurrentDictionary<Guid, ControlledDocumentRecord> _documents = new();

    private readonly ConcurrentDictionary<Guid, PublicationPackage> _publicationPackages = new();

    private readonly List<PublicationApproval> _publicationApprovals = [];

    private readonly ConcurrentDictionary<Guid, ProjectRecord> _projects = new();
    private readonly ConcurrentDictionary<Guid, SiteRecord> _sites = new();
    private readonly ConcurrentDictionary<Guid, CellRegistration> _cellRegistrations = new();
    private readonly ConcurrentDictionary<Guid, StoredCellState> _cells = new();
    private readonly ConcurrentDictionary<Guid, CommandTransaction> _commands = new();
    private readonly ConcurrentDictionary<(Guid ProjectId, string Key), Guid> _idempotency = new();
    private readonly ConcurrentDictionary<Guid, PartRecord> _parts = new();
    private readonly ConcurrentDictionary<string, DeviceRecord> _devices = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<Guid, CalibrationRecord> _calibrations = new();
    private readonly ConcurrentDictionary<Guid, AssetRecord> _assets = new();
    private readonly ConcurrentDictionary<Guid, ProductRevisionRecord> _revisions = new();
    private readonly ConcurrentDictionary<Guid, WorkOrderRecord> _workOrders = new();
    private readonly ConcurrentDictionary<Guid, TestRunRecord> _testRuns = new();
    private readonly ConcurrentDictionary<Guid, NcrRecord> _ncrs = new();
    private readonly ConcurrentDictionary<Guid, StepUpGrant> _stepUpGrants = new();
    private readonly ConcurrentDictionary<Guid, CredentialRecord> _credentials = new();
    private readonly ConcurrentDictionary<Guid, WebAuthnChallenge> _webAuthnChallenges = new();
    private readonly ConcurrentDictionary<Guid, ReportRecord> _reports = new();
    private readonly ConcurrentDictionary<Guid, ScanEventRecord> _scanEvents = new();
    private readonly ConcurrentDictionary<Guid, Alarm> _alarms = new();
    private readonly ConcurrentDictionary<Guid, Experiment> _experiments = new();
    private readonly ConcurrentDictionary<Guid, ExperimentRevision> _experimentRevisions = new();
    private readonly Lock _experimentGate = new();
    private readonly ConcurrentDictionary<Guid, ResourceRecord> _resources = new();
    private readonly ConcurrentDictionary<Guid, ResourceAllocation> _allocations = new();
    private readonly Lock _allocationGate = new();
    private readonly ConcurrentDictionary<Guid, ContextThread> _contextThreads = new();
    private readonly ConcurrentDictionary<Guid, ContextMessage> _contextMessages = new();
    private readonly ConcurrentDictionary<(Guid MessageId, string RecipientId), MessageAcknowledgement> _messageAcks = new();
    private readonly List<TelemetrySample> _telemetry = [];
    private readonly Lock _telemetryGate = new();
    private readonly AuditChain _audit = new();

    /// <summary>
    /// How many samples the volatile store keeps. The PostgreSQL table is partitioned
    /// and retained under the controlled retention policy; this store exists only for
    /// development and tests, so it keeps a bounded window and discards the oldest
    /// rather than growing without limit inside a long-running development process.
    /// </summary>
    private const int TelemetryRetainedSamples = 50_000;

    public ValueTask<ProjectRecord?> FindProjectAsync(Guid projectId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_projects.GetValueOrDefault(projectId));
    }

    public ValueTask<ProjectRecord?> FindProjectByCodeAsync(string projectCode, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(
            _projects.Values.SingleOrDefault(item => StringComparer.Ordinal.Equals(item.ProjectCode, projectCode)));
    }

    public ValueTask SaveProjectAsync(ProjectRecord project, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors the UNIQUE constraint on ch1.projects.project_code so the in-memory
        // store refuses what PostgreSQL would refuse.
        var conflicting = _projects.Values.FirstOrDefault(item =>
            StringComparer.Ordinal.Equals(item.ProjectCode, project.ProjectCode) && item.ProjectId != project.ProjectId);
        if (conflicting is not null)
        {
            throw new DomainRuleException("PROJECT_CODE_CONFLICT", "The project code is already assigned.");
        }

        _projects[project.ProjectId] = project;
        return ValueTask.CompletedTask;
    }

    public ValueTask<SiteRecord?> FindSiteAsync(Guid siteId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_sites.GetValueOrDefault(siteId));
    }

    public ValueTask SaveSiteAsync(SiteRecord site, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _sites[site.SiteId] = site;
        return ValueTask.CompletedTask;
    }

    public ValueTask SaveCellRegistrationAsync(CellRegistration cell, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _cellRegistrations[cell.CellId] = cell;
        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<CellRegistration>> ListCellsBySiteAsync(
        Guid projectId,
        Guid siteId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Project is part of the filter, not only the site, so a site identifier from
        // another project cannot return rows. This is the application-side equivalent
        // of the composite project_id foreign keys and row-level security in the schema.
        var cells = _cellRegistrations.Values
            .Where(item => item.ProjectId == projectId && item.SiteId == siteId)
            .OrderBy(item => item.Name, StringComparer.Ordinal)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<CellRegistration>>(cells);
    }

    public ValueTask<DeviceRecord?> FindDeviceAsync(string deviceId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_devices.GetValueOrDefault(deviceId));
    }

    public ValueTask SaveDeviceAsync(DeviceRecord device, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors ux_devices_certificate_thumbprint: one certificate, one device. The
        // in-memory store refuses exactly what PostgreSQL refuses.
        if (device.CertificateThumbprint is { } thumbprint)
        {
            var clash = _devices.Values.FirstOrDefault(item =>
                item.ProjectId == device.ProjectId &&
                StringComparer.Ordinal.Equals(item.CertificateThumbprint, thumbprint) &&
                !StringComparer.Ordinal.Equals(item.DeviceId, device.DeviceId));
            if (clash is not null)
            {
                throw new DomainRuleException(
                    "DEVICE_CERTIFICATE_ALREADY_ENROLLED",
                    "That certificate is already enrolled for another device in this project.");
            }
        }

        _devices[device.DeviceId] = device;
        return ValueTask.CompletedTask;
    }

    public ValueTask<DeviceRecord?> FindDeviceByThumbprintAsync(
        Guid projectId,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_devices.Values.FirstOrDefault(item =>
            item.ProjectId == projectId &&
            StringComparer.Ordinal.Equals(item.CertificateThumbprint, thumbprint)));
    }

    public ValueTask<CalibrationRecord?> FindCalibrationAsync(Guid calibrationId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_calibrations.GetValueOrDefault(calibrationId));
    }

    public ValueTask<IReadOnlyList<CalibrationRecord>> ListCalibrationsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<CalibrationRecord> page =
        [
            .. _calibrations.Values
                .Where(item => item.ProjectId == projectId)
                .OrderByDescending(item => item.CalibratedAt)
                .ThenByDescending(item => item.CalibrationId)
                .Take(Math.Clamp(limit, 1, 500)),
        ];
        return ValueTask.FromResult(page);
    }

    public ValueTask<IReadOnlyList<ScanEventRecord>> ListScanEventsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<ScanEventRecord> page =
        [
            .. _scanEvents.Values
                .Where(item => item.ProjectId == projectId)
                .OrderByDescending(item => item.ScannedAt)
                .ThenByDescending(item => item.ScanEventId)
                .Take(Math.Clamp(limit, 1, 500)),
        ];
        return ValueTask.FromResult(page);
    }

    public ValueTask<IReadOnlyList<WorkOrderRecord>> ListWorkOrdersAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<WorkOrderRecord> page =
        [
            .. _workOrders.Values
                .Where(item => item.ProjectId == projectId)
                .OrderByDescending(item => item.ReleasedAt ?? DateTimeOffset.MaxValue)
                .ThenByDescending(item => item.WorkOrderNumber, StringComparer.Ordinal)
                .Take(Math.Clamp(limit, 1, 500)),
        ];
        return ValueTask.FromResult(page);
    }

    public ValueTask<IReadOnlyList<Experiment>> ListExperimentsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<Experiment> page =
        [
            .. _experiments.Values
                .Where(item => item.ProjectId == projectId)
                .OrderByDescending(item => item.CreatedAt)
                .ThenByDescending(item => item.ExperimentId)
                .Take(Math.Clamp(limit, 1, 500)),
        ];
        return ValueTask.FromResult(page);
    }

    public ValueTask SaveCalibrationAsync(CalibrationRecord calibration, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _calibrations[calibration.CalibrationId] = calibration;
        return ValueTask.CompletedTask;
    }

    public ValueTask<AssetRecord?> FindAssetAsync(Guid assetId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_assets.GetValueOrDefault(assetId));
    }

    public ValueTask SaveAssetAsync(AssetRecord asset, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _assets[asset.AssetId] = asset;
        return ValueTask.CompletedTask;
    }

    public ValueTask<ProductRevisionRecord?> FindRevisionAsync(Guid revisionId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_revisions.GetValueOrDefault(revisionId));
    }

    public ValueTask SaveRevisionAsync(ProductRevisionRecord revision, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors UNIQUE (project_id, product_code, revision_code) on ch1.product_revisions.
        var conflict = _revisions.Values.FirstOrDefault(item =>
            item.RevisionId != revision.RevisionId &&
            item.ProjectId == revision.ProjectId &&
            StringComparer.Ordinal.Equals(item.ProductCode, revision.ProductCode) &&
            StringComparer.Ordinal.Equals(item.RevisionCode, revision.RevisionCode));
        if (conflict is not null)
        {
            throw new DomainRuleException("REVISION_CODE_CONFLICT", "That product revision code already exists.");
        }

        _revisions[revision.RevisionId] = revision;
        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<ProductRevisionRecord>> ListRevisionsAsync(
        Guid projectId,
        string? productCode,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var revisions = _revisions.Values
            .Where(item => item.ProjectId == projectId)
            .Where(item => productCode is null || StringComparer.Ordinal.Equals(item.ProductCode, productCode))
            .OrderBy(item => item.ProductCode, StringComparer.Ordinal)
            .ThenBy(item => item.RevisionCode, StringComparer.Ordinal)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<ProductRevisionRecord>>(revisions);
    }

    public ValueTask<WorkOrderRecord?> FindWorkOrderAsync(Guid workOrderId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_workOrders.GetValueOrDefault(workOrderId));
    }

    public ValueTask<WorkOrderRecord?> FindWorkOrderByNumberAsync(
        Guid projectId,
        string workOrderNumber,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_workOrders.Values.FirstOrDefault(item =>
            item.ProjectId == projectId && StringComparer.Ordinal.Equals(item.WorkOrderNumber, workOrderNumber)));
    }

    public ValueTask SaveWorkOrderAsync(WorkOrderRecord workOrder, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors UNIQUE (project_id, work_order_number) on ch1.work_orders.
        var conflict = _workOrders.Values.FirstOrDefault(item =>
            item.WorkOrderId != workOrder.WorkOrderId &&
            item.ProjectId == workOrder.ProjectId &&
            StringComparer.Ordinal.Equals(item.WorkOrderNumber, workOrder.WorkOrderNumber));
        if (conflict is not null)
        {
            throw new DomainRuleException("WORK_ORDER_NUMBER_CONFLICT", "That work-order number already exists.");
        }

        _workOrders[workOrder.WorkOrderId] = workOrder;
        return ValueTask.CompletedTask;
    }

    public ValueTask<StoredCellState?> FindCellAsync(Guid cellId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_cells.GetValueOrDefault(cellId));
    }

    /// <summary>
    /// The development store keeps the whole snapshot, interlocks included, because here
    /// the dictionary is the only place state exists — there is no controller behind it
    /// and nothing else to restore from. That is a property of a development mode, not a
    /// relaxation of the rule: PostgreSQL persists only the durable half, and a deployment
    /// running on it reads as not permissive until a controller reports.
    /// </summary>
    public ValueTask SaveCellAsync(CellSnapshot cell, CellObservation observation, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _cells[cell.CellId] = new StoredCellState(cell, observation);
        return ValueTask.CompletedTask;
    }

    public ValueTask<CommandTransaction?> FindCommandAsync(Guid commandId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_commands.GetValueOrDefault(commandId));
    }

    public ValueTask<CommandTransaction?> FindCommandByIdempotencyKeyAsync(
        Guid projectId,
        string idempotencyKey,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(
            _idempotency.TryGetValue((projectId, idempotencyKey), out var commandId)
                ? _commands.GetValueOrDefault(commandId)
                : null);
    }

    public ValueTask SaveCommandAsync(
        CommandTransaction command,
        int? expectedVersion,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (expectedVersion is not null &&
            (!_commands.TryGetValue(command.CommandId, out var current) || current.Version != expectedVersion))
        {
            throw new DomainRuleException("CONCURRENCY_CONFLICT", "The command changed since it was read.");
        }

        var key = (command.Intent.ProjectId, command.Intent.IdempotencyKey);
        if (_idempotency.TryGetValue(key, out var existingId) && existingId != command.CommandId)
        {
            throw new DomainRuleException("IDEMPOTENCY_CONFLICT", "The idempotency key is already assigned.");
        }

        _commands[command.CommandId] = command;
        _idempotency[key] = command.CommandId;
        return ValueTask.CompletedTask;
    }

    public ValueTask<PartRecord?> FindPartAsync(Guid partId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_parts.GetValueOrDefault(partId));
    }

    public ValueTask SavePartAsync(PartRecord part, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _parts[part.PartId] = part;
        return ValueTask.CompletedTask;
    }

    public ValueTask<TestRunRecord?> FindTestRunAsync(Guid testRunId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_testRuns.GetValueOrDefault(testRunId));
    }

    public ValueTask SaveTestRunAsync(TestRunRecord testRun, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _testRuns[testRun.TestRunId] = testRun;
        return ValueTask.CompletedTask;
    }

    public ValueTask<NcrRecord?> FindNcrAsync(Guid ncrId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_ncrs.GetValueOrDefault(ncrId));
    }

    public ValueTask SaveNcrAsync(NcrRecord ncr, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _ncrs[ncr.NcrId] = ncr;
        return ValueTask.CompletedTask;
    }

    public ValueTask AppendTelemetryAsync(IReadOnlyList<TelemetrySample> samples, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_telemetryGate)
        {
            _telemetry.AddRange(samples);
            var excess = _telemetry.Count - TelemetryRetainedSamples;
            if (excess > 0)
            {
                _telemetry.RemoveRange(0, excess);
            }
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<TelemetrySample>> QueryTelemetryAsync(
        TelemetryQuery query,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        TelemetrySample[] matched;
        lock (_telemetryGate)
        {
            // Project is part of the filter, mirroring the row-level security policy
            // PostgreSQL applies to ch1.telemetry_samples.
            matched = _telemetry
                .Where(item => item.ProjectId == query.ProjectId)
                .Where(item => query.CellId is null || item.CellId == query.CellId)
                .Where(item => query.DeviceId is null || StringComparer.Ordinal.Equals(item.DeviceId, query.DeviceId))
                .Where(item => query.ChannelIds.Count == 0 || query.ChannelIds.Contains(item.ChannelId, StringComparer.Ordinal))
                .Where(item => item.SampledAt >= query.From && item.SampledAt <= query.To)
                .OrderByDescending(item => item.SampledAt)
                .ThenBy(item => item.SampleId)
                .Take(query.Limit)
                .ToArray();
        }

        return ValueTask.FromResult<IReadOnlyList<TelemetrySample>>(matched);
    }

    public ValueTask<Alarm?> FindAlarmAsync(Guid alarmId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_alarms.GetValueOrDefault(alarmId));
    }

    public ValueTask<Alarm?> FindOutstandingAlarmAsync(
        Guid projectId,
        Guid cellId,
        string sourceId,
        string alarmCode,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var outstanding = _alarms.Values
            .Where(item =>
                item.ProjectId == projectId &&
                item.CellId == cellId &&
                StringComparer.Ordinal.Equals(item.SourceId, sourceId) &&
                StringComparer.Ordinal.Equals(item.AlarmCode, alarmCode) &&
                !item.CauseClear)
            .OrderByDescending(item => item.ActivatedAt)
            .FirstOrDefault();
        return ValueTask.FromResult(outstanding);
    }

    public ValueTask<IReadOnlyList<Alarm>> FindOutstandingAlarmsAsync(
        Guid projectId,
        Guid cellId,
        string sourceId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<Alarm> outstanding = _alarms.Values
            .Where(item =>
                item.ProjectId == projectId &&
                item.CellId == cellId &&
                StringComparer.Ordinal.Equals(item.SourceId, sourceId) &&
                !item.CauseClear)
            .OrderByDescending(item => item.ActivatedAt)
            .ToList();
        return ValueTask.FromResult(outstanding);
    }

    public ValueTask SaveAlarmAsync(Alarm alarm, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _alarms[alarm.AlarmId] = alarm;
        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<Alarm>> ListAlarmsAsync(AlarmQuery query, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var page = _alarms.Values
            .Where(item => item.ProjectId == query.ProjectId)
            .Where(item => query.CellId is null || item.CellId == query.CellId)
            .Where(item => query.States.Count == 0 || query.States.Contains(item.State))
            .Where(item => query.MaximumPriority is null || item.Priority <= query.MaximumPriority)
            .OrderBy(item => item.Priority)
            .ThenByDescending(item => item.ActivatedAt)
            .ThenBy(item => item.AlarmId)
            .Where(item => query.After is null || IsAfterCursor(item, query.After))
            .Take(query.Limit)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<Alarm>>(page);
    }

    /// <summary>
    /// Keyset comparison over the same (priority, activated_at DESC, alarm_id) order the
    /// PostgreSQL store applies, so a page boundary means the same thing in both stores.
    /// </summary>
    private static bool IsAfterCursor(Alarm alarm, AlarmCursor cursor) =>
        alarm.Priority > cursor.Priority ||
        (alarm.Priority == cursor.Priority && alarm.ActivatedAt < cursor.ActivatedAt) ||
        (alarm.Priority == cursor.Priority && alarm.ActivatedAt == cursor.ActivatedAt && alarm.AlarmId.CompareTo(cursor.AlarmId) > 0);

    public ValueTask<Experiment?> FindExperimentAsync(Guid experimentId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_experiments.GetValueOrDefault(experimentId));
    }

    public ValueTask SaveExperimentAsync(
        Experiment experiment,
        long? expectedVersion,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors CHECK (production_authority = false) on ch1.experiments.
        if (experiment.ProductionAuthority)
        {
            throw new DomainRuleException(
                "EXPERIMENT_PRODUCTION_AUTHORITY",
                "An experiment can never carry production authority.");
        }

        lock (_experimentGate)
        {
            if (expectedVersion is not null)
            {
                var existing = _experiments.GetValueOrDefault(experiment.ExperimentId);
                if (existing is null || existing.Version != expectedVersion)
                {
                    throw new DomainRuleException(
                        "CONCURRENCY_CONFLICT",
                        "The experiment changed since it was read.");
                }
            }

            _experiments[experiment.ExperimentId] = experiment;
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask SaveExperimentRevisionAsync(
        ExperimentRevision revision,
        Experiment experiment,
        long expectedExperimentVersion,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (revision.ProductionAuthority)
        {
            throw new DomainRuleException(
                "EXPERIMENT_PRODUCTION_AUTHORITY",
                "An experiment run can never carry production authority.");
        }

        lock (_experimentGate)
        {
            var existing = _experiments.GetValueOrDefault(experiment.ExperimentId);
            if (existing is null || existing.Version != expectedExperimentVersion)
            {
                throw new DomainRuleException(
                    "CONCURRENCY_CONFLICT",
                    "The experiment changed since it was read.");
            }

            // Mirrors UNIQUE (experiment_id, revision_number): two runs cannot claim the
            // same revision number.
            var duplicate = _experimentRevisions.Values.Any(item =>
                item.ExperimentId == revision.ExperimentId && item.RevisionNumber == revision.RevisionNumber);
            if (duplicate)
            {
                throw new DomainRuleException(
                    "EXPERIMENT_REVISION_CONFLICT",
                    "That experiment revision number is already recorded.");
            }

            // Mirrors the append-only trigger: a recorded run is never rewritten.
            if (_experimentRevisions.ContainsKey(revision.ExperimentRevisionId))
            {
                throw new DomainRuleException(
                    "EXPERIMENT_REVISION_IMMUTABLE",
                    "A recorded experiment run cannot be modified.");
            }

            _experimentRevisions[revision.ExperimentRevisionId] = revision;
            _experiments[experiment.ExperimentId] = experiment;
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<ExperimentRevision>> ListExperimentRevisionsAsync(
        Guid projectId,
        Guid experimentId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var revisions = _experimentRevisions.Values
            .Where(item => item.ProjectId == projectId && item.ExperimentId == experimentId)
            .OrderBy(item => item.RevisionNumber)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<ExperimentRevision>>(revisions);
    }

    public ValueTask<ResourceRecord?> FindResourceAsync(Guid resourceId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_resources.GetValueOrDefault(resourceId));
    }

    public ValueTask SaveResourceAsync(ResourceRecord resource, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _resources[resource.ResourceId] = resource;
        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<ResourceRecord>> ListResourcesAsync(
        ResourceQuery query,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var page = _resources.Values
            .Where(item => item.ProjectId == query.ProjectId)
            .Where(item => query.ResourceType is null ||
                StringComparer.Ordinal.Equals(item.ResourceType, query.ResourceType))
            .Where(item => query.AvailabilityState is null || item.AvailabilityState == query.AvailabilityState)
            .OrderBy(item => item.Name, StringComparer.Ordinal)
            .ThenBy(item => item.ResourceId)
            .Where(item => query.After is null || IsAfterResourceCursor(item, query.After))
            .Take(query.Limit)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<ResourceRecord>>(page);
    }

    private static bool IsAfterResourceCursor(ResourceRecord resource, ResourceCursor cursor)
    {
        var byName = StringComparer.Ordinal.Compare(resource.Name, cursor.Name);
        return byName > 0 || (byName == 0 && resource.ResourceId.CompareTo(cursor.ResourceId) > 0);
    }

    public ValueTask<ResourceAllocation?> FindAllocationAsync(Guid allocationId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_allocations.GetValueOrDefault(allocationId));
    }

    public ValueTask<IReadOnlyList<ResourceAllocation>> ListAllocationsAsync(
        Guid projectId,
        IReadOnlyList<Guid> resourceIds,
        DateTimeOffset windowStart,
        DateTimeOffset windowEnd,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var matched = _allocations.Values
            .Where(item => item.ProjectId == projectId && resourceIds.Contains(item.ResourceId))
            .Where(item => item.Status != AllocationStatus.Cancelled)
            .Where(item => item.StartsAt < windowEnd && item.EndsAt > windowStart)
            .OrderBy(item => item.StartsAt)
            .ThenBy(item => item.AllocationId)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<ResourceAllocation>>(matched);
    }

    /// <summary>
    /// Writes the reservation and bumps the resource version, refusing if the resource
    /// moved since the conflict check read it. The gate makes the check-and-write one
    /// step, which is what the PostgreSQL store gets from its transaction.
    /// </summary>
    public ValueTask SaveAllocationAsync(
        ResourceAllocation allocation,
        long expectedResourceVersion,
        long? expectedAllocationVersion,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_allocationGate)
        {
            var resource = _resources.GetValueOrDefault(allocation.ResourceId)
                ?? throw new DomainRuleException("RESOURCE_NOT_FOUND", "The resource does not exist.");
            if (resource.Version != expectedResourceVersion)
            {
                throw new DomainRuleException(
                    "CONCURRENCY_CONFLICT",
                    "The resource changed since it was read.");
            }

            if (expectedAllocationVersion is not null)
            {
                var existing = _allocations.GetValueOrDefault(allocation.AllocationId);
                if (existing is null || existing.Version != expectedAllocationVersion)
                {
                    throw new DomainRuleException(
                        "CONCURRENCY_CONFLICT",
                        "The reservation changed since it was read.");
                }
            }

            _allocations[allocation.AllocationId] = allocation;
            _resources[resource.ResourceId] = resource with { Version = resource.Version + 1 };
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask<ContextThread?> FindContextThreadAsync(Guid threadId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_contextThreads.GetValueOrDefault(threadId));
    }

    public ValueTask SaveContextThreadAsync(ContextThread thread, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors UNIQUE (project_id, object_type, object_id) on ch1.context_threads:
        // one thread per controlled object, whichever store is configured.
        var conflicting = _contextThreads.Values.FirstOrDefault(item =>
            item.ProjectId == thread.ProjectId &&
            item.ObjectType == thread.ObjectType &&
            StringComparer.Ordinal.Equals(item.ObjectId, thread.ObjectId) &&
            item.ThreadId != thread.ThreadId);
        if (conflicting is not null)
        {
            throw new DomainRuleException(
                "CONTEXT_THREAD_CONFLICT",
                "A contextual thread already exists for that controlled object.");
        }

        _contextThreads[thread.ThreadId] = thread;
        return ValueTask.CompletedTask;
    }

    public ValueTask<ContextMessage?> FindContextMessageAsync(Guid messageId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_contextMessages.GetValueOrDefault(messageId));
    }

    public ValueTask SaveContextMessageAsync(ContextMessage message, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors CHECK (control_authority = false) on ch1.context_messages. The
        // in-memory store refuses exactly what PostgreSQL refuses.
        if (message.ControlAuthority)
        {
            throw new DomainRuleException(
                "CONTEXT_MESSAGE_CONTROL_AUTHORITY",
                "A contextual message can never carry control authority.");
        }

        _contextMessages[message.MessageId] = message;
        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<ContextMessage>> ListContextMessagesAsync(
        ContextMessageQuery query,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var page = _contextMessages.Values
            .Where(item => item.ProjectId == query.ProjectId && item.ThreadId == query.ThreadId)
            .OrderBy(item => item.CreatedAt)
            .ThenBy(item => item.MessageId)
            .Where(item => query.After is null ||
                item.CreatedAt > query.After.CreatedAt ||
                (item.CreatedAt == query.After.CreatedAt && item.MessageId.CompareTo(query.After.MessageId) > 0))
            .Take(query.Limit)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<ContextMessage>>(page);
    }

    public ValueTask<IReadOnlyList<MessageAcknowledgement>> ListMessageAcknowledgementsAsync(
        Guid projectId,
        IReadOnlyList<Guid> messageIds,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var receipts = _messageAcks.Values
            .Where(item => item.ProjectId == projectId && messageIds.Contains(item.MessageId))
            .OrderBy(item => item.AcknowledgedAt)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<MessageAcknowledgement>>(receipts);
    }

    public ValueTask SaveMessageAcknowledgementAsync(
        MessageAcknowledgement acknowledgement,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors UNIQUE (message_id, recipient_id): a second receipt from the same
        // recipient must not overwrite who first confirmed, or when.
        var key = (acknowledgement.MessageId, acknowledgement.RecipientId);
        if (!_messageAcks.TryAdd(key, acknowledgement))
        {
            throw new DomainRuleException(
                "CONTEXT_RECEIPT_CONFLICT",
                "That recipient has already recorded receipt of this message.");
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask SaveStepUpGrantAsync(StepUpGrant grant, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _stepUpGrants[grant.GrantId] = grant;
        return ValueTask.CompletedTask;
    }

    public ValueTask<ReportRecord?> FindReportByDeterminismKeyAsync(
        Guid projectId,
        string determinismKey,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_reports.Values.FirstOrDefault(item =>
            item.ProjectId == projectId
            && string.Equals(item.DeterminismKey, determinismKey, StringComparison.Ordinal)));
    }

    public ValueTask SaveReportAsync(ReportRecord report, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors the unique determinism key, so the in-memory mode refuses what
        // PostgreSQL refuses and a defect cannot hide behind the store in use.
        if (_reports.Values.Any(item =>
                item.ReportId != report.ReportId
                && item.ProjectId == report.ProjectId
                && string.Equals(item.DeterminismKey, report.DeterminismKey, StringComparison.Ordinal)))
        {
            throw new DomainRuleException(
                "REPORT_ALREADY_GENERATED",
                "A report for these inputs under this template revision already exists.");
        }

        _reports[report.ReportId] = report;
        return ValueTask.CompletedTask;
    }

    public ValueTask<ScanEventRecord?> FindScanEventByDeliveryAsync(
        Guid projectId,
        string deviceId,
        string identifierValue,
        DateTimeOffset scannedAt,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_scanEvents.Values.FirstOrDefault(item =>
            item.ProjectId == projectId
            && item.DuplicateOf is null
            && string.Equals(item.DeviceId, deviceId, StringComparison.Ordinal)
            && string.Equals(item.IdentifierValue, identifierValue, StringComparison.Ordinal)
            && item.ScannedAt == scannedAt));
    }

    public ValueTask<PartRecord?> FindPartByIdentifierAsync(
        Guid projectId,
        string identifierValue,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_parts.Values.FirstOrDefault(item =>
            item.ProjectId == projectId
            && (string.Equals(item.PermanentIdentityUri, identifierValue, StringComparison.Ordinal)
                || string.Equals(item.SerialNumber, identifierValue, StringComparison.Ordinal))));
    }

    public ValueTask SaveScanEventAsync(ScanEventRecord scanEvent, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _scanEvents[scanEvent.ScanEventId] = scanEvent;
        return ValueTask.CompletedTask;
    }

    public ValueTask<CredentialRecord?> FindCredentialAsync(Guid credentialId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_credentials.GetValueOrDefault(credentialId));
    }

    public ValueTask<CredentialRecord?> FindCredentialByWebAuthnIdAsync(
        Guid projectId,
        byte[] webAuthnCredentialId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_credentials.Values.FirstOrDefault(item =>
            item.ProjectId == projectId
            && item.WebAuthnCredentialId is not null
            && item.WebAuthnCredentialId.AsSpan().SequenceEqual(webAuthnCredentialId)));
    }

    public ValueTask<IReadOnlyList<CredentialRecord>> ListCredentialsAsync(
        Guid projectId,
        string subjectId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        IReadOnlyList<CredentialRecord> found = _credentials.Values
            .Where(item => item.ProjectId == projectId
                && string.Equals(item.SubjectId, subjectId, StringComparison.Ordinal))
            .OrderByDescending(item => item.EnrolledAt)
            .ToList();
        return ValueTask.FromResult(found);
    }

    public ValueTask SaveCredentialAsync(CredentialRecord credential, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Mirrors ux_credentials_webauthn_id. Without it the in-memory mode would accept
        // a duplicate enrolment that PostgreSQL refuses, and the tests that run here
        // would not see the defect - which is exactly how the SaveCommandAsync parameter
        // fault survived.
        if (credential.WebAuthnCredentialId is { Length: > 0 } handle)
        {
            var clash = _credentials.Values.FirstOrDefault(item =>
                item.CredentialId != credential.CredentialId
                && item.ProjectId == credential.ProjectId
                && item.WebAuthnCredentialId is not null
                && item.WebAuthnCredentialId.AsSpan().SequenceEqual(handle));
            if (clash is not null)
            {
                throw new DomainRuleException(
                    "CREDENTIAL_ALREADY_ENROLLED",
                    $"That authenticator is already enrolled to {clash.SubjectId}.");
            }
        }

        _credentials[credential.CredentialId] = credential;
        return ValueTask.CompletedTask;
    }

    public ValueTask<WebAuthnChallenge?> FindWebAuthnChallengeAsync(
        Guid challengeId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_webAuthnChallenges.GetValueOrDefault(challengeId));
    }

    public ValueTask SaveWebAuthnChallengeAsync(WebAuthnChallenge challenge, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _webAuthnChallenges[challenge.ChallengeId] = challenge;
        return ValueTask.CompletedTask;
    }

    /// <summary>
    /// The role assignment history, appended to and never replaced - the same behaviour
    /// migration 0012 gives the table, where the application holds SELECT and INSERT and
    /// nothing else. A dictionary keyed on the identifier would let a repeated identifier
    /// silently overwrite an earlier change, which is exactly what the PostgreSQL path
    /// refuses with ROLE_ASSIGNMENT_ALREADY_RECORDED.
    /// </summary>
    public ValueTask<ControlledDocumentRecord?> FindControlledDocumentAsync(
        Guid documentId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_documents.GetValueOrDefault(documentId));
    }

    public ValueTask SaveControlledDocumentAsync(
        ControlledDocumentRecord document,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(document);
        cancellationToken.ThrowIfCancellationRequested();
        _documents[document.DocumentId] = document;
        return ValueTask.CompletedTask;
    }

    public ValueTask<PublicationPackage?> FindPublicationPackageAsync(
        Guid packageId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_publicationPackages.GetValueOrDefault(packageId));
    }

    public ValueTask SavePublicationPackageAsync(
        PublicationPackage package,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(package);
        cancellationToken.ThrowIfCancellationRequested();
        _publicationPackages[package.PackageId] = package;
        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<PublicationApproval>> ListPublicationApprovalsAsync(
        Guid projectId,
        Guid packageId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_publicationApprovals)
        {
            IReadOnlyList<PublicationApproval> held =
            [
                .. _publicationApprovals
                    .Where(item => item.ProjectId == projectId && item.PackageId == packageId)
                    .OrderBy(item => item.ReviewedAt)
                    .ThenBy(item => item.ApprovalId),
            ];
            return ValueTask.FromResult(held);
        }
    }

    /// <summary>
    /// Appended, never replaced, and refusing a second decision from the same capacity -
    /// which is the UNIQUE (package_id, reviewer_capacity) constraint 0013 declares. The
    /// two stores must refuse the same thing or the in-memory one is a weaker model of the
    /// controlled schema than the tests believe.
    /// </summary>
    public ValueTask SavePublicationApprovalAsync(
        PublicationApproval approval,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(approval);
        cancellationToken.ThrowIfCancellationRequested();
        lock (_publicationApprovals)
        {
            if (_publicationApprovals.Any(item =>
                    item.PackageId == approval.PackageId && item.Capacity == approval.Capacity))
            {
                throw new DomainRuleException(
                    "PUBLICATION_CAPACITY_ALREADY_REVIEWED",
                    "That capacity has already reviewed this package.");
            }

            _publicationApprovals.Add(approval);
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask SaveRoleAssignmentAsync(
        RoleAssignmentRecord assignment,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(assignment);
        cancellationToken.ThrowIfCancellationRequested();
        lock (_roleAssignments)
        {
            if (_roleAssignments.Any(item => item.AssignmentId == assignment.AssignmentId))
            {
                throw new DomainRuleException(
                    "ROLE_ASSIGNMENT_ALREADY_RECORDED",
                    "That role assignment has already been recorded.");
            }

            _roleAssignments.Add(assignment);
        }

        return ValueTask.CompletedTask;
    }

    public ValueTask<IReadOnlyList<RoleAssignmentRecord>> ListRoleAssignmentsAsync(
        Guid projectId,
        string subjectUserId,
        int limit,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_roleAssignments)
        {
            IReadOnlyList<RoleAssignmentRecord> page =
            [
                .. _roleAssignments
                    .Where(item => item.ProjectId == projectId
                        && StringComparer.Ordinal.Equals(item.SubjectUserId, subjectUserId))
                    .OrderByDescending(item => item.AssignedAt)
                    .ThenByDescending(item => item.AssignmentId)
                    .Take(Math.Clamp(limit, 1, 200)),
            ];
            return ValueTask.FromResult(page);
        }
    }

    public ValueTask<StepUpGrant?> FindStepUpGrantAsync(Guid grantId, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_stepUpGrants.GetValueOrDefault(grantId));
    }

    public ValueTask<AuditEvent> AppendAuditAsync(AuditInput input, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_audit.Append(input));
    }

    public ValueTask<IReadOnlyList<AuditEvent>> QueryAuditAsync(
        Guid projectId,
        Guid? correlationId,
        int limit,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var boundedLimit = Math.Clamp(limit, 1, 1_000);
        var events = _audit.Snapshot()
            .Where(item => item.ProjectId == projectId && (correlationId is null || item.CorrelationId == correlationId))
            .TakeLast(boundedLimit)
            .ToArray();
        return ValueTask.FromResult<IReadOnlyList<AuditEvent>>(events);
    }

    public ValueTask<AuditVerification> VerifyAuditAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(_audit.Verify());
    }
}

