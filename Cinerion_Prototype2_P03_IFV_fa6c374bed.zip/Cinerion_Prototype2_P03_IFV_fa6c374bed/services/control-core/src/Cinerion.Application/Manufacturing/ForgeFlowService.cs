// Revision control and work orders. A part gets its identity from the order that authorised
// it.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Manufacturing;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Manufacturing;

/// <summary>
/// Engineering revision control and production orders.
/// </summary>
/// <requirements>CH1-MFG-FR-0001, CH1-MFG-FR-0003, CH1-MFG-FR-0005, CH1-NFR-AUD-0001</requirements>
public sealed class ForgeFlowService(ICinerionStore store, ISystemClock clock) : IDisposable
{
    /// <summary>
    /// Who may read the work-order board. The roles screens.json declares it for, plus the
    /// two that have to see what is in production to do their own work.
    /// </summary>
    public static bool CanReadWorkOrders(ActorContext actor)
    {
        ArgumentNullException.ThrowIfNull(actor);
        return actor.HasRole(CinerionRoles.ProjectManager)
            || actor.HasRole(CinerionRoles.Engineer)
            || actor.HasRole(CinerionRoles.OperationsCoordinator)
            || actor.HasRole(CinerionRoles.Inspector);
    }

    /// <summary>
    /// The work-order board: what has been raised, what has been released, and by whom.
    /// </summary>
    /// <remarks>
    /// An owner-approved read, recorded in traceability/owner-approved-operations.json.
    /// This is recorded conflict 14: the catalogue can raise a work order and release one,
    /// and can read neither back, so the declared board could only ever be a screen
    /// explaining its own emptiness. Release state is REPORTED here and conferred nowhere:
    /// releasing remains POST /api/v1/work-orders/{id}/release with its step-up grant.
    /// </remarks>
    /// <requirements>CH1-MFG-FR-0001, CH1-CYB-FR-0001</requirements>
    public async ValueTask<IReadOnlyList<WorkOrderRecord>> ListWorkOrdersAsync(
        ActorContext actor,
        int limit,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(actor);
        Guard.Against(
            !CanReadWorkOrders(actor),
            "AUTH_WORK_ORDER_BOARD",
            "Reading the work-order board requires a Project Manager, Engineer, Operations " +
            "Coordinator or Inspector.");
        return await store.ListWorkOrdersAsync(actor.ProjectId, limit, cancellationToken)
            .ConfigureAwait(false);
    }

    private readonly SemaphoreSlim _gate = new(1, 1);

    public ValueTask<IReadOnlyList<ProductRevisionRecord>> ListRevisionsAsync(
        string? productCode,
        ActorContext actor,
        CancellationToken cancellationToken) =>
        store.ListRevisionsAsync(actor.ProjectId, productCode, cancellationToken);

    public async ValueTask<ProductRevisionRecord> CreateRevisionAsync(
        string productCode,
        string revisionCode,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var revision = ProductRevisionRecord.CreateDraft(productCode, revisionCode, actor);
            await store.SaveRevisionAsync(revision, cancellationToken).ConfigureAwait(false);
            await AuditAsync(actor, revision.RevisionId.ToString(), "ProductRevisionDrafted", "Allowed", "ENGINEERING_REVISION_CREATED", new { revision.ProductCode, revision.RevisionCode }, cancellationToken).ConfigureAwait(false);
            return revision;
        }
        finally
        {
            _gate.Release();
        }
    }

    public ValueTask<ProductRevisionRecord> SetBomAsync(
        Guid revisionId,
        IReadOnlyList<BomLine> bom,
        long expectedVersion,
        ActorContext actor,
        CancellationToken cancellationToken) =>
        MutateRevisionAsync(
            revisionId,
            actor,
            revision => revision.WithBom(bom, expectedVersion, actor),
            "ProductRevisionBomChanged",
            "BILL_OF_MATERIAL_REPLACED",
            cancellationToken);

    public ValueTask<ProductRevisionRecord> SetRouteAsync(
        Guid revisionId,
        IReadOnlyList<RouteStep> route,
        long expectedVersion,
        ActorContext actor,
        CancellationToken cancellationToken) =>
        MutateRevisionAsync(
            revisionId,
            actor,
            revision => revision.WithRoute(route, expectedVersion, actor),
            "ProductRevisionRouteChanged",
            "ROUTE_REPLACED",
            cancellationToken);

    public ValueTask<ProductRevisionRecord> ReleaseRevisionAsync(
        Guid revisionId,
        long expectedVersion,
        ActorContext actor,
        CancellationToken cancellationToken) =>
        MutateRevisionAsync(
            revisionId,
            actor,
            revision => revision.Release(expectedVersion, actor, clock.UtcNow),
            "ProductRevisionReleased",
            "ENGINEERING_REVISION_RELEASED",
            cancellationToken);

    private async ValueTask<ProductRevisionRecord> MutateRevisionAsync(
        Guid revisionId,
        ActorContext actor,
        Func<ProductRevisionRecord, ProductRevisionRecord> mutate,
        string eventType,
        string reasonCode,
        CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await store.FindRevisionAsync(revisionId, cancellationToken).ConfigureAwait(false);
            // An unknown revision and one in another project read identically.
            Guard.Against(
                current is null || current.ProjectId != actor.ProjectId,
                "REVISION_NOT_FOUND",
                "Revision does not exist or is outside the caller scope.");

            var updated = mutate(current!);
            await store.SaveRevisionAsync(updated, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor,
                updated.RevisionId.ToString(),
                eventType,
                "Allowed",
                reasonCode,
                new { updated.ProductCode, updated.RevisionCode, updated.SourceChecksum, updated.Version, LifecycleState = updated.LifecycleState.ToString() },
                cancellationToken).ConfigureAwait(false);
            return updated;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async ValueTask<WorkOrderRecord> CreateWorkOrderAsync(
        string workOrderNumber,
        Guid revisionId,
        Guid? cellId,
        int quantity,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var revision = await store.FindRevisionAsync(revisionId, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                revision is null || revision.ProjectId != actor.ProjectId,
                "REVISION_NOT_FOUND",
                "Revision does not exist or is outside the caller scope.");

            var workOrder = WorkOrderRecord.Create(workOrderNumber, revision!, cellId, quantity, actor);
            await store.SaveWorkOrderAsync(workOrder, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor,
                workOrder.WorkOrderId.ToString(),
                "WorkOrderRaised",
                "Allowed",
                "RELEASED_REVISION_PINNED",
                new { workOrder.WorkOrderNumber, workOrder.RevisionId, workOrder.Quantity },
                cancellationToken).ConfigureAwait(false);
            return workOrder;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async ValueTask<WorkOrderRecord> ReleaseWorkOrderAsync(
        Guid workOrderId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var workOrder = await store.FindWorkOrderAsync(workOrderId, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                workOrder is null || workOrder.ProjectId != actor.ProjectId,
                "WORK_ORDER_NOT_FOUND",
                "Work order does not exist or is outside the caller scope.");
            var revision = await store.FindRevisionAsync(workOrder!.RevisionId, cancellationToken).ConfigureAwait(false);
            Guard.Against(revision is null, "REVISION_NOT_FOUND", "The pinned revision could not be resolved.");

            var released = workOrder.Release(revision!, actor, clock.UtcNow);
            await store.SaveWorkOrderAsync(released, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor,
                released.WorkOrderId.ToString(),
                "WorkOrderReleased",
                "Allowed",
                "READINESS_AND_STEP_UP_VERIFIED",
                new { released.WorkOrderNumber, released.RevisionId, released.ReleasedBy },
                cancellationToken).ConfigureAwait(false);
            return released;
        }
        finally
        {
            _gate.Release();
        }
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                "ForgeFlow",
                objectId,
                Guid.NewGuid(),
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);

    public void Dispose()
    {
        _gate.Dispose();
        GC.SuppressFinalize(this);
    }
}
