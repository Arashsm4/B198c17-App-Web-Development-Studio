// Builds reports from controlled records. Same records in, same report out, every time.

using System.Globalization;
using System.Text;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Evidence;

/// <summary>
/// Deterministic report generation from controlled records.
/// <para>
/// The renderer here is deliberately plain text over the records the request names. It
/// produces the same bytes for the same inputs under the same template revision, which is
/// what "deterministic" has to mean before anything about a report's checksum is worth
/// stating. A richer renderer belongs behind CH1-COM-IF-0015 with the evidence store; the
/// content is not the controlled property, the determinism and the provenance are.
/// </para>
/// </summary>
/// <requirements>CH1-RPT-FR-0001, CH1-RPT-FR-0002</requirements>
public sealed class ReportForgeService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// Templates this build can render, with the revision each is pinned at. A template
    /// the platform does not hold is refused rather than rendered as an empty document:
    /// a report naming a template that does not exist would be evidence of nothing.
    /// </summary>
    public static readonly IReadOnlyDictionary<string, string> Templates =
        new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["CH1-RPT-TPL-PART-GENEALOGY"] = "1.0.0",
            ["CH1-RPT-TPL-TEST-SUMMARY"] = "1.0.0",
            ["CH1-RPT-TPL-NCR-REGISTER"] = "1.0.0",
        };

    public static bool CanGenerate(ActorContext actor) =>
        actor.HasRole(CinerionRoles.Inspector)
        || actor.HasRole(CinerionRoles.ProjectManager)
        || actor.HasRole(CinerionRoles.Engineer);

    public async ValueTask<(ReportRecord Report, bool AlreadyExisted)> GenerateAsync(
        string templateId,
        string reportType,
        string inputObjectType,
        IReadOnlyList<string> inputObjectIds,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        try
        {
            // api_endpoints.json gives this to a "Quality or Project role".
            Guard.Against(
                !CanGenerate(actor),
                "AUTH_REPORT_GENERATION",
                "Generating a report requires an Inspector, Engineer or Project Manager.");
            Guard.Against(
                !Templates.TryGetValue(templateId ?? string.Empty, out var templateRevision),
                "REPORT_TEMPLATE_UNKNOWN",
                $"'{templateId}' is not a template this build holds. Available templates are " +
                $"{string.Join(", ", Templates.Keys)}.");

            var determinismKey = ReportRecord.ComputeDeterminismKey(
                templateId!, templateRevision!, inputObjectType, inputObjectIds);

            // The same inputs under the same template revision are the same report.
            // Returning the one already generated is what makes the operation
            // deterministic rather than merely repeatable, and it means a retry after a
            // dropped response cannot produce a second document with a different
            // checksum covering the same records.
            var existing = await store
                .FindReportByDeterminismKeyAsync(actor.ProjectId, determinismKey, cancellationToken)
                .ConfigureAwait(false);
            if (existing is not null)
            {
                return (existing, true);
            }

            var rendered = await RenderAsync(
                templateId!, templateRevision!, inputObjectType, inputObjectIds, actor, cancellationToken)
                .ConfigureAwait(false);

            var reportId = Guid.CreateVersion7();
            var report = ReportRecord.Generate(
                reportId, actor.ProjectId, reportType, templateId!, templateRevision!,
                inputObjectType, inputObjectIds, rendered, "text/plain; charset=utf-8",
                $"CH1-RPT-{reportId.ToString()[..8].ToUpperInvariant()}",
                actor.ActorId, clock.UtcNow);

            await store.SaveReportAsync(report, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor, report.ReportId.ToString(), "ReportGenerated", "Allowed",
                "DETERMINISTIC_GENERATION_FROM_PINNED_INPUTS",
                new
                {
                    report.ReportType,
                    report.TemplateId,
                    report.TemplateRevision,
                    report.InputObjectType,
                    InputCount = inputObjectIds.Count,
                    report.DeterminismKey,
                    report.ContentSha256,
                    report.ApprovalState,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return (report, false);
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, templateId ?? "unknown-template", "ReportGenerationRejected", "Rejected",
                error.Code, new { TemplateId = templateId, InputCount = inputObjectIds.Count },
                correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Renders the report body from the records it names.
    /// <para>
    /// Every input is fetched and either reported or named as not found. A record the
    /// caller may not see is absent for the same reason it is absent from every other
    /// read, and the report says so rather than omitting it silently — a report with a
    /// quietly missing row is worse than one that states the gap.
    /// </para>
    /// </summary>
    private async ValueTask<string> RenderAsync(
        string templateId,
        string templateRevision,
        string inputObjectType,
        IReadOnlyList<string> inputObjectIds,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var body = new StringBuilder()
            .Append("CINERION CH1 CONTROLLED REPORT\n")
            .Append("Template: ").Append(templateId).Append(" revision ").Append(templateRevision).Append('\n')
            .Append("Project: ").Append(actor.ProjectId).Append('\n')
            .Append("Input type: ").Append(inputObjectType).Append('\n')
            .Append("Issue status: IFV  Approval state: Unapproved\n")
            .Append("-----\n");

        // Ordered, so the rendered bytes do not depend on the order the caller listed
        // them in - the same property the determinism key relies on.
        foreach (var id in inputObjectIds.OrderBy(item => item, StringComparer.Ordinal))
        {
            body.Append(inputObjectType).Append(' ').Append(id).Append(": ");
            if (!Guid.TryParse(id, out var objectId))
            {
                body.Append("not a controlled identifier\n");
                continue;
            }

            switch (inputObjectType)
            {
                case "Part":
                    var part = await store.FindPartAsync(objectId, cancellationToken).ConfigureAwait(false);
                    body.Append(part is null || part.ProjectId != actor.ProjectId
                        ? "not available to this identity\n"
                        : string.Create(
                            CultureInfo.InvariantCulture,
                            $"serial {part.SerialNumber}, revision {part.RevisionId}, status {part.Status}, " +
                            $"measurements {part.Measurements.Count}, open NCRs {part.OpenNcrIds.Count}\n"));
                    break;

                case "TestRun":
                    var run = await store.FindTestRunAsync(objectId, cancellationToken).ConfigureAwait(false);
                    body.Append(run is null || run.ProjectId != actor.ProjectId
                        ? "not available to this identity\n"
                        : string.Create(
                            CultureInfo.InvariantCulture,
                            $"procedure {run.ProcedureId} revision {run.ProcedureRevision}, status {run.Status}\n"));
                    break;

                case "Ncr":
                    var ncr = await store.FindNcrAsync(objectId, cancellationToken).ConfigureAwait(false);
                    body.Append(ncr is null || ncr.ProjectId != actor.ProjectId
                        ? "not available to this identity\n"
                        : string.Create(
                            CultureInfo.InvariantCulture,
                            $"status {ncr.Status}, part {ncr.PartId}\n"));
                    break;

                default:
                    throw new DomainRuleException(
                        "REPORT_INPUT_TYPE_UNSUPPORTED",
                        $"'{inputObjectType}' is not a record type this template can draw on. " +
                        "Valid types are Part, TestRun and Ncr.");
            }
        }

        return body.Append("-----\nEnd of report.\n").ToString();
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType, actor.ActorId, actor.Kind, actor.ProjectId,
                nameof(ReportRecord), objectId, correlationId, clock.UtcNow,
                decision, reasonCode, payload, clock.TimeQuality),
            cancellationToken);
}
