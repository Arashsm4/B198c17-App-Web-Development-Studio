// QR and RFID scans from the field, tied to the part they name.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Evidence;

/// <summary>
/// QR and RFID part identification delivered from the field.
/// <para>
/// A scan resolves identity and state. It confers no authority: it starts nothing,
/// releases nothing and satisfies no permissive, and every response says so. CH1-CYB-IAM-
/// 0001 restricts RC522-class readers to part identification precisely because a tag UID
/// is cloneable, so the tag class travels with the event and is never treated as proof of
/// a person.
/// </para>
/// </summary>
/// <requirements>CH1-MFG-FR-0002, CH1-TRC-FR-0002, CH1-COM-FR-0007</requirements>
public sealed class FieldCompanionService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// Who may read the scan register. The field roles that produce the evidence and the
    /// inspection roles that review it.
    /// </summary>
    public static bool CanReadScanEvents(ActorContext actor)
    {
        ArgumentNullException.ThrowIfNull(actor);
        return actor.HasRole(CinerionRoles.Engineer)
            || actor.HasRole(CinerionRoles.Inspector)
            || actor.HasRole(CinerionRoles.MaintenanceEngineer)
            || actor.HasRole(CinerionRoles.OperationsCoordinator);
    }

    /// <summary>
    /// The scan register: what enrolled field devices resolved, newest first.
    /// </summary>
    /// <remarks>
    /// An owner-approved read, recorded in traceability/owner-approved-operations.json with
    /// the screen it serves and why the P03 catalogue has nothing for it. It reads and does
    /// nothing else: the authority check and the project scope are the same ones a
    /// controlled read carries, and there is no field here that could confer anything.
    /// </remarks>
    /// <requirements>CH1-MFG-FR-0002, CH1-CYB-FR-0001</requirements>
    public async ValueTask<IReadOnlyList<ScanEventRecord>> ListScanEventsAsync(
        ActorContext actor,
        int limit,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(actor);
        Guard.Against(
            !CanReadScanEvents(actor),
            "AUTH_SCAN_REGISTER",
            "Reading the scan register requires an Engineer, Inspector, Maintenance Engineer " +
            "or Operations Coordinator.");
        return await store.ListScanEventsAsync(actor.ProjectId, limit, cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<(ScanEventRecord Event, PartRecord? Part)> RecordScanAsync(
        string deviceId,
        string stationId,
        ScanIdentifierKind identifierKind,
        string identifierValue,
        DateTimeOffset scannedAt,
        string presentedSignature,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        try
        {
            // The device is the bound identity api_endpoints.json names. Trust is checked
            // the same way telemetry ingestion checks it, so a revoked device cannot
            // deliver scans any more than it can deliver readings.
            var device = await store.FindDeviceAsync(deviceId, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                device is null || device.ProjectId != actor.ProjectId,
                "SCAN_DEVICE_NOT_FOUND",
                "The scanning device does not exist or is outside the caller scope.");
            Guard.Against(
                !device!.IsTrusted,
                "SCAN_DEVICE_NOT_TRUSTED",
                $"The device is {device.TrustState} and its scans are not accepted.");

            // The signature is recomputed from the device's enrolled session material and
            // compared, never taken as presented. Without a session key the platform
            // refuses rather than accepting an unsigned scan - api_endpoints.json makes a
            // signed session the control on this operation.
            var sessionKey = device.CertificateThumbprint;
            Guard.Against(
                string.IsNullOrWhiteSpace(sessionKey),
                "SCAN_DEVICE_SESSION_NOT_ESTABLISHED",
                "The device has no enrolled certificate, so a scan session cannot be verified. " +
                "Enrol the device before it delivers scans.");

            var expected = ScanEventRecord.ComputeSessionSignature(
                deviceId, stationId, identifierValue, scannedAt,
                Convert.FromHexString(sessionKey!));
            Guard.Against(
                !CryptographicEquals(expected, presentedSignature),
                "SCAN_SESSION_SIGNATURE_INVALID",
                "The scan signature did not verify against the device's session. The event is " +
                "refused rather than recorded as if the device had produced it.");

            // Duplicate handling: a re-delivery is recorded as pointing at the first
            // event, not dropped, so a retry is visible and a gap in the sequence is never
            // mistaken for a missed scan.
            var firstDelivery = await store
                .FindScanEventByDeliveryAsync(actor.ProjectId, deviceId, identifierValue, scannedAt, cancellationToken)
                .ConfigureAwait(false);

            var part = firstDelivery is null
                ? await store
                    .FindPartByIdentifierAsync(actor.ProjectId, identifierValue, cancellationToken)
                    .ConfigureAwait(false)
                : null;

            var scanEvent = ScanEventRecord.Record(
                Guid.CreateVersion7(), actor.ProjectId, part?.PartId,
                identifierKind, identifierValue, stationId, deviceId, actor.ActorId,
                scannedAt, expected, firstDelivery?.ScanEventId, clock.UtcNow);

            await store.SaveScanEventAsync(scanEvent, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor, scanEvent.ScanEventId.ToString(), "PartScanRecorded", "Allowed",
                scanEvent.Resolution switch
                {
                    ScanResolution.Duplicate => "REDELIVERED_SCAN_LINKED_TO_FIRST",
                    ScanResolution.UnknownIdentifier => "IDENTIFIER_NOT_KNOWN_TO_THIS_PROJECT",
                    _ => "PART_IDENTITY_RESOLVED",
                },
                new
                {
                    scanEvent.DeviceId,
                    scanEvent.StationId,
                    IdentifierKind = identifierKind.ToString(),
                    Resolution = scanEvent.Resolution.ToString(),
                    scanEvent.PartId,
                    scanEvent.ScannedAt,
                    scanEvent.ReceivedAt,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return (scanEvent, part);
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, identifierValue, "PartScanRejected", "Rejected", error.Code,
                new { DeviceId = deviceId, StationId = stationId },
                correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Fixed-time comparison of two hex digests. A short-circuiting comparison would leak,
    /// through timing, how much of a forged signature was correct.
    /// </summary>
    private static bool CryptographicEquals(string expected, string presented) =>
        expected.Length == presented.Length
        && System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(
            System.Text.Encoding.ASCII.GetBytes(expected),
            System.Text.Encoding.ASCII.GetBytes(presented));

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType, actor.ActorId, actor.Kind, actor.ProjectId,
                nameof(ScanEventRecord), objectId, correlationId, clock.UtcNow,
                decision, reasonCode, payload, clock.TimeQuality),
            cancellationToken);
}
