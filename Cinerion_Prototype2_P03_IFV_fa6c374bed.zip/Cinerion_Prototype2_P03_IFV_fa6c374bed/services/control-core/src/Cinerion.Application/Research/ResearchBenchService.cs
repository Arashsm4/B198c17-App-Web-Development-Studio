// R&D experiments and where they came from. Sandbox rules apply: nothing here reaches
// production.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Research;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Research;

/// <summary>
/// Isolated R&amp;D experiments, their run provenance, and outbound promotion requests.
/// <para>
/// The isolation is structural. This service can reach experiments and their revisions
/// and nothing else: it holds no reference to a cell, a command, an interlock, a work
/// order or a released revision, so there is no path through it by which an experiment
/// could command equipment or enter the controlled implementation. CH1-RND-FR-0001
/// requires an R&amp;D workspace without production authority and CH1-CYB-ACP-0001 states
/// that ResearchBench roles cannot reach production routes unless an approved promotion
/// and bench-mode transition exist; neither exists, and requesting promotion creates
/// neither.
/// </para>
/// <para>
/// ResearchBench records runs; it does not perform them. The computation happens in the
/// R&amp;D engineer's own simulator and is recorded here with the provenance
/// CH1-RND-FR-0002 requires. Saying so plainly is the difference between a provenance
/// record and a claim that this service executed something.
/// </para>
/// </summary>
/// <requirements>CH1-RND-FR-0001, CH1-RND-FR-0002, CH1-RND-FR-0003</requirements>
public sealed class ResearchBenchService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// access.json gives "Create R&amp;D experiment" to the R&amp;D Engineer. Defining and
    /// running an experiment is their authority alone; an Engineer holds production
    /// authorities and gains no bench authority from them.
    /// </summary>
    public static bool CanDefineExperiments(ActorContext actor) => actor.HasRole(CinerionRoles.RDEngineer);

    /// <summary>
    /// api_endpoints.json gives promotion to "R&amp;D Engineer or Engineer". access.json
    /// adds that the Engineer proposes and a Project Manager or Configuration Manager
    /// approves — the approval is a separate act in configuration control, so this is the
    /// proposing authority only.
    /// </summary>
    public static bool CanProposePromotion(ActorContext actor) =>
        actor.HasRole(CinerionRoles.RDEngineer) || actor.HasRole(CinerionRoles.Engineer);

    /// <summary>
    /// Roles that may read an experiment. Kept aligned with the operational read set,
    /// with the R&amp;D Engineer added because the workspace is theirs.
    /// </summary>
    public static bool CanReadExperiments(ActorContext actor) =>
        actor.HasRole(CinerionRoles.RDEngineer) ||
        actor.HasRole(CinerionRoles.Engineer) ||
        actor.HasRole(CinerionRoles.Auditor) ||
        actor.HasRole(CinerionRoles.ProjectManager) ||
        actor.HasRole(CinerionRoles.ConfigurationManager);

    /// <summary>
    /// The R&D workbench: every experiment in this project, newest first.
    /// </summary>
    /// <remarks>
    /// An owner-approved read, recorded in traceability/owner-approved-operations.json with
    /// the screen it serves and why the P03 catalogue has nothing for it. It reads and does
    /// nothing else: the authority check and the project scope are the same ones a
    /// controlled read carries, and there is no field here that could confer anything.
    /// </remarks>
    /// <para>
    /// Row-level security is the isolation, exactly as for every other read.
    /// CH1-RND-FR-0001's separation is a property of what an experiment may DO - it holds no
    /// production authority until an explicit authorised transition - not of whether the
    /// project's own people may see that it exists.
    /// </para>
    /// <requirements>CH1-RND-FR-0001, CH1-CYB-FR-0001</requirements>
    public async ValueTask<IReadOnlyList<Experiment>> ListExperimentsAsync(
        ActorContext actor,
        int limit,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(actor);
        Guard.Against(
            !CanReadExperiments(actor),
            "AUTH_EXPERIMENT_READ",
            "Reading experiments requires an R&D Engineer, Engineer, Auditor, Project Manager " +
            "or Configuration Manager.");
        return await store.ListExperimentsAsync(actor.ProjectId, limit, cancellationToken)
            .ConfigureAwait(false);
    }

    /// <summary>
    /// One experiment with its revisions, for the promotion review.
    /// </summary>
    /// <remarks>
    /// The promotion fields travel on the experiment itself - the change record, the impact
    /// analysis and the verification - which is how the promotion request was modelled when
    /// the register turned out to have no entity for it (conflict 8). This read is what lets
    /// a reviewer see all three before deciding, rather than after.
    /// </remarks>
    /// <requirements>CH1-RND-FR-0002, CH1-RND-FR-0003, CH1-CYB-FR-0001</requirements>
    public async ValueTask<(Experiment Experiment, IReadOnlyList<ExperimentRevision> Revisions)?>
        ReadExperimentAsync(
            Guid experimentId,
            ActorContext actor,
            CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(actor);
        Guard.Against(
            !CanReadExperiments(actor),
            "AUTH_EXPERIMENT_READ",
            "Reading experiments requires an R&D Engineer, Engineer, Auditor, Project Manager " +
            "or Configuration Manager.");

        var experiment = await store.FindExperimentAsync(experimentId, cancellationToken)
            .ConfigureAwait(false);

        // An experiment in another project and one that does not exist are the same answer,
        // for the same reason every other read gives one answer.
        if (experiment is null || experiment.ProjectId != actor.ProjectId)
        {
            return null;
        }

        var revisions = await store
            .ListExperimentRevisionsAsync(actor.ProjectId, experimentId, cancellationToken)
            .ConfigureAwait(false);
        return (experiment, revisions);
    }

    /// <summary>
    /// Defines an experiment. Always in the simulator: the controlled bench transition
    /// is a separate authorised act with no operation behind it.
    /// </summary>
    /// <requirements>CH1-RND-FR-0001</requirements>
    public async ValueTask<Experiment> DefineAsync(
        string objective,
        ExperimentEnvironment requestedEnvironment,
        ActorContext owner,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanDefineExperiments(owner),
            "AUTH_EXPERIMENT_DEFINITION",
            "Defining an experiment requires the R&D Engineer role.");

        var experiment = Experiment.Define(Guid.NewGuid(), requestedEnvironment, objective, owner, clock.UtcNow);
        await store.SaveExperimentAsync(experiment, null, cancellationToken).ConfigureAwait(false);

        await AuditAsync(
            owner,
            "ExperimentDefined",
            "Allowed",
            "ISOLATED_SIMULATOR_WORKSPACE_NO_PRODUCTION_AUTHORITY",
            nameof(Experiment),
            experiment.ExperimentId,
            new
            {
                experiment.ExperimentId,
                experiment.OwnerId,
                Environment = experiment.Environment.ToString(),
                experiment.ProductionAuthority,
                Status = experiment.Status.ToString(),
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);
        return experiment;
    }

    /// <summary>
    /// Records a bounded run with the provenance needed to reproduce it.
    /// </summary>
    /// <requirements>CH1-RND-FR-0002, CH1-VVT-TC-0111</requirements>
    public async ValueTask<(Experiment Experiment, ExperimentRevision Revision)> RecordRunAsync(
        Guid experimentId,
        ExperimentRunInput input,
        ActorContext requester,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanDefineExperiments(requester),
            "AUTH_EXPERIMENT_RUN",
            "Recording an experiment run requires the R&D Engineer role.");

        var experiment = await RequireExperimentAsync(experimentId, requester, cancellationToken).ConfigureAwait(false);
        var existing = await store.ListExperimentRevisionsAsync(
            requester.ProjectId, experimentId, cancellationToken).ConfigureAwait(false);

        var revision = ExperimentRevision.Capture(
            Guid.NewGuid(), experiment, existing.Count + 1, input, requester, clock.UtcNow);
        var advanced = experiment.WithRunRecorded();
        await store.SaveExperimentRevisionAsync(revision, advanced, experiment.Version, cancellationToken)
            .ConfigureAwait(false);

        await AuditAsync(
            requester,
            "ExperimentRunRecorded",
            "Allowed",
            "SIMULATOR_RUN_RECORDED_WITHOUT_PRODUCTION_AUTHORITY",
            nameof(ExperimentRevision),
            revision.ExperimentRevisionId,
            new
            {
                revision.ExperimentRevisionId,
                revision.ExperimentId,
                revision.RevisionNumber,
                Environment = revision.Environment.ToString(),
                revision.ExecutedBy,
                revision.ConfigurationSha256,
                revision.InputSha256,
                revision.ResultSha256,
                revision.ProductionAuthority,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);
        return (advanced, revision);
    }

    /// <summary>
    /// Emits an outbound promotion request to configuration control.
    /// <para>
    /// This is a request, not an approval, and CH1-COM-IF-0021 describes it as outbound
    /// only. The experiment's environment and production authority are unchanged by it;
    /// what changes is that a change record, an impact assessment and a verification
    /// reference are now attached to it and permanently audited.
    /// </para>
    /// </summary>
    /// <requirements>CH1-RND-FR-0003, CH1-VVT-TC-0112</requirements>
    public async ValueTask<Experiment> RequestPromotionAsync(
        Guid experimentId,
        string changeRecord,
        string impactAnalysis,
        string verification,
        ActorContext proposer,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanProposePromotion(proposer),
            "AUTH_EXPERIMENT_PROMOTION",
            "Proposing a promotion requires the R&D Engineer or Engineer role.");

        var experiment = await RequireExperimentAsync(experimentId, proposer, cancellationToken).ConfigureAwait(false);
        var requested = experiment.RequestPromotion(
            proposer, changeRecord, impactAnalysis, verification, clock.UtcNow);
        await store.SaveExperimentAsync(requested, experiment.Version, cancellationToken).ConfigureAwait(false);

        await AuditAsync(
            proposer,
            "ExperimentPromotionRequested",
            // The decision word is "Requested", never "Approved". The approving authority
            // is a Project Manager or Configuration Manager acting in configuration
            // control, and an audit trail that said "Allowed" here would misdescribe what
            // happened.
            "Requested",
            "OUTBOUND_REQUEST_ONLY_NO_PRODUCTION_AUTHORITY_GRANTED",
            nameof(Experiment),
            requested.ExperimentId,
            new
            {
                requested.ExperimentId,
                requested.PromotionChangeRecord,
                requested.PromotionImpactAnalysis,
                requested.PromotionVerification,
                requested.PromotionRequestedBy,
                Environment = requested.Environment.ToString(),
                requested.ProductionAuthority,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);
        return requested;
    }

    public async ValueTask<IReadOnlyList<ExperimentRevision>> ListRunsAsync(
        Guid experimentId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await RequireExperimentAsync(experimentId, actor, cancellationToken).ConfigureAwait(false);
        return await store.ListExperimentRevisionsAsync(actor.ProjectId, experimentId, cancellationToken)
            .ConfigureAwait(false);
    }

    /// <summary>
    /// An experiment in another project reads exactly as one that does not exist, so a
    /// caller cannot probe for R&amp;D work outside their scope.
    /// </summary>
    public async ValueTask<Experiment> RequireExperimentAsync(
        Guid experimentId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var experiment = await store.FindExperimentAsync(experimentId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            experiment is null || experiment.ProjectId != actor.ProjectId,
            "EXPERIMENT_NOT_FOUND",
            "The experiment does not exist or is outside the caller scope.");
        return experiment!;
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string eventType,
        string decision,
        string reasonCode,
        string objectType,
        Guid objectId,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                objectType,
                objectId.ToString(),
                correlationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
