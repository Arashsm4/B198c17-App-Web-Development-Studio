// The command lifecycle: prepare, confirm, commit, audit. Every step checked, every step
// written down.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Commands;

public sealed class CommandService(
    ICinerionStore store,
    ISystemClock clock,
    CommandRuntimeOptions options,
    Cinerion.Application.Edge.CellStateResolver cells) : IDisposable
{
    private readonly SemaphoreSlim _transactionGate = new(1, 1);

    public async ValueTask<CommandTransaction> PrepareAsync(
        PrepareIntent intent,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var existing = await store.FindCommandByIdempotencyKeyAsync(
                intent.ProjectId,
                intent.IdempotencyKey,
                cancellationToken).ConfigureAwait(false);
            if (existing is not null)
            {
                Guard.Against(
                    !StringComparer.Ordinal.Equals(
                        CanonicalJson.Sha256Hex(existing.Intent),
                        CanonicalJson.Sha256Hex(intent)),
                    "IDEMPOTENCY_CONFLICT",
                    "The idempotency key was already used for different command content.");
                return existing;
            }

            var cell = await RequireCellAsync(intent.CellId, cancellationToken).ConfigureAwait(false);
            var command = CommandTransaction.Prepare(intent, actor, cell, clock.UtcNow);
            await store.SaveCommandAsync(command, null, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                command,
                actor,
                "CommandPrepared",
                "Allowed",
                "POLICY_AND_PRELIMINARY_PERMISSIVES_VALID",
                new { command.Intent.CommandType, command.Intent.ExpectedStateHash },
                cancellationToken).ConfigureAwait(false);
            return command;
        }
        catch (DomainRuleException error)
        {
            await store.AppendAuditAsync(
                new AuditInput(
                    "CommandPrepareRejected",
                    actor.ActorId,
                    actor.Kind,
                    intent.ProjectId,
                    "CommandIntent",
                    CanonicalJson.Sha256Hex(new { intent.IdempotencyKey }),
                    Guid.NewGuid(),
                    clock.UtcNow,
                    "Rejected",
                    error.Code,
                    new
                    {
                        Error = error.Code,
                        intent.CommandType,
                        intent.CellId,
                        intent.WorkOrderId,
                        intent.PartId,
                        intent.ConfigurationRevision,
                    },
                    clock.TimeQuality),
                cancellationToken).ConfigureAwait(false);
            throw;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    public async ValueTask<CommandTransaction> RecordCredentialProofAsync(
        Guid commandId,
        CredentialProof proof,
        ActorContext controller,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await RequireCommandAsync(commandId, cancellationToken).ConfigureAwait(false);
            var updated = current.RecordCredentialProof(
                proof,
                controller,
                clock.UtcNow,
                options.Profile == CommandRuntimeProfile.Simulation);
            await store.SaveCommandAsync(updated, current.Version, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                updated,
                controller,
                "CredentialProofAccepted",
                "Allowed",
                // The audit reason states which of the two actually happened, exactly as
                // the local-commit audit below distinguishes a physical edge from a marked
                // simulator one. Recording a stand-in's assertion as
                // CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED would put a claim that a person
                // was at the cell into the controlled evidence chain.
                proof.AuthenticatorClass == AuthenticatorClass.SimulatedPresence
                    ? "MARKED_SIMULATED_PRESENCE_NO_PERSON_AND_NO_CREDENTIAL_PRESENT"
                    : "CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED",
                new { proof.ProofId, proof.CredentialId, proof.UserId, proof.ExpiresAt, AuthenticatorClass = proof.AuthenticatorClass.ToString() },
                cancellationToken).ConfigureAwait(false);
            return updated;
        }
        catch (DomainRuleException error)
        {
            await AuditRejectedAsync(commandId, controller, "CredentialProofRejected", error, cancellationToken).ConfigureAwait(false);
            throw;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    public async ValueTask<CommandTransaction> LocalCommitAsync(
        Guid commandId,
        LocalButtonObservation observation,
        ActorContext controller,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await RequireCommandAsync(commandId, cancellationToken).ConfigureAwait(false);
            var cell = await RequireCellAsync(current.Intent.CellId, cancellationToken).ConfigureAwait(false);
            var updated = current.LocalCommit(
                observation,
                controller,
                cell,
                clock.UtcNow,
                options.Profile == CommandRuntimeProfile.Simulation);
            await store.SaveCommandAsync(updated, current.Version, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                updated,
                controller,
                "LocalCommitAccepted",
                "Allowed",
                observation.Source == ButtonEventSource.PhysicalInput
                    ? "PHYSICAL_EDGE_AND_FINAL_PERMISSIVES_VALID"
                    : "MARKED_SIMULATOR_EDGE_AND_FINAL_PERMISSIVES_VALID",
                new { observation.ObservedAt, observation.ControllerBootId, StateHash = cell.StateHash() },
                cancellationToken).ConfigureAwait(false);
            return updated;
        }
        catch (DomainRuleException error)
        {
            await AuditRejectedAsync(commandId, controller, "LocalCommitRejected", error, cancellationToken).ConfigureAwait(false);
            throw;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    public async ValueTask<CommandTransaction> CancelAsync(
        Guid commandId,
        string reason,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await RequireCommandAsync(commandId, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                !StringComparer.Ordinal.Equals(current.RequesterId, actor.ActorId) && !actor.HasRole(CinerionRoles.Engineer),
                "AUTH_COMMAND_CANCEL_FORBIDDEN",
                "Only the requester or an authorised Engineer may cancel this command.");

            // api_endpoints.json makes "idempotent cancel" the control on this operation,
            // and it is a safety property rather than a convenience: a client whose first
            // request timed out must be able to retry and learn that the command is
            // cancelled, instead of receiving an error it could read as "still armed".
            // The repeat has no second effect - no version bump and no second audit
            // event - and the response carries the reason that was actually recorded, so
            // a later caller supplying a different reason is told the original rather
            // than silently overwriting it.
            if (current.State == CommandState.Cancelled)
            {
                return current;
            }

            var updated = current.Cancel(reason);
            await store.SaveCommandAsync(updated, current.Version, cancellationToken).ConfigureAwait(false);
            await AuditAsync(updated, actor, "CommandCancelled", "Allowed", "AUTHORISED_CANCELLATION", new { reason }, cancellationToken).ConfigureAwait(false);
            return updated;
        }
        catch (DomainRuleException error)
        {
            await AuditRejectedAsync(commandId, actor, "CommandCancellationRejected", error, cancellationToken).ConfigureAwait(false);
            throw;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    public ValueTask<CommandTransaction?> FindAsync(Guid commandId, CancellationToken cancellationToken) =>
        store.FindCommandAsync(commandId, cancellationToken);

    /// <summary>
    /// The command, the controller's answers to it, and the immutable audit links that
    /// evidence both.
    /// <para>
    /// This is step 7 of the controlled PREPARE / LOCAL COMMIT sequence — "correlate
    /// telemetry, result and audit evidence" — and the last message of that sequence,
    /// "visible execution outcome", is what it returns. api_endpoints.json controls
    /// <c>GET /api/v1/commands/{commandId}</c> as "Read command lifecycle AND controller
    /// acknowledgements", with "object-level authorisation and immutable audit links";
    /// the read carried the lifecycle alone, which is the domain's decision and not the
    /// equipment's answer (defect 77).
    /// </para>
    /// <para>
    /// Nothing is re-derived here. An acknowledgement is an audit row that
    /// <see cref="Cinerion.Application.Edge.EdgeIngressService"/> wrote under this
    /// command's own correlation identity, and it is returned as what it is — evidence
    /// about delivery, carrying its own hash — never as command state. The command's
    /// state still advances only on a credential proof and a physical button edge.
    /// </para>
    /// </summary>
    /// <requirements>CH1-CMD-FR-0006, CH1-TRC-FR-0002, CH1-CYB-FR-0006</requirements>
    public async ValueTask<CommandOutcome?> FindOutcomeAsync(
        Guid commandId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var command = await store.FindCommandAsync(commandId, cancellationToken).ConfigureAwait(false);
        if (command is null || command.Intent.ProjectId != actor.ProjectId)
        {
            return null;
        }

        // Correlated, not searched. Every event either side of this transaction carries
        // the command's CorrelationId, so the join is the identity rather than a scan for
        // rows that mention the command id somewhere.
        var events = await store.QueryAuditAsync(
            command.Intent.ProjectId,
            command.CorrelationId,
            CorrelatedEvidenceLimit,
            cancellationToken).ConfigureAwait(false);

        var links = events
            .Select(item => new AuditLink(
                item.EventId,
                item.Sequence,
                item.EventType,
                item.ActorId,
                item.ActorKind.ToString(),
                item.Decision,
                item.ReasonCode,
                item.OccurredAt,
                item.TimeQuality,
                item.PayloadHash,
                item.EventHash))
            .ToArray();

        var acknowledgements = links
            .Where(link => StringComparer.Ordinal.Equals(link.EventType, ControllerAcknowledgementEventType))
            .Select(link => new ControllerAcknowledgement(
                link.EventId,
                link.ActorId,
                StringComparer.Ordinal.Equals(link.Decision, "Acknowledged"),
                link.Decision,
                link.OccurredAt,
                link.TimeQuality,
                link.EventHash))
            .ToArray();

        return new CommandOutcome(command, acknowledgements, links);
    }

    /// <summary>
    /// The event type <see cref="Cinerion.Application.Edge.EdgeIngressService"/> writes
    /// for a controller's answer. Named once, because a typo here would silently return
    /// an empty acknowledgement list rather than fail.
    /// </summary>
    public const string ControllerAcknowledgementEventType = "ControllerAcknowledgementRecorded";

    /// <summary>
    /// A ceiling on correlated evidence, so one command's read cannot become an
    /// unbounded scan. A transaction that produced more rows than this has a reporting
    /// problem of its own, and the audit endpoint is where an investigator goes for the
    /// full chain.
    /// </summary>
    private const int CorrelatedEvidenceLimit = 200;

    private async ValueTask<CommandTransaction> RequireCommandAsync(Guid commandId, CancellationToken cancellationToken) =>
        await store.FindCommandAsync(commandId, cancellationToken).ConfigureAwait(false)
        ?? throw new DomainRuleException("COMMAND_NOT_FOUND", "Command does not exist or is outside the caller scope.");

    /// <summary>
    /// The cell as the platform can currently describe it — the stored record overlaid by
    /// the controller's report while one is current, through the same resolver
    /// <c>GET /api/v1/cells/{cellId}/state</c> uses.
    /// <para>
    /// It has to be the same resolver. A preparation is refused unless its expected-state
    /// hash equals the cell's own, and the client obtains that hash from the read; two
    /// assemblies of the same cell would refuse every preparation as stale for a reason
    /// nobody could see.
    /// </para>
    /// </summary>
    private async ValueTask<CellSnapshot> RequireCellAsync(Guid cellId, CancellationToken cancellationToken) =>
        (await cells.ResolveAsync(cellId, cancellationToken).ConfigureAwait(false))?.Snapshot
        ?? throw new DomainRuleException("CELL_NOT_FOUND", "Cell does not exist or is outside the caller scope.");

    private ValueTask<AuditEvent> AuditAsync(
        CommandTransaction command,
        ActorContext actor,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                command.Intent.ProjectId,
                nameof(CommandTransaction),
                command.CommandId.ToString(),
                command.CorrelationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);

    private async ValueTask AuditRejectedAsync(
        Guid commandId,
        ActorContext actor,
        string eventType,
        DomainRuleException error,
        CancellationToken cancellationToken)
    {
        var command = await store.FindCommandAsync(commandId, cancellationToken).ConfigureAwait(false);
        if (command is null)
        {
            await store.AppendAuditAsync(
                new AuditInput(
                    eventType,
                    actor.ActorId,
                    actor.Kind,
                    actor.ProjectId,
                    nameof(CommandTransaction),
                    commandId.ToString(),
                    Guid.NewGuid(),
                    clock.UtcNow,
                    "Rejected",
                    error.Code,
                    new { Error = error.Code },
                    clock.TimeQuality),
                cancellationToken).ConfigureAwait(false);
            return;
        }

        await AuditAsync(
            command,
            actor,
            eventType,
            "Rejected",
            error.Code,
            new { Error = error.Code },
            cancellationToken).ConfigureAwait(false);
    }

    public void Dispose()
    {
        _transactionGate.Dispose();
        GC.SuppressFinalize(this);
    }
}

/// <summary>
/// A controller's answer to a prepared command, as the audit chain recorded it.
/// <para>
/// <see cref="Accepted"/> restates <see cref="Decision"/> as a boolean for a caller that
/// only needs the fact. Neither is command state: CH1-COM-PRO-0001 is explicit that "a
/// QoS acknowledgement is never treated as physical execution", and the same holds for a
/// controller's own answer.
/// </para>
/// </summary>
public sealed record ControllerAcknowledgement(
    Guid EventId,
    string GatewayIdentity,
    bool Accepted,
    string Decision,
    DateTimeOffset RecordedAt,
    string TimeQuality,
    string EventHash);

/// <summary>
/// One immutable link into the audit chain: what it was, who caused it, what was decided
/// and the hash that makes altering it detectable.
/// <para>
/// The payload itself is not returned, only <see cref="PayloadHash"/>. A command read is
/// project-scoped and object-scoped; the audit endpoint is where a reader with audit
/// authority goes for content, and duplicating it here would widen a read authority both
/// controlled documents agree on.
/// </para>
/// </summary>
public sealed record AuditLink(
    Guid EventId,
    long Sequence,
    string EventType,
    string ActorId,
    string ActorKind,
    string Decision,
    string ReasonCode,
    DateTimeOffset OccurredAt,
    string TimeQuality,
    string PayloadHash,
    string EventHash);

/// <summary>The command, what the equipment answered, and the evidence for both.</summary>
public sealed record CommandOutcome(
    CommandTransaction Command,
    IReadOnlyList<ControllerAcknowledgement> Acknowledgements,
    IReadOnlyList<AuditLink> AuditLinks);

public enum CommandRuntimeProfile
{
    Simulation,
    PrototypeElv,
    Production,
}

public sealed record CommandRuntimeOptions(CommandRuntimeProfile Profile);
