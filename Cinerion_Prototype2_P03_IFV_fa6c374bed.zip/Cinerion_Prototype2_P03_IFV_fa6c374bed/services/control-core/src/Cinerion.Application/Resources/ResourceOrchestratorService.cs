// Capacity, reservations and conflicts. Booking a machine never switches it on.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Resources;

/// <summary>One resource with its reservations and conflicts over the queried window.</summary>
public sealed record ResourceAvailability(
    ResourceRecord Resource,
    IReadOnlyList<ResourceAllocation> Reservations,
    decimal CommittedPeak,
    DateTimeOffset PeakAt,
    IReadOnlyList<CapacityConflict> Conflicts);

/// <summary>
/// Resource capacity, reservation and conflict state.
/// <para>
/// A reservation holds capacity; it starts nothing. CH1-MGT-FR-0002 requires any
/// management action that can affect physical behaviour to go through CommandGuard,
/// local permissives and local confirmation — so this service creates no command,
/// touches no cell and reads no interlock, and reserving a coating station does not
/// energise, arm or prepare it.
/// </para>
/// </summary>
/// <requirements>CH1-MGT-FR-0002, CH1-MGT-FR-0003, CH1-MGT-FR-0004</requirements>
public sealed class ResourceOrchestratorService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// Roles that may read the resource view, from the "View dashboards" row of
    /// access.json. Matches the operational read set used for telemetry and alarms.
    /// </summary>
    private static readonly string[] DashboardReaderRoles =
    [
        CinerionRoles.Viewer,
        CinerionRoles.Auditor,
        CinerionRoles.Engineer,
        CinerionRoles.Inspector,
        CinerionRoles.MaintenanceEngineer,
        CinerionRoles.ProjectManager,
        CinerionRoles.OperationsCoordinator,
        CinerionRoles.SystemAdministrator,
        CinerionRoles.CybersecurityAdministrator,
    ];

    public static bool CanReadResources(ActorContext actor) => DashboardReaderRoles.Any(actor.HasRole);

    /// <summary>
    /// Who may create or cancel a reservation. access.json gives "Manage resource
    /// allocations" to the Operations Coordinator or Project Manager.
    /// </summary>
    public static bool CanManageAllocations(ActorContext actor) =>
        actor.HasRole(CinerionRoles.OperationsCoordinator) || actor.HasRole(CinerionRoles.ProjectManager);

    /// <summary>
    /// Lists resources with capacity, reservations and conflicts over a bounded window.
    /// </summary>
    /// <requirements>CH1-MGT-FR-0004</requirements>
    public async ValueTask<IReadOnlyList<ResourceAvailability>> ListAsync(
        string? resourceType,
        ResourceAvailabilityState? availabilityState,
        DateTimeOffset? from,
        DateTimeOffset? to,
        string? cursor,
        int? limit,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var (windowFrom, windowTo) = ResourceQuery.Window(from, to, clock.UtcNow);
        var query = ResourceQuery.Create(
            actor.ProjectId, resourceType, availabilityState, ResourceCursor.Decode(cursor), limit);
        var resources = await store.ListResourcesAsync(query, cancellationToken).ConfigureAwait(false);
        if (resources.Count == 0)
        {
            return [];
        }

        var allocations = await store.ListAllocationsAsync(
            actor.ProjectId,
            [.. resources.Select(item => item.ResourceId)],
            windowFrom,
            windowTo,
            cancellationToken).ConfigureAwait(false);

        var byResource = allocations.GroupBy(item => item.ResourceId)
            .ToDictionary(group => group.Key, group => (IReadOnlyList<ResourceAllocation>)[.. group]);

        var view = new List<ResourceAvailability>(resources.Count);
        foreach (var resource in resources)
        {
            var reservations = byResource.GetValueOrDefault(resource.ResourceId, []);
            var (peak, at) = CapacityLedger.Peak(reservations, windowFrom, windowTo);
            view.Add(new ResourceAvailability(
                resource,
                reservations,
                peak,
                at,
                CapacityLedger.Conflicts(reservations, resource.Capacity, windowFrom, windowTo)));
        }

        return view;
    }

    /// <summary>
    /// Reserves capacity for a bounded interval.
    /// <para>
    /// The conflict check and the write are one step. The resource version read before
    /// the check is required to still be current when the reservation lands, so two
    /// callers who both saw room cannot both commit; the second is refused with
    /// CONCURRENCY_CONFLICT rather than quietly over-committing the resource.
    /// </para>
    /// </summary>
    /// <requirements>CH1-MGT-FR-0004, CH1-VVT-TC-0106</requirements>
    public async ValueTask<ResourceAllocation> ReserveAsync(
        Guid resourceId,
        Guid? workOrderId,
        Guid? experimentId,
        decimal quantity,
        DateTimeOffset startsAt,
        DateTimeOffset endsAt,
        long? expectedResourceVersion,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanManageAllocations(actor),
            "AUTH_RESOURCE_ALLOCATION",
            "Reserving a resource requires the Operations Coordinator or Project Manager role.");

        var resource = await store.FindResourceAsync(resourceId, cancellationToken).ConfigureAwait(false);
        // A resource in another project reads exactly as one that does not exist.
        Guard.Against(
            resource is null || resource.ProjectId != actor.ProjectId,
            "RESOURCE_NOT_FOUND",
            "The resource does not exist or is outside the caller scope.");

        // CH1-SWA-API-0001 makes optimistic concurrency explicit. A caller that states a
        // version is held to it; one that states none is told what to send.
        Guard.Against(
            expectedResourceVersion is null,
            "RESOURCE_VERSION_REQUIRED",
            $"Reserving requires the resource version in If-Match. The current version is {resource!.Version}.");
        Guard.Against(
            expectedResourceVersion != resource!.Version,
            "CONCURRENCY_CONFLICT",
            $"The resource has moved on; the current version is {resource.Version}.");

        await RequireAllocationTargetAsync(workOrderId, experimentId, actor, cancellationToken).ConfigureAwait(false);

        var candidate = ResourceAllocation.Reserve(
            Guid.NewGuid(), resource, workOrderId, experimentId, quantity, startsAt, endsAt, actor);

        var overlapping = await store.ListAllocationsAsync(
            actor.ProjectId, [resourceId], candidate.StartsAt, candidate.EndsAt, cancellationToken).ConfigureAwait(false);
        var (fits, peakWithRequest, peakAt) = CapacityLedger.Admits(
            overlapping, resource.Capacity, candidate.Quantity, candidate.StartsAt, candidate.EndsAt);

        if (!fits)
        {
            // Audited as a refusal. A blocked reservation is an operational fact worth
            // keeping: it records contention on a shared resource, not just a failed call.
            await AuditAsync(
                actor,
                "ResourceReservationRejected",
                "Rejected",
                "CAPACITY_CONFLICT",
                candidate.AllocationId,
                new
                {
                    resource.ResourceId,
                    resource.Capacity,
                    resource.Unit,
                    Requested = candidate.Quantity,
                    PeakWithRequest = peakWithRequest,
                    PeakAt = peakAt,
                    candidate.StartsAt,
                    candidate.EndsAt,
                },
                correlationId,
                cancellationToken).ConfigureAwait(false);
            throw new DomainRuleException(
                "ALLOCATION_CAPACITY_CONFLICT",
                $"The reservation would commit {peakWithRequest} {resource.Unit} at {peakAt:u}, " +
                $"which exceeds the capacity of {resource.Capacity} {resource.Unit}.");
        }

        await store.SaveAllocationAsync(candidate, resource.Version, null, cancellationToken).ConfigureAwait(false);
        await AuditAsync(
            actor,
            "ResourceReserved",
            "Allowed",
            "CAPACITY_CHECKED_AND_COMMITTED",
            candidate.AllocationId,
            new
            {
                candidate.AllocationId,
                candidate.ResourceId,
                candidate.WorkOrderId,
                candidate.ExperimentId,
                candidate.Quantity,
                candidate.StartsAt,
                candidate.EndsAt,
                ResourceVersionBefore = resource.Version,
                // Restated in the audit, because a reservation is a management action
                // and CH1-MGT-FR-0002 turns on this not being a physical one.
                PhysicalEffect = "None: a reservation holds capacity and starts no equipment.",
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);
        return candidate;
    }

    /// <summary>
    /// Cancels a reservation, releasing its capacity.
    /// </summary>
    /// <requirements>CH1-MGT-FR-0003</requirements>
    public async ValueTask<ResourceAllocation> CancelAsync(
        Guid allocationId,
        string reason,
        long? expectedVersion,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var allocation = await store.FindAllocationAsync(allocationId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            allocation is null || allocation.ProjectId != actor.ProjectId,
            "RESERVATION_NOT_FOUND",
            "The reservation does not exist or is outside the caller scope.");

        // api_endpoints.json gives this operation to the reservation owner or an
        // Operations Coordinator. The owner is whoever requested it, which is narrower
        // than the role that may create one.
        Guard.Against(
            !StringComparer.Ordinal.Equals(allocation!.RequestedBy, actor.ActorId) &&
            !actor.HasRole(CinerionRoles.OperationsCoordinator),
            "AUTH_RESERVATION_CANCELLATION",
            "Cancelling a reservation requires its owner or the Operations Coordinator role.");

        Guard.Against(
            expectedVersion is null,
            "RESERVATION_VERSION_REQUIRED",
            $"Cancelling requires the reservation version in If-Match. The current version is {allocation.Version}.");
        Guard.Against(
            expectedVersion != allocation.Version,
            "CONCURRENCY_CONFLICT",
            $"The reservation has moved on; the current version is {allocation.Version}.");

        var resource = await store.FindResourceAsync(allocation.ResourceId, cancellationToken).ConfigureAwait(false);
        Guard.Against(resource is null, "RESOURCE_NOT_FOUND", "The reservation's resource no longer exists.");

        var cancelled = allocation.Cancel(actor, reason, clock.UtcNow);
        await store.SaveAllocationAsync(cancelled, resource!.Version, allocation.Version, cancellationToken)
            .ConfigureAwait(false);

        await AuditAsync(
            actor,
            "ResourceReservationCancelled",
            "Allowed",
            "CAPACITY_RELEASED_BY_AUTHORISED_ACTOR",
            cancelled.AllocationId,
            new
            {
                cancelled.AllocationId,
                cancelled.ResourceId,
                cancelled.WorkOrderId,
                cancelled.Quantity,
                cancelled.CancellationReason,
                cancelled.CancelledBy,
                VersionBefore = allocation.Version,
                VersionAfter = cancelled.Version,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);
        return cancelled;
    }

    /// <summary>
    /// Confirms the order or experiment a reservation is for exists inside the caller's
    /// project. CH1-MGT-FR-0004 requires every allocation to be linked to one, and the
    /// schema requires exactly one, so capacity is never held for nothing.
    /// </summary>
    private async ValueTask RequireAllocationTargetAsync(
        Guid? workOrderId,
        Guid? experimentId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        // Checked here as well as in ResourceAllocation.Reserve, because this method
        // resolves the target before that rule runs and would otherwise dereference a
        // link the caller never supplied.
        Guard.Against(
            (workOrderId is null) == (experimentId is null),
            "ALLOCATION_LINK_REQUIRED",
            "A reservation must name exactly one of a work order or an experiment.");

        if (experimentId is not null)
        {
            // Reserving capacity for an experiment is a booking, not a bench transition:
            // the experiment gains no production authority and no equipment command
            // authority from holding a resource.
            var experiment = await store.FindExperimentAsync(experimentId.Value, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                experiment is null || experiment.ProjectId != actor.ProjectId,
                "EXPERIMENT_NOT_FOUND",
                "The experiment does not exist or is outside the caller scope.");
            return;
        }

        var workOrder = await store.FindWorkOrderAsync(workOrderId!.Value, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            workOrder is null || workOrder.ProjectId != actor.ProjectId,
            "WORK_ORDER_NOT_FOUND",
            "The work order does not exist or is outside the caller scope.");
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string eventType,
        string decision,
        string reasonCode,
        Guid objectId,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(ResourceAllocation),
                objectId.ToString(),
                correlationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
