// The publication pipeline: package, review, approve. Nobody reviews their own homework.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Documents;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Documents;

/// <summary>
/// The publication pipeline of CH1-DOC-FR-0004.
/// <para>
/// <em>"Public material shall be generated only from an approved redaction profile and
/// shall pass content diff, metadata scrub, secret scan, owner approval and checksum
/// generation before publication."</em>
/// </para>
/// <para>
/// Five controls, and this service performs four of them completely. The fifth - the diff
/// against the source documents' own text - needs bytes this platform does not hold, and
/// the package says so on its face rather than leaving the gap to be discovered. See
/// <see cref="PublicationPackage.DiffNotPerformedNote"/>.
/// </para>
/// <para>
/// <b>Nothing here publishes anything.</b> The pipeline produces a derivative and holds it
/// until two named capacities have reviewed the exact bytes; publication itself is an act
/// outside CH1, and there is deliberately no operation that performs it.
/// </para>
/// </summary>
/// <requirements>CH1-DOC-FR-0001, CH1-DOC-FR-0004, CH1-CYB-FR-0001</requirements>
public sealed class PublicationPipelineService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// The redaction profiles this build holds, each pinned at a revision.
    /// <para>
    /// A profile the platform does not hold is refused rather than treated as permissive:
    /// material redacted according to a profile nobody defined has been redacted according
    /// to nothing. The allowlists are allowlists rather than blocklists, so a
    /// classification or a metadata key nobody anticipated is excluded by default.
    /// </para>
    /// </summary>
    public static readonly IReadOnlyDictionary<string, RedactionProfile> Profiles =
        new Dictionary<string, RedactionProfile>(StringComparer.Ordinal)
        {
            ["CH1-DOC-RDP-SHOWCASE"] = new(
                "CH1-DOC-RDP-SHOWCASE",
                "1.0.0",
                // Project Internal and below. Controlled and Security Sensitive material
                // is never an input to a public showcase derivative.
                ["Project Internal", "Public"],
                ["title", "abstract", "publishedRevision", "licence"]),
            ["CH1-DOC-RDP-ACADEMIC"] = new(
                "CH1-DOC-RDP-ACADEMIC",
                "1.0.0",
                ["Project Internal", "Public", "Controlled"],
                ["title", "abstract", "authors", "institution", "publishedRevision", "licence"]),
        };

    /// <summary>
    /// api_endpoints.json: "Document Controller". access.json agrees - "Create a clean-room
    /// redacted showcase derivative" is a Document Control act.
    /// </summary>
    public static bool CanCreate(ActorContext actor) =>
        actor.HasRole(CinerionRoles.DocumentController);

    /// <summary>
    /// Which review capacity, if any, this identity may exercise.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Conflict 23, resolved.</b> api_endpoints.json names the reviewers "IR plus
    /// Document Control review", and stakeholders.json declares the role in as many
    /// words — "IR - Project Owner … P03 scope, owner authorisation,
    /// confidential/publication boundary and resources … A: P03 owner decisions and
    /// authorisation". Until now <c>CinerionRoles</c> had no such role and the owner's
    /// capacity was exercised by the Project Manager, which was a mapping decision nobody
    /// had recorded. The register now carries what the controlled document declares, and
    /// <c>traceability/controlled-authorities.json</c> records the mapping so it cannot be
    /// made silently again.
    /// </para>
    /// <para>
    /// The Project Manager is deliberately NOT retained as a second route to the owner's
    /// capacity. Keeping it would mean two roles could sign the same half of a two-person
    /// review, which is the property this whole path exists to hold — and an authority
    /// that stays reachable through the old mapping is an authority the resolution did not
    /// actually move.
    /// </para>
    /// <para>
    /// The <i>two-person</i> property does not depend on the mapping and is enforced
    /// regardless: two distinct capacities, two distinct identities, and neither of them
    /// the author.
    /// </para>
    /// </remarks>
    public static ReviewerCapacity? CapacityFor(ActorContext actor) =>
        actor.HasRole(CinerionRoles.ProjectOwner) ? ReviewerCapacity.ProjectOwner
        : actor.HasRole(CinerionRoles.DocumentController) ? ReviewerCapacity.DocumentControl
        : null;

    public async ValueTask<PublicationPackage> CreateAsync(
        string profileId,
        string title,
        IReadOnlyList<Guid> sourceDocumentIds,
        string content,
        string mediaType,
        IReadOnlyDictionary<string, string> metadata,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sourceDocumentIds);
        ArgumentNullException.ThrowIfNull(metadata);

        try
        {
            Guard.Against(
                !CanCreate(actor),
                "AUTH_PUBLICATION_PACKAGE",
                "Building a publication package requires the Document Controller role.");
            Guard.Against(
                !Profiles.TryGetValue(profileId ?? string.Empty, out var profile),
                "PUBLICATION_PROFILE_UNKNOWN",
                $"'{profileId}' is not a redaction profile this build holds. Available profiles are " +
                $"{string.Join(", ", Profiles.Keys)}.");

            // ---------------------------------------------- allowlist the inputs
            var sources = new List<PublicationSource>(sourceDocumentIds.Count);
            foreach (var documentId in sourceDocumentIds.Distinct())
            {
                var document = await store.FindControlledDocumentAsync(documentId, cancellationToken)
                    .ConfigureAwait(false);

                // A document this caller cannot see and a document that does not exist are
                // the same answer, for the same reason every other read gives one answer.
                Guard.Against(
                    document is null || document.ProjectId != actor.ProjectId,
                    "PUBLICATION_SOURCE_NOT_FOUND",
                    $"Document {documentId} is not a controlled document available to this identity.");
                Guard.Against(
                    !profile!.PermittedSourceClassifications.Contains(
                        document!.Classification, StringComparer.Ordinal),
                    "PUBLICATION_SOURCE_NOT_ALLOWLISTED",
                    $"Profile '{profile.ProfileId}' does not permit a {document.Classification} " +
                    $"document as an input. It permits " +
                    $"{string.Join(", ", profile.PermittedSourceClassifications)}.");

                sources.Add(new PublicationSource(
                    document.DocumentId,
                    document.DocumentNumber,
                    document.Revision,
                    document.Classification,
                    document.ContentSha256));
            }

            // ---------------------------------------------------- metadata scrub
            // Everything not on the profile's allowlist is removed, and what was removed is
            // named. A package that claims to have been scrubbed and can name nothing it
            // removed is one nobody can check.
            var retained = new Dictionary<string, string>(StringComparer.Ordinal);
            var removed = new List<string>();
            foreach (var (key, value) in metadata.OrderBy(entry => entry.Key, StringComparer.Ordinal))
            {
                if (profile!.PermittedMetadataKeys.Contains(key, StringComparer.Ordinal))
                {
                    retained[key] = value;
                }
                else
                {
                    removed.Add(key);
                }
            }

            // ------------------------------------------------------- secret scan
            // A finding is a refusal, not a note. The names of the patterns that matched
            // are reported; the matched text is not, because putting it in a response body
            // or an audit payload is the same disclosure by another route.
            var findings = PublicationSecretScan.Scan(content ?? string.Empty);
            Guard.Against(
                findings.Count > 0,
                "PUBLICATION_SECRET_SCAN_FAILED",
                "The candidate derivative matched the secret scan: " +
                $"{string.Join(", ", findings)}. It has not been recorded.");

            // The metadata that survives is published too, so it is scanned on the same
            // terms as the body rather than trusted because it is short.
            var metadataFindings = PublicationSecretScan.Scan(
                string.Join("\n", retained.Select(entry => $"{entry.Key}: {entry.Value}")));
            Guard.Against(
                metadataFindings.Count > 0,
                "PUBLICATION_SECRET_SCAN_FAILED",
                "The retained metadata matched the secret scan: " +
                $"{string.Join(", ", metadataFindings)}. It has not been recorded.");

            // ------------------------------------ checksum, diff and the record
            var package = PublicationPackage.Create(
                Guid.CreateVersion7(),
                actor.ProjectId,
                profile!,
                title ?? string.Empty,
                sources,
                content ?? string.Empty,
                string.IsNullOrWhiteSpace(mediaType) ? "text/plain; charset=utf-8" : mediaType,
                removed,
                retained,
                PublicationSecretScan.ProfileId,
                PublicationSecretScan.PatternCount,
                actor.ActorId,
                clock.UtcNow);

            await store.SavePublicationPackageAsync(package, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor, package.PackageId.ToString(), "PublicationPackageCreated", "Allowed",
                "ALLOWLISTED_SCRUBBED_AND_SCANNED",
                new
                {
                    package.RedactionProfile,
                    package.ProfileRevision,
                    package.Title,
                    SourceCount = sources.Count,
                    package.ContentSha256,
                    MetadataRemoved = removed,
                    package.SecretScanProfile,
                    package.SecretScanPatterns,
                    package.ContentDiffPerformed,
                    package.State,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return package;
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, profileId ?? "unknown-profile", "PublicationPackageRejected", "Rejected",
                error.Code,
                new { ProfileId = profileId, SourceCount = sourceDocumentIds.Count },
                correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    public async ValueTask<(PublicationPackage Package, PublicationApproval Approval)> ApproveAsync(
        Guid packageId,
        bool approved,
        string reviewedChecksum,
        string comment,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        try
        {
            var capacity = CapacityFor(actor);
            Guard.Against(
                capacity is null,
                "AUTH_PUBLICATION_APPROVAL",
                "Reviewing a publication package requires the Project Manager or the " +
                "Document Controller role.");

            var package = await store.FindPublicationPackageAsync(packageId, cancellationToken)
                .ConfigureAwait(false);
            Guard.Against(
                package is null || package.ProjectId != actor.ProjectId,
                "PUBLICATION_PACKAGE_NOT_FOUND",
                "That publication package does not exist or is outside this identity's project.");

            var existing = await store
                .ListPublicationApprovalsAsync(actor.ProjectId, packageId, cancellationToken)
                .ConfigureAwait(false);

            var approval = PublicationApproval.Record(
                Guid.CreateVersion7(),
                package!,
                capacity!.Value,
                approved,
                actor.ActorId,
                capacity.Value.ToString(),
                reviewedChecksum ?? string.Empty,
                comment ?? string.Empty,
                existing,
                clock.UtcNow);

            await store.SavePublicationApprovalAsync(approval, cancellationToken).ConfigureAwait(false);

            var decided = package!.WithDecision([.. existing, approval], clock.UtcNow);
            if (decided.Version != package.Version)
            {
                await store.SavePublicationPackageAsync(decided, cancellationToken).ConfigureAwait(false);
            }

            await AuditAsync(
                actor, packageId.ToString(), "PublicationPackageReviewed", "Allowed",
                approved ? "REVIEWED_AND_APPROVED" : "REVIEWED_AND_REJECTED",
                new
                {
                    PackageId = packageId,
                    Capacity = capacity.Value.ToString(),
                    approval.Decision,
                    approval.ReviewedChecksum,
                    ReviewsHeld = existing.Count + 1,
                    ResultingState = decided.State.ToString(),
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return (decided, approval);
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, packageId.ToString(), "PublicationApprovalRejected", "Rejected",
                error.Code, new { PackageId = packageId }, correlationId, cancellationToken)
                .ConfigureAwait(false);
            throw;
        }
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType, actor.ActorId, actor.Kind, actor.ProjectId,
                nameof(PublicationPackage), objectId, correlationId, clock.UtcNow,
                decision, reasonCode, payload, clock.TimeQuality),
            cancellationToken);
}
