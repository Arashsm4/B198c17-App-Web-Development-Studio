// Reads and creates projects, sites and cells inside the caller's own scope.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Configuration;

/// <summary>
/// Project, site and cell configuration reads and controlled creation.
/// </summary>
/// <requirements>CH1-MGT-FR-0001, CH1-MGT-FR-0003, CH1-NFR-AUD-0001</requirements>
public sealed class ProjectService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// Projects visible to the caller. A token carries exactly one project scope, so
    /// this returns that project if it has been established and an empty list
    /// otherwise. It never synthesises a project from the claim itself: doing so
    /// would report a governance record that no one created and nothing audited.
    /// </summary>
    public async ValueTask<IReadOnlyList<ProjectRecord>> ListVisibleAsync(
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var project = await store.FindProjectAsync(actor.ProjectId, cancellationToken).ConfigureAwait(false);
        return project is null ? [] : [project];
    }

    /// <summary>
    /// Establishes the project this identity is scoped to.
    /// <para>
    /// The identifier is taken from the caller's own <c>ch1_project</c> scope rather
    /// than from the request body. A Project Manager scoped to one project must not be
    /// able to create records in another, and the schema enforces the same boundary
    /// through row-level security keyed on the project identifier.
    /// </para>
    /// </summary>
    public async ValueTask<ProjectRecord> CreateAsync(
        string projectCode,
        string name,
        string baseline,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        try
        {
            ProjectRecord.AuthoriseCreation(actor);

            var existing = await store.FindProjectAsync(actor.ProjectId, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                existing is not null,
                "PROJECT_ALREADY_ESTABLISHED",
                "A project already exists for this scope; configuration changes are revisioned, not recreated.");

            var byCode = await store.FindProjectByCodeAsync(projectCode, cancellationToken).ConfigureAwait(false);
            Guard.Against(byCode is not null, "PROJECT_CODE_CONFLICT", "The project code is already assigned.");

            var project = ProjectRecord.Create(actor.ProjectId, projectCode, name, baseline, clock.UtcNow);
            await store.SaveProjectAsync(project, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor,
                project.ProjectId.ToString(),
                "ProjectEstablished",
                "Allowed",
                "PROJECT_MANAGER_AUTHORITY_VERIFIED",
                new { project.ProjectCode, project.Name, project.Baseline, project.Version },
                cancellationToken).ConfigureAwait(false);
            return project;
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor,
                actor.ProjectId.ToString(),
                "ProjectEstablishmentRejected",
                "Rejected",
                error.Code,
                new { RequestedCode = projectCode },
                cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Cells registered against a site. The site is resolved inside the caller's
    /// project, so a site identifier belonging to another project reads as absent
    /// rather than revealing that it exists elsewhere.
    /// </summary>
    public async ValueTask<IReadOnlyList<CellRegistration>?> ListCellsAsync(
        Guid siteId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var site = await store.FindSiteAsync(siteId, cancellationToken).ConfigureAwait(false);
        if (site is null || site.ProjectId != actor.ProjectId)
        {
            return null;
        }

        var cells = await store.ListCellsBySiteAsync(actor.ProjectId, siteId, cancellationToken).ConfigureAwait(false);
        // Cell assignment is part of the identity, so a project-scoped listing is
        // narrowed again to the cells this actor is actually assigned to.
        return [.. cells.Where(cell => actor.CanAccessCell(cell.CellId))];
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(ProjectRecord),
                objectId,
                Guid.NewGuid(),
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
