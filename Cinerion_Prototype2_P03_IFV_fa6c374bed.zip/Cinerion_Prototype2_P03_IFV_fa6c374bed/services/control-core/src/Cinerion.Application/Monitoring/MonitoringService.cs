// Telemetry in, alarms out. Readings get checked before they get believed.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Monitoring;

/// <summary>One reading offered for storage by a gateway or device account.</summary>
public sealed record TelemetryReading(
    Guid CellId,
    string DeviceId,
    string ChannelId,
    double Value,
    string Unit,
    DataQuality Quality,
    Freshness Freshness,
    DateTimeOffset SampledAt,
    /// <summary>
    /// What the source declared about the clock that stamped <paramref name="SampledAt"/>.
    /// Optional because the in-process simulated source and the demonstration seed are
    /// this service's own clock and have nothing else to declare; a gateway always has.
    /// </summary>
    string? SourceTimeQuality = null);

/// <summary>What an ingested batch changed, so a caller can log it without re-reading.</summary>
public sealed record TelemetryIngestionResult(
    int Accepted,
    IReadOnlyList<Alarm> Raised,
    IReadOnlyList<Alarm> Cleared);

/// <summary>
/// Telemetry query, alarm list and alarm acknowledgement.
/// <para>
/// Acknowledgement is the security-relevant operation here. It is deliberately the
/// only write this service exposes to a human caller, and it can change nothing except
/// the acknowledgement columns: it never touches a cell, a command, an interlock or a
/// permissive. CH1-COL-FR-0003 and CH1-AUT-FDS-0001 both require that separation, and
/// CH1-CYB-ACP-0001 restates it.
/// </para>
/// </summary>
/// <requirements>CH1-MON-FR-0001, CH1-MON-FR-0002, CH1-COL-FR-0003, CH1-AUT-FDS-0001</requirements>
public sealed class MonitoringService(
    ICinerionStore store,
    ISystemClock clock,
    Cinerion.Application.Assets.DevicePkiService deviceTrust)
{
    /// <summary>
    /// Roles that may read an operational view, from the "View dashboards" row of
    /// access.json: Viewer, Auditor, Engineer, Inspector, Maintenance, Project Manager
    /// and Administrators. An authenticated identity holding none of them reads
    /// nothing, so a token issued without a project role is not an operational reader.
    /// </summary>
    private static readonly string[] DashboardReaderRoles =
    [
        CinerionRoles.Viewer,
        CinerionRoles.Auditor,
        CinerionRoles.Engineer,
        CinerionRoles.Inspector,
        CinerionRoles.MaintenanceEngineer,
        CinerionRoles.ProjectManager,
        CinerionRoles.SystemAdministrator,
        CinerionRoles.CybersecurityAdministrator,
    ];

    public static bool CanReadOperationalView(ActorContext actor) =>
        DashboardReaderRoles.Any(actor.HasRole);

    /// <summary>
    /// Bounded historical telemetry for the caller's own project. The project is taken
    /// from the identity rather than the query string, so there is no project parameter
    /// a caller could point at someone else's data.
    /// </summary>
    public async ValueTask<IReadOnlyList<TelemetrySample>> QueryTelemetryAsync(
        Guid? cellId,
        string? deviceId,
        IReadOnlyList<string> channelIds,
        DateTimeOffset? from,
        DateTimeOffset? to,
        int? limit,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var query = TelemetryQuery.Create(
            actor.ProjectId, cellId, deviceId, channelIds, from, to, limit, clock.UtcNow);
        return await store.QueryTelemetryAsync(query, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// How fresh the alarm and telemetry projection is, judged from the data rather
    /// than asserted.
    /// <para>
    /// An alarm list is only as current as the telemetry that would clear it: if the
    /// newest sample is old, a cause that has already gone would still be shown as
    /// present, and the operator must be able to see that. CH1-MON-FR-0003 requires
    /// live, stale, disconnected, simulated, maintenance and unknown to stay
    /// distinguishable, so the state is computed and returned rather than left for the
    /// client to guess.
    /// </para>
    /// </summary>
    /// <requirements>CH1-MON-FR-0001, CH1-MON-FR-0003</requirements>
    public async ValueTask<(Freshness Freshness, DateTimeOffset? NewestSampleAt)> ResolveFreshnessAsync(
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var now = clock.UtcNow;
        var newest = await store.QueryTelemetryAsync(
            TelemetryQuery.Create(
                actor.ProjectId, null, null, [], now - TelemetryQuery.MaximumWindow, now, 1, now),
            cancellationToken).ConfigureAwait(false);
        if (newest.Count == 0)
        {
            // No reading within the widest window the API will serve. Nothing is known
            // about the source, which is Unknown and not Disconnected: this service has
            // no evidence that a link was ever established.
            return (Freshness.Unknown, null);
        }

        var sample = newest[0];
        return (now - sample.SampledAt > StaleAfter ? Freshness.Stale : sample.Freshness, sample.SampledAt);
    }

    /// <summary>
    /// How long a projection stays current after its newest sample. Deliberately far
    /// wider than the CH1-NFR-PER-0002 dashboard target of 1.5 s at the 95th percentile:
    /// that target governs delivery latency, whereas this decides when a reading stops
    /// being usable evidence at all.
    /// </summary>
    public static readonly TimeSpan StaleAfter = TimeSpan.FromSeconds(30);

    public async ValueTask<IReadOnlyList<Alarm>> ListAlarmsAsync(
        Guid? cellId,
        IReadOnlyList<AlarmState> states,
        int? maximumPriority,
        string? cursor,
        int? limit,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var query = AlarmQuery.Create(
            actor.ProjectId, cellId, states, maximumPriority, AlarmCursor.Decode(cursor), limit);
        return await store.ListAlarmsAsync(query, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Records that an authorised operator has seen an alarm.
    /// <para>
    /// The authority is the one stated for this operation: the operator assigned to the
    /// alarm's cell, or an Engineer within the project. No step-up is required and none
    /// is implied — acknowledging is not a physical action and grants no command
    /// authority.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COL-FR-0003, CH1-AUT-FDS-0001</requirements>
    public async ValueTask<Alarm> AcknowledgeAlarmAsync(
        Guid alarmId,
        string comment,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var alarm = await store.FindAlarmAsync(alarmId, cancellationToken).ConfigureAwait(false);
        // An alarm in another project reads exactly as one that does not exist.
        Guard.Against(
            alarm is null || alarm.ProjectId != actor.ProjectId,
            "ALARM_NOT_FOUND",
            "The alarm does not exist or is outside the caller scope.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.Engineer) && !actor.CanAccessCell(alarm!.CellId),
            "AUTH_ALARM_ACKNOWLEDGEMENT",
            "Acknowledging an alarm requires the assigned operator for its cell, or an Engineer.");

        var acknowledged = alarm!.Acknowledge(actor, comment, clock.UtcNow);
        await store.SaveAlarmAsync(acknowledged, cancellationToken).ConfigureAwait(false);

        // The audit record states in its own reason code that the cause was not
        // touched, so the separation is evidenced and not merely intended.
        await store.AppendAuditAsync(
            new AuditInput(
                "AlarmAcknowledged",
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                "Alarm",
                acknowledged.AlarmId.ToString(),
                correlationId,
                clock.UtcNow,
                acknowledged.State.ToString(),
                "ACKNOWLEDGEMENT_DOES_NOT_CLEAR_CAUSE",
                new
                {
                    acknowledged.AlarmId,
                    acknowledged.AlarmCode,
                    acknowledged.CellId,
                    acknowledged.Priority,
                    acknowledged.AcknowledgementComment,
                    CauseClear = acknowledged.CauseClear,
                    State = acknowledged.State.ToString(),
                },
                clock.TimeQuality),
            cancellationToken).ConfigureAwait(false);
        return acknowledged;
    }

    /// <summary>
    /// Stores a batch of readings and evaluates the alarm rules over them.
    /// <para>
    /// Every reading is validated against the controlled channel catalogue before it is
    /// stored, in both channel and unit: an adapter that starts reporting millimetres on
    /// a channel declared in degrees would otherwise be recorded as a plausible value and
    /// could satisfy or breach a limit for the wrong reason.
    /// </para>
    /// <para>
    /// The device must be enrolled, assigned to the cell it reports for, and not
    /// revoked. Trust is read from the stored device record, never from the message.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COM-FR-0007, CH1-COM-FR-0009, CH1-CYB-FR-0001, CH1-AUT-FDS-0001</requirements>
    public async ValueTask<TelemetryIngestionResult> IngestAsync(
        Guid projectId,
        IReadOnlyList<TelemetryReading> readings,
        CancellationToken cancellationToken)
    {
        var receivedAt = clock.UtcNow;
        var samples = new List<TelemetrySample>(readings.Count);
        var raised = new List<Alarm>();
        var cleared = new List<Alarm>();
        var revokedUse = new List<Alarm>();

        // One lookup per device in the batch, not one per reading.
        //
        // A gateway publishes every channel of a device together, so a four-reading batch
        // asked the store for the same device four times - and on PostgreSQL each of those
        // takes a pooled connection and spends a round trip setting the project scope on it
        // before the SELECT. That is three connection acquisitions and six round trips per
        // publication spent re-reading a record that cannot have changed inside the batch.
        //
        // The trust decision is unchanged in every respect: the record is still read from
        // the store rather than believed from the message, still per batch rather than
        // cached across calls, and every guard below still runs for every reading. What is
        // removed is only the repetition.
        var devicesInBatch = new Dictionary<string, DeviceRecord?>(StringComparer.Ordinal);

        foreach (var reading in readings)
        {
            var channel = TelemetryChannelCatalogue.Require(reading.ChannelId);
            Guard.Against(
                !StringComparer.Ordinal.Equals(channel.Unit, reading.Unit),
                "TELEMETRY_UNIT_MISMATCH",
                $"Channel '{channel.ChannelId}' is measured in {channel.Unit}, not {reading.Unit}.");

            if (!devicesInBatch.TryGetValue(reading.DeviceId, out var device))
            {
                device = await store.FindDeviceAsync(reading.DeviceId, cancellationToken).ConfigureAwait(false);
                devicesInBatch[reading.DeviceId] = device;
            }
            Guard.Against(
                device is null || device.ProjectId != projectId,
                "TELEMETRY_DEVICE_NOT_ENROLLED",
                "Telemetry was offered by a device that is not enrolled in this project.");

            // A revoked device still trying to publish is either equipment nobody told or
            // something presenting a withdrawn credential. CH1-CYB-CSRS-0001 lists revoked
            // device use among the events alerting must cover, so it raises an alarm and
            // is then refused - the alarm first, because the refusal throws.
            if (device!.IsRevoked)
            {
                var securityAlarm = await deviceTrust
                    .RaiseRevokedUseAsync(device, cancellationToken).ConfigureAwait(false);
                if (securityAlarm is not null)
                {
                    revokedUse.Add(securityAlarm);
                }
            }

            Guard.Against(
                !device.IsTrusted,
                "TELEMETRY_DEVICE_NOT_TRUSTED",
                "Telemetry was offered by a device whose trust has been revoked or never established.");
            Guard.Against(
                device.CellId != reading.CellId,
                "TELEMETRY_DEVICE_CELL_MISMATCH",
                "The device is not assigned to the cell the reading claims.");

            // An enrolled device declared what it can publish, under its own certificate.
            // That declaration narrows the baseline catalogue and never widens it: a
            // channel must be in both. A device with no enrolled manifest is governed by
            // the catalogue alone, which is where every device stood before enrolment
            // existed.
            Guard.Against(
                device.CapabilityManifest is { } declared && !declared.Declares(reading.ChannelId, reading.Unit),
                "TELEMETRY_CHANNEL_NOT_DECLARED",
                $"Device '{device.DeviceId}' did not declare channel '{reading.ChannelId}' in {reading.Unit} " +
                "in the capability manifest it presented at enrolment.");

            samples.Add(new TelemetrySample(
                Guid.NewGuid(),
                projectId,
                reading.CellId,
                reading.DeviceId,
                reading.ChannelId,
                reading.Value,
                reading.Unit,
                reading.Quality,
                reading.Freshness,
                reading.SampledAt,
                receivedAt,
                clock.TimeQuality,
                // Copied, not judged. An empty declaration stays empty rather than
                // becoming this service's own clock quality, which is the substitution
                // that made defect 59 invisible.
                string.IsNullOrWhiteSpace(reading.SourceTimeQuality) ? null : reading.SourceTimeQuality));
        }

        await store.AppendTelemetryAsync(samples, cancellationToken).ConfigureAwait(false);

        // The alarms a source already holds, read once for the batch rather than once per
        // reading. Every reading needs to know whether an alarm of its own code is
        // outstanding — both to avoid raising a second one and to clear the first when the
        // value returns inside its limits — and asking per reading meant four pooled
        // connections for four readings of one device, each with a round trip to set the
        // project scope before its SELECT.
        //
        // A source holds at most one outstanding alarm per code, so the newest per code is
        // exactly the row the per-reading query returned. Nothing about the decision moves:
        // the state still comes from the store, still per call rather than cached across
        // calls, and every reading is still evaluated on its own.
        var outstanding = new Dictionary<(Guid Cell, string Source), IReadOnlyList<Alarm>>();
        foreach (var sample in samples)
        {
            var key = (sample.CellId, sample.DeviceId);
            if (outstanding.ContainsKey(key))
            {
                continue;
            }

            outstanding[key] = await store
                .FindOutstandingAlarmsAsync(projectId, sample.CellId, sample.DeviceId, cancellationToken)
                .ConfigureAwait(false);
        }

        foreach (var sample in samples)
        {
            var held = outstanding[(sample.CellId, sample.DeviceId)];
            var transition = await EvaluateAlarmAsync(sample, held, cancellationToken).ConfigureAwait(false);
            if (transition is { } alarm)
            {
                (alarm.CauseClear ? cleared : raised).Add(alarm);

                // A transition changes what is outstanding for the readings after it, so
                // the batch's view is updated rather than left describing the state before
                // the change. Two readings on one channel in one batch would otherwise both
                // raise.
                outstanding[(sample.CellId, sample.DeviceId)] = alarm.CauseClear
                    ? [.. held.Where(item => item.AlarmId != alarm.AlarmId)]
                    : [alarm, .. held.Where(item => item.AlarmId != alarm.AlarmId)];
            }
        }

        return new TelemetryIngestionResult(samples.Count, [.. raised, .. revokedUse], cleared);
    }

    /// <summary>
    /// Applies one channel's activation and clear conditions.
    /// <para>
    /// A condition that stays true keeps the alarm it already raised rather than raising
    /// a new one each sample, and a condition that goes away marks the cause clear.
    /// Whether an alarm then leaves the list depends on acknowledgement, which is the
    /// latching policy CH1-AUT-FDS-0001 requires.
    /// </para>
    /// <para>
    /// A sample whose quality is not Good is not treated as evidence that the condition
    /// has gone: a bad reading clears nothing. It does not raise an alarm either, since
    /// an untrustworthy value is not a measurement of a breach.
    /// </para>
    /// </summary>
    private async ValueTask<Alarm?> EvaluateAlarmAsync(
        TelemetrySample sample,
        IReadOnlyList<Alarm> outstandingForSource,
        CancellationToken cancellationToken)
    {
        var channel = TelemetryChannelCatalogue.Require(sample.ChannelId);

        // The alarms this source holds were read once for the batch; the one that governs
        // this reading is the newest outstanding alarm carrying its channel's code, which
        // is precisely what the per-reading query used to return.
        var existing = outstandingForSource
            .Where(item => StringComparer.Ordinal.Equals(item.AlarmCode, channel.AlarmCode))
            .MaxBy(item => item.ActivatedAt);

        if (sample.Quality != DataQuality.Good)
        {
            return null;
        }

        var breached = sample.Value < channel.LowerAlarmLimit || sample.Value > channel.UpperAlarmLimit;

        if (breached)
        {
            if (existing is not null)
            {
                return null;
            }

            var alarm = Alarm.Raise(
                Guid.NewGuid(),
                sample.ProjectId,
                sample.CellId,
                sample.DeviceId,
                channel.AlarmCode,
                channel.AlarmPriority,
                sample.SampledAt);
            await store.SaveAlarmAsync(alarm, cancellationToken).ConfigureAwait(false);
            return alarm;
        }

        if (existing is null)
        {
            return null;
        }

        var settled = existing.ObserveCauseClear(sample.SampledAt);
        await store.SaveAlarmAsync(settled, cancellationToken).ConfigureAwait(false);
        return settled;
    }
}
