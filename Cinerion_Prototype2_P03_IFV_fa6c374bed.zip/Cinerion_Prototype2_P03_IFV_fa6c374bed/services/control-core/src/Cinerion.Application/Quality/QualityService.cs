// The quality loop: test, hold on a fail, NCR, retest, release. A failed part stays held until
// it earns its way out.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Quality;

public sealed class QualityService(ICinerionStore store, ISystemClock clock) : IDisposable
{
    private readonly SemaphoreSlim _transactionGate = new(1, 1);

    /// <summary>
    /// Starts a controlled test run and persists it. Previously the endpoint returned
    /// a fresh identifier and stored nothing, so every measurement referenced a run
    /// that had never existed.
    /// </summary>
    /// <requirements>CH1-QMS-FR-0001</requirements>
    public async ValueTask<TestRunRecord> StartTestRunAsync(
        Guid partId,
        string procedureId,
        string procedureRevision,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var part = await RequirePartAsync(partId, cancellationToken).ConfigureAwait(false);
            Guard.Against(part.ProjectId != actor.ProjectId, "AUTH_PROJECT_SCOPE", "Actor is outside the part project scope.");
            var run = TestRunRecord.Start(partId, procedureId, procedureRevision, actor, clock.UtcNow);
            await store.SaveTestRunAsync(run, cancellationToken).ConfigureAwait(false);
            await AuditPartAsync(
                part,
                actor,
                "TestRunStarted",
                "Allowed",
                "CONTROLLED_PROCEDURE_REVISION_PINNED",
                new { run.TestRunId, run.ProcedureId, run.ProcedureRevision },
                cancellationToken).ConfigureAwait(false);
            return run;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    /// <summary>
    /// Records the controlled decision on an open nonconformity.
    /// </summary>
    /// <requirements>CH1-QMS-FR-0004, CH1-QMS-FR-0005</requirements>
    public async ValueTask<(NcrRecord Ncr, PartRecord Part)> DisposeNcrAsync(
        Guid ncrId,
        NcrDispositionKind disposition,
        string justification,
        ActorContext inspector,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var ncr = await store.FindNcrAsync(ncrId, cancellationToken).ConfigureAwait(false);
            // An unknown nonconformity and one in another project read identically.
            Guard.Against(
                ncr is null || ncr.ProjectId != inspector.ProjectId,
                "NCR_NOT_FOUND",
                "Nonconformity does not exist or is outside the caller scope.");
            var part = await RequirePartAsync(ncr!.PartId, cancellationToken).ConfigureAwait(false);

            var decided = ncr.Dispose(disposition, justification, part, inspector, clock.UtcNow);
            await store.SaveNcrAsync(decided, cancellationToken).ConfigureAwait(false);

            // Only a closing disposition clears the hold, and only through the part's
            // own rule, which re-checks the passing retest and any other open NCR.
            var updatedPart = part;
            if (decided.Status == NcrStatus.Closed)
            {
                updatedPart = part.CloseNcrAfterPassingRetest(ncrId);
                await store.SavePartAsync(updatedPart, cancellationToken).ConfigureAwait(false);
            }

            await AuditPartAsync(
                updatedPart,
                inspector,
                "NcrDispositioned",
                decided.Status.ToString(),
                $"DISPOSITION_{disposition.ToString().ToUpperInvariant()}",
                new { decided.NcrId, Disposition = disposition.ToString(), decided.ClosedByMeasurementId, PartStatus = updatedPart.Status.ToString() },
                cancellationToken).ConfigureAwait(false);
            return (decided, updatedPart);
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    public async ValueTask<PartRecord> RecordMeasurementAsync(
        Guid partId,
        Guid testRunId,
        MeasurementInput input,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await RequirePartAsync(partId, cancellationToken).ConfigureAwait(false);
            AuthoriseMeasurement(current, actor, input);

            // The run must exist, be open, and belong to this part. Without this a
            // result could name any identifier and still appear as controlled evidence.
            var run = await store.FindTestRunAsync(testRunId, cancellationToken).ConfigureAwait(false);
            Guard.Against(run is null, "TEST_RUN_NOT_FOUND", "Test run does not exist or is outside the caller scope.");
            run!.EnsureAcceptsResultsFor(partId, actor);

            // CH1-QMS-FR-0006 requires calibration-expired instruments to be blocked
            // from controlled acceptance results. That determination is made here from
            // the stored certificate. It was previously taken from a boolean in the
            // request body, which meant the submitting client asserted the validity of
            // its own calibration and an expired instrument could simply claim to be
            // in date.
            var calibration = await store.FindCalibrationAsync(input.CalibrationRecordId, cancellationToken).ConfigureAwait(false);
            Guard.Against(
                calibration is null || calibration.ProjectId != actor.ProjectId,
                "CALIBRATION_RECORD_NOT_FOUND",
                "The calibration record does not exist or is outside the caller scope.");
            var calibrationValid = calibration!.IsValidAt(clock.UtcNow, input.SourceDeviceId);

            var updated = current.RecordMeasurement(
                testRunId,
                input.Characteristic,
                input.Value,
                input.Unit,
                input.LowerLimit,
                input.UpperLimit,
                input.Mandatory,
                input.SourceDeviceId,
                input.CalibrationRecordId,
                calibrationValid,
                clock.UtcNow,
                input.SupersedesMeasurementId);
            await store.SavePartAsync(updated, cancellationToken).ConfigureAwait(false);
            await AuditPartAsync(
                updated,
                actor,
                "MeasurementRecorded",
                updated.Measurements[^1].Result.ToString(),
                updated.Status == PartStatus.Hold ? "MANDATORY_LIMIT_FAILED_PART_HELD" : "LIMIT_EVALUATED",
                // Which half of the controlled authority appended this, recorded rather
                // than inferred. An auditor reading a measurement needs to know whether a
                // person witnessed it or an instrument reported it; the source device is
                // already carried, but a device identity and a human using that instrument
                // would otherwise look identical in the record.
                new
                {
                    Measurement = updated.Measurements[^1],
                    AppendedBy = IsBoundInstrumentAdapter(current, actor)
                        ? "BoundInstrumentAdapter"
                        : "Human",
                    ActorKind = actor.Kind.ToString(),
                },
                cancellationToken).ConfigureAwait(false);
            return updated;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    public async ValueTask<(PartRecord Part, NcrRecord Ncr)> RaiseNcrAsync(
        Guid partId,
        string title,
        string description,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await RequirePartAsync(partId, cancellationToken).ConfigureAwait(false);
            AuthoriseInspection(current, actor);
            var result = current.RaiseNcr();

            // The nonconformity is now a record in its own right. Previously the title
            // and description were echoed back to the caller and discarded, so the
            // evidence link the requirement asks for did not survive the response.
            var failed = current.Measurements
                .LastOrDefault(item => item.Mandatory && item.Result == MeasurementResult.Fail);
            var ncr = NcrRecord.Raise(
                result.NcrId,
                partId,
                failed?.TestRunId,
                failed?.MeasurementId,
                title,
                description,
                actor,
                clock.UtcNow);

            await store.SavePartAsync(result.Part, cancellationToken).ConfigureAwait(false);
            await store.SaveNcrAsync(ncr, cancellationToken).ConfigureAwait(false);
            await AuditPartAsync(
                result.Part,
                actor,
                "NcrRaised",
                "Hold",
                "NONCONFORMANCE_RECORDED",
                new { ncr.NcrId, ncr.TestRunId, ncr.SourceMeasurementId },
                cancellationToken).ConfigureAwait(false);
            return (result.Part, ncr);
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    /// <summary>
    /// Releases an accepted part. The redeemed step-up grant is carried through to the
    /// domain and named in the audit event, so the chain records which single controlled
    /// re-authentication authorised this release rather than merely that the caller's
    /// session claimed to be strong enough.
    /// </summary>
    /// <requirements>CH1-QMS-FR-0005, CH1-IAM-FR-0004</requirements>
    public async ValueTask<PartRecord> ReleaseAsync(
        Guid partId,
        StepUpGrant stepUp,
        ActorContext inspector,
        CancellationToken cancellationToken)
    {
        await _transactionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var current = await RequirePartAsync(partId, cancellationToken).ConfigureAwait(false);
            var released = current.ReleaseBy(inspector, stepUp, clock.UtcNow);
            await store.SavePartAsync(released, cancellationToken).ConfigureAwait(false);
            await AuditPartAsync(
                released, inspector, "PartReleased", "Released", "INDEPENDENT_ACCEPTANCE_COMPLETE",
                new
                {
                    released.Release,
                    StepUpGrantId = stepUp.GrantId,
                    StepUpStrength = stepUp.Strength.ToString(),
                    stepUp.Purpose,
                },
                cancellationToken).ConfigureAwait(false);
            return released;
        }
        finally
        {
            _transactionGate.Release();
        }
    }

    /// <summary>
    /// Who may read a part's genealogy. api_endpoints.json gives
    /// <c>GET /api/v1/parts/{partId}/genealogy</c> to "Engineer, Inspector or Auditor",
    /// and the genealogy is the whole evidence graph for a physical part — every
    /// measurement with its value and limits, the instrument and its calibration record,
    /// the operator who performed the work, open nonconformities and the release.
    /// A reader outside those three roles learns the complete quality history of a part
    /// from one request, so the role is checked here rather than assumed from project
    /// scope.
    /// </summary>
    /// <requirements>CH1-MFG-FR-0002, CH1-TRC-FR-0001, CH1-CYB-ACP-0001</requirements>
    /// <summary>
    /// access.json puts calibration validity with the Inspector and the Maintenance
    /// Engineer: the people who decide whether a measurement is admissible and the people
    /// who keep the instrument fit to make one.
    /// </summary>
    public static bool CanReadCalibrations(ActorContext actor)
    {
        ArgumentNullException.ThrowIfNull(actor);
        return actor.HasRole(CinerionRoles.Inspector)
            || actor.HasRole(CinerionRoles.MaintenanceEngineer)
            || actor.HasRole(CinerionRoles.Engineer);
    }

    /// <summary>
    /// The calibration register: every certificate this project holds, newest first, with
    /// the validity an inspector needs before accepting a measurement taken with it.
    /// </summary>
    /// <remarks>
    /// An owner-approved read, recorded in traceability/owner-approved-operations.json with
    /// the screen it serves and why the P03 catalogue has nothing for it. It reads and does
    /// nothing else: the authority check and the project scope are the same ones a
    /// controlled read carries, and there is no field here that could confer anything.
    /// </remarks>
    /// <requirements>CH1-QMS-FR-0005, CH1-CYB-FR-0001</requirements>
    public async ValueTask<IReadOnlyList<CalibrationRecord>> ListCalibrationsAsync(
        ActorContext actor,
        int limit,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(actor);
        Guard.Against(
            !CanReadCalibrations(actor),
            "AUTH_CALIBRATION_REGISTER",
            "Reading the calibration register requires an Inspector, Maintenance Engineer or Engineer.");
        return await store.ListCalibrationsAsync(actor.ProjectId, limit, cancellationToken)
            .ConfigureAwait(false);
    }

    public static bool CanReadGenealogy(ActorContext actor) =>
        actor.HasRole(CinerionRoles.Engineer)
        || actor.HasRole(CinerionRoles.Inspector)
        || actor.HasRole(CinerionRoles.Auditor);

    public async ValueTask<PartRecord?> FindPartAsync(
        Guid partId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        // A caller without the role is answered exactly as one asking about a part that
        // does not exist, so probing cannot distinguish "not allowed" from "not there".
        if (!CanReadGenealogy(actor))
        {
            return null;
        }

        var part = await store.FindPartAsync(partId, cancellationToken).ConfigureAwait(false);
        return part is not null && part.ProjectId == actor.ProjectId ? part : null;
    }

    /// <summary>
    /// Resolves a printed or spoken serial number to the controlled part identity, and
    /// nothing else.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Recorded as conflict 15. screens.json declares CH1-UX-SCR-0007 as "QR/RFID identity
    /// and complete history" for the Engineer and Inspector, and the only operation that
    /// turned a scanned code into a part was
    /// <c>POST /api/v1/parts/scan-events</c>, which requires a signed session from an
    /// enrolled Field Companion device. That binding is correct and stays: CH1-IAM-FR-0008
    /// keeps human, service and device accounts separate, and a browser able to mint a
    /// scan event would break it. The consequence was that an Engineer holding a printed
    /// serial number had no controlled way to reach the genealogy at all.
    /// </para>
    /// <para>
    /// This resolves the identity and mints nothing. It records no scan event, produces no
    /// evidence and changes no state. The authority is EXACTLY the genealogy's — Engineer,
    /// Inspector or Auditor — so the lookup can disclose nothing the read it leads to would
    /// not, and a caller without it is answered as though the serial did not exist.
    /// </para>
    /// <para>
    /// The match is exact on the serial or the permanent identity URI. A prefix or
    /// wildcard would let a caller enumerate the project's serial numbers one character at
    /// a time, which is a disclosure nobody asked for and the reason this takes an
    /// identifier rather than a search term.
    /// </para>
    /// </remarks>
    /// <requirements>CH1-MFG-FR-0002, CH1-QMS-FR-0002, CH1-CYB-FR-0001</requirements>
    public async ValueTask<PartRecord?> ResolvePartBySerialAsync(
        string serialNumber,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        if (!CanReadGenealogy(actor) || string.IsNullOrWhiteSpace(serialNumber))
        {
            return null;
        }

        return await store
            .FindPartByIdentifierAsync(actor.ProjectId, serialNumber.Trim(), cancellationToken)
            .ConfigureAwait(false);
    }

    private async ValueTask<PartRecord> RequirePartAsync(Guid partId, CancellationToken cancellationToken) =>
        await store.FindPartAsync(partId, cancellationToken).ConfigureAwait(false)
        ?? throw new DomainRuleException("PART_NOT_FOUND", "Part does not exist or is outside the caller scope.");

    private static void AuthoriseInspection(PartRecord part, ActorContext actor)
    {
        Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", "A human identity is required for controlled inspection.");
        Guard.Against(
            !actor.HasRole(CinerionRoles.Inspector) && !actor.HasRole(CinerionRoles.Engineer),
            "AUTH_INSPECTION_ROLE_REQUIRED",
            "Inspector or Engineer role is required for controlled measurement and NCR records.");
        Guard.Against(actor.ProjectId != part.ProjectId, "AUTH_PROJECT_SCOPE", "Actor is outside the part project scope.");
        Guard.Against(actor.AuthenticationStrength < AuthenticationStrength.Mfa, "AUTH_MFA_REQUIRED", "Controlled inspection requires MFA.");
    }

    /// <summary>
    /// Whether this actor is the "bound instrument adapter" half of the controlled
    /// authority for appending a measurement.
    /// <para>
    /// <c>api_endpoints.json</c> gives <c>POST /test-runs/{testRunId}/measurements</c> to
    /// "Bound instrument adapter or Test Engineer", and only the second half was
    /// implemented: every measurement went through <see cref="AuthoriseInspection"/>, which
    /// refuses any actor that is not <see cref="ActorKind.Human"/>. The controlled document
    /// therefore named a capability this platform did not have, and an automatic
    /// quality-check machine could not put a result into the system at all. Recorded as a
    /// conflict and resolved in favour of the controlled document.
    /// </para>
    /// <para>
    /// "Bound" is the load-bearing word and is what the rest of this method checks. An
    /// adapter is an enrolled device authenticated by mutual TLS - the same identity a cell
    /// controller presents, established from the certificate rather than from anything the
    /// caller sends - and it is bound to the project the part belongs to. What it may NOT
    /// do is anything else in this service: it cannot raise a nonconformity, decide a
    /// disposition or release a part, because the controlled authority for each of those
    /// names a human role and only a human role.
    /// </para>
    /// </summary>
    /// <requirements>CH1-QMS-FR-0002, CH1-IAM-FR-0008</requirements>
    private static bool IsBoundInstrumentAdapter(PartRecord part, ActorContext actor) =>
        actor.Kind == ActorKind.Device &&
        actor.HasRole(CinerionRoles.DeviceController) &&
        actor.AuthenticationStrength == AuthenticationStrength.MutualTls &&
        actor.ProjectId == part.ProjectId;

    /// <summary>
    /// Authorises appending a measurement, by either half of the controlled authority.
    /// <para>
    /// A device may report ONLY ITS OWN readings. CH1-QMS-FR-0002 requires a measured value
    /// to retain its source device, and a reading is evidence about the instrument that
    /// produced it - so an adapter appending a measurement that names a DIFFERENT
    /// instrument would be attributing a result to equipment that did not make it. That is
    /// the one failure mode machine-fed evidence has and human-entered evidence does not,
    /// and it is refused here rather than left to inspection.
    /// </para>
    /// <para>
    /// Nothing else is relaxed. The calibration record must still cover that instrument and
    /// still be current at the moment of the reading (CH1-QMS-FR-0006); the test run must be
    /// open and belong to this part; a failed mandatory result still holds the part. A
    /// machine cannot lift a hold, and cannot release anything.
    /// </para>
    /// </summary>
    private static void AuthoriseMeasurement(PartRecord part, ActorContext actor, MeasurementInput input)
    {
        if (!IsBoundInstrumentAdapter(part, actor))
        {
            AuthoriseInspection(part, actor);
            return;
        }

        Guard.Against(
            !StringComparer.Ordinal.Equals(input.SourceDeviceId, actor.ActorId),
            "AUTH_INSTRUMENT_NOT_ITS_OWN_READING",
            "A bound instrument adapter may only append readings its own instrument produced.");
    }

    private ValueTask<AuditEvent> AuditPartAsync(
        PartRecord part,
        ActorContext actor,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(PartRecord),
                part.PartId.ToString(),
                Guid.NewGuid(),
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);

    public void Dispose()
    {
        _transactionGate.Dispose();
        GC.SuppressFinalize(this);
    }
}

public sealed record MeasurementInput(
    string Characteristic,
    // TestRunId is passed alongside this record rather than inside it, because the run
    // is addressed by the route and must not be overridable from the body.
    decimal Value,
    string Unit,
    decimal LowerLimit,
    decimal UpperLimit,
    bool Mandatory,
    string SourceDeviceId,
    Guid CalibrationRecordId,
    // Retained on the wire for contract compatibility but deliberately ignored: the
    // server decides calibration validity from the stored certificate, never from the
    // caller's assertion about its own instrument.
    bool CalibrationValid,
    Guid? SupersedesMeasurementId = null);
