// Contract for talking to the identity provider's user directory.

using Cinerion.Domain.Identity;

namespace Cinerion.Application.Identity;

/// <summary>One page of users, with whether another page exists.</summary>
public sealed record UserPage(IReadOnlyList<IdentityUser> Users, bool HasMore, int NextOffset);

/// <summary>
/// The identity provider, as Control Core needs it.
/// <para>
/// FortressGate owns identity; there is no <c>ch1.users</c> table and Control Core never
/// becomes a second system of record for it. This port is deliberately narrow: read
/// users, replace one user's controlled roles, and end a session. It cannot create or
/// delete an account, set a credential, or change realm policy — an adapter that could
/// would hold authority CH1-CYB-ACP-0001 reserves for other roles, and the Keycloak
/// service account behind it is granted no such permission either.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0006, CH1-IAM-FR-0008, CH1-CYB-ACP-0001</requirements>
public interface IIdentityDirectory
{
    /// <summary>
    /// Whether a provider is actually configured. False means every operation below will
    /// refuse; it never means an empty directory.
    /// </summary>
    bool IsConfigured { get; }

    /// <summary>How this directory identifies itself in audit and diagnostics.</summary>
    string ProviderDescription { get; }

    /// <summary>
    /// Users within one project scope. The scope filter is applied by the provider where
    /// it can be, and re-applied here, so a provider that ignored it returns nothing
    /// rather than everything.
    /// </summary>
    ValueTask<UserPage> ListUsersAsync(UserQuery query, CancellationToken cancellationToken);

    ValueTask<IdentityUser?> FindUserAsync(string userId, CancellationToken cancellationToken);

    /// <summary>
    /// Replaces a user's controlled realm roles with exactly this set. Roles the
    /// provider holds that CH1 does not control are left alone.
    /// </summary>
    ValueTask ReplaceControlledRolesAsync(
        string userId,
        IReadOnlyList<string> roles,
        CancellationToken cancellationToken);

    /// <summary>
    /// The active session with this identifier, searched within one project's users.
    /// <para>
    /// The project is part of the lookup rather than a filter applied afterwards: a
    /// session belonging to another project's user is simply not found, so an
    /// administrator cannot end a session outside their own scope even by guessing an
    /// identifier.
    /// </para>
    /// </summary>
    ValueTask<IdentitySession?> FindSessionAsync(
        Guid projectId,
        string sessionId,
        CancellationToken cancellationToken);

    /// <summary>
    /// Ends a session immediately. Returns false when the provider reports no such
    /// session, so a caller is never told a session was revoked that never existed.
    /// </summary>
    ValueTask<bool> RevokeSessionAsync(string sessionId, CancellationToken cancellationToken);
}
