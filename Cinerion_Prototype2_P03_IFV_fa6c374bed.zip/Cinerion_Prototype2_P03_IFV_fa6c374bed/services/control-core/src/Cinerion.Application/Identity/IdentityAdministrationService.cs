// Changes who holds which role, with segregation checks and a record of every change.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Identity;

/// <summary>The roles a user held and the roles they hold now.</summary>
public sealed record RoleAssignmentResult(
    IdentityUser Subject,
    IReadOnlyList<string> Previous,
    IReadOnlyList<string> Current,
    IReadOnlyList<string> Granted,
    IReadOnlyList<string> Withdrawn);

/// <summary>
/// User administration and session revocation against the identity provider.
/// <para>
/// This service reads and writes identity and nothing else. It holds no reference to a
/// cell, a command, an alarm or a part, so administering a user cannot reach equipment.
/// What it does hold is the segregation rules, applied before any change reaches the
/// provider, so a refusal costs nothing and an accepted change has already been checked.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0006, CH1-IAM-FR-0008, CH1-CYB-ACP-0001</requirements>
public sealed class IdentityAdministrationService(
    IIdentityDirectory directory,
    ICinerionStore store,
    ISystemClock clock)
{
    /// <summary>
    /// access.json gives "Manage users" to the System Administrator. CH1-CYB-ACP-0001
    /// adds that this authority stops short of cybersecurity policy, which
    /// <see cref="RoleSegregation"/> enforces per role.
    /// </summary>
    public static bool CanAdministerUsers(ActorContext actor) =>
        actor.HasRole(CinerionRoles.SystemAdministrator);

    /// <summary>
    /// Lists users the caller may see. The project scope comes from the caller's own
    /// identity, so there is no parameter by which one administrator could enumerate
    /// another project's people.
    /// </summary>
    /// <requirements>CH1-CYB-FR-0001</requirements>
    public async ValueTask<UserPage> ListUsersAsync(
        string? search,
        string? cursor,
        int? limit,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        // Authority first, then configuration. A caller without the role is told they
        // lack it whatever state the deployment is in, and does not learn from a refusal
        // whether an identity provider is configured.
        Guard.Against(
            !CanAdministerUsers(actor),
            "AUTH_USER_ADMINISTRATION",
            "Listing users requires the System Administrator role.");
        RequireDirectory();

        return await directory
            .ListUsersAsync(UserQuery.Create(actor.ProjectId, search, cursor, limit), cancellationToken)
            .ConfigureAwait(false);
    }

    /// <summary>
    /// Replaces one user's controlled roles.
    /// <para>
    /// The segregation rules run before the provider is touched, and the audit event
    /// records the previous and current sets rather than only the new one — CH1-MGT-FR-0003
    /// wants configuration changes reversible to a known state, and a record of what a
    /// person used to hold is the only thing that makes an assignment reversible.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0004, CH1-CYB-ACP-0001, CH1-NFR-AUD-0001</requirements>
    public async ValueTask<RoleAssignmentResult> ReplaceRolesAsync(
        string userId,
        IReadOnlyList<string> requestedRoles,
        ActorContext administrator,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanAdministerUsers(administrator),
            "AUTH_USER_ADMINISTRATION",
            "Changing role assignments requires the System Administrator role.");
        RequireDirectory();

        var subject = await RequireUserAsync(userId, administrator, cancellationToken).ConfigureAwait(false);
        var roles = requestedRoles.Distinct(StringComparer.Ordinal).ToArray();

        try
        {
            RoleSegregation.EnsureAssignable(subject, roles, administrator);
        }
        catch (DomainRuleException error)
        {
            // A refused role change is the security event of interest: it records an
            // attempt to cross a segregation boundary, so it must never be dropped.
            await AuditAsync(
                administrator,
                "RoleAssignmentRejected",
                "Rejected",
                error.Code,
                subject.UserId,
                new { subject.UserId, subject.Username, Requested = roles, Current = subject.Roles },
                correlationId,
                cancellationToken).ConfigureAwait(false);
            throw;
        }

        var granted = roles.Where(role => !subject.Roles.Contains(role, StringComparer.Ordinal)).ToArray();
        var withdrawn = subject.Roles.Where(role => !roles.Contains(role, StringComparer.Ordinal)).ToArray();

        await directory.ReplaceControlledRolesAsync(subject.UserId, roles, cancellationToken).ConfigureAwait(false);

        // The controlled record of the change, beside the audit event rather than instead
        // of it. entities.json declares RoleAssignment with a seven-year retention, and
        // ch1.audit_events stores a payload HASH - so without this row the history is
        // verifiable and not readable: an auditor could prove the event was not altered
        // while being unable to say what it recorded.
        //
        // Written AFTER the directory has accepted the change, so a row can never assert a
        // grant the provider refused. A failure here therefore leaves the provider changed
        // and the register short, which is the direction that can be detected and repaired;
        // the reverse could not be.
        if (granted.Length > 0 || withdrawn.Length > 0)
        {
            await store.SaveRoleAssignmentAsync(
                RoleAssignmentRecord.Record(
                    Guid.CreateVersion7(),
                    administrator.ProjectId,
                    subject,
                    subject.Roles,
                    roles,
                    administrator.ActorId,
                    directory.ProviderDescription,
                    correlationId,
                    clock.UtcNow),
                cancellationToken).ConfigureAwait(false);
        }

        await AuditAsync(
            administrator,
            "RoleAssignmentChanged",
            "Allowed",
            "SEGREGATION_CHECKED_AND_APPLIED",
            subject.UserId,
            new
            {
                subject.UserId,
                subject.Username,
                Previous = subject.Roles,
                Current = roles,
                Granted = granted,
                Withdrawn = withdrawn,
                Provider = directory.ProviderDescription,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);

        return new RoleAssignmentResult(subject, subject.Roles, roles, granted, withdrawn);
    }

    /// <summary>
    /// Ends one session.
    /// <para>
    /// api_endpoints.json gives this to the "session owner or Identity Administrator",
    /// and notably does not require step-up: someone who believes their session is
    /// compromised must be able to end it immediately, and a step-up they may be unable
    /// to complete would stand between them and doing so.
    /// </para>
    /// <para>
    /// The session owner is established from the caller's own <c>sid</c> claim rather
    /// than from anything they send, so ownership cannot be asserted.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0006, CH1-CYB-IAM-0001</requirements>
    public async ValueTask<IdentitySession?> RevokeSessionAsync(
        string sessionId,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        // Ownership is established from the caller's own sid claim, so this decision
        // needs no provider and is made before one is required.
        var ownSession = StringComparer.Ordinal.Equals(sessionId, actor.SessionId);
        Guard.Against(
            !ownSession && !CanAdministerUsers(actor),
            "AUTH_SESSION_REVOCATION",
            "Revoking another identity's session requires the System Administrator role.");
        RequireDirectory();

        // The lookup is bounded to the caller's project, so a session in another project
        // reads exactly as one that does not exist and cannot be ended by identifier.
        var session = await directory
            .FindSessionAsync(actor.ProjectId, sessionId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            session is null,
            "SESSION_NOT_FOUND",
            "The session does not exist or is outside the caller scope.");

        var revoked = await directory.RevokeSessionAsync(sessionId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            !revoked,
            "SESSION_NOT_FOUND",
            "The session does not exist or is outside the caller scope.");

        await AuditAsync(
            actor,
            "SessionRevoked",
            "Allowed",
            ownSession ? "SELF_REVOCATION" : "ADMINISTRATIVE_REVOCATION",
            sessionId,
            new
            {
                SessionId = sessionId,
                SubjectUserId = session?.UserId,
                SubjectUsername = session?.Username,
                OwnSession = ownSession,
                Provider = directory.ProviderDescription,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);
        return session;
    }

    private async ValueTask<IdentityUser> RequireUserAsync(
        string userId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var user = await directory.FindUserAsync(userId, cancellationToken).ConfigureAwait(false);
        // A user in another project and one that does not exist read identically.
        Guard.Against(
            user is null || user.ProjectId != actor.ProjectId,
            "USER_NOT_FOUND",
            "The user does not exist or is outside the caller scope.");
        return user!;
    }

    /// <summary>
    /// Refuses when no identity provider is configured.
    /// <para>
    /// This is the fail-closed direction and the reason the development identity scheme
    /// cannot serve these operations: there is no directory behind it, and returning an
    /// empty list or a fabricated user would be a fake-success answer to a security
    /// question.
    /// </para>
    /// </summary>
    private void RequireDirectory() =>
        Guard.Against(
            !directory.IsConfigured,
            "IDENTITY_PROVIDER_NOT_CONFIGURED",
            "No identity provider is configured, so user administration is unavailable. " +
            "Set CINERION_KEYCLOAK_IDENTITY_ADMIN_CLIENT and CINERION_KEYCLOAK_IDENTITY_ADMIN_SECRET.");

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string eventType,
        string decision,
        string reasonCode,
        string objectId,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(IdentityUser),
                objectId,
                correlationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
