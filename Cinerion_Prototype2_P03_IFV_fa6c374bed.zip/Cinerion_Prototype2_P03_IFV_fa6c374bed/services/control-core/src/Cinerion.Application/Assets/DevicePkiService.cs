// Device enrolment and revocation, with an alarm whenever trust changes.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Assets;

/// <summary>An enrolment or revocation, with the alarm it raised if it raised one.</summary>
public sealed record DeviceTrustChange(DeviceRecord Device, CertificateProof? Proof, Alarm? Alarm);

/// <summary>
/// Device certificate enrolment and revocation.
/// <para>
/// This platform is a trust registry, not a certificate authority. It holds no signing
/// key and issues nothing: the device generates its key pair inside its own secure
/// element and presents only the certificate, which CH1-CYB-CSRS-0001 requires by making
/// long-lived private keys non-exportable. A private key arriving here would mean that
/// boundary had already failed, so it is refused and named as a compromise rather than
/// used.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0006, CH1-IAM-FR-0008, CH1-CYB-FR-0002, CH1-CYB-FR-0003</requirements>
public sealed class DevicePkiService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// access.json gives "Enrol/revoke device" to the Cybersecurity Administrator, and
    /// CH1-CYB-ACP-0001 makes credentials, certificates, trust and revocation exactly
    /// their remit.
    /// </summary>
    public static bool CanAdministerDeviceTrust(ActorContext actor) =>
        actor.HasRole(CinerionRoles.CybersecurityAdministrator);

    /// <summary>
    /// Records a verified certificate against a device already known to the project.
    /// <para>
    /// "Allowlist" in the API control column is read as exactly that: enrolment attaches
    /// a certificate to a device the project already expects, and does not create device
    /// identities. A certificate presented for an unknown identifier is refused.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0006, CH1-CYB-FR-0003</requirements>
    public async ValueTask<DeviceTrustChange> EnrolAsync(
        string deviceId,
        string presentedCertificate,
        DeviceCapabilityManifest manifest,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanAdministerDeviceTrust(actor),
            "AUTH_DEVICE_TRUST",
            "Enrolling a device requires the Cybersecurity Administrator role.");

        var device = await RequireDeviceAsync(deviceId, actor, cancellationToken).ConfigureAwait(false);

        CertificateProof proof;
        try
        {
            proof = DeviceCertificate.Inspect(presentedCertificate, deviceId, clock.UtcNow);
        }
        catch (DomainRuleException error)
        {
            // A rejected enrolment is the security event of interest, and a submitted
            // private key especially so. The audit payload names the failure and never
            // the material: CH1-CYB-CSRS-0001 requires logs to contain no private keys.
            await AuditAsync(
                actor,
                "DeviceEnrolmentRejected",
                "Rejected",
                error.Code,
                deviceId,
                new { DeviceId = deviceId, device.ProjectId, PrivateKeyRetained = false },
                correlationId,
                cancellationToken).ConfigureAwait(false);
            throw;
        }

        // One certificate, one device. Checked before writing so the refusal names the
        // clone rather than surfacing as a constraint violation.
        var holder = await store
            .FindDeviceByThumbprintAsync(actor.ProjectId, proof.Thumbprint, cancellationToken)
            .ConfigureAwait(false);
        Guard.Against(
            holder is not null && !StringComparer.Ordinal.Equals(holder.DeviceId, deviceId),
            "DEVICE_CERTIFICATE_ALREADY_ENROLLED",
            $"That certificate is already enrolled for device '{holder?.DeviceId}'.");

        var previousThumbprint = device.CertificateThumbprint;
        var enrolled = device.Enrol(proof, manifest, clock.UtcNow);
        await store.SaveDeviceAsync(enrolled, cancellationToken).ConfigureAwait(false);

        // CH1-CYB-CSRS-0001 lists trust-list change among the events alerting must cover.
        var alarm = await RaiseAsync(
            enrolled,
            SecurityAlarms.DeviceTrustChanged,
            cancellationToken).ConfigureAwait(false);

        await AuditAsync(
            actor,
            previousThumbprint is null ? "DeviceEnrolled" : "DeviceCertificateRotated",
            "Allowed",
            "CERTIFICATE_VERIFIED_BY_PLATFORM_PRIVATE_KEY_NEVER_PRESENTED",
            deviceId,
            new
            {
                DeviceId = deviceId,
                PreviousThumbprint = previousThumbprint,
                proof.Thumbprint,
                proof.Subject,
                proof.Issuer,
                proof.SerialNumber,
                proof.KeyAlgorithm,
                proof.KeySizeBits,
                proof.NotBefore,
                proof.NotAfter,
                proof.SelfSigned,
                DeclaredChannels = enrolled.CapabilityManifest?.TelemetryChannels.Select(item => item.ChannelId),
                AlarmRaised = alarm?.AlarmId,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);

        return new DeviceTrustChange(enrolled, proof, alarm);
    }

    /// <summary>
    /// Withdraws a device's trust.
    /// <para>
    /// The effect is immediate and real: <see cref="Cinerion.Application.Monitoring.MonitoringService"/>
    /// reads trust from the stored record on every reading, so the next thing this device
    /// publishes is refused. What this service cannot do is revoke the broker topic ACL —
    /// CH1-COM-IF-0004 puts that in the MQTT broker, which is not enabled — so the
    /// response says which half of "certificate/topic revocation" actually took effect
    /// rather than implying both did.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0006, CH1-CYB-CSRS-0001</requirements>
    public async ValueTask<DeviceTrustChange> RevokeAsync(
        string deviceId,
        string reason,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !CanAdministerDeviceTrust(actor),
            "AUTH_DEVICE_TRUST",
            "Revoking device trust requires the Cybersecurity Administrator role.");

        var device = await RequireDeviceAsync(deviceId, actor, cancellationToken).ConfigureAwait(false);
        var revoked = device.Revoke(reason, actor.ActorId, clock.UtcNow);
        await store.SaveDeviceAsync(revoked, cancellationToken).ConfigureAwait(false);

        // api_endpoints.json makes an alarm part of the control on this operation.
        var alarm = await RaiseAsync(revoked, SecurityAlarms.DeviceRevoked, cancellationToken).ConfigureAwait(false);

        await AuditAsync(
            actor,
            "DeviceRevoked",
            "Allowed",
            "TRUST_WITHDRAWN_TELEMETRY_REFUSED_IMMEDIATELY",
            deviceId,
            new
            {
                DeviceId = deviceId,
                revoked.CertificateThumbprint,
                revoked.RevocationReason,
                revoked.RevokedBy,
                revoked.RevokedAt,
                AlarmRaised = alarm?.AlarmId,
                TopicAclRevoked = false,
            },
            correlationId,
            cancellationToken).ConfigureAwait(false);

        return new DeviceTrustChange(revoked, null, alarm);
    }

    /// <summary>
    /// Raises a security alarm against the device's cell.
    /// <para>
    /// ch1.alarms requires a cell, so a device not assigned to one leaves the audit event
    /// as the only record. Returning null rather than inventing a cell keeps the alarm
    /// list honest about which equipment an alarm belongs to.
    /// </para>
    /// </summary>
    private async ValueTask<Alarm?> RaiseAsync(
        DeviceRecord device,
        string alarmCode,
        CancellationToken cancellationToken)
    {
        if (device.CellId is not { } cellId)
        {
            return null;
        }

        var outstanding = await store.FindOutstandingAlarmAsync(
            device.ProjectId, cellId, device.DeviceId, alarmCode, cancellationToken).ConfigureAwait(false);
        if (outstanding is not null)
        {
            return outstanding;
        }

        var alarm = Alarm.Raise(
            Guid.NewGuid(),
            device.ProjectId,
            cellId,
            device.DeviceId,
            alarmCode,
            SecurityAlarms.PriorityOf(alarmCode),
            clock.UtcNow);
        await store.SaveAlarmAsync(alarm, cancellationToken).ConfigureAwait(false);
        return alarm;
    }

    /// <summary>
    /// Raises the alarm for a revoked device that tried to publish. Kept here rather than
    /// in the monitoring service so the security alarm and the trust decision that made
    /// it meaningful live together.
    /// </summary>
    /// <requirements>CH1-CYB-CSRS-0001</requirements>
    public ValueTask<Alarm?> RaiseRevokedUseAsync(DeviceRecord device, CancellationToken cancellationToken) =>
        RaiseAsync(device, SecurityAlarms.RevokedDeviceUse, cancellationToken);

    private async ValueTask<DeviceRecord> RequireDeviceAsync(
        string deviceId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var device = await store.FindDeviceAsync(deviceId, cancellationToken).ConfigureAwait(false);
        // A device in another project and one that does not exist read identically.
        Guard.Against(
            device is null || device.ProjectId != actor.ProjectId,
            "DEVICE_NOT_FOUND",
            "The device does not exist or is outside the caller scope.");
        return device!;
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string eventType,
        string decision,
        string reasonCode,
        string deviceId,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(DeviceRecord),
                deviceId,
                correlationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
