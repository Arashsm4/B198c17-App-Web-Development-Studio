// Messages and receipts on controlled objects. Reading a message is not acknowledging an
// alarm.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Collaboration;

/// <summary>A page of a thread with the receipts recorded against it.</summary>
public sealed record ContextMessagePage(
    ContextThread Thread,
    IReadOnlyList<ContextMessage> Messages,
    IReadOnlyDictionary<Guid, IReadOnlyList<MessageAcknowledgement>> Acknowledgements);

/// <summary>
/// Contextual project communication.
/// <para>
/// This service can read and write exactly three things: threads, messages and
/// receipts. It holds no reference to alarms, commands, cells or interlocks, and there
/// is no path through it that could reach one. CH1-COL-FR-0003 requires that
/// acknowledging a communication does not acknowledge an alarm, clear a fault, satisfy
/// an interlock or confirm a physical action; the strongest form of that guarantee is a
/// component that has no way to express such an effect, and this is that component.
/// </para>
/// </summary>
/// <requirements>CH1-COL-FR-0001, CH1-COL-FR-0002, CH1-COL-FR-0003</requirements>
public sealed class ContextBridgeService(ICinerionStore store, ISystemClock clock)
{
    /// <summary>
    /// Declared retention for this data, from entities.json. Returned with every page
    /// because CH1-SWA-API-0001 makes retention policy a control on the read operation,
    /// and CH1-DBA-DD-0001 warns that contextual messages must not be allowed to become
    /// an uncontrolled permanent engineering decision record. A reader is told what this
    /// conversation is, and what it is not.
    /// </summary>
    public static class Retention
    {
        public const string Message = "Project life + 7 years";
        public const string Acknowledgement = "7 years";
        public const string Disposal =
            "Deletion is an authorised, logged administrative process, not a user action.";
        public const string Standing =
            "A contextual message is communication, not a controlled engineering decision. " +
            "Approvals, dispositions and releases are separate controlled records.";
    }

    /// <summary>
    /// Reads one page of a thread.
    /// <para>
    /// A thread the caller is not a participant in reads exactly as one that does not
    /// exist, so scope cannot be probed. CH1-VVT-TC-0107 requires messages to be
    /// inaccessible outside authorised scope, and an error that distinguished
    /// "forbidden" from "absent" would leak the existence of the conversation and of the
    /// object it is attached to.
    /// </para>
    /// </summary>
    /// <requirements>CH1-VVT-TC-0107</requirements>
    public async ValueTask<ContextMessagePage?> ReadThreadAsync(
        Guid threadId,
        string? cursor,
        int? limit,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var thread = await store.FindContextThreadAsync(threadId, cancellationToken).ConfigureAwait(false);
        if (thread is null || !thread.Admits(actor))
        {
            return null;
        }

        var messages = await store.ListContextMessagesAsync(
            ContextMessageQuery.Create(actor.ProjectId, threadId, ContextMessageCursor.Decode(cursor), limit),
            cancellationToken).ConfigureAwait(false);

        var receipts = await store.ListMessageAcknowledgementsAsync(
            actor.ProjectId,
            [.. messages.Select(message => message.MessageId)],
            cancellationToken).ConfigureAwait(false);

        var byMessage = receipts
            .GroupBy(receipt => receipt.MessageId)
            .ToDictionary(group => group.Key, group => (IReadOnlyList<MessageAcknowledgement>)[.. group]);

        return new ContextMessagePage(thread, messages, byMessage);
    }

    /// <summary>
    /// Adds a message, opening the thread against its controlled object on first use.
    /// <para>
    /// The thread identifier is derived from the object, so a caller cannot invent one:
    /// posting to an identifier that does not match the object named in the request is
    /// refused, and the canonical identifier is returned so the caller can correct it.
    /// Without that, a thread could be opened at an arbitrary identifier and a
    /// conversation would exist that no object page could ever find.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COL-FR-0001, CH1-COL-FR-0002</requirements>
    public async ValueTask<(ContextThread Thread, ContextMessage Message)> PostMessageAsync(
        Guid threadId,
        ContextObjectType? objectType,
        string? objectId,
        ThreadAccessScope? requestedScope,
        MessagePriority priority,
        string body,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var thread = await store.FindContextThreadAsync(threadId, cancellationToken).ConfigureAwait(false);
        if (thread is null)
        {
            thread = await OpenThreadAsync(
                threadId, objectType, objectId, requestedScope, actor, correlationId, cancellationToken)
                .ConfigureAwait(false);
        }
        else
        {
            Guard.Against(
                !thread.Admits(actor),
                "CONTEXT_THREAD_NOT_FOUND",
                "The thread does not exist or is outside the caller scope.");
            // A stated object link on an existing thread must agree with the stored one.
            // Silently ignoring a mismatch would let a client believe it had posted
            // against a different object.
            Guard.Against(
                objectType is not null &&
                (objectType != thread.ObjectType ||
                 !StringComparer.Ordinal.Equals((objectId ?? string.Empty).Trim(), thread.ObjectId)),
                "CONTEXT_OBJECT_MISMATCH",
                "The stated controlled object does not match the object this thread belongs to.");
        }

        var message = ContextMessage.Compose(Guid.NewGuid(), thread, actor, priority, body, clock.UtcNow);
        await store.SaveContextMessageAsync(message, cancellationToken).ConfigureAwait(false);

        // Provenance goes to the audit chain; the body does not. ch1.audit_events is
        // append-only and immutable, so recording message text there would make every
        // contextual message permanently undeletable and turn project chat into exactly
        // the uncontrolled permanent engineering record CH1-DBA-DD-0001 warns against.
        // The payload hash still binds this event to that text if it is ever produced.
        await store.AppendAuditAsync(
            new AuditInput(
                "ContextMessagePosted",
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                "ContextMessage",
                message.MessageId.ToString(),
                correlationId,
                clock.UtcNow,
                "Allowed",
                "CONTEXT_MESSAGE_CARRIES_NO_CONTROL_AUTHORITY",
                new
                {
                    message.MessageId,
                    message.ThreadId,
                    ObjectType = thread.ObjectType.ToString(),
                    thread.ObjectId,
                    Priority = message.Priority.ToString(),
                    BodySha256 = CanonicalJson.Sha256Hex(message.Body),
                    message.ControlAuthority,
                },
                clock.TimeQuality),
            cancellationToken).ConfigureAwait(false);

        return (thread, message);
    }

    private async ValueTask<ContextThread> OpenThreadAsync(
        Guid threadId,
        ContextObjectType? objectType,
        string? objectId,
        ThreadAccessScope? requestedScope,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            objectType is null || string.IsNullOrWhiteSpace(objectId),
            "CONTEXT_OBJECT_REQUIRED",
            "The first message in a thread must state the controlled object it belongs to.");

        var trimmedObjectId = objectId!.Trim();
        var canonical = ContextThread.DeriveId(actor.ProjectId, objectType!.Value, trimmedObjectId);
        Guard.Against(
            canonical != threadId,
            "CONTEXT_THREAD_ID_MISMATCH",
            $"The thread for {objectType} {trimmedObjectId} is {canonical}. " +
            "Thread identifiers are derived from the object, not chosen.");

        // The object must exist and be inside the caller's project. Without this a
        // conversation could be attached to something that was never there, and every
        // later authorisation decision would rest on a link to nothing.
        await RequireObjectAsync(objectType.Value, trimmedObjectId, actor, cancellationToken).ConfigureAwait(false);

        var scope = requestedScope ?? DefaultScope(actor);
        var opened = ContextThread.Open(actor.ProjectId, objectType.Value, trimmedObjectId, scope, actor, clock.UtcNow);
        Guard.Against(
            !opened.Admits(actor),
            "CONTEXT_SCOPE_EXCLUDES_AUTHOR",
            "The stated access scope would exclude the author from their own thread.");

        await store.SaveContextThreadAsync(opened, cancellationToken).ConfigureAwait(false);
        await store.AppendAuditAsync(
            new AuditInput(
                "ContextThreadOpened",
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                "ContextThread",
                opened.ThreadId.ToString(),
                correlationId,
                clock.UtcNow,
                "Allowed",
                "CONTEXT_THREAD_BOUND_TO_CONTROLLED_OBJECT",
                new
                {
                    opened.ThreadId,
                    ObjectType = opened.ObjectType.ToString(),
                    opened.ObjectId,
                    opened.AccessScope.Roles,
                    opened.AccessScope.ActorIds,
                },
                clock.TimeQuality),
            cancellationToken).ConfigureAwait(false);
        return opened;
    }

    /// <summary>
    /// The scope a thread gets when the author states none: the author, plus the roles
    /// access.json grants an operational read. Narrow enough to be a real boundary, and
    /// a caller who wants a narrower one states it.
    /// </summary>
    private static ThreadAccessScope DefaultScope(ActorContext actor) => ThreadAccessScope.Create(
        [
            CinerionRoles.Viewer,
            CinerionRoles.Auditor,
            CinerionRoles.Engineer,
            CinerionRoles.Inspector,
            CinerionRoles.MaintenanceEngineer,
            CinerionRoles.ProjectManager,
        ],
        [actor.ActorId]);

    /// <summary>
    /// Confirms the controlled object exists inside the caller's project.
    /// <para>
    /// Every branch reads through the store, so row-level security has already bounded
    /// the lookup to one project; the explicit project comparison covers the in-memory
    /// store, which has no such boundary of its own.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COL-FR-0001, CH1-VVT-TC-0107</requirements>
    private async ValueTask RequireObjectAsync(
        ContextObjectType objectType,
        string objectId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var found = objectType switch
        {
            ContextObjectType.Device =>
                await store.FindDeviceAsync(objectId, cancellationToken).ConfigureAwait(false) is { } device &&
                device.ProjectId == actor.ProjectId,
            _ => await RequireGuidObjectAsync(objectType, objectId, actor, cancellationToken).ConfigureAwait(false),
        };

        // An object outside the project and one that never existed read identically.
        Guard.Against(
            !found,
            "CONTEXT_OBJECT_NOT_FOUND",
            $"{objectType} {objectId} does not exist or is outside the caller scope.");
    }

    private async ValueTask<bool> RequireGuidObjectAsync(
        ContextObjectType objectType,
        string objectId,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !Guid.TryParse(objectId, out var id),
            "CONTEXT_OBJECT_ID_INVALID",
            $"A {objectType} identifier must be a UUID.");

        return objectType switch
        {
            ContextObjectType.Project =>
                id == actor.ProjectId &&
                await store.FindProjectAsync(id, cancellationToken).ConfigureAwait(false) is not null,
            ContextObjectType.Cell =>
                await store.FindCellAsync(id, cancellationToken).ConfigureAwait(false) is { } cell &&
                cell.Snapshot.ProjectId == actor.ProjectId,
            ContextObjectType.Asset =>
                await store.FindAssetAsync(id, cancellationToken).ConfigureAwait(false) is { } asset &&
                asset.ProjectId == actor.ProjectId,
            ContextObjectType.Part =>
                await store.FindPartAsync(id, cancellationToken).ConfigureAwait(false) is { } part &&
                part.ProjectId == actor.ProjectId,
            ContextObjectType.WorkOrder =>
                await store.FindWorkOrderAsync(id, cancellationToken).ConfigureAwait(false) is { } workOrder &&
                workOrder.ProjectId == actor.ProjectId,
            ContextObjectType.Alarm =>
                await store.FindAlarmAsync(id, cancellationToken).ConfigureAwait(false) is { } alarm &&
                alarm.ProjectId == actor.ProjectId,
            ContextObjectType.Ncr =>
                await store.FindNcrAsync(id, cancellationToken).ConfigureAwait(false) is { } ncr &&
                ncr.ProjectId == actor.ProjectId,
            ContextObjectType.Experiment =>
                await store.FindExperimentAsync(id, cancellationToken).ConfigureAwait(false) is { } experiment &&
                experiment.ProjectId == actor.ProjectId,
            _ => false,
        };
    }

    /// <summary>
    /// Records that a recipient read a message.
    /// <para>
    /// This is the operation CH1-VVT-TC-0109 exists to test. It writes one row into
    /// ch1.message_acknowledgements and appends one audit event. It does not read, and
    /// cannot reach, an alarm, a command transaction, a cell or an interlock — even when
    /// the message is attached to an alarm thread, which is precisely the case the test
    /// covers.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COL-FR-0003, CH1-CYB-ACP-0001</requirements>
    public async ValueTask<(ContextThread Thread, MessageAcknowledgement Receipt)> AcknowledgeMessageAsync(
        Guid messageId,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var message = await store.FindContextMessageAsync(messageId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            message is null || message.ProjectId != actor.ProjectId,
            "CONTEXT_MESSAGE_NOT_FOUND",
            "The message does not exist or is outside the caller scope.");

        var thread = await store.FindContextThreadAsync(message!.ThreadId, cancellationToken).ConfigureAwait(false);
        // access.json gives this operation to the assigned recipient. The audience of a
        // message is the access scope of its thread, so a non-participant is told the
        // message does not exist rather than that they may not read it.
        Guard.Against(
            thread is null || !thread.Admits(actor),
            "CONTEXT_MESSAGE_NOT_FOUND",
            "The message does not exist or is outside the caller scope.");

        var receipt = MessageAcknowledgement.Record(Guid.NewGuid(), message, actor, clock.UtcNow);
        await store.SaveMessageAcknowledgementAsync(receipt, cancellationToken).ConfigureAwait(false);

        await store.AppendAuditAsync(
            new AuditInput(
                "ContextMessageRead",
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                "MessageAcknowledgement",
                receipt.MessageAckId.ToString(),
                correlationId,
                clock.UtcNow,
                // The decision word is "Read", never "Acknowledged". CH1-UXD-DSG-0001
                // requires the verbs to differ so nobody can mistake a message receipt
                // for an alarm acknowledgement, and the audit trail is read by people too.
                MessageAcknowledgement.Kind,
                "MESSAGE_RECEIPT_IS_NOT_ALARM_FAULT_INTERLOCK_OR_COMMAND",
                new
                {
                    receipt.MessageAckId,
                    receipt.MessageId,
                    ThreadObjectType = thread!.ObjectType.ToString(),
                    thread.ObjectId,
                    receipt.RecipientId,
                    receipt.ControlAuthority,
                },
                clock.TimeQuality),
            cancellationToken).ConfigureAwait(false);

        return (thread, receipt);
    }
}
