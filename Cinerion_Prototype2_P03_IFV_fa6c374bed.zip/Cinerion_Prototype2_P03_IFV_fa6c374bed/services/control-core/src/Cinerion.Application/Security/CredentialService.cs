// Passkey and TOTP enrolment and checks. A secret is shown once, then sealed away.

using System.Security.Cryptography;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Security;

/// <summary>What a TOTP enrolment discloses, once and never again.</summary>
public sealed record TotpEnrolment(
    CredentialRecord Credential,
    string SharedSecretBase32,
    string EnrolmentUri,
    TotpParameters Parameters);

/// <summary>
/// Enrolment, assertion and revocation of human authenticators.
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-IAM-FR-0007, CH1-CYB-IAM-0001</requirements>
public sealed class CredentialService(
    ICinerionStore store,
    ICredentialSealer sealer,
    ISystemClock clock)
{
    /// <summary>
    /// Who may administer another person's credentials. Self-service is separately
    /// permitted for TOTP, which api_endpoints.json gives to "Self or Identity
    /// Administrator"; registering and revoking a physical credential is a Cybersecurity
    /// Administrator action in every case.
    /// </summary>
    public static bool CanAdministerCredentials(ActorContext actor) =>
        actor.HasRole(CinerionRoles.CybersecurityAdministrator);

    // ------------------------------------------------------------------ TOTP

    /// <summary>
    /// Begins a TOTP enrolment. The seed is generated here, sealed before it is stored
    /// and returned exactly once in the response; no later operation can retrieve it.
    /// </summary>
    public async ValueTask<TotpEnrolment> EnrolTotpAsync(
        string subjectId,
        string label,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var subject = string.IsNullOrWhiteSpace(subjectId) ? actor.ActorId : subjectId.Trim();
        try
        {
            // Self-service, or an administrator acting for someone else. Checked before
            // anything is generated so a refusal never leaves a seed in memory.
            Guard.Against(
                !string.Equals(subject, actor.ActorId, StringComparison.Ordinal)
                    && !actor.HasRole(CinerionRoles.SystemAdministrator),
                "AUTH_CREDENTIAL_SUBJECT",
                "Enrolling a second factor for another identity requires a System Administrator.");
            Guard.Against(
                actor.Kind != ActorKind.Human,
                "AUTH_HUMAN_REQUIRED",
                "A one-time password authenticates a person; service identities use workload credentials.");
            Guard.Against(
                !sealer.IsConfigured,
                "CREDENTIAL_SEALING_NOT_CONFIGURED",
                "No credential encryption key is configured, so a shared secret cannot be stored. " +
                "Enrolment refuses rather than keeping a seed in the clear.");

            var existing = await store
                .ListCredentialsAsync(actor.ProjectId, subject, cancellationToken)
                .ConfigureAwait(false);
            // One active TOTP per identity, mirroring ux_credentials_active_totp. Two
            // live seeds would leave the holder unable to tell which an attacker had.
            Guard.Against(
                existing.Any(item =>
                    item.Kind == CredentialKind.Totp && item.Status == CredentialStatus.Active),
                "CREDENTIAL_TOTP_ALREADY_ENROLLED",
                "This identity already holds an active one-time-password enrolment. " +
                "Revoke it before enrolling a replacement.");

            var parameters = TotpParameters.Default;
            var secret = Totp.GenerateSecret();
            var credentialId = Guid.CreateVersion7();
            var sealedSecret = sealer.Seal(secret, credentialId.ToByteArray());

            var credential = CredentialRecord.EnrolTotp(
                credentialId,
                actor.ProjectId,
                subject,
                string.IsNullOrWhiteSpace(label) ? "Authenticator app" : label,
                sealedSecret.Ciphertext,
                sealedSecret.Nonce,
                parameters,
                actor.ActorId,
                clock.UtcNow);

            await store.SaveCredentialAsync(credential, cancellationToken).ConfigureAwait(false);

            // The audit records that an enrolment happened and for whom. It records no
            // part of the seed, not even a hash: a hash of a 160-bit secret drawn from a
            // known alphabet is still a target, and the audit chain is permanent.
            await AuditAsync(
                actor, credentialId.ToString(), "CredentialEnrolled", "Allowed",
                "TOTP_ENROLLED_SECRET_DISCLOSED_ONCE",
                new
                {
                    Subject = subject,
                    Kind = nameof(CredentialKind.Totp),
                    credential.Label,
                    PhishingResistant = false,
                    parameters.Digits,
                    PeriodSeconds = (int)parameters.Period.TotalSeconds,
                    parameters.Algorithm,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            var uri = Totp.EnrolmentUri(secret, "Cinerion CH1", subject, parameters);
            var base32 = Base32.Encode(secret);
            CryptographicOperations.ZeroMemory(secret);

            return new TotpEnrolment(credential, base32, uri, parameters);
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, subject, "CredentialEnrolmentRejected", "Rejected", error.Code,
                new { Subject = subject, Kind = nameof(CredentialKind.Totp) },
                correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    // --------------------------------------------------------------- passkeys

    /// <summary>
    /// Issues a short-lived, single-use challenge bound to the relying party and origin
    /// it will be answered against.
    /// </summary>
    public async ValueTask<WebAuthnChallenge> BeginPasskeyAssertionAsync(
        string purpose,
        string rpId,
        string origin,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            !StepUpPurpose.All.Contains(purpose ?? string.Empty),
            "STEP_UP_PURPOSE_UNKNOWN",
            "A passkey challenge must name the controlled purpose it will be redeemed for.");
        Guard.Against(
            actor.Kind != ActorKind.Human,
            "AUTH_HUMAN_REQUIRED",
            "A passkey authenticates a person.");

        var credentials = await store
            .ListCredentialsAsync(actor.ProjectId, actor.ActorId, cancellationToken)
            .ConfigureAwait(false);
        // Told plainly rather than issued a challenge nothing could answer, which would
        // look like a broken authenticator instead of an absent enrolment.
        Guard.Against(
            !credentials.Any(item => item.PhishingResistant && item.IsUsable(clock.UtcNow)),
            "PASSKEY_NOT_ENROLLED",
            "This identity holds no usable passkey or security token. Enrol one before " +
            "attempting a phishing-resistant step-up.");

        var challenge = new WebAuthnChallenge(
            Guid.CreateVersion7(),
            actor.ProjectId,
            actor.ActorId,
            RandomNumberGenerator.GetBytes(32),
            rpId,
            origin,
            purpose!,
            clock.UtcNow,
            clock.UtcNow + WebAuthnChallenge.Lifetime,
            null);

        await store.SaveWebAuthnChallengeAsync(challenge, cancellationToken).ConfigureAwait(false);
        await AuditAsync(
            actor, challenge.ChallengeId.ToString(), "PasskeyChallengeIssued", "Allowed",
            "ORIGIN_BOUND_CHALLENGE_ISSUED",
            new { challenge.Purpose, challenge.RpId, challenge.Origin, challenge.ExpiresAt },
            correlationId, cancellationToken).ConfigureAwait(false);

        return challenge;
    }

    /// <summary>
    /// Verifies an assertion and, if it holds, issues a phishing-resistant step-up grant.
    /// <para>
    /// The challenge is consumed before the assertion is judged, so a failed attempt
    /// cannot be retried against the same nonce — replay rejection is the control
    /// api_endpoints.json names on this operation.
    /// </para>
    /// </summary>
    public async ValueTask<(StepUpGrant Grant, CredentialRecord Credential)> CompletePasskeyAssertionAsync(
        Guid challengeId,
        WebAuthnAssertion assertion,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var challenge = await store
            .FindWebAuthnChallengeAsync(challengeId, cancellationToken)
            .ConfigureAwait(false);
        try
        {
            // An unknown challenge and one belonging to someone else answer identically.
            Guard.Against(
                challenge is null
                    || challenge.ProjectId != actor.ProjectId
                    || !string.Equals(challenge.SubjectId, actor.ActorId, StringComparison.Ordinal),
                "PASSKEY_CHALLENGE_NOT_FOUND",
                "No usable challenge matches this assertion.");
            Guard.Against(
                !challenge!.IsRedeemable(clock.UtcNow),
                "PASSKEY_CHALLENGE_SPENT",
                "The challenge has expired or has already been answered. Request a new one.");

            // Consumed first. Everything after this point is judgement on an assertion
            // that can no longer be replayed, whatever the outcome.
            await store
                .SaveWebAuthnChallengeAsync(challenge with { ConsumedAt = clock.UtcNow }, cancellationToken)
                .ConfigureAwait(false);

            var credential = await store
                .FindCredentialByWebAuthnIdAsync(actor.ProjectId, assertion.CredentialId, cancellationToken)
                .ConfigureAwait(false);
            Guard.Against(
                credential is null,
                "PASSKEY_CREDENTIAL_NOT_ENROLLED",
                "The assertion names a credential this project has not enrolled.");
            Guard.Against(
                !credential!.IsUsable(clock.UtcNow),
                "PASSKEY_CREDENTIAL_NOT_USABLE",
                $"The credential is {credential.Status} and cannot be used.");

            var verification = WebAuthnVerifier.Verify(
                assertion, challenge, credential, requireUserVerification: true);

            // Clone detection, then the grant. Order matters: a counter that did not
            // advance must refuse before any authority is issued.
            var observed = credential.ObserveAssertion(verification.SignCount, clock.UtcNow);
            await store.SaveCredentialAsync(observed, cancellationToken).ConfigureAwait(false);

            var grant = StepUpGrant.IssueFromVerifiedPasskey(
                actor, challenge.Purpose, observed, clock.UtcNow);
            await store.SaveStepUpGrantAsync(grant, cancellationToken).ConfigureAwait(false);

            await AuditAsync(
                actor, credential.CredentialId.ToString(), "PasskeyAssertionVerified", "Allowed",
                "ORIGIN_BOUND_ASSERTION_VERIFIED",
                new
                {
                    challenge.Purpose,
                    challenge.Origin,
                    challenge.RpId,
                    Strength = grant.Strength.ToString(),
                    verification.UserVerified,
                    verification.SignCount,
                    GrantId = grant.GrantId,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return (grant, observed);
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, challengeId.ToString(), "PasskeyAssertionRejected", "Rejected", error.Code,
                new { Purpose = challenge?.Purpose, Origin = challenge?.Origin },
                correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    // ---------------------------------------------------- physical credentials

    /// <summary>
    /// Registers a cryptographic physical credential against an identity, on the strength
    /// of a proof of possession this platform verified itself.
    /// <para>
    /// api_endpoints.json makes the control on <c>POST /api/v1/credentials</c> "Proof of
    /// possession, unique identity and lifecycle record". Until now only the last two were
    /// implemented: the public key arrived as a request field and was stored, so a
    /// Cybersecurity Administrator could enrol any key at all — including one they held
    /// themselves — against any subject, and the audit event said
    /// <c>PROOF_OF_POSSESSION_RECORDED</c> about a proof nobody had made. The key now comes
    /// out of the attestation the authenticator signed over a challenge this platform
    /// issued, and <paramref name="enrolmentProof"/> is the result of checking it.
    /// </para>
    /// </summary>
    /// <requirements>CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-CYB-IAM-0001</requirements>
    public async ValueTask<CredentialRecord> RegisterAsync(
        string subjectId,
        CredentialKind kind,
        string label,
        WebAuthnEnrolment? enrolmentProof,
        string? serialNumber,
        string rpId,
        UserVerificationRequirement userVerification,
        DateTimeOffset? expiresAt,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        try
        {
            // Role first, so a caller who could never perform the action is told that
            // rather than told to obtain a step-up they could not use.
            Guard.Against(
                !CanAdministerCredentials(actor),
                "AUTH_CREDENTIAL_ADMINISTRATION",
                "Registering a physical credential requires a Cybersecurity Administrator.");
            Guard.Against(
                string.IsNullOrWhiteSpace(subjectId),
                "CREDENTIAL_SUBJECT_REQUIRED",
                "A credential must name the identity it belongs to.");
            Guard.Against(
                kind == CredentialKind.Totp,
                "CREDENTIAL_KIND_NOT_PHYSICAL",
                "A one-time password is enrolled through POST /api/v1/auth/totp/enrolments, " +
                "not as a physical credential.");

            var credentialId = Guid.CreateVersion7();
            CredentialRecord credential;

            if (kind is CredentialKind.Passkey or CredentialKind.SecurityToken)
            {
                // Not "the caller sent a proof" — "this platform verified one". The
                // endpoint hands over the result of checking the attestation against the
                // step-up grant's own challenge, and everything stored below comes out of
                // that result rather than out of the request body.
                Guard.Against(
                    enrolmentProof is null,
                    "CREDENTIAL_PROOF_OF_POSSESSION_REQUIRED",
                    "A FIDO2 credential is enrolled from a registration this platform verified " +
                    "against a challenge it issued. Obtain a step-up for CredentialAdministration, " +
                    "call navigator.credentials.create() with its challenge, and submit the " +
                    "attestation.");

                var existing = await store
                    .FindCredentialByWebAuthnIdAsync(
                        actor.ProjectId, enrolmentProof!.CredentialId, cancellationToken)
                    .ConfigureAwait(false);
                Guard.Against(
                    existing is not null,
                    "CREDENTIAL_ALREADY_ENROLLED",
                    $"That authenticator is already enrolled to {existing?.SubjectId}. " +
                    "One authenticator handle belongs to one credential record.");

                credential = CredentialRecord.EnrolFido(
                    credentialId, actor.ProjectId, subjectId, kind, label,
                    enrolmentProof.PublicKeySpki, enrolmentProof.CredentialId,
                    enrolmentProof.Aaguid == Guid.Empty ? null : enrolmentProof.Aaguid, rpId,
                    userVerification, actor.ActorId, clock.UtcNow, expiresAt);
            }
            else
            {
                // CH1-CYB-IAM-0001 describes the smart-card ceremony — "a cryptographic
                // credential and reader capable of challenge-response" — and this platform
                // does not perform it: there is no reader here, and no challenge-response
                // exchange with a DESFire-class card. Registering a key nobody proved
                // possession of, against a credential class whose whole purpose is LOCAL
                // PRESENCE at a cell, is exactly the fake success AGENTS.md forbids, so it
                // is refused rather than served.
                //
                // CredentialRecord.EnrolSmartCard stays, tested, for when the ceremony
                // exists. What is unavailable is the claim that this operation performed it.
                _ = serialNumber;
                throw new DomainRuleException(
                    "CREDENTIAL_CEREMONY_NOT_IMPLEMENTED",
                    "Smart-card enrolment needs a reader capable of challenge-response, which " +
                    "this deployment does not have. api_endpoints.json makes proof of possession " +
                    "the control on this operation and it cannot be established for this " +
                    "credential class here; enrol a FIDO2 authenticator instead.");
            }

            await store.SaveCredentialAsync(credential, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor, credentialId.ToString(), "CredentialEnrolled", "Allowed",
                "PROOF_OF_POSSESSION_VERIFIED",
                new
                {
                    Subject = credential.SubjectId,
                    Kind = kind.ToString(),
                    credential.Label,
                    credential.PhishingResistant,
                    UserVerification = userVerification.ToString(),
                    credential.SerialNumber,
                    credential.ExpiresAt,
                    // What the authenticator actually proved, rather than what the request
                    // asserted. CH1-CYB-IAM-0001 requires authentication logs to record the
                    // authenticator class and policy reason.
                    UserVerifiedAtEnrolment = enrolmentProof?.UserVerified,
                    EnrolmentOrigin = enrolmentProof?.Origin,
                    InitialSignCount = enrolmentProof?.SignCount,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return credential;
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, subjectId, "CredentialEnrolmentRejected", "Rejected", error.Code,
                new { Subject = subjectId, Kind = kind.ToString() },
                correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Revokes a credential. The record is kept: a forgotten credential could be
    /// presented elsewhere unnoticed, and CH1-IAM-FR-0006 requires the lifecycle to
    /// remain auditable without deleting history.
    /// </summary>
    public async ValueTask<CredentialRecord> RevokeAsync(
        Guid credentialId,
        string reason,
        ActorContext actor,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var credential = await store.FindCredentialAsync(credentialId, cancellationToken).ConfigureAwait(false);
        try
        {
            Guard.Against(
                !CanAdministerCredentials(actor),
                "AUTH_CREDENTIAL_ADMINISTRATION",
                "Revoking a credential requires a Cybersecurity Administrator.");
            Guard.Against(
                credential is null || credential.ProjectId != actor.ProjectId,
                "CREDENTIAL_NOT_FOUND",
                "The credential does not exist or is outside the caller scope.");

            var revoked = credential!.Revoke(actor.ActorId, reason, clock.UtcNow);
            await store.SaveCredentialAsync(revoked, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor, credentialId.ToString(), "CredentialRevoked", "Allowed",
                "IMMEDIATE_DENYLIST_ENTRY",
                new
                {
                    Subject = revoked.SubjectId,
                    Kind = revoked.Kind.ToString(),
                    revoked.RevocationReason,
                    revoked.RevokedAt,
                },
                correlationId, cancellationToken).ConfigureAwait(false);

            return revoked;
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor, credentialId.ToString(), "CredentialRevocationRejected", "Rejected", error.Code,
                new { Reason = reason }, correlationId, cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    public ValueTask<IReadOnlyList<CredentialRecord>> ListAsync(
        string subjectId,
        ActorContext actor,
        CancellationToken cancellationToken) =>
        store.ListCredentialsAsync(actor.ProjectId, subjectId, cancellationToken);

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        Guid correlationId,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(CredentialRecord),
                objectId,
                correlationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
