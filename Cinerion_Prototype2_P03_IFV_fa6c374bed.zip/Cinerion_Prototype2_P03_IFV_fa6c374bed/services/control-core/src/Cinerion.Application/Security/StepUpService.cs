// Issues and redeems step-up grants. One purpose, short life, single use.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Security;

/// <summary>
/// Issues and redeems purpose-bound step-up grants.
/// <para>
/// Both the granted and the refused path are audited. A refusal is the security
/// event of interest — it records an attempt to reach a sensitive action without
/// recent strong authentication — so it must never be dropped.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-CYB-FR-0006, CH1-NFR-AUD-0001</requirements>
public sealed class StepUpService(ICinerionStore store, ISystemClock clock)
{
    public async ValueTask<StepUpGrant> RequestAsync(
        string purpose,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        try
        {
            var grant = StepUpGrant.Issue(actor, purpose, clock.UtcNow);
            await store.SaveStepUpGrantAsync(grant, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor,
                grant.GrantId.ToString(),
                "StepUpGranted",
                "Allowed",
                "RECENT_AUTHENTICATION_VERIFIED",
                new { grant.Purpose, Strength = grant.Strength.ToString(), grant.AuthenticatedAt, grant.ExpiresAt },
                cancellationToken).ConfigureAwait(false);
            return grant;
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor,
                "step-up-request",
                "StepUpRejected",
                "Rejected",
                error.Code,
                new { RequestedPurpose = purpose, Strength = actor.AuthenticationStrength.ToString() },
                cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>
    /// Redeems a grant for one sensitive action. The grant is consumed before the
    /// caller proceeds, so a failure after this point cannot leave it reusable.
    /// </summary>
    public async ValueTask<StepUpGrant> RedeemAsync(
        Guid grantId,
        string purpose,
        AuthenticationStrength required,
        ActorContext actor,
        CancellationToken cancellationToken)
    {
        var grant = await store.FindStepUpGrantAsync(grantId, cancellationToken).ConfigureAwait(false);
        try
        {
            // An unknown identifier and a grant belonging to someone else are reported
            // identically, so probing cannot distinguish them.
            Guard.Against(grant is null, "STEP_UP_NOT_FOUND", "No usable step-up matches this request.");
            grant!.EnsureUsableBy(actor, purpose, required, clock.UtcNow);
            var consumed = grant.Consume(clock.UtcNow);
            await store.SaveStepUpGrantAsync(consumed, cancellationToken).ConfigureAwait(false);
            await AuditAsync(
                actor,
                consumed.GrantId.ToString(),
                "StepUpRedeemed",
                "Allowed",
                "PURPOSE_BOUND_STEP_UP_CONSUMED",
                new { consumed.Purpose, Strength = consumed.Strength.ToString() },
                cancellationToken).ConfigureAwait(false);
            return consumed;
        }
        catch (DomainRuleException error)
        {
            await AuditAsync(
                actor,
                grantId.ToString(),
                "StepUpRedemptionRejected",
                "Rejected",
                error.Code,
                new { RequestedPurpose = purpose, Required = required.ToString() },
                cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    private ValueTask<AuditEvent> AuditAsync(
        ActorContext actor,
        string objectId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                actor.ActorId,
                actor.Kind,
                actor.ProjectId,
                nameof(StepUpGrant),
                objectId,
                Guid.NewGuid(),
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}
