// Assembles a cell's state in one place, so the command path and the screen can't disagree.

using Cinerion.Application.Abstractions;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Monitoring;

namespace Cinerion.Application.Edge;

/// <summary>
/// The one place a cell's state is assembled, so the command path and the screen cannot
/// disagree about it.
/// <para>
/// That is not tidiness. <c>CommandTransaction.Prepare</c> refuses an intent whose
/// expected-state hash does not equal the cell's own, and the client obtains that hash
/// from <c>GET /api/v1/cells/{cellId}/state</c>. If the read and the command path
/// assembled the cell differently, every preparation would be refused as stale for a
/// reason nobody could see.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-MON-FR-0003, CH1-SAF-FR-0003, CH1-CMD-FR-0002</requirements>
public sealed class CellStateResolver(
    ICinerionStore store,
    CellRuntimeProjection runtime,
    ISystemClock clock)
{
    /// <summary>
    /// The stored cell, overlaid by the controller's report while one is current.
    /// <para>
    /// With no current report the store's own answer is returned unchanged. On PostgreSQL
    /// that answer carries no interlocks — they are not persisted — so the cell reads as
    /// not permissive, which is the safe direction and the whole reason a live report is
    /// needed before equipment can be armed.
    /// </para>
    /// </summary>
    public async ValueTask<ResolvedCellState?> ResolveAsync(Guid cellId, CancellationToken cancellationToken)
    {
        var stored = await store.FindCellAsync(cellId, cancellationToken).ConfigureAwait(false);
        if (stored is null)
        {
            return null;
        }

        var now = clock.UtcNow;
        var report = runtime.FindCurrent(cellId, now);
        if (report is null)
        {
            var latest = runtime.FindLatest(cellId);
            return new ResolvedCellState(
                stored.Snapshot,
                Observe(stored.Observation, latest?.ReceivedAt, now),
                ReportedPermissives.NotReported,
                null);
        }

        return new ResolvedCellState(
            report.ToCellState(stored.Snapshot),
            new CellObservation(report.Freshness, DataQuality.Good, report.ReceivedAt),
            report.Permissives,
            report);
    }

    /// <summary>
    /// Freshness judged from when the cell was last heard from, never asserted.
    /// <para>
    /// The order matters. A cell nothing has ever reported for is <c>Unknown</c>, not
    /// <c>Disconnected</c>: this service has no evidence that a link was ever established,
    /// which is the same distinction <c>MonitoringService.ResolveFreshnessAsync</c> makes
    /// for telemetry. A cell that was reported and has since gone quiet is <c>Stale</c>.
    /// Only a report inside the window keeps the freshness it declared, and that value is
    /// never upgraded — a simulator's report stays <c>Simulated</c>.
    /// </para>
    /// </summary>
    private static CellObservation Observe(
        CellObservation stored,
        DateTimeOffset? lastReportReceivedAt,
        DateTimeOffset now)
    {
        var sourceTimestamp = lastReportReceivedAt ?? stored.SourceTimestamp;

        // ch1.cells.source_timestamp is NOT NULL, so a registered cell always carries one
        // — it is stamped when the registration row is written. Age alone would therefore
        // report a cell nobody has ever reported for as Stale, which claims a link once
        // existed. The stored freshness is what distinguishes the two: SaveCellRegistration
        // writes Unknown, and only a controller report replaces it.
        if (sourceTimestamp is null || (lastReportReceivedAt is null && stored.Freshness == Freshness.Unknown))
        {
            return CellObservation.NeverReported;
        }

        return now - sourceTimestamp.Value > CellRuntimeProjection.ValidFor
            ? new CellObservation(Freshness.Stale, stored.Quality, sourceTimestamp)
            : stored with { SourceTimestamp = sourceTimestamp };
    }
}

/// <summary>
/// A cell as the platform can honestly describe it right now: the state, how current it
/// is, and what the controller did or did not answer about its permissives.
/// </summary>
public sealed record ResolvedCellState(
    CellSnapshot Snapshot,
    CellObservation Observation,
    ReportedPermissives Permissives,
    ControllerReport? Report);
