// What a controller reported about its local inputs, and whether it reported them at all.

using Cinerion.Domain.Commands;
using Cinerion.Domain.Monitoring;

namespace Cinerion.Application.Edge;

/// <summary>
/// The local inputs a controller reports, and whether it reported them at all.
/// <para>
/// <see cref="Reported"/> is the field that matters. The controlled OPC UA and Modbus
/// profiles both declare <c>207 PRELIMINARY_PERMISSIVE_INVALID</c> as a deferred check:
/// the S7-1200 G2 reads <c>UDT_CH1_Permissives</c> from wired inputs, and a stand-in has
/// no wired inputs to read. A gateway in front of such a controller must be able to say
/// "not answered", because the only alternative is inventing the answer that decides
/// whether a machine may move.
/// </para>
/// <para>
/// When <see cref="Reported"/> is false every other member here is meaningless, and
/// <see cref="ToCellState"/> resolves the cell as not permissive.
/// </para>
/// </summary>
/// <requirements>CH1-SAF-FR-0003, CH1-CMD-FR-0002, CH1-AUT-FDS-0001</requirements>
public sealed record ReportedPermissives(
    bool Reported,
    bool ControllerOnline,
    bool StartEnable,
    bool StopCircuitHealthy,
    bool GuardHealthy,
    bool ActuatorHome,
    bool ButtonPressed,
    bool FaultCauseActive,
    IReadOnlyList<uint> DeferredCheckCodes)
{
    public static readonly ReportedPermissives NotReported =
        new(false, false, false, false, false, false, false, false, []);

    /// <summary>
    /// Value comparison, stated rather than inherited. The compiler-generated equality of
    /// a positional record compares <see cref="DeferredCheckCodes"/> by reference, so two
    /// identical reports arriving as separate messages would never compare equal and every
    /// heartbeat would be recorded as a change.
    /// </summary>
    public bool SameAs(ReportedPermissives other) =>
        Reported == other.Reported &&
        ControllerOnline == other.ControllerOnline &&
        StartEnable == other.StartEnable &&
        StopCircuitHealthy == other.StopCircuitHealthy &&
        GuardHealthy == other.GuardHealthy &&
        ActuatorHome == other.ActuatorHome &&
        ButtonPressed == other.ButtonPressed &&
        FaultCauseActive == other.FaultCauseActive &&
        DeferredCheckCodes.SequenceEqual(other.DeferredCheckCodes);
}

/// <summary>
/// One controller's report of itself, as EdgeLink observed it and Control Core received
/// it.
/// <para>
/// This is never written to <c>ch1.cells</c> in full, and that is deliberate: interlocks,
/// controller boot identity and button state are sampled each cycle, and restoring them
/// from a database would present a stale permissive as a current one. CH1-SAF-FR-0003
/// requires a restart to default to a non-energising safe state, so this record lives in
/// memory for as long as <see cref="CellRuntimeProjection.ValidFor"/> and no longer.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-SAF-FR-0003, CH1-MON-FR-0003</requirements>
public sealed record ControllerReport(
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    string ControllerId,
    Guid ControllerBootId,
    CellOperatingState OperatingState,
    string ConfigurationRevision,
    ReportedPermissives Permissives,
    string AdapterId,
    string Protocol,
    string SecurityProfile,
    string FirmwareVersion,
    Freshness Freshness,
    long Sequence,
    string MessageId,
    DateTimeOffset ObservedAt,
    DateTimeOffset ReceivedAt,
    string GatewayIdentity)
{
    /// <summary>
    /// The cell as this report says it is, laid over the identity and assignments the
    /// store already holds.
    /// <para>
    /// The assignments — asset, work order and part — are taken from the stored record
    /// rather than from the report. A gateway observes equipment; it does not decide
    /// which work order is loaded, and a report that could move a part between cells
    /// would be a controller rewriting the digital thread.
    /// </para>
    /// </summary>
    public CellSnapshot ToCellState(CellSnapshot stored) => stored with
    {
        ControllerId = ControllerId,
        ControllerBootId = ControllerBootId,
        OperatingState = OperatingState,
        ConfigurationRevision = ConfigurationRevision,
        ControllerOnline = Permissives.Reported && Permissives.ControllerOnline,
        StartEnable = Permissives.Reported && Permissives.StartEnable,
        StopCircuitHealthy = Permissives.Reported && Permissives.StopCircuitHealthy,
        GuardHealthy = Permissives.Reported && Permissives.GuardHealthy,
        ActuatorHome = Permissives.Reported && Permissives.ActuatorHome,
        ButtonPressed = Permissives.Reported && Permissives.ButtonPressed,

        // A fault cause that was not reported is not evidence that there is none. It
        // makes no difference to whether the cell is permissive — an unreported
        // permissive already refuses that — but reporting "no fault" for a controller
        // that said nothing would be the wrong half of the pair to guess at.
        FaultCauseActive = !Permissives.Reported || Permissives.FaultCauseActive,
    };

    /// <summary>
    /// What changed between two reports, for the audit chain. A heartbeat every couple of
    /// seconds must not become an audit event every couple of seconds — CH1-DBA-DD-0001
    /// warns against an uncontrolled permanent record — so only these transitions are
    /// recorded.
    /// </summary>
    public bool IsMateriallyDifferentFrom(ControllerReport? previous) =>
        previous is null ||
        previous.ControllerBootId != ControllerBootId ||
        previous.OperatingState != OperatingState ||
        !previous.Permissives.SameAs(Permissives) ||
        !StringComparer.Ordinal.Equals(previous.ConfigurationRevision, ConfigurationRevision) ||
        previous.Freshness != Freshness;
}
