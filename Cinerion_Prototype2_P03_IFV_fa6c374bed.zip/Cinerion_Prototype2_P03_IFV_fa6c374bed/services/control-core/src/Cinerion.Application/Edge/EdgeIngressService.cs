// Takes gateway messages in, checks who sent them and whether they make sense, then files
// them.

using Cinerion.Application.Abstractions;
using Cinerion.Application.Monitoring;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Edge;

/// <summary>
/// Who the peer on the other end of the gRPC edge turned out to be.
/// <para>
/// Built from the mutual-TLS client certificate the transport verified, never from
/// anything a message says about itself. CH1-COM-ICD-0001: "the receiver validates
/// schema, authority, state and bounds" and "neither endpoint assumes that a connected
/// peer is trustworthy merely because communication succeeds".
/// </para>
/// </summary>
public sealed record GatewayPeer(string GatewayIdentity, string CertificateThumbprint);

/// <summary>
/// The receiving half of CH1-COM-IF-0003.
/// <para>
/// Everything a gateway offers arrives here, and nothing is taken on trust: the schema
/// version, the identity in the envelope, the project, the enrolled device, its trust
/// state, its cell assignment, the message's age and its ordering are all checked before
/// a single field of the payload reaches the domain. The device checks are the same ones
/// telemetry has always had, because a controller reporting its own permissives is at
/// least as security-relevant as one reporting a temperature.
/// </para>
/// <para>
/// There is deliberately no operation on this service that commands equipment. A gateway
/// can report what it observed and answer a command the domain issued; it cannot ask for
/// motion. CH1-AUT-FDS-0001 puts the commit behind a cryptographic credential proof and a
/// physical button edge at the cell, and CH1-CYB-TMD-0001 treats any path that could arm
/// equipment without them as a priority threat case.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-COM-FR-0007, CH1-COM-FR-0010, CH1-CYB-FR-0001, CH1-MON-FR-0003</requirements>
public sealed class EdgeIngressService(
    ICinerionStore store,
    CellRuntimeProjection runtime,
    MonitoringService monitoring,
    ISystemClock clock)
{
    /// <summary>
    /// The one schema version this build understands. CH1-COM-ICD-0001 makes unknown
    /// mandatory semantics fail closed, so a peer built against another major version is
    /// refused rather than partly understood.
    /// </summary>
    public const string SchemaVersion = "1.0.0";

    /// <summary>The identity a gateway must address, so a misrouted report is refused.</summary>
    public const string ControlCoreIdentity = "cinerion-control-core";

    /// <summary>
    /// How far ahead of this service's clock a report may be stamped. Commands expire and
    /// telemetry is judged by age, so a peer whose clock runs fast could otherwise hold a
    /// permissive current indefinitely.
    /// </summary>
    public static readonly TimeSpan ClockLead = TimeSpan.FromSeconds(30);

    /// <summary>Records what a controller reports about itself.</summary>
    public async ValueTask<ControllerReport> PublishControllerStateAsync(
        GatewayPeer peer,
        ControllerReportInput input,
        CancellationToken cancellationToken)
    {
        var now = clock.UtcNow;
        ValidateEnvelope(peer, input.Envelope, now);
        Guard.Against(
            input.ControllerBootId == Guid.Empty,
            "INGRESS_BOOT_IDENTITY_REQUIRED",
            "A controller must report the boot identity a prepared command is bound to.");
        Guard.Against(
            string.IsNullOrWhiteSpace(input.ConfigurationRevision),
            "INGRESS_CONFIGURATION_REVISION_REQUIRED",
            "A controller must report the controlled configuration revision it is running.");

        // Never Live for a controller that said Simulated, and never upgraded here. The
        // gateway states what it observed; this service records it.
        Guard.Against(
            input.Freshness is Freshness.Unknown,
            "INGRESS_FRESHNESS_REQUIRED",
            "A controller report must state the freshness of what was observed.");

        var device = await RequireTrustedDeviceAsync(
            input.ControllerId, input.Envelope.ProjectId, input.Envelope.CellId, cancellationToken).ConfigureAwait(false);

        var stored = await store.FindCellAsync(input.Envelope.CellId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            stored is null || stored.Snapshot.ProjectId != device.ProjectId,
            "INGRESS_CELL_NOT_FOUND",
            "The cell does not exist or is outside the reporting device's project.");
        Guard.Against(
            input.Envelope.SiteId != Guid.Empty && input.Envelope.SiteId != stored!.Snapshot.SiteId,
            "INGRESS_SITE_MISMATCH",
            "The report names a site the cell does not belong to.");

        var report = new ControllerReport(
            device.ProjectId,
            stored!.Snapshot.SiteId,
            input.Envelope.CellId,
            stored.Snapshot.AssetId,
            input.ControllerId,
            input.ControllerBootId,
            input.OperatingState,
            input.ConfigurationRevision,
            input.Permissives,
            input.AdapterId,
            input.Protocol,
            input.SecurityProfile,
            input.FirmwareVersion,
            input.Freshness,
            input.Envelope.Sequence,
            input.Envelope.MessageId,
            input.Envelope.OccurredAt,
            now,
            peer.GatewayIdentity);

        var previous = runtime.Accept(report);

        // The durable half only. Interlocks, boot identity and button state are not
        // written anywhere: restoring them would present a stale permissive as a current
        // one, which CH1-SAF-FR-0003 forbids. What is stored is what a restart may safely
        // remember — identity, operating state, configuration revision, and when the cell
        // was last heard from, which is what makes freshness computable rather than
        // asserted.
        await store.SaveCellAsync(
            report.ToCellState(stored.Snapshot),
            new CellObservation(report.Freshness, DataQuality.Good, now),
            cancellationToken).ConfigureAwait(false);

        // A heartbeat every couple of seconds must not become an audit event every couple
        // of seconds. CH1-DBA-DD-0001 warns against an uncontrolled permanent record, and
        // the chain is append-only, so only a material change is recorded: the first
        // report, a reboot, a change of operating state, of configuration revision, of
        // freshness, or any movement in the permissives.
        if (report.IsMateriallyDifferentFrom(previous))
        {
            await AuditAsync(
                peer,
                report.ProjectId,
                "Cell",
                report.CellId.ToString(),
                CorrelationOf(input.Envelope),
                "ControllerStateReported",
                "Allowed",
                report.Permissives.Reported
                    ? "CONTROLLER_REPORT_ACCEPTED"
                    : "PERMISSIVES_NOT_REPORTED_CELL_NOT_PERMISSIVE",
                new
                {
                    report.ControllerId,
                    report.ControllerBootId,
                    OperatingState = report.OperatingState.ToString(),
                    report.ConfigurationRevision,
                    report.Permissives.Reported,
                    DeferredChecks = report.Permissives.DeferredCheckCodes,
                    Freshness = report.Freshness.ToString(),
                    report.AdapterId,
                    report.Protocol,
                    report.SecurityProfile,
                    Rebooted = previous is not null && previous.ControllerBootId != report.ControllerBootId,
                },
                cancellationToken).ConfigureAwait(false);
        }

        return report;
    }

    /// <summary>
    /// Records a transition the gateway observed at the controller.
    /// <para>
    /// It writes an audit event and <b>changes no cell state</b>, which is what makes it
    /// safe to accept late. A controller event may have been sitting in the gateway's buffer
    /// for twenty hours; a state report that old would be refused for exactly that reason,
    /// but "the guard opened at 03:14" is as true now as it was then. The permanence is the
    /// point — without this, a fault that latched and cleared during an outage would leave
    /// no trace anywhere.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COM-IF-0003, CH1-NFR-REL-0001, CH1-NFR-AUD-0001</requirements>
    public async ValueTask<ControllerEventRecord> PublishControllerEventAsync(
        GatewayPeer peer,
        ControllerEventInput input,
        CancellationToken cancellationToken)
    {
        var now = clock.UtcNow;

        // The envelope's own expiry is still honoured, and a controller event never carries
        // one: expiry is how a *command* is bounded, and applying it to evidence would make
        // a long outage delete its own record of itself.
        ValidateEnvelope(peer, input.Envelope, now);
        Guard.Against(
            string.IsNullOrWhiteSpace(input.Kind) || input.Kind == "Unspecified",
            "INGRESS_EVENT_KIND_REQUIRED",
            "A controller event must name the transition it reports.");

        var device = await RequireTrustedDeviceAsync(
            input.ControllerId, input.Envelope.ProjectId, input.Envelope.CellId, cancellationToken).ConfigureAwait(false);

        var record = new ControllerEventRecord(
            device.ProjectId,
            input.Envelope.CellId,
            input.ControllerId,
            input.Kind,
            input.ReasonCode,
            input.ObservedAt,
            now);

        // Same reason as telemetry, and it matters more here: the audit chain is
        // append-only, so a replayed transition is a second permanent record of one event
        // that an investigator would read as two.
        runtime.RegisterMessage(input.Envelope.MessageId, now);

        await AuditAsync(
            peer,
            record.ProjectId,
            "Cell",
            record.CellId.ToString(),
            CorrelationOf(input.Envelope),
            "ControllerEventObserved",
            "Observed",
            // Stated on every event: a controller reporting what happened is not the domain
            // deciding that anything may happen next.
            "CONTROLLER_TRANSITION_IS_NOT_COMMAND_AUTHORITY",
            new
            {
                record.ControllerId,
                input.ControllerBootId,
                record.Kind,
                record.ReasonCode,
                input.PreviousState,
                input.CurrentState,
                input.PreviousPermissivesReported,
                input.CurrentPermissivesReported,
                input.PreviousConfigurationRevision,
                input.ConfigurationRevision,
                input.AdapterId,
                ObservedAt = record.ObservedAt,
                // How late the evidence is. A non-trivial value is the gateway's buffer
                // doing its job, and it belongs in the record rather than in a log nobody
                // keeps.
                DeliveryLagSeconds = Math.Max(0, (now - record.ObservedAt).TotalSeconds),
            },
            cancellationToken).ConfigureAwait(false);

        return record;
    }

    /// <summary>Offers readings for storage and alarm evaluation through the ordinary path.</summary>
    public async ValueTask<TelemetryIngestionResult> PublishTelemetryAsync(
        GatewayPeer peer,
        TelemetryPublicationInput input,
        CancellationToken cancellationToken)
    {
        var now = clock.UtcNow;
        ValidateEnvelope(peer, input.Envelope, now);
        Guard.Against(
            input.Readings.Count == 0,
            "INGRESS_TELEMETRY_EMPTY",
            "A telemetry publication must carry at least one reading.");
        Guard.Against(
            input.Readings.Count > MaximumReadingsPerPublication,
            "INGRESS_TELEMETRY_BATCH_TOO_LARGE",
            $"A telemetry publication may carry at most {MaximumReadingsPerPublication} readings.");

        var device = await RequireTrustedDeviceAsync(
            input.DeviceId, input.Envelope.ProjectId, input.Envelope.CellId, cancellationToken).ConfigureAwait(false);

        foreach (var reading in input.Readings)
        {
            Guard.Against(
                reading.SampledAt > now + ClockLead,
                "INGRESS_SAMPLE_FROM_FUTURE",
                "A reading is stamped further ahead of this service than the permitted clock lead.");
        }

        // Duplicate suppression, applied here for the same reason it is applied to a
        // controller report: the gateway's buffer removes a record only once this service
        // has answered for it, so a gateway that dies between the answer and the removal
        // replays on restart. Until CH1-NFR-REL-0001's buffer existed nothing ever replayed
        // a reading, and the envelope's own comment — "a message identifier is required for
        // duplicate suppression" — was true of controller state and of nothing else.
        //
        // Registered after every check has passed and immediately before the readings are
        // stored, so a refused publication does not burn its identifier and an accepted one
        // cannot be counted twice.
        runtime.RegisterMessage(input.Envelope.MessageId, now);

        // Straight into the path a gateway has always been meant to use. Channel and unit
        // are checked against the controlled catalogue, the device's enrolled capability
        // manifest narrows it further, and the alarm rules are evaluated over the result -
        // none of which is duplicated here, because a second implementation of those
        // checks is a second place for them to differ.
        return await monitoring.IngestAsync(
            device.ProjectId,
            [.. input.Readings.Select(reading => new TelemetryReading(
                input.Envelope.CellId,
                input.DeviceId,
                reading.ChannelId,
                reading.Value,
                reading.Unit,
                reading.Quality,
                reading.Freshness,
                reading.SampledAt,
                // Carried through unchanged. This is the whole of the fix for defect 59:
                // the gateway now has somewhere to put what the device declared, and this
                // service stores it rather than substituting its own clock's quality.
                reading.SourceTimeQuality))],
            cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Records a controller's answer to a command the domain prepared.
    /// <para>
    /// It changes no command state, and that is the point. The CH1 command state machine
    /// advances on a cryptographic credential proof and a physical button edge, never on a
    /// controller saying it received something — CH1-COM-PRO-0001 puts it plainly for the
    /// broker case, "a QoS acknowledgement is never treated as physical execution", and
    /// the same holds here. An acknowledgement naming a command Control Core never issued
    /// is refused outright: a controller answers transactions, it does not introduce them.
    /// </para>
    /// </summary>
    public async ValueTask<CommandTransaction> AcknowledgeCommandAsync(
        GatewayPeer peer,
        CommandAcknowledgementInput input,
        CancellationToken cancellationToken)
    {
        var now = clock.UtcNow;
        ValidateEnvelope(peer, input.Envelope, now);

        var device = await RequireTrustedDeviceAsync(
            input.ControllerId, input.Envelope.ProjectId, input.Envelope.CellId, cancellationToken).ConfigureAwait(false);

        var command = await store.FindCommandAsync(input.CommandId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            command is null || command.Intent.ProjectId != device.ProjectId,
            "INGRESS_COMMAND_NOT_FOUND",
            "The acknowledgement names a command this platform did not issue.");
        Guard.Against(
            command!.Intent.CellId != input.Envelope.CellId,
            "INGRESS_COMMAND_CELL_MISMATCH",
            "The acknowledgement names a command prepared for another cell.");

        // The command's own correlation identity, not the envelope's, and not a new one.
        // This row is the controller's answer to a transaction the domain opened, and
        // step 7 of the controlled PREPARE / LOCAL COMMIT sequence — "correlate
        // telemetry, result and audit evidence" — is reachable only if the answer is
        // filed under the same identity as the question. The gateway's own correlation
        // identifier is carried in the payload rather than discarded, so the message that
        // delivered the answer stays traceable too.
        await AuditAsync(
            peer,
            command.Intent.ProjectId,
            nameof(CommandTransaction),
            command.CommandId.ToString(),
            command.CorrelationId,
            "ControllerAcknowledgementRecorded",
            input.Accepted ? "Acknowledged" : "Refused",
            // Stated on every event: the controller's answer is evidence about delivery,
            // never authority to execute.
            "ACKNOWLEDGEMENT_IS_NOT_EXECUTION_AUTHORITY",
            new
            {
                command.CommandId,
                input.ControllerId,
                input.Accepted,
                input.ControllerState,
                input.ReasonCode,
                input.ObservedAt,
                input.AdapterId,
                CommandState = command.State.ToString(),
                MessageCorrelationId = input.Envelope.CorrelationId,
                input.Envelope.MessageId,
            },
            cancellationToken).ConfigureAwait(false);

        return command;
    }

    /// <summary>
    /// Records a refusal, so a rejected report is evidence rather than a silence.
    /// <para>
    /// <paramref name="correlationId"/> is the correlation identifier the refused message
    /// carried, when it carried a usable one. A message refused because its envelope was
    /// malformed may have carried nothing, or nonsense; that row is stamped with an
    /// identity of its own and is honest about the fact, because the alternative — filing
    /// it under a correlation the sender chose but this service never validated — would
    /// let a rejected message attach itself to someone else's trace.
    /// </para>
    /// </summary>
    public ValueTask<AuditEvent> AuditRefusalAsync(
        GatewayPeer peer,
        Guid projectId,
        string eventType,
        string objectId,
        DomainRuleException error,
        Guid? correlationId,
        CancellationToken cancellationToken) =>
        AuditAsync(
            peer,
            projectId,
            "Cell",
            objectId,
            correlationId ?? Guid.NewGuid(),
            eventType,
            "Rejected",
            error.Code,
            new { Error = error.Code, peer.GatewayIdentity, Correlated = correlationId is not null },
            cancellationToken);

    private const int MaximumReadingsPerPublication = 256;

    /// <summary>
    /// Every controlled field of the envelope, checked before any payload is looked at.
    /// </summary>
    private static void ValidateEnvelope(GatewayPeer peer, IngressEnvelope envelope, DateTimeOffset now)
    {
        Guard.Against(
            !StringComparer.Ordinal.Equals(envelope.SchemaVersion, SchemaVersion),
            "INGRESS_SCHEMA_UNSUPPORTED",
            $"This build speaks CH1 edge schema {SchemaVersion}; unknown mandatory semantics fail closed.");

        // The identity in the message must be the identity the certificate attests. A
        // gateway does not get to name itself: mutual TLS already decided who it is, and
        // an envelope claiming another source is either misconfigured or dishonest.
        Guard.Against(
            !StringComparer.Ordinal.Equals(envelope.SourceId, peer.GatewayIdentity),
            "INGRESS_SOURCE_IDENTITY_MISMATCH",
            "The envelope names a source other than the identity the peer certificate attests.");
        Guard.Against(
            !StringComparer.Ordinal.Equals(envelope.DestinationId, ControlCoreIdentity),
            "INGRESS_DESTINATION_MISMATCH",
            "The envelope is addressed to another destination.");
        Guard.Against(
            string.IsNullOrWhiteSpace(envelope.MessageId) || envelope.MessageId.Length > 128,
            "INGRESS_MESSAGE_ID_REQUIRED",
            "A message identifier is required for duplicate suppression.");

        // CH1-COM-ICD-0001 lists the correlation ID among the fields every controlled
        // message carries, and CH1-CYB-FR-0006 requires a security event to carry
        // "correlation data". This field was decoded and then dropped: every audit row
        // this service wrote was stamped with a freshly generated GUID, so nothing a
        // gateway published could ever be joined to anything else — including a
        // controller's answer to a command, which is the one join the controlled
        // PREPARE / LOCAL COMMIT sequence names outright (defect 76). It is validated
        // here, with the other mandatory envelope fields, because a correlation
        // identifier that is not required is a correlation identifier that will be
        // absent exactly when an investigator needs it.
        Guard.Against(
            !Guid.TryParse(envelope.CorrelationId, out var correlation) || correlation == Guid.Empty,
            "INGRESS_CORRELATION_REQUIRED",
            "A correlation identifier is required on every controlled message.");
        Guard.Against(
            envelope.Sequence <= 0,
            "INGRESS_SEQUENCE_INVALID",
            "A message sequence number must be positive.");
        Guard.Against(
            envelope.ProjectId == Guid.Empty || envelope.CellId == Guid.Empty,
            "INGRESS_SCOPE_REQUIRED",
            "Project and cell scope are required on every controlled message.");
        Guard.Against(
            envelope.OccurredAt > now + ClockLead,
            "INGRESS_MESSAGE_FROM_FUTURE",
            "The message is stamped further ahead of this service than the permitted clock lead.");
        Guard.Against(
            envelope.ExpiresAt is { } expiry && expiry <= now,
            "INGRESS_MESSAGE_EXPIRED",
            "The message expired before it was received and is not stored late.");
    }

    /// <summary>
    /// The device trust checks, in one place. Identical in substance to the ones telemetry
    /// has always had: enrolled in this project, still trusted, and assigned to the cell it
    /// reports for. Trust is read from the stored record and can never be asserted by the
    /// message.
    /// </summary>
    private async ValueTask<Domain.Assets.DeviceRecord> RequireTrustedDeviceAsync(
        string deviceId,
        Guid claimedProjectId,
        Guid cellId,
        CancellationToken cancellationToken)
    {
        Guard.Against(
            string.IsNullOrWhiteSpace(deviceId),
            "INGRESS_DEVICE_REQUIRED",
            "A controlled message must name the device it came from.");

        var device = await store.FindDeviceAsync(deviceId, cancellationToken).ConfigureAwait(false);
        Guard.Against(
            device is null,
            "INGRESS_DEVICE_NOT_ENROLLED",
            "The message names a device that is not enrolled.");
        Guard.Against(
            device!.ProjectId != claimedProjectId,
            "INGRESS_PROJECT_MISMATCH",
            "The envelope names a project the device does not belong to.");
        Guard.Against(
            !device.IsTrusted,
            "INGRESS_DEVICE_NOT_TRUSTED",
            "The device's trust has been revoked or was never established.");
        Guard.Against(
            device.CellId != cellId,
            "INGRESS_DEVICE_CELL_MISMATCH",
            "The device is not assigned to the cell the message claims.");
        return device;
    }

    /// <summary>
    /// The correlation identity a record inherits from the message that produced it.
    /// <para>
    /// Every caller passes one explicitly. There is deliberately no overload that mints a
    /// GUID here: that is what this service used to do, and a per-row random correlation
    /// is not correlation data — it has the shape of a join key and joins nothing.
    /// </para>
    /// </summary>
    private static Guid CorrelationOf(IngressEnvelope envelope) => Guid.Parse(envelope.CorrelationId);

    private ValueTask<AuditEvent> AuditAsync(
        GatewayPeer peer,
        Guid projectId,
        string objectType,
        string objectId,
        Guid correlationId,
        string eventType,
        string decision,
        string reasonCode,
        object payload,
        CancellationToken cancellationToken) =>
        store.AppendAuditAsync(
            new AuditInput(
                eventType,
                peer.GatewayIdentity,
                ActorKind.Device,
                projectId,
                objectType,
                objectId,
                correlationId,
                clock.UtcNow,
                decision,
                reasonCode,
                payload,
                clock.TimeQuality),
            cancellationToken);
}

/// <summary>The controlled envelope, decoded from the wire and not yet trusted.</summary>
public sealed record IngressEnvelope(
    string SchemaVersion,
    string MessageType,
    string MessageId,
    string CorrelationId,
    string SourceId,
    string DestinationId,
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    long Sequence,
    DateTimeOffset OccurredAt,
    DateTimeOffset? ExpiresAt);

public sealed record ControllerReportInput(
    IngressEnvelope Envelope,
    string ControllerId,
    Guid ControllerBootId,
    CellOperatingState OperatingState,
    string ConfigurationRevision,
    ReportedPermissives Permissives,
    string AdapterId,
    string Protocol,
    string SecurityProfile,
    string FirmwareVersion,
    Freshness Freshness);

public sealed record TelemetryReadingInput(
    string ChannelId,
    double Value,
    string Unit,
    DataQuality Quality,
    Freshness Freshness,
    DateTimeOffset SampledAt,
    long Sequence,
    /// <summary>
    /// What the SOURCE declared about the clock that stamped <paramref name="SampledAt"/>.
    /// <c>null</c> when it declared nothing, which is stored as nothing.
    /// </summary>
    string? SourceTimeQuality = null);

public sealed record TelemetryPublicationInput(
    IngressEnvelope Envelope,
    string DeviceId,
    IReadOnlyList<TelemetryReadingInput> Readings);

public sealed record ControllerEventInput(
    IngressEnvelope Envelope,
    string ControllerId,
    string ControllerBootId,
    string Kind,
    string ReasonCode,
    string PreviousState,
    string CurrentState,
    bool PreviousPermissivesReported,
    bool CurrentPermissivesReported,
    string PreviousConfigurationRevision,
    string ConfigurationRevision,
    string AdapterId,
    DateTimeOffset ObservedAt);

/// <summary>A transition, as the domain recorded it.</summary>
public sealed record ControllerEventRecord(
    Guid ProjectId,
    Guid CellId,
    string ControllerId,
    string Kind,
    string ReasonCode,
    DateTimeOffset ObservedAt,
    DateTimeOffset ReceivedAt);

public sealed record CommandAcknowledgementInput(
    IngressEnvelope Envelope,
    Guid CommandId,
    string ControllerId,
    bool Accepted,
    string ControllerState,
    string ReasonCode,
    DateTimeOffset ObservedAt,
    string AdapterId);
