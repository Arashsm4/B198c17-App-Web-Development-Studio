// What each controller last reported, kept in memory only. Fresh news, never archived.

using System.Collections.Concurrent;
using Cinerion.Domain.Common;

namespace Cinerion.Application.Edge;

/// <summary>
/// The volatile half of cell state: what each controller last reported, held in memory
/// and never written anywhere.
/// <para>
/// It is a singleton because the state it holds belongs to the process rather than to a
/// request, and because it must survive the per-request store scope that PostgreSQL mode
/// uses. It is deliberately not durable. Restoring interlocks from a database would
/// present a stale permissive as a current one, and CH1-SAF-FR-0003 requires a restart to
/// default to a non-energising safe state — so after a restart every cell reads as not
/// permissive until a controller reports again, and a prepared command is refused until
/// then. This is the same settled decision that keeps <c>ch1.cells</c> free of interlock
/// columns; the projection is where the live answer lives instead.
/// </para>
/// <para>
/// Duplicate suppression and ordering are both here, because CH1-COM-FR-0010 requires the
/// gateway path to apply them and CH1-COM-ICD-0001 states them as message ID and sequence
/// windows. A message identifier already seen inside the window is refused, and a report
/// older than the one already held is refused rather than allowed to overwrite it — an
/// out-of-order delivery must not be able to reinstate a permissive that has since gone.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-COM-FR-0010, CH1-SAF-FR-0003, CH1-CMD-FR-0009</requirements>
public sealed class CellRuntimeProjection
{
    /// <summary>
    /// How long a controller's report stands before the cell reads as not permissive
    /// again.
    /// <para>
    /// Deliberately far tighter than the 30 s <c>MonitoringService.StaleAfter</c> that
    /// governs a telemetry projection. A stale temperature is a reading an operator can
    /// judge for themselves; a stale permissive is the state a prepared command is
    /// authorised against, and presenting one as current is the single failure this whole
    /// handshake exists to prevent. The gateway publishes far more often than this, so
    /// expiry means the link is gone rather than that a report was late.
    /// </para>
    /// </summary>
    public static readonly TimeSpan ValidFor = TimeSpan.FromSeconds(10);

    /// <summary>
    /// How long a message identifier is remembered for duplicate suppression. Bounded so
    /// the window cannot grow without limit, which is the "flow control caps memory"
    /// obligation in CH1-COM-PRO-0001.
    /// </summary>
    public static readonly TimeSpan DuplicateWindow = TimeSpan.FromMinutes(5);

    /// <summary>
    /// How many message identifiers the window may hold before it is emptied.
    /// <para>
    /// <b>Sized against the controlled baseline load, not chosen.</b> CH1-NFR-PER-0001
    /// requires 100 sustained telemetry messages per second, and
    /// <see cref="DuplicateWindow"/> is five minutes — so honouring the stated window at the
    /// stated load takes 30 000 identifiers. The previous bound was 8192, which is 82
    /// seconds of baseline traffic: past that the window emptied itself and duplicate
    /// suppression silently degraded to a fraction of what it documents, exactly when the
    /// system is busiest. Found by running the baseline load rather than by reading this
    /// constant.
    /// </para>
    /// <para>
    /// It is still a bound, which is what CH1-COM-PRO-0001's "flow control caps memory"
    /// asks for. 32 768 identifiers is a few megabytes and covers the baseline rate with
    /// room above it; a deployment past that empties the window for one period rather than
    /// growing without limit.
    /// </para>
    /// </summary>
    private const int MaximumRememberedMessages = 32_768;

    private readonly ConcurrentDictionary<Guid, ControllerReport> _byCell = new();
    private readonly ConcurrentDictionary<string, DateTimeOffset> _seenMessages = new(StringComparer.Ordinal);
    private readonly Lock _gate = new();

    /// <summary>
    /// Records a report, or refuses it. The previous report is returned so a caller can
    /// tell whether anything material changed without a second lookup.
    /// </summary>
    public ControllerReport? Accept(ControllerReport report)
    {
        lock (_gate)
        {
            PruneSeenMessages(report.ReceivedAt);
            Guard.Against(
                _seenMessages.ContainsKey(report.MessageId),
                "INGRESS_DUPLICATE_MESSAGE",
                "This message identifier has already been received inside the duplicate-suppression window.");

            var previous = _byCell.GetValueOrDefault(report.CellId);

            // Ordering, not merely duplication. A report that left the gateway before the
            // one already held must not overwrite it: the older one may still say the
            // guard was closed after the newer one said it had opened.
            Guard.Against(
                previous is not null && report.ObservedAt < previous.ObservedAt,
                "INGRESS_REPORT_SUPERSEDED",
                "A newer controller report for this cell has already been received.");

            _seenMessages[report.MessageId] = report.ReceivedAt;
            _byCell[report.CellId] = report;
            return previous;
        }
    }

    /// <summary>
    /// The report currently held for a cell, whatever its age. The caller decides whether
    /// it is still current, because that decision differs between "may this command be
    /// prepared" and "what should this screen show".
    /// </summary>
    public ControllerReport? FindLatest(Guid cellId) => _byCell.GetValueOrDefault(cellId);

    /// <summary>The report for a cell if it is still inside <see cref="ValidFor"/>.</summary>
    public ControllerReport? FindCurrent(Guid cellId, DateTimeOffset now) =>
        FindLatest(cellId) is { } report && now - report.ReceivedAt <= ValidFor ? report : null;

    /// <summary>Cells a controller has reported for in this process. Diagnostic only.</summary>
    public int TrackedCells => _byCell.Count;

    /// <summary>
    /// Refuses a message identifier already seen inside the window, and remembers it.
    /// <para>
    /// This exists because the gateway's store-and-forward buffer removes a record only
    /// once Control Core has answered for it (CH1-NFR-REL-0001), so a gateway that dies
    /// between the answer and the removal <em>will</em> replay. Without suppression here
    /// that replay is a second copy of a reading rather than a refusal, and a buffer built
    /// to lose nothing would silently double-count instead.
    /// </para>
    /// <para>
    /// It is the same window and the same store <see cref="Accept"/> uses, deliberately:
    /// CH1-COM-FR-0010 asks for duplicate suppression on the edge, not for one per message
    /// kind, and two windows would be two things to keep in step.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COM-FR-0010, CH1-NFR-REL-0001, CH1-COM-PRO-0001</requirements>
    public void RegisterMessage(string messageId, DateTimeOffset receivedAt)
    {
        lock (_gate)
        {
            PruneSeenMessages(receivedAt);
            Guard.Against(
                _seenMessages.ContainsKey(messageId),
                "INGRESS_DUPLICATE_MESSAGE",
                "This message identifier has already been received inside the duplicate-suppression window.");
            _seenMessages[messageId] = receivedAt;
        }
    }

    private void PruneSeenMessages(DateTimeOffset now)
    {
        if (_seenMessages.Count < MaximumRememberedMessages)
        {
            var cutoff = now - DuplicateWindow;
            foreach (var (messageId, seenAt) in _seenMessages)
            {
                if (seenAt < cutoff)
                {
                    _seenMessages.TryRemove(messageId, out _);
                }
            }

            return;
        }

        // The window is full of entries too new to expire. Emptying it is the only bounded
        // option, and it is the safe direction: duplicate suppression weakens for one
        // window, whereas an unbounded dictionary is a memory fault in a service that
        // authorises physical work.
        _seenMessages.Clear();
    }
}
