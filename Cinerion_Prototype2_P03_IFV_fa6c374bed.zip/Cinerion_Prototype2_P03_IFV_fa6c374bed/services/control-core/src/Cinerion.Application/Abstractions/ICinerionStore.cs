// The storage contract every store must honour, in memory or in PostgreSQL alike.

using Cinerion.Domain.Assets;
using Cinerion.Domain.Audit;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Documents;
using Cinerion.Domain.Evidence;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Manufacturing;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Research;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;

namespace Cinerion.Application.Abstractions;

public interface ICinerionStore
{
    ValueTask<ProjectRecord?> FindProjectAsync(Guid projectId, CancellationToken cancellationToken);

    ValueTask<ProjectRecord?> FindProjectByCodeAsync(string projectCode, CancellationToken cancellationToken);

    ValueTask SaveProjectAsync(ProjectRecord project, CancellationToken cancellationToken);

    ValueTask<SiteRecord?> FindSiteAsync(Guid siteId, CancellationToken cancellationToken);

    ValueTask SaveSiteAsync(SiteRecord site, CancellationToken cancellationToken);

    ValueTask SaveCellRegistrationAsync(CellRegistration cell, CancellationToken cancellationToken);

    /// <summary>Cells belonging to one site, always filtered by the caller's project.</summary>
    ValueTask<IReadOnlyList<CellRegistration>> ListCellsBySiteAsync(
        Guid projectId,
        Guid siteId,
        CancellationToken cancellationToken);

    ValueTask<DeviceRecord?> FindDeviceAsync(string deviceId, CancellationToken cancellationToken);

    ValueTask SaveDeviceAsync(DeviceRecord device, CancellationToken cancellationToken);

    /// <summary>
    /// The device already holding this certificate thumbprint, if any. One certificate
    /// belongs to one device; the same one on two identities is a cloned credential.
    /// </summary>
    ValueTask<DeviceRecord?> FindDeviceByThumbprintAsync(
        Guid projectId,
        string thumbprint,
        CancellationToken cancellationToken);

    /// <summary>One enrolled authenticator, or null when it does not exist.</summary>
    ValueTask<CredentialRecord?> FindCredentialAsync(Guid credentialId, CancellationToken cancellationToken);

    /// <summary>
    /// The credential holding this WebAuthn handle, if any. One handle belongs to one
    /// record; the same handle on two identities is a cloned authenticator.
    /// </summary>
    ValueTask<CredentialRecord?> FindCredentialByWebAuthnIdAsync(
        Guid projectId,
        byte[] webAuthnCredentialId,
        CancellationToken cancellationToken);

    /// <summary>Every credential held by one identity, newest enrolment first.</summary>
    ValueTask<IReadOnlyList<CredentialRecord>> ListCredentialsAsync(
        Guid projectId,
        string subjectId,
        CancellationToken cancellationToken);

    ValueTask SaveCredentialAsync(CredentialRecord credential, CancellationToken cancellationToken);

    ValueTask<WebAuthnChallenge?> FindWebAuthnChallengeAsync(
        Guid challengeId,
        CancellationToken cancellationToken);

    ValueTask SaveWebAuthnChallengeAsync(WebAuthnChallenge challenge, CancellationToken cancellationToken);

    /// <summary>
    /// Records one controlled change to the roles an identity holds
    /// (entities.json: RoleAssignment, Security Sensitive, retention 7 years).
    /// </summary>
    /// <remarks>
    /// Write-only from the application's side, and the grant in migration 0012 is only
    /// SELECT and INSERT for the same reason: a role change that already happened is not
    /// something any code path has a reason to alter.
    /// </remarks>
    ValueTask SaveRoleAssignmentAsync(RoleAssignmentRecord assignment, CancellationToken cancellationToken);

    /// <summary>
    /// The role changes recorded for one identity, newest first. This is what makes the
    /// history readable rather than only verifiable: the audit chain stores a payload
    /// hash, so it can prove an event was not altered while being unable to say what it
    /// recorded.
    /// </summary>
    ValueTask<IReadOnlyList<RoleAssignmentRecord>> ListRoleAssignmentsAsync(
        Guid projectId,
        string subjectUserId,
        int limit,
        CancellationToken cancellationToken);

    /// <summary>
    /// The report already generated for this template revision and input set, if any.
    /// Deterministic generation means the same request returns the same report rather
    /// than a second one that might differ.
    /// </summary>
    ValueTask<ReportRecord?> FindReportByDeterminismKeyAsync(
        Guid projectId,
        string determinismKey,
        CancellationToken cancellationToken);

    ValueTask SaveReportAsync(ReportRecord report, CancellationToken cancellationToken);

    /// <summary>
    /// One controlled document, or null when it does not exist. Reads the register
    /// CH1-DOC-FR-0001 requires; it does not resolve the representation, which is the
    /// gated vault.
    /// </summary>
    ValueTask<ControlledDocumentRecord?> FindControlledDocumentAsync(
        Guid documentId,
        CancellationToken cancellationToken);

    ValueTask SaveControlledDocumentAsync(
        ControlledDocumentRecord document,
        CancellationToken cancellationToken);

    ValueTask<PublicationPackage?> FindPublicationPackageAsync(
        Guid packageId,
        CancellationToken cancellationToken);

    ValueTask SavePublicationPackageAsync(
        PublicationPackage package,
        CancellationToken cancellationToken);

    /// <summary>Every review held for one package, oldest first.</summary>
    ValueTask<IReadOnlyList<PublicationApproval>> ListPublicationApprovalsAsync(
        Guid projectId,
        Guid packageId,
        CancellationToken cancellationToken);

    ValueTask SavePublicationApprovalAsync(
        PublicationApproval approval,
        CancellationToken cancellationToken);

    /// <summary>
    /// The scan already delivered for this device, identifier and instant, if any. A
    /// re-delivery is recorded as pointing at the first, never dropped.
    /// </summary>
    ValueTask<ScanEventRecord?> FindScanEventByDeliveryAsync(
        Guid projectId,
        string deviceId,
        string identifierValue,
        DateTimeOffset scannedAt,
        CancellationToken cancellationToken);

    /// <summary>The part carrying this permanent identity or serial, if it is known.</summary>
    ValueTask<PartRecord?> FindPartByIdentifierAsync(
        Guid projectId,
        string identifierValue,
        CancellationToken cancellationToken);

    ValueTask SaveScanEventAsync(ScanEventRecord scanEvent, CancellationToken cancellationToken);

    ValueTask<CalibrationRecord?> FindCalibrationAsync(Guid calibrationId, CancellationToken cancellationToken);

    ValueTask SaveCalibrationAsync(CalibrationRecord calibration, CancellationToken cancellationToken);

    /// <summary>
    /// The calibration register for one project, newest certificate first.
    /// </summary>
    /// <remarks>
    /// Bounded, and the bound is the store's rather than the caller's: an operator screen
    /// asking for a register must not be able to ask for an unbounded one.
    /// </remarks>
    ValueTask<IReadOnlyList<CalibrationRecord>> ListCalibrationsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken);

    /// <summary>Scan events recorded in one project, newest first.</summary>
    /// <remarks>
    /// Bounded, and the bound is the store's rather than the caller's: an operator screen
    /// asking for a register must not be able to ask for an unbounded one.
    /// </remarks>
    ValueTask<IReadOnlyList<ScanEventRecord>> ListScanEventsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken);

    /// <summary>Work orders in one project, newest first.</summary>
    /// <remarks>
    /// Bounded, and the bound is the store's rather than the caller's: an operator screen
    /// asking for a register must not be able to ask for an unbounded one.
    /// </remarks>
    ValueTask<IReadOnlyList<WorkOrderRecord>> ListWorkOrdersAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken);

    /// <summary>Experiments in one project, newest first.</summary>
    /// <remarks>
    /// Bounded, and the bound is the store's rather than the caller's: an operator screen
    /// asking for a register must not be able to ask for an unbounded one.
    /// </remarks>
    ValueTask<IReadOnlyList<Experiment>> ListExperimentsAsync(
        Guid projectId,
        int limit,
        CancellationToken cancellationToken);

    ValueTask<AssetRecord?> FindAssetAsync(Guid assetId, CancellationToken cancellationToken);

    ValueTask SaveAssetAsync(AssetRecord asset, CancellationToken cancellationToken);

    ValueTask<ProductRevisionRecord?> FindRevisionAsync(Guid revisionId, CancellationToken cancellationToken);

    ValueTask SaveRevisionAsync(ProductRevisionRecord revision, CancellationToken cancellationToken);

    /// <summary>Product revisions in one project, newest product code first.</summary>
    ValueTask<IReadOnlyList<ProductRevisionRecord>> ListRevisionsAsync(
        Guid projectId,
        string? productCode,
        CancellationToken cancellationToken);

    ValueTask<WorkOrderRecord?> FindWorkOrderAsync(Guid workOrderId, CancellationToken cancellationToken);

    ValueTask<WorkOrderRecord?> FindWorkOrderByNumberAsync(
        Guid projectId,
        string workOrderNumber,
        CancellationToken cancellationToken);

    ValueTask SaveWorkOrderAsync(WorkOrderRecord workOrder, CancellationToken cancellationToken);

    /// <summary>
    /// The durable half of a cell's state, with how current the store believes it to be.
    /// The volatile half — interlocks, controller boot identity and button state — is not
    /// stored and comes from <c>CellRuntimeProjection</c> instead.
    /// </summary>
    ValueTask<StoredCellState?> FindCellAsync(Guid cellId, CancellationToken cancellationToken);

    /// <summary>
    /// Writes the durable half, and when it was observed. The observation is a parameter
    /// rather than a constant inside the store because freshness must describe what
    /// actually happened: a value written into the SQL text is a claim no reader can check.
    /// </summary>
    ValueTask SaveCellAsync(CellSnapshot cell, CellObservation observation, CancellationToken cancellationToken);

    ValueTask<CommandTransaction?> FindCommandAsync(Guid commandId, CancellationToken cancellationToken);

    ValueTask<CommandTransaction?> FindCommandByIdempotencyKeyAsync(
        Guid projectId,
        string idempotencyKey,
        CancellationToken cancellationToken);

    ValueTask SaveCommandAsync(
        CommandTransaction command,
        int? expectedVersion,
        CancellationToken cancellationToken);

    ValueTask<PartRecord?> FindPartAsync(Guid partId, CancellationToken cancellationToken);

    ValueTask SavePartAsync(PartRecord part, CancellationToken cancellationToken);

    ValueTask<TestRunRecord?> FindTestRunAsync(Guid testRunId, CancellationToken cancellationToken);

    ValueTask SaveTestRunAsync(TestRunRecord testRun, CancellationToken cancellationToken);

    ValueTask<NcrRecord?> FindNcrAsync(Guid ncrId, CancellationToken cancellationToken);

    ValueTask SaveNcrAsync(NcrRecord ncr, CancellationToken cancellationToken);

    /// <summary>
    /// Stores accepted telemetry. Written in one batch because store-and-forward
    /// delivers bursts, and a partially stored burst would leave a gap that later reads
    /// as missing data rather than as a failed write.
    /// </summary>
    ValueTask AppendTelemetryAsync(IReadOnlyList<TelemetrySample> samples, CancellationToken cancellationToken);

    /// <summary>Bounded historical telemetry. Bounds are enforced by the query itself.</summary>
    ValueTask<IReadOnlyList<TelemetrySample>> QueryTelemetryAsync(
        TelemetryQuery query,
        CancellationToken cancellationToken);

    ValueTask<Alarm?> FindAlarmAsync(Guid alarmId, CancellationToken cancellationToken);

    /// <summary>
    /// The alarm already raised for this source and code that has not yet cleared, if
    /// any. A condition that persists must keep one alarm rather than raise a new one
    /// on every sample.
    /// </summary>
    ValueTask<Alarm?> FindOutstandingAlarmAsync(
        Guid projectId,
        Guid cellId,
        string sourceId,
        string alarmCode,
        CancellationToken cancellationToken);

    /// <summary>
    /// Every outstanding alarm a source holds, in one read.
    /// </summary>
    /// <remarks>
    /// The singular form above is the right shape for one decision and the wrong shape for
    /// a batch: a gateway publishes every channel of a device together, and evaluating four
    /// readings asked four separate questions of the store - four pooled connections, each
    /// spending a round trip setting the project scope before its SELECT. The answers are
    /// identical either way; only the number of exchanges changes.
    /// </remarks>
    ValueTask<IReadOnlyList<Alarm>> FindOutstandingAlarmsAsync(
        Guid projectId,
        Guid cellId,
        string sourceId,
        CancellationToken cancellationToken);

    ValueTask SaveAlarmAsync(Alarm alarm, CancellationToken cancellationToken);

    /// <summary>One keyset page of alarms, ordered by priority then most recent first.</summary>
    ValueTask<IReadOnlyList<Alarm>> ListAlarmsAsync(AlarmQuery query, CancellationToken cancellationToken);

    ValueTask<Experiment?> FindExperimentAsync(Guid experimentId, CancellationToken cancellationToken);

    /// <summary>
    /// Writes an experiment. <paramref name="expectedVersion"/> is null on creation and
    /// otherwise must still be current, so a stale caller cannot overwrite a newer state.
    /// </summary>
    ValueTask SaveExperimentAsync(
        Experiment experiment,
        long? expectedVersion,
        CancellationToken cancellationToken);

    /// <summary>
    /// Appends a run and advances the experiment in one transaction. The revision is
    /// immutable once written, so a partially applied pair would leave a provenance
    /// record whose experiment never acknowledged it.
    /// </summary>
    ValueTask SaveExperimentRevisionAsync(
        ExperimentRevision revision,
        Experiment experiment,
        long expectedExperimentVersion,
        CancellationToken cancellationToken);

    /// <summary>Runs recorded against one experiment, oldest revision first.</summary>
    ValueTask<IReadOnlyList<ExperimentRevision>> ListExperimentRevisionsAsync(
        Guid projectId,
        Guid experimentId,
        CancellationToken cancellationToken);

    ValueTask<ResourceRecord?> FindResourceAsync(Guid resourceId, CancellationToken cancellationToken);

    ValueTask SaveResourceAsync(ResourceRecord resource, CancellationToken cancellationToken);

    /// <summary>One keyset page of resources, ordered by name.</summary>
    ValueTask<IReadOnlyList<ResourceRecord>> ListResourcesAsync(
        ResourceQuery query,
        CancellationToken cancellationToken);

    ValueTask<ResourceAllocation?> FindAllocationAsync(Guid allocationId, CancellationToken cancellationToken);

    /// <summary>
    /// Every allocation for the given resources that overlaps the window, cancelled ones
    /// excluded. Read for a set of resources at once so a page of the resource list
    /// costs one query rather than one per row.
    /// </summary>
    ValueTask<IReadOnlyList<ResourceAllocation>> ListAllocationsAsync(
        Guid projectId,
        IReadOnlyList<Guid> resourceIds,
        DateTimeOffset windowStart,
        DateTimeOffset windowEnd,
        CancellationToken cancellationToken);

    /// <summary>
    /// Writes a reservation and the resource version it was decided against, in one
    /// transaction. <paramref name="expectedResourceVersion"/> must still be current or
    /// the write is refused: without that, two callers reading the same capacity could
    /// both pass the conflict check and both commit.
    /// </summary>
    ValueTask SaveAllocationAsync(
        ResourceAllocation allocation,
        long expectedResourceVersion,
        long? expectedAllocationVersion,
        CancellationToken cancellationToken);

    ValueTask<ContextThread?> FindContextThreadAsync(Guid threadId, CancellationToken cancellationToken);

    ValueTask SaveContextThreadAsync(ContextThread thread, CancellationToken cancellationToken);

    ValueTask<ContextMessage?> FindContextMessageAsync(Guid messageId, CancellationToken cancellationToken);

    ValueTask SaveContextMessageAsync(ContextMessage message, CancellationToken cancellationToken);

    /// <summary>One keyset page of a thread, oldest first.</summary>
    ValueTask<IReadOnlyList<ContextMessage>> ListContextMessagesAsync(
        ContextMessageQuery query,
        CancellationToken cancellationToken);

    /// <summary>
    /// Receipts for the given messages, so a page of a thread can show its
    /// acknowledgement state without one query per message.
    /// </summary>
    ValueTask<IReadOnlyList<MessageAcknowledgement>> ListMessageAcknowledgementsAsync(
        Guid projectId,
        IReadOnlyList<Guid> messageIds,
        CancellationToken cancellationToken);

    /// <summary>
    /// Records a receipt. A second receipt from the same recipient is a conflict rather
    /// than an overwrite of who first confirmed and when.
    /// </summary>
    ValueTask SaveMessageAcknowledgementAsync(
        MessageAcknowledgement acknowledgement,
        CancellationToken cancellationToken);

    ValueTask SaveStepUpGrantAsync(StepUpGrant grant, CancellationToken cancellationToken);

    ValueTask<StepUpGrant?> FindStepUpGrantAsync(Guid grantId, CancellationToken cancellationToken);

    ValueTask<AuditEvent> AppendAuditAsync(AuditInput input, CancellationToken cancellationToken);

    ValueTask<IReadOnlyList<AuditEvent>> QueryAuditAsync(
        Guid projectId,
        Guid? correlationId,
        int limit,
        CancellationToken cancellationToken);

    ValueTask<AuditVerification> VerifyAuditAsync(CancellationToken cancellationToken);
}

public interface ISystemClock
{
    DateTimeOffset UtcNow { get; }

    string TimeQuality { get; }
}

public sealed class SystemClock : ISystemClock
{
    public DateTimeOffset UtcNow => DateTimeOffset.UtcNow;

    public string TimeQuality => "SystemClock-Unqualified";
}
