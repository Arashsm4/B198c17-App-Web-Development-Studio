// Contract for sealing secrets at rest. Plain text stays out of the database.

namespace Cinerion.Application.Abstractions;

/// <summary>Sealed material and the nonce it was sealed under.</summary>
public sealed record SealedSecret(byte[] Ciphertext, byte[] Nonce);

/// <summary>
/// Seals and opens the one symmetric secret this platform has to keep: a TOTP seed.
/// <para>
/// Behind an interface because the key belongs to the deployment, not to the code.
/// api_endpoints.json makes "encrypted storage" a control on TOTP enrolment, and
/// CH1-CYB-CSRS-0001 puts key custody outside the application, so an implementation that
/// invented or embedded a key would satisfy the letter of encryption while defeating its
/// purpose. The shipped implementation therefore refuses to start without a key supplied
/// by configuration, in the same fail-closed way the identity directory refuses without a
/// client secret.
/// </para>
/// <para>
/// Nothing else in the platform is sealed this way. Passkeys, security tokens and smart
/// cards keep their private keys in hardware and hand over only a public key, which is
/// why <c>ch1.credentials</c> has no column one could be written to.
/// </para>
/// </summary>
/// <requirements>CH1-CYB-IAM-0001, CH1-CYB-CSRS-0001</requirements>
public interface ICredentialSealer
{
    /// <summary>True when a key has been supplied and sealing can be performed at all.</summary>
    bool IsConfigured { get; }

    /// <summary>
    /// Seals a secret. <paramref name="associatedData"/> binds the ciphertext to the
    /// record it belongs to, so a sealed seed lifted from one row cannot be pasted into
    /// another and still open.
    /// </summary>
    SealedSecret Seal(ReadOnlySpan<byte> plaintext, ReadOnlySpan<byte> associatedData);

    /// <summary>
    /// Opens a sealed secret, or throws if the key, nonce or associated data do not
    /// match. There is no variant that reports failure as an empty result: a seed that
    /// silently opened to nothing would verify no codes and look like a wrong device.
    /// </summary>
    byte[] Open(SealedSecret sealedSecret, ReadOnlySpan<byte> associatedData);
}
