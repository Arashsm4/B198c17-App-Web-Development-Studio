// Settings for the gRPC edge listener: port, trusted authority, who's allowed in.

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace Cinerion.Api.Ingress;

/// <summary>
/// The deployment's half of CH1-COM-IF-0003: which port the internal gRPC edge listens
/// on, the controlled authority that decides which gateways exist, this service's own
/// server certificate, and the gateway identity it will accept.
/// <para>
/// <b>All five or none.</b> The same rule the MQTT and OPC UA adapters follow, for the
/// same reason: a partially configured mutual-TLS edge is the one case where a helpful
/// default silently drops mutual authentication. An unconfigured deployment therefore has
/// no gRPC listener at all — the ingress is not reachable rather than reachable without
/// a client certificate — and <c>GET /api/v1/system/health</c> says so.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-CYB-FR-0001, CH1-CYB-CSRS-0001</requirements>
public sealed record EdgeIngressOptions(
    int Port,
    X509Certificate2 ServerCertificate,
    X509Certificate2 CertificateAuthority,
    string GatewayIdentity)
{
    public static EdgeIngressOptions? FromConfiguration(IConfiguration configuration)
    {
        var port = configuration["CINERION_EDGE_GRPC_PORT"];
        var caPath = configuration["CINERION_EDGE_GRPC_CA_CERT"];
        var certificatePath = configuration["CINERION_EDGE_GRPC_SERVER_CERT"];
        var keyPath = configuration["CINERION_EDGE_GRPC_SERVER_KEY"];
        var gatewayIdentity = configuration["CINERION_EDGE_GRPC_GATEWAY_IDENTITY"];

        if (string.IsNullOrWhiteSpace(port) || string.IsNullOrWhiteSpace(caPath) ||
            string.IsNullOrWhiteSpace(certificatePath) || string.IsNullOrWhiteSpace(keyPath) ||
            string.IsNullOrWhiteSpace(gatewayIdentity))
        {
            return null;
        }

        if (!int.TryParse(port, out var portNumber) || portNumber is < 1 or > 65535)
        {
            throw new InvalidOperationException($"CINERION_EDGE_GRPC_PORT '{port}' is not a usable TCP port.");
        }

        return new EdgeIngressOptions(
            portNumber,
            LoadServerCertificate(certificatePath, keyPath),
            X509CertificateLoader.LoadCertificateFromFile(caPath),
            gatewayIdentity);
    }

    /// <summary>
    /// The name a gateway addresses this service by on the internal edge, taken from the
    /// common name of the service's own certificate.
    /// <para>
    /// It is needed because <c>AllowedHosts=localhost</c> is a deliberate setting for the
    /// REST API and host filtering is a single global middleware: a gRPC call whose
    /// <c>:authority</c> is the Compose service name is answered <c>400</c> before it
    /// reaches any handler, which surfaces as "Bad gRPC response. HTTP status code: 400"
    /// and looks nothing like a host-header rejection. Deriving the name from the
    /// certificate rather than from a free-text setting means the only extra host accepted
    /// is the one this deployment's authority already attested.
    /// </para>
    /// </summary>
    public string ServiceCommonName =>
        ServerCertificate.GetNameInfo(X509NameType.SimpleName, forIssuer: false) ?? string.Empty;

    /// <summary>
    /// Decides whether a presented client certificate belongs to this deployment.
    /// <para>
    /// The controlled CA is the <em>only</em> trust anchor: <see cref="X509ChainTrustMode.CustomRootTrust"/>
    /// with an empty <c>CustomTrustStore</c> plus this one certificate means the machine's
    /// own root store is not consulted at all. A certificate from a public authority that
    /// happens to carry the right common name is refused, because identity here is what
    /// this authority attested and not a name a client chose.
    /// </para>
    /// </summary>
    public bool IsIssuedByControlledAuthority(X509Certificate2 clientCertificate, SslPolicyErrors errors)
    {
        // A missing certificate is not something to evaluate; Kestrel is configured to
        // require one, and this makes the refusal explicit rather than incidental.
        if (errors.HasFlag(SslPolicyErrors.RemoteCertificateNotAvailable))
        {
            return false;
        }

        using var chain = new X509Chain
        {
            ChainPolicy =
            {
                TrustMode = X509ChainTrustMode.CustomRootTrust,
                RevocationMode = X509RevocationMode.NoCheck,
                VerificationFlags = X509VerificationFlags.NoFlag,
            },
        };
        chain.ChainPolicy.CustomTrustStore.Add(CertificateAuthority);
        return chain.Build(clientCertificate);
    }

    /// <summary>
    /// Loads the PEM certificate and its key in a form the platform's TLS stack will
    /// actually serve.
    /// <para>
    /// The round trip through PKCS#12 on Windows is not decoration: SChannel cannot use
    /// the ephemeral key handle <see cref="X509Certificate2.CreateFromPemFile"/> produces,
    /// and a server configured with one fails at the handshake with an error that names
    /// the credential rather than the cause. Linux — where this service is deployed — has
    /// no such restriction, so the conversion is confined to the platform that needs it.
    /// </para>
    /// </summary>
    private static X509Certificate2 LoadServerCertificate(string certificatePath, string keyPath)
    {
        var certificate = X509Certificate2.CreateFromPemFile(certificatePath, keyPath);
        if (!OperatingSystem.IsWindows())
        {
            return certificate;
        }

        using (certificate)
        {
            return X509CertificateLoader.LoadPkcs12(certificate.Export(X509ContentType.Pkcs12), password: null);
        }
    }
}
