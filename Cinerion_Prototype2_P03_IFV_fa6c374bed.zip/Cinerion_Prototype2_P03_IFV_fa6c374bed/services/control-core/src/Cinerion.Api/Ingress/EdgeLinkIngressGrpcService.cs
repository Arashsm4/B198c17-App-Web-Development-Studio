// Receives what EdgeLink saw, over gRPC with mutual TLS, and checks every message before
// believing it.

using Cinerion.Application.Edge;
using Cinerion.Contracts.EdgeLink.V1;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;

namespace Cinerion.Api.Ingress;

/// <summary>
/// The receiving end of CH1-COM-IF-0003, on its own mutually authenticated listener.
/// <para>
/// This class does the translation and the peer identification; every decision about
/// whether a message may be believed belongs to <see cref="EdgeIngressService"/>, so the
/// transport cannot become a second place where authority is decided.
/// </para>
/// <para>
/// A refusal is answered as an ordinary receipt carrying its stable reason code, not as a
/// gRPC fault. CH1-COM-ICD-0001 requires errors to carry "stable codes and actionable
/// detail without leaking secrets", and a gateway needs to log <em>why</em> its report was
/// rejected — an <c>UNKNOWN</c> status would tell it only that something went wrong. The
/// exceptions are the two failures that are genuinely about the caller rather than the
/// message: no client certificate, and a certificate for another gateway.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-CYB-FR-0001, CH1-MON-FR-0003</requirements>
public sealed partial class EdgeLinkIngressGrpcService(
    EdgeIngressService ingress,
    EdgeIngressOptions options,
    IServiceProvider services,
    ILogger<EdgeLinkIngressGrpcService> logger) : EdgeLinkIngress.EdgeLinkIngressBase
{
    /// <summary>
    /// Establishes the database scope for this call, exactly as
    /// <see cref="Security.ActorContextFactory"/> does for an HTTP request.
    /// <para>
    /// The project comes from the envelope, and that is safe in one direction only: it
    /// <em>restricts</em>. Row-level security then filters every store call to that
    /// project, so a gateway naming a project it does not serve sees nothing there — and
    /// the device it names must be enrolled, trusted and assigned inside that same
    /// project, which is a decision this platform stored rather than one the message
    /// makes. A device in another project is not found, which reads identically to one
    /// that was never enrolled.
    /// </para>
    /// </summary>
    private void EstablishProjectScope(IngressEnvelope envelope) =>
        services.GetService<Infrastructure.Persistence.ProjectScope>()?.Set(envelope.ProjectId);

    public override async Task<IngressReceipt> PublishControllerState(
        ControllerStateReport request,
        ServerCallContext context)
    {
        var peer = RequirePeer(context);
        try
        {
            var envelope = ReadEnvelope(request.Envelope);
            EstablishProjectScope(envelope);
            var report = await ingress.PublishControllerStateAsync(
                peer,
                new ControllerReportInput(
                    envelope,
                    request.ControllerId,
                    ParseGuid(request.ControllerBootId, "INGRESS_BOOT_IDENTITY_REQUIRED", "controller boot identity"),
                    ReadOperatingState(request.OperatingState),
                    request.ConfigurationRevision,
                    ReadPermissives(request.Permissives),
                    request.AdapterId,
                    request.Protocol,
                    request.SecurityProfile,
                    request.FirmwareVersion,
                    ReadFreshness(request.Freshness)),
                context.CancellationToken).ConfigureAwait(false);

            LogControllerReport(
                logger,
                peer.GatewayIdentity,
                report.ControllerId,
                report.CellId,
                report.OperatingState,
                report.Permissives.Reported,
                report.Freshness);

            return Accepted(
                request.Envelope,
                report.Permissives.Reported
                    ? "CONTROLLER_REPORT_ACCEPTED"
                    : "PERMISSIVES_NOT_REPORTED_CELL_NOT_PERMISSIVE",
                1);
        }
        catch (DomainRuleException error)
        {
            return await RefuseAsync(peer, request.Envelope, "ControllerReportRejected", error, context)
                .ConfigureAwait(false);
        }
    }

    public override async Task<IngressReceipt> PublishControllerEvent(
        ControllerEvent request,
        ServerCallContext context)
    {
        var peer = RequirePeer(context);
        try
        {
            var envelope = ReadEnvelope(request.Envelope);
            EstablishProjectScope(envelope);
            var record = await ingress.PublishControllerEventAsync(
                peer,
                new ControllerEventInput(
                    envelope,
                    request.ControllerId,
                    request.ControllerBootId,
                    request.Kind.ToString().Replace("ControllerEventKind", string.Empty, StringComparison.Ordinal),
                    request.ReasonCode,
                    request.PreviousState.ToString(),
                    request.CurrentState.ToString(),
                    request.PreviousPermissives?.Reported ?? false,
                    request.CurrentPermissives?.Reported ?? false,
                    request.PreviousConfigurationRevision,
                    request.ConfigurationRevision,
                    request.AdapterId,
                    ReadTimestamp(request.ObservedAt)),
                context.CancellationToken).ConfigureAwait(false);

            LogControllerEvent(logger, peer.GatewayIdentity, record.ControllerId, record.Kind, record.ObservedAt);
            return Accepted(request.Envelope, "CONTROLLER_TRANSITION_IS_NOT_COMMAND_AUTHORITY", 1);
        }
        catch (DomainRuleException error)
        {
            return await RefuseAsync(peer, request.Envelope, "ControllerEventRejected", error, context)
                .ConfigureAwait(false);
        }
    }

    public override async Task<IngressReceipt> PublishTelemetry(
        TelemetryPublication request,
        ServerCallContext context)
    {
        var peer = RequirePeer(context);
        try
        {
            var envelope = ReadEnvelope(request.Envelope);
            EstablishProjectScope(envelope);
            var result = await ingress.PublishTelemetryAsync(
                peer,
                new TelemetryPublicationInput(
                    envelope,
                    request.DeviceId,
                    [.. request.Readings.Select(reading => new TelemetryReadingInput(
                        reading.ChannelId,
                        reading.Value,
                        reading.Unit,
                        ReadQuality(reading.Quality),
                        ReadFreshness(reading.Freshness),
                        ReadTimestamp(reading.SampledAt),
                        reading.Sequence,
                        ReadSourceTimeQuality(reading.SourceTimeQuality)))]),
                context.CancellationToken).ConfigureAwait(false);

            var receipt = Accepted(request.Envelope, "TELEMETRY_STORED", result.Accepted);
            receipt.RaisedAlarmCodes.AddRange(result.Raised.Select(alarm => alarm.AlarmCode));
            LogTelemetryPublication(
                logger, peer.GatewayIdentity, request.DeviceId, result.Accepted, result.Raised.Count);
            return receipt;
        }
        catch (DomainRuleException error)
        {
            return await RefuseAsync(peer, request.Envelope, "GatewayTelemetryRejected", error, context)
                .ConfigureAwait(false);
        }
    }

    public override async Task<IngressReceipt> AcknowledgeCommand(
        CommandAcknowledgement request,
        ServerCallContext context)
    {
        var peer = RequirePeer(context);
        try
        {
            var envelope = ReadEnvelope(request.Envelope);
            EstablishProjectScope(envelope);
            var command = await ingress.AcknowledgeCommandAsync(
                peer,
                new CommandAcknowledgementInput(
                    envelope,
                    ParseGuid(request.CommandId, "INGRESS_COMMAND_ID_INVALID", "command identifier"),
                    request.ControllerId,
                    request.Accepted,
                    request.ControllerState,
                    request.ReasonCode,
                    ReadTimestamp(request.ObservedAt),
                    request.AdapterId),
                context.CancellationToken).ConfigureAwait(false);

            LogAcknowledgement(
                logger, peer.GatewayIdentity, command.CommandId, command.State, request.ReasonCode);

            // The controller's answer is recorded; the command state is the domain's and is
            // reported back unchanged. CH1-AUT-FDS-0001 advances it on a credential proof
            // and a physical button edge, never on a controller saying it heard something.
            return Accepted(request.Envelope, "ACKNOWLEDGEMENT_IS_NOT_EXECUTION_AUTHORITY", 1);
        }
        catch (DomainRuleException error)
        {
            return await RefuseAsync(peer, request.Envelope, "ControllerAcknowledgementRejected", error, context)
                .ConfigureAwait(false);
        }
    }

    /// <summary>
    /// Who the caller is, from the certificate the transport verified.
    /// <para>
    /// Two independent controls, deliberately. Kestrel has already refused anything the
    /// controlled authority did not sign; this refuses a certificate that authority signed
    /// for some <em>other</em> gateway. Either alone would look like it was working while
    /// the other did the work — which is exactly what attacking the OPC UA endpoint showed
    /// about its anonymous-token refusal.
    /// </para>
    /// </summary>
    private GatewayPeer RequirePeer(ServerCallContext context)
    {
        var http = context.GetHttpContext();

        // The ingress lives on its own listener and nowhere else. The REST listener
        // requires no client certificate, so a gRPC call arriving there would already fail
        // the check below; stating the port as well makes the separation structural rather
        // than a consequence of how the other listener happens to be configured.
        if (http.Connection.LocalPort != options.Port)
        {
            throw new RpcException(new Status(
                StatusCode.PermissionDenied,
                "The EdgeLink ingress is served only on the mutually authenticated internal listener."));
        }

        var certificate = http.Connection.ClientCertificate
            ?? throw new RpcException(new Status(
                StatusCode.Unauthenticated,
                "CH1-COM-IF-0003 requires a client certificate issued by the controlled authority."));

        var commonName = certificate.GetNameInfo(System.Security.Cryptography.X509Certificates.X509NameType.SimpleName, forIssuer: false);
        if (!StringComparer.Ordinal.Equals(commonName, options.GatewayIdentity))
        {
            LogGatewayIdentityRefused(logger, commonName ?? "(none)", options.GatewayIdentity);
            throw new RpcException(new Status(
                StatusCode.PermissionDenied,
                "The client certificate is trusted but names another gateway."));
        }

        return new GatewayPeer(commonName, certificate.Thumbprint);
    }

    private async Task<IngressReceipt> RefuseAsync(
        GatewayPeer peer,
        Envelope? envelope,
        string eventType,
        DomainRuleException error,
        ServerCallContext context)
    {
        LogIngressRefused(logger, peer.GatewayIdentity, eventType, error.Code, error.Message);

        // A refusal is evidence, so it is recorded — but only when the message named a
        // project this service could scope the record to. An envelope that failed
        // validation before its project was established has nowhere to be audited to, and
        // inventing a project for it would put an unattributable row in a chain that is
        // verified per project.
        if (Guid.TryParse(envelope?.ProjectId, out var projectId) && projectId != Guid.Empty)
        {
            try
            {
                // The refused message's own correlation identifier, when it carried one
                // this service can use. A malformed envelope may carry none, and a
                // refusal is then recorded uncorrelated rather than attached to an
                // identity nobody validated.
                var correlated = Guid.TryParse(envelope?.CorrelationId, out var correlationId) &&
                    correlationId != Guid.Empty
                    ? correlationId
                    : (Guid?)null;
                await ingress.AuditRefusalAsync(
                    peer, projectId, eventType, envelope?.CellId ?? string.Empty, error, correlated, context.CancellationToken)
                    .ConfigureAwait(false);
            }
            catch (DomainRuleException auditError)
            {
                // The refusal still has to be reported to the gateway. A project that does
                // not exist cannot carry an audit row, and that is itself the answer to the
                // original message rather than a new failure.
                LogRefusalNotAudited(logger, error.Code, auditError.Code);
            }
        }

        return new IngressReceipt
        {
            Accepted = false,
            ReasonCode = error.Code,
            Detail = error.Message,
            CorrelationId = envelope?.CorrelationId ?? string.Empty,
            AcceptedCount = 0,
            ReceivedAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow),
        };
    }

    private static IngressReceipt Accepted(Envelope? envelope, string reasonCode, int acceptedCount) => new()
    {
        Accepted = true,
        ReasonCode = reasonCode,
        Detail = string.Empty,
        CorrelationId = envelope?.CorrelationId ?? string.Empty,
        AcceptedCount = acceptedCount,
        ReceivedAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow),
    };

    private static IngressEnvelope ReadEnvelope(Envelope? envelope)
    {
        Guard.Against(envelope is null, "INGRESS_ENVELOPE_REQUIRED", "Every controlled message carries an envelope.");
        return new IngressEnvelope(
            envelope!.SchemaVersion,
            envelope.MessageType,
            envelope.MessageId,
            envelope.CorrelationId,
            envelope.SourceId,
            envelope.DestinationId,
            ParseGuid(envelope.ProjectId, "INGRESS_SCOPE_REQUIRED", "project identifier"),
            ParseOptionalGuid(envelope.SiteId),
            ParseGuid(envelope.CellId, "INGRESS_SCOPE_REQUIRED", "cell identifier"),
            ParseOptionalGuid(envelope.AssetId),
            envelope.Sequence,
            ReadTimestamp(envelope.OccurredAt),
            envelope.ExpiresAt is null ? null : ReadTimestamp(envelope.ExpiresAt));
    }

    private static ReportedPermissives ReadPermissives(Permissives? permissives) =>
        permissives is null
            ? ReportedPermissives.NotReported
            : new ReportedPermissives(
                permissives.Reported,
                permissives.ControllerOnline,
                permissives.StartEnable,
                permissives.StopCircuitHealthy,
                permissives.GuardHealthy,
                permissives.ActuatorHome,
                permissives.ButtonPressed,
                permissives.FaultCauseActive,
                [.. permissives.DeferredCheckCodes]);

    private static CellOperatingState ReadOperatingState(ControllerOperatingState state) => state switch
    {
        ControllerOperatingState.Initialising => CellOperatingState.Initialising,
        ControllerOperatingState.Idle => CellOperatingState.Idle,
        ControllerOperatingState.Prepared => CellOperatingState.Prepared,
        ControllerOperatingState.Executing => CellOperatingState.Executing,
        ControllerOperatingState.Complete => CellOperatingState.Complete,
        ControllerOperatingState.FaultLatched => CellOperatingState.FaultLatched,
        ControllerOperatingState.Maintenance => CellOperatingState.Maintenance,
        _ => throw new DomainRuleException(
            "INGRESS_OPERATING_STATE_UNKNOWN",
            "A controller must report an operating state this contract defines."),
    };

    private static Domain.Monitoring.Freshness ReadFreshness(Contracts.EdgeLink.V1.Freshness freshness) => freshness switch
    {
        Contracts.EdgeLink.V1.Freshness.Live => Domain.Monitoring.Freshness.Live,
        Contracts.EdgeLink.V1.Freshness.Stale => Domain.Monitoring.Freshness.Stale,
        Contracts.EdgeLink.V1.Freshness.Disconnected => Domain.Monitoring.Freshness.Disconnected,
        Contracts.EdgeLink.V1.Freshness.Simulated => Domain.Monitoring.Freshness.Simulated,
        Contracts.EdgeLink.V1.Freshness.Maintenance => Domain.Monitoring.Freshness.Maintenance,
        // Unspecified is not silently read as Live. CH1-MON-FR-0003 makes the six states
        // distinguishable, and a peer that did not say which one it meant has said Unknown.
        _ => Domain.Monitoring.Freshness.Unknown,
    };

    /// <summary>
    /// The SOURCE's own declaration about the clock that stamped the sample, read as it
    /// was sent. It is deliberately NOT resolved to this service's clock quality, and not
    /// resolved to a default either: UNSPECIFIED means the source declared nothing, and
    /// storing nothing is the honest record of that. CH1-COM-ICD-0001 requires time
    /// quality to be observable "so audit and TOTP decisions are not silently made on
    /// invalid time"; a substituted value would make exactly that decision silently.
    /// </summary>
    private static string? ReadSourceTimeQuality(Contracts.EdgeLink.V1.TimeQuality quality) => quality switch
    {
        Contracts.EdgeLink.V1.TimeQuality.Trusted => "Trusted",
        Contracts.EdgeLink.V1.TimeQuality.Qualified => "Qualified",
        Contracts.EdgeLink.V1.TimeQuality.Degraded => "Degraded",
        Contracts.EdgeLink.V1.TimeQuality.Unknown => "Unknown",
        _ => null,
    };

    private static Domain.Monitoring.DataQuality ReadQuality(Contracts.EdgeLink.V1.DataQuality quality) => quality switch
    {
        Contracts.EdgeLink.V1.DataQuality.Good => Domain.Monitoring.DataQuality.Good,
        Contracts.EdgeLink.V1.DataQuality.Uncertain => Domain.Monitoring.DataQuality.Uncertain,
        Contracts.EdgeLink.V1.DataQuality.Bad => Domain.Monitoring.DataQuality.Bad,
        _ => Domain.Monitoring.DataQuality.Unknown,
    };

    private static DateTimeOffset ReadTimestamp(Timestamp? timestamp)
    {
        Guard.Against(timestamp is null, "INGRESS_TIMESTAMP_REQUIRED", "A controlled message must be timestamped.");
        return timestamp!.ToDateTimeOffset();
    }

    private static Guid ParseGuid(string value, string code, string what) =>
        Guid.TryParse(value, out var parsed) && parsed != Guid.Empty
            ? parsed
            : throw new DomainRuleException(code, $"A valid {what} is required.");

    private static Guid ParseOptionalGuid(string value) =>
        Guid.TryParse(value, out var parsed) ? parsed : Guid.Empty;

    [LoggerMessage(
        EventId = 2000,
        Level = LogLevel.Information,
        Message = "Ingress {Gateway}: controller {ControllerId} on cell {CellId} reports {OperatingState}; permissives reported={PermissivesReported}; freshness {Freshness}")]
    private static partial void LogControllerReport(
        ILogger logger,
        string gateway,
        string controllerId,
        Guid cellId,
        CellOperatingState operatingState,
        bool permissivesReported,
        Domain.Monitoring.Freshness freshness);

    [LoggerMessage(
        EventId = 2006,
        Level = LogLevel.Information,
        Message = "Ingress {Gateway}: controller {ControllerId} transition {Kind} observed at {ObservedAt:O} recorded in the audit chain")]
    private static partial void LogControllerEvent(
        ILogger logger, string gateway, string controllerId, string kind, DateTimeOffset observedAt);

    [LoggerMessage(
        EventId = 2001,
        Level = LogLevel.Information,
        Message = "Ingress {Gateway}: device {DeviceId} published {Stored} reading(s); {Raised} alarm(s) raised")]
    private static partial void LogTelemetryPublication(
        ILogger logger, string gateway, string deviceId, int stored, int raised);

    [LoggerMessage(
        EventId = 2002,
        Level = LogLevel.Information,
        Message = "Ingress {Gateway}: acknowledgement for command {CommandId} recorded; command state remains {CommandState}; controller said {ReasonCode}")]
    private static partial void LogAcknowledgement(
        ILogger logger, string gateway, Guid commandId, CommandState commandState, string reasonCode);

    [LoggerMessage(
        EventId = 2003,
        Level = LogLevel.Warning,
        Message = "Ingress {Gateway}: {EventType} refused as {ReasonCode}: {Detail}")]
    private static partial void LogIngressRefused(
        ILogger logger, string gateway, string eventType, string reasonCode, string detail);

    [LoggerMessage(
        EventId = 2004,
        Level = LogLevel.Warning,
        Message = "Ingress: a certificate the controlled authority signed names gateway {PresentedIdentity}, but this deployment serves {ExpectedIdentity}")]
    private static partial void LogGatewayIdentityRefused(
        ILogger logger, string presentedIdentity, string expectedIdentity);

    [LoggerMessage(
        EventId = 2005,
        Level = LogLevel.Warning,
        Message = "Ingress: refusal {ReasonCode} could not be audited ({AuditReasonCode}); the refusal still stands")]
    private static partial void LogRefusalNotAudited(ILogger logger, string reasonCode, string auditReasonCode);
}
