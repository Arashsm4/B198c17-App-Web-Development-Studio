// Control Core starts here: auth, storage, listeners and routes all get wired up. The big
// switchboard.

using System.Text.Json.Serialization;
using Cinerion.Api.Endpoints;
using Cinerion.Api.Errors;
using Cinerion.Api.Ingress;
using Cinerion.Api.Security;
using Cinerion.Application.Abstractions;
using Cinerion.Application.Assets;
using Cinerion.Application.Collaboration;
using Cinerion.Application.Commands;
using Cinerion.Application.Configuration;
using Cinerion.Application.Edge;
using Cinerion.Application.Documents;
using Cinerion.Application.Evidence;
using Cinerion.Application.Identity;
using Cinerion.Application.Manufacturing;
using Cinerion.Application.Monitoring;
using Cinerion.Application.Quality;
using Cinerion.Application.Research;
using Cinerion.Application.Resources;
using Cinerion.Application.Security;
using Cinerion.Infrastructure.Identity;
using Cinerion.Infrastructure.InMemory;
using Cinerion.Infrastructure.Monitoring;
using Cinerion.Infrastructure.Persistence;
using Cinerion.Infrastructure.Security;
using Cinerion.Infrastructure.Seed;
using Microsoft.AspNetCore.Authentication.JwtBearer;

var builder = WebApplication.CreateBuilder(args);

var profileText = builder.Configuration["CINERION_RUNTIME_PROFILE"] ?? "Simulation";
if (!Enum.TryParse<CommandRuntimeProfile>(profileText, ignoreCase: true, out var runtimeProfile))
{
    throw new InvalidOperationException($"Unknown CINERION_RUNTIME_PROFILE '{profileText}'.");
}

var allowDevelopmentIdentity = string.Equals(
    builder.Configuration["CINERION_ALLOW_DEVELOPMENT_IDENTITY"],
    "true",
    StringComparison.OrdinalIgnoreCase);

if (runtimeProfile == CommandRuntimeProfile.Production && allowDevelopmentIdentity)
{
    throw new InvalidOperationException("Development identity is forbidden in the Production runtime profile.");
}

// Demonstration records, so a reviewer can tell a screen that works and has nothing to show
// from a screen that is broken. Off unless explicitly asked for, and refused outright in the
// Production profile: seeded records that reached a real deployment would be indistinguishable
// from operational ones to anyone reading the database, whatever the labels said.
var demonstrationData = string.Equals(
    builder.Configuration["CINERION_DEMONSTRATION_DATA"],
    "true",
    StringComparison.OrdinalIgnoreCase);

if (runtimeProfile == CommandRuntimeProfile.Production && demonstrationData)
{
    throw new InvalidOperationException("Demonstration data is forbidden in the Production runtime profile.");
}

if (allowDevelopmentIdentity && !builder.Environment.IsDevelopment())
{
    throw new InvalidOperationException("Development identity requires ASPNETCORE_ENVIRONMENT=Development.");
}

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
    options.SerializerOptions.PropertyNameCaseInsensitive = false;
});
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<DomainExceptionHandler>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<ISystemClock, SystemClock>();

// The one symmetric secret the platform stores is a TOTP seed, and its key belongs to
// the deployment. With CINERION_CREDENTIAL_ENCRYPTION_KEY unset the sealer reports
// itself unconfigured and TOTP enrolment refuses, rather than keeping a seed in the
// clear - the same fail-closed direction the identity directory takes without its
// client secret.
builder.Services.AddSingleton<ICredentialSealer>(_ =>
    new AesGcmCredentialSealer(builder.Configuration["CINERION_CREDENTIAL_ENCRYPTION_KEY"]));

// Which store the service runs on is an explicit, validated decision rather than a
// silent default. In-memory storage is permitted only in Development.
var storage = StorageModeSelection.Resolve(
    builder.Configuration["CINERION_DATABASE_MODE"],
    builder.Configuration["CINERION_POSTGRES_CONNECTION"],
    builder.Environment.IsDevelopment());

// Registered without the connection string, so no endpoint can read a credential
// from it while still being able to state which store answered.
builder.Services.AddSingleton(storage with { ConnectionString = null });

if (storage.Mode == CinerionStorageMode.Postgres)
{
    // The connection and the controlled schema are verified at startup, so a
    // misconfigured database fails here rather than at the first controlled operation.
    // Set only when the server grants fewer connections than the unstated default would
    // open; every data source below is built with it, so the cap is not something one code
    // path applies and another forgets.
    int? poolCeiling = null;
    var startupScope = new ProjectScope();
    await using (var probe = new CinerionDataSource(storage.ConnectionString!, startupScope))
    {
        var controlledTables = await probe.CountControlledTablesAsync(CancellationToken.None).ConfigureAwait(false);
        if (controlledTables == 0)
        {
            throw new InvalidOperationException(
                "CINERION_DATABASE_MODE=Postgres: connected, but the controlled ch1 schema is absent. Apply the migrations first.");
        }

        // A pool entitled to ask for more connections than the server grants does not
        // degrade under load, it breaks: the pool opens connections until PostgreSQL
        // refuses, and that refusal reaches the caller as a failed request rather than as
        // a wait for one of the connections it could have had. Both defaults are 100 and
        // PostgreSQL reserves three of its own, so an unconfigured deployment is already
        // over by three. The CH1-NFR-PER-0001 rig found it as "Failed to connect" mixed in
        // with genuine pool timeouts.
        //
        // What is done about it depends on who chose the number. A deployment that stated
        // a pool larger than the server grants asked for something impossible and is told
        // so; one that stated nothing inherited a default it never picked, and is given a
        // pool that fits instead of a refusal it cannot act on.
        var budget = await probe.DescribeConnectionBudgetAsync(CancellationToken.None).ConfigureAwait(false);
        if (budget.PoolMaximum > budget.ServerGrants)
        {
            if (CinerionDataSource.StatesPoolSize(storage.ConnectionString!))
            {
                throw new InvalidOperationException(
                    $"CINERION_DATABASE_MODE=Postgres: the connection string asks for a pool of " +
                    $"{budget.PoolMaximum} but this server grants {budget.ServerGrants}. Lower " +
                    "'Maximum Pool Size' in CINERION_POSTGRES_CONNECTION to at or below what the server " +
                    "grants, allowing for every service instance sharing it.");
            }

            poolCeiling = budget.ServerGrants;

            // Written to the console rather than through the logger: the host is not built
            // yet at this point, and a cap the operator cannot see is a cap nobody will
            // think to override.
            Console.WriteLine(
                $"CINERION_POSTGRES_CONNECTION states no pool size, and Npgsql's default of " +
                $"{budget.PoolMaximum} exceeds the {budget.ServerGrants} connections this server grants. " +
                $"The pool is capped at {budget.ServerGrants} so a request waits for a connection rather " +
                "than failing to obtain one. State 'Maximum Pool Size' explicitly to choose a different " +
                "number, allowing for every service instance sharing this server.");
        }

        // A database at an older schema revision would appear to work until the first
        // operation that needs the newer column, which would surface as a runtime
        // failure in front of an operator. It is named here instead.
        var missing = await probe.FindMissingMigrationsAsync(CancellationToken.None).ConfigureAwait(false);
        if (missing.Count > 0)
        {
            throw new InvalidOperationException(
                "CINERION_DATABASE_MODE=Postgres: the controlled schema is behind this build. Apply: " +
                string.Join(", ", missing));
        }
    }

    var effectiveConnectionString = poolCeiling is { } ceiling
        ? CinerionDataSource.WithPoolSize(storage.ConnectionString!, ceiling)
        : storage.ConnectionString!;

    // The lifetimes live in one place, next to the reasons for them, and are executed by
    // PostgresStorageRegistrationTests rather than only read. The one that matters most is
    // the connection pool: it is per process, because a pool that ends with the request
    // pools nothing.
    builder.Services.AddCinerionPostgresStorage(effectiveConnectionString);
}
else
{
    builder.Services.AddSingleton<ICinerionStore, InMemoryCinerionStore>();
}
builder.Services.AddSingleton(new CommandRuntimeOptions(runtimeProfile));

// The volatile half of cell state — what each controller last reported over
// CH1-COM-IF-0003. A singleton whatever the store is, because it belongs to the process
// rather than to a request, and because it must outlive the per-request store scope that
// PostgreSQL mode uses. Deliberately not durable: CH1-SAF-FR-0003 requires a restart to
// default to a non-energising safe state, so after a restart every cell reads as not
// permissive until a controller reports again.
builder.Services.AddSingleton<CellRuntimeProjection>();

// Application services follow the store's lifetime. With PostgreSQL the store is
// per request, because its connection carries that request's project scope; the
// database then provides serialisation through optimistic concurrency and the audit
// advisory lock. With the in-memory store they stay singletons so their process-wide
// transaction gates continue to serialise read-modify-write across requests, which is
// the only thing protecting a dictionary-backed aggregate.
if (storage.Mode == CinerionStorageMode.Postgres)
{
    builder.Services.AddScoped<CommandService>();
    builder.Services.AddScoped<QualityService>();
    builder.Services.AddScoped<StepUpService>();
    builder.Services.AddScoped<ProjectService>();
    builder.Services.AddScoped<ForgeFlowService>();
    builder.Services.AddScoped<MonitoringService>();
    builder.Services.AddScoped<ContextBridgeService>();
    builder.Services.AddScoped<ResourceOrchestratorService>();
    builder.Services.AddScoped<ResearchBenchService>();
    builder.Services.AddScoped<DevicePkiService>();
    builder.Services.AddScoped<CredentialService>();
    builder.Services.AddScoped<ReportForgeService>();
    builder.Services.AddScoped<PublicationPipelineService>();
    builder.Services.AddScoped<FieldCompanionService>();
    builder.Services.AddScoped<CellStateResolver>();
    builder.Services.AddScoped<EdgeIngressService>();
}
else
{
    builder.Services.AddSingleton<CommandService>();
    builder.Services.AddSingleton<QualityService>();
    builder.Services.AddSingleton<StepUpService>();
    builder.Services.AddSingleton<ProjectService>();
    builder.Services.AddSingleton<ForgeFlowService>();
    builder.Services.AddSingleton<MonitoringService>();
    builder.Services.AddSingleton<ContextBridgeService>();
    builder.Services.AddSingleton<ResourceOrchestratorService>();
    builder.Services.AddSingleton<ResearchBenchService>();
    builder.Services.AddSingleton<DevicePkiService>();
    builder.Services.AddSingleton<CredentialService>();
    builder.Services.AddSingleton<ReportForgeService>();
    builder.Services.AddSingleton<PublicationPipelineService>();
    builder.Services.AddSingleton<FieldCompanionService>();
    builder.Services.AddSingleton<CellStateResolver>();
    builder.Services.AddSingleton<EdgeIngressService>();
}

// Telemetry has to come from somewhere before the query, alarm and acknowledgement
// path can be verified on a running system. The device path (MQTT over TLS with
// per-device certificates, through EdgeLink) is PKI and hardware gated, so in the
// Simulation profile a simulated source feeds the ordinary ingestion path. It is
// registered only in that profile, and every sample it writes carries Simulated
// freshness so no view can mistake it for a live reading.
//
// CINERION_SIMULATED_TELEMETRY=false turns it off, for running the Simulation profile
// against a real feed and for tests that need a store nothing else is writing to.
var simulatedTelemetry = !string.Equals(
    builder.Configuration["CINERION_SIMULATED_TELEMETRY"],
    "false",
    StringComparison.OrdinalIgnoreCase);
if (runtimeProfile == CommandRuntimeProfile.Simulation && simulatedTelemetry)
{
    builder.Services.AddHostedService<SimulatedCellTelemetrySource>();
}

builder.Services.AddScoped<ActorContextFactory>();

// FortressGate owns identity, so user administration reaches the identity provider
// rather than any ch1 table. The secret comes from configuration and is never held in
// source or a realm export. When it is absent the directory refuses every operation
// instead of returning an empty list, so the development identity scheme — which has no
// directory behind it — cannot answer a security question with invented data.
var identityAdmin = new IdentityAdminOptions(
    builder.Configuration["CINERION_OIDC_AUTHORITY"],
    builder.Configuration["CINERION_KEYCLOAK_IDENTITY_ADMIN_CLIENT"],
    builder.Configuration["CINERION_KEYCLOAK_IDENTITY_ADMIN_SECRET"],
    builder.Configuration["CINERION_OIDC_PORTAL_CLIENT"] ?? "cinerion-operator-portal");
builder.Services.AddSingleton(identityAdmin);
if (identityAdmin.IsConfigured)
{
    builder.Services.AddHttpClient<IIdentityDirectory, KeycloakIdentityDirectory>()
        .ConfigureHttpClient(client => client.Timeout = TimeSpan.FromSeconds(15));
    builder.Services.AddSingleton(TimeProvider.System);
}
else
{
    builder.Services.AddSingleton<IIdentityDirectory>(new UnconfiguredIdentityDirectory(
        "CINERION_KEYCLOAK_IDENTITY_ADMIN_CLIENT and CINERION_KEYCLOAK_IDENTITY_ADMIN_SECRET are not set."));
}

builder.Services.AddScoped<IdentityAdministrationService>();

// Device identities over HTTP, on their own mutually authenticated listener.
//
// Declared BEFORE the human scheme because the human scheme's registration is what fixes
// the default, and the two must not compete for it: a request on the device listener is
// answered by the device scheme and a request anywhere else is not, which the handler
// decides from the local port rather than from anything the caller sends.
//
// All five settings or none. An unconfigured deployment has no device listener at all, so
// the controller-local operations are UNREACHABLE rather than reachable without a client
// certificate - the same fail-closed direction the gRPC edge and both protocol adapters
// take, and for the same reason.
var deviceCertificates = DeviceCertificateOptions.FromConfiguration(builder.Configuration);
if (deviceCertificates is not null)
{
    builder.Services.AddSingleton(deviceCertificates);
}

// Which scheme a human session is authenticated by. Named rather than implied, because
// the authorisation policy below has to list it beside the device scheme: a policy that
// took the default would accept only one of the two.
var defaultAuthenticationScheme = allowDevelopmentIdentity
    ? DevelopmentAuthenticationHandler.SchemeName
    : JwtBearerDefaults.AuthenticationScheme;

if (allowDevelopmentIdentity)
{
    builder.Services
        .AddAuthentication(DevelopmentAuthenticationHandler.SchemeName)
        .AddScheme<DevelopmentAuthenticationOptions, DevelopmentAuthenticationHandler>(
            DevelopmentAuthenticationHandler.SchemeName,
            options => options.Enabled = true);
}
else
{
    var authority = builder.Configuration["CINERION_OIDC_AUTHORITY"]
        ?? throw new InvalidOperationException("CINERION_OIDC_AUTHORITY is required when development identity is disabled.");
    var audience = builder.Configuration["CINERION_OIDC_AUDIENCE"] ?? "cinerion-control-core";
    builder.Services
        .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(options =>
        {
            options.Authority = authority;
            options.Audience = audience;

            // Where the discovery document and signing keys are FETCHED, when that differs
            // from the issuer the tokens carry. In a container deployment it always does:
            // the browser reaches the identity provider on a published host port, so every
            // token is issued for that URL, and the same URL does not resolve from inside
            // this container. Setting only the authority makes startup fail on a discovery
            // fetch it cannot perform.
            //
            // This changes where keys come from and NOTHING about what is accepted. The
            // issuer, audience, lifetime and signing key are all still validated below,
            // against the public issuer. Unset, the authority is used for both, which is
            // the correct behaviour whenever the two addresses are the same.
            var metadataAddress = builder.Configuration["CINERION_OIDC_METADATA_ADDRESS"];
            if (!string.IsNullOrWhiteSpace(metadataAddress))
            {
                options.MetadataAddress = metadataAddress;
            }
            options.RequireHttpsMetadata = runtimeProfile == CommandRuntimeProfile.Production;
            options.MapInboundClaims = false;

            // Validation is stated explicitly rather than left to defaults, so that a
            // future framework default cannot silently relax issuer, audience or
            // lifetime checking on the controlled API.
            options.TokenValidationParameters.ValidateIssuer = true;
            options.TokenValidationParameters.ValidIssuer = authority;
            options.TokenValidationParameters.ValidateAudience = true;
            options.TokenValidationParameters.ValidAudience = audience;
            options.TokenValidationParameters.ValidateLifetime = true;
            options.TokenValidationParameters.ValidateIssuerSigningKey = true;

            // The framework default tolerates five minutes of clock drift. Commands
            // carry short expiry windows, so an accepted token must not outlive its
            // stated lifetime by longer than the window it is used to authorise.
            options.TokenValidationParameters.ClockSkew = TimeSpan.FromSeconds(30);

            // MapInboundClaims=false keeps the original JWT claim names, so identity
            // and roles must be read under those names rather than the WS-Federation
            // URIs. The realm role mapper emits a flat "roles" array; without this the
            // roles arrive nested inside realm_access and every role check denies.
            options.TokenValidationParameters.NameClaimType = ActorContextFactory.ClaimNames.Subject;
            options.TokenValidationParameters.RoleClaimType = ActorContextFactory.ClaimNames.Role;
        });
}

// CH1-COM-IF-0003: CommandGuard to EdgeLink, internal gRPC, Protobuf, mTLS.
//
// The edge is raised only when the deployment has been issued everything it needs —
// port, controlled CA, server certificate, its key and the gateway identity to expect.
// All five or none, exactly as the MQTT and OPC UA adapters are configured, and for the
// same reason: a partially configured mutual-TLS edge is the one case where a helpful
// default would silently drop mutual authentication. Unconfigured means there is no
// listener at all, so the ingress is unreachable rather than reachable without a
// certificate.
//
// It is a separate listener from the REST API on purpose. The two surfaces have different
// callers, different credentials and different zones: CH1-COM-IF-0001 carries the portal
// over OIDC on the presentation network, and this carries a gateway over mutual TLS on the
// control network. Putting them on one port would mean one connection could reach both.
var edgeIngress = EdgeIngressOptions.FromConfiguration(builder.Configuration);
if (edgeIngress is not null)
{
    builder.Services.AddSingleton(edgeIngress);
    builder.Services.AddGrpc(options =>
    {
        // A gateway's message is small and bounded. CH1-COM-PRO-0001 requires flow control
        // to cap memory, and the default 4 MB is far more than any controlled message on
        // this edge needs.
        options.MaxReceiveMessageSize = 256 * 1024;
        options.EnableDetailedErrors = false;
    });
}

// The listeners, and the host names this service answers to.
//
// Conditional on EITHER mutually authenticated surface, not on the gRPC edge alone. The
// device listener was first added inside the edge's own `if`, so a deployment that
// configured device identities and not the internal gRPC edge bound no device port at all
// - and `GET /api/v1/system/health` reported the listener as enabled while a controller
// met "connection actively refused". The two surfaces are independent and are configured
// independently.
//
// Declaring ANY endpoint here stops Kestrel honouring ASPNETCORE_URLS and
// ASPNETCORE_HTTP_PORTS, and it says so only in a warning - so the controlled REST API is
// restated inside whichever branch runs, or it silently disappears.
if (edgeIngress is not null || deviceCertificates is not null)
{
    // Every name a caller may legitimately address this service by, taken from the common
    // names of the certificates this deployment's own authority attested rather than from
    // free-text settings. A name nobody attested is not added.
    string[] attestedNames =
    [
        .. edgeIngress is null || string.IsNullOrWhiteSpace(edgeIngress.ServiceCommonName)
            ? Array.Empty<string>()
            : [edgeIngress.ServiceCommonName],
        .. deviceCertificates is null || string.IsNullOrWhiteSpace(deviceCertificates.ServiceCommonName)
            ? Array.Empty<string>()
            : [deviceCertificates.ServiceCommonName],
    ];

    // AllowedHosts=localhost is a deliberate setting for the REST API, and host filtering is
    // one global middleware rather than a per-endpoint one. A gateway's gRPC call carries
    // the Compose service name as its :authority and was answered 400 before reaching any
    // handler — reported by the client as "Bad gRPC response. HTTP status code: 400", which
    // reads like a protocol fault and is nothing of the kind. The one extra name accepted is
    // taken from the common name of this service's own certificate, so it is a name the
    // controlled authority attested rather than one a setting invented, and localhost stays
    // the only host the REST API answers to.
    //
    // The configured hosts are read here rather than appended to whatever the options
    // already hold, and that is not fussiness. The host builder fills AllowedHosts in a
    // *post*-configure step that runs only when the list is still empty, so appending to it
    // suppressed the framework's own step and left "control-core" as the only permitted
    // host — every request naming localhost, including the container healthcheck, was then
    // answered "400 Bad Request - Invalid Hostname". Stating the whole list removes the
    // ordering question entirely.
    var configuredHosts = (builder.Configuration["AllowedHosts"] ?? "localhost")
        .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
    builder.Services.Configure<Microsoft.AspNetCore.HostFiltering.HostFilteringOptions>(options =>
        options.AllowedHosts = [.. configuredHosts, .. attestedNames]);

    builder.WebHost.ConfigureKestrel(kestrel =>
    {
        // Kestrel stops honouring ASPNETCORE_URLS and ASPNETCORE_HTTP_PORTS the moment any
        // endpoint is configured here, and says so only in a warning. The controlled REST
        // API therefore has to be restated alongside the ingress or it silently disappears
        // — which is exactly what happened the first time this ran: the service came up
        // listening on 8443 alone, every HTTP request failed, and the log line that
        // explained it was "Overriding address(es)".
        foreach (var port in ConfiguredHttpPorts(builder.Configuration))
        {
            kestrel.ListenAnyIP(port, listen =>
                listen.Protocols = Microsoft.AspNetCore.Server.Kestrel.Core.HttpProtocols.Http1AndHttp2);
        }

        if (edgeIngress is not null)
        {
            kestrel.ListenAnyIP(edgeIngress.Port, listen =>
            {
                listen.Protocols = Microsoft.AspNetCore.Server.Kestrel.Core.HttpProtocols.Http2;
                listen.UseHttps(edgeIngress.ServerCertificate, https =>
                {
                    https.ClientCertificateMode =
                        Microsoft.AspNetCore.Server.Kestrel.Https.ClientCertificateMode.RequireCertificate;

                    // Stated rather than inherited. The default validation consults the
                    // machine trust store, which would accept a certificate from any public
                    // authority carrying the right name; this accepts only what the
                    // controlled CA signed.
                    https.ClientCertificateValidation = (certificate, _, errors) =>
                        edgeIngress.IsIssuedByControlledAuthority(certificate, errors);
                });
            });
        }

        // The device listener, for cell controllers and bound instrument adapters.
        //
        // A THIRD listener and a third set of callers. The REST API carries humans over
        // OIDC, the gRPC edge carries the gateway, and this carries device identities
        // speaking the controlled HTTP catalogue - the credential proof and the local
        // commit above all, which `ValidateController` will only accept from an
        // mTLS-authenticated device. Keeping it on its own port is what makes the
        // separation real: a browser on the REST port cannot become a controller by
        // sending different headers, because there is no header that does it.
        if (deviceCertificates is not null)
        {
            kestrel.ListenAnyIP(deviceCertificates.Port, listen =>
            {
                listen.Protocols = Microsoft.AspNetCore.Server.Kestrel.Core.HttpProtocols.Http1AndHttp2;
                listen.UseHttps(deviceCertificates.ServerCertificate, https =>
                {
                    https.ClientCertificateMode =
                        Microsoft.AspNetCore.Server.Kestrel.Https.ClientCertificateMode.RequireCertificate;
                    https.ClientCertificateValidation = (certificate, _, errors) =>
                        deviceCertificates.IsIssuedByControlledAuthority(certificate, errors);
                });
            });
        }
    });
}

/// <summary>
/// The HTTP ports the controlled REST API is meant to be served on, read from the same
/// settings the host would have used had nothing been configured explicitly. Restating them
/// is not optional once any Kestrel endpoint is declared, because the host stops reading
/// them at that point.
/// </summary>
static IReadOnlyList<int> ConfiguredHttpPorts(IConfiguration configuration)
{
    var declared = configuration["ASPNETCORE_HTTP_PORTS"];
    if (!string.IsNullOrWhiteSpace(declared))
    {
        var ports = declared
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(value => int.TryParse(value, out var port) ? port : 0)
            .Where(port => port is > 0 and <= 65535)
            .ToArray();
        if (ports.Length > 0)
        {
            return ports;
        }
    }

    var urls = configuration["ASPNETCORE_URLS"] ?? configuration["urls"];
    if (!string.IsNullOrWhiteSpace(urls))
    {
        var ports = urls
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(value => Uri.TryCreate(value.Replace("*", "localhost", StringComparison.Ordinal), UriKind.Absolute, out var uri) ? uri.Port : 0)
            .Where(port => port is > 0 and <= 65535)
            .ToArray();
        if (ports.Length > 0)
        {
            return ports;
        }
    }

    // The port the controlled container image declares, and the one every compose model,
    // healthcheck and gate addresses.
    return [8080];
}

/// <summary>
/// The TLS port the controlled REST API is served on, if a deployment states one. Never
/// inferred from the endpoints the server happens to be listening on: one of those belongs
/// to CH1-COM-IF-0003 and requires a client certificate, and a redirect onto it would break
/// every browser and every gateway-unaware client.
/// </summary>
static int? ConfiguredHttpsPort(IConfiguration configuration)
{
    var declared = configuration["ASPNETCORE_HTTPS_PORTS"] ?? configuration["CINERION_API_HTTPS_PORT"];
    if (string.IsNullOrWhiteSpace(declared))
    {
        return null;
    }

    var first = declared.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
        .FirstOrDefault();
    return int.TryParse(first, out var port) && port is > 0 and <= 65535 ? port : null;
}

// HTTPS redirection must never infer its target, and this is not a theoretical preference.
// With no TLS endpoint of its own the middleware did nothing; the moment CH1-COM-IF-0003's
// mutually authenticated listener existed it found that port and began answering every API
// request with `307 → https://…:8443`, redirecting the portal onto a gateway interface that
// requires a client certificate no browser holds. Observed directly, on a running service.
//
// The redirect target is therefore taken from configuration and the middleware is applied
// only when a deployment actually states one. An API served plaintext behind a loopback
// binding or a TLS-terminating proxy — which is every deployment in this checkpoint — is
// unchanged, because the middleware was already a no-op there.
var apiHttpsPort = ConfiguredHttpsPort(builder.Configuration);
if (apiHttpsPort is int httpsPort)
{
    builder.Services.AddHttpsRedirection(options => options.HttpsPort = httpsPort);
}

// The device scheme is added to whichever authentication builder the human scheme just
// created, so both are registered and neither is the other's default. `AddAuthentication()`
// with no argument returns the existing builder rather than replacing it.
if (deviceCertificates is not null)
{
    builder.Services
        .AddAuthentication()
        .AddScheme<DeviceCertificateAuthenticationOptions, DeviceCertificateAuthenticationHandler>(
            DeviceCertificateAuthenticationHandler.SchemeName,
            options =>
            {
                options.Port = deviceCertificates.Port;
                options.DeclaredProjectId = deviceCertificates.ProjectId;
            });
}

// Every endpoint that says RequireAuthorization() gets this policy, and it accepts EITHER
// a human session or a device certificate.
//
// It has to name both schemes rather than take the default, because the default is the
// human one and an endpoint that only accepted it would refuse every device. The
// endpoints themselves are unchanged and stay the place authority is decided: a human
// reaching /credential-proofs is still refused by `ValidateController`, which requires
// ActorKind.Device, the DeviceController role and MutualTls strength, and a device
// reaching a human operation is refused by that operation's own role check. Authentication
// says WHO is speaking; none of these rules moved.
builder.Services.AddAuthorization(options =>
{
    var schemes = deviceCertificates is null
        ? new[] { defaultAuthenticationScheme }
        : [defaultAuthenticationScheme, DeviceCertificateAuthenticationHandler.SchemeName];
    options.DefaultPolicy = new Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder(schemes)
        .RequireAuthenticatedUser()
        .Build();
});
builder.Services.AddCors(options => options.AddPolicy("DevelopmentPortal", policy =>
{
    if (builder.Environment.IsDevelopment())
    {
        policy.WithOrigins("http://localhost:8081", "http://localhost:19006")
            .AllowAnyHeader()
            .AllowAnyMethod();
    }
}));

var app = builder.Build();
app.UseMiddleware<CorrelationMiddleware>();
app.UseExceptionHandler();
app.UseStatusCodePages();
if (apiHttpsPort is not null)
{
    app.UseHttpsRedirection();
}

app.UseCors("DevelopmentPortal");
app.UseAuthentication();
app.UseAuthorization();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

if (runtimeProfile == CommandRuntimeProfile.Production)
{
    throw new InvalidOperationException(
        "P03 does not authorise the Production runtime profile. Complete independent review, safety acceptance, persistent store, and production identity gates first.");
}

// The store may be per request, so the seed runs inside its own scope. The scope is
// set to the prototype project first, otherwise row-level security would correctly
// refuse every write the seed attempts.
await using (var seedScope = app.Services.CreateAsyncScope())
{
    seedScope.ServiceProvider.GetService<ProjectScope>()?.Set(PrototypeSeed.Ids.ProjectId);
    var seedStore = seedScope.ServiceProvider.GetRequiredService<ICinerionStore>();
    await PrototypeSeed.ApplyAsync(seedStore, app.Lifetime.ApplicationStopping).ConfigureAwait(false);

    // A demonstration dataset, off unless asked for. The prototype seed leaves most of the
    // 22 declared screens showing their empty state, and an empty screen is indistinguishable
    // from a broken one — which is a real problem for anyone reviewing this, and the only
    // reason this exists.
    //
    // Every record it writes says what it is: telemetry is Simulated and never Live, no
    // command reaches an executing or committed state, and credentials carry no secret
    // material. It is unreachable in the Production profile because the block above refuses
    // to start at all in one.
    if (demonstrationData)
    {
        // Console rather than ILogger: CA1848 wants a LoggerMessage delegate for a hot path,
        // and this runs once at start-up before the application is serving anything.
        Console.WriteLine(
            "CINERION_DEMONSTRATION_DATA is on: seeding demonstration records. Telemetry is " +
            "marked Simulated, no command is executable, and no credential can authenticate.");
        try
        {
            await DemonstrationSeed.ApplyAsync(seedStore, app.Lifetime.ApplicationStopping).ConfigureAwait(false);
        }
        catch (Exception error)
        {
            // A DEMONSTRATION dataset must never be able to stop a controlled service from
            // starting. It failed twice while being written — once on a NOT NULL column no
            // writer set (defect 67), once on a duplicate key from an interrupted retry — and
            // each time it took the host down, which turned a cosmetic problem into an
            // unavailable service and made the actual cause hard to see behind a restart loop.
            //
            // Loud rather than silent, and rethrown for nothing: the service comes up, the
            // reason is on the console, and `npm run demo:data` then reports precisely which
            // screens have nothing behind them. An empty screen is a visible problem; a
            // service that will not start is a worse one.
            Console.WriteLine(
                "CINERION_DEMONSTRATION_DATA: the dataset could not be applied and the service " +
                "is starting without it. Screens will show their empty state. Reason: " + error);
        }
    }
}

app.MapSystemEndpoints(runtimeProfile, allowDevelopmentIdentity, deviceCertificates is not null);
app.MapAuthenticationEndpoints();
app.MapOperationsEndpoints();
app.MapForgeFlowEndpoints();
app.MapCommandEndpoints();
app.MapQualityEndpoints();
app.MapMonitoringEndpoints();
app.MapContextBridgeEndpoints();
app.MapResourceEndpoints();
app.MapResearchBenchEndpoints();
app.MapIdentityAdministrationEndpoints();
app.MapDevicePkiEndpoints();
app.MapCredentialEndpoints();
app.MapEvidenceEndpoints();
app.MapPublicationEndpoints();
app.MapOwnerApprovedReadEndpoints();
app.MapAuditEndpoints();
app.MapDeferredCatalogueEndpoints();

// CH1-COM-IF-0003. Mapped only when the edge is configured, so an unconfigured deployment
// has neither a listener nor a route. The service itself refuses any call that did not
// arrive on the ingress listener, so the two controls are independent.
if (edgeIngress is not null)
{
    app.MapGrpcService<EdgeLinkIngressGrpcService>();
}

await app.RunAsync().ConfigureAwait(false);

public partial class Program;
