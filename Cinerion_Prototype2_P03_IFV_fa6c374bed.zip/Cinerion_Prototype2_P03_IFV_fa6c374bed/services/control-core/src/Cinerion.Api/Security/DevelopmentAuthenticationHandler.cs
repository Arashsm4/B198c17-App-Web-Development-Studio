// Fake login for local development and tests only. Refused everywhere else, no exceptions.

using System.Globalization;
using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace Cinerion.Api.Security;

public sealed class DevelopmentAuthenticationOptions : AuthenticationSchemeOptions
{
    public bool Enabled { get; set; }
}

/// <summary>
/// Explicit local simulator identity. This handler is registered only when the
/// host is Development and CINERION_ALLOW_DEVELOPMENT_IDENTITY=true.
/// It is not a production authentication mechanism.
/// </summary>
public sealed class DevelopmentAuthenticationHandler(
    IOptionsMonitor<DevelopmentAuthenticationOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder)
    : AuthenticationHandler<DevelopmentAuthenticationOptions>(options, logger, encoder)
{
    /// <summary>
    /// Scheme identifier. Named <c>SchemeName</c> rather than <c>Scheme</c> because
    /// <see cref="AuthenticationHandler{TOptions}.Scheme"/> already defines a
    /// non-string <c>Scheme</c> property; a const of the same name hid it (CS0108)
    /// and silently rebound every in-class use of <c>Scheme</c> to this literal.
    /// </summary>
    public const string SchemeName = "CinerionDevelopmentIdentity";

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!Options.Enabled)
        {
            return Task.FromResult(AuthenticateResult.NoResult());
        }

        if (!Request.Headers.TryGetValue("X-CH1-Actor", out var actor) ||
            string.IsNullOrWhiteSpace(actor.FirstOrDefault()))
        {
            return Task.FromResult(AuthenticateResult.Fail("Explicit X-CH1-Actor is required in development mode."));
        }

        if (!Request.Headers.TryGetValue("X-CH1-Project", out var project) ||
            !Guid.TryParse(project.FirstOrDefault(), out var projectId))
        {
            return Task.FromResult(AuthenticateResult.Fail("Valid X-CH1-Project is required in development mode."));
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, actor.First()!),
            new("ch1_project", projectId.ToString()),
            new("ch1_actor_kind", Request.Headers["X-CH1-Actor-Kind"].FirstOrDefault() ?? "Human"),
            new("ch1_auth_strength", Request.Headers["X-CH1-Auth-Strength"].FirstOrDefault() ?? "SingleFactor"),
            new("sid", Request.Headers["X-CH1-Session"].FirstOrDefault() ?? Guid.NewGuid().ToString()),
            new("ch1_development_identity", "true"),

            // Mirrors the OIDC auth_time claim so recency-dependent rules exercise the
            // same code path locally. X-CH1-Auth-Time carries Unix seconds and lets a
            // test present a deliberately stale session; the default is "just now".
            new(
                ActorContextFactory.ClaimNames.AuthenticationTime,
                Request.Headers["X-CH1-Auth-Time"].FirstOrDefault()
                    ?? DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture)),
        };

        foreach (var role in SplitHeader(Request.Headers["X-CH1-Roles"].FirstOrDefault()))
        {
            claims.Add(new Claim(ClaimTypes.Role, role));
        }

        foreach (var cell in SplitHeader(Request.Headers["X-CH1-Cells"].FirstOrDefault()))
        {
            if (!Guid.TryParse(cell, out var cellId))
            {
                return Task.FromResult(AuthenticateResult.Fail("X-CH1-Cells contains an invalid UUID."));
            }

            claims.Add(new Claim("ch1_cell", cellId.ToString()));
        }

        var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, SchemeName));
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(principal, SchemeName)));
    }

    private static IEnumerable<string> SplitHeader(string? value) =>
        (value ?? string.Empty)
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Distinct(StringComparer.Ordinal);
}
