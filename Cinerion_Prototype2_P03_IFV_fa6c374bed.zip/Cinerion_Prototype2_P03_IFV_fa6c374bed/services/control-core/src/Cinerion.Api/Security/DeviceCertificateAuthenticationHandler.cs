// Authenticates devices by client certificate on their own listener. Headers can't talk their
// way in.

using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Encodings.Web;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace Cinerion.Api.Security;

public sealed class DeviceCertificateAuthenticationOptions : AuthenticationSchemeOptions
{
    /// <summary>The port device identities are answered on; requests elsewhere are not this scheme's.</summary>
    public int Port { get; set; }

    /// <summary>
    /// The project whose device register this listener resolves certificates against.
    /// <para>
    /// A device cannot state its own project - that is the whole point of taking the
    /// identity from the enrolled record - and the record cannot be found until the query
    /// runs under a project scope, because row-level security is what keeps one project's
    /// devices out of another's reads. So the deployment declares which project's cell
    /// controllers this listener serves, and a deployment that declares none has no device
    /// listener at all rather than one that searches everywhere.
    /// </para>
    /// </summary>
    public Guid DeclaredProjectId { get; set; }
}

/// <summary>
/// Authenticates a device by the certificate it presented, against the record this
/// platform enrolled.
/// <para>
/// Everything about the identity comes from the enrolled record and nothing from the
/// request. The certificate says which device is speaking; <c>ch1.devices</c> says which
/// project and cell that device belongs to, and whether its trust still stands. A device
/// therefore cannot name its own scope, which is the difference between this and the
/// development identity handler — there, every claim is a header the caller chose, which
/// is exactly why that handler is not a production authentication mechanism.
/// </para>
/// <para>
/// Three refusals matter and each is separate. A certificate this deployment's authority
/// did not issue never reaches here: Kestrel refuses the handshake. A certificate that
/// matches no enrolled device is refused, because enrolment is what makes an identity
/// exist. And a device whose trust has been withdrawn is refused even though its
/// certificate is still perfectly valid — revocation is a decision about the device, not
/// about its key material, and CH1-CYB-IAM-0001's lost-token response depends on the
/// platform acting on that decision rather than on the certificate expiring eventually.
/// </para>
/// <para>
/// The roles are fixed at <see cref="CinerionRoles.DeviceController"/> and are not read
/// from anywhere. A device cannot hold a human role: <c>RoleSegregation</c> and
/// CH1-IAM-FR-0008 keep the two populations apart, and a scheme that could grant Inspector
/// to a machine would defeat the whole of CH1-CYB-ACP-0001 from outside it.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0008, CH1-CYB-FR-0001, CH1-CYB-FR-0003, CH1-AUT-FDS-0001</requirements>
public sealed partial class DeviceCertificateAuthenticationHandler(
    IOptionsMonitor<DeviceCertificateAuthenticationOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder,
    IServiceProvider services)
    : AuthenticationHandler<DeviceCertificateAuthenticationOptions>(options, logger, encoder)
{
    public const string SchemeName = "CinerionDeviceCertificate";

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        // A request that did not arrive on the device listener is not this scheme's to
        // decide. Returning NoResult rather than Fail lets the human scheme answer it,
        // which is what keeps one listener from becoming a second door into the other.
        if (Context.Connection.LocalPort != Options.Port)
        {
            return AuthenticateResult.NoResult();
        }

        var certificate = await Context.Connection.GetClientCertificateAsync(Context.RequestAborted)
            .ConfigureAwait(false);
        if (certificate is null)
        {
            // Kestrel is configured to require one, so this is belt and braces rather than
            // the main control — and it is stated rather than left to a null reference.
            return AuthenticateResult.Fail("No client certificate was presented on the device listener.");
        }

        // The same computation the enrolment path performs, so the value compared here is
        // the value stored there. A different hash would silently match nothing and every
        // device would read as unenrolled.
        var thumbprint = Convert.ToHexStringLower(certificate.GetCertHash(HashAlgorithmName.SHA256));

        // The device lookup is by thumbprint within a project, and the project is not
        // known before the device is found - so the query runs with row-level security
        // scoped to the project the deployment declares its devices live in. That is the
        // same project every other device operation is scoped to, and a deployment that
        // does not declare one has no device listener at all.
        var projectId = Options.DeclaredProjectId;
        if (projectId == Guid.Empty)
        {
            return AuthenticateResult.Fail(
                "The device listener has no declared project scope, so no enrolled device can be resolved.");
        }

        // CreateAsyncScope, and this is not style. `CinerionDataSource` implements
        // IAsyncDisposable and NOT IDisposable, so a synchronous scope disposal throws
        // InvalidOperationException - AFTER the authentication decision has been made.
        // Every device request against PostgreSQL therefore answered 500 while the
        // handler had authenticated it perfectly, and nothing caught it: the in-memory
        // store has no data source to dispose, so the tests and the commit-loop gate
        // both passed. Found by running the stand-in controller against the real lab.
        await using var scope = services.CreateAsyncScope();
        scope.ServiceProvider.GetService<ProjectScope>()?.Set(projectId);
        var store = scope.ServiceProvider.GetRequiredService<ICinerionStore>();
        var device = await store
            .FindDeviceByThumbprintAsync(projectId, thumbprint, Context.RequestAborted)
            .ConfigureAwait(false);

        if (device is null)
        {
            // Deliberately the same message whichever way it failed. A caller must not be
            // able to tell "no such device" from "not in this project" by probing.
            return AuthenticateResult.Fail("The presented certificate does not identify an enrolled device.");
        }

        if (device.IsRevoked)
        {
            // Logged rather than only refused. A revoked device still presenting a valid
            // certificate is a security event of interest whichever way it happened - a
            // controller nobody took off the network, or one somebody put back.
            LogRevokedDeviceRefused(Logger, device.DeviceId, thumbprint);
            return AuthenticateResult.Fail("The device presenting this certificate has had its trust withdrawn.");
        }

        if (!device.IsTrusted)
        {
            return AuthenticateResult.Fail("The device presenting this certificate is not in a trusted state.");
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, device.DeviceId),
            new(ActorContextFactory.ClaimNames.Project, device.ProjectId.ToString()),
            new(ActorContextFactory.ClaimNames.ActorKind, nameof(ActorKind.Device)),
            // Stated, and true: the connection this request arrived on was mutually
            // authenticated against the controlled authority. It is not a claim the
            // caller made.
            new(ActorContextFactory.ClaimNames.AuthenticationStrength, nameof(AuthenticationStrength.MutualTls)),
            new(ActorContextFactory.ClaimNames.SessionId, $"mtls:{thumbprint[..16]}"),
            new(ClaimTypes.Role, CinerionRoles.DeviceController),
        };

        if (device.CellId is { } cellId)
        {
            claims.Add(new Claim(ActorContextFactory.ClaimNames.Cell, cellId.ToString()));
        }

        var identity = new ClaimsIdentity(claims, SchemeName, ActorContextFactory.ClaimNames.Subject, ClaimTypes.Role);
        return AuthenticateResult.Success(
            new AuthenticationTicket(new ClaimsPrincipal(identity), SchemeName));
    }

    [LoggerMessage(
        EventId = 2100,
        Level = LogLevel.Warning,
        Message = "Device {DeviceId} presented a valid certificate ({Thumbprint}) after its trust was withdrawn; refused.")]
    private static partial void LogRevokedDeviceRefused(ILogger logger, string deviceId, string thumbprint);
}
