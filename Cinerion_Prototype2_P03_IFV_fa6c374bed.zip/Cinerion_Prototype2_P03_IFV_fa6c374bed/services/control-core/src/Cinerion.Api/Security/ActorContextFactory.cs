// Turns a signed-in principal into who, which scope and which roles. The server decides, not
// the client.

using System.Globalization;
using System.Security.Claims;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Persistence;

namespace Cinerion.Api.Security;

/// <summary>
/// Translates an authenticated principal into the server-side authorisation context.
/// It is the single place where the CH1 identity claim contract is interpreted, so
/// the development scheme and the OIDC scheme cannot drift apart.
/// </summary>
/// <requirements>CH1-IAM-FR-0001, CH1-IAM-FR-0004, CH1-IAM-FR-0008, CH1-CYB-FR-0001</requirements>
public sealed class ActorContextFactory(IServiceProvider services)
{
    /// <summary>
    /// Claim names forming the CH1 identity contract. The OIDC side of this contract
    /// is produced by the protocol mappers in
    /// infrastructure/keycloak/cinerion-realm.json; the development side is produced
    /// by <see cref="DevelopmentAuthenticationHandler"/>.
    /// </summary>
    public static class ClaimNames
    {
        public const string Subject = "sub";
        public const string SessionId = "sid";
        public const string Role = "roles";
        public const string Project = "ch1_project";
        public const string Cell = "ch1_cell";
        public const string ActorKind = "ch1_actor_kind";
        public const string AuthenticationStrength = "ch1_auth_strength";
        public const string AuthenticationMethods = "amr";
        public const string AuthenticationTime = "auth_time";
    }

    public ActorContext Create(ClaimsPrincipal principal)
    {
        var actorId = principal.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? principal.FindFirstValue(ClaimNames.Subject)
            ?? throw new DomainRuleException("AUTH_IDENTITY_REQUIRED", "Authenticated actor identifier is missing.");
        var projectId = ParseRequiredGuid(principal.FindFirstValue(ClaimNames.Project), "AUTH_PROJECT_SCOPE_REQUIRED");
        var actorKind = ParseEnum(principal.FindFirstValue(ClaimNames.ActorKind), ActorKind.Human);
        var strength = ResolveAuthenticationStrength(principal);
        var roles = RoleClaims(principal).Select(item => item.Value).ToHashSet(StringComparer.Ordinal);
        var cells = principal.FindAll(ClaimNames.Cell)
            .Select(item => ParseRequiredGuid(item.Value, "AUTH_CELL_SCOPE_INVALID"))
            .ToHashSet();
        // The database scope is established from the identity, at the one point where
        // the identity is authoritatively resolved. Every store call in this request
        // then runs under row-level security for exactly this project, and a request
        // that never reaches here reads nothing rather than everything.
        services.GetService<ProjectScope>()?.Set(projectId);

        var sessionId = principal.FindFirstValue(ClaimNames.SessionId) ?? "session-unavailable";
        return new ActorContext(
            actorId,
            actorKind,
            roles,
            strength,
            projectId,
            cells,
            sessionId,
            ResolveAuthenticationTime(principal));
    }

    /// <summary>
    /// Reads the OIDC <c>auth_time</c> claim (seconds since the Unix epoch). Left null
    /// when absent or unparseable, so recency is treated as unknown rather than fresh;
    /// step-up then refuses instead of silently accepting a stale session.
    /// </summary>
    private static DateTimeOffset? ResolveAuthenticationTime(ClaimsPrincipal principal) =>
        long.TryParse(
            principal.FindFirstValue(ClaimNames.AuthenticationTime),
            NumberStyles.Integer,
            CultureInfo.InvariantCulture,
            out var seconds)
            ? DateTimeOffset.FromUnixTimeSeconds(seconds)
            : null;

    /// <summary>
    /// Roles are read through each identity's own <see cref="ClaimsIdentity.RoleClaimType"/>.
    /// The development handler issues <see cref="ClaimTypes.Role"/>; the OIDC handler is
    /// configured for the flat <c>roles</c> claim emitted by the realm role mapper.
    /// Reading one fixed claim type would return an empty role set for the other scheme
    /// and deny every role-gated operation.
    /// </summary>
    private static IEnumerable<Claim> RoleClaims(ClaimsPrincipal principal) =>
        principal.Identities.SelectMany(identity => identity.FindAll(identity.RoleClaimType));

    /// <summary>
    /// Authentication strength describes how the current session was authenticated, so
    /// it is never read from a stored user attribute. A stored attribute would grant a
    /// permanent step-up and defeat the release, credential and security-policy gates in
    /// CH1-CYB-ACP-0001.
    /// <para>
    /// The development handler states the value explicitly and is reachable only when
    /// the host is Development and CINERION_ALLOW_DEVELOPMENT_IDENTITY=true. For OIDC the
    /// value is derived from the token's <c>amr</c> (RFC 8176), which the identity
    /// provider sets per authentication.
    /// </para>
    /// <para>
    /// The OIDC derivation is deliberately capped at <see cref="AuthenticationStrength.Mfa"/>.
    /// CH1-CYB-IAM-0001 requires step-up to be both phishing-resistant and <em>recent</em>,
    /// and recency cannot be established from <c>amr</c> alone. Granting
    /// StepUpPhishingResistant here would silently satisfy the independent-release gate
    /// from an ordinary long-lived session. Step-up therefore remains unavailable over
    /// OIDC until POST /api/v1/auth/step-up is implemented with an auth_time recency
    /// check; it is a controlled 501 until then.
    /// </para>
    /// </summary>
    private static AuthenticationStrength ResolveAuthenticationStrength(ClaimsPrincipal principal)
    {
        var declared = principal.FindFirstValue(ClaimNames.AuthenticationStrength);
        if (Enum.TryParse<AuthenticationStrength>(declared, ignoreCase: true, out var parsed))
        {
            return parsed;
        }

        var methods = principal.FindAll(ClaimNames.AuthenticationMethods)
            .Select(item => item.Value)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        return methods.Overlaps(MultiFactorAuthenticationMethods)
            ? AuthenticationStrength.Mfa
            : AuthenticationStrength.SingleFactor;
    }

    /// <summary>RFC 8176 authentication methods that evidence more than one factor.</summary>
    private static readonly string[] MultiFactorAuthenticationMethods = ["mfa", "otp", "hwk", "swk"];

    private static Guid ParseRequiredGuid(string? value, string errorCode) =>
        Guid.TryParse(value, out var parsed)
            ? parsed
            : throw new DomainRuleException(errorCode, "A required identity scope is missing or invalid.");

    private static T ParseEnum<T>(string? value, T fallback)
        where T : struct, Enum =>
        Enum.TryParse<T>(value, ignoreCase: true, out var parsed) ? parsed : fallback;
}
