// Settings for device certificate auth. All of them or none, never a half-open door.

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace Cinerion.Api.Security;

/// <summary>
/// The deployment's half of device authentication over HTTP: which port device identities
/// are answered on, this service's own certificate there, and the controlled authority
/// that decides which device certificates exist at all.
/// <para>
/// <b>All five or none.</b> The same rule the internal gRPC edge and the MQTT and OPC UA
/// adapters follow, for the same reason: a partially configured mutual-TLS listener is the
/// one case where a helpful default silently drops mutual authentication. An unconfigured
/// deployment therefore has <em>no device listener at all</em> — the controller-local
/// operations are unreachable rather than reachable without a client certificate — and
/// <c>GET /api/v1/system/health</c> says so.
/// </para>
/// <para>
/// This exists because of a gap that had no honest workaround. <c>POST
/// /confirmations/{id}/credential-proofs</c> and <c>POST /confirmations/{id}/local-commits</c>
/// are performed by a "bound cell-controller identity" — <c>ValidateController</c> requires
/// <see cref="Cinerion.Domain.Security.ActorKind.Device"/>, the DeviceController role and
/// <see cref="Cinerion.Domain.Security.AuthenticationStrength.MutualTls"/> — and the only
/// way to present such an actor was the development identity handler, which is mutually
/// exclusive with OIDC and is not a production authentication mechanism. So a lab serving
/// the portal over OIDC had no way for a controller to answer a prepared command, and the
/// controlled sequence could never complete end to end.
/// </para>
/// </summary>
/// <requirements>CH1-IAM-FR-0008, CH1-CYB-FR-0001, CH1-CYB-FR-0002, CH1-AUT-FDS-0001</requirements>
public sealed record DeviceCertificateOptions(
    int Port,
    X509Certificate2 ServerCertificate,
    X509Certificate2 CertificateAuthority,
    Guid ProjectId)
{
    public static DeviceCertificateOptions? FromConfiguration(IConfiguration configuration)
    {
        var port = configuration["CINERION_DEVICE_MTLS_PORT"];
        var caPath = configuration["CINERION_DEVICE_MTLS_CA_CERT"];
        var certificatePath = configuration["CINERION_DEVICE_MTLS_SERVER_CERT"];
        var keyPath = configuration["CINERION_DEVICE_MTLS_SERVER_KEY"];
        var project = configuration["CINERION_DEVICE_MTLS_PROJECT_ID"];

        if (string.IsNullOrWhiteSpace(port) || string.IsNullOrWhiteSpace(caPath) ||
            string.IsNullOrWhiteSpace(certificatePath) || string.IsNullOrWhiteSpace(keyPath) ||
            string.IsNullOrWhiteSpace(project))
        {
            return null;
        }

        if (!int.TryParse(port, out var portNumber) || portNumber is < 1 or > 65535)
        {
            throw new InvalidOperationException($"CINERION_DEVICE_MTLS_PORT '{port}' is not a usable TCP port.");
        }

        if (!Guid.TryParse(project, out var projectId) || projectId == Guid.Empty)
        {
            throw new InvalidOperationException(
                $"CINERION_DEVICE_MTLS_PROJECT_ID '{project}' is not a project identifier.");
        }

        return new DeviceCertificateOptions(
            portNumber,
            LoadServerCertificate(certificatePath, keyPath),
            X509CertificateLoader.LoadCertificateFromFile(caPath),
            projectId);
    }

    /// <summary>
    /// The name a device addresses this service by, taken from the common name of the
    /// service's own certificate.
    /// <para>
    /// Needed for the reason the gRPC edge needs it: <c>AllowedHosts</c> is a deliberate
    /// setting for the REST API and host filtering is a single global middleware, so a
    /// request whose Host header is the Compose service name is answered <c>400</c> before
    /// it reaches any handler. Deriving the name from the certificate rather than from a
    /// free-text setting means the only extra host accepted is one this deployment's own
    /// authority attested.
    /// </para>
    /// </summary>
    public string ServiceCommonName =>
        ServerCertificate.GetNameInfo(X509NameType.SimpleName, forIssuer: false) ?? string.Empty;

    /// <summary>
    /// Whether a presented client certificate belongs to this deployment.
    /// <para>
    /// The controlled CA is the <em>only</em> trust anchor: <see cref="X509ChainTrustMode.CustomRootTrust"/>
    /// with an empty <c>CustomTrustStore</c> plus this one certificate means the machine's
    /// own root store is never consulted. A certificate from a public authority carrying
    /// the right common name is refused, because identity here is what this authority
    /// attested and not a name a client chose.
    /// </para>
    /// <para>
    /// This is only the first of two gates, and deliberately the weaker one. Passing it
    /// establishes that this deployment issued the certificate; it says nothing about
    /// which device holds it, whether that device is enrolled, or whether its trust has
    /// been withdrawn. <see cref="DeviceCertificateAuthenticationHandler"/> decides all
    /// three from the enrolled record.
    /// </para>
    /// </summary>
    public bool IsIssuedByControlledAuthority(X509Certificate2 clientCertificate, SslPolicyErrors errors)
    {
        if (errors.HasFlag(SslPolicyErrors.RemoteCertificateNotAvailable))
        {
            return false;
        }

        using var chain = new X509Chain
        {
            ChainPolicy =
            {
                TrustMode = X509ChainTrustMode.CustomRootTrust,
                RevocationMode = X509RevocationMode.NoCheck,
                VerificationFlags = X509VerificationFlags.NoFlag,
            },
        };
        chain.ChainPolicy.CustomTrustStore.Add(CertificateAuthority);
        return chain.Build(clientCertificate);
    }

    /// <summary>
    /// Loads the PEM certificate and its key in a form the platform's TLS stack will serve.
    /// The PKCS#12 round trip on Windows is the same one <c>EdgeIngressOptions</c> performs
    /// and for the same reason: SChannel cannot use the ephemeral key handle
    /// <see cref="X509Certificate2.CreateFromPemFile"/> produces.
    /// </summary>
    private static X509Certificate2 LoadServerCertificate(string certificatePath, string keyPath)
    {
        var certificate = X509Certificate2.CreateFromPemFile(certificatePath, keyPath);
        if (!OperatingSystem.IsWindows())
        {
            return certificate;
        }

        using (certificate)
        {
            return X509CertificateLoader.LoadPkcs12(certificate.Export(X509ContentType.Pkcs12), password: null);
        }
    }
}
