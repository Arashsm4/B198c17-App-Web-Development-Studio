// Stamps every request with a correlation id so its trail can be followed through the logs.

namespace Cinerion.Api.Security;

public sealed class CorrelationMiddleware(RequestDelegate next)
{
    public const string ItemKey = "CH1.CorrelationId";
    public const string HeaderName = "X-Correlation-ID";

    public async Task InvokeAsync(HttpContext context)
    {
        var correlationId = context.Request.Headers.TryGetValue(HeaderName, out var supplied) &&
            Guid.TryParse(supplied.FirstOrDefault(), out var parsed)
            ? parsed
            : Guid.NewGuid();
        context.Items[ItemKey] = correlationId;
        context.Response.Headers[HeaderName] = correlationId.ToString();
        await next(context).ConfigureAwait(false);
    }

    public static Guid Get(HttpContext context) =>
        context.Items.TryGetValue(ItemKey, out var value) && value is Guid id ? id : Guid.NewGuid();
}

