// Turns broken domain rules into clean HTTP answers without leaking what it shouldn't.

using Cinerion.Api.Security;
using Cinerion.Domain.Common;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace Cinerion.Api.Errors;

public sealed class DomainExceptionHandler : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        // A body the model binder cannot read is a client fault. Left unhandled it
        // surfaced as 500 with no stable code, which both misattributes the fault to
        // the server and denies the caller the machine-readable reason and
        // correlation identifier CH1-SWA-API-0001 requires on every error.
        if (exception is BadHttpRequestException badRequest)
        {
            await WriteProblemAsync(
                httpContext,
                badRequest.StatusCode is >= 400 and < 500 ? badRequest.StatusCode : StatusCodes.Status400BadRequest,
                "CH1_REQUEST_BODY_INVALID",
                "Controlled operation rejected",
                badRequest.Message,
                cancellationToken).ConfigureAwait(false);
            return true;
        }

        if (exception is not DomainRuleException error)
        {
            return false;
        }

        var status = error.Code switch
        {
            var code when code.Contains("NOT_FOUND", StringComparison.Ordinal) => StatusCodes.Status404NotFound,
            var code when code.StartsWith("AUTH_", StringComparison.Ordinal) => StatusCodes.Status403Forbidden,
            "CONCURRENCY_CONFLICT" or "IDEMPOTENCY_CONFLICT" => StatusCodes.Status409Conflict,
            _ => StatusCodes.Status400BadRequest,
        };
        await WriteProblemAsync(
            httpContext,
            status,
            error.Code,
            "Controlled operation rejected",
            error.Message,
            cancellationToken).ConfigureAwait(false);
        return true;
    }

    private static async Task WriteProblemAsync(
        HttpContext httpContext,
        int status,
        string code,
        string title,
        string detail,
        CancellationToken cancellationToken)
    {
        var problem = new ProblemDetails
        {
            Status = status,
            Title = title,
            Detail = detail,
            Type = $"urn:cinerion:problem:{code.ToLowerInvariant()}",
            Instance = httpContext.Request.Path,
        };
        problem.Extensions["code"] = code;
        problem.Extensions["correlationId"] = CorrelationMiddleware.Get(httpContext);
        httpContext.Response.StatusCode = status;
        await httpContext.Response.WriteAsJsonAsync(problem, cancellationToken).ConfigureAwait(false);
    }
}
