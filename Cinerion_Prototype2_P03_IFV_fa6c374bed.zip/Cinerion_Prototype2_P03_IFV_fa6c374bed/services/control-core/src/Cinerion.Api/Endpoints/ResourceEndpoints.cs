// HTTP routes for resources and reservations. Booking capacity never starts anything.

using System.Globalization;
using Cinerion.Api.Security;
using Cinerion.Application.Resources;
using Cinerion.Application.Security;
using Cinerion.Domain.Common;
using Cinerion.Domain.Resources;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>Body of POST /api/v1/resources/{resourceId}/reservations.</summary>
public sealed record ReserveResourceDto(
    decimal Quantity,
    DateTimeOffset StartsAt,
    DateTimeOffset EndsAt,
    Guid? WorkOrderId = null,
    Guid? ExperimentId = null);

/// <summary>
/// Resource capacity, reservations and conflicts.
/// </summary>
/// <requirements>CH1-MGT-FR-0002, CH1-MGT-FR-0003, CH1-MGT-FR-0004</requirements>
public static class ResourceEndpoints
{
    public static void MapResourceEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("resources");

        // Catalogue entry 39: project role scoped; filter, cursor pagination and freshness.
        group.MapGet("/resources", async (
            string? resourceType,
            string? availabilityState,
            DateTimeOffset? from,
            DateTimeOffset? to,
            string? cursor,
            int? limit,
            HttpContext context,
            ResourceOrchestratorService resources,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                if (!ResourceOrchestratorService.CanReadResources(actor))
                {
                    return Results.NotFound();
                }

                ResourceAvailabilityState? state = null;
                if (!string.IsNullOrWhiteSpace(availabilityState))
                {
                    if (!Enum.TryParse<ResourceAvailabilityState>(availabilityState, ignoreCase: true, out var parsed))
                    {
                        throw new DomainRuleException(
                            "RESOURCE_AVAILABILITY_FILTER_INVALID",
                            $"'{availabilityState}' is not an availability state. Valid values are " +
                            $"{string.Join(", ", Enum.GetNames<ResourceAvailabilityState>())}.");
                    }

                    state = parsed;
                }

                var view = await resources.ListAsync(
                    resourceType, state, from, to, cursor, limit, actor, cancellationToken).ConfigureAwait(false);

                var appliedLimit = Math.Clamp(limit ?? ResourceQuery.DefaultRows, 1, ResourceQuery.MaximumRows);
                var last = view.Count == appliedLimit ? view[^1].Resource : null;
                var now = DateTimeOffset.UtcNow;
                var windowFrom = from ?? now;

                return Results.Ok(new
                {
                    items = view.Select(item => Availability(item, windowFrom)),
                    count = view.Count,
                    nextCursor = last is null ? null : new ResourceCursor(last.Name, last.ResourceId).Encode(),
                    window = new { from = windowFrom, to = to ?? windowFrom + ResourceQuery.DefaultWindow },
                    bounds = new
                    {
                        maximumRows = ResourceQuery.MaximumRows,
                        defaultRows = ResourceQuery.DefaultRows,
                        maximumWindowDays = ResourceQuery.MaximumWindow.TotalDays,
                        defaultWindowDays = ResourceQuery.DefaultWindow.TotalDays,
                        maximumReservationDays = ResourceAllocation.MaximumDuration.TotalDays,
                    },
                    // The reservation ledger is transactional: it is read from the system
                    // of record at request time, not sampled from equipment, so it is Live
                    // rather than Simulated. A resource's own availability state is
                    // administrative and travels with each row.
                    freshness = "Live",
                    asOf = now,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 40: Operations Coordinator or Project Manager; conflict check,
        // optimistic concurrency and audit. access.json additionally requires step-up MFA
        // to manage resource allocations.
        group.MapPost("/resources/{resourceId:guid}/reservations", async (
            Guid resourceId,
            ReserveResourceDto request,
            HttpContext context,
            ResourceOrchestratorService resources,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                await RedeemStepUpAsync(context, stepUp, actor, "Reserving a resource", cancellationToken)
                    .ConfigureAwait(false);

                var allocation = await resources.ReserveAsync(
                    resourceId,
                    request.WorkOrderId,
                    request.ExperimentId,
                    request.Quantity,
                    request.StartsAt,
                    request.EndsAt,
                    IfMatchVersion(context),
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                context.Response.Headers.ETag = $"\"{allocation.Version}\"";
                // The P03 catalogue has no operation that reads one reservation, so the
                // location is the list the new reservation now appears in.
                return Results.Created("/api/v1/resources", Allocation(allocation));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 41: reservation owner or Operations Coordinator; reason,
        // version match and audit.
        group.MapDelete("/reservations/{reservationId:guid}", async (
            Guid reservationId,
            string? reason,
            HttpContext context,
            ResourceOrchestratorService resources,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                await RedeemStepUpAsync(context, stepUp, actor, "Cancelling a reservation", cancellationToken)
                    .ConfigureAwait(false);

                var cancelled = await resources.CancelAsync(
                    reservationId,
                    reason ?? string.Empty,
                    IfMatchVersion(context),
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                context.Response.Headers.ETag = $"\"{cancelled.Version}\"";
                // 200 rather than 204: the cancellation record is the evidence, and a
                // caller that received no body could not show who released the capacity
                // or why without a second request.
                return Results.Ok(Allocation(cancelled));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    /// <summary>
    /// CH1-CYB-ACP-0001 lists managing resource allocations among the actions requiring
    /// step-up authentication. The required strength is MFA, not phishing-resistant —
    /// the access matrix distinguishes the two, and reading a stronger requirement into
    /// it would make an operation the baseline permits unreachable.
    /// </summary>
    /// <requirements>CH1-IAM-FR-0004, CH1-CYB-ACP-0001</requirements>
    private static async Task RedeemStepUpAsync(
        HttpContext context,
        StepUpService stepUp,
        ActorContext actor,
        string action,
        CancellationToken cancellationToken)
    {
        var header = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
        if (!Guid.TryParse(header, out var grantId))
        {
            throw new DomainRuleException(
                "STEP_UP_REQUIRED",
                $"{action} requires a step-up grant in X-CH1-Step-Up.");
        }

        await stepUp.RedeemAsync(
            grantId,
            StepUpPurpose.ResourceAllocation,
            AuthenticationStrength.Mfa,
            actor,
            cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Reads the entity version from If-Match. Quotes are optional so a caller may send
    /// either the ETag as issued or the bare number.
    /// </summary>
    private static long? IfMatchVersion(HttpContext context)
    {
        var value = context.Request.Headers.IfMatch.FirstOrDefault()?.Trim();
        if (string.IsNullOrEmpty(value))
        {
            return null;
        }

        // Accept a weak validator prefix and surrounding quotes, so a caller may send the
        // ETag exactly as it was issued or the bare version number.
        if (value.StartsWith("W/", StringComparison.Ordinal))
        {
            value = value[2..];
        }

        value = value.Trim('"');
        return long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var version)
            ? version
            : null;
    }

    private static object Availability(ResourceAvailability item, DateTimeOffset windowFrom) => new
    {
        item.Resource.ResourceId,
        item.Resource.ResourceType,
        item.Resource.Name,
        item.Resource.Capacity,
        item.Resource.Unit,
        availabilityState = item.Resource.AvailabilityState.ToString(),
        acceptsReservations = item.Resource.AcceptsReservations,
        // The version a caller must echo in If-Match to reserve against this resource.
        item.Resource.Version,
        etag = $"\"{item.Resource.Version}\"",
        committedNow = CapacityLedger.CommittedAt(item.Reservations, windowFrom),
        availableNow = item.Resource.Capacity - CapacityLedger.CommittedAt(item.Reservations, windowFrom),
        committedPeak = item.CommittedPeak,
        peakAt = item.PeakAt,
        availableAtPeak = item.Resource.Capacity - item.CommittedPeak,
        reservations = item.Reservations.Select(Allocation),
        // CH1-MGT-FR-0004 requires conflict state to be exposed, not merely prevented.
        // Reservations refuse to over-commit, but capacity reduced after the fact can
        // still leave an interval over-committed, and an operations view must show it.
        conflicts = item.Conflicts.Select(conflict => new
        {
            conflict.From,
            conflict.To,
            conflict.Committed,
            conflict.Capacity,
            conflict.OverCommittedBy,
        }),
        conflicted = item.Conflicts.Count > 0,
    };

    private static object Allocation(ResourceAllocation allocation) => new
    {
        allocation.AllocationId,
        allocation.ResourceId,
        // Exactly one of these is set: CH1-MGT-FR-0004 requires every allocation to be
        // linked to its work order or experiment.
        allocation.WorkOrderId,
        allocation.ExperimentId,
        allocation.Quantity,
        allocation.StartsAt,
        allocation.EndsAt,
        status = allocation.Status.ToString(),
        allocation.RequestedBy,
        allocation.Version,
        allocation.CancellationReason,
        allocation.CancelledBy,
        allocation.CancelledAt,
        // A reservation holds capacity; it starts nothing. CH1-MGT-FR-0002 keeps every
        // physical-effect path inside CommandGuard and local confirmation.
        physicalEffect = "None: a reservation holds capacity and starts no equipment.",
    };
}
