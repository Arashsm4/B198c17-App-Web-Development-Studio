// HTTP routes for messages pinned to real objects. Chat that can never press a button.

using Cinerion.Api.Security;
using Cinerion.Application.Collaboration;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// Body of POST /api/v1/context-threads/{threadId}/messages.
/// <para>
/// There is no author field, and there is deliberately no way to add one. The author is
/// the authenticated actor; a client-supplied author is the "immutable author" control
/// on this operation failing.
/// </para>
/// </summary>
public sealed record PostContextMessageDto(
    string Body,
    MessagePriority? Priority = null,
    ContextObjectType? ObjectType = null,
    string? ObjectId = null,
    IReadOnlyList<string>? ScopeRoles = null,
    IReadOnlyList<string>? ScopeActorIds = null);

/// <summary>
/// Contextual project communication linked to a controlled object.
/// </summary>
/// <requirements>CH1-COL-FR-0001, CH1-COL-FR-0002, CH1-COL-FR-0003, CH1-UXD-DSG-0001</requirements>
public static class ContextBridgeEndpoints
{
    public static void MapContextBridgeEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("collaboration");

        // Catalogue entry 42: thread participant; object scope, cursor pagination and
        // retention policy.
        group.MapGet("/context-threads/{threadId:guid}/messages", async (
            Guid threadId,
            string? cursor,
            int? limit,
            HttpContext context,
            ContextBridgeService contextBridge,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var page = await contextBridge
                    .ReadThreadAsync(threadId, cursor, limit, actor, cancellationToken)
                    .ConfigureAwait(false);
                if (page is null)
                {
                    // A thread outside the caller's scope reads exactly as one that does
                    // not exist, so neither the conversation nor the object it belongs to
                    // can be probed.
                    return Results.NotFound();
                }

                var appliedLimit = Math.Clamp(
                    limit ?? ContextMessageQuery.DefaultRows, 1, ContextMessageQuery.MaximumRows);
                var last = page.Messages.Count == appliedLimit ? page.Messages[^1] : null;

                return Results.Ok(new
                {
                    thread = Thread(page.Thread),
                    items = page.Messages.Select(message => Message(message, page.Acknowledgements)),
                    count = page.Messages.Count,
                    nextCursor = last is null
                        ? null
                        : new ContextMessageCursor(last.CreatedAt, last.MessageId).Encode(),
                    bounds = new
                    {
                        maximumRows = ContextMessageQuery.MaximumRows,
                        defaultRows = ContextMessageQuery.DefaultRows,
                        maximumBodyLength = ContextMessage.MaximumBodyLength,
                    },
                    retention = new
                    {
                        message = ContextBridgeService.Retention.Message,
                        acknowledgement = ContextBridgeService.Retention.Acknowledgement,
                        disposal = ContextBridgeService.Retention.Disposal,
                        standing = ContextBridgeService.Retention.Standing,
                    },
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 43: authorised participant; content limits, immutable author
        // and audit.
        group.MapPost("/context-threads/{threadId:guid}/messages", async (
            Guid threadId,
            PostContextMessageDto request,
            HttpContext context,
            ContextBridgeService contextBridge,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var scope = request.ScopeRoles is null && request.ScopeActorIds is null
                    ? null
                    : ThreadAccessScope.Create(request.ScopeRoles, request.ScopeActorIds);

                var (thread, message) = await contextBridge.PostMessageAsync(
                    threadId,
                    request.ObjectType,
                    request.ObjectId,
                    scope,
                    request.Priority ?? MessagePriority.Routine,
                    request.Body,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created(
                    $"/api/v1/context-threads/{thread.ThreadId}/messages",
                    new
                    {
                        thread = Thread(thread),
                        message = Message(message, null),
                    });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 44: assigned recipient; no alarm, interlock or command effect.
        group.MapPost("/context-messages/{messageId:guid}/acknowledgements", async (
            Guid messageId,
            HttpContext context,
            ContextBridgeService contextBridge,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var (thread, receipt) = await contextBridge.AcknowledgeMessageAsync(
                    messageId,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/context-threads/{thread.ThreadId}/messages", new
                {
                    receipt.MessageAckId,
                    receipt.MessageId,
                    receipt.RecipientId,
                    receipt.AcknowledgedAt,
                    // "Read", never "Acknowledged". CH1-UXD-DSG-0001 requires messages
                    // and alarms to use different verbs so a user cannot mistake a
                    // message receipt for an alarm acknowledgement, and a client that
                    // renders this field verbatim inherits that separation.
                    kind = MessageAcknowledgement.Kind,
                    effect = "MessageReceiptRecorded",
                    receipt.ControlAuthority,
                    // Stated in full, because for this operation what did not happen is
                    // the requirement. The thread's object is named so a reader can see
                    // that even an alarm-linked message left that alarm alone.
                    controlSideEffect =
                        "None: no alarm acknowledged, no fault cleared, no interlock satisfied, no command confirmed.",
                    threadObject = new { type = thread.ObjectType.ToString(), id = thread.ObjectId },
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    private static object Thread(ContextThread thread) => new
    {
        thread.ThreadId,
        objectType = thread.ObjectType.ToString(),
        thread.ObjectId,
        accessScope = new { thread.AccessScope.Roles, thread.AccessScope.ActorIds },
        thread.CreatedBy,
        thread.CreatedAt,
    };

    private static object Message(
        ContextMessage message,
        IReadOnlyDictionary<Guid, IReadOnlyList<MessageAcknowledgement>>? acknowledgements)
    {
        var receipts = acknowledgements is not null &&
            acknowledgements.TryGetValue(message.MessageId, out var found)
            ? found
            : [];

        return new
        {
            message.MessageId,
            message.ThreadId,
            message.AuthorId,
            authorKind = message.AuthorKind.ToString(),
            priority = message.Priority.ToString(),
            message.Body,
            message.CreatedAt,
            deliveryState = message.DeliveryState.ToString(),
            // CH1-COL-FR-0002 requires acknowledgement state to be retained and visible
            // alongside the message it belongs to.
            readBy = receipts.Select(receipt => new
            {
                receipt.RecipientId,
                receipt.AcknowledgedAt,
                kind = MessageAcknowledgement.Kind,
            }),
            readCount = receipts.Count,
            message.ControlAuthority,
        };
    }
}
