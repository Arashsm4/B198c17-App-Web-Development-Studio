// HTTP routes for the audit trail: read the events, and check the hash chain still holds.

using Cinerion.Api.Security;
using Cinerion.Application.Abstractions;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

public static class AuditEndpoints
{
    public static void MapAuditEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1/audit").RequireAuthorization().WithTags("audit");

        group.MapGet("/events", async (
            Guid? correlationId,
            int? limit,
            HttpContext context,
            ICinerionStore store,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            if (!actor.HasRole(CinerionRoles.Auditor) && !actor.HasRole(CinerionRoles.CybersecurityAdministrator))
            {
                return Results.NotFound();
            }

            var events = await store.QueryAuditAsync(
                actor.ProjectId,
                correlationId,
                limit ?? 250,
                cancellationToken).ConfigureAwait(false);
            return Results.Ok(new { items = events, count = events.Count });
        });

        group.MapPost("/chain-verifications", async (
            HttpContext context,
            ICinerionStore store,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            if (!actor.HasRole(CinerionRoles.Auditor) && !actor.HasRole(CinerionRoles.CybersecurityAdministrator))
            {
                return Results.NotFound();
            }

            var result = await store.VerifyAuditAsync(cancellationToken).ConfigureAwait(false);
            return Results.Ok(new
            {
                verificationId = Guid.NewGuid(),
                result.Valid,
                result.Checked,
                result.FailureAt,
                verifiedAt = DateTimeOffset.UtcNow,
                verifiedBy = actor.ActorId,
            });
        });
    }
}

