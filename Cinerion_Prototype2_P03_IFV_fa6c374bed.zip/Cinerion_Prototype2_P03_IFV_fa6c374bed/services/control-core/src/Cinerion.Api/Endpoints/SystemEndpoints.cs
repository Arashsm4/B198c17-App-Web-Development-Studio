// The health endpoint. The one route anyone may call, and all it says is that we're alive.

using Cinerion.Application.Commands;
using Cinerion.Infrastructure.Seed;

namespace Cinerion.Api.Endpoints;

public static class SystemEndpoints
{
    public static void MapSystemEndpoints(
        this IEndpointRouteBuilder endpoints,
        CommandRuntimeProfile profile,
        bool developmentIdentityEnabled,
        bool deviceIdentityListenerEnabled = false)
    {
        endpoints.MapGet("/api/v1/system/health", () => Results.Ok(new
        {
            status = "Healthy",
            project = "Cinerion",
            @namespace = "CH1",
            baseline = "P03/IFV",
            version = "0.1.0-prototype.1",
            runtimeProfile = profile.ToString(),
            dataFreshness = "Live",
            dataQuality = "Good",
            simulation = profile == CommandRuntimeProfile.Simulation,
            developmentIdentityEnabled,
            // Whether a cell controller or a bound instrument adapter can reach this
            // service at all. Reported for the reason the gRPC edge's absence is: an
            // unconfigured mutual-TLS listener means the controller-local operations are
            // UNREACHABLE, and a reader looking at a command stuck at AwaitingCredential
            // needs to be able to tell that from a controller that is simply not answering.
            deviceIdentityListenerEnabled,
            safetyNotice = "Confirmation is a readiness gate, not an E-stop or safety-rated function.",
            time = DateTimeOffset.UtcNow,
        })).AllowAnonymous();

        endpoints.MapGet("/api/v1/system/prototype-seed", () => Results.Ok(PrototypeSeed.Ids))
            .RequireAuthorization()
            .WithTags("system");
    }
}

