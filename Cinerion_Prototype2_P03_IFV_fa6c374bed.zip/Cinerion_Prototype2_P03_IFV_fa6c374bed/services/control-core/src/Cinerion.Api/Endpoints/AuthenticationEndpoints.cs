// HTTP route for step-up: ask for a short, single-purpose proof that it's still you.

using Cinerion.Api.Security;
using Cinerion.Application.Security;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

public static class AuthenticationEndpoints
{
    public static void MapAuthenticationEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("authentication");

        // CH1-IAM-FR-0004: sensitive approval, release and security-administration
        // actions require step-up. This issues the purpose-bound, short-TTL grant;
        // each sensitive endpoint redeems it via StepUpService.RedeemAsync.
        group.MapPost("/auth/step-up", async (
            StepUpRequestDto request,
            HttpContext context,
            StepUpService service,
            ActorContextFactory actorFactory,
            IConfiguration configuration,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var grant = await service.RequestAsync(
                    request.Purpose,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                var (rpId, origin) = CredentialEndpoints.ResolveRelyingParty(configuration, null, null);
                return Results.Ok(new
                {
                    grant.GrantId,
                    grant.Purpose,
                    grantedStrength = grant.Strength.ToString(),
                    grant.GrantedAt,
                    grant.ExpiresAt,
                    singleUse = true,
                    // The purpose-bound challenge api_endpoints.json makes the control on
                    // this operation. It had no challenge at all until now, which is why
                    // conflict 13 read as a missing operation rather than as a missing
                    // field: a proof of possession has to be made against something, and
                    // there was nothing to make it against.
                    challenge = grant.Challenge is null ? null : Base64Url.Encode(grant.Challenge),
                    rpId,
                    origin,
                    // Required, not preferred. Every purpose this challenge can be
                    // redeemed for is a sensitive action, and presence alone does not
                    // establish that the right person touched the authenticator.
                    userVerification = "required",
                    // ES256 and RS256, the two algorithms WebAuthnVerifier accepts. An
                    // authenticator offered anything else would mint a key no assertion
                    // here could ever verify against.
                    pubKeyCredParams = new[]
                    {
                        new { type = "public-key", alg = -7 },
                        new { type = "public-key", alg = -257 },
                    },
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }
}

/// <summary>
/// Only the purpose is supplied. The strength and recency of the step-up are taken
/// from the authentication the identity provider attested, never from the request,
/// so a client cannot ask for an assurance level it did not actually reach.
/// </summary>
public sealed record StepUpRequestDto(string Purpose)
{
    public static IReadOnlySet<string> SupportedPurposes => StepUpPurpose.All;
}
