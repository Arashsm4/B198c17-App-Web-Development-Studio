// HTTP routes for projects, sites, cells and cell state.

using Cinerion.Api.Security;
using Cinerion.Application.Abstractions;
using Cinerion.Application.Configuration;
using Cinerion.Application.Edge;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;
using Cinerion.Domain.Configuration;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// The project identifier is deliberately absent: a project is established for the
/// scope the caller's identity already carries, so a Project Manager cannot create
/// records in a project they are not scoped to.
/// </summary>
public sealed record CreateProjectDto(string ProjectCode, string Name, string Baseline);

public static class OperationsEndpoints
{
    public static void MapOperationsEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("operations");

        group.MapGet("/projects", async (
            HttpContext context,
            ProjectService projects,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            var visible = await projects.ListVisibleAsync(actor, cancellationToken).ConfigureAwait(false);
            return Results.Ok(visible.Select(Project));
        });

        /// <requirements>CH1-MGT-FR-0001, CH1-MGT-FR-0003</requirements>
        group.MapPost("/projects", async (
            CreateProjectDto request,
            HttpContext context,
            ProjectService projects,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var project = await projects.CreateAsync(
                    request.ProjectCode,
                    request.Name,
                    request.Baseline,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/projects/{project.ProjectId}", Project(project));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapGet("/sites/{siteId:guid}/cells", async (
            Guid siteId,
            CellStateResolver cellStates,
            HttpContext context,
            ProjectService projects,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            var registrations = await projects.ListCellsAsync(siteId, actor, cancellationToken).ConfigureAwait(false);
            if (registrations is null)
            {
                // A site outside the caller's project is reported exactly as one that
                // does not exist, so a probe cannot distinguish the two.
                return Results.NotFound();
            }

            var cells = new List<object>(registrations.Count);
            foreach (var registration in registrations)
            {
                var resolved = await cellStates.ResolveAsync(registration.CellId, cancellationToken).ConfigureAwait(false);
                if (resolved is not null)
                {
                    cells.Add(ProjectCell(resolved, registration));
                }
            }

            return Results.Ok(cells);
        });

        // Catalogue entry 14: Engineer or Maintainer, secret-free projection and
        // last-seen quality. The certificate thumbprint is a public fingerprint; no
        // key material, enrolment secret or credential is exposed here or stored.
        group.MapGet("/devices/{deviceId}", async (
            string deviceId,
            ICinerionStore store,
            HttpContext context,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            if (!actor.HasRole(CinerionRoles.Engineer) && !actor.HasRole(CinerionRoles.MaintenanceEngineer))
            {
                return Results.NotFound();
            }

            var device = await store.FindDeviceAsync(deviceId, cancellationToken).ConfigureAwait(false);
            if (device is null || device.ProjectId != actor.ProjectId)
            {
                return Results.NotFound();
            }

            return Results.Ok(new
            {
                device.DeviceId,
                device.CellId,
                device.DeviceType,
                device.FirmwareVersion,
                device.ConfigurationRevision,
                device.CertificateThumbprint,
                device.TrustState,
                trusted = device.IsTrusted,
                device.LastSeenAt,
                device.RevokedAt,
                device.Version,
                // Whether the reading is current is the client's to judge; the server
                // states when it last heard from the device rather than asserting it
                // is online.
                lastSeenQuality = device.LastSeenAt is null ? "Unknown" : "Reported",
            });
        });

        group.MapGet("/cells/{cellId:guid}/state", async (
            Guid cellId,
            CellStateResolver cellStates,
            HttpContext context,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            if (!actor.CanAccessCell(cellId))
            {
                return Results.NotFound();
            }

            var cell = await cellStates.ResolveAsync(cellId, cancellationToken).ConfigureAwait(false);
            return cell is null ? Results.NotFound() : Results.Ok(ProjectCell(cell));
        });
    }

    private static object Project(ProjectRecord project) => new
    {
        project.ProjectId,
        project.ProjectCode,
        project.Name,
        project.Baseline,
        project.Version,
        project.CreatedAt,
    };

    private static object ProjectCell(ResolvedCellState resolved, CellRegistration? registration = null)
    {
        var cell = resolved.Snapshot;
        return new
        {
            cell.CellId,
            name = registration?.Name,
            cell.SiteId,
            cell.AssetId,
            cell.ControllerId,
            state = cell.OperatingState.ToString(),
            cell.ConfigurationRevision,
            cell.WorkOrderId,
            cell.PartId,
            interlocks = new
            {
                cell.ControllerOnline,
                cell.StartEnable,
                cell.StopCircuitHealthy,
                cell.GuardHealthy,
                cell.ActuatorHome,
                cell.FaultCauseActive,
            },
            // Whether the controller answered its permissives at all, and which checks it
            // declared it does not answer. A stand-in has no wired inputs and says so with
            // deferred check 207; without this field an operator could not tell a cell that
            // is not permissive from one whose controller was never asked. CH1-MON-FR-0003
            // requires the difference to remain visible, and it is additive, which is the
            // compatibility rule CH1-SWA-API-0001 states.
            permissivesReported = resolved.Permissives.Reported,
            deferredCheckCodes = resolved.Permissives.DeferredCheckCodes,
            // Computed from when the cell was last heard from, never asserted. Unknown
            // when no controller has ever reported, Stale once a report has aged out, and
            // otherwise whatever the report declared — never upgraded to Live.
            freshness = resolved.Observation.Freshness.ToString(),
            quality = resolved.Observation.Quality.ToString(),
            sourceTimestamp = resolved.Observation.SourceTimestamp,
            stateHash = cell.StateHash(),
            // Where discussion of this cell lives. An additive optional field, which is
            // the compatibility rule CH1-SWA-API-0001 states; the P03 catalogue has no
            // operation that issues a thread identifier, so object pages carry the derived
            // one. Posting a message there starts nothing and confirms nothing.
            contextThreadId = ContextThread.DeriveId(cell.ProjectId, ContextObjectType.Cell, cell.CellId.ToString()),
        };
    }
}

