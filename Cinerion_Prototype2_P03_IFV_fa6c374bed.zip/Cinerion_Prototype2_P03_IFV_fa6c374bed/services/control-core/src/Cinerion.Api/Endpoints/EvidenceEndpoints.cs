// HTTP routes for reports and field scan events.

using Cinerion.Api.Security;
using Cinerion.Application.Evidence;
using Cinerion.Domain.Common;
using Cinerion.Domain.Evidence;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// Body of POST /api/v1/reports.
/// <para>
/// The caller names a template and the records to draw on. It cannot supply content, a
/// checksum, an approval state or a document number: a report whose body came from the
/// requester would evidence what the requester wanted it to say, which is the opposite of
/// what CH1-RPT-FR-0001 asks a report to be.
/// </para>
/// </summary>
public sealed record GenerateReportDto(
    string TemplateId,
    string ReportType,
    string InputObjectType,
    IReadOnlyList<string> InputObjectIds);

/// <summary>
/// Body of POST /api/v1/parts/scan-events.
/// <para>
/// There is no field for the resolved part. The platform resolves the identifier itself,
/// so a caller cannot assert that a tag belongs to a part it does not — the wrong-object
/// error CH1-UXD-DSG-0001 exists to prevent.
/// </para>
/// </summary>
public sealed record RecordScanEventDto(
    string DeviceId,
    string StationId,
    string IdentifierKind,
    string IdentifierValue,
    DateTimeOffset ScannedAt,
    string SessionSignature);

/// <summary>
/// Deterministic report generation and field part identification.
/// </summary>
/// <requirements>CH1-RPT-FR-0001, CH1-RPT-FR-0002, CH1-MFG-FR-0002, CH1-TRC-FR-0002</requirements>
public static class EvidenceEndpoints
{
    public static void MapEvidenceEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("evidence");

        // Catalogue entry 38: Quality or Project role; template revision, immutable
        // inputs and checksum.
        group.MapPost("/reports", async (
            GenerateReportDto request,
            HttpContext context,
            ReportForgeService reports,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var (report, alreadyExisted) = await reports.GenerateAsync(
                    request.TemplateId,
                    request.ReportType,
                    request.InputObjectType,
                    request.InputObjectIds ?? [],
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                var projection = Projection(report, alreadyExisted);

                // 200 when the report already existed, 201 when this request produced it.
                // The distinction is the operation's determinism made visible: a caller
                // that retries after a dropped response learns it received the same
                // document rather than believing it created a second one.
                return alreadyExisted
                    ? Results.Ok(projection)
                    : Results.Created($"/api/v1/reports/{report.ReportId}", projection);
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 32: bound device or Field Companion; signed session, station
        // scope and duplicate handling.
        group.MapPost("/parts/scan-events", async (
            RecordScanEventDto request,
            HttpContext context,
            FieldCompanionService field,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                if (!Enum.TryParse<ScanIdentifierKind>(request.IdentifierKind, ignoreCase: true, out var kind))
                {
                    throw new DomainRuleException(
                        "SCAN_IDENTIFIER_KIND_UNKNOWN",
                        $"'{request.IdentifierKind}' is not an identifier kind. Valid values are " +
                        $"{string.Join(", ", Enum.GetNames<ScanIdentifierKind>())}.");
                }

                var (scanEvent, part) = await field.RecordScanAsync(
                    request.DeviceId,
                    request.StationId,
                    kind,
                    request.IdentifierValue,
                    request.ScannedAt,
                    request.SessionSignature ?? string.Empty,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/parts/scan-events/{scanEvent.ScanEventId}", new
                {
                    scanEvent.ScanEventId,
                    resolution = scanEvent.Resolution.ToString(),
                    scanEvent.PartId,
                    // Present only when the identifier resolved, and taken from the part
                    // record rather than echoed from the request.
                    part = part is null
                        ? null
                        : new
                        {
                            part.PartId,
                            part.SerialNumber,
                            part.PermanentIdentityUri,
                            status = part.Status.ToString(),
                            part.WorkOrderId,
                            part.RevisionId,
                            openNcrCount = part.OpenNcrIds.Count,
                        },
                    identifierKind = scanEvent.IdentifierKind.ToString(),
                    scanEvent.StationId,
                    scanEvent.DeviceId,
                    scanEvent.ScannedAt,
                    scanEvent.ReceivedAt,
                    // A re-delivery names the event it repeats rather than being dropped,
                    // so a retry stays visible and a gap in the sequence is never mistaken
                    // for a missed scan.
                    scanEvent.DuplicateOf,
                    // Stated on every response, because what a scan does not do is the
                    // requirement. CH1-CYB-IAM-0001 restricts a tag read to identification
                    // precisely because a UID is cloneable.
                    controlSideEffect =
                        "None: a scan resolves identity and state. It starts no equipment, releases no part, " +
                        "satisfies no interlock and proves nothing about who is holding the tag.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    /// <summary>
    /// What a report looks like to a caller. Carries the provenance a reader needs to
    /// re-derive it: the template revision it was produced under, the records it drew on,
    /// and the checksum of the content those two produced.
    /// </summary>
    private static object Projection(ReportRecord report, bool alreadyExisted) => new
    {
        report.ReportId,
        report.ReportType,
        report.TemplateId,
        report.TemplateRevision,
        report.InputObjectType,
        report.InputObjectIds,
        report.DeterminismKey,
        report.ContentSha256,
        report.MediaType,
        report.SizeBytes,
        report.StorageUri,
        report.DocumentNumber,
        report.IssueStatus,
        report.ApprovalState,
        report.GeneratedBy,
        report.GeneratedAt,
        // True when this request returned a report an earlier one generated. The same
        // inputs under the same template revision are the same report.
        alreadyExisted,
        // CH1-RPT-FR-0002 wants the approval state on the face of the report. The
        // platform generates; it does not approve, and saying so plainly stops an
        // unreviewed document being mistaken for an approved deliverable.
        approvalAuthority =
            "Generated by Control Core and not approved. Approval is a controlled review outside this service.",
    };
}
