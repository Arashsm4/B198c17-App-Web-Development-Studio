// The few extra reads the owner approved beyond the P03 catalogue. Reads only, never writes.

using Cinerion.Api.Security;
using Cinerion.Application.Evidence;
using Cinerion.Application.Manufacturing;
using Cinerion.Application.Quality;
using Cinerion.Application.Research;
using Cinerion.Domain.Common;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// The reads this deployment serves that the P03 catalogue does not contain.
/// </summary>
/// <remarks>
/// <para>
/// Kept in one file on purpose, rather than folded into the endpoint groups they belong to
/// by subject. A reader asking "what does this platform serve beyond the controlled
/// catalogue" gets one answer in one place, and
/// <c>scripts/check-repository-policy.mjs</c> reconciles every route here against
/// <c>traceability/owner-approved-operations.json</c> - a route missing from that register
/// fails the build, and an entry in the register that nothing serves fails it too.
/// </para>
/// <para>
/// <b>Every operation here is a read.</b> That is what makes the register safe to have:
/// none of these creates, changes, releases, approves, commands or deletes anything, so
/// none can weaken an interlock, a credential proof, a local confirmation or a segregation
/// rule. Each carries the same authority check and the same project scope a controlled read
/// carries, and the policy gate refuses a non-GET entry outright.
/// </para>
/// <para>
/// They exist because <c>screens.json</c> declares operator screens whose subjects the
/// catalogue can write and cannot read back - four screens that could not be built at all,
/// and a work-order board that could only be built as a screen explaining its own
/// emptiness.
/// </para>
/// </remarks>
/// <requirements>CH1-QMS-FR-0005, CH1-MFG-FR-0001, CH1-MFG-FR-0002, CH1-RND-FR-0001, CH1-RND-FR-0002, CH1-RND-FR-0003, CH1-CYB-FR-0001</requirements>
public static class OwnerApprovedReadEndpoints
{
    /// <summary>
    /// How many rows a register read may return when the caller names no limit, and the
    /// most it may return however large a number it names. The ceiling is the store's; this
    /// is only the default.
    /// </summary>
    private const int DefaultRows = 100;

    public static void MapOwnerApprovedReadEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("owner-approved-reads");

        // CH1-UX-SCR-0012, the instrument and calibration register.
        group.MapGet("/calibrations", async (
            int? limit,
            HttpContext context,
            QualityService quality,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var register = await quality
                    .ListCalibrationsAsync(actor, limit ?? DefaultRows, cancellationToken)
                    .ConfigureAwait(false);

                var now = DateTimeOffset.UtcNow;
                return Results.Ok(new
                {
                    items = register.Select(entry => new
                    {
                        entry.CalibrationId,
                        entry.InstrumentId,
                        entry.CertificateNumber,
                        entry.CalibratedAt,
                        entry.ValidUntil,
                        entry.Status,

                        // Computed here rather than left to the screen. Whether a
                        // certificate is still valid is a fact about the certificate and
                        // the clock, and two readers must not be able to disagree about it
                        // because one of them subtracted the dates differently.
                        expired = entry.ValidUntil <= now,
                        daysRemaining = (int)Math.Floor((entry.ValidUntil - now).TotalDays),
                    }),
                    count = register.Count,
                    asOf = now,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // CH1-UX-SCR-0015, mobile scan and evidence mode.
        group.MapGet("/parts/scan-events", async (
            int? limit,
            HttpContext context,
            FieldCompanionService field,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var events = await field
                    .ListScanEventsAsync(actor, limit ?? DefaultRows, cancellationToken)
                    .ConfigureAwait(false);

                return Results.Ok(new
                {
                    items = events.Select(entry => new
                    {
                        entry.ScanEventId,
                        entry.PartId,
                        identifierKind = entry.IdentifierKind.ToString(),
                        entry.IdentifierValue,
                        entry.StationId,
                        entry.DeviceId,
                        entry.ScannedBy,
                        entry.ScannedAt,
                        entry.ReceivedAt,
                        resolution = entry.Resolution.ToString(),

                        // A re-delivery points at the scan it repeats rather than being
                        // dropped: an evidence screen that hid it would be concealing that
                        // the field device sent the same reading twice.
                        entry.DuplicateOf,

                        // The session signature is NOT projected. It is the proof the
                        // device authenticated with, and a register that handed it back
                        // would be handing back the means to forge the next one.
                    }),
                    count = events.Count,
                    asOf = DateTimeOffset.UtcNow,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // CH1-UX-SCR-0006, the work-order board. Recorded conflict 14.
        group.MapGet("/work-orders", async (
            int? limit,
            HttpContext context,
            ForgeFlowService forge,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var orders = await forge
                    .ListWorkOrdersAsync(actor, limit ?? DefaultRows, cancellationToken)
                    .ConfigureAwait(false);

                return Results.Ok(new
                {
                    items = orders.Select(order => new
                    {
                        order.WorkOrderId,
                        order.WorkOrderNumber,
                        order.RevisionId,
                        order.CellId,
                        order.Quantity,
                        status = order.Status.ToString(),
                        order.ReleasedBy,
                        order.ReleasedAt,
                        order.Version,
                    }),
                    count = orders.Count,
                    asOf = DateTimeOffset.UtcNow,

                    // Stated on the response. This read reports release state; it confers
                    // none. Releasing is POST /api/v1/work-orders/{id}/release and still
                    // takes its step-up grant.
                    releaseAuthority =
                        "Release state is reported here and conferred nowhere. Releasing a " +
                        "work order is a separate controlled operation carrying a step-up grant.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // CH1-UX-SCR-0020, the R&D workbench.
        group.MapGet("/experiments", async (
            int? limit,
            HttpContext context,
            ResearchBenchService bench,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var experiments = await bench
                    .ListExperimentsAsync(actor, limit ?? DefaultRows, cancellationToken)
                    .ConfigureAwait(false);

                return Results.Ok(new
                {
                    items = experiments.Select(experiment => new
                    {
                        experiment.ExperimentId,
                        experiment.OwnerId,
                        experiment.Objective,
                        environment = experiment.Environment.ToString(),
                        status = experiment.Status.ToString(),
                        experiment.CreatedAt,
                        experiment.Version,
                        promotionRequested = experiment.PromotionRequestedAt is not null,

                        // On the face of every row. CH1-RND-FR-0001 keeps R&D apart from
                        // controlled production, and a workbench that did not say which
                        // side of that line a record sat on would be the place the
                        // separation quietly stopped meaning anything.
                        experiment.ProductionAuthority,
                    }),
                    count = experiments.Count,
                    asOf = DateTimeOffset.UtcNow,
                    isolationStatement =
                        "An experiment holds no production authority until an explicit " +
                        "authorised transition. No operation in this platform performs one.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // CH1-UX-SCR-0020 and CH1-UX-SCR-0021, the promotion review.
        group.MapGet("/experiments/{experimentId:guid}", async (
            Guid experimentId,
            HttpContext context,
            ResearchBenchService bench,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var found = await bench
                    .ReadExperimentAsync(experimentId, actor, cancellationToken)
                    .ConfigureAwait(false);
                if (found is not { } result)
                {
                    return Results.NotFound();
                }

                var (experiment, revisions) = result;
                return Results.Ok(new
                {
                    experiment.ExperimentId,
                    experiment.OwnerId,
                    experiment.Objective,
                    environment = experiment.Environment.ToString(),
                    status = experiment.Status.ToString(),
                    experiment.CreatedAt,
                    experiment.Version,
                    experiment.ProductionAuthority,

                    // The three things CH1-RND-FR-0003 requires a promotion to carry, and
                    // the screen that reviews it exists to show all three together.
                    promotion = experiment.PromotionRequestedAt is null ? null : new
                    {
                        changeRecord = experiment.PromotionChangeRecord,
                        impactAnalysis = experiment.PromotionImpactAnalysis,
                        verification = experiment.PromotionVerification,
                        requestedBy = experiment.PromotionRequestedBy,
                        requestedAt = experiment.PromotionRequestedAt,
                    },

                    // The provenance CH1-RND-FR-0002 asks a run to carry: what it was
                    // configured with, what went in, what came out, who asked and who ran
                    // it. Every reference travels with its checksum, because a reference
                    // without one names a thing that may have changed since.
                    revisions = revisions.Select(revision => new
                    {
                        revision.ExperimentRevisionId,
                        revision.RevisionNumber,
                        environment = revision.Environment.ToString(),
                        revision.ConfigurationReference,
                        revision.ConfigurationSha256,
                        revision.ModelReference,
                        revision.InputReference,
                        revision.InputSha256,
                        revision.ResultSummary,
                        revision.ResultSha256,
                        revision.RequestedBy,
                        revision.ExecutedBy,
                        revision.StartedAt,
                        revision.FinishedAt,
                        revision.ProductionAuthority,
                    }),
                    revisionCount = revisions.Count,
                    asOf = DateTimeOffset.UtcNow,
                    promotionAuthority =
                        "This platform emits a promotion request. Approving one is an act " +
                        "in configuration control, and no operation here performs it.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }
}
