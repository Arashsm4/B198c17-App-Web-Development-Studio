// HTTP routes for the quality loop: test runs, measurements, NCRs, dispositions, release.

using Cinerion.Api.Security;
using Cinerion.Application.Quality;
using Cinerion.Application.Security;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;
using Cinerion.Domain.Quality;
using Cinerion.Domain.Security;
using Cinerion.Infrastructure.Persistence;

namespace Cinerion.Api.Endpoints;

public static class QualityEndpoints
{
    public static void MapQualityEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("quality");

        // Owner-approved read, recorded in traceability/owner-approved-operations.json
        // with the screen it serves and the reason it exists. NOT a controlled operation:
        // the P03 catalogue stays exactly 54 and nothing here edits it.
        //
        // It resolves an identifier and returns an identifier. The genealogy below applies
        // its own authority check to the identifier this hands back, so a caller gains
        // nothing by going through here that they could not have reached directly.
        group.MapGet("/parts", async (
            string? serialNumber,
            HttpContext context,
            QualityService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            if (string.IsNullOrWhiteSpace(serialNumber))
            {
                return EndpointResults.FromDomainError(
                    context,
                    new DomainRuleException(
                        "PART_SERIAL_REQUIRED",
                        "Name the serial number to resolve. This operation resolves one controlled " +
                        "identity; it does not list or search parts, because a search over serial " +
                        "numbers is an enumeration of the project's components."));
            }

            var actor = actorFactory.Create(context.User);
            var part = await service
                .ResolvePartBySerialAsync(serialNumber, actor, cancellationToken)
                .ConfigureAwait(false);

            // Identical to a serial that never existed. A caller without the genealogy
            // authority must not be able to tell "not permitted" from "not there".
            return part is null ? Results.NotFound() : Results.Ok(new
            {
                part.PartId,
                part.SerialNumber,
                part.PermanentIdentityUri,
                // Said plainly, because a caller could otherwise assume a lookup that
                // answered is a lookup that disclosed the history.
                genealogy = $"/api/v1/parts/{part.PartId}/genealogy",
                effect = "IdentityResolved",
                scanEventRecorded = false,
                scanEventNote =
                    "No scan event was recorded. POST /api/v1/parts/scan-events is the controlled " +
                    "evidence path and needs a signed session from an enrolled Field Companion device; " +
                    "a browser lookup is not that and does not claim to be.",
            });
        });

        group.MapGet("/parts/{partId:guid}/genealogy", async (
            Guid partId,
            HttpContext context,
            QualityService service,
            StorageSelection storage,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            var part = await service.FindPartAsync(partId, actor, cancellationToken).ConfigureAwait(false);
            return part is null ? Results.NotFound() : Results.Ok(new
            {
                part,
                // Provenance must name the store the evidence actually came from. A
                // fixed string claiming an in-memory store while running on PostgreSQL
                // would misdescribe the durability of controlled evidence.
                provenance = storage.Mode == CinerionStorageMode.Postgres
                    ? "Controlled PostgreSQL store with project row-level security"
                    : "Volatile in-memory development store",
                evidenceCompleteness = part.Release is null ? "Open" : "Released",
                // Where discussion of this PART lives, derived rather than allocated,
                // exactly as the cell and alarm reads already do it. CH1-COL-FR-0001
                // ties a thread to a controlled object and the catalogue has no
                // operation that issues a thread identifier, so the object's own page
                // carries the derived value - an additive optional field, which is the
                // compatibility rule CH1-SWA-API-0001 states.
                //
                // Without it a part's discussion was reachable only by copying the
                // part identifier into the collaboration screen by hand, which is the
                // gap between departments being CONNECTED and being merely correlated.
                contextThreadId = ContextThread.DeriveId(
                    part.ProjectId,
                    ContextObjectType.Part,
                    part.PartId.ToString()),
            });
        });

        group.MapPost("/test-runs", async (
            StartTestRunDto request,
            HttpContext context,
            QualityService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var run = await service.StartTestRunAsync(
                    request.PartId,
                    request.ProcedureId,
                    request.ProcedureRevision,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/test-runs/{run.TestRunId}", new
                {
                    run.TestRunId,
                    run.PartId,
                    run.ProcedureId,
                    run.ProcedureRevision,
                    run.StartedBy,
                    status = run.Status.ToString(),
                    run.StartedAt,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPost("/test-runs/{testRunId:guid}/measurements", async (
            Guid testRunId,
            MeasurementDto request,
            HttpContext context,
            QualityService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var input = new MeasurementInput(
                    request.Characteristic,
                    request.Value,
                    request.Unit,
                    request.LowerLimit,
                    request.UpperLimit,
                    request.Mandatory,
                    request.SourceDeviceId,
                    request.CalibrationRecordId,
                    request.CalibrationValid,
                    request.SupersedesMeasurementId);
                var part = await service.RecordMeasurementAsync(
                    request.PartId,
                    testRunId,
                    input,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/parts/{part.PartId}/genealogy", new
                {
                    testRunId,
                    measurement = part.Measurements[^1],
                    partStatus = part.Status.ToString(),
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPost("/ncrs", async (
            RaiseNcrDto request,
            HttpContext context,
            QualityService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var result = await service.RaiseNcrAsync(
                    request.PartId,
                    request.Title,
                    request.Description,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/ncrs/{result.Ncr.NcrId}", new
                {
                    result.Ncr.NcrId,
                    result.Ncr.PartId,
                    result.Ncr.TestRunId,
                    result.Ncr.SourceMeasurementId,
                    result.Ncr.Title,
                    result.Ncr.Description,
                    status = result.Ncr.Status.ToString(),
                    result.Ncr.RaisedBy,
                    result.Ncr.RaisedAt,
                    partStatus = result.Part.Status.ToString(),
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // CH1-CYB-ACP-0001: closing a nonconformity is an Inspector action requiring
        // step-up. The grant is redeemed here, so the decision rests on a recent,
        // purpose-bound, single-use re-authentication rather than on session age.
        group.MapPost("/ncrs/{ncrId:guid}/dispositions", async (
            Guid ncrId,
            DisposeNcrDto request,
            HttpContext context,
            QualityService service,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var grantHeader = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(grantHeader, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Dispositioning a nonconformity requires a step-up grant in X-CH1-Step-Up.");
                }

                await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.NcrDisposition,
                    AuthenticationStrength.StepUpPhishingResistant,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var (ncr, part) = await service.DisposeNcrAsync(
                    ncrId,
                    request.Disposition,
                    request.Justification,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/ncrs/{ncr.NcrId}", new
                {
                    ncr.NcrId,
                    disposition = ncr.Disposition?.ToString(),
                    status = ncr.Status.ToString(),
                    ncr.DispositionBy,
                    ncr.DispositionAt,
                    ncr.DispositionJustification,
                    ncr.ClosedByMeasurementId,
                    partStatus = part.Status.ToString(),
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry: Inspector; all gates/tests closed, step-up MFA and signed
        // record. The step-up is redeemed here, in the same shape as NCR disposition and
        // work-order release, rather than being read off the session: a standing strength
        // claim cannot say that this person re-authenticated for this release, once.
        group.MapPost("/release-records", async (
            ReleasePartDto request,
            HttpContext context,
            QualityService service,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var grantHeader = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(grantHeader, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Releasing a part requires a phishing-resistant step-up grant in X-CH1-Step-Up.");
                }

                var redeemed = await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.PartRelease,
                    AuthenticationStrength.StepUpPhishingResistant,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var part = await service.ReleaseAsync(
                    request.PartId,
                    redeemed,
                    actor,
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/release-records/{part.Release!.ReleaseId}", part.Release);
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }
}

public sealed record StartTestRunDto(Guid PartId, string ProcedureId, string ProcedureRevision);

public sealed record MeasurementDto(
    Guid PartId,
    string Characteristic,
    decimal Value,
    string Unit,
    decimal LowerLimit,
    decimal UpperLimit,
    bool Mandatory,
    string SourceDeviceId,
    Guid CalibrationRecordId,
    bool CalibrationValid,
    Guid? SupersedesMeasurementId = null);

public sealed record RaiseNcrDto(Guid PartId, string Title, string Description);

public sealed record DisposeNcrDto(NcrDispositionKind Disposition, string Justification);

public sealed record ReleasePartDto(Guid PartId);
