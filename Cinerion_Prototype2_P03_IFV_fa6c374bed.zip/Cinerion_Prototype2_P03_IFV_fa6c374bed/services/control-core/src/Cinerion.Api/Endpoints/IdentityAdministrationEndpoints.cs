// HTTP routes for managing users, roles and sessions.

using Cinerion.Api.Security;
using Cinerion.Application.Identity;
using Cinerion.Application.Security;
using Cinerion.Domain.Common;
using Cinerion.Domain.Identity;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// Body of PUT /api/v1/users/{userId}/roles.
/// <para>
/// The full role set, not a delta. A caller states what the person should hold, so two
/// administrators working from the same view cannot compose a set neither intended.
/// </para>
/// </summary>
public sealed record ReplaceRolesDto(IReadOnlyList<string> Roles);

/// <summary>
/// User administration and session revocation.
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0006, CH1-IAM-FR-0008, CH1-CYB-ACP-0001</requirements>
public static class IdentityAdministrationEndpoints
{
    public static void MapIdentityAdministrationEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("identity");

        // Catalogue entry 6: System Administrator; scope filter, cursor pagination and no
        // secret fields.
        group.MapGet("/users", async (
            string? search,
            string? cursor,
            int? limit,
            HttpContext context,
            IdentityAdministrationService identity,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var page = await identity
                    .ListUsersAsync(search, cursor, limit, actor, cancellationToken)
                    .ConfigureAwait(false);

                return Results.Ok(new
                {
                    items = page.Users.Select(User),
                    count = page.Users.Count,
                    nextCursor = page.HasMore ? UserCursor.Encode(page.NextOffset) : null,
                    bounds = new { maximumRows = UserQuery.MaximumRows, defaultRows = UserQuery.DefaultRows },
                    // Said explicitly because it is the control on this operation: the
                    // projection carries identifiers, scope and lifecycle state, and no
                    // credential, secret, token or authenticator material of any kind.
                    disclosure = "Identifiers, scope, roles and lifecycle only. No credential or secret fields.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 7: System Administrator; step-up, segregation check, revision
        // and audit.
        group.MapPut("/users/{userId}/roles", async (
            string userId,
            ReplaceRolesDto request,
            HttpContext context,
            IdentityAdministrationService identity,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);

                // Role before step-up, for the same reason the device PKI endpoints do
                // it: a caller who cannot perform the action is told that rather than
                // told to obtain a grant, and no single-use grant is spent on a request
                // that was always going to be refused.
                if (!IdentityAdministrationService.CanAdministerUsers(actor))
                {
                    throw new DomainRuleException(
                        "AUTH_USER_ADMINISTRATION",
                        "Changing role assignments requires the System Administrator role.");
                }

                var header = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(header, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Changing role assignments requires a step-up grant in X-CH1-Step-Up.");
                }

                // access.json requires hardware-backed MFA to manage users, which is a
                // stronger statement than the "Step-up MFA" in the API control column.
                // The stronger of two controlled requirements is taken; the conflict is
                // recorded in docs/implementation/PROTOTYPE2_PROGRESS.md.
                await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.RoleAssignment,
                    AuthenticationStrength.StepUpPhishingResistant,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var result = await identity.ReplaceRolesAsync(
                    userId,
                    request.Roles ?? [],
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Ok(new
                {
                    result.Subject.UserId,
                    result.Subject.Username,
                    // Both sets, because CH1-MGT-FR-0003 wants a configuration change
                    // reversible to a known state and only the previous set makes it so.
                    previousRoles = result.Previous,
                    roles = result.Current,
                    granted = result.Granted,
                    withdrawn = result.Withdrawn,
                    segregation = new
                    {
                        securityPolicyRolesWithheld = RoleSegregation.SecurityPolicyRoles,
                        incompatiblePairs = RoleSegregation.IncompatiblePairs
                            .Select(pair => new { pair.First, pair.Second, pair.Reason }),
                    },
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 5: session owner or Identity Administrator; CSRF protection,
        // immediate revocation and audit.
        group.MapDelete("/auth/sessions/{sessionId}", async (
            string sessionId,
            HttpContext context,
            IdentityAdministrationService identity,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var session = await identity.RevokeSessionAsync(
                    sessionId,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Ok(new
                {
                    sessionId,
                    revoked = true,
                    ownSession = StringComparer.Ordinal.Equals(sessionId, actor.SessionId),
                    subjectUsername = session?.Username,
                    revokedBy = actor.ActorId,
                    revokedAt = DateTimeOffset.UtcNow,
                    // The control column names CSRF protection. This API is authenticated
                    // by a bearer token that no browser attaches automatically, so a
                    // cross-site request carries no credential and cannot revoke anything.
                    // Stated rather than left implied, and it is the reason no anti-forgery
                    // token appears here: adding one would suggest a cookie session exists.
                    crossSiteRequestForgery =
                        "Not applicable: bearer-token authentication is never sent automatically by a browser.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    /// <summary>
    /// The user projection. Every field is an identifier, a scope or a lifecycle state;
    /// nothing here is or derives from a credential.
    /// </summary>
    private static object User(IdentityUser user) => new
    {
        user.UserId,
        user.Username,
        user.DisplayName,
        user.Enabled,
        user.ProjectId,
        user.CellIds,
        user.Roles,
        actorKind = user.ActorKind.ToString(),
        user.CreatedAt,
    };
}
