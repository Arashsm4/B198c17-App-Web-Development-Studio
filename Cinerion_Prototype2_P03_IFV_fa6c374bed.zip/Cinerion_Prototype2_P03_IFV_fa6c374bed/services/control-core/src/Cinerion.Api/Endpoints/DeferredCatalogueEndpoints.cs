// Operations the baseline defers, like the document vault. They answer 501 honestly instead of
// pretending.

using Cinerion.Api.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// Keeps the full P03 API surface explicit while gated modules are implemented.
/// A controlled 501 is preferable to a misleading stub that appears to succeed.
/// </summary>
public static class DeferredCatalogueEndpoints
{
    private static readonly (string Method, string Path, string Capability)[] Deferred =
    [
        // Both remaining entries are the secure document vault, and both are genuinely a
        // declared future phase rather than work nobody did. CH1-DOC-FR-0002 requires a
        // unique data-encryption key per controlled document behind a separate
        // key-encryption boundary, and CH1-DOC-FR-0003 requires a hardware-backed
        // credential and user verification to decrypt. A vault without those is not a
        // vault, and an endpoint that returned a representation without them would be the
        // fake success this class exists to avoid.
        //
        // The two publication-package operations were on this list with them and should
        // not have been: CH1-DOC-FR-0004 is "Baseline P03", not a design target, and it
        // needs no key boundary at all. They are implemented in PublicationEndpoints.
        ("GET", "/api/v1/documents/{documentId}", "Secure document vault"),
        ("POST", "/api/v1/documents/{documentId}/export-requests", "Secure document export"),
    ];

    public static void MapDeferredCatalogueEndpoints(this IEndpointRouteBuilder endpoints)
    {
        foreach (var (method, path, capability) in Deferred)
        {
            endpoints.MapMethods(path, [method], (HttpContext context) => Results.Problem(
                    statusCode: StatusCodes.Status501NotImplemented,
                    title: "Controlled capability is not enabled in Prototype 1",
                    detail: $"{capability} remains gated and has not been represented as operational.",
                    type: "urn:cinerion:problem:capability-not-enabled",
                    extensions: new Dictionary<string, object?>
                    {
                        ["code"] = "CH1_CAPABILITY_NOT_ENABLED",
                        ["correlationId"] = CorrelationMiddleware.Get(context),
                        ["runtimeAuthority"] = "Simulation and controlled extra-low-voltage Prototype 1 only",
                    }))
                .RequireAuthorization()
                .WithTags("deferred");
        }
    }
}

