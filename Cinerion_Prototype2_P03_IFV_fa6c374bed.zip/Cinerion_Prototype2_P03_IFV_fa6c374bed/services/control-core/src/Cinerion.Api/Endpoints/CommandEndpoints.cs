// HTTP routes for commands: prepare, cancel, read. The portal can ask; only the cell can
// commit.

using System.Text.Json;
using Cinerion.Api.Security;
using Cinerion.Application.Commands;
using Cinerion.Application.Security;
using Cinerion.Domain.Commands;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

public static class CommandEndpoints
{
    public static void MapCommandEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("commands");

        group.MapPost("/commands/prepare", async (
            PrepareCommandDto request,
            HttpContext context,
            CommandService service,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var idempotencyKey = context.Request.Headers["Idempotency-Key"].FirstOrDefault()
                    ?? throw new DomainRuleException("CMD_IDEMPOTENCY_REQUIRED", "Idempotency-Key header is required.");
                var actor = actorFactory.Create(context.User);

                // CH1-CYB-IAM-0001 lists physical-effect preparation among the actions
                // requiring step-up. Redeeming the grant here adds what the token alone
                // cannot express: that the re-authentication was recent, was made for
                // this purpose, and is single use. Single use is what stops one
                // re-authentication from silently arming a series of preparations.
                var grantHeader = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(grantHeader, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Preparing a physical procedure requires a step-up grant in X-CH1-Step-Up.");
                }

                await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.PhysicalCommandPreparation,
                    AuthenticationStrength.StepUpPhishingResistant,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var intent = new PrepareIntent(
                    request.CommandType,
                    request.ProjectId,
                    request.SiteId,
                    request.CellId,
                    request.AssetId,
                    request.WorkOrderId,
                    request.PartId,
                    request.ProcedureRevision,
                    request.ConfigurationRevision,
                    request.ExpectedStateHash,
                    request.Sequence,
                    request.ExpiresAt,
                    idempotencyKey,
                    request.Parameters.ToDictionary(item => item.Key, item => (object)item.Value));
                var command = await service.PrepareAsync(intent, actor, cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/commands/{command.CommandId}", Project(command));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapGet("/commands/{commandId:guid}", async (
            Guid commandId,
            HttpContext context,
            CommandService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            // "Read command lifecycle AND controller acknowledgements", controlled by
            // "object-level authorisation and immutable audit links". All three halves
            // come from one correlated read rather than from the transaction alone: the
            // lifecycle is what the domain decided, and the acknowledgements are what the
            // equipment answered, and a reader given only the first cannot see the
            // outcome at all.
            var actor = actorFactory.Create(context.User);
            var outcome = await service.FindOutcomeAsync(commandId, actor, cancellationToken).ConfigureAwait(false);
            return outcome is null ? Results.NotFound() : Results.Ok(Project(outcome));
        });

        group.MapPost("/commands/{commandId:guid}/cancel", async (
            Guid commandId,
            CancelCommandDto request,
            HttpContext context,
            CommandService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var updated = await service.CancelAsync(
                    commandId,
                    request.Reason,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Ok(Project(updated));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPost("/confirmations/{confirmationId:guid}/credential-proofs", async (
            Guid confirmationId,
            CredentialProofDto request,
            HttpContext context,
            CommandService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                if (confirmationId != request.ConfirmationId)
                {
                    throw new DomainRuleException("PROOF_CONFIRMATION_MISMATCH", "Route and payload confirmation identifiers differ.");
                }

                var proof = new CredentialProof(
                    request.ProofId,
                    request.CommandId,
                    request.ConfirmationId,
                    request.CellId,
                    request.ControllerId,
                    request.CredentialId,
                    request.UserId,
                    request.AuthenticatorClass,
                    request.ChallengeHash,
                    request.CryptographicallyVerified,
                    request.UserVerified,
                    request.VerifiedAt,
                    request.ExpiresAt);
                var updated = await service.RecordCredentialProofAsync(
                    request.CommandId,
                    proof,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Ok(Project(updated));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPost("/confirmations/{confirmationId:guid}/local-commits", async (
            Guid confirmationId,
            LocalCommitDto request,
            HttpContext context,
            CommandService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                if (confirmationId != request.ConfirmationId)
                {
                    throw new DomainRuleException("BUTTON_CONFIRMATION_MISMATCH", "Route and payload confirmation identifiers differ.");
                }

                var observation = new LocalButtonObservation(
                    request.CommandId,
                    request.ConfirmationId,
                    request.CellId,
                    request.ControllerId,
                    request.ControllerBootId,
                    request.Source,
                    request.PreviousState,
                    request.CurrentState,
                    request.ObservedAt);
                var updated = await service.LocalCommitAsync(
                    request.CommandId,
                    observation,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Ok(Project(updated));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    private static object Project(CommandTransaction command) => new
    {
        command.CommandId,
        command.ConfirmationId,
        command.CorrelationId,
        command.RequesterId,
        state = command.State.ToString(),
        command.Intent,
        command.PreparedAt,
        command.CredentialProof,
        command.LocalCommitId,
        command.TerminalReason,
        command.Version,
        physicalConfirmationRequired = true,
        remoteStartAvailable = false,
    };

    /// <summary>
    /// The lifecycle, plus what the equipment answered and the links that evidence it.
    /// <para>
    /// <c>acknowledgements</c> is a separate field from <c>state</c> and deliberately not
    /// folded into it. A controller saying it received a command is evidence about
    /// delivery; the command advances on a credential proof and a physical button edge,
    /// and a shape that merged the two would invite a reader to treat an acknowledgement
    /// as execution. <c>acknowledgementIsNotExecution</c> says so in the payload rather
    /// than only in this comment, for the same reason <c>remoteStartAvailable</c> is
    /// there: a client reads the response, not the source.
    /// </para>
    /// </summary>
    private static object Project(CommandOutcome outcome)
    {
        var command = outcome.Command;
        return new
        {
            command.CommandId,
            command.ConfirmationId,
            command.CorrelationId,
            command.RequesterId,
            state = command.State.ToString(),
            command.Intent,
            command.PreparedAt,
            command.CredentialProof,
            command.LocalCommitId,
            command.TerminalReason,
            command.Version,
            physicalConfirmationRequired = true,
            remoteStartAvailable = false,
            acknowledgements = outcome.Acknowledgements,
            acknowledgementIsNotExecution = true,
            auditLinks = outcome.AuditLinks,
        };
    }
}

public sealed record PrepareCommandDto(
    string CommandType,
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    Guid WorkOrderId,
    Guid PartId,
    string ProcedureRevision,
    string ConfigurationRevision,
    string ExpectedStateHash,
    long Sequence,
    DateTimeOffset ExpiresAt,
    IReadOnlyDictionary<string, JsonElement> Parameters);

public sealed record CancelCommandDto(string Reason);

public sealed record CredentialProofDto(
    Guid ProofId,
    Guid CommandId,
    Guid ConfirmationId,
    Guid CellId,
    string ControllerId,
    Guid CredentialId,
    string UserId,
    AuthenticatorClass AuthenticatorClass,
    string ChallengeHash,
    bool CryptographicallyVerified,
    bool UserVerified,
    DateTimeOffset VerifiedAt,
    DateTimeOffset ExpiresAt);

public sealed record LocalCommitDto(
    Guid CommandId,
    Guid ConfirmationId,
    Guid CellId,
    string ControllerId,
    Guid ControllerBootId,
    ButtonEventSource Source,
    bool PreviousState,
    bool CurrentState,
    DateTimeOffset ObservedAt);

