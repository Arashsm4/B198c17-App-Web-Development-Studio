// HTTP routes for telemetry and alarms. Acknowledging an alarm changes nothing physical.

using Cinerion.Api.Security;
using Cinerion.Application.Monitoring;
using Cinerion.Domain.Collaboration;
using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;

namespace Cinerion.Api.Endpoints;

/// <summary>Body of POST /api/v1/alarms/{alarmId}/acknowledgements.</summary>
public sealed record AcknowledgeAlarmDto(string Comment);

/// <summary>
/// Telemetry query, alarm list and alarm acknowledgement.
/// </summary>
/// <requirements>CH1-MON-FR-0001, CH1-MON-FR-0002, CH1-MON-FR-0003, CH1-COL-FR-0003, CH1-AUT-FDS-0001</requirements>
public static class MonitoringEndpoints
{
    public static void MapMonitoringEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("monitoring");

        // Catalogue entry 17: project role scoped, with a channel allowlist and time
        // and row bounds. The bounds that were applied are returned alongside the rows
        // so a caller can tell a complete answer from a truncated one.
        group.MapGet("/telemetry", async (
            Guid? cellId,
            string? deviceId,
            DateTimeOffset? from,
            DateTimeOffset? to,
            int? limit,
            HttpContext context,
            MonitoringService monitoring,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                if (!MonitoringService.CanReadOperationalView(actor))
                {
                    return Results.NotFound();
                }

                var channels = context.Request.Query["channel"]
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Select(value => value!)
                    .ToArray();

                var samples = await monitoring.QueryTelemetryAsync(
                    cellId, deviceId, channels, from, to, limit, actor, cancellationToken).ConfigureAwait(false);
                var (freshness, newestSampleAt) = await monitoring
                    .ResolveFreshnessAsync(actor, cancellationToken).ConfigureAwait(false);

                return Results.Ok(new
                {
                    items = samples.Select(Sample),
                    count = samples.Count,
                    // A full page means there may be more inside the same window. Saying
                    // so is the difference between "these are all the samples" and
                    // "these are the first N".
                    truncated = samples.Count == Math.Clamp(limit ?? TelemetryQuery.DefaultRows, 1, TelemetryQuery.MaximumRows),
                    bounds = new
                    {
                        maximumRows = TelemetryQuery.MaximumRows,
                        defaultRows = TelemetryQuery.DefaultRows,
                        maximumWindowDays = TelemetryQuery.MaximumWindow.TotalDays,
                        defaultWindowHours = TelemetryQuery.DefaultWindow.TotalHours,
                    },
                    channelAllowlist = new
                    {
                        version = TelemetryChannelCatalogue.Version,
                        channels = TelemetryChannelCatalogue.All.Select(channel => new
                        {
                            channel.ChannelId,
                            channel.Unit,
                            channel.LowerAlarmLimit,
                            channel.UpperAlarmLimit,
                        }),
                    },
                    freshness = freshness.ToString(),
                    newestSampleAt,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 18: severity and state filters, cursor pagination and
        // freshness.
        group.MapGet("/alarms", async (
            Guid? cellId,
            int? maxPriority,
            string? cursor,
            int? limit,
            HttpContext context,
            MonitoringService monitoring,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                if (!MonitoringService.CanReadOperationalView(actor))
                {
                    return Results.NotFound();
                }

                var states = new List<AlarmState>();
                foreach (var value in context.Request.Query["state"])
                {
                    if (!Enum.TryParse<AlarmState>(value, ignoreCase: true, out var parsed))
                    {
                        throw new DomainRuleException(
                            "ALARM_STATE_FILTER_INVALID",
                            $"'{value}' is not an alarm state. Valid values are {string.Join(", ", Enum.GetNames<AlarmState>())}.");
                    }

                    states.Add(parsed);
                }

                var alarms = await monitoring.ListAlarmsAsync(
                    cellId, states, maxPriority, cursor, limit, actor, cancellationToken).ConfigureAwait(false);
                var (freshness, newestSampleAt) = await monitoring
                    .ResolveFreshnessAsync(actor, cancellationToken).ConfigureAwait(false);

                var appliedLimit = Math.Clamp(limit ?? AlarmQuery.DefaultRows, 1, AlarmQuery.MaximumRows);
                var last = alarms.Count == appliedLimit ? alarms[^1] : null;

                return Results.Ok(new
                {
                    items = alarms.Select(alarm => AlarmProjection(alarm, actor.ProjectId)),
                    count = alarms.Count,
                    // Present only when a further page may exist, so an absent cursor
                    // means the end of the list rather than an unknown position.
                    nextCursor = last is null
                        ? null
                        : new AlarmCursor(last.Priority, last.ActivatedAt, last.AlarmId).Encode(),
                    // The alarm list is only as current as the telemetry that would
                    // clear it, so its freshness is reported with it.
                    freshness = freshness.ToString(),
                    newestSampleAt,
                    asOf = DateTimeOffset.UtcNow,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 19: assigned operator or Engineer; comment, identity and
        // timestamp; no control side effect.
        group.MapPost("/alarms/{alarmId:guid}/acknowledgements", async (
            Guid alarmId,
            AcknowledgeAlarmDto request,
            HttpContext context,
            MonitoringService monitoring,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var alarm = await monitoring.AcknowledgeAlarmAsync(
                    alarmId,
                    request.Comment,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/alarms?cellId={alarm.CellId}", new
                {
                    alarm.AlarmId,
                    state = alarm.State.ToString(),
                    alarm.AcknowledgedBy,
                    alarm.AcknowledgedAt,
                    alarm.AcknowledgementComment,
                    // Restated in the response, because the whole point of the
                    // operation is what it does not do. CH1-COL-FR-0003 and
                    // CH1-AUT-FDS-0001 require acknowledgement to leave the cause,
                    // any fault, every interlock and local confirmation untouched.
                    alarm.CauseClear,
                    alarm.ClearedAt,
                    effect = "AcknowledgementRecorded",
                    controlSideEffect = "None: no fault cleared, no interlock satisfied, no command confirmed.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    private static object Sample(TelemetrySample sample) => new
    {
        sample.SampleId,
        sample.CellId,
        sample.DeviceId,
        sample.ChannelId,
        sample.Value,
        sample.Unit,
        quality = sample.Quality.ToString(),
        freshness = sample.Freshness.ToString(),
        sample.SampledAt,
        sample.ReceivedAt,
        // Two clocks, named separately. `timeQuality` is this service's, and therefore
        // describes `receivedAt`; `sourceTimeQuality` is what the source said about the
        // clock that stamped `sampledAt`, and is null when it said nothing. Reporting
        // only the first left a reader unable to tell a disciplined controller from an
        // undisciplined one - CH1-COM-ICD-0001 requires time quality to be observable,
        // and observable means legible here rather than merely stored. Defect 59.
        sample.TimeQuality,
        sample.SourceTimeQuality,
    };

    private static object AlarmProjection(Alarm alarm, Guid projectId) => new
    {
        alarm.AlarmId,
        alarm.CellId,
        alarm.SourceId,
        alarm.AlarmCode,
        alarm.Priority,
        state = alarm.State.ToString(),
        alarm.ActivatedAt,
        alarm.AcknowledgedBy,
        alarm.AcknowledgedAt,
        alarm.AcknowledgementComment,
        alarm.CauseClear,
        alarm.ClearedAt,
        outstanding = alarm.IsOutstanding,
        guidance = OperatorGuidance(alarm.AlarmCode),
        // Where discussion of this alarm lives. An additive optional field, which is
        // the compatibility rule CH1-SWA-API-0001 states; the P03 catalogue has no
        // operation that hands out a thread identifier, so object pages carry it.
        // Posting there acknowledges nothing about this alarm.
        contextThreadId = ContextThread.DeriveId(
            projectId, ContextObjectType.Alarm, alarm.AlarmId.ToString()),
    };

    /// <summary>
    /// CH1-AUT-FDS-0001 requires each alarm to carry operator guidance. It is served
    /// from the controlled channel catalogue rather than stored per alarm, so revising
    /// the guidance does not rewrite the record of an alarm that has already occurred.
    /// </summary>
    private static string OperatorGuidance(string alarmCode) =>
        TelemetryChannelCatalogue.All
            .FirstOrDefault(channel => StringComparer.Ordinal.Equals(channel.AlarmCode, alarmCode))
            ?.OperatorGuidance
        // Security alarms reach the same operator list through the same lifecycle, so
        // they carry guidance the same way.
        ?? SecurityAlarms.GuidanceFor(alarmCode)
        ?? "No guidance is registered for this alarm code. Refer to the cell operating procedure.";
}
