// Shared helpers so every route answers in the same shape.

using Cinerion.Api.Security;
using Cinerion.Domain.Common;

namespace Cinerion.Api.Endpoints;

public static class EndpointResults
{
    public static IResult FromDomainError(HttpContext context, DomainRuleException error)
    {
        var status = error.Code switch
        {
            var code when code.Contains("NOT_FOUND", StringComparison.Ordinal) => StatusCodes.Status404NotFound,
            var code when code.StartsWith("AUTH_", StringComparison.Ordinal) => StatusCodes.Status403Forbidden,
            // A uniqueness collision is a conflict with the current state of the
            // resource, which is 409. Only CONCURRENCY_CONFLICT and IDEMPOTENCY_CONFLICT
            // were listed, so PROJECT_CODE_CONFLICT, REVISION_CODE_CONFLICT,
            // WORK_ORDER_NUMBER_CONFLICT and CONTEXT_THREAD_CONFLICT all reported 400 -
            // a client could not tell "you sent something malformed" from "someone else
            // already has that identifier and retrying will not help".
            //
            // A refusal that comes from a record's own state machine rather than a
            // collision between two records stays 400: ALARM_ALREADY_ACKNOWLEDGED is
            // not a conflict with another row, it is an operation the record's current
            // state does not permit.
            var code when code.Contains("CONFLICT", StringComparison.Ordinal) => StatusCodes.Status409Conflict,
            _ => StatusCodes.Status400BadRequest,
        };
        return Results.Problem(
            statusCode: status,
            title: "Controlled operation rejected",
            detail: error.Message,
            type: $"urn:cinerion:problem:{error.Code.ToLowerInvariant()}",
            extensions: new Dictionary<string, object?>
            {
                ["code"] = error.Code,
                ["correlationId"] = CorrelationMiddleware.Get(context),
            });
    }
}

