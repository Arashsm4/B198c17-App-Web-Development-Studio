// HTTP routes for R&D experiments. Walled off from production, on purpose.

using Cinerion.Api.Security;
using Cinerion.Application.Research;
using Cinerion.Application.Security;
using Cinerion.Domain.Common;
using Cinerion.Domain.Research;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>Body of POST /api/v1/experiments.</summary>
public sealed record DefineExperimentDto(string Objective, ExperimentEnvironment? Environment = null);

/// <summary>
/// Body of POST /api/v1/experiments/{experimentId}/runs.
/// <para>
/// There is no environment field and no executor field. Both are taken from the
/// experiment, so a run can neither elect to be a bench run nor name a production
/// identity as its executor.
/// </para>
/// </summary>
public sealed record RecordExperimentRunDto(
    string ConfigurationReference,
    string ConfigurationSha256,
    string ModelReference,
    string InputReference,
    string InputSha256,
    string ResultSummary,
    string ResultSha256,
    DateTimeOffset StartedAt,
    DateTimeOffset FinishedAt);

/// <summary>Body of POST /api/v1/experiments/{experimentId}/promotion-requests.</summary>
public sealed record RequestPromotionDto(
    string ChangeRecord,
    string ImpactAnalysis,
    string Verification);

/// <summary>
/// Isolated R&amp;D experiments, run provenance and outbound promotion requests.
/// </summary>
/// <requirements>CH1-RND-FR-0001, CH1-RND-FR-0002, CH1-RND-FR-0003, CH1-CYB-ACP-0001</requirements>
public static class ResearchBenchEndpoints
{
    /// <summary>
    /// Said on every response. CH1-VVT-TC-0110 tests that experiment roles have no
    /// implicit production or real-equipment command authority, and a client that renders
    /// this verbatim inherits the statement rather than having to infer it.
    /// </summary>
    private const string IsolationNotice =
        "Isolated R&D workspace: simulator only, no production authority and no equipment command authority.";

    public static void MapResearchBenchEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("research");

        // Catalogue entry 45: R&D Engineer; simulator default, owner, objective and
        // provenance.
        group.MapPost("/experiments", async (
            DefineExperimentDto request,
            HttpContext context,
            ResearchBenchService research,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var experiment = await research.DefineAsync(
                    request.Objective,
                    request.Environment ?? ExperimentEnvironment.Simulator,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                context.Response.Headers.ETag = $"\"{experiment.Version}\"";
                return Results.Created(
                    $"/api/v1/experiments/{experiment.ExperimentId}/runs",
                    Projection(experiment));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 46: R&D Engineer; resource quota, isolated identity and
        // captured configuration.
        group.MapPost("/experiments/{experimentId:guid}/runs", async (
            Guid experimentId,
            RecordExperimentRunDto request,
            HttpContext context,
            ResearchBenchService research,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var (experiment, revision) = await research.RecordRunAsync(
                    experimentId,
                    new ExperimentRunInput(
                        request.ConfigurationReference,
                        request.ConfigurationSha256,
                        request.ModelReference,
                        request.InputReference,
                        request.InputSha256,
                        request.ResultSummary,
                        request.ResultSha256,
                        request.StartedAt,
                        request.FinishedAt),
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                context.Response.Headers.ETag = $"\"{experiment.Version}\"";
                return Results.Created(
                    $"/api/v1/experiments/{experimentId}/runs",
                    new
                    {
                        run = Run(revision),
                        experiment = Projection(experiment),
                        quota = new { recorded = revision.RevisionNumber, maximum = Experiment.MaximumRuns },
                    });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 47: R&D Engineer or Engineer; change record, impact analysis,
        // review and verification required. access.json additionally requires step-up MFA
        // to promote an R&D result.
        group.MapPost("/experiments/{experimentId:guid}/promotion-requests", async (
            Guid experimentId,
            RequestPromotionDto request,
            HttpContext context,
            ResearchBenchService research,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var header = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(header, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Requesting promotion requires a step-up grant in X-CH1-Step-Up.");
                }

                await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.ConfigurationPromotion,
                    AuthenticationStrength.Mfa,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var experiment = await research.RequestPromotionAsync(
                    experimentId,
                    request.ChangeRecord,
                    request.ImpactAnalysis,
                    request.Verification,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                context.Response.Headers.ETag = $"\"{experiment.Version}\"";
                return Results.Created($"/api/v1/experiments/{experimentId}/runs", new
                {
                    experiment = Projection(experiment),
                    // Stated in full, because for this operation what did not happen is
                    // the requirement. CH1-COM-IF-0021 makes promotion an outbound
                    // request; the approving authority is a Project Manager or
                    // Configuration Manager acting in configuration control.
                    outcome = "PromotionRequested",
                    approved = false,
                    approvalAuthority = "Project Manager or Configuration Manager, in configuration control",
                    effect =
                        "None: the request grants no production authority, no bench-mode transition and " +
                        "no equipment command authority.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    private static object Projection(Experiment experiment) => new
    {
        experiment.ExperimentId,
        experiment.OwnerId,
        experiment.Objective,
        environment = experiment.Environment.ToString(),
        status = experiment.Status.ToString(),
        experiment.Version,
        etag = $"\"{experiment.Version}\"",
        experiment.CreatedAt,
        experiment.PromotionChangeRecord,
        experiment.PromotionImpactAnalysis,
        experiment.PromotionVerification,
        experiment.PromotionRequestedBy,
        experiment.PromotionRequestedAt,
        promotionApproved = false,
        // Enforced by the database as well as here: ch1.experiments carries
        // CHECK (production_authority = false).
        experiment.ProductionAuthority,
        isolation = IsolationNotice,
    };

    private static object Run(ExperimentRevision revision) => new
    {
        revision.ExperimentRevisionId,
        revision.ExperimentId,
        revision.RevisionNumber,
        environment = revision.Environment.ToString(),
        // CH1-RND-FR-0002: everything a second authorised user needs to reproduce it.
        provenance = new
        {
            revision.ConfigurationReference,
            revision.ConfigurationSha256,
            revision.ModelReference,
            revision.InputReference,
            revision.InputSha256,
            revision.ResultSha256,
        },
        revision.ResultSummary,
        revision.RequestedBy,
        // The isolated bench identity the run executed under, derived from the
        // experiment. CH1-COM-IF-0020 requires it to be separate from any production
        // credential.
        revision.ExecutedBy,
        revision.StartedAt,
        revision.FinishedAt,
        revision.ProductionAuthority,
        immutable = true,
        // No fake success: this platform records runs, it does not perform them.
        platformRole = "Recorded. ResearchBench captures run provenance; the simulation itself runs elsewhere.",
    };
}
