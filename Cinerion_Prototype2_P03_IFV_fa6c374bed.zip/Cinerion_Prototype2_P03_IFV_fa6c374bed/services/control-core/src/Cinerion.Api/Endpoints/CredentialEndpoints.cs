// HTTP routes for passkeys and TOTP: enrol, challenge, verify, revoke.

using Cinerion.Api.Security;
using Cinerion.Application.Security;
using Cinerion.Domain.Common;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// Body of POST /api/v1/credentials.
/// <para>
/// There is no field for a private key, a PIN or a seed, and there deliberately never
/// will be. CH1-CYB-IAM-0001 keeps long-lived private keys non-exportable in the
/// authenticator, so material arriving here would mean that boundary had already failed
/// — the same rule device enrolment applies to certificates.
/// </para>
/// </summary>
public sealed record RegisterCredentialDto(
    string SubjectId,
    string Kind,
    string Label,
    /// <summary>
    /// Base64url. The attestation object <c>navigator.credentials.create()</c> returned,
    /// carrying the authenticator data the authenticator signed and the attested credential
    /// data the key comes out of.
    /// </summary>
    string? AttestationObject = null,
    /// <summary>Base64url. The client data the browser produced for the same call.</summary>
    string? ClientDataJson = null,
    /// <summary>
    /// The step-up whose challenge the registration answers. It is the same grant this
    /// operation already required for authority, so there is one nonce and one place it is
    /// read from; a caller cannot present a challenge that disagrees with its grant.
    /// </summary>
    Guid? StepUpGrantId = null,
    string? SerialNumber = null,
    string? UserVerification = null,
    DateTimeOffset? ExpiresAt = null)
{
    /// <summary>
    /// Both halves of the registration, or a controlled refusal naming what is missing.
    /// <para>
    /// Nullable and checked here rather than non-nullable and trusted: a body that omits
    /// them is an ordinary client mistake and must answer 400 with a code, not 500 with a
    /// trace identifier. The old body shape - a public key and a handle as request fields
    /// - reaches exactly this branch, which is the right answer for it.
    /// </para>
    /// </summary>
    public (string Attestation, string ClientData) RequireRegistration()
    {
        if (string.IsNullOrWhiteSpace(AttestationObject) || string.IsNullOrWhiteSpace(ClientDataJson))
        {
            throw new DomainRuleException(
                "CREDENTIAL_PROOF_OF_POSSESSION_REQUIRED",
                "A FIDO2 credential is enrolled from a registration this platform verified: " +
                "attestationObject and clientDataJson are both required. A public key supplied " +
                "as a request field is not proof of possession and is no longer accepted.");
        }

        return (AttestationObject!, ClientDataJson!);
    }
}

/// <summary>Body of POST /api/v1/auth/totp/enrolments.</summary>
public sealed record EnrolTotpDto(string? SubjectId = null, string? Label = null);

/// <summary>Body of POST /api/v1/auth/passkey/options.</summary>
public sealed record PasskeyOptionsDto(string Purpose, string? RpId = null, string? Origin = null);

/// <summary>Body of POST /api/v1/auth/passkey/verify.</summary>
public sealed record PasskeyVerifyDto(
    Guid ChallengeId,
    string CredentialId,
    string AuthenticatorData,
    string ClientDataJson,
    string Signature);

/// <summary>
/// Enrolment, assertion and revocation of human authenticators.
/// </summary>
/// <requirements>CH1-IAM-FR-0004, CH1-IAM-FR-0005, CH1-IAM-FR-0006, CH1-IAM-FR-0007</requirements>
public static class CredentialEndpoints
{
    public static void MapCredentialEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("credentials");

        // Catalogue entry 3: self or Identity Administrator; step-up MFA, secret shown
        // once and encrypted storage.
        group.MapPost("/auth/totp/enrolments", async (
            EnrolTotpDto request,
            HttpContext context,
            CredentialService credentials,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                await RedeemStepUpAsync(
                    context, stepUp, actor, StepUpPurpose.CredentialAdministration,
                    AuthenticationStrength.Mfa, "Enrolling a second factor", cancellationToken)
                    .ConfigureAwait(false);

                var enrolment = await credentials.EnrolTotpAsync(
                    request.SubjectId ?? actor.ActorId,
                    request.Label ?? "Authenticator app",
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                // The one and only disclosure. No read operation returns the secret, the
                // audit chain records none of it, and a second enrolment is refused
                // while this one is active - so a caller that loses this response has to
                // revoke and enrol again, which is the intended consequence.
                return Results.Created(
                    $"/api/v1/credentials/{enrolment.Credential.CredentialId}",
                    new
                    {
                        enrolment.Credential.CredentialId,
                        enrolment.Credential.SubjectId,
                        kind = enrolment.Credential.Kind.ToString(),
                        enrolment.Credential.Label,
                        sharedSecret = enrolment.SharedSecretBase32,
                        otpauthUri = enrolment.EnrolmentUri,
                        algorithm = enrolment.Parameters.Algorithm,
                        enrolment.Parameters.Digits,
                        periodSeconds = (int)enrolment.Parameters.Period.TotalSeconds,
                        driftStepsAccepted = TotpParameters.DriftSteps,
                        // Stated plainly, because a caller that assumed otherwise would
                        // discover it only when a phishing-resistant gate refused them.
                        phishingResistant = false,
                        disclosure = "This secret is shown once and is never retrievable again. " +
                            "Store it in an authenticator now; if it is lost, revoke this credential and enrol another.",
                        assurance = "A one-time password is a shared secret. It satisfies step-up MFA " +
                            "and never satisfies a phishing-resistant step-up.",
                    });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 1: short TTL, origin/RP binding, nonce and audit.
        //
        // The catalogue marks this operation anonymous with a rate limit, which suits a
        // deployment where a passkey is the primary login. Here FortressGate performs
        // login and this endpoint raises an existing session to phishing-resistant
        // strength, so it is bound to the authenticated caller: an anonymous challenge
        // would have no identity whose enrolled authenticators it could name, and would
        // let an unauthenticated caller enumerate whether an account holds a passkey.
        // Reported as a conflict rather than resolved silently.
        group.MapPost("/auth/passkey/options", async (
            PasskeyOptionsDto request,
            HttpContext context,
            CredentialService credentials,
            ActorContextFactory actorFactory,
            IConfiguration configuration,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var (rpId, origin) = ResolveRelyingParty(configuration, request.RpId, request.Origin);

                var challenge = await credentials.BeginPasskeyAssertionAsync(
                    request.Purpose, rpId, origin, actor,
                    CorrelationMiddleware.Get(context), cancellationToken).ConfigureAwait(false);

                var enrolled = await credentials
                    .ListAsync(actor.ActorId, actor, cancellationToken).ConfigureAwait(false);

                return Results.Ok(new
                {
                    challenge.ChallengeId,
                    challenge = Base64Url.Encode(challenge.Challenge),
                    rpId = challenge.RpId,
                    challenge.Origin,
                    challenge.Purpose,
                    challenge.ExpiresAt,
                    timeoutMilliseconds = (int)WebAuthnChallenge.Lifetime.TotalMilliseconds,
                    // Required, not preferred: every purpose this challenge can be
                    // redeemed for is a sensitive action, and presence alone does not
                    // establish that the right person touched the authenticator.
                    userVerification = "required",
                    allowCredentials = enrolled
                        .Where(item => item.PhishingResistant && item.WebAuthnCredentialId is not null)
                        .Select(item => new
                        {
                            type = "public-key",
                            id = Base64Url.Encode(item.WebAuthnCredentialId!),
                            item.Label,
                        }),
                    singleUse = true,
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 2: challenge holder; FIDO2 verification, replay rejection and
        // secure cookie.
        //
        // The catalogue says "create session". This issues a phishing-resistant step-up
        // grant instead, and does not mint a second kind of session: FortressGate owns
        // sessions, and a parallel session mechanism here would mean two revocation
        // paths, one of which DELETE /api/v1/auth/sessions/{sessionId} could not reach.
        // Reported as a conflict.
        group.MapPost("/auth/passkey/verify", async (
            PasskeyVerifyDto request,
            HttpContext context,
            CredentialService credentials,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var assertion = new WebAuthnAssertion(
                    WebAuthnVerifier.FromBase64Url(request.CredentialId, "PASSKEY_CREDENTIAL_ID_INVALID"),
                    WebAuthnVerifier.FromBase64Url(request.AuthenticatorData, "PASSKEY_AUTHENTICATOR_DATA_INVALID"),
                    WebAuthnVerifier.FromBase64Url(request.ClientDataJson, "PASSKEY_CLIENT_DATA_INVALID"),
                    WebAuthnVerifier.FromBase64Url(request.Signature, "PASSKEY_SIGNATURE_MALFORMED"));

                var (grant, credential) = await credentials.CompletePasskeyAssertionAsync(
                    request.ChallengeId, assertion, actor,
                    CorrelationMiddleware.Get(context), cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/credentials/{credential.CredentialId}", new
                {
                    grant.GrantId,
                    grant.Purpose,
                    grantedStrength = grant.Strength.ToString(),
                    grant.GrantedAt,
                    grant.ExpiresAt,
                    singleUse = true,
                    credential.CredentialId,
                    credential.Label,
                    signCount = credential.SignCount,
                    // Said in as many words: the grant raises the strength of one
                    // action, and creates no session of its own.
                    effect = "PhishingResistantStepUpGranted",
                    sessionEffect = "None: FortressGate owns the session. This grant authorises one action.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 8: Cybersecurity Administrator; proof of possession, unique
        // identity and lifecycle record.
        group.MapPost("/credentials", async (
            RegisterCredentialDto request,
            HttpContext context,
            CredentialService credentials,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            IConfiguration configuration,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                if (!Enum.TryParse<CredentialKind>(request.Kind, ignoreCase: true, out var kind))
                {
                    throw new DomainRuleException(
                        "CREDENTIAL_KIND_UNKNOWN",
                        $"'{request.Kind}' is not a credential kind. Valid values are " +
                        $"{string.Join(", ", Enum.GetNames<CredentialKind>())}.");
                }

                // Role before step-up, so a caller who could never perform the action is
                // not told to obtain a grant they could not use, and a single-use grant
                // is not spent on a request that was always going to be refused.
                if (!CredentialService.CanAdministerCredentials(actor))
                {
                    throw new DomainRuleException(
                        "AUTH_CREDENTIAL_ADMINISTRATION",
                        "Registering a physical credential requires a Cybersecurity Administrator.");
                }

                var grant = await RedeemStepUpAsync(
                    context, stepUp, actor, StepUpPurpose.CredentialAdministration,
                    AuthenticationStrength.Mfa, "Registering a credential", cancellationToken)
                    .ConfigureAwait(false);

                var (rpId, origin) = ResolveRelyingParty(configuration, null, null);

                // The proof of possession api_endpoints.json makes the control on this
                // operation, verified here rather than asserted. The public key and the
                // credential handle come OUT of this, not out of the request: the platform
                // decides from the artefact, never from what the submitter claims about it.
                //
                // The challenge is the grant's own, read from the redeemed grant and never
                // taken from the body, so there is exactly one nonce and it cannot be made
                // to disagree with the authority it travelled with.
                WebAuthnEnrolment? proof = null;
                if (kind is CredentialKind.Passkey or CredentialKind.SecurityToken)
                {
                    if (request.StepUpGrantId is Guid stated && stated != grant.GrantId)
                    {
                        throw new DomainRuleException(
                            "STEP_UP_GRANT_MISMATCH",
                            "The registration names a different step-up than the one presented.");
                    }

                    var (attestation, clientData) = request.RequireRegistration();
                    proof = grant.VerifyEnrolment(
                        new WebAuthnRegistration(
                            WebAuthnVerifier.FromBase64Url(attestation, "PASSKEY_ATTESTATION_INVALID"),
                            WebAuthnVerifier.FromBase64Url(clientData, "PASSKEY_CLIENT_DATA_INVALID")),
                        rpId,
                        origin);
                }

                var registered = await credentials.RegisterAsync(
                    request.SubjectId,
                    kind,
                    request.Label,
                    proof,
                    request.SerialNumber,
                    rpId,
                    ParseUserVerification(request.UserVerification),
                    request.ExpiresAt,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/credentials/{registered.CredentialId}", Projection(registered));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 9: Cybersecurity Administrator; step-up MFA, immediate
        // denylist and audit.
        group.MapDelete("/credentials/{credentialId:guid}", async (
            Guid credentialId,
            string? reason,
            HttpContext context,
            CredentialService credentials,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                if (!CredentialService.CanAdministerCredentials(actor))
                {
                    throw new DomainRuleException(
                        "AUTH_CREDENTIAL_ADMINISTRATION",
                        "Revoking a credential requires a Cybersecurity Administrator.");
                }

                await RedeemStepUpAsync(
                    context, stepUp, actor, StepUpPurpose.CredentialAdministration,
                    AuthenticationStrength.Mfa, "Revoking a credential", cancellationToken)
                    .ConfigureAwait(false);

                var revoked = await credentials.RevokeAsync(
                    credentialId, reason ?? string.Empty, actor,
                    CorrelationMiddleware.Get(context), cancellationToken).ConfigureAwait(false);

                // 200 rather than 204: the revocation record is the evidence, and a
                // caller with no body could not show who withdrew the credential or why.
                return Results.Ok(Projection(revoked));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    /// <summary>
    /// The relying party this platform verifies assertions for.
    /// <para>
    /// Taken from configuration, never from the request. A caller that could name its own
    /// relying-party identifier or origin could obtain a challenge for a site it
    /// controls, which is precisely the phishing this credential class exists to prevent.
    /// A supplied value is accepted only when it matches what is configured.
    /// </para>
    /// </summary>
    /// <summary>
    /// The relying party this deployment is. Internal rather than private because
    /// <c>POST /api/v1/auth/step-up</c> now returns it alongside the challenge, and two
    /// implementations of "which origin are we" is two places for them to disagree — which
    /// on a passkey is the difference between phishing resistant and not.
    /// </summary>
    internal static (string RpId, string Origin) ResolveRelyingParty(
        IConfiguration configuration,
        string? requestedRpId,
        string? requestedOrigin)
    {
        var rpId = configuration["CINERION_WEBAUTHN_RP_ID"] ?? "localhost";
        var origin = configuration["CINERION_WEBAUTHN_ORIGIN"] ?? "http://localhost:19006";

        Guard.Against(
            requestedRpId is not null && !string.Equals(requestedRpId, rpId, StringComparison.Ordinal),
            "PASSKEY_RP_ID_NOT_PERMITTED",
            "The relying party is fixed by configuration and cannot be chosen by the caller.");
        Guard.Against(
            requestedOrigin is not null && !string.Equals(requestedOrigin, origin, StringComparison.Ordinal),
            "PASSKEY_ORIGIN_NOT_PERMITTED",
            "The origin is fixed by configuration and cannot be chosen by the caller.");

        return (rpId, origin);
    }

    private static UserVerificationRequirement ParseUserVerification(string? value) =>
        Enum.TryParse<UserVerificationRequirement>(value, ignoreCase: true, out var parsed)
            ? parsed
            : UserVerificationRequirement.Required;

    private static async Task<StepUpGrant> RedeemStepUpAsync(
        HttpContext context,
        StepUpService stepUp,
        ActorContext actor,
        string purpose,
        AuthenticationStrength required,
        string action,
        CancellationToken cancellationToken)
    {
        var header = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
        if (!Guid.TryParse(header, out var grantId))
        {
            throw new DomainRuleException(
                "STEP_UP_REQUIRED",
                $"{action} requires a step-up grant in X-CH1-Step-Up.");
        }

        return await stepUp.RedeemAsync(grantId, purpose, required, actor, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// What a credential looks like to a caller. Carries no secret, no seed and no
    /// private key — entities.json declares this record as authenticator metadata, and
    /// the projection is where that promise is kept.
    /// </summary>
    private static object Projection(CredentialRecord credential) => new
    {
        credential.CredentialId,
        credential.SubjectId,
        kind = credential.Kind.ToString(),
        credential.Label,
        credential.PhishingResistant,
        userVerification = credential.UserVerification.ToString(),
        status = credential.Status.ToString(),
        credential.SerialNumber,
        credential.SignCount,
        credential.EnrolledBy,
        credential.EnrolledAt,
        credential.LastUsedAt,
        credential.ExpiresAt,
        credential.RevokedAt,
        credential.RevokedBy,
        credential.RevocationReason,
        credential.Version,
        // CH1-COM-IF-0004 puts the reader-side denylist in the cell controller, which is
        // not enabled, so revocation here withdraws platform trust and says so rather
        // than implying the card has been stopped at every door.
        platformTrustWithdrawn = credential.Status == CredentialStatus.Revoked,
        readerDenylistUpdated = false,
    };
}
