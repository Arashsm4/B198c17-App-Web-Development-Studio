// HTTP routes for publication packages and their two-person review.

using Cinerion.Api.Security;
using Cinerion.Application.Documents;
using Cinerion.Domain.Common;
using Cinerion.Domain.Documents;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// Body of POST /api/v1/publication-packages.
/// <para>
/// The caller supplies the derivative and the profile to judge it against. It cannot
/// supply a checksum, a state, or a statement that any control passed: every one of those
/// is computed here, because a package whose checksum came from the requester would be
/// evidence of what the requester wanted it to say.
/// </para>
/// </summary>
public sealed record CreatePublicationPackageDto(
    string RedactionProfileId,
    string Title,
    IReadOnlyList<Guid> SourceDocumentIds,
    string Content,
    string? MediaType,
    IReadOnlyDictionary<string, string>? Metadata);

/// <summary>
/// Body of POST /api/v1/publication-packages/{packageId}/approvals.
/// <para>
/// <see cref="ReviewedChecksum"/> is the control, not a formality: the reviewer states the
/// checksum of what they actually looked at, and a review of different bytes is refused.
/// There is no field for the capacity - it is derived from the reviewer's own roles, so a
/// caller cannot nominate which of the two reviews they are performing.
/// </para>
/// </summary>
public sealed record ReviewPublicationPackageDto(
    bool Approved,
    string ReviewedChecksum,
    string Comment);

/// <summary>
/// The CH1-DOC-FR-0004 publication pipeline: a clean-room redacted derivative and the two
/// reviews that must precede publication.
/// </summary>
/// <remarks>
/// There is no operation here that publishes. CH1 builds the derivative, records what the
/// pipeline did to it and holds it until two named capacities have reviewed the exact
/// bytes; publication itself is an act outside this platform.
/// </remarks>
/// <requirements>CH1-DOC-FR-0001, CH1-DOC-FR-0004, CH1-CYB-FR-0001</requirements>
public static class PublicationEndpoints
{
    public static void MapPublicationEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("publication");

        // Catalogue entry: Document Controller; allowlist inputs, metadata scrub, secret
        // scan and diff.
        group.MapPost("/publication-packages", async (
            CreatePublicationPackageDto request,
            HttpContext context,
            PublicationPipelineService publication,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var package = await publication.CreateAsync(
                    request.RedactionProfileId,
                    request.Title,
                    request.SourceDocumentIds ?? [],
                    request.Content,
                    request.MediaType ?? string.Empty,
                    request.Metadata ?? new Dictionary<string, string>(StringComparer.Ordinal),
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created(
                    $"/api/v1/publication-packages/{package.PackageId}", Projection(package, []));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry: IR plus Document Control review; phishing-resistant step-up,
        // visual review and checksum.
        group.MapPost("/publication-packages/{packageId:guid}/approvals", async (
            Guid packageId,
            ReviewPublicationPackageDto request,
            HttpContext context,
            PublicationPipelineService publication,
            Cinerion.Application.Security.StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);

                // access.json: "Approve redacted publication | IR plus Document Control
                // review | Step-up phishing-resistant MFA". Redeemed before the decision is
                // recorded, so a failure afterwards cannot leave the grant reusable.
                var header = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(header, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Approving a publication package requires a step-up grant in X-CH1-Step-Up.");
                }

                await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.PublicationApproval,
                    AuthenticationStrength.StepUpPhishingResistant,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var (package, approval) = await publication.ApproveAsync(
                    packageId,
                    request.Approved,
                    request.ReviewedChecksum,
                    request.Comment,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Ok(Projection(package, [approval]));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    /// <summary>
    /// What the platform will say about a package.
    /// </summary>
    /// <remarks>
    /// <c>contentDiffPerformed</c> and its note are on the face of every response, on the
    /// same terms as a device revocation reporting <c>brokerTopicAclRevoked: false</c>: the
    /// half of a control that did not happen is stated rather than implied by its absence.
    /// </remarks>
    private static object Projection(
        PublicationPackage package,
        IReadOnlyList<PublicationApproval> approvals) => new
        {
            package.PackageId,
            package.Title,
            redactionProfile = package.RedactionProfile,
            package.ProfileRevision,
            state = package.State.ToString(),
            package.ContentSha256,
            package.MediaType,
            package.SizeBytes,
            package.StorageUri,
            sources = package.Sources.Select(source => new
            {
                source.DocumentId,
                source.DocumentNumber,
                source.Revision,
                source.Classification,
                source.ContentSha256,
            }),
            metadataRemoved = package.MetadataRemoved,
            metadataRetained = package.MetadataRetained,
            secretScan = new
            {
                profile = package.SecretScanProfile,
                patterns = package.SecretScanPatterns,
                findings = Array.Empty<string>(),
            },
            package.ContentDiffPerformed,
            package.ContentDiffNote,
            package.CreatedBy,
            package.CreatedAt,
            package.DecidedAt,
            package.Version,
            reviews = approvals.Select(approval => new
            {
                approval.ApprovalId,
                capacity = approval.Capacity.ToString(),
                decision = approval.Decision.ToString(),
                approval.ReviewedBy,
                approval.ReviewedChecksum,
                approval.Comment,
                approval.ReviewedAt,
            }),

            // Stated on every response. The pipeline decides what may be published; it
            // never publishes, and no operation in this platform does.
            publicationAuthority =
                "CH1 records the reviews CH1-DOC-FR-0004 requires. Publication itself is an " +
                "act outside this platform.",
        };
}
