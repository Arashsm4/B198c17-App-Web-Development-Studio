// HTTP routes for revisions, BOMs, routes and work orders. The paperwork of making things.

using Cinerion.Api.Security;
using Cinerion.Application.Manufacturing;
using Cinerion.Application.Security;
using Cinerion.Domain.Common;
using Cinerion.Domain.Manufacturing;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>
/// ForgeFlow: product revisions, bills of material, routes and work orders.
/// </summary>
public static class ForgeFlowEndpoints
{
    public static void MapForgeFlowEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("forgeflow");

        group.MapGet("/products", async (
            string? productCode,
            HttpContext context,
            ForgeFlowService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            var actor = actorFactory.Create(context.User);
            var revisions = await service.ListRevisionsAsync(productCode, actor, cancellationToken).ConfigureAwait(false);
            // Products are projected from their revisions: a product exists because a
            // controlled revision of it exists, which is what the schema records.
            var products = revisions
                .GroupBy(item => item.ProductCode, StringComparer.Ordinal)
                .Select(product => new
                {
                    productCode = product.Key,
                    revisions = product.Select(Project).ToArray(),
                });
            return Results.Ok(products);
        });

        group.MapPost("/products/{productId}/revisions", async (
            string productId,
            CreateRevisionDto request,
            HttpContext context,
            ForgeFlowService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var revision = await service.CreateRevisionAsync(
                    productId,
                    request.RevisionCode,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/product-revisions/{revision.RevisionId}", Project(revision));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPut("/product-revisions/{revisionId:guid}/bom", async (
            Guid revisionId,
            SetBomDto request,
            HttpContext context,
            ForgeFlowService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var revision = await service.SetBomAsync(
                    revisionId,
                    [.. request.Lines.Select(line => new BomLine(line.ComponentCode, line.Quantity, line.Unit))],
                    request.ExpectedVersion,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Ok(Project(revision));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPut("/product-revisions/{revisionId:guid}/route", async (
            Guid revisionId,
            SetRouteDto request,
            HttpContext context,
            ForgeFlowService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var revision = await service.SetRouteAsync(
                    revisionId,
                    [.. request.Steps.Select(step => new RouteStep(step.StepNumber, step.OperationCode, step.Description, step.MandatoryInspection))],
                    request.ExpectedVersion,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Ok(Project(revision));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        group.MapPost("/work-orders", async (
            CreateWorkOrderDto request,
            HttpContext context,
            ForgeFlowService service,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var workOrder = await service.CreateWorkOrderAsync(
                    request.WorkOrderNumber,
                    request.RevisionId,
                    request.CellId,
                    request.Quantity,
                    actorFactory.Create(context.User),
                    cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/work-orders/{workOrder.WorkOrderId}", Project(workOrder));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // CH1-CYB-ACP-0001: releasing a work order is a Project Manager action
        // requiring step-up, redeemed here the same way preparation and NCR
        // disposition redeem theirs.
        group.MapPost("/work-orders/{workOrderId:guid}/release", async (
            Guid workOrderId,
            HttpContext context,
            ForgeFlowService service,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                var grantHeader = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
                if (!Guid.TryParse(grantHeader, out var grantId))
                {
                    throw new DomainRuleException(
                        "STEP_UP_REQUIRED",
                        "Releasing a work order requires a step-up grant in X-CH1-Step-Up.");
                }

                await stepUp.RedeemAsync(
                    grantId,
                    StepUpPurpose.WorkOrderRelease,
                    AuthenticationStrength.StepUpPhishingResistant,
                    actor,
                    cancellationToken).ConfigureAwait(false);

                var released = await service.ReleaseWorkOrderAsync(workOrderId, actor, cancellationToken).ConfigureAwait(false);
                return Results.Created($"/api/v1/work-orders/{released.WorkOrderId}", Project(released));
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    private static object Project(ProductRevisionRecord revision) => new
    {
        revision.RevisionId,
        revision.ProductCode,
        revision.RevisionCode,
        lifecycleState = revision.LifecycleState.ToString(),
        revision.Bom,
        revision.Route,
        revision.SourceChecksum,
        revision.ReleasedAt,
        revision.SupersededAt,
        revision.Version,
    };

    private static object Project(WorkOrderRecord workOrder) => new
    {
        workOrder.WorkOrderId,
        workOrder.WorkOrderNumber,
        workOrder.RevisionId,
        workOrder.CellId,
        workOrder.Quantity,
        status = workOrder.Status.ToString(),
        workOrder.ReleasedBy,
        workOrder.ReleasedAt,
        workOrder.Version,
    };
}

public sealed record CreateRevisionDto(string RevisionCode);

public sealed record BomLineDto(string ComponentCode, decimal Quantity, string Unit);

/// <summary>ExpectedVersion carries the optimistic concurrency check the catalogue requires.</summary>
public sealed record SetBomDto(long ExpectedVersion, IReadOnlyList<BomLineDto> Lines);

public sealed record RouteStepDto(int StepNumber, string OperationCode, string Description, bool MandatoryInspection);

public sealed record SetRouteDto(long ExpectedVersion, IReadOnlyList<RouteStepDto> Steps);

public sealed record CreateWorkOrderDto(string WorkOrderNumber, Guid RevisionId, Guid? CellId, int Quantity);
