// HTTP routes for device certificates: enrol a device, revoke one.

using Cinerion.Api.Security;
using Cinerion.Application.Assets;
using Cinerion.Application.Security;
using Cinerion.Domain.Assets;
using Cinerion.Domain.Common;
using Cinerion.Domain.Monitoring;
using Cinerion.Domain.Security;

namespace Cinerion.Api.Endpoints;

/// <summary>One channel a device declares it can publish.</summary>
public sealed record DeviceChannelDto(string ChannelId, string Unit);

/// <summary>
/// Body of POST /api/v1/devices/{deviceId}/enrolment.
/// <para>
/// <c>Certificate</c> is the device's certificate as PEM or base64 DER. There is no
/// field for a private key, no field for a thumbprint and no field for a validity
/// window: the key never leaves the device, and the other two are derived here from the
/// certificate itself.
/// </para>
/// </summary>
public sealed record EnrolDeviceDto(
    string Certificate,
    string SchemaVersion,
    string DeviceType,
    string FirmwareVersion,
    string ConfigurationRevision,
    IReadOnlyList<DeviceChannelDto> TelemetryChannels,
    IReadOnlyList<string> SupportedCommands,
    string SecurityProfile);

/// <summary>Body of POST /api/v1/devices/{deviceId}/revoke.</summary>
public sealed record RevokeDeviceDto(string Reason);

/// <summary>
/// Device certificate enrolment and revocation.
/// </summary>
/// <requirements>CH1-IAM-FR-0006, CH1-IAM-FR-0008, CH1-CYB-FR-0002, CH1-CYB-FR-0003</requirements>
public static class DevicePkiEndpoints
{
    public static void MapDevicePkiEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/v1").RequireAuthorization().WithTags("device-pki");

        // Catalogue entry 15: Cybersecurity Administrator; attestation/certificate proof,
        // allowlist and audit. access.json additionally requires hardware-backed MFA to
        // enrol or revoke a device.
        group.MapPost("/devices/{deviceId}/enrolment", async (
            string deviceId,
            EnrolDeviceDto request,
            HttpContext context,
            DevicePkiService devices,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                await RedeemStepUpAsync(context, stepUp, actor, "Enrolling a device", cancellationToken)
                    .ConfigureAwait(false);

                var change = await devices.EnrolAsync(
                    deviceId,
                    request.Certificate,
                    new DeviceCapabilityManifest(
                        request.SchemaVersion,
                        request.DeviceType,
                        request.FirmwareVersion,
                        request.ConfigurationRevision,
                        [.. (request.TelemetryChannels ?? []).Select(item => new DeviceChannel(item.ChannelId, item.Unit))],
                        request.SupportedCommands ?? [],
                        request.SecurityProfile),
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Created($"/api/v1/devices/{deviceId}", new
                {
                    device = Device(change.Device),
                    // What this platform derived from the certificate, so an administrator
                    // can compare it against the certificate the device actually holds.
                    certificate = new
                    {
                        change.Proof!.Thumbprint,
                        change.Proof.Subject,
                        change.Proof.Issuer,
                        change.Proof.SerialNumber,
                        change.Proof.KeyAlgorithm,
                        change.Proof.KeySizeBits,
                        change.Proof.NotBefore,
                        change.Proof.NotAfter,
                        change.Proof.SelfSigned,
                        thumbprintSource = "Computed by Control Core from the certificate bytes, not supplied by the caller.",
                    },
                    alarm = AlarmSummary(change.Alarm),
                    // Stated because it is the whole shape of the operation: this platform
                    // is a trust registry, not a certificate authority.
                    privateKey = "Never presented, never stored. The device key stays inside the device's hardware boundary.",
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });

        // Catalogue entry 16: Cybersecurity Administrator; step-up MFA,
        // certificate/topic revocation and alarm.
        group.MapPost("/devices/{deviceId}/revoke", async (
            string deviceId,
            RevokeDeviceDto request,
            HttpContext context,
            DevicePkiService devices,
            StepUpService stepUp,
            ActorContextFactory actorFactory,
            CancellationToken cancellationToken) =>
        {
            try
            {
                var actor = actorFactory.Create(context.User);
                await RedeemStepUpAsync(context, stepUp, actor, "Revoking device trust", cancellationToken)
                    .ConfigureAwait(false);

                var change = await devices.RevokeAsync(
                    deviceId,
                    request.Reason,
                    actor,
                    CorrelationMiddleware.Get(context),
                    cancellationToken).ConfigureAwait(false);

                return Results.Ok(new
                {
                    device = Device(change.Device),
                    alarm = AlarmSummary(change.Alarm),
                    effect = new
                    {
                        // Real, and provable: the next reading this device offers is
                        // refused, because trust is read from the stored record each time.
                        platformTrustWithdrawn = true,
                        telemetryRefusedImmediately = true,
                        // Not done, and not claimed. CH1-COM-IF-0004 puts the topic ACL in
                        // the MQTT broker, which is not enabled at this checkpoint.
                        brokerTopicAclRevoked = false,
                        brokerTopicAclNote =
                            "The MQTT broker is not enabled, so the topic ACL is unchanged. Revoke it at the " +
                            "broker as well before returning the conduit to service.",
                    },
                });
            }
            catch (DomainRuleException error)
            {
                return EndpointResults.FromDomainError(context, error);
            }
        });
    }

    /// <summary>
    /// CH1-CYB-ACP-0001 lists device trust among the actions requiring step-up, and
    /// access.json asks for hardware-backed MFA specifically — the same wording it uses
    /// for managing users, and read the same way here.
    /// </summary>
    /// <requirements>CH1-IAM-FR-0004, CH1-CYB-ACP-0001</requirements>
    private static async Task RedeemStepUpAsync(
        HttpContext context,
        StepUpService stepUp,
        ActorContext actor,
        string action,
        CancellationToken cancellationToken)
    {
        // Role before step-up. A caller who cannot perform the action at all is told
        // that, rather than being told to obtain a step-up they could not use — and a
        // single-use grant is not consumed on a request that was always going to fail.
        // The service checks the same rule again; this only decides what to spend.
        Guard.Against(
            !DevicePkiService.CanAdministerDeviceTrust(actor),
            "AUTH_DEVICE_TRUST",
            $"{action} requires the Cybersecurity Administrator role.");

        var header = context.Request.Headers["X-CH1-Step-Up"].FirstOrDefault();
        if (!Guid.TryParse(header, out var grantId))
        {
            throw new DomainRuleException(
                "STEP_UP_REQUIRED",
                $"{action} requires a step-up grant in X-CH1-Step-Up.");
        }

        await stepUp.RedeemAsync(
            grantId,
            StepUpPurpose.DeviceTrust,
            AuthenticationStrength.StepUpPhishingResistant,
            actor,
            cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// The device projection. Carries the certificate fingerprint, which is public, and
    /// no key material, enrolment secret or credential.
    /// </summary>
    private static object Device(DeviceRecord device) => new
    {
        device.DeviceId,
        device.CellId,
        device.DeviceType,
        device.FirmwareVersion,
        device.ConfigurationRevision,
        device.CertificateThumbprint,
        device.TrustState,
        trusted = device.IsTrusted,
        device.LastSeenAt,
        device.RevokedAt,
        device.RevocationReason,
        device.RevokedBy,
        device.Version,
        capabilityManifest = device.CapabilityManifest,
    };

    private static object? AlarmSummary(Alarm? alarm) => alarm is null
        ? null
        : new
        {
            alarm.AlarmId,
            alarm.AlarmCode,
            alarm.Priority,
            state = alarm.State.ToString(),
            guidance = SecurityAlarms.GuidanceFor(alarm.AlarmCode),
        };
}
