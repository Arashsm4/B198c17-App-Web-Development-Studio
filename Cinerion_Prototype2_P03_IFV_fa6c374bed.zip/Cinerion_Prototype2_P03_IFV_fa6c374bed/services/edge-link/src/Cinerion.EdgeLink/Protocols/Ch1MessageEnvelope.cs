// The CH1 envelope in CBOR, gateway side. It must match the firmware byte for byte, and a test
// checks that.

using System.Formats.Cbor;
using System.Globalization;
using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// The CH1 message envelope as it travels over MQTT, encoded in CBOR.
/// </summary>
/// <remarks>
/// <para>
/// CH1-COM-ICD-0001 states what every controlled message carries: schema version, message
/// type, message id, correlation id, source and destination identities, project/cell/asset
/// scope, timestamp, time quality, sequence, expiry where relevant, payload and integrity
/// context. Commands additionally carry expected state, configuration revision and an
/// idempotency key; telemetry carries engineering unit, quality and source sample time.
/// Every one of those is a field here, and a message missing a mandatory one is refused
/// rather than defaulted — the ICD's rule is that unknown optional fields are ignored
/// safely while unknown mandatory semantics fail closed.
/// </para>
/// <para>
/// CBOR because CH1-COM-IF-0005 names it on the broker-to-ESP32-S3 edge, and the same
/// bytes cross CH1-COM-IF-0004 unchanged: a broker is a transport, not a translator, so
/// inventing a second representation for the EdgeLink side would create two encodings of
/// one contract and a place for them to disagree.
/// </para>
/// <para>
/// Encoding is <see cref="CborConformanceMode.Canonical"/>: definite lengths and map keys
/// in a defined order, so the same envelope always produces the same bytes. That matters
/// twice over — an embedded decoder can rely on the ordering, and the firmware's own
/// encoder can be checked against these bytes rather than against a paraphrase of them.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-ICD-0001, CH1-COM-IF-0004, CH1-COM-IF-0005, CH1-COM-FR-0001</requirements>
public static class Ch1MessageEnvelope
{
    public const string SchemaVersion = "1.0.0";

    /// <summary>Message types. Deliberately a closed set; an unknown type is refused.</summary>
    public static class Types
    {
        public const string Command = "command";
        public const string Telemetry = "telemetry";
        public const string Acknowledgement = "acknowledgement";
        public const string Heartbeat = "heartbeat";
        public const string Capability = "capability";
    }

    /// <summary>
    /// A decoded envelope. The payload is left as a raw CBOR slice so the header can be
    /// validated — identity, scope, expiry, sequence — before anything interprets what is
    /// inside it. The ICD makes the receiver responsible for schema, authority, state and
    /// bounds, and that order is what stops a malformed payload from being parsed by a
    /// message that had no business being accepted.
    /// </summary>
    public sealed record Decoded(
        string Schema,
        string Type,
        Guid MessageId,
        Guid CorrelationId,
        string Source,
        string Destination,
        Guid ProjectId,
        Guid CellId,
        Guid AssetId,
        DateTimeOffset SentAt,
        string TimeQuality,
        long Sequence,
        DateTimeOffset? ExpiresAt,
        IReadOnlyDictionary<string, object?> Payload);

    // ------------------------------------------------------------------ encoding

    public static byte[] EncodeCommand(SemanticCommandEnvelope command, string source, string destination)
    {
        ArgumentNullException.ThrowIfNull(command);
        var writer = new CborWriter(CborConformanceMode.Canonical, convertIndefiniteLengthEncodings: true);
        writer.WriteStartMap(14);

        WriteHeader(
            writer,
            Types.Command,
            command.MessageId,
            command.CorrelationId,
            source,
            destination,
            command.ProjectId,
            command.CellId,
            command.AssetId,
            DateTimeOffset.UtcNow,
            "Synchronised",
            command.Sequence);

        writer.WriteTextString("expiresAt");
        writer.WriteInt64(command.ExpiresAt.ToUnixTimeMilliseconds());

        writer.WriteTextString("payload");
        writer.WriteStartMap(5);
        writer.WriteTextString("commandType");
        writer.WriteTextString(command.CommandType);
        writer.WriteTextString("configurationRevision");
        writer.WriteTextString(command.ConfigurationRevision);
        writer.WriteTextString("expectedStateHash");
        writer.WriteTextString(command.ExpectedStateHash);
        // CH1-COM-ICD-0001 requires commands to carry an idempotency key. The command
        // identifier is that key: one prepared command is one intent, and a repeat of the
        // same identifier must be recognised as the same intent rather than a second one.
        writer.WriteTextString("idempotencyKey");
        writer.WriteByteString(command.CommandId.ToByteArray());
        writer.WriteTextString("parameters");
        WriteParameters(writer, command.Parameters);
        writer.WriteEndMap();

        writer.WriteEndMap();
        return writer.Encode();
    }

    /// <remarks>
    /// <paramref name="messageId"/> and <paramref name="sentAt"/> are parameters rather
    /// than values this method invents, so a given envelope always produces the same
    /// bytes. That is what makes the encoding checkable at all: the firmware in
    /// <c>firmware/shared/src/ch1_envelope.cpp</c> is an independent implementation of the
    /// same controlled format, and the only way to know the two agree is for both to
    /// produce one literal that a test on each side asserts.
    /// </remarks>
    public static byte[] EncodeTelemetry(
        TelemetryPoint point,
        string source,
        string destination,
        Guid projectId,
        Guid cellId,
        Guid assetId,
        Guid correlationId,
        Guid messageId,
        DateTimeOffset sentAt)
    {
        ArgumentNullException.ThrowIfNull(point);
        var writer = new CborWriter(CborConformanceMode.Canonical, convertIndefiniteLengthEncodings: true);
        writer.WriteStartMap(13);

        WriteHeader(
            writer,
            Types.Telemetry,
            messageId,
            correlationId,
            source,
            destination,
            projectId,
            cellId,
            assetId,
            sentAt,
            "Synchronised",
            point.Sequence);

        writer.WriteTextString("payload");
        writer.WriteStartMap(5);
        writer.WriteTextString("channelId");
        writer.WriteTextString(point.ChannelId);
        writer.WriteTextString("quality");
        writer.WriteTextString(point.Quality);
        // The source sample time, not the send time. Store-and-forward makes the two
        // differ, and a reader that could not tell them apart would age a buffered
        // reading from the moment it happened to arrive.
        writer.WriteTextString("sampledAt");
        writer.WriteInt64(point.SampledAt.ToUnixTimeMilliseconds());
        writer.WriteTextString("unit");
        writer.WriteTextString(point.Unit);
        writer.WriteTextString("value");
        writer.WriteDouble(point.Value);
        writer.WriteEndMap();

        writer.WriteEndMap();
        return writer.Encode();
    }

    public static byte[] EncodeAcknowledgement(
        AdapterAcknowledgement acknowledgement,
        Guid correlationId,
        string source,
        string destination,
        Guid projectId,
        Guid cellId,
        Guid assetId,
        long sequence)
    {
        ArgumentNullException.ThrowIfNull(acknowledgement);
        var writer = new CborWriter(CborConformanceMode.Canonical, convertIndefiniteLengthEncodings: true);
        writer.WriteStartMap(13);

        WriteHeader(
            writer,
            Types.Acknowledgement,
            Guid.NewGuid(),
            correlationId,
            source,
            destination,
            projectId,
            cellId,
            assetId,
            acknowledgement.ObservedAt,
            "Synchronised",
            sequence);

        writer.WriteTextString("payload");
        writer.WriteStartMap(5);
        writer.WriteTextString("accepted");
        writer.WriteBoolean(acknowledgement.Accepted);
        writer.WriteTextString("adapterId");
        writer.WriteTextString(acknowledgement.AdapterId);
        writer.WriteTextString("commandId");
        writer.WriteByteString(acknowledgement.CommandId.ToByteArray());
        writer.WriteTextString("controllerState");
        writer.WriteTextString(acknowledgement.ControllerState);
        writer.WriteTextString("reasonCode");
        writer.WriteTextString(acknowledgement.ReasonCode);
        writer.WriteEndMap();

        writer.WriteEndMap();
        return writer.Encode();
    }

    private static void WriteHeader(
        CborWriter writer,
        string type,
        Guid messageId,
        Guid correlationId,
        string source,
        string destination,
        Guid projectId,
        Guid cellId,
        Guid assetId,
        DateTimeOffset sentAt,
        string timeQuality,
        long sequence)
    {
        writer.WriteTextString("assetId");
        writer.WriteByteString(assetId.ToByteArray());
        writer.WriteTextString("cellId");
        writer.WriteByteString(cellId.ToByteArray());
        writer.WriteTextString("correlationId");
        writer.WriteByteString(correlationId.ToByteArray());
        writer.WriteTextString("destination");
        writer.WriteTextString(destination);
        writer.WriteTextString("messageId");
        writer.WriteByteString(messageId.ToByteArray());
        writer.WriteTextString("projectId");
        writer.WriteByteString(projectId.ToByteArray());
        writer.WriteTextString("schema");
        writer.WriteTextString(SchemaVersion);
        writer.WriteTextString("sentAt");
        writer.WriteInt64(sentAt.ToUnixTimeMilliseconds());
        writer.WriteTextString("sequence");
        writer.WriteInt64(sequence);
        writer.WriteTextString("source");
        writer.WriteTextString(source);
        // Observable rather than assumed. CH1-COM-ICD-0001 requires clock offset and time
        // quality to be visible so audit and TOTP decisions are not silently made on
        // invalid time.
        writer.WriteTextString("timeQuality");
        writer.WriteTextString(timeQuality);
        writer.WriteTextString("type");
        writer.WriteTextString(type);
    }

    private static void WriteParameters(CborWriter writer, IReadOnlyDictionary<string, object> parameters)
    {
        var ordered = parameters
            .OrderBy(pair => pair.Key.Length)
            .ThenBy(pair => pair.Key, StringComparer.Ordinal)
            .ToArray();
        writer.WriteStartMap(ordered.Length);
        foreach (var (key, value) in ordered)
        {
            writer.WriteTextString(key);
            switch (value)
            {
                case bool flag: writer.WriteBoolean(flag); break;
                case long number: writer.WriteInt64(number); break;
                case int number: writer.WriteInt64(number); break;
                case double number: writer.WriteDouble(number); break;
                case string text: writer.WriteTextString(text); break;
                // A parameter this envelope has no encoding for is written as its
                // invariant text rather than dropped: a command that silently lost a
                // parameter would be a different command.
                default: writer.WriteTextString(Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty); break;
            }
        }

        writer.WriteEndMap();
    }

    // ------------------------------------------------------------------ decoding

    /// <summary>
    /// Decodes and validates the header. Throws <see cref="Ch1EnvelopeException"/> with a
    /// stable code for anything malformed, which the adapter turns into a refusal rather
    /// than a crash — the ICD asks for stable codes and actionable detail without leaking
    /// secrets.
    /// </summary>
    public static Decoded Decode(ReadOnlyMemory<byte> bytes)
    {
        CborReader reader;
        try
        {
            reader = new CborReader(bytes, CborConformanceMode.Canonical);
        }
        catch (Exception error)
        {
            throw new Ch1EnvelopeException("ENVELOPE_NOT_CBOR", error.Message);
        }

        var fields = new Dictionary<string, object?>(StringComparer.Ordinal);
        Dictionary<string, object?> payload = new(StringComparer.Ordinal);

        try
        {
            var count = reader.ReadStartMap();
            if (count is null)
            {
                throw new Ch1EnvelopeException("ENVELOPE_INDEFINITE_LENGTH", "A controlled envelope is definite-length.");
            }

            for (var index = 0; index < count; index++)
            {
                var key = reader.ReadTextString();
                if (key == "payload")
                {
                    payload = ReadMap(reader);
                }
                else
                {
                    fields[key] = ReadValue(reader);
                }
            }

            reader.ReadEndMap();
        }
        catch (Ch1EnvelopeException)
        {
            throw;
        }
        catch (Exception error)
        {
            throw new Ch1EnvelopeException("ENVELOPE_MALFORMED", error.Message);
        }

        // Mandatory semantics fail closed. Every one of these is named by the ICD, so a
        // message without it is not a message this platform can act on.
        var schema = Text(fields, "schema");
        if (schema != SchemaVersion)
        {
            throw new Ch1EnvelopeException(
                "ENVELOPE_SCHEMA_UNSUPPORTED",
                $"schema '{schema}' is not the supported major version {SchemaVersion}");
        }

        var type = Text(fields, "type");
        if (type is not (Types.Command or Types.Telemetry or Types.Acknowledgement or Types.Heartbeat or Types.Capability))
        {
            throw new Ch1EnvelopeException("ENVELOPE_TYPE_UNKNOWN", $"message type '{type}'");
        }

        return new Decoded(
            schema,
            type,
            Uuid(fields, "messageId"),
            Uuid(fields, "correlationId"),
            Text(fields, "source"),
            Text(fields, "destination"),
            Uuid(fields, "projectId"),
            Uuid(fields, "cellId"),
            Uuid(fields, "assetId"),
            Instant(fields, "sentAt"),
            Text(fields, "timeQuality"),
            Number(fields, "sequence"),
            fields.TryGetValue("expiresAt", out var expiry) && expiry is long milliseconds
                ? DateTimeOffset.FromUnixTimeMilliseconds(milliseconds)
                : null,
            payload);
    }

    private static Dictionary<string, object?> ReadMap(CborReader reader)
    {
        var map = new Dictionary<string, object?>(StringComparer.Ordinal);
        var count = reader.ReadStartMap()
            ?? throw new Ch1EnvelopeException("ENVELOPE_INDEFINITE_LENGTH", "A controlled payload is definite-length.");
        for (var index = 0; index < count; index++)
        {
            map[reader.ReadTextString()] = ReadValue(reader);
        }

        reader.ReadEndMap();
        return map;
    }

    private static object? ReadValue(CborReader reader) => reader.PeekState() switch
    {
        CborReaderState.UnsignedInteger or CborReaderState.NegativeInteger => reader.ReadInt64(),
        CborReaderState.TextString => reader.ReadTextString(),
        CborReaderState.ByteString => reader.ReadByteString(),
        CborReaderState.DoublePrecisionFloat or CborReaderState.SinglePrecisionFloat
            or CborReaderState.HalfPrecisionFloat => reader.ReadDouble(),
        CborReaderState.Boolean => reader.ReadBoolean(),
        CborReaderState.Null => ReadNull(reader),
        CborReaderState.StartMap => ReadMap(reader),
        CborReaderState.StartArray => ReadArray(reader),
        var state => throw new Ch1EnvelopeException("ENVELOPE_VALUE_UNSUPPORTED", state.ToString()),
    };

    private static object? ReadNull(CborReader reader)
    {
        reader.ReadNull();
        return null;
    }

    private static List<object?> ReadArray(CborReader reader)
    {
        var count = reader.ReadStartArray()
            ?? throw new Ch1EnvelopeException("ENVELOPE_INDEFINITE_LENGTH", "A controlled array is definite-length.");
        var items = new List<object?>(count);
        for (var index = 0; index < count; index++)
        {
            items.Add(ReadValue(reader));
        }

        reader.ReadEndArray();
        return items;
    }

    private static string Text(Dictionary<string, object?> fields, string key) =>
        fields.TryGetValue(key, out var value) && value is string text && text.Length > 0
            ? text
            : throw new Ch1EnvelopeException("ENVELOPE_FIELD_MISSING", key);

    private static long Number(Dictionary<string, object?> fields, string key) =>
        fields.TryGetValue(key, out var value) && value is long number
            ? number
            : throw new Ch1EnvelopeException("ENVELOPE_FIELD_MISSING", key);

    private static DateTimeOffset Instant(Dictionary<string, object?> fields, string key) =>
        DateTimeOffset.FromUnixTimeMilliseconds(Number(fields, key));

    private static Guid Uuid(Dictionary<string, object?> fields, string key) =>
        fields.TryGetValue(key, out var value) && value is byte[] { Length: 16 } bytes
            ? new Guid(bytes)
            : throw new Ch1EnvelopeException("ENVELOPE_FIELD_MISSING", key);

    /// <summary>Reads one payload field, or throws with the same stable code shape.</summary>
    public static string PayloadText(IReadOnlyDictionary<string, object?> payload, string key) =>
        payload.TryGetValue(key, out var value) && value is string text
            ? text
            : throw new Ch1EnvelopeException("PAYLOAD_FIELD_MISSING", key);

    public static double PayloadNumber(IReadOnlyDictionary<string, object?> payload, string key) =>
        payload.TryGetValue(key, out var value)
            ? value switch
            {
                double number => number,
                long number => number,
                _ => throw new Ch1EnvelopeException("PAYLOAD_FIELD_MISSING", key),
            }
            : throw new Ch1EnvelopeException("PAYLOAD_FIELD_MISSING", key);

    public static bool PayloadFlag(IReadOnlyDictionary<string, object?> payload, string key) =>
        payload.TryGetValue(key, out var value) && value is bool flag
            ? flag
            : throw new Ch1EnvelopeException("PAYLOAD_FIELD_MISSING", key);

    public static Guid PayloadUuid(IReadOnlyDictionary<string, object?> payload, string key) =>
        payload.TryGetValue(key, out var value) && value is byte[] { Length: 16 } bytes
            ? new Guid(bytes)
            : throw new Ch1EnvelopeException("PAYLOAD_FIELD_MISSING", key);
}

/// <summary>A refusal with a stable code, as CH1-COM-ICD-0001 requires of every error.</summary>
public sealed class Ch1EnvelopeException(string code, string detail)
    : Exception($"{code}: {detail}")
{
    public string Code { get; } = code;

    public string Detail { get; } = detail;
}
