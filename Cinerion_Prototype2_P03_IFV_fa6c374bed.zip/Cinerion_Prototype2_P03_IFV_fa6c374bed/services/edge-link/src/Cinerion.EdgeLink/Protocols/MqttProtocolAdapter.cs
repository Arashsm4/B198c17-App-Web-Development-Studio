// The MQTT 5 adapter: subscribes to device topics over TLS and passes the envelopes along.

using System.Collections.Concurrent;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;
using Cinerion.EdgeLink.Contracts;
using MQTTnet;
using MQTTnet.Formatter;
using MQTTnet.Protocol;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// Where the CH1 MQTT topics live. The broker's ACL is written against exactly this
/// shape, so the two are one statement rather than two that must be kept in step.
/// </summary>
public static class Ch1MqttTopics
{
    public const string Root = "ch1/v1/devices";

    public static string Commands(string deviceId) => $"{Root}/{deviceId}/commands";

    public static string Command(string deviceId, Guid commandId) => $"{Commands(deviceId)}/{commandId:N}";

    public static string Telemetry(string deviceId) => $"{Root}/{deviceId}/telemetry";

    public static string Acknowledgements(string deviceId) => $"{Root}/{deviceId}/acks";

    public static string Heartbeat(string deviceId) => $"{Root}/{deviceId}/heartbeat";

    public static string Capability(string deviceId) => $"{Root}/{deviceId}/capability";
}

/// <summary>
/// Everything the MQTT edge needs, and nothing it can run without.
/// </summary>
/// <remarks>
/// There is no default host, no default certificate and no anonymous fallback. An
/// unconfigured MQTT edge does not become a working one with weaker security; it stays
/// gated, which is the same fail-closed direction the identity directory and the storage
/// mode already take.
/// </remarks>
public sealed record MqttAdapterOptions(
    string Host,
    int Port,
    string ClientId,
    string DeviceId,
    string CertificateAuthorityPath,
    string ClientCertificatePath,
    string ClientPrivateKeyPath,
    Guid ProjectId,
    Guid CellId,
    Guid AssetId,
    TimeSpan AcknowledgementTimeout)
{
    public static MqttAdapterOptions? FromConfiguration(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var host = configuration["CINERION_MQTT_HOST"];
        var clientCertificate = configuration["CINERION_MQTT_CLIENT_CERT"];
        var clientKey = configuration["CINERION_MQTT_CLIENT_KEY"];
        var authority = configuration["CINERION_MQTT_CA_CERT"];

        // All four or none. A partially configured TLS edge is the one case where a
        // helpful default would silently drop mutual authentication.
        if (string.IsNullOrWhiteSpace(host)
            || string.IsNullOrWhiteSpace(clientCertificate)
            || string.IsNullOrWhiteSpace(clientKey)
            || string.IsNullOrWhiteSpace(authority))
        {
            return null;
        }

        return new MqttAdapterOptions(
            host,
            int.TryParse(configuration["CINERION_MQTT_PORT"], CultureInfo.InvariantCulture, out var port) ? port : 8883,
            configuration["CINERION_MQTT_CLIENT_ID"] ?? "ch1-edgelink",
            configuration["CINERION_MQTT_DEVICE_ID"] ?? "CH1-DEV-CELL-0001",
            authority,
            clientCertificate,
            clientKey,
            Guid.TryParse(configuration["CINERION_MQTT_PROJECT_ID"], out var project) ? project : Guid.Empty,
            Guid.TryParse(configuration["CINERION_MQTT_CELL_ID"], out var cell) ? cell : Guid.Empty,
            Guid.TryParse(configuration["CINERION_MQTT_ASSET_ID"], out var asset) ? asset : Guid.Empty,
            TimeSpan.FromSeconds(
                int.TryParse(configuration["CINERION_MQTT_ACK_TIMEOUT_SECONDS"], CultureInfo.InvariantCulture, out var seconds)
                    ? seconds
                    : 10));
    }
}

/// <summary>
/// The live MQTT 5 adapter — CH1-COM-IF-0004 on the EdgeLink side, and the other end of
/// CH1-COM-IF-0005 where an ESP32-S3 speaks the same envelope.
/// </summary>
/// <remarks>
/// <para>
/// This is EdgeLink's second <em>operational</em> adapter. Until now the protocol
/// boundary had one implementation behind it and three that refused, which shows that
/// the interface was shaped around the one thing implementing it. It is held to exactly
/// the same <see cref="AdapterConformance"/> suite as the simulator, run by the same
/// code, with the domain unchanged between them.
/// </para>
/// <para>
/// Three things it deliberately does not do. It does not invent a capability manifest:
/// the manifest comes from the device's own retained <c>capability</c> topic, and an
/// adapter that had never heard from its device refuses rather than describing one. It
/// does not treat a published command as an accepted one: <see cref="PrepareAsync"/>
/// waits for the controller's acknowledgement and reports a timeout as a refusal, because
/// "the broker took the message" is not "the controller accepted the intent". And it never
/// replays: a command that expired or whose sequence has been spent is refused locally,
/// before it reaches the wire, which is the gateway obligation CH1-COM-FR-0010 states.
/// </para>
/// <para>
/// Security is not negotiable here. TLS 1.3, the broker validated against the controlled
/// CA, and a client certificate whose subject is the identity the broker's topic ACL is
/// written against. There is no anonymous path and no "encryption optional" switch.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0002, CH1-COM-FR-0006, CH1-COM-FR-0008, CH1-COM-FR-0010, CH1-COM-IF-0004, CH1-COM-IF-0005, CH1-CYB-CSRS-0001</requirements>
public sealed partial class MqttProtocolAdapter : IProtocolAdapter, IAsyncDisposable
{
    private readonly MqttAdapterOptions _options;
    private readonly ILogger<MqttProtocolAdapter> _logger;
    private readonly TimeProvider _timeProvider;
    private readonly IMqttClient _client;
    private readonly SemaphoreSlim _connectionGate = new(1, 1);
    private readonly ConcurrentDictionary<Guid, TaskCompletionSource<AdapterAcknowledgement>> _pending = new();
    private readonly Channel<TelemetryPoint> _telemetry =
        Channel.CreateBounded<TelemetryPoint>(new BoundedChannelOptions(1024)
        {
            // Telemetry may be stored and forwarded, and a full queue must have a stated
            // overflow behaviour rather than an accidental one. The oldest reading is the
            // one dropped: a stale value is worth less than the newest one.
            FullMode = BoundedChannelFullMode.DropOldest,
        });

    private DeviceCapabilityManifest? _manifest;
    private long _lastSequence;

    public MqttProtocolAdapter(
        MqttAdapterOptions options,
        ILogger<MqttProtocolAdapter> logger,
        TimeProvider? timeProvider = null)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _timeProvider = timeProvider ?? TimeProvider.System;
        _client = new MqttClientFactory().CreateMqttClient();
        _client.ApplicationMessageReceivedAsync += OnMessageAsync;
    }

    public string AdapterId => "CH1-ADP-MQTT-0001";

    public string Protocol => "MQTT5";

    // ------------------------------------------------------------------ connection

    private async ValueTask ConnectAsync(CancellationToken cancellationToken)
    {
        if (_client.IsConnected)
        {
            return;
        }

        await _connectionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (_client.IsConnected)
            {
                return;
            }

            using var authority = X509CertificateLoader.LoadCertificateFromFile(_options.CertificateAuthorityPath);
            var identity = X509Certificate2.CreateFromPemFile(
                _options.ClientCertificatePath, _options.ClientPrivateKeyPath);
            // Windows requires the key to be persisted through an export/import round
            // trip before the handshake can use it. Ephemeral, in memory, never written.
            var usable = X509CertificateLoader.LoadPkcs12(identity.Export(X509ContentType.Pkcs12), null);
            identity.Dispose();

            var options = new MqttClientOptionsBuilder()
                .WithTcpServer(_options.Host, _options.Port)
                .WithProtocolVersion(MqttProtocolVersion.V500)
                .WithClientId(_options.ClientId)
                .WithCleanSession()
                .WithTlsOptions(tls => tls
                    .UseTls()
                    .WithSslProtocols(System.Security.Authentication.SslProtocols.Tls13)
                    .WithClientCertificates([usable])
                    // The broker is checked against the controlled CA rather than the
                    // machine trust store, and a certificate that does not chain to it is
                    // refused. No callback here returns true unconditionally: that is the
                    // single line that turns mutual TLS into decoration.
                    .WithTrustChain([authority])
                    .WithAllowUntrustedCertificates(false)
                    .WithIgnoreCertificateChainErrors(false)
                    .WithIgnoreCertificateRevocationErrors(false))
                .Build();

            await _client.ConnectAsync(options, cancellationToken).ConfigureAwait(false);

            // The device's own paths. EdgeLink never subscribes to its own command topic:
            // it is the publisher there, and a gateway that read back its own commands
            // could mistake one for a controller's.
            await _client.SubscribeAsync(
                new MqttClientSubscribeOptionsBuilder()
                    .WithTopicFilter($"{Ch1MqttTopics.Telemetry(_options.DeviceId)}/#", MqttQualityOfServiceLevel.AtLeastOnce)
                    .WithTopicFilter($"{Ch1MqttTopics.Acknowledgements(_options.DeviceId)}/#", MqttQualityOfServiceLevel.AtLeastOnce)
                    .WithTopicFilter(Ch1MqttTopics.Heartbeat(_options.DeviceId), MqttQualityOfServiceLevel.AtLeastOnce)
                    .WithTopicFilter(Ch1MqttTopics.Capability(_options.DeviceId), MqttQualityOfServiceLevel.AtLeastOnce)
                    .Build(),
                cancellationToken).ConfigureAwait(false);

            LogConnected(_logger, _options.Host, _options.Port, _options.ClientId);
        }
        finally
        {
            _connectionGate.Release();
        }
    }

    private async Task OnMessageAsync(MqttApplicationMessageReceivedEventArgs args)
    {
        var topic = args.ApplicationMessage.Topic;
        Ch1MessageEnvelope.Decoded envelope;
        try
        {
            envelope = Ch1MessageEnvelope.Decode(
                System.Buffers.BuffersExtensions.ToArray(args.ApplicationMessage.Payload));
        }
        catch (Ch1EnvelopeException error)
        {
            // Refused, not repaired and not guessed at. A malformed message from a
            // device is a fault to report, and the topic it arrived on says who sent it.
            LogRefused(_logger, topic, error.Code);
            return;
        }

        // The scope is checked before the payload is interpreted. A device publishing
        // under another project's identifiers is not a device this gateway serves,
        // whatever the broker let through.
        if (envelope.ProjectId != _options.ProjectId || envelope.CellId != _options.CellId)
        {
            LogOutOfScope(_logger, envelope.Type, topic, envelope.ProjectId, envelope.CellId);
            return;
        }

        switch (envelope.Type)
        {
            case Ch1MessageEnvelope.Types.Capability:
                _manifest = ReadManifest(envelope);
                break;

            case Ch1MessageEnvelope.Types.Telemetry:
                _telemetry.Writer.TryWrite(new TelemetryPoint(
                    _options.DeviceId,
                    Ch1MessageEnvelope.PayloadText(envelope.Payload, "channelId"),
                    Ch1MessageEnvelope.PayloadNumber(envelope.Payload, "value"),
                    Ch1MessageEnvelope.PayloadText(envelope.Payload, "unit"),
                    Ch1MessageEnvelope.PayloadText(envelope.Payload, "quality"),
                    DateTimeOffset.FromUnixTimeMilliseconds(
                        (long)Ch1MessageEnvelope.PayloadNumber(envelope.Payload, "sampledAt")),
                    envelope.Sequence,
                    // The device's own declaration about the clock that stamped
                    // `sampledAt`. It was decoded here and discarded before this: the
                    // gateway then stamped every forwarded publication `Qualified`, so a
                    // controller reporting an undisciplined clock arrived looking
                    // disciplined. Defect 59, conflict 27.
                    envelope.TimeQuality));
                break;

            case Ch1MessageEnvelope.Types.Acknowledgement:
                var commandId = Ch1MessageEnvelope.PayloadUuid(envelope.Payload, "commandId");
                if (_pending.TryRemove(commandId, out var waiter))
                {
                    waiter.TrySetResult(new AdapterAcknowledgement(
                        commandId,
                        Ch1MessageEnvelope.PayloadFlag(envelope.Payload, "accepted"),
                        Ch1MessageEnvelope.PayloadText(envelope.Payload, "controllerState"),
                        Ch1MessageEnvelope.PayloadText(envelope.Payload, "reasonCode"),
                        envelope.SentAt,
                        AdapterId,
                        envelope.TimeQuality));
                }

                break;

            case Ch1MessageEnvelope.Types.Heartbeat:
            {
                // CH1-COM-ICD-0001 requires a heartbeat to carry firmware and
                // configuration revision, so both are read before anything is reported.
                // A heartbeat without them is a malformed message, not a quiet one: a
                // controller running something other than the released baseline must be
                // visible without anybody having to ask it.
                var firmware = Ch1MessageEnvelope.PayloadText(envelope.Payload, "firmwareVersion");
                var configuration = Ch1MessageEnvelope.PayloadText(envelope.Payload, "configurationRevision");
                LogHeartbeat(_logger, _options.DeviceId, firmware, configuration);
                break;
            }

            default:
                LogIgnored(_logger, envelope.Type, topic);
                break;
        }

        await Task.CompletedTask.ConfigureAwait(false);
    }

    private static DeviceCapabilityManifest ReadManifest(Ch1MessageEnvelope.Decoded envelope)
    {
        var payload = envelope.Payload;
        var channels = payload.TryGetValue("telemetryChannels", out var raw) && raw is List<object?> declared
            ? declared.OfType<IReadOnlyDictionary<string, object?>>()
                .Select(item => new CapabilityChannel(
                    Ch1MessageEnvelope.PayloadText(item, "channelId"),
                    Ch1MessageEnvelope.PayloadText(item, "unit")))
                .ToArray()
            : [];

        var commands = payload.TryGetValue("supportedCommands", out var rawCommands) && rawCommands is List<object?> list
            ? list.OfType<string>().ToArray()
            : [];

        return new DeviceCapabilityManifest(
            envelope.Schema,
            Ch1MessageEnvelope.PayloadText(payload, "deviceId"),
            Ch1MessageEnvelope.PayloadText(payload, "deviceType"),
            Ch1MessageEnvelope.PayloadText(payload, "firmwareVersion"),
            Ch1MessageEnvelope.PayloadText(payload, "configurationRevision"),
            commands,
            channels,
            [new ProtocolEndpoint("MQTT5", Ch1MessageEnvelope.SchemaVersion)],
            Ch1MessageEnvelope.PayloadText(payload, "securityProfile"));
    }

    // ------------------------------------------------------------------ contract

    /// <summary>
    /// The manifest the device published under its own certificate, never one composed
    /// here. An adapter that has not heard from its device refuses.
    /// </summary>
    public async ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);

        // The capability topic is retained, so a device that announced itself before this
        // gateway started is still heard. Waiting is bounded: an absent manifest is an
        // absent device, and describing one anyway would put an invented capability into
        // the trust registry.
        var deadline = _timeProvider.GetUtcNow() + _options.AcknowledgementTimeout;
        while (_manifest is null && _timeProvider.GetUtcNow() < deadline)
        {
            await Task.Delay(TimeSpan.FromMilliseconds(100), _timeProvider, cancellationToken).ConfigureAwait(false);
        }

        return _manifest ?? throw new InvalidOperationException(
            $"No capability manifest has been published on {Ch1MqttTopics.Capability(_options.DeviceId)}. " +
            "The device has not announced itself, and this adapter does not describe one it has not heard from.");
    }

    /// <summary>
    /// Publishes one semantic intent and reports what the controller answered.
    /// </summary>
    public async ValueTask<AdapterAcknowledgement> PrepareAsync(
        SemanticCommandEnvelope command,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(command);

        // Local refusals first, before anything reaches the wire. CH1-COM-FR-0007 permits
        // store-and-forward for telemetry and forbids it for commands, and CH1-COM-FR-0010
        // makes duplicate suppression the gateway's obligation rather than a hope about
        // the network.
        if (command.ExpiresAt <= _timeProvider.GetUtcNow())
        {
            return Reject(command, "COMMAND_EXPIRED");
        }

        if (command.Sequence <= Interlocked.Read(ref _lastSequence))
        {
            return Reject(command, "SEQUENCE_REPLAY_OR_DUPLICATE");
        }

        if (!command.CommandType.All(character =>
                char.IsAsciiLetterUpper(character) || char.IsAsciiDigit(character) || character == '_'))
        {
            return Reject(command, "SEMANTIC_COMMAND_INVALID");
        }

        await ConnectAsync(cancellationToken).ConfigureAwait(false);

        var waiter = new TaskCompletionSource<AdapterAcknowledgement>(TaskCreationOptions.RunContinuationsAsynchronously);
        _pending[command.CommandId] = waiter;
        Interlocked.Exchange(ref _lastSequence, command.Sequence);

        try
        {
            await _client.PublishAsync(
                new MqttApplicationMessageBuilder()
                    .WithTopic(Ch1MqttTopics.Command(_options.DeviceId, command.CommandId))
                    .WithPayload(Ch1MessageEnvelope.EncodeCommand(command, _options.ClientId, _options.DeviceId))
                    .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
                    // Never retained. A retained command would be delivered again to any
                    // device that reconnected, which is the one thing a command must
                    // never do: CH1-COM-PRO-0001 cancels prepared commands across reboot.
                    .WithRetainFlag(false)
                    .WithMessageExpiryInterval(
                        (uint)Math.Max(1, (command.ExpiresAt - _timeProvider.GetUtcNow()).TotalSeconds))
                    .Build(),
                cancellationToken).ConfigureAwait(false);

            using var timeout = new CancellationTokenSource(_options.AcknowledgementTimeout);
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeout.Token);
            return await waiter.Task.WaitAsync(linked.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            // The broker accepted the packet and the controller did not answer. Reporting
            // acceptance here would have the domain believe a controller had taken the
            // intent when nothing is known about whether it did.
            return Reject(command, "CONTROLLER_ACKNOWLEDGEMENT_TIMEOUT");
        }
        finally
        {
            _pending.TryRemove(command.CommandId, out _);
        }
    }

    public async IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);
        await foreach (var point in _telemetry.Reader.ReadAllAsync(cancellationToken).ConfigureAwait(false))
        {
            yield return point;
        }
    }

    /// <summary>
    /// Re-establishes the link and restores nothing. The spent-sequence high-water mark
    /// survives on purpose: a reconnection that made a spent sequence acceptable again
    /// would arm equipment nobody asked to arm.
    /// </summary>
    public async ValueTask ReconcileAsync(CancellationToken cancellationToken)
    {
        foreach (var (_, waiter) in _pending)
        {
            waiter.TrySetException(new InvalidOperationException(
                "The link was reconciled while this command was outstanding; it is abandoned, not retried."));
        }

        _pending.Clear();

        if (_client.IsConnected)
        {
            await _client.DisconnectAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        await ConnectAsync(cancellationToken).ConfigureAwait(false);
    }

    // Source-generated per CH1-SWA-SDP-0001, as EdgeLinkWorker's are. Identity, topic and
    // stable codes only: no payload content and no certificate material ever reaches a
    // log line, because a diagnostic that leaked a controlled message would outlive the
    // message it described.
    [LoggerMessage(EventId = 2000, Level = LogLevel.Information,
        Message = "MQTT adapter connected to {Host}:{Port} as {ClientId} over TLS 1.3 with a client certificate.")]
    private static partial void LogConnected(ILogger logger, string host, int port, string clientId);

    [LoggerMessage(EventId = 2001, Level = LogLevel.Warning,
        Message = "Refused a message on {Topic}: {Code}")]
    private static partial void LogRefused(ILogger logger, string topic, string code);

    [LoggerMessage(EventId = 2002, Level = LogLevel.Warning,
        Message = "Refused a {Type} on {Topic}: it names project {Project} and cell {Cell}, which this gateway does not serve.")]
    private static partial void LogOutOfScope(ILogger logger, string type, string topic, Guid project, Guid cell);

    [LoggerMessage(EventId = 2003, Level = LogLevel.Information,
        Message = "Heartbeat from {Device}: firmware {Firmware}, configuration {Configuration}")]
    private static partial void LogHeartbeat(ILogger logger, string device, string firmware, string configuration);

    [LoggerMessage(EventId = 2004, Level = LogLevel.Warning,
        Message = "Ignored a {Type} on {Topic}: not a message a gateway receives.")]
    private static partial void LogIgnored(ILogger logger, string type, string topic);

    private AdapterAcknowledgement Reject(SemanticCommandEnvelope command, string reason) => new(
        command.CommandId,
        false,
        "Idle",
        reason,
        _timeProvider.GetUtcNow(),
        AdapterId);

    public async ValueTask DisposeAsync()
    {
        _telemetry.Writer.TryComplete();
        if (_client.IsConnected)
        {
            await _client.DisconnectAsync().ConfigureAwait(false);
        }

        _client.Dispose();
        _connectionGate.Dispose();
    }
}
