// The built-in simulator adapter, plus a loopback transport for tests.

using System.Runtime.CompilerServices;
using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Protocols;

public sealed class SimulatorProtocolAdapter(TimeProvider? timeProvider = null)
    : IProtocolAdapter, IControllerStateSource
{
    private readonly TimeProvider _timeProvider = timeProvider ?? TimeProvider.System;
    private long _lastSequence;

    /// <summary>
    /// Changes whenever this process starts, which is what a real controller's boot
    /// identity does. A command prepared before a restart can then never be committed
    /// after one, which is the CH1-CMD-FR-0009 obligation.
    /// </summary>
    private readonly Guid _bootId = Guid.NewGuid();

    public string AdapterId => "CH1-ADP-SIM-0001";

    public string Protocol => "SIMULATOR";

    /// <summary>
    /// The simulator is the only adapter here that can honestly answer the permissives,
    /// and it can because it <em>is</em> the controller — there is no wired input it is
    /// guessing at. Every value it reports is marked <c>Simulated</c>, all the way through
    /// to the cell's freshness on the operations view, so nothing downstream can mistake
    /// this for a live machine. The OPC UA and Modbus stand-ins are in the opposite
    /// position: they front a guard whose permissive check is declared deferred, so a
    /// gateway in front of them reports "not answered" and the cell stays not permissive.
    /// </summary>
    /// <requirements>CH1-COM-IF-0003, CH1-SAF-FR-0003, CH1-MON-FR-0003</requirements>
    public ValueTask<ControllerStateObservation> ReadControllerStateAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(new ControllerStateObservation(
            "CH1-DEV-CELL-0001",
            _bootId,
            "Idle",
            "CFG-REFAB-P01-R01",
            new ControllerPermissives(
                Reported: true,
                ControllerOnline: true,
                StartEnable: true,
                StopCircuitHealthy: true,
                GuardHealthy: true,
                ActuatorHome: true,
                ButtonPressed: false,
                FaultCauseActive: false,
                DeferredCheckCodes: []),
            "SIMULATION-NO-PHYSICAL-AUTHORITY",
            "0.1.0-prototype.1",
            "Simulated",
            _timeProvider.GetUtcNow()));
    }

    public ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.FromResult(new DeviceCapabilityManifest(
            "1.0.0",
            "CH1-DEV-CELL-0001",
            "Simulator",
            "0.1.0-prototype.1",
            "CFG-REFAB-P01-R01",
            ["RUN_TENSION_CALIBRATION", "RUN_DIMENSIONAL_TEST"],
            [
                new CapabilityChannel("temperature", "degC"),
                new CapabilityChannel("humidity", "%RH"),
                new CapabilityChannel("position", "mm"),
                new CapabilityChannel("vibration_rms", "m/s2"),
            ],
            [new ProtocolEndpoint("SIMULATOR", "1.0.0")],
            "SIMULATION-NO-PHYSICAL-AUTHORITY"));
    }

    /// <requirements>CH1-COM-FR-0006, CH1-COM-FR-0008, CH1-CMD-FR-0001</requirements>
    public ValueTask<AdapterAcknowledgement> PrepareAsync(
        SemanticCommandEnvelope command,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (command.ExpiresAt <= _timeProvider.GetUtcNow())
        {
            return ValueTask.FromResult(Reject(command, "COMMAND_EXPIRED"));
        }

        if (command.Sequence <= Interlocked.Read(ref _lastSequence))
        {
            return ValueTask.FromResult(Reject(command, "SEQUENCE_REPLAY_OR_DUPLICATE"));
        }

        if (!command.CommandType.All(character => char.IsAsciiLetterUpper(character) || char.IsAsciiDigit(character) || character == '_'))
        {
            return ValueTask.FromResult(Reject(command, "SEMANTIC_COMMAND_INVALID"));
        }

        Interlocked.Exchange(ref _lastSequence, command.Sequence);
        return ValueTask.FromResult(new AdapterAcknowledgement(
            command.CommandId,
            true,
            "AwaitingCredential",
            "PREPARE_ACCEPTED_SIMULATION_ONLY",
            _timeProvider.GetUtcNow(),
            AdapterId));
    }

    public async IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        long sequence = 0;
        while (!cancellationToken.IsCancellationRequested)
        {
            var now = _timeProvider.GetUtcNow();
            yield return new TelemetryPoint(
                "CH1-DEV-CELL-0001",
                "temperature",
                22.4 + Math.Sin(sequence / 30d) * 0.4,
                "degC",
                "Simulated",
                now,
                ++sequence,
                // There is no device and no device clock. `now` is this gateway's own.
                TelemetryPoint.GatewayStamped);
            await Task.Delay(TimeSpan.FromSeconds(1), _timeProvider, cancellationToken).ConfigureAwait(false);
        }
    }

    public ValueTask ReconcileAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Prepared commands are intentionally not restored or replayed.
        return ValueTask.CompletedTask;
    }

    private AdapterAcknowledgement Reject(SemanticCommandEnvelope command, string reason) => new(
        command.CommandId,
        false,
        "Idle",
        reason,
        _timeProvider.GetUtcNow(),
        AdapterId);
}

public sealed class LoopbackTransportProvider : ITransportProvider
{
    private readonly System.Threading.Channels.Channel<ReadOnlyMemory<byte>> _channel =
        System.Threading.Channels.Channel.CreateBounded<ReadOnlyMemory<byte>>(
            new System.Threading.Channels.BoundedChannelOptions(256)
            {
                FullMode = System.Threading.Channels.BoundedChannelFullMode.DropOldest,
                SingleReader = false,
                SingleWriter = false,
            });

    public string ProviderId => "CH1-TRN-LOOPBACK-0001";

    public ValueTask SendAsync(ReadOnlyMemory<byte> versionedEnvelope, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (!_channel.Writer.TryWrite(versionedEnvelope.ToArray()))
        {
            throw new InvalidOperationException("Loopback transport queue is unavailable.");
        }

        return ValueTask.CompletedTask;
    }

    public IAsyncEnumerable<ReadOnlyMemory<byte>> ReceiveAsync(CancellationToken cancellationToken) =>
        _channel.Reader.ReadAllAsync(cancellationToken);
}

