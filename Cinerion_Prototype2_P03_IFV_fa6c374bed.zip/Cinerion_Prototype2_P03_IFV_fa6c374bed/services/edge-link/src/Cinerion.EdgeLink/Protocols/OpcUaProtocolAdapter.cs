// The OPC UA adapter: browses the controller's information model and reads its state.

using System.Globalization;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;
using Cinerion.EdgeLink.Contracts;
using Microsoft.Extensions.Logging;
using Opc.Ua;
using Opc.Ua.Client;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// Routes the OPC UA stack's own diagnostics into EdgeLink's logger, so a refused
/// certificate or a rejected identity token is reported by the thing that refused it.
/// </summary>
internal sealed class OpcUaTelemetryContext(ILoggerFactory loggerFactory) : TelemetryContextBase(loggerFactory);

/// <summary>
/// Everything the OPC UA edge needs, and nothing it can run without.
/// </summary>
/// <remarks>
/// All four or none, exactly as the MQTT edge decides. There is no default endpoint, no
/// default certificate and no unsecured fallback: an unconfigured OPC UA edge stays gated
/// rather than becoming a working one with weaker security.
/// </remarks>
public sealed record OpcUaAdapterOptions(
    string EndpointUrl,
    string ApplicationUri,
    string DeviceId,
    string CertificateAuthorityPath,
    string ClientCertificatePath,
    string ClientPrivateKeyPath,
    Guid ProjectId,
    Guid CellId,
    Guid AssetId,
    TimeSpan CallTimeout)
{
    public static OpcUaAdapterOptions? FromConfiguration(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var endpoint = configuration["CINERION_OPCUA_ENDPOINT"];
        var clientCertificate = configuration["CINERION_OPCUA_CLIENT_CERT"];
        var clientKey = configuration["CINERION_OPCUA_CLIENT_KEY"];
        var authority = configuration["CINERION_OPCUA_CA_CERT"];

        if (string.IsNullOrWhiteSpace(endpoint)
            || string.IsNullOrWhiteSpace(clientCertificate)
            || string.IsNullOrWhiteSpace(clientKey)
            || string.IsNullOrWhiteSpace(authority))
        {
            return null;
        }

        return new OpcUaAdapterOptions(
            endpoint,
            configuration["CINERION_OPCUA_APPLICATION_URI"] ?? "urn:cinerion:ch1:edgelink",
            configuration["CINERION_OPCUA_DEVICE_ID"] ?? "CH1-DEV-CELL-0001",
            authority,
            clientCertificate,
            clientKey,
            Guid.TryParse(configuration["CINERION_OPCUA_PROJECT_ID"], out var project) ? project : Guid.Empty,
            Guid.TryParse(configuration["CINERION_OPCUA_CELL_ID"], out var cell) ? cell : Guid.Empty,
            Guid.TryParse(configuration["CINERION_OPCUA_ASSET_ID"], out var asset) ? asset : Guid.Empty,
            TimeSpan.FromSeconds(
                int.TryParse(configuration["CINERION_OPCUA_CALL_TIMEOUT_SECONDS"], CultureInfo.InvariantCulture, out var seconds)
                    ? seconds
                    : 15));
    }
}

/// <summary>
/// The live OPC UA adapter — CH1-COM-IF-0007 to the PLC simulator and CH1-COM-IF-0022 to
/// the Siemens S7-1200 G2 CPU.
/// </summary>
/// <remarks>
/// <para>
/// EdgeLink's <em>third</em> operational adapter, and the one that makes CH1-VVT-TC-0022 a
/// statement about more than one protocol: it is held to the same unchanged
/// <see cref="AdapterConformance"/> suite as the simulator and the MQTT adapter, run by the
/// same code, with no domain or inspection logic differing between the three.
/// </para>
/// <para>
/// <b>The capability model is browsed, not composed.</b> Everything the manifest reports —
/// device identity, firmware, configuration revision, supported commands, telemetry
/// channels and their engineering units — is read out of the server's address space, and
/// every node is reached by <em>browse path</em> from the Objects folder rather than by a
/// node identifier this adapter invented. A real S7 runtime numbers its nodes differently
/// from a stand-in; the browse names are the contract, so the adapter that resolves them is
/// the one that will still work against the CPU.
/// </para>
/// <para>
/// <b>Read-only is derived, not asserted.</b> A telemetry channel is reported as writable
/// or not according to the <c>AccessLevel</c> attribute the server itself publishes, so
/// <c>ADP-03-CHANNELS-READ-ONLY</c> is evidence about the controller's model rather than a
/// claim this adapter makes about it.
/// </para>
/// <para>
/// <b>Security is not negotiable.</b> The endpoint is selected with security required, and
/// then the mode is checked: anything other than <c>SignAndEncrypt</c> is refused outright
/// rather than merely not preferred, because "the most secure endpoint offered" is a
/// property of the server and CH1-COM-IF-0007 states a requirement on the link. The server
/// is validated against the controlled certificate authority, the session presents a
/// certificate user identity, and there is no anonymous path and no auto-accept callback.
/// </para>
/// <para>
/// <b>Expiry and replay are refused locally, before anything reaches the wire</b>, which is
/// the gateway obligation CH1-COM-FR-0010 states — and the controller refuses them again on
/// its own terms, because neither end assumes the other checked.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0002, CH1-COM-FR-0006, CH1-COM-FR-0008, CH1-COM-FR-0010, CH1-COM-IF-0007, CH1-COM-IF-0022, CH1-CYB-CSRS-0001</requirements>
public sealed partial class OpcUaProtocolAdapter : IProtocolAdapter, IControllerStateSource, IAsyncDisposable
{
    /// <summary>The versioned namespace the CH1 handshake and capability nodes live in.</summary>
    public const string Ch1Namespace = "urn:cinerion:ch1:plc:handshake:v1";

    private readonly OpcUaAdapterOptions _options;
    private readonly ILogger<OpcUaProtocolAdapter> _logger;
    private readonly ILoggerFactory _loggerFactory;
    private readonly TimeProvider _timeProvider;
    private readonly SemaphoreSlim _connectionGate = new(1, 1);
    private readonly HashSet<string> _announcedChannels = [];
    private readonly Channel<TelemetryPoint> _telemetry =
        Channel.CreateBounded<TelemetryPoint>(new BoundedChannelOptions(1024)
        {
            // Stated overflow behaviour rather than an accidental one, on the same terms as
            // the MQTT edge: the oldest reading is the one dropped.
            FullMode = BoundedChannelFullMode.DropOldest,
        });

    private ISession? _session;
    private Subscription? _subscription;
    private ushort _namespaceIndex;
    private NodeId? _handshakeFolder;
    private NodeId? _prepareMethod;
    private IReadOnlyList<ResolvedChannel> _channels = [];
    private long _lastSequence;
    private long _telemetrySequence;

    private sealed record ResolvedChannel(string ChannelId, NodeId Node, string Unit, bool Writable);

    public OpcUaProtocolAdapter(
        OpcUaAdapterOptions options,
        ILogger<OpcUaProtocolAdapter> logger,
        ILoggerFactory loggerFactory,
        TimeProvider? timeProvider = null)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _loggerFactory = loggerFactory ?? throw new ArgumentNullException(nameof(loggerFactory));
        _timeProvider = timeProvider ?? TimeProvider.System;
    }

    public string AdapterId => "CH1-ADP-OPCUA-0001";

    public string Protocol => "OPCUA";

    // ------------------------------------------------------------------ connection

    private async ValueTask<ISession> ConnectAsync(CancellationToken cancellationToken)
    {
        if (_session is { Connected: true } live)
        {
            return live;
        }

        await _connectionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (_session is { Connected: true } established)
            {
                return established;
            }

            var configuration = BuildConfiguration();
            await configuration.ValidateAsync(ApplicationType.Client, cancellationToken).ConfigureAwait(false);

            var telemetry = new OpcUaTelemetryContext(_loggerFactory);
            var description = await CoreClientUtils
                .SelectEndpointAsync(configuration, _options.EndpointUrl, useSecurity: true, telemetry, cancellationToken)
                .ConfigureAwait(false)
                ?? throw new InvalidOperationException(
                    $"No endpoint was offered at {_options.EndpointUrl}, so there is no controller here to speak to.");

            // Selected with security required, and then checked. "The most secure endpoint
            // this server offered" is a fact about the server; CH1-COM-IF-0007 states a
            // requirement about the link, so a server offering nothing better than Sign, or
            // nothing but None, is refused rather than connected to.
            if (description.SecurityMode != MessageSecurityMode.SignAndEncrypt)
            {
                throw new InvalidOperationException(
                    $"The endpoint at {_options.EndpointUrl} offers {description.SecurityMode} with policy "
                    + $"{description.SecurityPolicyUri}. CH1-COM-IF-0007 requires SignAndEncrypt, and this "
                    + "adapter refuses rather than accepting a weaker channel.");
            }

            using var pemIdentity = X509Certificate2.CreateFromPemFile(
                _options.ClientCertificatePath, _options.ClientPrivateKeyPath);
            // Round-tripped through PKCS#12 so the private key is usable by the secure
            // channel on every platform. Ephemeral, in memory, never written.
            var clientIdentity = X509CertificateLoader.LoadPkcs12(
                pemIdentity.Export(X509ContentType.Pkcs12), null);

            var endpoint = new ConfiguredEndpoint(
                null, description, EndpointConfiguration.Create(configuration));

            var session = await new DefaultSessionFactory(telemetry).CreateAsync(
                configuration,
                endpoint,
                updateBeforeConnect: false,
                sessionName: $"{_options.ApplicationUri}:{_options.DeviceId}",
                sessionTimeout: 60_000,
                // A certificate user identity, because the controller refuses anonymous.
                // The application certificate authenticates the gateway to the channel; this
                // authenticates the gateway to the session, and they are different questions.
                identity: new UserIdentity(clientIdentity),
                preferredLocales: null,
                ct: cancellationToken).ConfigureAwait(false);

            _session = session;
            _namespaceIndex = (ushort)session.NamespaceUris.GetIndex(Ch1Namespace);
            if (_namespaceIndex == 0)
            {
                throw new InvalidOperationException(
                    $"The server at {_options.EndpointUrl} does not publish the {Ch1Namespace} namespace, "
                    + "so it is not a controller speaking the CH1 handshake.");
            }

            // Scope is agreed before anything else opens. CH1-COM-ICD-0001 puts project,
            // cell and asset scope on every controlled message, and the same question has
            // to be asked of a controller: one serving another project is not a controller
            // this gateway serves, whatever endpoint it was reached on. Checked here rather
            // than in ReadCapabilityAsync so no subscription and no command path is opened
            // against a controller whose scope was never agreed.
            await AgreeScopeAsync(session, cancellationToken).ConfigureAwait(false);

            _handshakeFolder = await ResolveAsync(session, cancellationToken, "CH1", "Handshake").ConfigureAwait(false);
            _prepareMethod = await ResolveAsync(session, cancellationToken, "CH1", "Handshake", "Prepare").ConfigureAwait(false);
            _channels = await ResolveChannelsAsync(session, cancellationToken).ConfigureAwait(false);
            await SubscribeAsync(session, cancellationToken).ConfigureAwait(false);

            var securityMode = description.SecurityMode.ToString();
            LogConnected(
                _logger,
                _options.EndpointUrl,
                securityMode,
                description.SecurityPolicyUri,
                _channels.Count);
            return session;
        }
        finally
        {
            _connectionGate.Release();
        }
    }

    private ApplicationConfiguration BuildConfiguration()
    {
        // Not disposed: the trust list holds this certificate for the life of the
        // configuration, and a disposed trust anchor makes every server certificate
        // untrusted — which surfaces as a secure-channel failure rather than as a trust
        // one, and is therefore the kind of defect that sends a reader to the wrong place.
        var authority = X509CertificateLoader.LoadCertificateFromFile(_options.CertificateAuthorityPath);
        var pki = Path.Combine(Path.GetTempPath(), "ch1-edgelink-opcua-pki");
        var trustedIssuers = Path.Combine(pki, "issuers");
        var trustedPeers = Path.Combine(pki, "peers");
        var rejected = Path.Combine(pki, "rejected");
        foreach (var store in new[] { trustedIssuers, trustedPeers, rejected })
        {
            Directory.CreateDirectory(store);
        }

        using var pemIdentity = X509Certificate2.CreateFromPemFile(
            _options.ClientCertificatePath, _options.ClientPrivateKeyPath);
        var clientIdentity = X509CertificateLoader.LoadPkcs12(
            pemIdentity.Export(X509ContentType.Pkcs12), null);

        return new ApplicationConfiguration
        {
            ApplicationName = "Cinerion CH1 EdgeLink",
            ApplicationUri = _options.ApplicationUri,
            ProductUri = "urn:cinerion:ch1:edgelink",
            ApplicationType = ApplicationType.Client,
            ClientConfiguration = new ClientConfiguration
            {
                DefaultSessionTimeout = 60_000,
                MinSubscriptionLifetime = 10_000,
            },
            SecurityConfiguration = new SecurityConfiguration
            {
                ApplicationCertificate = new CertificateIdentifier(clientIdentity),
                // The controlled laboratory authority, held in memory. The directories are
                // created empty and stay empty, so a certificate dropped into one could not
                // quietly become trusted, and there is no callback anywhere here that
                // returns true regardless — that single line is what turns a certificate
                // trust list into decoration.
                TrustedIssuerCertificates = new CertificateTrustList
                {
                    StoreType = CertificateStoreType.Directory,
                    StorePath = trustedIssuers,
                    TrustedCertificates = [new CertificateIdentifier(authority)],
                },
                TrustedPeerCertificates = new CertificateTrustList
                {
                    StoreType = CertificateStoreType.Directory,
                    StorePath = trustedPeers,
                    TrustedCertificates = [new CertificateIdentifier(authority)],
                },
                RejectedCertificateStore = new CertificateStoreIdentifier
                {
                    StoreType = CertificateStoreType.Directory,
                    StorePath = rejected,
                },
                AutoAcceptUntrustedCertificates = false,
                RejectSHA1SignedCertificates = true,
                RejectUnknownRevocationStatus = false,
                MinimumCertificateKeySize = 2048,
                AddAppCertToTrustedStore = false,
                SendCertificateChain = false,
            },
            TransportConfigurations = [],
            TransportQuotas = new TransportQuotas
            {
                OperationTimeout = (int)_options.CallTimeout.TotalMilliseconds,
                MaxStringLength = 1_048_576,
                MaxByteStringLength = 1_048_576,
                MaxArrayLength = 65_535,
                MaxMessageSize = 4_194_304,
                MaxBufferSize = 65_535,
                ChannelLifetime = 300_000,
                SecurityTokenLifetime = 3_600_000,
            },
            TraceConfiguration = new TraceConfiguration { DeleteOnLoad = false },
            DisableHiResClock = true,
        };
    }

    /// <summary>
    /// Reads the scope the controller declares and refuses one this gateway does not serve.
    /// </summary>
    private async ValueTask AgreeScopeAsync(ISession session, CancellationToken cancellationToken)
    {
        var reads = new ReadValueIdCollection();
        foreach (var name in new[] { "ProjectId", "CellId", "AssetId" })
        {
            reads.Add(new ReadValueId
            {
                NodeId = await ResolveAsync(session, cancellationToken, "CH1", "Capability", name).ConfigureAwait(false),
                AttributeId = Attributes.Value,
            });
        }

        var response = await session
            .ReadAsync(null, 0, TimestampsToReturn.Neither, reads, cancellationToken)
            .ConfigureAwait(false);

        Guid Declared(int index) =>
            Guid.TryParse(response.Results[index].Value as string, out var value) ? value : Guid.Empty;

        var project = Declared(0);
        var cell = Declared(1);
        var asset = Declared(2);

        if (project != _options.ProjectId || cell != _options.CellId || asset != _options.AssetId)
        {
            throw new InvalidOperationException(
                $"The controller at {_options.EndpointUrl} serves project {project}, cell {cell} and asset {asset}. "
                + $"This gateway is configured for project {_options.ProjectId}, cell {_options.CellId} and asset "
                + $"{_options.AssetId}, so it does not serve this controller and will not open a command path to it.");
        }

        LogScopeAgreed(_logger, project, cell, asset);
    }

    /// <summary>
    /// Resolves a node by browse path from the Objects folder. The browse names are the
    /// interface contract; node identifiers are a server's private business.
    /// </summary>
    private async ValueTask<NodeId> ResolveAsync(
        ISession session,
        CancellationToken cancellationToken,
        params string[] path)
    {
        var browsePath = new BrowsePath
        {
            StartingNode = ObjectIds.ObjectsFolder,
            RelativePath = new RelativePath(),
        };

        foreach (var element in path)
        {
            browsePath.RelativePath.Elements.Add(new RelativePathElement
            {
                ReferenceTypeId = ReferenceTypeIds.HierarchicalReferences,
                IsInverse = false,
                IncludeSubtypes = true,
                TargetName = new QualifiedName(element, _namespaceIndex),
            });
        }

        var response = await session
            .TranslateBrowsePathsToNodeIdsAsync(null, [browsePath], cancellationToken)
            .ConfigureAwait(false);

        var result = response.Results.Count > 0 ? response.Results[0] : null;
        if (result is null || StatusCode.IsBad(result.StatusCode) || result.Targets.Count == 0)
        {
            throw new InvalidOperationException(
                $"The controller does not expose /{string.Join('/', path)}, so it is not speaking the CH1 model.");
        }

        return ExpandedNodeId.ToNodeId(result.Targets[0].TargetId, session.NamespaceUris);
    }

    private async ValueTask<IReadOnlyList<ResolvedChannel>> ResolveChannelsAsync(
        ISession session,
        CancellationToken cancellationToken)
    {
        var folder = await ResolveAsync(session, cancellationToken, "CH1", "Telemetry").ConfigureAwait(false);
        var (_, _, references) = await session.BrowseAsync(
            null,
            null,
            folder,
            0,
            BrowseDirection.Forward,
            ReferenceTypeIds.HierarchicalReferences,
            true,
            (uint)NodeClass.Variable,
            cancellationToken).ConfigureAwait(false);

        var channels = new List<ResolvedChannel>();
        foreach (var reference in references)
        {
            var node = ExpandedNodeId.ToNodeId(reference.NodeId, session.NamespaceUris);
            var channelId = reference.BrowseName.Name;

            // The unit comes from the channel's own EngineeringUnits property, and the
            // read-only answer comes from its own AccessLevel attribute. Both are the
            // server's statements about its model rather than this adapter's assumptions.
            //
            // Found by browsing the channel's properties rather than by a browse path,
            // because EngineeringUnits is a standard OPC UA browse name in namespace 0
            // while every CH1 name is in the CH1 namespace — a path that assumed one index
            // for both would resolve on this server and fail on a real one.
            var (_, _, properties) = await session.BrowseAsync(
                null,
                null,
                node,
                0,
                BrowseDirection.Forward,
                ReferenceTypeIds.HasProperty,
                true,
                (uint)NodeClass.Variable,
                cancellationToken).ConfigureAwait(false);

            var unitReference = properties.FirstOrDefault(property =>
                string.Equals(property.BrowseName.Name, BrowseNames.EngineeringUnits, StringComparison.Ordinal))
                ?? throw new InvalidOperationException(
                    $"Telemetry channel {channelId} declares no EngineeringUnits property. "
                    + "CH1-COM-ICD-0001 requires telemetry to carry an engineering unit, and this "
                    + "adapter does not supply one the controller did not state.");
            var unitNode = ExpandedNodeId.ToNodeId(unitReference.NodeId, session.NamespaceUris);

            var read = await session.ReadAsync(
                null,
                0,
                TimestampsToReturn.Neither,
                [
                    new ReadValueId { NodeId = node, AttributeId = Attributes.AccessLevel },
                    new ReadValueId { NodeId = unitNode, AttributeId = Attributes.Value },
                ],
                cancellationToken).ConfigureAwait(false);

            var accessLevel = read.Results[0].Value is byte level ? level : (byte)0;
            var unit = read.Results[1].Value is ExtensionObject { Body: EUInformation information }
                ? information.DisplayName?.Text ?? string.Empty
                : string.Empty;

            channels.Add(new ResolvedChannel(
                channelId,
                node,
                unit,
                (accessLevel & AccessLevels.CurrentWrite) != 0));
        }

        return channels;
    }

    private async ValueTask SubscribeAsync(ISession session, CancellationToken cancellationToken)
    {
        var subscription = new Subscription(
            new OpcUaTelemetryContext(_loggerFactory),
            new SubscriptionOptions
            {
                DisplayName = "CH1 telemetry",
                PublishingInterval = 1_000,
                PublishingEnabled = true,
                KeepAliveCount = 10,
                LifetimeCount = 30,
                TimestampsToReturn = TimestampsToReturn.Both,
            });

        foreach (var channel in _channels)
        {
            var item = new MonitoredItem(
                new OpcUaTelemetryContext(_loggerFactory),
                new MonitoredItemOptions
                {
                    DisplayName = channel.ChannelId,
                    StartNodeId = channel.Node,
                    AttributeId = Attributes.Value,
                    MonitoringMode = MonitoringMode.Reporting,
                    SamplingInterval = 1_000,
                    QueueSize = 10,
                    DiscardOldest = true,
                })
            {
                Handle = channel,
            };

            item.Notification += OnTelemetryNotification;
            subscription.AddItem(item);
        }

        session.AddSubscription(subscription);
        await subscription.CreateAsync(cancellationToken).ConfigureAwait(false);
        await subscription.ApplyChangesAsync(cancellationToken).ConfigureAwait(false);
        _subscription = subscription;
    }

    private void OnTelemetryNotification(MonitoredItem item, MonitoredItemNotificationEventArgs args)
    {
        if (item.Handle is not ResolvedChannel channel)
        {
            return;
        }

        foreach (var value in item.DequeueValues())
        {
            if (value.Value is not double reading)
            {
                continue;
            }

            // The quality word is the server's status code, translated rather than
            // invented. A gateway that reported Good for a value the controller marked
            // otherwise would be the one place a bad reading could become a good one.
            var quality = StatusCode.IsBad(value.StatusCode)
                ? "Bad"
                : value.StatusCode.Code == StatusCodes.GoodLocalOverride ? "Simulated" : "Good";

            var point = new TelemetryPoint(
                _options.DeviceId,
                channel.ChannelId,
                reading,
                channel.Unit,
                quality,
                value.SourceTimestamp == default
                    ? _timeProvider.GetUtcNow()
                    : new DateTimeOffset(value.SourceTimestamp, TimeSpan.Zero),
                Interlocked.Increment(ref _telemetrySequence),
                // Which clock stamped the sample decides what may be said about it, and
                // here it genuinely differs per reading. A SourceTimestamp is the OPC UA
                // SERVER's clock, and the protocol carries no quality for it - so the
                // honest declaration is that the source declared nothing, which is stored
                // as nothing. Only when the server offered no source timestamp did this
                // gateway stamp it, and only then is the gateway's own declaration the
                // right one to carry.
                value.SourceTimestamp == default ? TelemetryPoint.GatewayStamped : null);

            _telemetry.Writer.TryWrite(point);

            // One line per channel, the first time it delivers. Enough to show that a
            // monitored item really produced a reading, and not enough to fill a log.
            lock (_announcedChannels)
            {
                if (_announcedChannels.Add(channel.ChannelId))
                {
                    LogFirstSample(_logger, channel.ChannelId, reading, channel.Unit, quality);
                }
            }
        }
    }

    // ------------------------------------------------------------------ contract

    /// <summary>
    /// The capability model as the controller publishes it, browsed out of the address
    /// space. An adapter that has not reached its controller refuses rather than describing
    /// one it has never spoken to.
    /// </summary>
    public async ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken)
    {
        var session = await ConnectAsync(cancellationToken).ConfigureAwait(false);

        string[] names =
        [
            "SchemaVersion", "DeviceId", "DeviceType", "FirmwareVersion",
            "ConfigurationRevision", "SecurityProfile", "SupportedCommands", "ProtocolProfileVersion",
        ];

        var reads = new ReadValueIdCollection();
        foreach (var name in names)
        {
            reads.Add(new ReadValueId
            {
                NodeId = await ResolveAsync(session, cancellationToken, "CH1", "Capability", name).ConfigureAwait(false),
                AttributeId = Attributes.Value,
            });
        }

        var response = await session
            .ReadAsync(null, 0, TimestampsToReturn.Neither, reads, cancellationToken)
            .ConfigureAwait(false);

        string Text(int index) => response.Results[index].Value as string ?? string.Empty;

        var commands = response.Results[6].Value as string[] ?? [];

        return new DeviceCapabilityManifest(
            Text(0),
            Text(1),
            Text(2),
            Text(3),
            Text(4),
            commands,
            [.. _channels.Select(channel => new CapabilityChannel(channel.ChannelId, channel.Unit, channel.Writable))],
            [new ProtocolEndpoint("OPCUA", Text(7))],
            Text(5));
    }

    /// <summary>
    /// What the controller says about itself, read out of the address space it publishes.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The value of implementing this for OPC UA is not that a cell becomes permissive. It
    /// is that it becomes <b>observably not</b> permissive, end to end. The stand-in fronts
    /// the same FB_CH1_CommandGuard translation the Modbus zone does, and that guard
    /// declares its permissive check deferred - <c>207 PRELIMINARY_PERMISSIVE_INVALID</c>,
    /// because UDT_CH1_Permissives is read from wired inputs a stand-in has none of. Until
    /// this existed, a gateway in front of an OPC UA controller reported nothing about the
    /// controller at all, and CellStateResolver's "no controller has answered" path was
    /// reached by absence rather than by an answer. Now the refusal travels: the adapter
    /// reports a controller that exists, is running a known configuration, and has NOT
    /// answered its permissives, with the reason code attached - which is exactly what
    /// defect 47 showed a screen must be able to distinguish.
    /// </para>
    /// <para>
    /// <see cref="ControllerPermissives.NotReported"/> is returned unconditionally. There is
    /// no branch here that could produce a reported permissive, whatever the address space
    /// contains: the guard is the authority on that and it has said it cannot answer.
    /// </para>
    /// </remarks>
    public async ValueTask<ControllerStateObservation> ReadControllerStateAsync(
        CancellationToken cancellationToken)
    {
        var session = await ConnectAsync(cancellationToken).ConfigureAwait(false);

        var reads = new ReadValueIdCollection();
        foreach (var (folder, name) in new[]
                 {
                     ("Capability", "DeviceId"),
                     ("Capability", "ControllerBootId"),
                     ("Capability", "ConfigurationRevision"),
                     ("Capability", "SecurityProfile"),
                     ("Capability", "FirmwareVersion"),
                     ("Handshake", "State"),
                     ("Handshake", "DeferredChecks"),
                 })
        {
            reads.Add(new ReadValueId
            {
                NodeId = await ResolveAsync(session, cancellationToken, "CH1", folder, name).ConfigureAwait(false),
                AttributeId = Attributes.Value,
            });
        }

        var response = await session
            .ReadAsync(null, 0, TimestampsToReturn.Neither, reads, cancellationToken)
            .ConfigureAwait(false);

        return BuildControllerState(
            [.. response.Results.Select(result => result.Value)],
            _timeProvider.GetUtcNow());
    }

    /// <summary>
    /// The decoding, separated from the wire so the safety-relevant property can be
    /// asserted without standing up a controller - the same seam the Modbus adapter has,
    /// and for the same reason.
    /// </summary>
    public static ControllerStateObservation BuildControllerState(
        IReadOnlyList<object?> values,
        DateTimeOffset observedAt)
    {
        ArgumentNullException.ThrowIfNull(values);

        string Text(int index) => index < values.Count ? values[index] as string ?? string.Empty : string.Empty;

        // The controller states its boot identity as a string, and a value that will not
        // parse is Guid.Empty rather than a fresh one. A random identity would change on
        // every read and void every prepared command on a healthy controller, which is the
        // opposite of what CH1-CMD-FR-0009 asks the boot identity to do.
        var bootId = Guid.TryParse(Text(1), out var parsed) ? parsed : Guid.Empty;

        var state = values.Count > 5 && values[5] is ushort code
            ? Ch1GuardStates.Name(code)
            : "Unknown";

        // The codes the guard itself declares deferred, taken from the leading number of
        // each line it publishes rather than from a list held here - a second copy would be
        // a second thing to drift.
        var deferred = new List<uint>(2);
        foreach (var line in (values.Count > 6 ? values[6] as string[] : null) ?? [])
        {
            var digits = new string([.. line.TakeWhile(char.IsAsciiDigit)]);
            if (uint.TryParse(digits, System.Globalization.CultureInfo.InvariantCulture, out var value)
                && !deferred.Contains(value))
            {
                deferred.Add(value);
            }
        }

        // 207 is stated whether or not this read happened to carry it. The permissive check
        // is deferred for this profile as a matter of the controlled document, not as a
        // matter of what one read reported, and a reader of the cell needs to know WHY the
        // permissives are unanswered rather than merely that they are.
        if (!deferred.Contains(PreliminaryPermissiveInvalid))
        {
            deferred.Add(PreliminaryPermissiveInvalid);
        }

        return new ControllerStateObservation(
            Text(0),
            bootId,
            state,
            Text(2),
            ControllerPermissives.NotReported with { DeferredCheckCodes = deferred },
            Text(3),
            Text(4),
            // Never "Live". This is a controller stand-in and says so all the way through to
            // the freshness a screen renders.
            "Simulated",
            observedAt);
    }

    /// <summary>
    /// <c>207 PRELIMINARY_PERMISSIVE_INVALID</c>, the reason FB_CH1_CommandGuard gives for
    /// not answering its permissives when UDT_CH1_Permissives comes from wired inputs a
    /// stand-in does not have.
    /// </summary>
    private const uint PreliminaryPermissiveInvalid = 207;

    /// <summary>
    /// Calls the controller's one method and reports what the guard answered.
    /// </summary>
    public async ValueTask<AdapterAcknowledgement> PrepareAsync(
        SemanticCommandEnvelope command,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(command);

        // Local refusals first, before anything reaches the wire. CH1-COM-FR-0007 permits
        // store-and-forward for telemetry and forbids it for commands, and CH1-COM-FR-0010
        // makes duplicate suppression the gateway's obligation rather than a hope about the
        // network. The controller refuses both again on its own terms.
        if (command.ExpiresAt <= _timeProvider.GetUtcNow())
        {
            return Reject(command, "COMMAND_EXPIRED");
        }

        if (command.Sequence <= Interlocked.Read(ref _lastSequence))
        {
            return Reject(command, "SEQUENCE_REPLAY_OR_DUPLICATE");
        }

        if (!command.CommandType.All(character =>
                char.IsAsciiLetterUpper(character) || char.IsAsciiDigit(character) || character == '_'))
        {
            return Reject(command, "SEMANTIC_COMMAND_INVALID");
        }

        var session = await ConnectAsync(cancellationToken).ConfigureAwait(false);
        Interlocked.Exchange(ref _lastSequence, command.Sequence);

        using var timeout = new CancellationTokenSource(_options.CallTimeout);
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeout.Token);

        IList<object> outputs;
        try
        {
            outputs = await session.CallAsync(
                _handshakeFolder!,
                _prepareMethod!,
                linked.Token,
                command.SchemaVersion,
                new Uuid(command.CommandId),
                command.Sequence,
                command.ConfigurationRevision,
                command.ExpiresAt.UtcDateTime,
                command.CommandType).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            // The call did not come back. Reporting acceptance here would have the domain
            // believe a controller took the intent when nothing is known about whether it did.
            return Reject(command, "CONTROLLER_CALL_TIMEOUT");
        }
        catch (ServiceResultException error)
        {
            return Reject(command, $"CONTROLLER_REFUSED_{error.StatusCode:X8}");
        }

        var accepted = outputs.Count > 0 && outputs[0] is true;
        var reasonName = outputs.Count > 3 ? outputs[3] as string ?? "UNSPECIFIED" : "UNSPECIFIED";
        var controllerState = outputs.Count > 4 ? outputs[4] as string ?? "Idle" : "Idle";

        // The two checks the controller stated it could not make are reported once per
        // connection rather than swallowed, so a reader of this gateway's log knows which
        // part of the guard was exercised and which was not.
        if (outputs.Count > 5 && outputs[5] is string[] deferred)
        {
            foreach (var check in deferred)
            {
                LogDeferredCheck(_logger, check);
            }
        }

        return new AdapterAcknowledgement(
            command.CommandId,
            accepted,
            controllerState,
            reasonName,
            _timeProvider.GetUtcNow(),
            AdapterId);
    }

    public async IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);
        await foreach (var point in _telemetry.Reader.ReadAllAsync(cancellationToken).ConfigureAwait(false))
        {
            yield return point;
        }
    }

    /// <summary>
    /// Re-establishes the session and restores nothing. The spent-sequence high-water mark
    /// survives on purpose: a reconnection that made a spent sequence acceptable again would
    /// arm equipment nobody asked to arm.
    /// </summary>
    public async ValueTask ReconcileAsync(CancellationToken cancellationToken)
    {
        await CloseAsync().ConfigureAwait(false);
        await ConnectAsync(cancellationToken).ConfigureAwait(false);
    }

    private async ValueTask CloseAsync()
    {
        if (_subscription is not null)
        {
            _subscription.Dispose();
            _subscription = null;
        }

        if (_session is not null)
        {
            try
            {
                await _session.CloseAsync(CancellationToken.None).ConfigureAwait(false);
            }
            catch (ServiceResultException)
            {
                // The link was already gone. Reconnecting is the answer either way.
            }

            _session.Dispose();
            _session = null;
        }

        lock (_announcedChannels)
        {
            _announcedChannels.Clear();
        }
    }

    private AdapterAcknowledgement Reject(SemanticCommandEnvelope command, string reason) => new(
        command.CommandId,
        false,
        "Idle",
        reason,
        _timeProvider.GetUtcNow(),
        AdapterId);

    // Source-generated per CH1-SWA-SDP-0001. Endpoint, policy and stable strings only: no
    // certificate material and no payload content ever reaches a log line.
    [LoggerMessage(EventId = 2200, Level = LogLevel.Information,
        Message = "OPC UA adapter connected to {Endpoint} with {SecurityMode} under {SecurityPolicy}; {Channels} telemetry channels browsed from the controller's model.")]
    private static partial void LogConnected(
        ILogger logger, string endpoint, string securityMode, string securityPolicy, int channels);

    [LoggerMessage(EventId = 2203, Level = LogLevel.Information,
        Message = "OPC UA adapter scope agreed with the controller: project {Project}, cell {Cell}, asset {Asset}")]
    private static partial void LogScopeAgreed(ILogger logger, Guid project, Guid cell, Guid asset);

    [LoggerMessage(EventId = 2201, Level = LogLevel.Information,
        Message = "OPC UA telemetry {Channel} first sample {Value} {Unit} quality {Quality}")]
    private static partial void LogFirstSample(
        ILogger logger, string channel, double value, string unit, string quality);

    [LoggerMessage(EventId = 2202, Level = LogLevel.Information,
        Message = "OPC UA controller deferred check: {Check}")]
    private static partial void LogDeferredCheck(ILogger logger, string check);

    public async ValueTask DisposeAsync()
    {
        _telemetry.Writer.TryComplete();
        await CloseAsync().ConfigureAwait(false);
        _connectionGate.Dispose();
    }
}
