// A small Modbus TCP client. Function codes in, register values out.

using System.Buffers.Binary;
using System.Net.Sockets;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>A Modbus exception response, carried as the code the device returned.</summary>
public sealed class ModbusProtocolException(byte functionCode, byte exceptionCode)
    : Exception($"Modbus function {functionCode} was refused with exception code {exceptionCode} ({Describe(exceptionCode)}).")
{
    public byte FunctionCode { get; } = functionCode;

    public byte ExceptionCode { get; } = exceptionCode;

    public static string Describe(byte code) => code switch
    {
        1 => "ILLEGAL_FUNCTION",
        2 => "ILLEGAL_DATA_ADDRESS",
        3 => "ILLEGAL_DATA_VALUE",
        4 => "SERVER_DEVICE_FAILURE",
        6 => "SERVER_DEVICE_BUSY",
        _ => "UNSPECIFIED",
    };
}

/// <summary>
/// A Modbus TCP master, written here rather than taken from a library.
/// </summary>
/// <remarks>
/// <para>
/// Deliberately written by hand, and deliberately <em>small</em>. The controller stand-in
/// this is exercised against uses an independent third-party Modbus implementation, so the
/// two ends share no code and agreement between them is evidence about the wire format
/// rather than about one library agreeing with itself — the same argument that pins the
/// firmware's CBOR encoder to the gateway's byte for byte.
/// </para>
/// <para>
/// <b>It offers three function codes and no more.</b> Read holding registers (3), read
/// input registers (4) and write multiple registers (16). There is no coil access, no
/// file-record access, no mask write, no arbitrary-function escape hatch, and nothing that
/// takes a function code from a caller — CH1-COM-PRO-0001 denies arbitrary function codes,
/// and a client that could emit one would leave that denial resting entirely on the device.
/// </para>
/// <para>
/// <b>Nor is it reachable by the domain.</b> It is internal to
/// <see cref="ModbusProtocolAdapter"/>, which passes only addresses from
/// <see cref="Ch1ModbusMap"/>. CH1-SYS-SAD-0001 prohibits direct register writes and
/// CH1-CYB-CSRS-0001 makes the gateway zone "not a general router"; a register-level API
/// escaping into the application would be exactly that router.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0008, CH1-COM-PRO-0001, CH1-CYB-CSRS-0001, CH1-SYS-SAD-0001</requirements>
internal sealed class ModbusTcpClient(string host, int port, byte unitIdentifier, TimeSpan timeout) : IDisposable
{
    private const byte FunctionReadHoldingRegisters = 3;
    private const byte FunctionReadInputRegisters = 4;
    private const byte FunctionWriteMultipleRegisters = 16;

    /// <summary>MBAP header: transaction, protocol, length, unit.</summary>
    private const int HeaderBytes = 7;

    /// <summary>Modbus caps a single read at 125 registers and a single write at 123.</summary>
    private const int MaximumReadRegisters = 125;

    private const int MaximumWriteRegisters = 123;

    private readonly SemaphoreSlim _exchange = new(1, 1);
    private TcpClient? _socket;
    private NetworkStream? _stream;
    private ushort _transaction;

    public bool Connected => _socket?.Connected == true;

    public async ValueTask ConnectAsync(CancellationToken cancellationToken)
    {
        if (Connected)
        {
            return;
        }

        Dispose();
        var socket = new TcpClient { NoDelay = true };
        using var deadline = new CancellationTokenSource(timeout);
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, deadline.Token);
        await socket.ConnectAsync(host, port, linked.Token).ConfigureAwait(false);
        _socket = socket;
        _stream = socket.GetStream();
    }

    public ValueTask<ushort[]> ReadHoldingRegistersAsync(ushort start, ushort count, CancellationToken cancellationToken) =>
        ReadAsync(FunctionReadHoldingRegisters, start, count, cancellationToken);

    public ValueTask<ushort[]> ReadInputRegistersAsync(ushort start, ushort count, CancellationToken cancellationToken) =>
        ReadAsync(FunctionReadInputRegisters, start, count, cancellationToken);

    private async ValueTask<ushort[]> ReadAsync(
        byte function,
        ushort start,
        ushort count,
        CancellationToken cancellationToken)
    {
        if (count is 0 || count > MaximumReadRegisters)
        {
            throw new ArgumentOutOfRangeException(
                nameof(count), count, $"Modbus reads at most {MaximumReadRegisters} registers in one request.");
        }

        var request = new byte[5];
        request[0] = function;
        BinaryPrimitives.WriteUInt16BigEndian(request.AsSpan(1), start);
        BinaryPrimitives.WriteUInt16BigEndian(request.AsSpan(3), count);

        var response = await ExchangeAsync(request, cancellationToken).ConfigureAwait(false);

        // response: function, byte count, then two bytes per register.
        var expected = count * 2;
        if (response.Length < 2 || response[1] != expected || response.Length < 2 + expected)
        {
            throw new InvalidOperationException(
                $"The device answered function {function} with {response.Length} bytes; {2 + expected} were required. "
                + "A short or over-long frame is refused rather than read past.");
        }

        var registers = new ushort[count];
        for (var index = 0; index < count; index++)
        {
            registers[index] = BinaryPrimitives.ReadUInt16BigEndian(response.AsSpan(2 + (index * 2)));
        }

        return registers;
    }

    public async ValueTask WriteMultipleRegistersAsync(
        ushort start,
        ushort[] values,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(values);
        if (values.Length is 0 || values.Length > MaximumWriteRegisters)
        {
            throw new ArgumentOutOfRangeException(
                nameof(values), values.Length, $"Modbus writes at most {MaximumWriteRegisters} registers in one request.");
        }

        var request = new byte[6 + (values.Length * 2)];
        request[0] = FunctionWriteMultipleRegisters;
        BinaryPrimitives.WriteUInt16BigEndian(request.AsSpan(1), start);
        BinaryPrimitives.WriteUInt16BigEndian(request.AsSpan(3), (ushort)values.Length);
        request[5] = (byte)(values.Length * 2);
        for (var index = 0; index < values.Length; index++)
        {
            BinaryPrimitives.WriteUInt16BigEndian(request.AsSpan(6 + (index * 2)), values[index]);
        }

        var response = await ExchangeAsync(request, cancellationToken).ConfigureAwait(false);

        // The echo is checked rather than discarded: a device that acknowledged a different
        // address or a different quantity has not done what was asked, and "the write
        // returned" is not "the write landed where it was aimed".
        if (response.Length < 5
            || BinaryPrimitives.ReadUInt16BigEndian(response.AsSpan(1)) != start
            || BinaryPrimitives.ReadUInt16BigEndian(response.AsSpan(3)) != values.Length)
        {
            throw new InvalidOperationException(
                $"The device acknowledged a write this gateway did not issue: {values.Length} registers at {start} "
                + "were requested and the echo did not match.");
        }
    }

    private async ValueTask<byte[]> ExchangeAsync(byte[] pdu, CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);
        await _exchange.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var stream = _stream ?? throw new InvalidOperationException("The Modbus link is not open.");
            var transaction = unchecked(++_transaction);

            var frame = new byte[HeaderBytes + pdu.Length];
            BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(0), transaction);
            BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(2), 0); // protocol identifier
            BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(4), (ushort)(pdu.Length + 1));
            frame[6] = unitIdentifier;
            pdu.CopyTo(frame.AsSpan(HeaderBytes));

            using var deadline = new CancellationTokenSource(timeout);
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, deadline.Token);

            await stream.WriteAsync(frame, linked.Token).ConfigureAwait(false);

            var header = new byte[HeaderBytes];
            await stream.ReadExactlyAsync(header, linked.Token).ConfigureAwait(false);

            // A reply carrying somebody else's transaction identifier is not this reply.
            var answeredTransaction = BinaryPrimitives.ReadUInt16BigEndian(header.AsSpan(0));
            if (answeredTransaction != transaction)
            {
                throw new InvalidOperationException(
                    $"The device answered transaction {answeredTransaction} to request {transaction}; "
                    + "a mismatched reply is discarded rather than read as this one's answer.");
            }

            var length = BinaryPrimitives.ReadUInt16BigEndian(header.AsSpan(4));
            if (length is < 2 or > 253)
            {
                throw new InvalidOperationException($"The device declared a {length}-byte Modbus payload, which is out of range.");
            }

            var body = new byte[length - 1];
            await stream.ReadExactlyAsync(body, linked.Token).ConfigureAwait(false);

            // The exception bit, and the reason. A refusal is reported as a refusal with its
            // own code, never flattened into a generic failure — the difference between
            // ILLEGAL_FUNCTION and ILLEGAL_DATA_ADDRESS is the difference between two
            // separate controls having held.
            if ((body[0] & 0x80) != 0)
            {
                throw new ModbusProtocolException((byte)(body[0] & 0x7F), body.Length > 1 ? body[1] : (byte)0);
            }

            if (body[0] != pdu[0])
            {
                throw new InvalidOperationException(
                    $"The device answered function {body[0]} to a function {pdu[0]} request.");
            }

            return body;
        }
        finally
        {
            _exchange.Release();
        }
    }

    public void Dispose()
    {
        _stream?.Dispose();
        _socket?.Dispose();
        _stream = null;
        _socket = null;
    }
}

/// <summary>
/// Reading and writing the controlled map's text and wide fields, in the byte order Modbus
/// itself uses. Stated identically in the controller stand-in, which holds its own copy.
/// </summary>
public static class Ch1ModbusEncoding
{
    /// <summary>ASCII, two characters per register, high byte first, NUL padded.</summary>
    public static string ReadText(ReadOnlySpan<ushort> registers)
    {
        Span<char> characters = stackalloc char[registers.Length * 2];
        var length = 0;
        foreach (var register in registers)
        {
            characters[length++] = (char)(register >> 8);
            characters[length++] = (char)(register & 0xFF);
        }

        var end = characters[..length].IndexOf('\0');
        return new string(characters[..(end < 0 ? length : end)]).TrimEnd();
    }

    public static void WriteText(Span<ushort> registers, string value)
    {
        registers.Clear();
        for (var index = 0; index < registers.Length; index++)
        {
            var high = (index * 2) < value.Length ? (byte)value[index * 2] : (byte)0;
            var low = ((index * 2) + 1) < value.Length ? (byte)value[(index * 2) + 1] : (byte)0;
            registers[index] = (ushort)((high << 8) | low);
        }
    }

    public static long ReadUInt32(ushort high, ushort low) => ((long)high << 16) | low;

    public static (ushort High, ushort Low) SplitUInt32(long value) =>
        ((ushort)((value >> 16) & 0xFFFF), (ushort)(value & 0xFFFF));
}
