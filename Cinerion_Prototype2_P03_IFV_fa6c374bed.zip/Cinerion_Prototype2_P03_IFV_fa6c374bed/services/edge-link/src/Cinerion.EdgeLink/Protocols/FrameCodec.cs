// The CH1 serial frame, gateway side.

using System.Buffers.Binary;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// The CH1 serial frame, as CH1-COM-PRO-0001 defines it: preamble, version, length,
/// type, sequence, payload, CRC and timeout.
/// </summary>
/// <remarks>
/// <para>
/// This is a second implementation of the format the Arduino-side node already speaks in
/// <c>firmware/arduino-io/src/frame_codec.cpp</c>. Two implementations of one wire format
/// are what make the format a contract rather than a description of whatever one side
/// happens to emit, and the conformance suite cross-checks them byte for byte against the
/// same vectors.
/// </para>
/// <para>
/// Everything here is decided from the bytes. A frame states its own length and carries
/// its own CRC; nothing is inferred from what the sender claimed elsewhere, and a frame
/// that does not add up is refused rather than repaired.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0004, CH1-COM-FR-0005, CH1-COM-IF-0009</requirements>
public static class FrameCodec
{
    public const ushort Preamble = 0xC1A1;
    public const byte Version = 1;

    /// <summary>Header bytes before the payload: preamble, version, type, length, sequence.</summary>
    public const int HeaderBytes = 10;

    /// <summary>Trailing CRC-16/CCITT-FALSE over every preceding byte of the frame.</summary>
    public const int CrcBytes = 2;

    /// <summary>
    /// The payload a single frame may carry. Fixed by the firmware's own buffer, so a
    /// larger value here would produce frames the node could not receive.
    /// </summary>
    public const int MaximumPayload = 128;

    /// <summary>A frame carrying a whole message.</summary>
    public const byte TypeSingle = 0x01;

    /// <summary>The first frame of a message that did not fit in one.</summary>
    public const byte TypeFirst = 0x02;

    /// <summary>A middle frame of a segmented message.</summary>
    public const byte TypeContinuation = 0x03;

    /// <summary>The last frame of a segmented message.</summary>
    public const byte TypeFinal = 0x04;

    /// <summary>CRC-16/CCITT-FALSE: polynomial 0x1021, initial value 0xFFFF, no reflection.</summary>
    public static ushort Crc16Ccitt(ReadOnlySpan<byte> bytes)
    {
        ushort crc = 0xFFFF;
        foreach (var value in bytes)
        {
            crc ^= (ushort)(value << 8);
            for (var bit = 0; bit < 8; bit++)
            {
                crc = (ushort)((crc & 0x8000) != 0 ? (crc << 1) ^ 0x1021 : crc << 1);
            }
        }

        return crc;
    }

    public static byte[] Encode(byte type, uint sequence, ReadOnlySpan<byte> payload)
    {
        if (payload.Length > MaximumPayload)
        {
            throw new ArgumentOutOfRangeException(
                nameof(payload),
                $"A frame carries at most {MaximumPayload} payload bytes; {payload.Length} were offered. " +
                "Segment the message rather than enlarging the frame.");
        }

        var frame = new byte[HeaderBytes + payload.Length + CrcBytes];
        BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(0, 2), Preamble);
        frame[2] = Version;
        frame[3] = type;
        BinaryPrimitives.WriteUInt16BigEndian(frame.AsSpan(4, 2), (ushort)payload.Length);
        BinaryPrimitives.WriteUInt32BigEndian(frame.AsSpan(6, 4), sequence);
        payload.CopyTo(frame.AsSpan(HeaderBytes));
        BinaryPrimitives.WriteUInt16BigEndian(
            frame.AsSpan(frame.Length - CrcBytes, CrcBytes),
            Crc16Ccitt(frame.AsSpan(0, frame.Length - CrcBytes)));
        return frame;
    }

    /// <summary>
    /// Why a frame was refused. The reason travels with the refusal because
    /// CH1-COM-ICD-0001 requires errors to carry a stable code and actionable detail.
    /// </summary>
    public enum FrameRejection
    {
        None,
        TooShort,
        PreambleInvalid,
        VersionUnsupported,
        TypeUnknown,
        LengthInvalid,
        SequenceNotAdvancing,
        CrcMismatch,
    }

    public readonly record struct DecodedFrame(byte Type, uint Sequence, byte[] Payload);

    /// <summary>
    /// Decodes one frame, refusing anything that does not add up. <paramref name="minimumSequence"/>
    /// is the replay window: a frame numbered below it is refused rather than accepted late.
    /// </summary>
    public static FrameRejection TryDecode(
        ReadOnlySpan<byte> frame,
        uint minimumSequence,
        out DecodedFrame decoded)
    {
        decoded = default;
        if (frame.Length < HeaderBytes + CrcBytes)
        {
            return FrameRejection.TooShort;
        }

        if (BinaryPrimitives.ReadUInt16BigEndian(frame[..2]) != Preamble)
        {
            return FrameRejection.PreambleInvalid;
        }

        if (frame[2] != Version)
        {
            return FrameRejection.VersionUnsupported;
        }

        var type = frame[3];
        if (type is not (TypeSingle or TypeFirst or TypeContinuation or TypeFinal))
        {
            return FrameRejection.TypeUnknown;
        }

        var payloadLength = BinaryPrimitives.ReadUInt16BigEndian(frame.Slice(4, 2));
        if (payloadLength > MaximumPayload || frame.Length != HeaderBytes + payloadLength + CrcBytes)
        {
            return FrameRejection.LengthInvalid;
        }

        var sequence = BinaryPrimitives.ReadUInt32BigEndian(frame.Slice(6, 4));
        if (sequence < minimumSequence)
        {
            return FrameRejection.SequenceNotAdvancing;
        }

        // Checked last, so a malformed header is named for what it is rather than
        // reported as a checksum failure.
        var expected = BinaryPrimitives.ReadUInt16BigEndian(frame[^CrcBytes..]);
        if (Crc16Ccitt(frame[..^CrcBytes]) != expected)
        {
            return FrameRejection.CrcMismatch;
        }

        decoded = new DecodedFrame(type, sequence, frame.Slice(HeaderBytes, payloadLength).ToArray());
        return FrameRejection.None;
    }
}
