// Placeholder adapters for protocols that aren't commissioned. They refuse, loudly and
// honestly.

using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Protocols;

public abstract class GatedIndustrialAdapter(string adapterId, string protocol) : IProtocolAdapter
{
    public string AdapterId { get; } = adapterId;

    public string Protocol { get; } = protocol;

    public abstract ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken);

    public ValueTask<AdapterAcknowledgement> PrepareAsync(
        SemanticCommandEnvelope command,
        CancellationToken cancellationToken) =>
        throw new InvalidOperationException(
            $"{Protocol} live command path is gated until certificate, allowlist, simulator, negative-path, and HIL conformance evidence is accepted.");

    public async IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await Task.CompletedTask.ConfigureAwait(false);
        cancellationToken.ThrowIfCancellationRequested();
        yield break;
    }

    public ValueTask ReconcileAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return ValueTask.CompletedTask;
    }
}

public sealed class Mqtt5ProtocolAdapter : GatedIndustrialAdapter
{
    public Mqtt5ProtocolAdapter() : base("CH1-ADP-MQTT-0001", "MQTT5")
    {
    }

    public override ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken) =>
        throw new InvalidOperationException("MQTT 5 device certificate and topic ACL configuration is not commissioned.");
}

/// <summary>
/// OPC UA while it is not commissioned. <see cref="OpcUaProtocolAdapter"/> is the live one;
/// this is what a deployment with no endpoint, certificate authority, certificate or key
/// gets instead, and its contract is refusal.
/// </summary>
public sealed class OpcUaGatedAdapter : GatedIndustrialAdapter
{
    public OpcUaGatedAdapter() : base("CH1-ADP-OPCUA-0001", "OPCUA")
    {
    }

    public override ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken) =>
        throw new InvalidOperationException("OPC UA trust list, SignAndEncrypt policy, and S7 runtime capability are not commissioned.");
}

/// <summary>
/// Modbus while it is not commissioned. <see cref="ModbusProtocolAdapter"/> is the live one;
/// this is what a deployment with no controller host gets instead, and its contract is
/// refusal.
/// </summary>
public sealed class ModbusGatedAdapter : GatedIndustrialAdapter
{
    public ModbusGatedAdapter() : base("CH1-ADP-MODBUS-0001", "MODBUS")
    {
    }

    public override ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken) =>
        throw new InvalidOperationException("Allowlisted Modbus semantic handshake map is not commissioned.");
}

