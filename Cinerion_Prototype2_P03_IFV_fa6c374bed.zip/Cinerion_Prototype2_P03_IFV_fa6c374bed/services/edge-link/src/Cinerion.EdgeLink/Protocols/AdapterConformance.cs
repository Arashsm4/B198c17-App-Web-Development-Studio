// The conformance suite every protocol adapter must pass before it's allowed to serve.

using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// The executable conformance suite every protocol adapter must pass, and the separate
/// one a gated adapter must pass while it is gated.
/// </summary>
/// <remarks>
/// <para>
/// CH1-COM-FR-0002 requires EdgeLink to support replaceable protocol adapters without
/// changing domain or inspection logic. Replaceability is not established by declaring an
/// interface — it is established by more than one adapter satisfying the same checks, run
/// by the same code, with the domain unchanged between them. That is what this is for,
/// and it is the evidence the MQTT, OPC UA and Modbus adapters will have to produce
/// against real equipment before their live command paths are opened.
/// </para>
/// <para>
/// A gated adapter is not exempt; it is held to a different, stricter contract. It must
/// refuse, refuse for a stated reason, and above all refuse to prepare a command. An
/// adapter that quietly returned an acknowledgement while uncommissioned would be the
/// exact fake-success failure the whole gating scheme exists to prevent, so
/// <see cref="RunGatedAsync"/> checks the refusals rather than skipping the adapter.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0002, CH1-COM-FR-0006, CH1-COM-FR-0008, CH1-CMD-FR-0001</requirements>
public static class AdapterConformance
{
    /// <summary>Checks any operational adapter must pass.</summary>
    public static async Task<IReadOnlyList<ConformanceResult>> RunAsync(
        IProtocolAdapter adapter,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(adapter);
        var results = new List<ConformanceResult>();

        results.Add(new ConformanceResult(
            "ADP-01-IDENTITY",
            !string.IsNullOrWhiteSpace(adapter.AdapterId)
                && adapter.AdapterId.StartsWith("CH1-ADP-", StringComparison.Ordinal)
                && !string.IsNullOrWhiteSpace(adapter.Protocol),
            $"{adapter.AdapterId} speaking {adapter.Protocol}"));

        var manifest = await adapter.ReadCapabilityAsync(cancellationToken).ConfigureAwait(false);

        // ADP-02 the common capability model, which CH1-COM-FR-0001 requires every
        // adapter to expose in the same shape whatever it speaks underneath.
        var manifestComplete =
            !string.IsNullOrWhiteSpace(manifest.SchemaVersion)
            && manifest.DeviceId.StartsWith("CH1-DEV-", StringComparison.Ordinal)
            && !string.IsNullOrWhiteSpace(manifest.DeviceType)
            && !string.IsNullOrWhiteSpace(manifest.FirmwareVersion)
            && !string.IsNullOrWhiteSpace(manifest.ConfigurationRevision)
            && manifest.SupportedCommands.Count > 0
            && manifest.TelemetryChannels.Count > 0
            && manifest.ProtocolEndpoints.Count > 0
            && !string.IsNullOrWhiteSpace(manifest.SecurityProfile);
        results.Add(new ConformanceResult(
            "ADP-02-CAPABILITY-MANIFEST",
            manifestComplete,
            $"schema {manifest.SchemaVersion}, device {manifest.DeviceId}, " +
            $"{manifest.SupportedCommands.Count} commands, {manifest.TelemetryChannels.Count} channels, " +
            $"security {manifest.SecurityProfile}"));

        // ADP-03 telemetry channels carry an engineering unit and are not writable.
        // A writable telemetry channel would be a register the domain could poke, which
        // is precisely what CH1-CMD-FR-0001 forbids.
        results.Add(new ConformanceResult(
            "ADP-03-CHANNELS-READ-ONLY",
            manifest.TelemetryChannels.All(channel =>
                !channel.Writable && !string.IsNullOrWhiteSpace(channel.Unit)),
            manifest.TelemetryChannels.Any(channel => channel.Writable)
                ? "a telemetry channel is declared writable"
                : $"{manifest.TelemetryChannels.Count} channels, all read-only and united"));

        // ADP-04 commands are semantic names, never register addresses.
        results.Add(new ConformanceResult(
            "ADP-04-SEMANTIC-COMMANDS",
            manifest.SupportedCommands.All(command =>
                command.Length > 0
                && command.All(character => char.IsAsciiLetterUpper(character) || char.IsAsciiDigit(character) || character == '_')),
            string.Join(", ", manifest.SupportedCommands)));

        // ADP-05 an expired command is refused, and is not held for later. CH1-COM-FR-0007
        // permits store-and-forward for telemetry and forbids it for commands.
        var expired = await adapter
            .PrepareAsync(Envelope(1_000, DateTimeOffset.UtcNow.AddSeconds(-1)), cancellationToken)
            .ConfigureAwait(false);
        results.Add(new ConformanceResult(
            "ADP-05-EXPIRED-REFUSED",
            !expired.Accepted && expired.ReasonCode.Length > 0,
            $"{expired.ReasonCode}"));

        // ADP-06 a replayed sequence is refused. CH1-COM-FR-0010 makes duplicate
        // suppression a gateway obligation, not a hope about the network.
        var expiry = DateTimeOffset.UtcNow.AddMinutes(5);
        var first = await adapter.PrepareAsync(Envelope(2_000, expiry), cancellationToken).ConfigureAwait(false);
        var replay = await adapter.PrepareAsync(Envelope(2_000, expiry), cancellationToken).ConfigureAwait(false);
        results.Add(new ConformanceResult(
            "ADP-06-REPLAY-REFUSED",
            first.Accepted && !replay.Accepted,
            first.Accepted
                ? $"the repeat was refused as {replay.ReasonCode}"
                : $"the first attempt was already refused as {first.ReasonCode}, so replay was not tested"));

        // ADP-07 an acknowledgement is an acknowledgement, never an execution. Every
        // physical effect belongs to the local confirmation chain.
        results.Add(new ConformanceResult(
            "ADP-07-NO-PHYSICAL-CLAIM",
            first.Accepted
                && !string.Equals(first.ControllerState, "Executing", StringComparison.OrdinalIgnoreCase)
                && !string.Equals(first.ControllerState, "Complete", StringComparison.OrdinalIgnoreCase)
                && string.Equals(first.AdapterId, adapter.AdapterId, StringComparison.Ordinal),
            $"state {first.ControllerState}, reason {first.ReasonCode}, from {first.AdapterId}"));

        // ADP-08 a command whose type is not a semantic name is refused rather than
        // forwarded for something downstream to interpret.
        var malformed = await adapter
            .PrepareAsync(Envelope(3_000, expiry) with { CommandType = "write:40001" }, cancellationToken)
            .ConfigureAwait(false);
        results.Add(new ConformanceResult(
            "ADP-08-MALFORMED-REFUSED",
            !malformed.Accepted,
            malformed.Accepted ? "a register write was accepted as a command type" : malformed.ReasonCode));

        // ADP-09 reconnection restores nothing. CH1-COM-PRO-0001 cancels prepared
        // commands across reboot; an adapter that replayed one on reconnect would arm
        // equipment nobody asked to arm.
        await adapter.ReconcileAsync(cancellationToken).ConfigureAwait(false);
        var afterReconcile = await adapter
            .PrepareAsync(Envelope(2_000, expiry), cancellationToken)
            .ConfigureAwait(false);
        results.Add(new ConformanceResult(
            "ADP-09-RECONCILE-REPLAYS-NOTHING",
            !afterReconcile.Accepted,
            afterReconcile.Accepted
                ? "a spent sequence became acceptable again after reconciliation"
                : $"the spent sequence is still refused as {afterReconcile.ReasonCode}"));

        return results;
    }

    /// <summary>What a run of prepared-command acknowledgements took.</summary>
    /// <param name="Samples">Preparations issued.</param>
    /// <param name="Accepted">
    /// How many the controller accepted. A run that is mostly refusals measures the
    /// refusal path, which is not what CH1-NFR-PER-0003 asks about, so the count travels
    /// with the percentiles rather than being assumed.
    /// </param>
    public sealed record AcknowledgementLatency(
        int Samples,
        int Accepted,
        double P50Milliseconds,
        double P95Milliseconds,
        double P99Milliseconds,
        double WorstMilliseconds);

    /// <summary>
    /// CH1-NFR-PER-0003 - "Prepared-command acknowledgement shall be less than 750
    /// milliseconds at the 95th percentile on the reference local network."
    /// </summary>
    /// <remarks>
    /// <para>
    /// Measured where the requirement is allocated: CommandGuard/EdgeLink, from the moment
    /// the gateway issues a preparation to the moment the controller's answer is in hand.
    /// Everything in between is real - the session, the transport, the method call or
    /// register exchange, and the guard's own evaluation.
    /// </para>
    /// <para>
    /// <b>Accepted preparations, not refused ones.</b> A refusal is a cheaper path through
    /// the guard and measuring it would flatter the result. Repeating an acceptance is
    /// possible because FB_CH1_CommandGuard housekeeps at the top of every evaluation: a
    /// preparation that has lapsed returns the guard to Idle on its own. Each sample
    /// therefore carries a short expiry and the next one waits past it, which is what makes
    /// a percentile of the accepted path obtainable at all - one acceptance per controller
    /// lifetime would be a sample of one.
    /// </para>
    /// <para>
    /// <b>This runs before the conformance suite, and it has to.</b> The suite's ADP-05
    /// accepts a preparation with a five-minute expiry, which leaves the guard Prepared for
    /// five minutes - so a measurement placed after it found a busy guard and every one of
    /// its twenty samples was refused as STATE_INVALID. That produced a p95 of 3 ms off the
    /// refusal path, which is a fast number about the wrong thing. It was caught because the
    /// accepted count travels with the percentile.
    /// </para>
    /// <para>
    /// Its sequence numbers are therefore BELOW the suite's, so the suite's own preparations
    /// are still ahead of the last one spent here and none of its checks changes meaning.
    /// The final sample is waited out like the others, so the guard is Idle again before the
    /// suite's first preparation arrives.
    /// </para>
    /// <para>
    /// <b>What this is not.</b> It is not evidence about the real S7-1200 G2. The CPU's own
    /// scan cycle is part of the number this requirement ultimately governs, and a stand-in
    /// does not have one. What is measured here is the platform half on the reference
    /// network, which is the half CH1 owns.
    /// </para>
    /// </remarks>
    public static async Task<AcknowledgementLatency> MeasureAcknowledgementLatencyAsync(
        IProtocolAdapter adapter,
        int samples,
        TimeProvider timeProvider,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(adapter);
        ArgumentNullException.ThrowIfNull(timeProvider);
        ArgumentOutOfRangeException.ThrowIfLessThan(samples, 1);

        // Long enough that a slow round trip cannot lapse mid-flight - the observed p95 is
        // tens of milliseconds, so this is an order of magnitude of headroom - and short
        // enough that waiting it out between samples costs a fraction of a second. A round
        // trip that did exceed it would be refused as EXPIRED and show up in the accepted
        // count rather than silently becoming a fast sample.
        var life = TimeSpan.FromMilliseconds(200);
        var latencies = new List<double>(samples);
        var accepted = 0;

        for (var index = 0; index < samples; index++)
        {
            var envelope = Envelope(index + 1, timeProvider.GetUtcNow().Add(life));

            var startedAt = timeProvider.GetTimestamp();
            var acknowledgement = await adapter.PrepareAsync(envelope, cancellationToken).ConfigureAwait(false);
            latencies.Add(timeProvider.GetElapsedTime(startedAt).TotalMilliseconds);

            if (acknowledgement.Accepted)
            {
                accepted++;
            }

            // Past the expiry, so the guard housekeeps back to Idle and the next sample
            // measures an acceptance rather than a state refusal. Waited after the LAST
            // sample too: whatever runs next would otherwise meet a guard this measurement
            // left Prepared, and the conformance suite runs next.
            await Task.Delay(life + TimeSpan.FromMilliseconds(40), cancellationToken).ConfigureAwait(false);
        }

        latencies.Sort();
        double Percentile(double fraction) =>
            latencies[Math.Min(latencies.Count - 1, (int)Math.Floor(fraction * latencies.Count))];

        return new AcknowledgementLatency(
            latencies.Count,
            accepted,
            Percentile(0.50),
            Percentile(0.95),
            Percentile(0.99),
            latencies[^1]);
    }

    /// <summary>
    /// Checks a gated adapter must pass while it is gated. The contract is refusal, and
    /// a refusal that is not stated is indistinguishable from a fault.
    /// </summary>
    public static async Task<IReadOnlyList<ConformanceResult>> RunGatedAsync(
        IProtocolAdapter adapter,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(adapter);
        var results = new List<ConformanceResult>
        {
            new(
                "GATE-01-IDENTITY",
                adapter.AdapterId.StartsWith("CH1-ADP-", StringComparison.Ordinal)
                    && !string.IsNullOrWhiteSpace(adapter.Protocol),
                $"{adapter.AdapterId} speaking {adapter.Protocol}"),
        };

        // GATE-02 the command path refuses, and says why. This is the one that matters:
        // an uncommissioned adapter that acknowledged a command would have the domain
        // believe a controller had accepted it.
        string prepareRefusal;
        var prepareRefused = false;
        try
        {
            var acknowledgement = await adapter
                .PrepareAsync(Envelope(1, DateTimeOffset.UtcNow.AddMinutes(5)), cancellationToken)
                .ConfigureAwait(false);
            prepareRefusal = acknowledgement.Accepted
                ? "ACCEPTED A COMMAND WHILE GATED"
                : $"refused as {acknowledgement.ReasonCode}";
            prepareRefused = !acknowledgement.Accepted;
        }
        catch (InvalidOperationException error)
        {
            prepareRefused = true;
            prepareRefusal = error.Message;
        }

        results.Add(new ConformanceResult("GATE-02-PREPARE-REFUSED", prepareRefused, prepareRefusal));

        // GATE-03 the capability path refuses too, and names what is not commissioned.
        // A manifest from an uncommissioned adapter would enter the trust registry.
        string capabilityRefusal;
        var capabilityRefused = false;
        try
        {
            var manifest = await adapter.ReadCapabilityAsync(cancellationToken).ConfigureAwait(false);
            capabilityRefusal = $"PUBLISHED A MANIFEST WHILE GATED: {manifest.DeviceId}";
        }
        catch (InvalidOperationException error)
        {
            capabilityRefused = error.Message.Length > 20;
            capabilityRefusal = error.Message;
        }

        results.Add(new ConformanceResult("GATE-03-CAPABILITY-REFUSED", capabilityRefused, capabilityRefusal));

        // GATE-04 telemetry is empty rather than invented. Nothing downstream should be
        // able to tell an uncommissioned adapter from one that has no readings yet by
        // receiving a plausible number.
        var samples = 0;
        await foreach (var _ in adapter.ReadTelemetryAsync(cancellationToken).ConfigureAwait(false))
        {
            samples++;
            if (samples > 0)
            {
                break;
            }
        }

        results.Add(new ConformanceResult(
            "GATE-04-NO-INVENTED-TELEMETRY",
            samples == 0,
            samples == 0 ? "no samples produced" : $"{samples} samples produced while gated"));

        return results;
    }

    private static SemanticCommandEnvelope Envelope(long sequence, DateTimeOffset expiry) => new(
        "1.0.0",
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        sequence,
        new string('a', 64),
        "CFG-REFAB-P01-R01",
        expiry,
        "RUN_DIMENSIONAL_TEST",
        new Dictionary<string, object>());
}
