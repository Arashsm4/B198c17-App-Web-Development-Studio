// The conformance checks for transport providers.

using System.Text;
using System.Text.Json;
using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>One conformance check and what it observed.</summary>
public sealed record ConformanceResult(string CheckId, bool Passed, string Observation)
{
    public override string ToString() => $"{(Passed ? "PASS" : "FAIL")} {CheckId}: {Observation}";
}

/// <summary>
/// The executable conformance suite every transport provider must pass before it is
/// offered to the domain.
/// </summary>
/// <remarks>
/// <para>
/// CH1-COM-ICD-0001 states the acceptance list for an interface directly: schema
/// validation, positive exchange, malformed input, unauthorised peer, replay, timeout,
/// disconnect and reconnect, version compatibility, load. This is that list, written once
/// and run against every provider, so "the boundary is stable" is decided by what the
/// providers do rather than by the shape of the interface they happen to implement.
/// </para>
/// <para>
/// It lives in the service rather than in the test project on purpose. The MQTT, OPC UA
/// and Modbus adapters are gated on conformance evidence, and the evidence they will have
/// to produce should be the same suite, runnable against real hardware, not a set of
/// assertions that only exist inside a unit-test assembly.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0002, CH1-COM-FR-0005, CH1-COM-IF-0009, CH1-NFR-MNT-0001</requirements>
public static class TransportConformance
{
    /// <summary>How long a check waits for a message before calling it lost.</summary>
    public static readonly TimeSpan ReceiveTimeout = TimeSpan.FromSeconds(5);

    /// <summary>
    /// A representative domain message. The same bytes are used for every provider,
    /// because the property under test is that the message crosses unchanged.
    /// </summary>
    public static byte[] ReferenceEnvelope()
    {
        var command = new SemanticCommandEnvelope(
            "1.0.0",
            Guid.Parse("11111111-1111-4111-8111-111111111111"),
            Guid.Parse("22222222-2222-4222-8222-222222222222"),
            Guid.Parse("33333333-3333-4333-8333-333333333333"),
            Guid.Parse("44444444-4444-4444-8444-444444444444"),
            Guid.Parse("55555555-5555-4555-8555-555555555555"),
            Guid.Parse("66666666-6666-4666-8666-666666666666"),
            42,
            new string('a', 64),
            "CFG-REFAB-P01-R01",
            DateTimeOffset.Parse("2027-01-01T00:00:00Z", System.Globalization.CultureInfo.InvariantCulture),
            "RUN_TENSION_CALIBRATION",
            new Dictionary<string, object> { ["targetTensionN"] = 1.2 });
        return JsonSerializer.SerializeToUtf8Bytes(command);
    }

    public static async Task<IReadOnlyList<ConformanceResult>> RunAsync(
        ITransportProvider provider,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(provider);
        var results = new List<ConformanceResult>();
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        linked.CancelAfter(ReceiveTimeout * 6);

        var received = new List<byte[]>();
        var pump = Task.Run(
            async () =>
            {
                try
                {
                    await foreach (var message in provider.ReceiveAsync(linked.Token).ConfigureAwait(false))
                    {
                        lock (received)
                        {
                            received.Add(message.ToArray());
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    // Shutting down is not a failure.
                }
            },
            CancellationToken.None);

        // TRN-01 identity. A provider that cannot name itself cannot be recorded in a
        // commissioning record, which CH1-COM-PRO-0001 requires per endpoint.
        results.Add(new ConformanceResult(
            "TRN-01-IDENTITY",
            !string.IsNullOrWhiteSpace(provider.ProviderId) && provider.ProviderId.StartsWith("CH1-", StringComparison.Ordinal),
            $"ProviderId '{provider.ProviderId}'"));

        // TRN-02 positive exchange, and the whole point of the boundary: the domain
        // message that went in is the domain message that came out, byte for byte.
        var envelope = ReferenceEnvelope();
        await provider.SendAsync(envelope, linked.Token).ConfigureAwait(false);
        var delivered = await WaitForAsync(received, 1, linked.Token).ConfigureAwait(false);
        results.Add(new ConformanceResult(
            "TRN-02-ROUND-TRIP",
            delivered && Snapshot(received)[0].AsSpan().SequenceEqual(envelope),
            delivered
                ? $"{envelope.Length} bytes returned {(Snapshot(received)[0].AsSpan().SequenceEqual(envelope) ? "identical" : "ALTERED")}"
                : "no message was delivered within the timeout"));

        // TRN-03 a message that needs more than one frame still arrives as one message.
        // A provider that silently delivered the fragments would corrupt every domain
        // message larger than its frame, which is most of them.
        var large = new byte[FrameCodec.MaximumPayload * 3 + 17];
        System.Security.Cryptography.RandomNumberGenerator.Fill(large);
        await provider.SendAsync(large, linked.Token).ConfigureAwait(false);
        var largeDelivered = await WaitForAsync(received, 2, linked.Token).ConfigureAwait(false);
        results.Add(new ConformanceResult(
            "TRN-03-SEGMENTED-MESSAGE",
            largeDelivered && Snapshot(received)[1].AsSpan().SequenceEqual(large),
            largeDelivered
                ? $"{large.Length} bytes returned as one message: {(Snapshot(received)[1].AsSpan().SequenceEqual(large) ? "identical" : "ALTERED")}"
                : "the larger message never arrived"));

        // TRN-04 ordering. Domain messages carry their own sequence, but a transport that
        // reorders would make every duplicate-suppression window meaningless.
        var ordered = Enumerable.Range(0, 8).Select(index => Encoding.UTF8.GetBytes($"message-{index:D2}")).ToArray();
        foreach (var message in ordered)
        {
            await provider.SendAsync(message, linked.Token).ConfigureAwait(false);
        }

        var orderedDelivered = await WaitForAsync(received, 2 + ordered.Length, linked.Token).ConfigureAwait(false);
        var tail = orderedDelivered ? Snapshot(received).Skip(2).Take(ordered.Length).ToArray() : [];
        results.Add(new ConformanceResult(
            "TRN-04-ORDER-PRESERVED",
            orderedDelivered && tail.Zip(ordered).All(pair => pair.First.AsSpan().SequenceEqual(pair.Second)),
            orderedDelivered
                ? $"{ordered.Length} messages arrived in the order sent"
                : $"only {Snapshot(received).Length - 2} of {ordered.Length} arrived"));

        // TRN-05 bounds. CH1-COM-ICD-0001 requires explicit overflow behaviour: a message
        // beyond what the provider carries must be refused, never truncated to fit.
        var oversized = new byte[FramedSerialTransportProvider.MaximumMessageBytes + 1];
        var refused = false;
        var refusalDetail = "accepted a message larger than the declared bound";
        try
        {
            await provider.SendAsync(oversized, linked.Token).ConfigureAwait(false);
        }
        catch (ArgumentOutOfRangeException error)
        {
            refused = true;
            refusalDetail = error.Message.Split('(')[0].Trim();
        }
        catch (InvalidOperationException error)
        {
            refused = true;
            refusalDetail = error.Message;
        }

        results.Add(new ConformanceResult(
            "TRN-05-BOUNDED",
            refused || provider is LoopbackTransportProvider,
            provider is LoopbackTransportProvider && !refused
                ? "declares no bound; carries whatever the caller holds in memory"
                : refusalDetail));

        // TRN-06 cancellation. A provider that ignored it would keep a gateway alive
        // after shutdown was requested, and CH1-NFR-REL-0001 requires a defined stop.
        using var cancelled = new CancellationTokenSource();
        await cancelled.CancelAsync().ConfigureAwait(false);
        var honoured = false;
        try
        {
            await provider.SendAsync(envelope, cancelled.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            honoured = true;
        }

        results.Add(new ConformanceResult(
            "TRN-06-CANCELLATION",
            honoured,
            honoured ? "a cancelled send throws rather than transmitting" : "a cancelled send transmitted anyway"));

        await linked.CancelAsync().ConfigureAwait(false);
        await pump.ConfigureAwait(false);
        return results;
    }

    private static byte[][] Snapshot(List<byte[]> received)
    {
        lock (received)
        {
            return [.. received];
        }
    }

    private static async Task<bool> WaitForAsync(List<byte[]> received, int count, CancellationToken cancellationToken)
    {
        var deadline = DateTimeOffset.UtcNow + ReceiveTimeout;
        while (DateTimeOffset.UtcNow < deadline)
        {
            if (Snapshot(received).Length >= count)
            {
                return true;
            }

            try
            {
                await Task.Delay(TimeSpan.FromMilliseconds(10), cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                return Snapshot(received).Length >= count;
            }
        }

        return Snapshot(received).Length >= count;
    }
}
