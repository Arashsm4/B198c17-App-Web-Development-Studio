// A pretend MQTT device with its own certificate, for testing the MQTT edge.

using System.Formats.Cbor;
using System.Security.Cryptography.X509Certificates;
using Cinerion.EdgeLink.Contracts;
using MQTTnet;
using MQTTnet.Formatter;
using MQTTnet.Protocol;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// The other end of CH1-COM-IF-0005: a device speaking the CH1 CBOR envelope over MQTT 5
/// with its own certificate, so the MQTT edge can be exercised end to end without the
/// ESP32-S3 board in hand.
/// </summary>
/// <remarks>
/// <para>
/// It is a <em>separate MQTT client with a separate certificate</em>, not a shortcut
/// inside the adapter. That is the whole point: the broker authenticates it as
/// <c>CH1-DEV-CELL-0001</c> and applies the device half of the topic ACL to it, so a
/// device attempting to publish where it may not, or to read another device's commands,
/// is refused by the broker rather than by agreement between two halves of one process.
/// The firmware in <c>firmware/esp32</c> encodes the same envelope, and the host test
/// there asserts the same bytes.
/// </para>
/// <para>
/// It is a Simulation-profile component, on the same terms as Control Core's simulated
/// telemetry source: it produces readings marked <c>Simulated</c>, it acknowledges a
/// command by reporting the controller state a real controller would report at that
/// point — <c>AwaitingCredential</c> — and it never claims execution. A simulator that
/// answered "Complete" would be teaching the domain that a physical effect had happened.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-IF-0005, CH1-COM-FR-0006, CH1-CMD-FR-0001, CH1-SAF-FR-0001</requirements>
public sealed partial class MqttDeviceSimulator(
    MqttAdapterOptions options,
    ILogger<MqttDeviceSimulator> logger,
    IConfiguration configuration,
    TimeProvider? timeProvider = null) : BackgroundService
{
    private readonly TimeProvider _timeProvider = timeProvider ?? TimeProvider.System;
    private IMqttClient? _client;
    private long _telemetrySequence;
    private long _acknowledgementSequence;

    /// <summary>The device's own identity, which is a different certificate from EdgeLink's.</summary>
    private string CertificatePath => configuration["CINERION_MQTT_DEVICE_CERT"]
        ?? throw new InvalidOperationException("CINERION_MQTT_DEVICE_CERT is required to run the device simulator.");

    private string PrivateKeyPath => configuration["CINERION_MQTT_DEVICE_KEY"]
        ?? throw new InvalidOperationException("CINERION_MQTT_DEVICE_KEY is required to run the device simulator.");

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _client = new MqttClientFactory().CreateMqttClient();
        _client.ApplicationMessageReceivedAsync += OnCommandAsync;

        using var authority = X509CertificateLoader.LoadCertificateFromFile(options.CertificateAuthorityPath);
        var identity = X509Certificate2.CreateFromPemFile(CertificatePath, PrivateKeyPath);
        var usable = X509CertificateLoader.LoadPkcs12(identity.Export(X509ContentType.Pkcs12), null);
        identity.Dispose();

        await _client.ConnectAsync(
            new MqttClientOptionsBuilder()
                .WithTcpServer(options.Host, options.Port)
                .WithProtocolVersion(MqttProtocolVersion.V500)
                .WithClientId(options.DeviceId)
                .WithCleanSession()
                .WithTlsOptions(tls => tls
                    .UseTls()
                    .WithSslProtocols(System.Security.Authentication.SslProtocols.Tls13)
                    .WithClientCertificates([usable])
                    .WithTrustChain([authority])
                    .WithAllowUntrustedCertificates(false)
                    .WithIgnoreCertificateChainErrors(false))
                .Build(),
            stoppingToken).ConfigureAwait(false);

        // Its own command path only. The ACL would refuse any other, which is the check
        // worth having: a device that could read another device's commands would be a
        // device that could act on them.
        await _client.SubscribeAsync(
            new MqttClientSubscribeOptionsBuilder()
                .WithTopicFilter($"{Ch1MqttTopics.Commands(options.DeviceId)}/#", MqttQualityOfServiceLevel.AtLeastOnce)
                .Build(),
            stoppingToken).ConfigureAwait(false);

        await PublishCapabilityAsync(stoppingToken).ConfigureAwait(false);
        LogDeviceOnline(logger, options.DeviceId);

        var heartbeatDue = _timeProvider.GetUtcNow();
        while (!stoppingToken.IsCancellationRequested)
        {
            await PublishTelemetryAsync(stoppingToken).ConfigureAwait(false);
            if (_timeProvider.GetUtcNow() >= heartbeatDue)
            {
                await PublishHeartbeatAsync(stoppingToken).ConfigureAwait(false);
                heartbeatDue = _timeProvider.GetUtcNow().AddSeconds(15);
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(1), _timeProvider, stoppingToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }
    }

    private async Task PublishCapabilityAsync(CancellationToken cancellationToken)
    {
        (string Channel, string Unit)[] channels =
        [
            ("temperature", "degC"),
            ("position", "mm"),
            ("vibration_rms", "m/s2"),
        ];

        var writer = new CborWriter(CborConformanceMode.Canonical, convertIndefiniteLengthEncodings: true);
        writer.WriteStartMap(13);
        WriteHeader(writer, Ch1MessageEnvelope.Types.Capability, 0);
        writer.WriteTextString("payload");
        writer.WriteStartMap(7);
        writer.WriteTextString("configurationRevision");
        writer.WriteTextString(ConfigurationRevision);
        writer.WriteTextString("deviceId");
        writer.WriteTextString(options.DeviceId);
        writer.WriteTextString("deviceType");
        writer.WriteTextString("ESP32-S3-CellController");
        writer.WriteTextString("firmwareVersion");
        writer.WriteTextString(FirmwareVersion);
        writer.WriteTextString("securityProfile");
        writer.WriteTextString("MTLS-DEVICE-CERTIFICATE-TOPIC-ACL");
        writer.WriteTextString("supportedCommands");
        writer.WriteStartArray(2);
        writer.WriteTextString("RUN_TENSION_CALIBRATION");
        writer.WriteTextString("RUN_DIMENSIONAL_TEST");
        writer.WriteEndArray();
        writer.WriteTextString("telemetryChannels");
        writer.WriteStartArray(channels.Length);
        foreach (var (channel, unit) in channels)
        {
            writer.WriteStartMap(2);
            writer.WriteTextString("channelId");
            writer.WriteTextString(channel);
            writer.WriteTextString("unit");
            writer.WriteTextString(unit);
            writer.WriteEndMap();
        }

        writer.WriteEndArray();
        writer.WriteEndMap();
        writer.WriteEndMap();

        // Retained, so a gateway that starts after the device still learns what it is.
        // Telemetry and commands are never retained: a capability announcement is a
        // standing fact about the device, which is the one thing that should survive.
        await PublishAsync(Ch1MqttTopics.Capability(options.DeviceId), writer.Encode(), true, cancellationToken)
            .ConfigureAwait(false);
    }

    private async Task PublishTelemetryAsync(CancellationToken cancellationToken)
    {
        var sequence = Interlocked.Increment(ref _telemetrySequence);
        var point = new TelemetryPoint(
            options.DeviceId,
            "temperature",
            22.4 + Math.Sin(sequence / 30d) * 0.4,
            "degC",
            "Simulated",
            _timeProvider.GetUtcNow(),
            sequence);

        await PublishAsync(
            $"{Ch1MqttTopics.Telemetry(options.DeviceId)}/temperature",
            Ch1MessageEnvelope.EncodeTelemetry(
                point,
                options.DeviceId,
                options.ClientId,
                options.ProjectId,
                options.CellId,
                options.AssetId,
                Guid.NewGuid(),
                Guid.NewGuid(),
                _timeProvider.GetUtcNow()),
            retain: false,
            cancellationToken).ConfigureAwait(false);
    }

    private async Task PublishHeartbeatAsync(CancellationToken cancellationToken)
    {
        var writer = new CborWriter(CborConformanceMode.Canonical, convertIndefiniteLengthEncodings: true);
        writer.WriteStartMap(13);
        WriteHeader(writer, Ch1MessageEnvelope.Types.Heartbeat, Interlocked.Increment(ref _telemetrySequence));
        writer.WriteTextString("payload");
        writer.WriteStartMap(3);
        // CH1-COM-ICD-0001: heartbeats include firmware and configuration revision, so a
        // controller running something other than the released baseline is visible
        // without anybody having to ask it.
        writer.WriteTextString("configurationRevision");
        writer.WriteTextString(ConfigurationRevision);
        writer.WriteTextString("firmwareVersion");
        writer.WriteTextString(FirmwareVersion);
        writer.WriteTextString("uptimeSeconds");
        writer.WriteInt64((long)(_timeProvider.GetUtcNow() - Process).TotalSeconds);
        writer.WriteEndMap();
        writer.WriteEndMap();

        await PublishAsync(Ch1MqttTopics.Heartbeat(options.DeviceId), writer.Encode(), false, cancellationToken)
            .ConfigureAwait(false);
    }

    private static readonly DateTimeOffset Process = DateTimeOffset.UtcNow;

    /// <summary>What the firmware in firmware/esp32 reports, so the two agree.</summary>
    private const string FirmwareVersion = "0.1.0-prototype.2";

    private const string ConfigurationRevision = "CFG-REFAB-P01-R01";

    private async Task OnCommandAsync(MqttApplicationMessageReceivedEventArgs args)
    {
        Ch1MessageEnvelope.Decoded command;
        try
        {
            command = Ch1MessageEnvelope.Decode(
                System.Buffers.BuffersExtensions.ToArray(args.ApplicationMessage.Payload));
        }
        catch (Ch1EnvelopeException error)
        {
            LogDeviceRefused(logger, error.Code);
            return;
        }

        var commandId = Ch1MessageEnvelope.PayloadUuid(command.Payload, "idempotencyKey");
        var accepted = command.ExpiresAt is { } expiry && expiry > _timeProvider.GetUtcNow();

        // The controller acknowledges a prepared intent and stops there. What follows is
        // a cryptographic credential proof and a physical button edge observed locally,
        // neither of which anything on this link can supply.
        var acknowledgement = new AdapterAcknowledgement(
            commandId,
            accepted,
            accepted ? "AwaitingCredential" : "Idle",
            accepted ? "PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION" : "COMMAND_EXPIRED",
            _timeProvider.GetUtcNow(),
            "CH1-DEV-CELL-0001");

        await PublishAsync(
            $"{Ch1MqttTopics.Acknowledgements(options.DeviceId)}/{commandId:N}",
            Ch1MessageEnvelope.EncodeAcknowledgement(
                acknowledgement,
                command.CorrelationId,
                options.DeviceId,
                options.ClientId,
                options.ProjectId,
                options.CellId,
                options.AssetId,
                Interlocked.Increment(ref _acknowledgementSequence)),
            retain: false,
            CancellationToken.None).ConfigureAwait(false);
    }

    private void WriteHeader(CborWriter writer, string type, long sequence)
    {
        writer.WriteTextString("assetId");
        writer.WriteByteString(options.AssetId.ToByteArray());
        writer.WriteTextString("cellId");
        writer.WriteByteString(options.CellId.ToByteArray());
        writer.WriteTextString("correlationId");
        writer.WriteByteString(Guid.NewGuid().ToByteArray());
        writer.WriteTextString("destination");
        writer.WriteTextString(options.ClientId);
        writer.WriteTextString("messageId");
        writer.WriteByteString(Guid.NewGuid().ToByteArray());
        writer.WriteTextString("projectId");
        writer.WriteByteString(options.ProjectId.ToByteArray());
        writer.WriteTextString("schema");
        writer.WriteTextString(Ch1MessageEnvelope.SchemaVersion);
        writer.WriteTextString("sentAt");
        writer.WriteInt64(_timeProvider.GetUtcNow().ToUnixTimeMilliseconds());
        writer.WriteTextString("sequence");
        writer.WriteInt64(sequence);
        writer.WriteTextString("source");
        writer.WriteTextString(options.DeviceId);
        writer.WriteTextString("timeQuality");
        writer.WriteTextString("Synchronised");
        writer.WriteTextString("type");
        writer.WriteTextString(type);
    }

    [LoggerMessage(EventId = 2100, Level = LogLevel.Information,
        Message = "MQTT device simulator online as {DeviceId}; capability announced.")]
    private static partial void LogDeviceOnline(ILogger logger, string deviceId);

    [LoggerMessage(EventId = 2101, Level = LogLevel.Warning,
        Message = "Device refused a malformed command: {Code}")]
    private static partial void LogDeviceRefused(ILogger logger, string code);

    private Task<MqttClientPublishResult> PublishAsync(
        string topic, byte[] payload, bool retain, CancellationToken cancellationToken) =>
        _client!.PublishAsync(
            new MqttApplicationMessageBuilder()
                .WithTopic(topic)
                .WithPayload(payload)
                .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
                .WithRetainFlag(retain)
                .Build(),
            cancellationToken);

    public override void Dispose()
    {
        _client?.Dispose();
        base.Dispose();
    }
}
