// An alternate transport over the CH1 serial frame, proving the domain doesn't care how the
// bytes travel.

using System.Runtime.CompilerServices;
using System.Threading.Channels;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// A reference alternate transport provider: the same domain messages, carried over the
/// CH1 serial frame instead of handed straight across.
/// </summary>
/// <remarks>
/// <para>
/// CH1-COM-FR-0005 requires a future secure transport overlay to connect through a stable
/// provider boundary <em>without changing domain messages</em>. That is a claim about the
/// boundary, and until there is a second provider on the other side of it, it is only a
/// claim: one implementation can always satisfy an interface shaped around it. This
/// provider shares nothing with <see cref="LoopbackTransportProvider"/> — it frames,
/// segments, checksums and sequences every message, and refuses malformed, replayed and
/// oversized input — and both are put through the same conformance suite, so what
/// survives is a property of the boundary rather than of either implementation.
/// </para>
/// <para>
/// It moves bytes between two ends of one process. It is not a serial port, and it is not
/// a secure overlay: there is no peer authentication and no confidentiality here, because
/// CH1-COM-IF-0009 puts those in the physical link and the conduit profile. What it does
/// establish is that a provider with a genuinely different wire format needs no change to
/// the messages above it.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0004, CH1-COM-FR-0005, CH1-COM-FR-0010</requirements>
public sealed class FramedSerialTransportProvider : ITransportProvider
{
    /// <summary>
    /// The largest message this provider will carry, across however many frames. A bound
    /// is required rather than optional: reassembly holds partial messages in memory, so
    /// an unbounded one is a way to exhaust the gateway with a message that never ends.
    /// </summary>
    public const int MaximumMessageBytes = 16 * 1024;

    private readonly Channel<byte[]> _wire = Channel.CreateBounded<byte[]>(
        new BoundedChannelOptions(1024)
        {
            // Telemetry tolerates bounded loss; the alternative is unbounded memory.
            // Which end is dropped is a policy decision and is stated here rather than
            // left to the default.
            FullMode = BoundedChannelFullMode.DropOldest,
            SingleReader = false,
            SingleWriter = false,
        });

    private int _sendSequence;

    public string ProviderId => "CH1-TRN-FRAMED-0001";

    /// <summary>Frames observed on the wire, including those that were refused.</summary>
    public long FramesObserved => Interlocked.Read(ref _framesObserved);

    /// <summary>Frames refused, by reason. Diagnostics per CH1-COM-PRO-0001.</summary>
    public IReadOnlyDictionary<FrameCodec.FrameRejection, long> Rejections
    {
        get
        {
            lock (_rejectionGate)
            {
                return new Dictionary<FrameCodec.FrameRejection, long>(_rejections);
            }
        }
    }

    private long _framesObserved;
    private readonly Lock _rejectionGate = new();
    private readonly Dictionary<FrameCodec.FrameRejection, long> _rejections = [];

    public ValueTask SendAsync(ReadOnlyMemory<byte> versionedEnvelope, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (versionedEnvelope.Length > MaximumMessageBytes)
        {
            throw new ArgumentOutOfRangeException(
                nameof(versionedEnvelope),
                $"This provider carries at most {MaximumMessageBytes} bytes per message; " +
                $"{versionedEnvelope.Length} were offered. The message is refused rather than truncated.");
        }

        var payload = versionedEnvelope.Span;
        var segments = Math.Max(1, (payload.Length + FrameCodec.MaximumPayload - 1) / FrameCodec.MaximumPayload);
        for (var index = 0; index < segments; index++)
        {
            var offset = index * FrameCodec.MaximumPayload;
            var length = Math.Min(FrameCodec.MaximumPayload, payload.Length - offset);
            var type = segments == 1
                ? FrameCodec.TypeSingle
                : index == 0
                    ? FrameCodec.TypeFirst
                    : index == segments - 1
                        ? FrameCodec.TypeFinal
                        : FrameCodec.TypeContinuation;

            // Sequence numbers are per frame and strictly increasing, which is what makes
            // the receiver's replay window meaningful.
            var sequence = (uint)Interlocked.Increment(ref _sendSequence);
            var frame = FrameCodec.Encode(type, sequence, payload.Slice(offset, length));
            if (!_wire.Writer.TryWrite(frame))
            {
                throw new InvalidOperationException("Framed transport wire is closed.");
            }
        }

        return ValueTask.CompletedTask;
    }

    /// <summary>
    /// Reassembles whole messages from frames, refusing anything that does not add up.
    /// A refused frame abandons the message being reassembled rather than being skipped,
    /// because a message with a hole in it is not the message that was sent.
    /// </summary>
    public async IAsyncEnumerable<ReadOnlyMemory<byte>> ReceiveAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        uint minimumSequence = 0;
        var assembling = new List<byte>();
        var inProgress = false;

        await foreach (var frame in _wire.Reader.ReadAllAsync(cancellationToken).ConfigureAwait(false))
        {
            Interlocked.Increment(ref _framesObserved);
            var rejection = FrameCodec.TryDecode(frame, minimumSequence, out var decoded);
            if (rejection != FrameCodec.FrameRejection.None)
            {
                Record(rejection);
                assembling.Clear();
                inProgress = false;
                continue;
            }

            minimumSequence = decoded.Sequence + 1;

            switch (decoded.Type)
            {
                case FrameCodec.TypeSingle:
                    assembling.Clear();
                    inProgress = false;
                    yield return decoded.Payload;
                    break;

                case FrameCodec.TypeFirst:
                    assembling.Clear();
                    assembling.AddRange(decoded.Payload);
                    inProgress = true;
                    break;

                case FrameCodec.TypeContinuation:
                case FrameCodec.TypeFinal:
                    if (!inProgress)
                    {
                        // A continuation with no first frame is a fragment of somebody
                        // else's message, or of one whose start was refused. Dropped.
                        Record(FrameCodec.FrameRejection.TypeUnknown);
                        break;
                    }

                    if (assembling.Count + decoded.Payload.Length > MaximumMessageBytes)
                    {
                        Record(FrameCodec.FrameRejection.LengthInvalid);
                        assembling.Clear();
                        inProgress = false;
                        break;
                    }

                    assembling.AddRange(decoded.Payload);
                    if (decoded.Type == FrameCodec.TypeFinal)
                    {
                        var message = assembling.ToArray();
                        assembling.Clear();
                        inProgress = false;
                        yield return message;
                    }

                    break;

                default:
                    Record(FrameCodec.FrameRejection.TypeUnknown);
                    break;
            }
        }
    }

    /// <summary>
    /// Injects raw bytes as if they had arrived on the link, so the conformance suite can
    /// present malformed, replayed and truncated frames a well-behaved sender never would.
    /// </summary>
    public bool InjectRawFrame(ReadOnlyMemory<byte> frame) => _wire.Writer.TryWrite(frame.ToArray());

    private void Record(FrameCodec.FrameRejection rejection)
    {
        lock (_rejectionGate)
        {
            _rejections[rejection] = _rejections.GetValueOrDefault(rejection) + 1;
        }
    }
}
