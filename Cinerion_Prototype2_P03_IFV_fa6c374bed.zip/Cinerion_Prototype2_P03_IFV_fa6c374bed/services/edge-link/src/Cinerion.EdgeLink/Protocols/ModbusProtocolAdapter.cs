// The Modbus TCP adapter: reads the controller's registers and reports what it finds.

using System.Globalization;
using System.Runtime.CompilerServices;
using System.Threading.Channels;
using Cinerion.EdgeLink.Contracts;
using Microsoft.Extensions.Logging;

namespace Cinerion.EdgeLink.Protocols;

/// <summary>
/// Everything the Modbus edge needs, and nothing it can run without.
/// </summary>
/// <remarks>
/// Host and port or nothing. There is no credential to configure, because Modbus has none:
/// CH1-COM-ICD-0001 puts this link inside a controlled zone with an allowlisted map, so the
/// deployment decision is which zone the gateway is on, not which secret it holds. An
/// unconfigured Modbus edge stays gated.
/// </remarks>
public sealed record ModbusAdapterOptions(
    string Host,
    int Port,
    byte UnitIdentifier,
    string DeviceId,
    TimeSpan ExchangeTimeout)
{
    public static ModbusAdapterOptions? FromConfiguration(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var host = configuration["CINERION_MODBUS_HOST"];
        if (string.IsNullOrWhiteSpace(host))
        {
            return null;
        }

        return new ModbusAdapterOptions(
            host,
            int.TryParse(configuration["CINERION_MODBUS_PORT"], CultureInfo.InvariantCulture, out var port) ? port : 502,
            byte.TryParse(configuration["CINERION_MODBUS_UNIT"], CultureInfo.InvariantCulture, out var unit)
                ? unit
                : (byte)Ch1ModbusMap.UnitIdentifier,
            configuration["CINERION_MODBUS_DEVICE_ID"] ?? "CH1-DEV-CELL-0001",
            TimeSpan.FromSeconds(
                int.TryParse(configuration["CINERION_MODBUS_TIMEOUT_SECONDS"], CultureInfo.InvariantCulture, out var seconds)
                    ? seconds
                    : 10));
    }
}

/// <summary>
/// The live Modbus TCP adapter — CH1-COM-IF-0008, and the Modbus half of CH1-COM-IF-0022.
/// </summary>
/// <remarks>
/// <para>
/// EdgeLink's <em>fourth</em> operational adapter, and the one that makes CH1-VVT-TC-0022 a
/// statement about all three protocols it names. It is held to the same unchanged
/// <see cref="AdapterConformance"/> suite as the simulator, MQTT and OPC UA.
/// </para>
/// <para>
/// <b>Modbus authenticates nothing, and this adapter never pretends otherwise.</b> There is
/// no certificate, no identity and no encryption on this wire; CH1-COM-ICD-0001 therefore
/// terminates it inside a controlled zone behind an allowlisted map, and the manifest this
/// adapter reports names the profile as exactly that rather than borrowing a word from the
/// links that do have cryptography. What replaces authentication here is that <em>nothing
/// reachable over this link can arm anything</em>: the guard's state, its reason code and
/// its execute permit live in input registers, which no Modbus function code can write.
/// </para>
/// <para>
/// <b>The map is versioned and the version is checked.</b> CH1-COM-ICD-0001 versions Modbus
/// maps like software APIs, so a controller reporting a version this gateway was not written
/// against is refused outright — the failure mode a map change would otherwise produce is a
/// gateway reading the right addresses of the wrong map and reporting plausible numbers.
/// </para>
/// <para>
/// <b>A lost bus is a refusal, never an acceptance.</b> CH1-COM-PRO-0001 is explicit that
/// loss of bus sets quality invalid and does not imply command success, so a timeout waiting
/// for the guard's answer is reported as <c>CONTROLLER_ANSWER_TIMEOUT</c> and telemetry
/// stops rather than repeating its last value.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0002, CH1-COM-FR-0003, CH1-COM-FR-0006, CH1-COM-FR-0008, CH1-COM-FR-0010, CH1-COM-IF-0008, CH1-COM-IF-0022, CH1-COM-PRO-0001, CH1-CYB-TMD-0001</requirements>
public sealed partial class ModbusProtocolAdapter : IProtocolAdapter, IControllerStateSource, IAsyncDisposable
{
    private readonly ModbusAdapterOptions _options;
    private readonly ILogger<ModbusProtocolAdapter> _logger;
    private readonly TimeProvider _timeProvider;
    private readonly ModbusTcpClient _client;
    private readonly SemaphoreSlim _connectionGate = new(1, 1);
    private readonly HashSet<string> _announcedChannels = [];
    private readonly Channel<TelemetryPoint> _telemetry =
        Channel.CreateBounded<TelemetryPoint>(new BoundedChannelOptions(1024)
        {
            FullMode = BoundedChannelFullMode.DropOldest,
        });

    private CancellationTokenSource? _pump;
    private long _lastSequence;
    private long _telemetrySequence;

    public ModbusProtocolAdapter(
        ModbusAdapterOptions options,
        ILogger<ModbusProtocolAdapter> logger,
        TimeProvider? timeProvider = null)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _timeProvider = timeProvider ?? TimeProvider.System;
        _client = new ModbusTcpClient(
            _options.Host, _options.Port, _options.UnitIdentifier, _options.ExchangeTimeout);
    }

    public string AdapterId => "CH1-ADP-MODBUS-0001";

    public string Protocol => "MODBUS";

    // ------------------------------------------------------------------ connection

    private async ValueTask ConnectAsync(CancellationToken cancellationToken)
    {
        if (_client.Connected && _pump is not null)
        {
            return;
        }

        await _connectionGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (_client.Connected && _pump is not null)
            {
                return;
            }

            await _client.ConnectAsync(cancellationToken).ConfigureAwait(false);

            // The map version, before anything is read from it. A gateway that decoded the
            // wrong map at the right addresses would report plausible numbers about the
            // wrong things, which is worse than reporting nothing.
            var identity = await _client
                .ReadHoldingRegistersAsync(Ch1ModbusMap.ConfigMapVersion, 4, cancellationToken)
                .ConfigureAwait(false);

            if (identity[0] != Ch1ModbusMap.MapVersion)
            {
                throw new InvalidOperationException(
                    $"The controller at {_options.Host}:{_options.Port} publishes Modbus map version {identity[0]}. "
                    + $"This gateway was written against version {Ch1ModbusMap.MapVersion}, and CH1-COM-ICD-0001 "
                    + "versions Modbus maps like software APIs, so it refuses rather than decoding an unknown map.");
            }

            LogConnected(_logger, _options.Host, _options.Port, identity[0], _options.UnitIdentifier);

            _pump = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            _ = Task.Run(() => PumpTelemetryAsync(_pump.Token), CancellationToken.None);
        }
        finally
        {
            _connectionGate.Release();
        }
    }

    /// <summary>
    /// Polls the read-only telemetry band. Modbus has no subscription: a master reads, and a
    /// reading that cannot be taken is absent rather than repeated.
    /// </summary>
    private async Task PumpTelemetryAsync(CancellationToken cancellationToken)
    {
        (string Channel, ushort Register)[] channels =
        [
            ("temperature", Ch1ModbusMap.TelemetryTemperature),
            ("position", Ch1ModbusMap.TelemetryPosition),
            ("vibration_rms", Ch1ModbusMap.TelemetryVibrationRms),
        ];

        string[] units = ["degC", "mm", "m/s2"];

        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                var band = await _client
                    .ReadInputRegistersAsync(
                        Ch1ModbusMap.TelemetryTemperature,
                        Ch1ModbusMap.TelemetrySampleCounter + 1,
                        cancellationToken)
                    .ConfigureAwait(false);

                var quality = band[Ch1ModbusMap.TelemetryQuality] switch
                {
                    Ch1ModbusMap.TelemetryQualityGood => "Good",
                    Ch1ModbusMap.TelemetryQualitySimulated => "Simulated",
                    _ => "Invalid",
                };

                for (var index = 0; index < channels.Length; index++)
                {
                    var raw = (short)band[channels[index].Register];
                    var point = new TelemetryPoint(
                        _options.DeviceId,
                        channels[index].Channel,
                        raw / (double)Ch1ModbusMap.TelemetryScale,
                        units[index],
                        quality,
                        // The gateway read a register and stamped the sample; the zone
                        // carries no time of its own. Modbus has no time quality field
                        // and no clock to describe, so the honest declaration is that
                        // this gateway's clock stamped it.
                        _timeProvider.GetUtcNow(),
                        Interlocked.Increment(ref _telemetrySequence),
                        TelemetryPoint.GatewayStamped);

                    _telemetry.Writer.TryWrite(point);

                    lock (_announcedChannels)
                    {
                        if (_announcedChannels.Add(point.ChannelId))
                        {
                            LogFirstSample(_logger, point.ChannelId, point.Value, point.Unit, point.Quality);
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                return;
            }
#pragma warning disable CA1031 // Any failure to read the bus is the bus being lost, and
            // CH1-COM-PRO-0001 says what that means: quality invalid, and no repetition of
            // the last value. Narrowing this would let one socket fault stop the pump for
            // good, which is a quieter failure than the one being handled.
            catch (Exception error)
#pragma warning restore CA1031
            {
                LogBusLost(_logger, error.Message.Split('\n')[0]);
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(1), _timeProvider, cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                return;
            }
        }
    }

    // ------------------------------------------------------------------ contract

    /// <summary>
    /// The capability model as the controller publishes it, read out of the configuration
    /// band. Nothing here is composed by the adapter.
    /// </summary>
    /// <summary>
    /// What this controller says about itself - and the permissives are deliberately
    /// <b>never</b> answered.
    /// <para>
    /// The controlled Modbus profile declares <c>207 PRELIMINARY_PERMISSIVE_INVALID</c> a
    /// deferred check: the real S7-1200 G2 reads <c>UDT_CH1_Permissives</c> from wired
    /// inputs, and a zone stand-in has no wires. There is therefore no register in the
    /// controlled map that carries an interlock, and inventing one - or defaulting the
    /// fields to true because the guard looks healthy - is exactly the dangerous message
    /// CH1-SAF-FR-0003 forbids. <see cref="ControllerPermissives.NotReported"/> is the
    /// honest answer, and Control Core resolves such a cell as <b>not permissive whatever
    /// the individual fields say</b>.
    /// </para>
    /// <para>
    /// Implementing this at all is what makes that refusal observable end to end. Until now
    /// only the attack probe could produce an unanswered permissive, so the safe behaviour
    /// was asserted against a synthetic message rather than against a real controller that
    /// genuinely cannot answer.
    /// </para>
    /// </summary>
    /// <requirements>CH1-COM-IF-0003, CH1-SAF-FR-0003, CH1-MON-FR-0003, CH1-COM-FR-0001</requirements>
    public async ValueTask<ControllerStateObservation> ReadControllerStateAsync(CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);

        var configuration = await _client
            .ReadHoldingRegistersAsync(Ch1ModbusMap.ConfigurationBandStart, 72, cancellationToken)
            .ConfigureAwait(false);
        var answer = await ReadAnswerAsync(cancellationToken).ConfigureAwait(false);

        return BuildControllerState(configuration, answer, _timeProvider.GetUtcNow());
    }

    /// <summary>
    /// The decoding, separated from the wire so it can be exercised without a controller.
    /// <para>
    /// Public rather than private, deliberately: the safety-relevant property - that this
    /// adapter can never report an answered permissive, whatever the controller puts in its
    /// registers - is a property of this function, and a property that matters that much
    /// should be assertable without standing up a controlled zone. The seam takes register
    /// bands rather than a connection, so a test drives exactly what the wire would deliver.
    /// </para>
    /// </summary>
    public ControllerStateObservation BuildControllerState(
        ushort[] configuration,
        ushort[] answer,
        DateTimeOffset observedAt)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        ArgumentNullException.ThrowIfNull(answer);

        string Text(ushort start, ushort length) =>
            Ch1ModbusEncoding.ReadText(configuration.AsSpan(start, length));

        // The controlled map carries one 16-bit boot value, and a boot identity has to be a
        // Guid to cross CH1-COM-IF-0003. It is widened deterministically rather than
        // generated: what CH1-CMD-FR-0009 needs is that the identity CHANGES when the
        // controller restarts, and a random Guid would change on every read instead, voiding
        // every prepared command on a healthy controller. Derived, and said to be derived.
        Span<byte> seed = stackalloc byte[16];
        "CH1-MODBUS-BOOT"u8.CopyTo(seed);
        BitConverter.TryWriteBytes(seed[..2], configuration[Ch1ModbusMap.ConfigControllerBootIdLow]);
        var bootId = new Guid(seed);

        var deferred = new List<uint>(2);
        foreach (var check in new[]
                 {
                     answer[Ch1ModbusMap.AnswerDeferredCheckFirst - Ch1ModbusMap.AnswerBandStart],
                     answer[Ch1ModbusMap.AnswerDeferredCheckSecond - Ch1ModbusMap.AnswerBandStart],
                 })
        {
            if (check != 0)
            {
                deferred.Add(check);
            }
        }

        // 207 is stated whether or not the guard happened to include it in this answer. The
        // permissive check is deferred for this profile as a matter of the controlled
        // document, not as a matter of what one scan reported, and a reader of the cell
        // needs to know why the permissives are unanswered rather than merely that they are.
        if (!deferred.Contains(Ch1ModbusMap.DeferredPreliminaryPermissiveInvalid))
        {
            deferred.Add(Ch1ModbusMap.DeferredPreliminaryPermissiveInvalid);
        }

        return new ControllerStateObservation(
            Text(Ch1ModbusMap.ConfigDeviceId, Ch1ModbusMap.LongTextRegisters),
            bootId,
            Ch1GuardStates.Name(answer[Ch1ModbusMap.AnswerState - Ch1ModbusMap.AnswerBandStart]),
            Text(Ch1ModbusMap.ConfigConfigurationRevision, Ch1ModbusMap.LongTextRegisters),
            ControllerPermissives.NotReported with { DeferredCheckCodes = deferred },
            configuration[Ch1ModbusMap.ConfigSecurityProfileCode] == Ch1ModbusMap.SecurityProfileZonedAllowlist
                ? "MODBUS-ZONED-ALLOWLIST-NO-GENERAL-ROUTING"
                : "MODBUS-PROFILE-UNKNOWN",
            Text(Ch1ModbusMap.ConfigFirmwareVersion, Ch1ModbusMap.LongTextRegisters),
            // Never "Live". This is a controller stand-in and says so all the way through to
            // the freshness a screen renders.
            "Simulated",
            observedAt);
    }

    public async ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);

        // Two requests, because Modbus caps a single read at 125 registers and the
        // configuration band is 140 long. The cap belongs to the protocol; splitting is the
        // master's job, and a master that assumed one request would silently read a short
        // band and decode the rest as zeros.
        const ushort firstChunk = 120;
        var low = await _client
            .ReadHoldingRegistersAsync(Ch1ModbusMap.ConfigurationBandStart, firstChunk, cancellationToken)
            .ConfigureAwait(false);
        var high = await _client
            .ReadHoldingRegistersAsync(
                firstChunk,
                (ushort)(Ch1ModbusMap.ConfigurationBandEnd - firstChunk + 1),
                cancellationToken)
            .ConfigureAwait(false);

        var band = new ushort[low.Length + high.Length];
        low.CopyTo(band, 0);
        high.CopyTo(band, low.Length);

        string Text(ushort start, ushort length) =>
            Ch1ModbusEncoding.ReadText(band.AsSpan(start, length));

        var commandCount = Math.Min(band[Ch1ModbusMap.ConfigSupportedCommandCount], (ushort)2);
        var commands = new List<string>(commandCount);
        ushort[] commandStarts = [Ch1ModbusMap.ConfigSupportedCommand0, Ch1ModbusMap.ConfigSupportedCommand1];
        for (var index = 0; index < commandCount; index++)
        {
            commands.Add(Text(commandStarts[index], Ch1ModbusMap.LongTextRegisters));
        }

        var channelCount = Math.Min(band[Ch1ModbusMap.ConfigTelemetryChannelCount], (ushort)3);
        ushort[] nameStarts = [Ch1ModbusMap.ConfigChannel0Name, Ch1ModbusMap.ConfigChannel1Name, Ch1ModbusMap.ConfigChannel2Name];
        ushort[] unitStarts = [Ch1ModbusMap.ConfigChannel0Unit, Ch1ModbusMap.ConfigChannel1Unit, Ch1ModbusMap.ConfigChannel2Unit];
        var channels = new List<CapabilityChannel>(channelCount);
        for (var index = 0; index < channelCount; index++)
        {
            // Never writable, and not as a matter of this adapter's opinion: these channels
            // are input registers, and no Modbus function code writes one.
            channels.Add(new CapabilityChannel(
                Text(nameStarts[index], Ch1ModbusMap.ShortTextRegisters),
                Text(unitStarts[index], Ch1ModbusMap.UnitTextRegisters),
                Writable: false));
        }

        var profile = band[Ch1ModbusMap.ConfigSecurityProfileCode] == Ch1ModbusMap.SecurityProfileZonedAllowlist
            ? "MODBUS-ZONED-ALLOWLIST-NO-GENERAL-ROUTING"
            : "MODBUS-PROFILE-UNKNOWN";

        var schema = string.Create(
            CultureInfo.InvariantCulture,
            $"{band[Ch1ModbusMap.ConfigSchemaMajor]}.{band[Ch1ModbusMap.ConfigSchemaMinor]}.{band[Ch1ModbusMap.ConfigSchemaPatch]}");

        return new DeviceCapabilityManifest(
            schema,
            Text(Ch1ModbusMap.ConfigDeviceId, Ch1ModbusMap.LongTextRegisters),
            Text(Ch1ModbusMap.ConfigDeviceType, Ch1ModbusMap.LongTextRegisters),
            Text(Ch1ModbusMap.ConfigFirmwareVersion, Ch1ModbusMap.LongTextRegisters),
            Text(Ch1ModbusMap.ConfigConfigurationRevision, Ch1ModbusMap.LongTextRegisters),
            commands,
            channels,
            [new ProtocolEndpoint("MODBUS", schema)],
            profile);
    }

    /// <summary>
    /// Writes one semantic intent into the handshake window and reports what the guard
    /// answered.
    /// </summary>
    public async ValueTask<AdapterAcknowledgement> PrepareAsync(
        SemanticCommandEnvelope command,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(command);

        // Local refusals first, before anything reaches the wire — CH1-COM-FR-0010 makes
        // duplicate suppression the gateway's obligation. The controller refuses them again
        // on its own terms, because neither end assumes the other checked.
        if (command.ExpiresAt <= _timeProvider.GetUtcNow())
        {
            return Reject(command, "COMMAND_EXPIRED");
        }

        if (command.Sequence <= Interlocked.Read(ref _lastSequence))
        {
            return Reject(command, "SEQUENCE_REPLAY_OR_DUPLICATE");
        }

        if (!command.CommandType.All(character =>
                char.IsAsciiLetterUpper(character) || char.IsAsciiDigit(character) || character == '_'))
        {
            return Reject(command, "SEMANTIC_COMMAND_INVALID");
        }

        await ConnectAsync(cancellationToken).ConfigureAwait(false);
        Interlocked.Exchange(ref _lastSequence, command.Sequence);

        var before = await ReadAnswerAsync(cancellationToken).ConfigureAwait(false);

        // The parameters go down first and the trigger goes down last, in a separate write.
        // A single write covering both would let a controller that evaluated mid-frame act
        // on half an intent.
        var parameters = new ushort[Ch1ModbusMap.HandshakeTrigger - Ch1ModbusMap.HandshakeBandStart];
        var span = parameters.AsSpan();
        span[Ch1ModbusMap.HandshakeSchemaMajor - Ch1ModbusMap.HandshakeBandStart] =
            ushort.TryParse(command.SchemaVersion.Split('.')[0], CultureInfo.InvariantCulture, out var major) ? major : (ushort)0;

        Span<byte> commandId = stackalloc byte[16];
        command.CommandId.TryWriteBytes(commandId, bigEndian: true, out _);
        for (var index = 0; index < Ch1ModbusMap.HandshakeCommandIdRegisters; index++)
        {
            span[Ch1ModbusMap.HandshakeCommandId - Ch1ModbusMap.HandshakeBandStart + index] =
                (ushort)((commandId[index * 2] << 8) | commandId[(index * 2) + 1]);
        }

        var (sequenceHigh, sequenceLow) = Ch1ModbusEncoding.SplitUInt32(command.Sequence);
        span[Ch1ModbusMap.HandshakeSequenceHigh - Ch1ModbusMap.HandshakeBandStart] = sequenceHigh;
        span[Ch1ModbusMap.HandshakeSequenceLow - Ch1ModbusMap.HandshakeBandStart] = sequenceLow;

        Ch1ModbusEncoding.WriteText(
            span.Slice(
                Ch1ModbusMap.HandshakeConfigurationRevision - Ch1ModbusMap.HandshakeBandStart,
                Ch1ModbusMap.HandshakeConfigurationRevisionRegisters),
            command.ConfigurationRevision);

        var (expiryHigh, expiryLow) = Ch1ModbusEncoding.SplitUInt32(command.ExpiresAt.ToUnixTimeSeconds());
        span[Ch1ModbusMap.HandshakeExpiresAtHigh - Ch1ModbusMap.HandshakeBandStart] = expiryHigh;
        span[Ch1ModbusMap.HandshakeExpiresAtLow - Ch1ModbusMap.HandshakeBandStart] = expiryLow;

        Ch1ModbusEncoding.WriteText(
            span.Slice(
                Ch1ModbusMap.HandshakeCommandType - Ch1ModbusMap.HandshakeBandStart,
                Ch1ModbusMap.HandshakeCommandTypeRegisters),
            command.CommandType);

        try
        {
            await _client.WriteMultipleRegistersAsync(Ch1ModbusMap.HandshakeBandStart, parameters, cancellationToken)
                .ConfigureAwait(false);
            await _client.WriteMultipleRegistersAsync(
                Ch1ModbusMap.HandshakeTrigger, [Ch1ModbusMap.HandshakeTriggerEvaluate], cancellationToken)
                .ConfigureAwait(false);
        }
        catch (ModbusProtocolException error)
        {
            return Reject(command, $"CONTROLLER_REFUSED_{ModbusProtocolException.Describe(error.ExceptionCode)}");
        }

        // Waiting for the guard's own answer counter to move, not for the write to return.
        // "The device took the registers" is not "the guard evaluated the intent".
        var deadline = _timeProvider.GetUtcNow() + _options.ExchangeTimeout;
        while (_timeProvider.GetUtcNow() < deadline)
        {
            var answer = await ReadAnswerAsync(cancellationToken).ConfigureAwait(false);
            if (answer[Ch1ModbusMap.AnswerCounter - Ch1ModbusMap.AnswerBandStart]
                != before[Ch1ModbusMap.AnswerCounter - Ch1ModbusMap.AnswerBandStart])
            {
                return Interpret(command, answer);
            }

            await Task.Delay(TimeSpan.FromMilliseconds(50), _timeProvider, cancellationToken).ConfigureAwait(false);
        }

        // CH1-COM-PRO-0001: loss of bus sets quality invalid and does not imply command
        // success. Reporting acceptance here would have the domain believe a controller took
        // an intent when nothing is known about whether it did.
        return Reject(command, "CONTROLLER_ANSWER_TIMEOUT");
    }

    private ValueTask<ushort[]> ReadAnswerAsync(CancellationToken cancellationToken) =>
        _client.ReadInputRegistersAsync(
            Ch1ModbusMap.AnswerBandStart,
            Ch1ModbusMap.InputRegisterCount - Ch1ModbusMap.AnswerBandStart,
            cancellationToken);

    private AdapterAcknowledgement Interpret(SemanticCommandEnvelope command, ushort[] answer)
    {
        var accepted = answer[Ch1ModbusMap.AnswerAccepted - Ch1ModbusMap.AnswerBandStart] == 1;
        var reason = answer[Ch1ModbusMap.AnswerReasonCode - Ch1ModbusMap.AnswerBandStart];
        var permit = answer[Ch1ModbusMap.AnswerExecutePermit - Ch1ModbusMap.AnswerBandStart];

        // The permit is read and asserted rather than assumed. It sits in an input register
        // precisely so nothing on this link can raise it; reading it back is how that stops
        // being an argument and starts being an observation.
        if (permit != 0)
        {
            throw new InvalidOperationException(
                "The Modbus controller reports an execute permit on a link that offers no way to commit. "
                + "CH1-AUT-FDS-0001 requires a credential proof and a local button edge, and neither can "
                + "arrive here, so this gateway refuses to serve the adapter rather than carrying the claim.");
        }

        foreach (var check in new[]
                 {
                     answer[Ch1ModbusMap.AnswerDeferredCheckFirst - Ch1ModbusMap.AnswerBandStart],
                     answer[Ch1ModbusMap.AnswerDeferredCheckSecond - Ch1ModbusMap.AnswerBandStart],
                 })
        {
            if (check != 0)
            {
                LogDeferredCheck(_logger, check);
            }
        }

        return new AdapterAcknowledgement(
            command.CommandId,
            accepted,
            accepted ? "AwaitingCredential" : "Idle",
            Ch1GuardReasons.Name(reason),
            _timeProvider.GetUtcNow(),
            AdapterId);
    }

    public async IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await ConnectAsync(cancellationToken).ConfigureAwait(false);
        await foreach (var point in _telemetry.Reader.ReadAllAsync(cancellationToken).ConfigureAwait(false))
        {
            yield return point;
        }
    }

    /// <summary>
    /// Reopens the socket and restores nothing. The spent-sequence high-water mark survives
    /// on purpose: a reconnection that made a spent sequence acceptable again would arm
    /// equipment nobody asked to arm.
    /// </summary>
    public async ValueTask ReconcileAsync(CancellationToken cancellationToken)
    {
        if (_pump is not null)
        {
            await _pump.CancelAsync().ConfigureAwait(false);
            _pump.Dispose();
            _pump = null;
        }

        _client.Dispose();
        lock (_announcedChannels)
        {
            _announcedChannels.Clear();
        }

        await ConnectAsync(cancellationToken).ConfigureAwait(false);
    }

    private AdapterAcknowledgement Reject(SemanticCommandEnvelope command, string reason) => new(
        command.CommandId,
        false,
        "Idle",
        reason,
        _timeProvider.GetUtcNow(),
        AdapterId);

    // Source-generated per CH1-SWA-SDP-0001. Endpoint, map version and stable strings only.
    [LoggerMessage(EventId = 2300, Level = LogLevel.Information,
        Message = "Modbus adapter connected to {Host}:{Port}; controlled map version {MapVersion}, unit {Unit}.")]
    private static partial void LogConnected(ILogger logger, string host, int port, ushort mapVersion, byte unit);

    [LoggerMessage(EventId = 2301, Level = LogLevel.Information,
        Message = "Modbus telemetry {Channel} first sample {Value} {Unit} quality {Quality}")]
    private static partial void LogFirstSample(ILogger logger, string channel, double value, string unit, string quality);

    [LoggerMessage(EventId = 2302, Level = LogLevel.Warning,
        Message = "Modbus bus lost; telemetry quality is invalid and no value is repeated: {Detail}")]
    private static partial void LogBusLost(ILogger logger, string detail);

    [LoggerMessage(EventId = 2303, Level = LogLevel.Information,
        Message = "Modbus controller deferred check: reason code {Code} is decided by the CPU, not on this link.")]
    private static partial void LogDeferredCheck(ILogger logger, ushort code);

    public async ValueTask DisposeAsync()
    {
        _telemetry.Writer.TryComplete();
        if (_pump is not null)
        {
            await _pump.CancelAsync().ConfigureAwait(false);
            _pump.Dispose();
            _pump = null;
        }

        _client.Dispose();
        _connectionGate.Dispose();
    }
}

/// <summary>
/// The SCL's reason codes by name, for a transport that can only carry the number.
/// </summary>
/// <remarks>
/// Modbus registers are 16-bit integers, so the guard's reason arrives as a code and this is
/// where it becomes the word an operator reads. The values are the controlled SCL's, and
/// <c>scripts/check-plc-model.mjs</c> holds every expression of them in step.
/// </remarks>
/// <summary>
/// The guard's own state codes, as the controlled SCL numbers them. Named rather than
/// passed through, because the operating state reaches an operations view and a bare
/// integer is not something an operator can act on.
/// </summary>
internal static class Ch1GuardStates
{
    public static string Name(ushort code) => code switch
    {
        0 => "Idle",
        1 => "Preparing",
        2 => "AwaitingCredential",
        3 => "AwaitingLocalConfirmation",
        4 => "Executing",
        5 => "FaultLatched",
        _ => "Unknown",
    };
}

internal static class Ch1GuardReasons
{
    public static string Name(ushort code) => code switch
    {
        0 => "NONE",
        10 => "PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION",
        110 => "CONTROLLER_RESTARTED",
        120 => "PREPARE_EXPIRED",
        201 => "STATE_INVALID",
        202 => "SCHEMA_UNSUPPORTED",
        203 => "REPLAY_OR_DUPLICATE",
        204 => "EXPIRED",
        205 => "REVISION_MISMATCH",
        // >= 1000 is the protocol-profile range, which the controlled SCL never uses.
        1001 => "COMMAND_TYPE_NOT_IN_CAPABILITY_MODEL",
        _ => "UNSPECIFIED",
    };
}
