// The contract every protocol adapter and transport provider has to implement.

using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Protocols;

/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0002, CH1-COM-FR-0005</requirements>
public interface IProtocolAdapter
{
    string AdapterId { get; }

    string Protocol { get; }

    ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken);

    ValueTask<AdapterAcknowledgement> PrepareAsync(
        SemanticCommandEnvelope command,
        CancellationToken cancellationToken);

    IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(CancellationToken cancellationToken);

    ValueTask ReconcileAsync(CancellationToken cancellationToken);
}

public interface ITransportProvider
{
    string ProviderId { get; }

    ValueTask SendAsync(ReadOnlyMemory<byte> versionedEnvelope, CancellationToken cancellationToken);

    IAsyncEnumerable<ReadOnlyMemory<byte>> ReceiveAsync(CancellationToken cancellationToken);
}

