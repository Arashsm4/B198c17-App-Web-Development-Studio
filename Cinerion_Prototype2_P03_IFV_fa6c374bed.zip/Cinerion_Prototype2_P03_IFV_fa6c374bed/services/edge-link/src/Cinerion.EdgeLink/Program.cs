// EdgeLink starts here: adapters, buffer and ingress client. The gateway gets dressed in this
// file.

using Cinerion.EdgeLink.Buffering;
using Cinerion.EdgeLink.Ingress;
using Cinerion.EdgeLink.Protocols;
using Cinerion.EdgeLink.Runtime;

// The verification client, not the gateway. It attacks the CH1-COM-IF-0003 ingress and
// reports what it could not do, and it lives in this image because the attacks have to be
// mounted from the gateway's own side of the edge — a probe built somewhere else would be
// testing a different client's certificates.
if (args.Contains("--probe", StringComparer.Ordinal))
{
    var probeConfiguration = new ConfigurationBuilder().AddEnvironmentVariables().Build();
    return await Ch1IngressProbe.RunAsync(probeConfiguration, CancellationToken.None).ConfigureAwait(false);
}

// The load driver, on the same terms and for the same reason. CH1-NFR-PER-0001's baseline
// has to be offered by the gateway's own client over the gateway's own mutually
// authenticated channel, or the measurement is of something else.
if (args.Contains("--load", StringComparer.Ordinal))
{
    var loadConfiguration = new ConfigurationBuilder().AddEnvironmentVariables().Build();
    return await Ch1LoadDriver.RunAsync(loadConfiguration, CancellationToken.None).ConfigureAwait(false);
}

var builder = Host.CreateApplicationBuilder(args);

var profile = builder.Configuration["CINERION_RUNTIME_PROFILE"] ?? "Simulation";
if (!StringComparer.OrdinalIgnoreCase.Equals(profile, "Simulation"))
{
    throw new InvalidOperationException(
        "This checkpoint enables the simulator, MQTT, OPC UA and Modbus adapters.");
}

builder.Services.AddSingleton<IProtocolAdapter, SimulatorProtocolAdapter>();

// The MQTT edge is registered only when it is completely configured: broker, controlled
// CA, client certificate and its key. A partially configured TLS edge is the one case
// where a helpful default would silently drop mutual authentication, so an unconfigured
// deployment gets the gated adapter — which must refuse, and is held to that contract by
// AdapterConformance.RunGatedAsync — rather than a live one with weaker security.
var mqtt = MqttAdapterOptions.FromConfiguration(builder.Configuration);
if (mqtt is null)
{
    builder.Services.AddSingleton<IProtocolAdapter, Mqtt5ProtocolAdapter>();
}
else
{
    builder.Services.AddSingleton(mqtt);
    builder.Services.AddSingleton<IProtocolAdapter>(services => new MqttProtocolAdapter(
        mqtt,
        services.GetRequiredService<ILogger<MqttProtocolAdapter>>(),
        services.GetService<TimeProvider>()));

    // The device end, for a deployment with no ESP32-S3 in front of it. It is a separate
    // MQTT client with its own certificate, so the broker authenticates it as the device
    // and applies the device half of the topic ACL to it — the alternative, a shortcut
    // inside the adapter, would test the gateway against itself.
    if (StringComparer.OrdinalIgnoreCase.Equals(
            builder.Configuration["CINERION_MQTT_DEVICE_SIMULATOR"], "true"))
    {
        builder.Services.AddHostedService<MqttDeviceSimulator>();
    }
}

// The OPC UA edge, on exactly the same terms: endpoint, controlled CA, client certificate
// and its key, all four or none. CH1-COM-IF-0007 requires SignAndEncrypt with certificate
// trust, so a partially configured edge gets the gated adapter — which must refuse, and is
// held to that contract by AdapterConformance.RunGatedAsync — rather than a live one that
// negotiated its security away.
var opcUa = OpcUaAdapterOptions.FromConfiguration(builder.Configuration);
if (opcUa is null)
{
    builder.Services.AddSingleton<IProtocolAdapter, OpcUaGatedAdapter>();
}
else
{
    builder.Services.AddSingleton(opcUa);
    builder.Services.AddSingleton<IProtocolAdapter>(services => new OpcUaProtocolAdapter(
        opcUa,
        services.GetRequiredService<ILogger<OpcUaProtocolAdapter>>(),
        services.GetRequiredService<ILoggerFactory>(),
        services.GetService<TimeProvider>()));
}

// The Modbus edge. Modbus has no credential to configure — CH1-COM-ICD-0001 terminates it
// inside a controlled zone behind an allowlisted map, so the deployment decision is which
// zone the gateway is on. An unset host leaves the gated adapter, which must refuse.
var modbus = ModbusAdapterOptions.FromConfiguration(builder.Configuration);
if (modbus is null)
{
    builder.Services.AddSingleton<IProtocolAdapter, ModbusGatedAdapter>();
}
else
{
    builder.Services.AddSingleton(modbus);
    builder.Services.AddSingleton<IProtocolAdapter>(services => new ModbusProtocolAdapter(
        modbus,
        services.GetRequiredService<ILogger<ModbusProtocolAdapter>>(),
        services.GetService<TimeProvider>()));
}

// Two providers, deliberately. CH1-COM-FR-0005 requires a transport overlay to connect
// through a stable provider boundary without changing domain messages, and a boundary
// with one implementation behind it demonstrates nothing. Both are put through the same
// conformance suite at startup, and the gateway refuses to serve either if it fails.
builder.Services.AddSingleton<ITransportProvider, LoopbackTransportProvider>();
builder.Services.AddSingleton<ITransportProvider, FramedSerialTransportProvider>();
builder.Services.AddSingleton(EdgeLinkWorkerOptions.FromConfiguration(builder.Configuration));
builder.Services.AddHostedService<EdgeLinkWorker>();

// CH1-COM-IF-0003: the internal gRPC edge into Control Core, mutually authenticated.
// Configured completely or not at all, on the same terms as the protocol adapters — a
// half-configured mutual-TLS channel into the domain is the one case where a helpful
// default would drop the authentication. Unconfigured means the gateway publishes nothing
// and says so, rather than opening an unauthenticated path or silently discarding what its
// adapters observe.
var ingress = ControlCoreIngressOptions.FromConfiguration(builder.Configuration);
if (ingress is null)
{
    Console.WriteLine(
        "CH1-COM-IF-0003 is not configured: no endpoint, controlled authority, client certificate, " +
        "key, gateway identity, project or cell. Nothing this gateway observes will reach Control Core.");
}
else
{
    builder.Services.AddSingleton(ingress);

    // CH1-NFR-REL-0001: at least 24 hours of configured telemetry, on disk, so an outage
    // long enough to need a buffer — which is long enough to include a restart — does not
    // empty it. The capacity is derived from the retention floor and the configured feed
    // rate rather than stated beside them, so a deployment cannot claim a 24-hour floor and
    // size itself for six; EdgeBufferOptions.Validate refuses that at startup, by name.
    //
    // Unset means store-and-forward is off and the publisher says so at startup. That is
    // the behaviour this gateway had before the buffer existed, now named rather than
    // silent — a helpful in-memory fallback would look like store-and-forward and would not
    // survive the restart.
    var bufferOptions = EdgeBufferOptions.FromConfiguration(builder.Configuration);
    if (bufferOptions is not null)
    {
        builder.Services.AddSingleton<IEdgeBuffer>(_ =>
            SqliteEdgeBuffer.OpenAsync(bufferOptions).AsTask().GetAwaiter().GetResult());
    }

    builder.Services.AddHostedService(services => new IngressPublisher(
        services.GetRequiredService<ControlCoreIngressOptions>(),
        services.GetRequiredService<IEnumerable<IProtocolAdapter>>(),
        services.GetRequiredService<ILogger<IngressPublisher>>(),
        services.GetService<IEdgeBuffer>(),
        services.GetService<TimeProvider>()));
}

// Stated rather than inherited. A conformance failure throws out of EdgeLinkWorker, and
// this is what turns that into a gateway that stops instead of one that logged an error
// and carried on serving an adapter that had just failed its own contract. It is the
// framework default, but a default is not a decision, and this one is load-bearing.
builder.Services.Configure<HostOptions>(options =>
    options.BackgroundServiceExceptionBehavior = BackgroundServiceExceptionBehavior.StopHost);

await builder.Build().RunAsync().ConfigureAwait(false);
return 0;
