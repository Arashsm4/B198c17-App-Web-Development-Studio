// EdgeLink's gRPC client for sending observations to Control Core over mutual TLS.

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Cinerion.Contracts.EdgeLink.V1;
using Cinerion.EdgeLink.Contracts;
using Google.Protobuf.WellKnownTypes;
using Grpc.Net.Client;

namespace Cinerion.EdgeLink.Ingress;

/// <summary>
/// The publishing end of CH1-COM-IF-0003.
/// <para>
/// The channel is mutually authenticated in both directions: this gateway presents the
/// certificate the controlled authority issued it, and it validates Control Core's server
/// certificate against that same authority and nothing else. The machine trust store is
/// deliberately not consulted — a certificate from a public authority carrying the right
/// name would otherwise be accepted, and identity here is what this authority attested.
/// </para>
/// <para>
/// It publishes and it reports what it was told. It does not retry a refusal: a report
/// Control Core rejected is not a delivery problem, and republishing it would be a gateway
/// arguing with the domain. A transport failure is a different thing and is retried by the
/// caller's own cadence, which is what CH1-COM-PRO-0001 means by bounded retry.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-COM-FR-0009, CH1-CYB-FR-0001</requirements>
public sealed class ControlCoreIngressClient : IDisposable
{
    private readonly ControlCoreIngressOptions _options;
    private readonly GrpcChannel _channel;
    private readonly EdgeLinkIngress.EdgeLinkIngressClient _client;
    private readonly TimeProvider _time;
    private long _sequence;

    public ControlCoreIngressClient(ControlCoreIngressOptions options, TimeProvider? timeProvider = null)
    {
        ArgumentNullException.ThrowIfNull(options);
        _options = options;
        _time = timeProvider ?? TimeProvider.System;

        var handler = new SocketsHttpHandler
        {
            SslOptions = new SslClientAuthenticationOptions
            {
                ClientCertificates = [options.ClientCertificate],
                RemoteCertificateValidationCallback = (_, certificate, _, errors) =>
                    IsControlCore(certificate, errors, options.CertificateAuthority),
            },
            // The control zone is a local network. A connection that has silently died
            // must be discovered by this gateway rather than by an operator noticing that
            // a cell went quiet, so the channel is actively kept honest.
            KeepAlivePingDelay = TimeSpan.FromSeconds(20),
            KeepAlivePingTimeout = TimeSpan.FromSeconds(10),
            EnableMultipleHttp2Connections = true,
        };

        _channel = GrpcChannel.ForAddress(options.Endpoint, new GrpcChannelOptions
        {
            HttpHandler = handler,
            MaxSendMessageSize = 256 * 1024,
            MaxReceiveMessageSize = 256 * 1024,
            DisposeHttpClient = true,
        });
        _client = new EdgeLinkIngress.EdgeLinkIngressClient(_channel);
    }

    public Uri Endpoint => _options.Endpoint;

    /// <summary>Publishes what an adapter observed about the controller itself.</summary>
    public async Task<IngressReceipt> PublishControllerStateAsync(
        ControllerStateObservation observation,
        string adapterId,
        string protocol,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(observation);
        var request = new ControllerStateReport
        {
            Envelope = NewEnvelope("ControllerState"),
            ControllerId = observation.ControllerId,
            ControllerBootId = observation.ControllerBootId.ToString(),
            OperatingState = MapOperatingState(observation.OperatingState),
            ConfigurationRevision = observation.ConfigurationRevision,
            Permissives = new Permissives
            {
                Reported = observation.Permissives.Reported,
                ControllerOnline = observation.Permissives.ControllerOnline,
                StartEnable = observation.Permissives.StartEnable,
                StopCircuitHealthy = observation.Permissives.StopCircuitHealthy,
                GuardHealthy = observation.Permissives.GuardHealthy,
                ActuatorHome = observation.Permissives.ActuatorHome,
                ButtonPressed = observation.Permissives.ButtonPressed,
                FaultCauseActive = observation.Permissives.FaultCauseActive,
            },
            AdapterId = adapterId,
            Protocol = protocol,
            SecurityProfile = observation.SecurityProfile,
            FirmwareVersion = observation.FirmwareVersion,
            Freshness = MapFreshness(observation.Freshness),
            // What the CONTROLLER said about its own clock, not what this gateway would
            // like to be true of it. An adapter that reads a controller with no clock to
            // describe - Modbus has none, and the OPC UA stand-in publishes none - passes
            // nothing, and nothing is stored.
            SourceTimeQuality = MapTimeQuality(observation.SourceTimeQuality),
        };
        request.Permissives.DeferredCheckCodes.AddRange(observation.Permissives.DeferredCheckCodes);
        request.Envelope.OccurredAt = Timestamp.FromDateTimeOffset(observation.ObservedAt);

        return await _client.PublishControllerStateAsync(
            request, cancellationToken: cancellationToken).ResponseAsync.ConfigureAwait(false);
    }

    /// <summary>The message type a buffered telemetry publication is replayed as.</summary>
    public const string TelemetryMessageType = "Telemetry";

    /// <summary>The message type a buffered controller transition is replayed as.</summary>
    public const string ControllerEventMessageType = "ControllerEvent";

    /// <summary>
    /// Replays a record the buffer held, exactly as it was built.
    /// <para>
    /// The bytes are not rebuilt, so the message identifier is the one the original carried:
    /// a publication that reached Control Core but whose receipt was lost is refused as a
    /// duplicate rather than stored twice. That is what makes an at-least-once buffer safe
    /// against a store that must not double-count a reading.
    /// </para>
    /// </summary>
    public Task<IngressReceipt> SendBufferedAsync(
        string messageType,
        byte[] payload,
        CancellationToken cancellationToken) => messageType switch
        {
            TelemetryMessageType => _client
                .PublishTelemetryAsync(TelemetryPublication.Parser.ParseFrom(payload), cancellationToken: cancellationToken)
                .ResponseAsync,
            ControllerEventMessageType => _client
                .PublishControllerEventAsync(ControllerEvent.Parser.ParseFrom(payload), cancellationToken: cancellationToken)
                .ResponseAsync,
            _ => throw new InvalidOperationException(
                $"The buffer holds a '{messageType}' record, which this gateway has no way to replay. " +
                "A record type that cannot be delivered would block the queue head for ever."),
        };

    /// <summary>Builds a transition record, without sending it.</summary>
    public ControllerEvent BuildControllerEvent(
        ControllerStateObservation observation,
        ControllerStateObservation? previous,
        Runtime.ControllerTransition transition,
        string adapterId)
    {
        ArgumentNullException.ThrowIfNull(observation);
        ArgumentNullException.ThrowIfNull(transition);
        var message = new ControllerEvent
        {
            Envelope = NewEnvelope(ControllerEventMessageType),
            ControllerId = observation.ControllerId,
            ControllerBootId = observation.ControllerBootId.ToString(),
            Kind = transition.Kind,
            ReasonCode = transition.ReasonCode,
            PreviousState = previous is null
                ? ControllerOperatingState.Unspecified
                : MapOperatingState(previous.OperatingState),
            CurrentState = MapOperatingState(observation.OperatingState),
            PreviousPermissives = previous is null ? null : MapPermissives(previous.Permissives),
            CurrentPermissives = MapPermissives(observation.Permissives),
            PreviousConfigurationRevision = previous?.ConfigurationRevision ?? string.Empty,
            ConfigurationRevision = observation.ConfigurationRevision,
            AdapterId = adapterId,
            ObservedAt = Timestamp.FromDateTimeOffset(observation.ObservedAt),
        };

        // The envelope is stamped with when the transition happened, not with when the
        // gateway got round to sending it. A record that arrives after a twenty-hour outage
        // must still say when the guard opened.
        message.Envelope.OccurredAt = Timestamp.FromDateTimeOffset(observation.ObservedAt);
        return message;
    }

    /// <summary>Builds a telemetry publication, without sending it.</summary>
    public TelemetryPublication BuildTelemetry(string deviceId, IReadOnlyList<TelemetryPoint> points)
    {
        ArgumentNullException.ThrowIfNull(points);
        var request = new TelemetryPublication
        {
            Envelope = NewEnvelope(TelemetryMessageType),
            DeviceId = deviceId,
        };

        foreach (var point in points)
        {
            request.Readings.Add(new global::Cinerion.Contracts.EdgeLink.V1.TelemetryReading
            {
                ChannelId = point.ChannelId,
                Value = point.Value,
                Unit = point.Unit,
                Quality = MapQuality(point.Quality),
                Freshness = MapFreshness(point.Quality),
                SampledAt = Timestamp.FromDateTimeOffset(point.SampledAt),
                Sequence = point.Sequence,
                // The device's own declaration, carried unchanged. The envelope's
                // time_quality above describes THIS gateway's clock and is a different
                // fact; before this field existed there was nowhere else to put the
                // device's, so it was discarded. Defect 59, conflict 27.
                SourceTimeQuality = MapTimeQuality(
                    point.SourceTimeQuality == TelemetryPoint.GatewayStamped
                        ? _options.GatewayTimeQuality
                        : point.SourceTimeQuality),
            });
        }

        return request;
    }

    /// <summary>
    /// Reads a source's declared time quality into the contract enum. An unrecognised or
    /// absent declaration becomes UNSPECIFIED, never QUALIFIED: a gateway that resolved
    /// silence into a claim of a disciplined clock would be making exactly the assertion
    /// CH1-COM-ICD-0001 requires to be observable rather than assumed.
    /// </summary>
    public static TimeQuality MapTimeQuality(string? declared) => declared switch
    {
        "Trusted" => TimeQuality.Trusted,
        // The firmware's own vocabulary, which is the one a CH1 device actually sends:
        // Unsynchronised, Synchronised, Holdover, Stale (conditioned_io.hpp). Mapped
        // conservatively in every case, and nothing maps to Trusted - no clock in this
        // deployment is traceable to an attested source, and inventing that claim here
        // is precisely the substitution defect 59 was.
        "Synchronised" or "Synchronized" or "Qualified" => TimeQuality.Qualified,
        "Holdover" or "Degraded" => TimeQuality.Degraded,
        // Disciplined so long ago that the drift is bounded by nothing, or never
        // disciplined at all. Since defect 58 the latter is what a controller with no
        // time server honestly reports.
        "Stale" or "Unsynchronised" or "Unsynchronized" or "Unknown" => TimeQuality.Unknown,
        _ => TimeQuality.Unspecified,
    };

    private static Permissives MapPermissives(ControllerPermissives permissives)
    {
        var mapped = new Permissives
        {
            Reported = permissives.Reported,
            ControllerOnline = permissives.ControllerOnline,
            StartEnable = permissives.StartEnable,
            StopCircuitHealthy = permissives.StopCircuitHealthy,
            GuardHealthy = permissives.GuardHealthy,
            ActuatorHome = permissives.ActuatorHome,
            ButtonPressed = permissives.ButtonPressed,
            FaultCauseActive = permissives.FaultCauseActive,
        };
        mapped.DeferredCheckCodes.AddRange(permissives.DeferredCheckCodes);
        return mapped;
    }

    /// <summary>Publishes readings an adapter took, exactly as the adapter reported them.</summary>
    public async Task<IngressReceipt> PublishTelemetryAsync(
        string deviceId,
        IReadOnlyList<TelemetryPoint> points,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(points);
        var request = new TelemetryPublication
        {
            Envelope = NewEnvelope(TelemetryMessageType),
            DeviceId = deviceId,
        };

        foreach (var point in points)
        {
            request.Readings.Add(new global::Cinerion.Contracts.EdgeLink.V1.TelemetryReading
            {
                ChannelId = point.ChannelId,
                Value = point.Value,
                Unit = point.Unit,
                // The adapter's own quality word, translated and never improved. A reading
                // a controller called Simulated stays Simulated all the way to the store.
                Quality = MapQuality(point.Quality),
                Freshness = MapFreshness(point.Quality),
                SampledAt = Timestamp.FromDateTimeOffset(point.SampledAt),
                Sequence = point.Sequence,
            });
        }

        return await _client.PublishTelemetryAsync(
            request, cancellationToken: cancellationToken).ResponseAsync.ConfigureAwait(false);
    }

    /// <summary>Passes on a controller's answer to a command the domain prepared.</summary>
    public async Task<IngressReceipt> AcknowledgeCommandAsync(
        AdapterAcknowledgement acknowledgement,
        string controllerId,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(acknowledgement);
        var request = new CommandAcknowledgement
        {
            Envelope = NewEnvelope("CommandAcknowledgement"),
            CommandId = acknowledgement.CommandId.ToString(),
            ControllerId = controllerId,
            Accepted = acknowledgement.Accepted,
            ControllerState = acknowledgement.ControllerState,
            ReasonCode = acknowledgement.ReasonCode,
            ObservedAt = Timestamp.FromDateTimeOffset(acknowledgement.ObservedAt),
            AdapterId = acknowledgement.AdapterId,
            SourceTimeQuality = MapTimeQuality(acknowledgement.SourceTimeQuality),
        };

        return await _client.AcknowledgeCommandAsync(
            request, cancellationToken: cancellationToken).ResponseAsync.ConfigureAwait(false);
    }

    /// <summary>
    /// A fresh envelope carrying everything CH1-COM-ICD-0001 requires. The message
    /// identifier is new every time, which is what makes Control Core's duplicate
    /// suppression meaningful rather than decorative.
    /// </summary>
    public Envelope NewEnvelope(string messageType) => new()
    {
        SchemaVersion = "1.0.0",
        MessageType = messageType,
        MessageId = Guid.NewGuid().ToString(),
        CorrelationId = Guid.NewGuid().ToString(),
        SourceId = _options.GatewayIdentity,
        DestinationId = "cinerion-control-core",
        ProjectId = _options.ProjectId.ToString(),
        SiteId = _options.SiteId == Guid.Empty ? string.Empty : _options.SiteId.ToString(),
        CellId = _options.CellId.ToString(),
        AssetId = _options.AssetId == Guid.Empty ? string.Empty : _options.AssetId.ToString(),
        Sequence = Interlocked.Increment(ref _sequence),
        OccurredAt = Timestamp.FromDateTimeOffset(_time.GetUtcNow()),
        // The GATEWAY's own clock, declared rather than asserted. This line read
        // `TimeQuality.Qualified` unconditionally, which was a claim nothing established
        // and which no deployment setting could correct. Defect 59, conflict 27.
        TimeQuality = MapTimeQuality(_options.GatewayTimeQuality),
    };

    /// <summary>The raw client, for a verification probe that must send what a well-behaved gateway would not.</summary>
    public EdgeLinkIngress.EdgeLinkIngressClient Raw => _client;

    /// <summary>
    /// Accepts Control Core only if the controlled authority signed its certificate.
    /// <para>
    /// <see cref="X509ChainTrustMode.CustomRootTrust"/> with this one anchor means the
    /// machine's root store is not consulted, so the gateway cannot be redirected to a
    /// server holding a certificate from a public authority. It is the mirror image of the
    /// check Control Core applies to this gateway, and both halves are needed: mutual TLS
    /// with one side trusting anything is not mutual.
    /// </para>
    /// </summary>
    private static bool IsControlCore(
        X509Certificate? certificate,
        SslPolicyErrors errors,
        X509Certificate2 authority)
    {
        if (certificate is null || errors.HasFlag(SslPolicyErrors.RemoteCertificateNotAvailable))
        {
            return false;
        }

        using var presented = X509CertificateLoader.LoadCertificate(certificate.Export(X509ContentType.Cert));
        using var chain = new X509Chain
        {
            ChainPolicy =
            {
                TrustMode = X509ChainTrustMode.CustomRootTrust,
                RevocationMode = X509RevocationMode.NoCheck,
            },
        };
        chain.ChainPolicy.CustomTrustStore.Add(authority);
        return chain.Build(presented);
    }

    private static ControllerOperatingState MapOperatingState(string state) => state switch
    {
        "Initialising" => ControllerOperatingState.Initialising,
        "Idle" => ControllerOperatingState.Idle,
        "Prepared" => ControllerOperatingState.Prepared,
        "Executing" => ControllerOperatingState.Executing,
        "Complete" => ControllerOperatingState.Complete,
        "FaultLatched" => ControllerOperatingState.FaultLatched,
        // CH1-AUT-FDS-0001's state diagram places Recovery between FaultLatched and Idle,
        // and since the cell controller implements that transition it can report it. Left
        // out, it would have fallen into the Unspecified branch below and been refused -
        // correct as a default, and wrong for a state the controlled diagram contains.
        "Recovery" => ControllerOperatingState.Recovery,
        "Maintenance" => ControllerOperatingState.Maintenance,
        // Unspecified rather than a guess. Control Core refuses it, which is the right
        // outcome: an operating state nobody recognises must not become Idle.
        _ => ControllerOperatingState.Unspecified,
    };

    private static global::Cinerion.Contracts.EdgeLink.V1.Freshness MapFreshness(string quality) => quality switch
    {
        "Good" or "Live" => global::Cinerion.Contracts.EdgeLink.V1.Freshness.Live,
        "Simulated" => global::Cinerion.Contracts.EdgeLink.V1.Freshness.Simulated,
        "Stale" => global::Cinerion.Contracts.EdgeLink.V1.Freshness.Stale,
        "Maintenance" => global::Cinerion.Contracts.EdgeLink.V1.Freshness.Maintenance,
        "Disconnected" or "Invalid" or "Bad" => global::Cinerion.Contracts.EdgeLink.V1.Freshness.Disconnected,
        _ => global::Cinerion.Contracts.EdgeLink.V1.Freshness.Unknown,
    };

    private static global::Cinerion.Contracts.EdgeLink.V1.DataQuality MapQuality(string quality) => quality switch
    {
        // A simulated reading is still a good measurement of a simulated thing. Whether it
        // came from a simulator is freshness, and it is carried there.
        "Good" or "Live" or "Simulated" => global::Cinerion.Contracts.EdgeLink.V1.DataQuality.Good,
        "Uncertain" or "Stale" => global::Cinerion.Contracts.EdgeLink.V1.DataQuality.Uncertain,
        "Bad" or "Invalid" => global::Cinerion.Contracts.EdgeLink.V1.DataQuality.Bad,
        _ => global::Cinerion.Contracts.EdgeLink.V1.DataQuality.Unknown,
    };

    public void Dispose()
    {
        _channel.Dispose();
        _options.ClientCertificate.Dispose();
        _options.CertificateAuthority.Dispose();
    }
}
