// Drives the baseline load over the ingress: lots of devices, lots of messages, all measured.

using System.Diagnostics;
using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Ingress;

/// <summary>
/// The baseline load of CH1-NFR-PER-0001, driven over CH1-COM-IF-0003.
/// <para>
/// The requirement states it in one line — <em>"The baseline shall support 25 active
/// devices, 250 live channels and 100 sustained telemetry messages per second"</em> — and
/// until the gRPC ingress existed there was no path over which any of it could be offered.
/// Telemetry reached the domain only from an in-process simulated source inside Control
/// Core itself, so a load test would have measured Control Core feeding itself.
/// </para>
/// <para>
/// <b>It is deliberately the gateway's own client.</b> The channel, the mutual TLS, the
/// envelope, the sequence numbering and the message construction are
/// <see cref="ControlCoreIngressClient"/>, unchanged — the same code the running gateway
/// uses. A load driver with its own client would measure the load driver.
/// </para>
/// <para>
/// <b>Sustained is measured, not assumed.</b> A burst that averages the required rate over
/// its whole run while collapsing in the middle meets the average and not the requirement,
/// so the achieved rate is reported per second and the worst one-second window is what the
/// gate judges.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-PER-0001, CH1-COM-IF-0003, CH1-MON-FR-0001</requirements>
public static class Ch1LoadDriver
{
    /// <summary>
    /// The controlled analogue channels, and there are exactly four of them.
    /// <para>
    /// CH1-SYS-ICD-0001's I/O table defines <c>CH1-IO-AI-0001</c>…<c>0004</c> — temperature,
    /// relative humidity, position/distance and motion/vibration — and
    /// <c>TelemetryChannelCatalogue</c> holds the same four. A device may publish no other
    /// channel: the ingress answers <c>TELEMETRY_CHANNEL_NOT_ALLOWED</c>. This is why the
    /// "250 live channels" half of CH1-NFR-PER-0001 cannot be met by 25 devices, and the
    /// driver states the arithmetic rather than inventing channels to reach the number.
    /// </para>
    /// </summary>
    private static readonly (string Channel, string Unit, double Low, double High)[] ControlledChannels =
    [
        ("temperature", "degC", 20.0, 24.0),
        ("humidity", "%RH", 40.0, 50.0),
        ("position", "mm", 10.0, 60.0),
        ("vibration_rms", "m/s2", 0.5, 1.5),
    ];

    /// <summary>
    /// How many publications may be awaiting an answer at once. Bounded so that a service
    /// which slowed down would show as a falling rate rather than as an ever-growing queue
    /// of in-flight calls, which is a flood test and not a sustained-rate one.
    /// </summary>
    private const int MaximumInFlight = 256;

    public static async Task<int> RunAsync(IConfiguration configuration, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var options = ControlCoreIngressOptions.FromConfiguration(configuration)
            ?? throw new InvalidOperationException(
                "The load driver needs the same CH1-COM-IF-0003 configuration the gateway does.");

        var devices = Read(configuration, "CINERION_LOAD_DEVICES", 25);
        var targetRate = Read(configuration, "CINERION_LOAD_MESSAGES_PER_SECOND", 100);
        var seconds = Read(configuration, "CINERION_LOAD_SECONDS", 60);

        // Load is offered for this long before the measured window opens, and what it
        // carries is discarded from the rate.
        //
        // This is not a way of dropping an inconvenient second. The per-second profile of
        // a cold run is 0, 33, 262, 99, 101, 99, 100 ... : the first full second of a
        // process's life carries a third of the rate while the ingestion path is compiled
        // and the connection pool opens its first backends, the next second carries the
        // backlog, and every second after that carries the requirement. Nothing is lost -
        // that run refused nothing and dropped nothing - so the number being measured
        // there is start-up, and CH1-NFR-PER-0001 asks for a SUSTAINED rate.
        //
        // The requirement is not lowered by a millisecond: every second inside the window
        // must still carry the full rate, refusals and transport failures are still
        // counted across the WHOLE run including the warm-up, and every publication the
        // warm-up made must still be found in the database afterwards. The warm-up is
        // reported and its seconds are printed, so it cannot become a place to hide.
        var warmupSeconds = Read(configuration, "CINERION_LOAD_WARMUP_SECONDS", 5);
        var prefix = string.IsNullOrWhiteSpace(configuration["CINERION_LOAD_DEVICE_PREFIX"])
            ? "CH1-DEV-LOAD-"
            : configuration["CINERION_LOAD_DEVICE_PREFIX"]!;

        using var client = new ControlCoreIngressClient(options);

        Console.WriteLine(
            $"LOAD CONFIG devices={devices} channelsPerDevice={ControlledChannels.Length} " +
            $"liveChannels={devices * ControlledChannels.Length} targetMessagesPerSecond={targetRate} seconds={seconds} " +
            $"warmupSeconds={warmupSeconds}");

        // Each device publishes at the same cadence, so the aggregate is the requirement and
        // no single device is carrying the run. A rate that 25 devices cannot divide evenly
        // is reported rather than rounded away.
        var perDevicePeriod = TimeSpan.FromSeconds((double)devices / targetRate);
        var accepted = 0;
        var refused = 0;
        var failed = 0;

        // Each latency is kept with the second it landed in, so the percentiles describe
        // the measured window rather than the warm-up that preceded it.
        var latencies = new System.Collections.Concurrent.ConcurrentBag<(int Bucket, double Milliseconds)>();

        // One extra second is offered after the measured window closes, so that every
        // second inside it is complete and fully drained. The old convention - drop the
        // first and last bucket as "partial by construction" - kept the first COMPLETE
        // second, which is the cold one.
        var offeredSeconds = warmupSeconds + seconds + 1;
        var perSecond = new int[offeredSeconds + 2];

        // What was OFFERED, second by second, beside what completed. Without it a shortfall
        // cannot be attributed: a second carrying 96 completions looks identical whether the
        // service could not keep up or the driver never issued the other four. It is the
        // second reading that turns "the rate was missed" into a diagnosis.
        var issuedPerSecond = new int[offeredSeconds + 2];
        var refusalCodes = new System.Collections.Concurrent.ConcurrentDictionary<string, int>(StringComparer.Ordinal);

        using var run = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        run.CancelAfter(TimeSpan.FromSeconds(offeredSeconds));

        // The wall clock beside the stopwatch, so that anything measuring this run from
        // outside can say exactly which of its own observations fall inside the measured
        // window. Inferring that boundary - from when data first appeared, from poll
        // numbers - put observations taken after the load had stopped into a percentile
        // describing the load: the newest reading simply aged, 0.9 s then 1.9 s then 3.0 s
        // off one unchanging sample, and the figure was three times the truth.
        var startedAt = DateTimeOffset.UtcNow;
        var clock = Stopwatch.StartNew();

        // Pacing is decoupled from completion, and that is the whole correctness of the
        // measurement. A publisher that waits for each acknowledgement before issuing the
        // next one cannot exceed concurrency ÷ latency, so it measures round-trip latency
        // and reports it as throughput — with 25 devices at half a second a call it would
        // report 46/s however much the service could actually carry. A real gateway does
        // not block either: it has readings to send and sends them.
        //
        // In-flight work is still bounded, because an unbounded flood is a different test
        // from a sustained rate, and CH1-COM-PRO-0001's flow control is on this side too.
        using var inFlight = new SemaphoreSlim(MaximumInFlight, MaximumInFlight);
        var issued = new System.Collections.Concurrent.ConcurrentBag<Task>();
        var sequences = new long[devices];

        var publishers = Enumerable.Range(0, devices).Select(index => Task.Run(async () =>
        {
            var deviceId = $"{prefix}{index + 1:D4}";
            // Staggered, because 25 publishers released on the same instant produce a
            // thundering start and then a saw-tooth, which is not a sustained rate.
            try
            {
                // The cadence is absolute, not accumulated, and that is a correctness
                // property of the measurement rather than a refinement of it. Computing the
                // next due time as "now plus the period" loses every overshoot for good, and
                // Task.Delay on Windows overshoots by up to the 15.6 ms timer tick. Over a
                // 66-second run at a 630 ms period that quietly cost about 0.4 %, so the
                // driver offered 99.6 msg/s while reporting itself configured for 100 - and
                // the service was then judged for not carrying a load nobody had offered it.
                // Against an absolute schedule a late iteration is followed by a shorter
                // wait, so the error does not accumulate.
                var stagger = perDevicePeriod * index / devices;
                var publication = 0L;

                while (!run.Token.IsCancellationRequested)
                {
                    var dueAt = stagger + (perDevicePeriod * publication);
                    var wait = dueAt - clock.Elapsed;
                    if (wait > TimeSpan.Zero)
                    {
                        await Task.Delay(wait, run.Token).ConfigureAwait(false);
                    }

                    publication++;
                    await inFlight.WaitAsync(run.Token).ConfigureAwait(false);

                    var startedAt = clock.Elapsed;
                    var issuedBucket = (int)startedAt.TotalSeconds;
                    if (issuedBucket >= 0 && issuedBucket < issuedPerSecond.Length)
                    {
                        Interlocked.Increment(ref issuedPerSecond[issuedBucket]);
                    }
                    var sampledAt = DateTimeOffset.UtcNow;
                    var sequence = Interlocked.Increment(ref sequences[index]);
                    var readings = ControlledChannels.Select(channel => new TelemetryPoint(
                        deviceId,
                        channel.Channel,
                        channel.Low + ((channel.High - channel.Low) * Random.Shared.NextDouble()),
                        channel.Unit,
                        "Good",
                        sampledAt,
                        sequence,
                        // The load rig is this gateway offering its own clock's samples.
                        TelemetryPoint.GatewayStamped)).ToArray();

                    issued.Add(Task.Run(async () =>
                    {
                        try
                        {
                            var receipt = await client.PublishTelemetryAsync(deviceId, readings, run.Token)
                                .ConfigureAwait(false);
                            var finishedAt = clock.Elapsed;
                            var bucket = (int)finishedAt.TotalSeconds;
                            latencies.Add((bucket, (finishedAt - startedAt).TotalMilliseconds));

                            if (receipt.Accepted)
                            {
                                Interlocked.Increment(ref accepted);
                                if (bucket >= 0 && bucket < perSecond.Length)
                                {
                                    Interlocked.Increment(ref perSecond[bucket]);
                                }
                            }
                            else
                            {
                                Interlocked.Increment(ref refused);
                                refusalCodes.AddOrUpdate(receipt.ReasonCode, 1, (_, count) => count + 1);
                            }
                        }
                        catch (OperationCanceledException)
                        {
                            // The run's own clock stopped it mid-flight. Not a failure of
                            // the service, and counting it as one would make a correct
                            // system fail its own gate at the last second of every run.
                        }
                        catch (Grpc.Core.RpcException error)
                            when (error.StatusCode == Grpc.Core.StatusCode.Cancelled && run.IsCancellationRequested)
                        {
                            // gRPC reports that same shutdown as a cancelled call.
                        }
                        catch (Grpc.Core.RpcException error)
                        {
                            Interlocked.Increment(ref failed);
                            refusalCodes.AddOrUpdate(
                                $"TRANSPORT_{error.StatusCode}", 1, (_, count) => count + 1);
                        }
                        finally
                        {
                            inFlight.Release();
                        }
                    }, CancellationToken.None));
                }
            }
            catch (OperationCanceledException)
            {
                // The run ended on its own clock; that is how it stops.
            }
        }, CancellationToken.None)).ToArray();

        await Task.WhenAll(publishers).ConfigureAwait(false);
        await Task.WhenAll(issued).ConfigureAwait(false);

        clock.Stop();
        var elapsedSeconds = clock.Elapsed.TotalSeconds;

        // The measured window: the `seconds` whole seconds that follow the warm-up. Every
        // one of them is complete, and every one of them is judged.
        var measured = perSecond.Skip(warmupSeconds).Take(seconds).ToArray();
        var measuredAccepted = measured.Sum();
        var achieved = seconds > 0 ? measuredAccepted / (double)seconds : 0;
        var worstSecond = measured.Length > 0 ? measured.Min() : 0;

        var measuredIssued = issuedPerSecond.Skip(warmupSeconds).Take(seconds).ToArray();
        var offeredRate = seconds > 0 ? measuredIssued.Sum() / (double)seconds : 0;

        // How far behind the service ever fell, in publications, over the measured window.
        // This is what "sustained" is really asking: a service that keeps up has a bounded
        // outstanding count, and one that does not has a growing one. It is immune to the
        // arbitrary placement of a one-second boundary, which a per-bucket minimum is not.
        var worstBacklog = 0;
        var outstanding = 0;
        for (var second = 0; second < warmupSeconds + seconds; second++)
        {
            outstanding += issuedPerSecond[second] - perSecond[second];
            if (second >= warmupSeconds && outstanding > worstBacklog)
            {
                worstBacklog = outstanding;
            }
        }

        var ordered = latencies
            .Where(entry => entry.Bucket >= warmupSeconds && entry.Bucket < warmupSeconds + seconds)
            .Select(entry => entry.Milliseconds)
            .OrderBy(value => value)
            .ToArray();
        double Percentile(double fraction) => ordered.Length == 0
            ? 0
            : ordered[Math.Min(ordered.Length - 1, (int)Math.Floor(fraction * ordered.Length))];

        // Measured: what the requirement is judged on. Total: everything the run
        // offered, warm-up included, which is what must be found in the database
        // afterwards. Reporting only one of the two would let the other hide something.
        Console.WriteLine($"LOAD ACCEPTED {measuredAccepted}");
        Console.WriteLine($"LOAD TOTAL-ACCEPTED {accepted}");
        Console.WriteLine($"LOAD WARMUP-SECONDS {warmupSeconds}");
        Console.WriteLine(
            "LOAD WINDOW-OPENED " +
            startedAt.AddSeconds(warmupSeconds).ToString("O", System.Globalization.CultureInfo.InvariantCulture));
        Console.WriteLine(
            "LOAD WINDOW-CLOSED " +
            startedAt.AddSeconds(warmupSeconds + seconds).ToString("O", System.Globalization.CultureInfo.InvariantCulture));
        Console.WriteLine($"LOAD MEASURED-SECONDS {seconds}");
        Console.WriteLine($"LOAD REFUSED {refused}");
        Console.WriteLine($"LOAD TRANSPORT-FAILED {failed}");
        Console.WriteLine($"LOAD ELAPSED-SECONDS {elapsedSeconds:0.00}");
        Console.WriteLine($"LOAD ACHIEVED-MESSAGES-PER-SECOND {achieved:0.00}");
        Console.WriteLine($"LOAD WORST-COMPLETE-SECOND {worstSecond}");
        Console.WriteLine($"LOAD OFFERED-MESSAGES-PER-SECOND {offeredRate:0.00}");

        // Issued, and what became of it. A publication still in flight when the run's clock
        // stopped was cancelled on this side while the service went on to store it, so it
        // is neither accepted nor refused nor failed - it is unaccounted, and the database
        // will hold it. Saying so is what lets the gate bracket the row count exactly
        // instead of settling for "at least", which would hide a service writing more than
        // it was asked to.
        var issuedTotal = issuedPerSecond.Sum();
        Console.WriteLine($"LOAD ISSUED {issuedTotal}");
        Console.WriteLine($"LOAD UNACCOUNTED {Math.Max(0, issuedTotal - accepted - refused - failed)}");
        Console.WriteLine($"LOAD WORST-BACKLOG {worstBacklog}");

        // The whole profile, second by second, because a single worst number cannot
        // distinguish the three things that produce one. A first-seconds dip is the
        // service warming up; a dip that repeats on a period is the database
        // checkpointing; a single dip anywhere is a pause. They need different
        // answers, and a gate that reports only the minimum leaves the next person
        // guessing which one they have - which is how the ceiling stayed undiagnosed
        // for two sessions.
        Console.WriteLine(
            "LOAD PER-SECOND " + string.Join(
                ",",
                perSecond.Take(Math.Max(0, (int)Math.Ceiling(elapsedSeconds)))));
        Console.WriteLine(
            "LOAD ISSUED-PER-SECOND " + string.Join(
                ",",
                issuedPerSecond.Take(Math.Max(0, (int)Math.Ceiling(elapsedSeconds)))));
        Console.WriteLine($"LOAD DEVICES {devices}");
        Console.WriteLine($"LOAD LIVE-CHANNELS {devices * ControlledChannels.Length}");
        Console.WriteLine($"LOAD LATENCY-P50-MS {Percentile(0.50):0.0}");
        Console.WriteLine($"LOAD LATENCY-P95-MS {Percentile(0.95):0.0}");
        Console.WriteLine($"LOAD LATENCY-P99-MS {Percentile(0.99):0.0}");
        foreach (var (code, count) in refusalCodes.OrderByDescending(entry => entry.Value))
        {
            Console.WriteLine($"LOAD REFUSAL-CODE {code} {count}");
        }

        // A driver that could not offer the load has not tested anything, and says so rather
        // than reporting a low number as though it were a measurement of the service.
        return refused == 0 && failed == 0 ? 0 : 1;
    }

    private static int Read(IConfiguration configuration, string key, int fallback)
    {
        var value = configuration[key];
        return string.IsNullOrWhiteSpace(value)
            ? fallback
            : int.TryParse(value, out var parsed) && parsed > 0
                ? parsed
                : throw new InvalidOperationException($"{key} must be a positive integer: '{value}'.");
    }
}
