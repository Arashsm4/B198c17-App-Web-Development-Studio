// A test client that attacks the ingress and reports everything it couldn't get away with.

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Cinerion.Contracts.EdgeLink.V1;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Grpc.Net.Client;

namespace Cinerion.EdgeLink.Ingress;

/// <summary>
/// A verification client that attacks the CH1-COM-IF-0003 ingress and reports what it
/// could not do.
/// <para>
/// It is deliberately not a well-behaved gateway. It connects with no certificate, with
/// one the controlled authority never signed, with one signed for a different gateway, and
/// in clear; it names another gateway in the envelope, a schema nobody serves, a device
/// that is not enrolled, a cell that device is not assigned to, a command nobody prepared
/// and a telemetry channel outside the controlled catalogue; it replays a message it has
/// already sent, back-dates one, and reports permissives it has not read.
/// </para>
/// <para>
/// Two probes deliberately succeed. Without them every refusal above would be equally well
/// explained by an endpoint that is simply broken, which is the failure mode an attack
/// suite is most likely to hide behind.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-CYB-FR-0001, CH1-CYB-TMD-0001</requirements>
public static class Ch1IngressProbe
{
    public static async Task<int> RunAsync(IConfiguration configuration, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var endpoint = new Uri(Required(configuration, "CINERION_EDGE_GRPC_ENDPOINT"));
        var caPath = Required(configuration, "CINERION_EDGE_GRPC_CA_CERT");
        var certificatePath = Required(configuration, "CINERION_EDGE_GRPC_CLIENT_CERT");
        var keyPath = Required(configuration, "CINERION_EDGE_GRPC_CLIENT_KEY");
        var identity = Required(configuration, "CINERION_EDGE_GRPC_GATEWAY_IDENTITY");
        var projectId = Guid.Parse(Required(configuration, "CINERION_EDGE_GRPC_PROJECT_ID"));
        var cellId = Guid.Parse(Required(configuration, "CINERION_EDGE_GRPC_CELL_ID"));
        var controllerId = configuration["CINERION_EDGE_GRPC_CONTROLLER_ID"] ?? "CH1-DEV-CELL-0001";

        using var authority = X509CertificateLoader.LoadCertificateFromFile(caPath);
        var failures = 0;

        void Report(string checkId, bool passed, string observation)
        {
            Console.WriteLine($"PROBE {(passed ? "PASS" : "FAIL")} {checkId}: {observation}");
            if (!passed)
            {
                failures++;
            }
        }

        var probe = new ProbeMessages(identity, projectId, cellId, controllerId);

        // --- The transport controls, before any message is judged ------------------------

        // Refused *at the transport*, and the probe insists on that rather than on refusal
        // in general. There are two independent controls here — Kestrel requiring a client
        // certificate, and RequirePeer refusing a call that arrives without one — and
        // attacking the gate proved it: with the Kestrel requirement relaxed the connection
        // still failed, but with the service's own message instead of a handshake failure.
        // A probe satisfied by either would have reported a control that was no longer
        // there. This one measures the transport; the service's own refusal is a second
        // defence that this deliberately does not accept as a substitute.
        var noCertificate = await SendAsync(endpoint, authority, null, probe.ValidReport(), cancellationToken)
            .ConfigureAwait(false);
        Report(
            "PROBE-01-NO-CLIENT-CERTIFICATE-REFUSED",
            !noCertificate.Accepted && noCertificate.RefusedByTransport,
            noCertificate.Describe());

        var foreign = await WithCertificateAsync(
            configuration, "CINERION_EDGE_GRPC_FOREIGN_CERT", "CINERION_EDGE_GRPC_FOREIGN_KEY",
            certificate => SendAsync(endpoint, authority, certificate, probe.ValidReport(), cancellationToken))
            .ConfigureAwait(false);
        Report(
            "PROBE-02-FOREIGN-CERTIFICATE-REFUSED",
            foreign is not null && !foreign.Accepted,
            foreign?.Describe()
                ?? "no foreign certificate was supplied, so the control was not measured");

        var otherGateway = await WithCertificateAsync(
            configuration, "CINERION_EDGE_GRPC_OTHER_GATEWAY_CERT", "CINERION_EDGE_GRPC_OTHER_GATEWAY_KEY",
            certificate => SendAsync(endpoint, authority, certificate, probe.ValidReport(), cancellationToken))
            .ConfigureAwait(false);
        // Refused *for being another gateway*, not merely refused. The same lesson as
        // PROBE-01: with the identity check removed, this attempt was still refused —
        // because the envelope's source no longer matched the peer the certificate named,
        // which PROBE-08 already measures. Requiring the identity refusal by name keeps the
        // two probes measuring two different controls.
        Report(
            "PROBE-03-OTHER-GATEWAY-REFUSED",
            otherGateway is not null && !otherGateway.Accepted && otherGateway.Detail.Contains("names another gateway", StringComparison.Ordinal),
            otherGateway?.Describe()
                ?? "no second gateway certificate was supplied, so the control was not measured");

        var plaintext = await SendPlaintextAsync(endpoint, probe.ValidReport(), cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-04-PLAINTEXT-REFUSED",
            !plaintext.Accepted,
            plaintext.Describe());

        // --- Everything below is the real gateway, so a refusal is the domain's decision --

        using var trusted = X509Certificate2.CreateFromPemFile(certificatePath, keyPath);

        var accepted = await SendAsync(endpoint, authority, trusted, probe.ValidReport(), cancellationToken)
            .ConfigureAwait(false);
        Report(
            "PROBE-05-CORRECT-GATEWAY-ACCEPTED",
            accepted.Accepted && accepted.ReasonCode == "CONTROLLER_REPORT_ACCEPTED",
            accepted.Describe());

        var replay = probe.ValidReport();
        await SendAsync(endpoint, authority, trusted, replay, cancellationToken).ConfigureAwait(false);
        var replayed = await SendAsync(endpoint, authority, trusted, replay, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-06-REPLAYED-MESSAGE-REFUSED",
            !replayed.Accepted && replayed.ReasonCode == "INGRESS_DUPLICATE_MESSAGE",
            replayed.Describe());

        var backdated = probe.ValidReport();
        backdated.Envelope.OccurredAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow.AddMinutes(-5));
        var superseded = await SendAsync(endpoint, authority, trusted, backdated, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-07-BACKDATED-REPORT-REFUSED",
            !superseded.Accepted && superseded.ReasonCode == "INGRESS_REPORT_SUPERSEDED",
            superseded.Describe());

        var impersonated = probe.ValidReport();
        impersonated.Envelope.SourceId = "ch1-some-other-gateway";
        var impersonation = await SendAsync(endpoint, authority, trusted, impersonated, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-08-SOURCE-IDENTITY-MISMATCH-REFUSED",
            !impersonation.Accepted && impersonation.ReasonCode == "INGRESS_SOURCE_IDENTITY_MISMATCH",
            impersonation.Describe());

        var wrongSchema = probe.ValidReport();
        wrongSchema.Envelope.SchemaVersion = "2.0.0";
        var schema = await SendAsync(endpoint, authority, trusted, wrongSchema, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-09-UNKNOWN-SCHEMA-REFUSED",
            !schema.Accepted && schema.ReasonCode == "INGRESS_SCHEMA_UNSUPPORTED",
            schema.Describe());

        var expired = probe.ValidReport();
        expired.Envelope.ExpiresAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow.AddSeconds(-30));
        var expiry = await SendAsync(endpoint, authority, trusted, expired, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-10-EXPIRED-MESSAGE-REFUSED",
            !expiry.Accepted && expiry.ReasonCode == "INGRESS_MESSAGE_EXPIRED",
            expiry.Describe());

        var strangerDevice = probe.ValidReport();
        strangerDevice.ControllerId = "CH1-DEV-NOT-ENROLLED-9999";
        var stranger = await SendAsync(endpoint, authority, trusted, strangerDevice, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-11-UNENROLLED-DEVICE-REFUSED",
            !stranger.Accepted && stranger.ReasonCode == "INGRESS_DEVICE_NOT_ENROLLED",
            stranger.Describe());

        var foreignCell = probe.ValidReport();
        foreignCell.Envelope.CellId = Guid.NewGuid().ToString();
        var cellScope = await SendAsync(endpoint, authority, trusted, foreignCell, cancellationToken).ConfigureAwait(false);
        Report(
            "PROBE-12-DEVICE-CELL-MISMATCH-REFUSED",
            !cellScope.Accepted && cellScope.ReasonCode == "INGRESS_DEVICE_CELL_MISMATCH",
            cellScope.Describe());

        // The one that decides whether equipment may move. A controller that did not answer
        // its permissives must leave the cell not permissive, and Control Core says so in
        // the reason code it returns rather than accepting the report silently.
        var unanswered = await SendAsync(endpoint, authority, trusted, probe.PermissivesNotReported(), cancellationToken)
            .ConfigureAwait(false);
        Report(
            "PROBE-13-UNANSWERED-PERMISSIVES-NOT-PERMISSIVE",
            unanswered.Accepted && unanswered.ReasonCode == "PERMISSIVES_NOT_REPORTED_CELL_NOT_PERMISSIVE",
            unanswered.Describe());

        var unknownChannel = await SendTelemetryAsync(
            endpoint, authority, trusted, probe.TelemetryOnChannel("rotor_speed", "rpm"), cancellationToken)
            .ConfigureAwait(false);
        Report(
            "PROBE-14-UNCATALOGUED-CHANNEL-REFUSED",
            !unknownChannel.Accepted && unknownChannel.ReasonCode == "TELEMETRY_CHANNEL_NOT_ALLOWED",
            unknownChannel.Describe());

        var wrongUnit = await SendTelemetryAsync(
            endpoint, authority, trusted, probe.TelemetryOnChannel("temperature", "mm"), cancellationToken)
            .ConfigureAwait(false);
        Report(
            "PROBE-15-UNIT-MISMATCH-REFUSED",
            !wrongUnit.Accepted && wrongUnit.ReasonCode == "TELEMETRY_UNIT_MISMATCH",
            wrongUnit.Describe());

        var invented = await SendAcknowledgementAsync(
            endpoint, authority, trusted, probe.AcknowledgementFor(Guid.NewGuid()), cancellationToken)
            .ConfigureAwait(false);
        Report(
            "PROBE-16-UNKNOWN-COMMAND-ACKNOWLEDGEMENT-REFUSED",
            !invented.Accepted && invented.ReasonCode == "INGRESS_COMMAND_NOT_FOUND",
            invented.Describe());

        Console.WriteLine(failures == 0
            ? "PROBE SUMMARY: every attack on the CH1-COM-IF-0003 ingress was refused, and the two control probes were accepted."
            : $"PROBE SUMMARY: {failures} probe(s) failed.");
        return failures;
    }

    /// <summary>The messages a well-behaved gateway would not send, built once and mutated per probe.</summary>
    private sealed class ProbeMessages(string identity, Guid projectId, Guid cellId, string controllerId)
    {
        private long _sequence;

        public Envelope NewEnvelope(string messageType) => new()
        {
            SchemaVersion = "1.0.0",
            MessageType = messageType,
            MessageId = Guid.NewGuid().ToString(),
            CorrelationId = Guid.NewGuid().ToString(),
            SourceId = identity,
            DestinationId = "cinerion-control-core",
            ProjectId = projectId.ToString(),
            CellId = cellId.ToString(),
            Sequence = Interlocked.Increment(ref _sequence),
            OccurredAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow),
            TimeQuality = TimeQuality.Qualified,
        };

        public ControllerStateReport ValidReport() => Build(permissivesReported: true);

        /// <summary>
        /// The dangerous shape, not the harmless one: <c>reported</c> is false while every
        /// individual permissive says the machine is ready to move.
        /// <para>
        /// A report with everything false would be refused by the values alone and would
        /// prove nothing about whether <c>reported</c> is load-bearing — which is exactly
        /// what attacking this gate showed. It is also the realistic mistake: proto3 leaves
        /// an unset boolean false, so a gateway that populates the interlocks and forgets
        /// the flag sends precisely this, and it must not arm anything.
        /// </para>
        /// </summary>
        public ControllerStateReport PermissivesNotReported()
        {
            var report = Build(permissivesReported: true);
            report.Permissives.Reported = false;

            // The controlled SCL's own numbering. 206 is EXPECTED_STATE_MISMATCH and 207 is
            // PRELIMINARY_PERMISSIVE_INVALID: the two checks a stand-in cannot answer,
            // because one needs the CPU's own material state and the other needs wired
            // inputs. Naming them is what makes the refusal attributable.
            report.Permissives.DeferredCheckCodes.Add(206);
            report.Permissives.DeferredCheckCodes.Add(207);
            return report;
        }

        public TelemetryPublication TelemetryOnChannel(string channelId, string unit)
        {
            var publication = new TelemetryPublication
            {
                Envelope = NewEnvelope("Telemetry"),
                DeviceId = controllerId,
            };
            publication.Readings.Add(new TelemetryReading
            {
                ChannelId = channelId,
                Value = 21.5,
                Unit = unit,
                Quality = DataQuality.Good,
                Freshness = global::Cinerion.Contracts.EdgeLink.V1.Freshness.Simulated,
                SampledAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow),
                Sequence = 1,
            });
            return publication;
        }

        public CommandAcknowledgement AcknowledgementFor(Guid commandId) => new()
        {
            Envelope = NewEnvelope("CommandAcknowledgement"),
            CommandId = commandId.ToString(),
            ControllerId = controllerId,
            Accepted = true,
            ControllerState = "AwaitingCredential",
            ReasonCode = "PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION",
            ObservedAt = Timestamp.FromDateTimeOffset(DateTimeOffset.UtcNow),
            AdapterId = "CH1-ADP-PROBE-0001",
        };

        private ControllerStateReport Build(bool permissivesReported) => new()
        {
            Envelope = NewEnvelope("ControllerState"),
            ControllerId = controllerId,
            ControllerBootId = Guid.NewGuid().ToString(),
            OperatingState = ControllerOperatingState.Idle,
            ConfigurationRevision = "CFG-REFAB-P01-R01",
            Permissives = new Permissives
            {
                Reported = permissivesReported,
                ControllerOnline = permissivesReported,
                StartEnable = permissivesReported,
                StopCircuitHealthy = permissivesReported,
                GuardHealthy = permissivesReported,
                ActuatorHome = permissivesReported,
            },
            AdapterId = "CH1-ADP-PROBE-0001",
            Protocol = "PROBE",
            SecurityProfile = "PROBE-VERIFICATION-CLIENT",
            FirmwareVersion = "probe",
            Freshness = global::Cinerion.Contracts.EdgeLink.V1.Freshness.Simulated,
        };
    }

    /// <summary>What the ingress did with one probe message.</summary>
    private sealed record ProbeOutcome(bool Reached, bool Accepted, string ReasonCode, string Detail)
    {
        public static ProbeOutcome TransportRefused(string detail) => new(false, false, "TRANSPORT_REFUSED", detail);

        /// <summary>
        /// Whether the connection failed before any handler ran, rather than being answered
        /// by one. A TLS handshake this server refused surfaces as a transport exception the
        /// gRPC stack reports as <c>Internal</c> or <c>Unavailable</c> with an HTTP/2 or SSL
        /// message; an application refusal carries a gRPC status the service chose. The
        /// difference is the whole distinction between "the transport requires a
        /// certificate" and "the service noticed there wasn't one".
        /// </summary>
        public bool RefusedByTransport =>
            !Accepted &&
            (ReasonCode is "TRANSPORT_REFUSED" or "Internal" or "Unavailable") &&
            (Detail.Contains("HTTP/2", StringComparison.Ordinal) ||
             Detail.Contains("SSL", StringComparison.OrdinalIgnoreCase) ||
             Detail.Contains("authentication", StringComparison.OrdinalIgnoreCase));

        /// <summary>
        /// What actually happened, stated plainly. The check identifier already says what
        /// was expected — PROBE-01-NO-CLIENT-CERTIFICATE-REFUSED — so this reads correctly
        /// whether the probe passed or failed, which a message written only for the failing
        /// case does not.
        /// </summary>
        public string Describe() => Accepted
            ? $"accepted, reason {ReasonCode}"
            : Reached
                ? $"refused by the domain as {ReasonCode}: {Trim(Detail)}"
                : $"refused at the transport: {Trim(Detail)}";

        private static string Trim(string detail) =>
            detail.Length <= 140 ? detail : string.Concat(detail.AsSpan(0, 140), "…");
    }

    private static async Task<ProbeOutcome?> WithCertificateAsync(
        IConfiguration configuration,
        string certificateKey,
        string keyKey,
        Func<X509Certificate2, Task<ProbeOutcome>> attempt)
    {
        var certificatePath = configuration[certificateKey];
        var keyPath = configuration[keyKey];
        if (string.IsNullOrWhiteSpace(certificatePath) || string.IsNullOrWhiteSpace(keyPath))
        {
            return null;
        }

        using var certificate = X509Certificate2.CreateFromPemFile(certificatePath, keyPath);
        return await attempt(certificate).ConfigureAwait(false);
    }

    private static Task<ProbeOutcome> SendAsync(
        Uri endpoint,
        X509Certificate2 authority,
        X509Certificate2? clientCertificate,
        ControllerStateReport request,
        CancellationToken cancellationToken) =>
        InvokeAsync(
            endpoint,
            authority,
            clientCertificate,
            client => client.PublishControllerStateAsync(request, cancellationToken: cancellationToken).ResponseAsync);

    private static Task<ProbeOutcome> SendTelemetryAsync(
        Uri endpoint,
        X509Certificate2 authority,
        X509Certificate2 clientCertificate,
        TelemetryPublication request,
        CancellationToken cancellationToken) =>
        InvokeAsync(
            endpoint,
            authority,
            clientCertificate,
            client => client.PublishTelemetryAsync(request, cancellationToken: cancellationToken).ResponseAsync);

    private static Task<ProbeOutcome> SendAcknowledgementAsync(
        Uri endpoint,
        X509Certificate2 authority,
        X509Certificate2 clientCertificate,
        CommandAcknowledgement request,
        CancellationToken cancellationToken) =>
        InvokeAsync(
            endpoint,
            authority,
            clientCertificate,
            client => client.AcknowledgeCommandAsync(request, cancellationToken: cancellationToken).ResponseAsync);

    /// <summary>
    /// One call on a channel built for this probe alone, so a refused handshake cannot be
    /// masked by a connection an earlier probe had already established.
    /// </summary>
    private static async Task<ProbeOutcome> InvokeAsync(
        Uri endpoint,
        X509Certificate2 authority,
        X509Certificate2? clientCertificate,
        Func<EdgeLinkIngress.EdgeLinkIngressClient, Task<IngressReceipt>> call)
    {
        var handler = new SocketsHttpHandler
        {
            SslOptions = new SslClientAuthenticationOptions
            {
                ClientCertificates = clientCertificate is null ? [] : [clientCertificate],
                RemoteCertificateValidationCallback = (_, certificate, _, _) => ValidatedBy(certificate, authority),
            },
        };
        using var channel = GrpcChannel.ForAddress(endpoint, new GrpcChannelOptions
        {
            HttpHandler = handler,
            DisposeHttpClient = true,
        });

        try
        {
            var receipt = await call(new EdgeLinkIngress.EdgeLinkIngressClient(channel)).ConfigureAwait(false);
            return new ProbeOutcome(true, receipt.Accepted, receipt.ReasonCode, receipt.Detail);
        }
        catch (RpcException error)
        {
            return new ProbeOutcome(false, false, error.StatusCode.ToString(), error.Status.Detail);
        }
    }

    /// <summary>The plaintext attempt, which must not even negotiate.</summary>
    private static async Task<ProbeOutcome> SendPlaintextAsync(
        Uri secureEndpoint,
        ControllerStateReport request,
        CancellationToken cancellationToken)
    {
        var plaintext = new UriBuilder(secureEndpoint) { Scheme = Uri.UriSchemeHttp }.Uri;
        using var channel = GrpcChannel.ForAddress(plaintext, new GrpcChannelOptions
        {
            HttpHandler = new SocketsHttpHandler(),
            DisposeHttpClient = true,
        });

        try
        {
            var receipt = await new EdgeLinkIngress.EdgeLinkIngressClient(channel)
                .PublishControllerStateAsync(request, cancellationToken: cancellationToken)
                .ResponseAsync.ConfigureAwait(false);
            return new ProbeOutcome(true, receipt.Accepted, receipt.ReasonCode, receipt.Detail);
        }
        catch (RpcException error)
        {
            return ProbeOutcome.TransportRefused($"{error.StatusCode}: {error.Status.Detail}");
        }
    }

    private static bool ValidatedBy(System.Security.Cryptography.X509Certificates.X509Certificate? certificate, X509Certificate2 authority)
    {
        if (certificate is null)
        {
            return false;
        }

        using var presented = X509CertificateLoader.LoadCertificate(certificate.Export(X509ContentType.Cert));
        using var chain = new X509Chain
        {
            ChainPolicy =
            {
                TrustMode = X509ChainTrustMode.CustomRootTrust,
                RevocationMode = X509RevocationMode.NoCheck,
            },
        };
        chain.ChainPolicy.CustomTrustStore.Add(authority);
        return chain.Build(presented);
    }

    private static string Required(IConfiguration configuration, string key) =>
        configuration[key] ?? throw new InvalidOperationException($"{key} is required to run the ingress probe.");
}
