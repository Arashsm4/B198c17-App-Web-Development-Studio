// Settings for reaching Control Core: where it is, and who vouches for it.

using System.Security.Cryptography.X509Certificates;

namespace Cinerion.EdgeLink.Ingress;

/// <summary>
/// The gateway's half of CH1-COM-IF-0003: where Control Core is, the controlled authority
/// that attests it, this gateway's own certificate and key, and the scope it reports for.
/// <para>
/// <b>All of it or none.</b> The same rule the MQTT and OPC UA adapters follow. An
/// unconfigured deployment publishes nothing and says so at startup, rather than opening
/// an unauthenticated channel into the domain or quietly dropping what its adapters
/// observe.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-CYB-FR-0001</requirements>
public sealed record ControlCoreIngressOptions(
    Uri Endpoint,
    X509Certificate2 ClientCertificate,
    X509Certificate2 CertificateAuthority,
    string GatewayIdentity,
    Guid ProjectId,
    Guid SiteId,
    Guid CellId,
    Guid AssetId,
    // Which adapter speaks for this cell's controller, when more than one can. One cell has
    // one controller; a gateway fronting two controller-state sources would otherwise
    // publish alternating reports into the same cell and make its permissives flap. Unset is
    // correct while only one adapter can report, and is refused the moment two can.
    string? ControllerAdapterId = null,
    // What this gateway declares about its OWN clock, and therefore about every sample it
    // stamps itself and every envelope it sends.
    //
    // It used to be the literal `TimeQuality.Qualified`, asserted on every message
    // unconditionally, and nothing on this workstation or in the controlled deployment
    // model disciplines the gateway's clock against a traceable source. Control Core says
    // the same thing about its own with `SystemClock-Unqualified`; a gateway claiming
    // better while sitting in the same container runtime was claiming something nobody had
    // established. CH1-COM-ICD-0001 requires time quality to be observable "so audit and
    // TOTP decisions are not silently made on invalid time", and an unconditional
    // assertion is the opposite of observable. Defect 59, conflict 27.
    //
    // A deployment that DOES discipline this host - a control-zone time server, the same
    // one the node reads from `ch1_cfg/sntp_server` - sets
    // CINERION_EDGE_GATEWAY_TIME_QUALITY to Qualified or Trusted and can then say so
    // truthfully. The default under-claims, which is the direction that is safe.
    string GatewayTimeQuality = "Unknown")
{
    /// <summary>
    /// Reads a declared gateway clock quality, refusing anything the contract does not
    /// contain rather than passing it through as a string nobody will recognise. An unset
    /// or unrecognised value is Unknown - never Qualified, because a deployment that has
    /// not said its clock is disciplined has not disciplined it.
    /// </summary>
    private static string NormaliseTimeQuality(string? declared) => declared?.Trim() switch
    {
        "Trusted" => "Trusted",
        "Qualified" => "Qualified",
        "Degraded" => "Degraded",
        _ => "Unknown",
    };

    public static ControlCoreIngressOptions? FromConfiguration(IConfiguration configuration)
    {
        var endpoint = configuration["CINERION_EDGE_GRPC_ENDPOINT"];
        var caPath = configuration["CINERION_EDGE_GRPC_CA_CERT"];
        var certificatePath = configuration["CINERION_EDGE_GRPC_CLIENT_CERT"];
        var keyPath = configuration["CINERION_EDGE_GRPC_CLIENT_KEY"];
        var identity = configuration["CINERION_EDGE_GRPC_GATEWAY_IDENTITY"];
        var projectId = configuration["CINERION_EDGE_GRPC_PROJECT_ID"];
        var cellId = configuration["CINERION_EDGE_GRPC_CELL_ID"];

        if (string.IsNullOrWhiteSpace(endpoint) || string.IsNullOrWhiteSpace(caPath) ||
            string.IsNullOrWhiteSpace(certificatePath) || string.IsNullOrWhiteSpace(keyPath) ||
            string.IsNullOrWhiteSpace(identity) || string.IsNullOrWhiteSpace(projectId) ||
            string.IsNullOrWhiteSpace(cellId))
        {
            return null;
        }

        return new ControlCoreIngressOptions(
            new Uri(endpoint),
            X509Certificate2.CreateFromPemFile(certificatePath, keyPath),
            X509CertificateLoader.LoadCertificateFromFile(caPath),
            identity,
            Guid.Parse(projectId),
            ParseOptional(configuration["CINERION_EDGE_GRPC_SITE_ID"]),
            Guid.Parse(cellId),
            ParseOptional(configuration["CINERION_EDGE_GRPC_ASSET_ID"]),
            configuration["CINERION_EDGE_CONTROLLER_ADAPTER"],
            NormaliseTimeQuality(configuration["CINERION_EDGE_GATEWAY_TIME_QUALITY"]));
    }

    private static Guid ParseOptional(string? value) =>
        Guid.TryParse(value, out var parsed) ? parsed : Guid.Empty;
}
