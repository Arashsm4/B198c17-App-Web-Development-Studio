// Spots what changed between two controller readings, so the gateway reports news, not reruns.

using Cinerion.Contracts.EdgeLink.V1;
using Cinerion.EdgeLink.Contracts;

namespace Cinerion.EdgeLink.Runtime;

/// <summary>One transition the gateway observed between two readings of a controller.</summary>
public sealed record ControllerTransition(ControllerEventKind Kind, string ReasonCode);

/// <summary>
/// Works out what changed between two observations of a controller.
/// <para>
/// This lives at the gateway because only the gateway sees both sides of a transition
/// during an outage — Control Core, by definition, sees nothing at all. A guard that opens
/// and closes while the link is down leaves no evidence anywhere unless something at the
/// edge noticed and kept it.
/// </para>
/// <para>
/// Each transition is a separate record. A reboot that also lost a permissive is two facts,
/// and collapsing them into one would make the second unfindable.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-FR-0009, CH1-CMD-FR-0009</requirements>
public static class ControllerTransitions
{
    public static IReadOnlyList<ControllerTransition> Between(
        ControllerStateObservation? previous,
        ControllerStateObservation current)
    {
        ArgumentNullException.ThrowIfNull(current);
        if (previous is null)
        {
            return [new ControllerTransition(
                ControllerEventKind.LinkEstablished,
                "GATEWAY_OBSERVED_CONTROLLER_FOR_THE_FIRST_TIME")];
        }

        var transitions = new List<ControllerTransition>(3);

        // A reboot first, because it explains everything that follows it. CH1-CMD-FR-0009
        // makes a prepared command uncommittable across one, so it is the transition a
        // reader most needs to see.
        if (previous.ControllerBootId != current.ControllerBootId)
        {
            transitions.Add(new ControllerTransition(
                ControllerEventKind.ControllerRebooted,
                "CONTROLLER_BOOT_IDENTITY_CHANGED_UNCOMMITTED_PREPARES_ARE_VOID"));
        }

        if (!StringComparer.Ordinal.Equals(previous.ConfigurationRevision, current.ConfigurationRevision))
        {
            transitions.Add(new ControllerTransition(
                ControllerEventKind.ConfigurationRevisionChanged,
                "CONTROLLED_CONFIGURATION_REVISION_CHANGED"));
        }

        if (previous.Permissives.Reported && !current.Permissives.Reported)
        {
            // Different from a permissive being lost: the controller has stopped answering
            // the question rather than answering it with "no". Both leave the cell not
            // permissive, and an investigator needs to know which happened.
            transitions.Add(new ControllerTransition(
                ControllerEventKind.PermissivesNoLongerAnswered,
                "CONTROLLER_STOPPED_ANSWERING_ITS_PERMISSIVES"));
        }
        else if (current.Permissives.Reported)
        {
            var wasPermissive = previous.Permissives.Reported && IsPermissive(previous.Permissives);
            var isPermissive = IsPermissive(current.Permissives);
            if (wasPermissive && !isPermissive)
            {
                transitions.Add(new ControllerTransition(
                    ControllerEventKind.PermissiveLost,
                    LostReason(previous.Permissives, current.Permissives)));
            }
            else if (!wasPermissive && isPermissive)
            {
                transitions.Add(new ControllerTransition(
                    ControllerEventKind.PermissiveRestored,
                    "ALL_LOCAL_PERMISSIVES_HEALTHY"));
            }
        }

        // Its own branch rather than a kind of permissive change, because a fault is what a
        // reader searches for and CH1-SYS-CON-0001 gives it its own recovery path: "Critical
        // faults enter FaultLatched, remove configured enables and require local authorised
        // recovery."
        if (current.Permissives.FaultCauseActive && !previous.Permissives.FaultCauseActive)
        {
            transitions.Add(new ControllerTransition(
                ControllerEventKind.FaultLatched,
                "CONTROLLER_REPORTED_AN_ACTIVE_FAULT_CAUSE"));
        }

        if (!StringComparer.Ordinal.Equals(previous.OperatingState, current.OperatingState))
        {
            transitions.Add(new ControllerTransition(
                ControllerEventKind.OperatingStateChanged,
                $"OPERATING_STATE_{previous.OperatingState.ToUpperInvariant()}_TO_{current.OperatingState.ToUpperInvariant()}"));
        }

        return transitions;
    }

    private static bool IsPermissive(ControllerPermissives permissives) =>
        permissives.ControllerOnline &&
        permissives.StartEnable &&
        permissives.StopCircuitHealthy &&
        permissives.GuardHealthy &&
        permissives.ActuatorHome &&
        !permissives.FaultCauseActive;

    /// <summary>
    /// Names the input that went, rather than reporting "a permissive was lost". Which one
    /// opened is the whole content of the event for anyone reading it afterwards.
    /// </summary>
    private static string LostReason(ControllerPermissives previous, ControllerPermissives current)
    {
        if (previous.GuardHealthy && !current.GuardHealthy)
        {
            return "GUARD_INTERLOCK_OPENED";
        }

        if (previous.StopCircuitHealthy && !current.StopCircuitHealthy)
        {
            return "STOP_CIRCUIT_UNHEALTHY";
        }

        if (previous.ControllerOnline && !current.ControllerOnline)
        {
            return "CONTROLLER_REPORTED_ITSELF_OFFLINE";
        }

        if (previous.StartEnable && !current.StartEnable)
        {
            return "LOCAL_START_ENABLE_REMOVED";
        }

        if (previous.ActuatorHome && !current.ActuatorHome)
        {
            return "ACTUATOR_LEFT_THE_HOME_POSITION";
        }

        return current.FaultCauseActive ? "FAULT_CAUSE_BECAME_ACTIVE" : "LOCAL_PERMISSIVE_LOST";
    }
}
