// Carries observations to Control Core, and hangs on to them while the link is down.

using Cinerion.Contracts.EdgeLink.V1;
using Cinerion.EdgeLink.Buffering;
using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Ingress;
using Cinerion.EdgeLink.Protocols;
using Google.Protobuf;

namespace Cinerion.EdgeLink.Runtime;

/// <summary>
/// Carries what the adapters observe into Control Core over CH1-COM-IF-0003, and holds it
/// when the link is down.
/// <para>
/// Three kinds of message with three different answers to "what if nobody is listening":
/// </para>
/// <list type="bullet">
/// <item><b>Telemetry is buffered.</b> CH1-NFR-REL-0001 requires at least 24 hours of it,
/// and CH1-SYS-CON-0001 permits it: "Telemetry may buffer, but commands are not stored for
/// future execution."</item>
/// <item><b>A controller <em>event</em> is buffered</b> and is never evicted to make room
/// for telemetry. A transition is what an investigator needs after the fact, and it stays
/// true however late it arrives.</item>
/// <item><b>A controller <em>state report</em> is not buffered at all</b>, and that is the
/// load-bearing distinction. It is a statement about now; replaying an hour-old one would
/// present a stale permissive as current, which CH1-SAF-FR-0003 forbids and which the
/// ten-second validity window in Control Core exists to prevent. A dropped state report
/// costs nothing, because the cell correctly reads as not permissive until a live one
/// arrives.</item>
/// </list>
/// <para>
/// There is no path here that buffers a command, and there is no method on
/// <see cref="IEdgeBuffer"/> that could carry one.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-FR-0007, CH1-COM-FR-0010, CH1-COM-IF-0003, CH1-SYS-CON-0001</requirements>
public sealed partial class IngressPublisher(
    ControlCoreIngressOptions options,
    IEnumerable<IProtocolAdapter> adapters,
    ILogger<IngressPublisher> logger,
    IEdgeBuffer? buffer = null,
    TimeProvider? timeProvider = null) : BackgroundService
{
    /// <summary>
    /// How often controller state is published. Comfortably inside the ten seconds Control
    /// Core holds a report for, so a single missed publication cannot make a working cell
    /// read as disconnected, while a stopped gateway is noticed within one window.
    /// </summary>
    public static readonly TimeSpan StateInterval = TimeSpan.FromSeconds(2);

    /// <summary>How long readings are gathered before a batch is enqueued.</summary>
    public static readonly TimeSpan TelemetryInterval = TimeSpan.FromSeconds(5);

    /// <summary>
    /// How many buffered records are offered per drain. Bounded because a gateway returning
    /// from a 24-hour outage holds hundreds of thousands, and delivering them in one call
    /// would build a message far past the ingress bound and fail every time — which is a
    /// buffer that can never empty.
    /// </summary>
    public const int DrainBatch = 64;

    /// <summary>
    /// How long the drain waits after emptying the buffer before looking again. Short
    /// enough that a reading taken during a healthy period reaches the domain promptly,
    /// and irrelevant during an outage, when the back-off governs the cadence instead.
    /// </summary>
    public static readonly TimeSpan DrainInterval = TimeSpan.FromSeconds(1);

    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;
    private readonly ReconnectPolicy _reconnect = new(
        ReconnectPolicy.DefaultInitialDelay, ReconnectPolicy.DefaultMaximumDelay);

    private readonly Dictionary<string, ControllerStateObservation> _lastObservation =
        new(StringComparer.Ordinal);

    /// <summary>Which adapter speaks for the cell's controller, and why.</summary>
    public sealed record ControllerSourceSelection(IControllerStateSource? Source, string Reason);

    /// <summary>
    /// Chooses the one adapter that reports this cell's controller state.
    /// <para>
    /// <b>One cell has one controller, and this is where that is enforced.</b> The envelope
    /// carries a single configured <c>CellId</c>, so every controller-state source in a
    /// gateway publishes into the same cell. With one source that is unambiguous. With two
    /// it is not: a deployment fronting both the simulator and a Modbus zone would publish
    /// alternating reports every two seconds — one saying the permissives are answered and
    /// healthy, the other that they were never answered — and since each is newer than the
    /// last, <c>CellRuntimeProjection</c> accepts both and <b>the cell flaps between
    /// permissive and not permissive</b>. A cell whose interlocks alternate is a cell no
    /// operator and no command check can rely on, which is precisely what CH1-SAF-FR-0003
    /// exists to prevent.
    /// </para>
    /// <para>
    /// Ambiguity therefore resolves to <b>no controller state at all</b>, not to a guess.
    /// The cell then reads as not permissive, which is the safe direction and the same
    /// state a gateway with no source at all produces. Naming
    /// <c>CINERION_EDGE_CONTROLLER_ADAPTER</c> resolves it explicitly; there is deliberately
    /// no default preference between adapters, because a silent winner is how one of two
    /// disagreeing controllers ends up authorising physical work.
    /// </para>
    /// <para>
    /// Written before a second source existed rather than after one broke something. Only
    /// the simulator implements <see cref="IControllerStateSource"/> today, so this changes
    /// nothing observable now and refuses the ambiguity the moment it is introduced.
    /// </para>
    /// </summary>
    /// <requirements>CH1-SAF-FR-0003, CH1-MON-FR-0003, CH1-COM-IF-0003</requirements>
    public static ControllerSourceSelection SelectControllerStateSource(
        IEnumerable<IProtocolAdapter> candidates,
        string? configuredAdapterId)
    {
        ArgumentNullException.ThrowIfNull(candidates);
        var sources = candidates.OfType<IControllerStateSource>().ToArray();

        if (sources.Length == 0)
        {
            return new ControllerSourceSelection(
                null,
                "no registered adapter can read a controller's permissives, so every cell reads as not permissive");
        }

        if (!string.IsNullOrWhiteSpace(configuredAdapterId))
        {
            var named = sources.FirstOrDefault(source =>
                StringComparer.Ordinal.Equals(((IProtocolAdapter)source).AdapterId, configuredAdapterId));

            return named is not null
                ? new ControllerSourceSelection(named, $"CINERION_EDGE_CONTROLLER_ADAPTER names {configuredAdapterId}")
                : new ControllerSourceSelection(
                    null,
                    $"CINERION_EDGE_CONTROLLER_ADAPTER names '{configuredAdapterId}', which is not a registered " +
                    "controller-state source. No controller state is published rather than a different adapter's.");
        }

        if (sources.Length > 1)
        {
            var names = string.Join(
                ", ", sources.Select(source => ((IProtocolAdapter)source).AdapterId).Order(StringComparer.Ordinal));
            return new ControllerSourceSelection(
                null,
                $"{sources.Length} adapters can report controller state ({names}) and one cell has one controller. " +
                "Set CINERION_EDGE_CONTROLLER_ADAPTER to name which one speaks for this cell. Until then no " +
                "controller state is published and the cell reads as not permissive, which is the safe direction.");
        }

        return new ControllerSourceSelection(
            sources[0], $"the only registered controller-state source is {((IProtocolAdapter)sources[0]).AdapterId}");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var client = new ControlCoreIngressClient(options, _time);
        LogIngressConfigured(logger, client.Endpoint, options.GatewayIdentity, options.CellId);

        if (buffer is null)
        {
            // Said plainly rather than left as a silence. Without a buffer this gateway
            // behaves exactly as it did before one existed: telemetry observed while the
            // link is down is lost. CH1-NFR-REL-0001 is not met by such a deployment, and
            // an operator should learn that at startup rather than after an outage.
            LogNoBuffer(logger);
        }
        else
        {
            var resumed = await buffer.StatisticsAsync(stoppingToken).ConfigureAwait(false);
            LogBufferOpened(
                logger, buffer.Description, resumed.TelemetryRecords, resumed.CriticalRecords, resumed.RetainedSpan);
        }

        var selection = SelectControllerStateSource(adapters, options.ControllerAdapterId);
        var sources = selection.Source is null ? [] : new[] { selection.Source };
        if (selection.Source is null)
        {
            LogNoControllerStateSource(logger, selection.Reason);
        }
        else
        {
            LogControllerStateSource(logger, ((IProtocolAdapter)selection.Source).AdapterId, selection.Reason);
        }

        var telemetry = Task.Run(() => GatherTelemetryAsync(client, stoppingToken), stoppingToken);

        // The drain runs on its own, and not merely for tidiness. A gateway returning from a
        // full outage holds hundreds of thousands of records, and a drain on the state loop
        // would hold live controller state off the wire for as long as that took — so the
        // cell would read as not permissive because the buffer was busy rather than because
        // the controller said so. Live state is the one thing that must never wait for
        // history.
        var drain = Task.Run(() => DrainLoopAsync(client, stoppingToken), stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            foreach (var source in sources)
            {
                await ObserveControllerAsync(client, source, stoppingToken).ConfigureAwait(false);
            }

            await Task.Delay(StateInterval, _time, stoppingToken).ConfigureAwait(false);
        }

        await Task.WhenAll(telemetry, drain).ConfigureAwait(false);
    }

    /// <summary>
    /// Reads the controller, records any transition, and publishes the live state.
    /// <para>
    /// The transition is worked out here rather than at Control Core because only the
    /// gateway sees both sides of it during an outage — Control Core, by definition, sees
    /// nothing at all.
    /// </para>
    /// </summary>
    private async Task ObserveControllerAsync(
        ControlCoreIngressClient client,
        IControllerStateSource source,
        CancellationToken cancellationToken)
    {
        var adapter = (IProtocolAdapter)source;
        ControllerStateObservation observation;
        try
        {
            observation = await source.ReadControllerStateAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (InvalidOperationException error)
        {
            LogControllerUnreadable(logger, adapter.AdapterId, error.Message);
            return;
        }

        var previous = _lastObservation.GetValueOrDefault(adapter.AdapterId);
        _lastObservation[adapter.AdapterId] = observation;

        foreach (var transition in ControllerTransitions.Between(previous, observation))
        {
            var message = client.BuildControllerEvent(observation, previous, transition, adapter.AdapterId);
            await EnqueueAsync(
                client,
                EdgeRecordClass.CriticalEvent,
                ControlCoreIngressClient.ControllerEventMessageType,
                observation.ControllerId,
                observation.ObservedAt,
                message.ToByteArray(),
                cancellationToken).ConfigureAwait(false);
            LogTransitionObserved(logger, adapter.AdapterId, transition.Kind, transition.ReasonCode);
        }

        // The live report, never buffered. If it cannot be delivered it is dropped, and the
        // cell correctly reads as not permissive until one arrives.
        try
        {
            var receipt = await client.PublishControllerStateAsync(
                observation, adapter.AdapterId, adapter.Protocol, cancellationToken).ConfigureAwait(false);
            _reconnect.Succeeded();
            if (receipt.Accepted)
            {
                LogStatePublished(logger, adapter.AdapterId, observation.ControllerId, receipt.ReasonCode);
            }
            else
            {
                LogStateRefused(logger, adapter.AdapterId, receipt.ReasonCode, receipt.Detail);
            }
        }
        catch (Grpc.Core.RpcException error)
        {
            LogStateNotDelivered(logger, adapter.AdapterId, error.Status.StatusCode.ToString());
        }
    }

    private async Task GatherTelemetryAsync(ControlCoreIngressClient client, CancellationToken cancellationToken)
    {
        var pumps = adapters
            .Select(adapter => Task.Run(() => PumpAsync(client, adapter, cancellationToken), cancellationToken))
            .ToArray();
        await Task.WhenAll(pumps).ConfigureAwait(false);
    }

    private async Task PumpAsync(
        ControlCoreIngressClient client,
        IProtocolAdapter adapter,
        CancellationToken cancellationToken)
    {
        var batch = new List<TelemetryPoint>();
        var flushAt = _time.GetUtcNow() + TelemetryInterval;
        try
        {
            await foreach (var point in adapter.ReadTelemetryAsync(cancellationToken).ConfigureAwait(false))
            {
                batch.Add(point);
                if (_time.GetUtcNow() < flushAt && batch.Count < DrainBatch)
                {
                    continue;
                }

                await EnqueueTelemetryAsync(client, adapter, batch, cancellationToken).ConfigureAwait(false);
                batch.Clear();
                flushAt = _time.GetUtcNow() + TelemetryInterval;
            }
        }
        catch (OperationCanceledException)
        {
            // Shutdown. What has already been enqueued is on disk and will be delivered by
            // whichever process starts next; what is still in this list has not been
            // observed long enough to matter.
        }
    }

    private async Task EnqueueTelemetryAsync(
        ControlCoreIngressClient client,
        IProtocolAdapter adapter,
        List<TelemetryPoint> batch,
        CancellationToken cancellationToken)
    {
        if (batch.Count == 0)
        {
            return;
        }

        // Grouped by the device that reported them. An adapter may front more than one
        // device, and Control Core checks trust per device, so a batch that mixed them
        // would be judged against whichever happened to be named first.
        foreach (var group in batch.GroupBy(point => point.DeviceId, StringComparer.Ordinal))
        {
            var readings = group.ToArray();
            var message = client.BuildTelemetry(group.Key, readings);
            await EnqueueAsync(
                client,
                EdgeRecordClass.Telemetry,
                ControlCoreIngressClient.TelemetryMessageType,
                group.Key,
                readings[^1].SampledAt,
                message.ToByteArray(),
                cancellationToken).ConfigureAwait(false);
            LogTelemetryEnqueued(logger, adapter.AdapterId, group.Key, readings.Length);
        }
    }

    /// <summary>
    /// Puts a record where it can survive, or sends it directly when no buffer exists.
    /// <para>
    /// The direct path is not a convenience. A deployment with no buffer configured must
    /// behave exactly as this gateway did before store-and-forward existed — publishing
    /// what it observes and losing what it cannot deliver — because the alternative is a
    /// gateway that silently publishes nothing at all. That failure would be invisible:
    /// every adapter would still read, every log line would still appear, and the domain
    /// would simply never hear anything.
    /// </para>
    /// </summary>
    private async Task EnqueueAsync(
        ControlCoreIngressClient client,
        EdgeRecordClass recordClass,
        string messageType,
        string deviceId,
        DateTimeOffset occurredAt,
        byte[] payload,
        CancellationToken cancellationToken)
    {
        if (buffer is null)
        {
            try
            {
                var direct = await client.SendBufferedAsync(messageType, payload, cancellationToken)
                    .ConfigureAwait(false);
                if (!direct.Accepted)
                {
                    LogUnbufferedRefused(logger, messageType, direct.ReasonCode);
                }
            }
            catch (Grpc.Core.RpcException error)
            {
                // Lost, and said so. Without a buffer there is nowhere for it to wait, which
                // is precisely what CH1-NFR-REL-0001 exists to change.
                LogUnbufferedLost(logger, messageType, error.Status.StatusCode.ToString());
            }

            return;
        }

        var admission = await buffer.EnqueueAsync(
            recordClass, messageType, deviceId, occurredAt, payload, cancellationToken).ConfigureAwait(false);

        if (!admission.Admitted)
        {
            LogAdmissionRefused(logger, messageType, admission.ReasonCode);
        }
        else if (admission.EvictedCritical > 0)
        {
            // Evidence has been lost. That is a policy outcome rather than a fault, but it
            // is never quiet: the link has been down long enough to overrun the critical
            // headroom entirely.
            LogCriticalEvicted(logger, admission.EvictedCritical, messageType);
        }
        else if (admission.EvictedTelemetry > 0)
        {
            LogTelemetryEvicted(logger, admission.EvictedTelemetry);
        }
    }

    /// <summary>
    /// Delivers what the buffer holds, oldest first, and backs off when it cannot.
    /// <para>
    /// A record is removed only once Control Core has answered for it, so a gateway that
    /// dies mid-delivery replays rather than loses. A replay of something already delivered
    /// is refused as a duplicate, which is the correct answer and is treated as delivery.
    /// </para>
    /// </summary>
    private async Task DrainLoopAsync(ControlCoreIngressClient client, CancellationToken cancellationToken)
    {
        if (buffer is null)
        {
            return;
        }

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await DrainAsync(client, cancellationToken).ConfigureAwait(false);
                await Task.Delay(DrainInterval, _time, cancellationToken).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
            // Shutdown. Whatever is still held is on disk and is delivered by whichever
            // process starts next, which is the whole point of it being on disk.
        }
    }

    private async Task DrainAsync(ControlCoreIngressClient client, CancellationToken cancellationToken)
    {
        if (buffer is null)
        {
            return;
        }

        while (!cancellationToken.IsCancellationRequested)
        {
            var records = await buffer.PeekAsync(DrainBatch, cancellationToken).ConfigureAwait(false);
            if (records.Count == 0)
            {
                return;
            }

            var delivered = new List<long>(records.Count);
            foreach (var record in records)
            {
                IngressReceipt receipt;
                try
                {
                    receipt = await client.SendBufferedAsync(
                        record.MessageType, record.Payload, cancellationToken).ConfigureAwait(false);
                }
                catch (Grpc.Core.RpcException error)
                {
                    // A transport failure is not a refusal. Everything from here stays where
                    // it is, in order, and the gateway waits.
                    //
                    // What has already been answered for is removed *before* the wait, not
                    // after it: the back-off reaches thirty seconds, and a process killed
                    // during one would otherwise replay records Control Core had already
                    // accepted. They would be refused as duplicates rather than
                    // double-counted, but a buffer should not manufacture work it knows is
                    // finished.
                    await buffer.RemoveAsync(delivered, cancellationToken).ConfigureAwait(false);
                    await BackOffAsync(error.Status.StatusCode.ToString(), records.Count, cancellationToken)
                        .ConfigureAwait(false);
                    return;
                }

                _reconnect.Succeeded();
                delivered.Add(record.Sequence);

                if (!receipt.Accepted && !StringComparer.Ordinal.Equals(receipt.ReasonCode, "INGRESS_DUPLICATE_MESSAGE"))
                {
                    // The domain has judged it. Republishing would be a gateway arguing with
                    // the domain, so the record is dropped and the reason reported.
                    LogBufferedRecordRefused(logger, record.MessageType, record.Sequence, receipt.ReasonCode);
                }
            }

            await buffer.RemoveAsync(delivered, cancellationToken).ConfigureAwait(false);
            LogDrained(logger, delivered.Count);

            if (records.Count < DrainBatch)
            {
                return;
            }
        }
    }

    private async Task BackOffAsync(string status, int outstanding, CancellationToken cancellationToken)
    {
        var delay = _reconnect.NextDelay();
        LogBackingOff(logger, status, outstanding, delay.ConsecutiveFailures, delay.Delay, delay.Bound);
        await Task.Delay(delay.Delay, _time, cancellationToken).ConfigureAwait(false);
    }

    [LoggerMessage(
        EventId = 1100,
        Level = LogLevel.Information,
        Message = "CH1-COM-IF-0003 ingress configured: {Endpoint} as {GatewayIdentity} for cell {CellId}, mutual TLS against the controlled authority")]
    private static partial void LogIngressConfigured(
        ILogger logger, Uri endpoint, string gatewayIdentity, Guid cellId);

    [LoggerMessage(
        EventId = 1101,
        Level = LogLevel.Information,
        Message = "Ingress: {AdapterId} published controller state for {ControllerId}; Control Core answered {ReasonCode}")]
    private static partial void LogStatePublished(
        ILogger logger, string adapterId, string controllerId, string reasonCode);

    [LoggerMessage(
        EventId = 1102,
        Level = LogLevel.Warning,
        Message = "Ingress: {AdapterId} controller state REFUSED as {ReasonCode}: {Detail}")]
    private static partial void LogStateRefused(ILogger logger, string adapterId, string reasonCode, string detail);

    [LoggerMessage(
        EventId = 1103,
        Level = LogLevel.Information,
        Message = "Ingress: {AdapterId} enqueued {Readings} reading(s) for {DeviceId}")]
    private static partial void LogTelemetryEnqueued(
        ILogger logger, string adapterId, string deviceId, int readings);

    [LoggerMessage(
        EventId = 1105,
        Level = LogLevel.Warning,
        Message = "Ingress: {AdapterId} could not deliver live controller state ({Status}). The cell reads as not permissive until it can, and the report is dropped rather than replayed later.")]
    private static partial void LogStateNotDelivered(ILogger logger, string adapterId, string status);

    [LoggerMessage(
        EventId = 1106,
        Level = LogLevel.Warning,
        Message = "Ingress: NO controller state will be published, and the cell reads as not permissive. {Reason}")]
    private static partial void LogNoControllerStateSource(ILogger logger, string reason);

    [LoggerMessage(
        EventId = 1119,
        Level = LogLevel.Information,
        Message = "Ingress: {AdapterId} speaks for this cell's controller. {Reason}")]
    private static partial void LogControllerStateSource(ILogger logger, string adapterId, string reason);

    [LoggerMessage(
        EventId = 1107,
        Level = LogLevel.Warning,
        Message = "Store-and-forward is NOT configured: CINERION_EDGE_BUFFER_PATH is unset, so telemetry observed while the link is down is lost. CH1-NFR-REL-0001 is not met by this deployment.")]
    private static partial void LogNoBuffer(ILogger logger);

    [LoggerMessage(
        EventId = 1108,
        Level = LogLevel.Information,
        Message = "Store-and-forward buffer open: {Description}. Resumed holding {Telemetry} telemetry and {Critical} critical record(s) spanning {Span}.")]
    private static partial void LogBufferOpened(
        ILogger logger, string description, long telemetry, long critical, TimeSpan span);

    [LoggerMessage(
        EventId = 1109,
        Level = LogLevel.Information,
        Message = "Ingress: delivered {Count} buffered record(s)")]
    private static partial void LogDrained(ILogger logger, int count);

    [LoggerMessage(
        EventId = 1110,
        Level = LogLevel.Warning,
        Message = "Ingress: link unavailable ({Status}) with {Outstanding} record(s) held; failure {Failures}, waiting {Delay} of a {Bound} bound")]
    private static partial void LogBackingOff(
        ILogger logger, string status, int outstanding, int failures, TimeSpan delay, TimeSpan bound);

    [LoggerMessage(
        EventId = 1111,
        Level = LogLevel.Warning,
        Message = "Buffer: {Count} telemetry record(s) evicted to admit newer telemetry")]
    private static partial void LogTelemetryEvicted(ILogger logger, int count);

    [LoggerMessage(
        EventId = 1112,
        Level = LogLevel.Error,
        Message = "Buffer: {Count} CRITICAL record(s) evicted to admit a newer {MessageType}. The critical headroom is full, so evidence has been lost.")]
    private static partial void LogCriticalEvicted(ILogger logger, int count, string messageType);

    [LoggerMessage(
        EventId = 1113,
        Level = LogLevel.Warning,
        Message = "Buffer: refused a {MessageType} as {ReasonCode}")]
    private static partial void LogAdmissionRefused(ILogger logger, string messageType, string reasonCode);

    [LoggerMessage(
        EventId = 1114,
        Level = LogLevel.Warning,
        Message = "Ingress: buffered {MessageType} #{Sequence} REFUSED as {ReasonCode}; dropped rather than republished")]
    private static partial void LogBufferedRecordRefused(
        ILogger logger, string messageType, long sequence, string reasonCode);

    [LoggerMessage(
        EventId = 1115,
        Level = LogLevel.Information,
        Message = "Ingress: {AdapterId} observed controller transition {Kind} ({ReasonCode})")]
    private static partial void LogTransitionObserved(
        ILogger logger, string adapterId, ControllerEventKind kind, string reasonCode);

    [LoggerMessage(
        EventId = 1116,
        Level = LogLevel.Warning,
        Message = "Ingress: {AdapterId} could not read its controller: {Detail}")]
    private static partial void LogControllerUnreadable(ILogger logger, string adapterId, string detail);

    [LoggerMessage(
        EventId = 1117,
        Level = LogLevel.Warning,
        Message = "Ingress: unbuffered {MessageType} REFUSED as {ReasonCode}")]
    private static partial void LogUnbufferedRefused(ILogger logger, string messageType, string reasonCode);

    [LoggerMessage(
        EventId = 1118,
        Level = LogLevel.Warning,
        Message = "Ingress: unbuffered {MessageType} LOST ({Status}). Store-and-forward is not configured, so there is nowhere for it to wait.")]
    private static partial void LogUnbufferedLost(ILogger logger, string messageType, string status);
}
