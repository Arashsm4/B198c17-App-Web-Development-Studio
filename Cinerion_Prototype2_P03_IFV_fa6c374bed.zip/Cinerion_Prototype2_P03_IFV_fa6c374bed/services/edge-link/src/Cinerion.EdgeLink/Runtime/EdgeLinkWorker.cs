// The gateway's main loop. Runs conformance at startup and won't serve if an adapter flunks
// it.

using Cinerion.EdgeLink.Protocols;

namespace Cinerion.EdgeLink.Runtime;

/// <summary>
/// What this gateway does at startup beyond serving.
/// </summary>
/// <param name="MeasureAcknowledgementLatency">
/// Whether to measure CH1-NFR-PER-0003's prepared-command acknowledgement latency against
/// each live adapter. Off by default: the measurement spends about five seconds per adapter
/// waiting for preparations to lapse, and a production edge that delayed coming online to
/// produce a figure for a verification report would be serving a document instead of a cell.
/// The edge gates turn it on.
/// </param>
public sealed record EdgeLinkWorkerOptions(bool MeasureAcknowledgementLatency)
{
    public const string MeasureAcknowledgementLatencySetting = "CINERION_EDGE_MEASURE_ACK_LATENCY";

    public static EdgeLinkWorkerOptions FromConfiguration(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        return new EdgeLinkWorkerOptions(
            string.Equals(
                configuration[MeasureAcknowledgementLatencySetting],
                "true",
                StringComparison.OrdinalIgnoreCase));
    }
}

public sealed partial class EdgeLinkWorker(
    IEnumerable<IProtocolAdapter> adapters,
    IEnumerable<ITransportProvider> providers,
    EdgeLinkWorkerOptions options,
    ILogger<EdgeLinkWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // The conformance suites run at startup, against whatever this deployment
        // actually registered. CH1-COM-PRO-0001 gates a live adapter on conformance
        // evidence; evidence produced only in a test assembly says nothing about the
        // adapter a running gateway was configured with, which may be a different one.
        // A failure here stops the gateway rather than degrading it, because a transport
        // that alters a domain message or an adapter that acknowledges a command it
        // cannot carry would both be worse than not starting.
        foreach (var provider in providers)
        {
            var results = await TransportConformance.RunAsync(provider, stoppingToken).ConfigureAwait(false);
            Report("transport", provider.ProviderId, results);
        }

        foreach (var adapter in adapters)
        {
            await adapter.ReconcileAsync(stoppingToken).ConfigureAwait(false);

            // A gated adapter is held to a contract, not skipped. Its contract is refusal:
            // refuse a command, refuse to publish a manifest, name what is not
            // commissioned, and invent no telemetry. An uncommissioned adapter that
            // quietly acknowledged a command would have the domain believe a controller
            // had accepted it, which is worse than one that is simply absent — so the
            // gateway runs those checks at startup, on the adapters it actually
            // registered, rather than leaving them to a unit-test assembly.
            if (adapter is GatedIndustrialAdapter)
            {
                Report("gated adapter", adapter.AdapterId, await AdapterConformance
                    .RunGatedAsync(adapter, stoppingToken).ConfigureAwait(false));
                LogAdapterGated(logger, adapter.AdapterId, adapter.Protocol);
                continue;
            }

            // CH1-NFR-PER-0003, measured BEFORE the conformance suite and not after.
            //
            // The suite's ADP-05 accepts a preparation with a five-minute expiry, which
            // leaves the guard Prepared for five minutes: a measurement placed after it met
            // a busy guard and every sample was refused as STATE_INVALID, producing a fast
            // p95 about the refusal path rather than the acknowledgement path. Here the
            // guard is as the probe left it - Idle, no sequence spent - and the measurement
            // drains itself before the suite's first preparation arrives.
            //
            // OFF unless a measurement asks for it. Twenty samples cost about five seconds
            // per adapter, spent waiting for preparations to lapse, and a production edge
            // that delayed coming online to produce a figure for a verification report
            // would be a gateway serving a document instead of a cell.
            //
            // REPORTED rather than enforced: the gateway states what it observed, and the
            // edge gates judge it against the controlled 750 ms. A service that refused to
            // start over a performance figure would take a working edge off the air for a
            // number that belongs in a report.
            if (options.MeasureAcknowledgementLatency)
            {
                var latency = await AdapterConformance
                    .MeasureAcknowledgementLatencyAsync(adapter, 20, TimeProvider.System, stoppingToken)
                    .ConfigureAwait(false);
                LogAcknowledgementLatency(
                    logger,
                    adapter.AdapterId,
                    latency.Samples,
                    latency.Accepted,
                    latency.P50Milliseconds,
                    latency.P95Milliseconds,
                    latency.P99Milliseconds,
                    latency.WorstMilliseconds);
            }

            var results = await AdapterConformance.RunAsync(adapter, stoppingToken).ConfigureAwait(false);
            Report("adapter", adapter.AdapterId, results);

            var capability = await adapter.ReadCapabilityAsync(stoppingToken).ConfigureAwait(false);
            LogAdapterOnline(
                logger,
                adapter.AdapterId,
                adapter.Protocol,
                capability.DeviceId,
                capability.ConfigurationRevision,
                capability.SecurityProfile);
        }

        await Task.Delay(Timeout.InfiniteTimeSpan, stoppingToken).ConfigureAwait(false);
    }

    private void Report(string kind, string identity, IReadOnlyList<ConformanceResult> results)
    {
        foreach (var result in results)
        {
            LogConformanceCheck(logger, kind, identity, result.CheckId, result.Passed, result.Observation);
        }

        var failed = results.Where(result => !result.Passed).ToArray();
        if (failed.Length > 0)
        {
            throw new InvalidOperationException(
                $"{kind} {identity} failed conformance and will not be served: " +
                string.Join("; ", failed.Select(result => $"{result.CheckId} - {result.Observation}")));
        }
    }

    /// <summary>
    /// Source-generated structured log entry per CH1-SWA-SDP-0001. Avoids the boxed
    /// params array and the eager argument evaluation flagged by CA1848/CA1873.
    /// Adapter identity and configuration revision only; no secret or payload content.
    /// </summary>
    [LoggerMessage(
        EventId = 1000,
        Level = LogLevel.Information,
        Message = "Adapter {AdapterId} online as {Protocol}; device {DeviceId}; configuration {ConfigurationRevision}; security {SecurityProfile}")]
    private static partial void LogAdapterOnline(
        ILogger logger,
        string adapterId,
        string protocol,
        string deviceId,
        string configurationRevision,
        string securityProfile);

    /// <summary>
    /// Says plainly that an adapter is registered and refusing, so a reader of the log
    /// cannot mistake "not commissioned" for "not present".
    /// </summary>
    [LoggerMessage(
        EventId = 1002,
        Level = LogLevel.Warning,
        Message = "Adapter {AdapterId} ({Protocol}) is GATED: it refuses commands and publishes no manifest or telemetry until its conformance evidence is accepted.")]
    private static partial void LogAdapterGated(ILogger logger, string adapterId, string protocol);

    /// <summary>
    /// CH1-NFR-PER-0003's figure, printed with the sample and acceptance counts beside it.
    /// A percentile with no count next to it cannot be told from a percentile of one.
    /// </summary>
    [LoggerMessage(
        EventId = 5110,
        Level = LogLevel.Information,
        Message = "AckLatency {AdapterId} samples={Samples} accepted={Accepted} " +
                  "p50={P50}ms p95={P95}ms p99={P99}ms worst={Worst}ms")]
    private static partial void LogAcknowledgementLatency(
        ILogger logger,
        string adapterId,
        int samples,
        int accepted,
        double p50,
        double p95,
        double p99,
        double worst);

    /// <summary>
    /// One line per conformance check, so the commissioning record CH1-COM-PRO-0001 asks
    /// for can be assembled from the gateway's own log rather than from a claim about it.
    /// </summary>
    [LoggerMessage(
        EventId = 1001,
        Level = LogLevel.Information,
        Message = "Conformance {Kind} {Identity} {CheckId} passed={Passed}: {Observation}")]
    private static partial void LogConformanceCheck(
        ILogger logger,
        string kind,
        string identity,
        string checkId,
        bool passed,
        string observation);
}
