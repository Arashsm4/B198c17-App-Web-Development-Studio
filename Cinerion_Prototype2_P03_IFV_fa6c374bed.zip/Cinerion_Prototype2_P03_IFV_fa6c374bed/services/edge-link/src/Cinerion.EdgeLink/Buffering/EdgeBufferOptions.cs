// How big the gateway's store-and-forward buffer is, and how it's shared out.

using System.Globalization;

namespace Cinerion.EdgeLink.Buffering;

/// <summary>
/// How the gateway's store-and-forward buffer is sized.
/// <para>
/// <b>Capacity is derived from the requirement, not configured beside it.</b>
/// CH1-NFR-REL-0001 says "at least 24 hours of configured telemetry", so the retention
/// floor and the configured feed rate are the settings and the record capacity is
/// computed: a deployment cannot state a 24-hour floor and a capacity too small to hold
/// it, because there is no second number to disagree with the first.
/// </para>
/// <para>
/// The byte bound is the other half — CH1-COM-PRO-0001 requires flow control to cap
/// "memory and disk". It is checked against the derived record count at startup rather
/// than enforced silently at run time, so a deployment whose disk allowance cannot hold
/// its own retention floor is refused rather than discovered to be lossy in the middle of
/// an outage.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-PRO-0001</requirements>
public sealed record EdgeBufferOptions(
    string Path,
    TimeSpan RetentionFloor,
    double FeedRecordsPerSecond,
    long CriticalHeadroomRecords,
    long MaximumBytes)
{
    /// <summary>
    /// The controlled floor. Named rather than written as a literal in three places, and
    /// the startup check refuses anything below it: a deployment may buffer more than
    /// CH1-NFR-REL-0001 requires, never less.
    /// </summary>
    public static readonly TimeSpan ControlledRetentionFloor = TimeSpan.FromHours(24);

    /// <summary>
    /// The telemetry the retention floor implies, in records. This is the number the buffer
    /// is built to hold and the number the gate fills it to.
    /// <para>
    /// <b>The trailing record is not an off-by-one, it is the difference between a count
    /// and a span.</b> Records arriving every <c>1/rate</c> seconds are separated by
    /// <c>n - 1</c> intervals, so a buffer holding exactly <c>rate × seconds</c> of them
    /// spans one interval less than its retention floor and retains 23:59:40 of a 24-hour
    /// obligation. CH1-NFR-REL-0001 says "at least 24 hours", and the measured span is what
    /// <see cref="BufferStatistics.RetainedSpan"/> reports, so the count is the one that
    /// gives way. Found by filling a buffer and measuring it rather than by reading this
    /// expression.
    /// </para>
    /// </summary>
    public long TelemetryCapacity =>
        (long)Math.Ceiling(RetentionFloor.TotalSeconds * FeedRecordsPerSecond) + 1;

    /// <summary>
    /// A generous per-record allowance, used only to decide at startup whether the disk
    /// bound can hold the retention floor. The buffer measures real sizes afterwards; this
    /// is what stops a deployment being configured into a corner it would only discover
    /// during an outage.
    /// </summary>
    public const int NominalRecordBytes = 256;

    public long RequiredBytes => (TelemetryCapacity + CriticalHeadroomRecords) * NominalRecordBytes;

    /// <summary>
    /// Reads the configuration, or reports that store-and-forward is not configured.
    /// <para>
    /// Absent means absent: the gateway says so at startup and telemetry observed while
    /// the link is down is lost, which is what happened before this buffer existed. A
    /// silent in-memory fallback would be worse — it would look like store-and-forward
    /// and would not survive the gateway restart an outage so often includes.
    /// </para>
    /// </summary>
    public static EdgeBufferOptions? FromConfiguration(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var path = configuration["CINERION_EDGE_BUFFER_PATH"];
        if (string.IsNullOrWhiteSpace(path))
        {
            return null;
        }

        var retentionHours = Read(configuration, "CINERION_EDGE_BUFFER_RETENTION_HOURS", 24d);
        var feedRate = Read(configuration, "CINERION_EDGE_BUFFER_FEED_RECORDS_PER_SECOND", 4d);
        var headroom = (long)Read(configuration, "CINERION_EDGE_BUFFER_CRITICAL_HEADROOM", 4096d);
        var maximumBytes = (long)Read(configuration, "CINERION_EDGE_BUFFER_MAX_BYTES", 256d * 1024 * 1024);

        var options = new EdgeBufferOptions(
            path,
            TimeSpan.FromHours(retentionHours),
            feedRate,
            headroom,
            maximumBytes);
        options.Validate();
        return options;
    }

    /// <summary>
    /// Refuses a configuration that cannot meet CH1-NFR-REL-0001, at startup, by name.
    /// <para>
    /// A gateway that cannot buffer what the controlled requirement demands must not run
    /// and then discover it during the outage the buffer exists for. The message states
    /// both numbers, because "buffer too small" is not actionable and "345600 records at
    /// 256 bytes needs 88473600, configured 1048576" is.
    /// </para>
    /// </summary>
    public void Validate()
    {
        if (RetentionFloor < ControlledRetentionFloor)
        {
            throw new InvalidOperationException(
                $"CINERION_EDGE_BUFFER_RETENTION_HOURS is {RetentionFloor.TotalHours:0.##} h. " +
                $"CH1-NFR-REL-0001 requires at least {ControlledRetentionFloor.TotalHours:0} h of configured telemetry.");
        }

        if (FeedRecordsPerSecond <= 0)
        {
            throw new InvalidOperationException(
                "CINERION_EDGE_BUFFER_FEED_RECORDS_PER_SECOND must be positive: the retention floor is meaningless without a feed rate.");
        }

        if (CriticalHeadroomRecords <= 0)
        {
            throw new InvalidOperationException(
                "CINERION_EDGE_BUFFER_CRITICAL_HEADROOM must be positive: critical events need room that telemetry cannot take.");
        }

        if (MaximumBytes < RequiredBytes)
        {
            throw new InvalidOperationException(
                $"CINERION_EDGE_BUFFER_MAX_BYTES is {MaximumBytes}, which cannot hold the " +
                $"{TelemetryCapacity} telemetry and {CriticalHeadroomRecords} critical records that a " +
                $"{RetentionFloor.TotalHours:0.##} h floor at {FeedRecordsPerSecond:0.##} records/s implies " +
                $"({RequiredBytes} bytes at {NominalRecordBytes} bytes each). " +
                "CH1-COM-PRO-0001 caps disk as well as memory; the two bounds must agree.");
        }
    }

    private static double Read(IConfiguration configuration, string key, double fallback)
    {
        var value = configuration[key];
        if (string.IsNullOrWhiteSpace(value))
        {
            return fallback;
        }

        return double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var parsed)
            ? parsed
            : throw new InvalidOperationException($"{key} is not a number: '{value}'.");
    }
}
