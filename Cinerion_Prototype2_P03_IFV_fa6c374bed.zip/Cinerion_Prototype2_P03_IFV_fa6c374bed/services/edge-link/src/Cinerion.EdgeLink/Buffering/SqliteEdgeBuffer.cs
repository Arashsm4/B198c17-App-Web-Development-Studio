// The gateway's durable buffer on SQLite. Holds on to data while Control Core is out of reach.

using Microsoft.Data.Sqlite;

namespace Cinerion.EdgeLink.Buffering;

/// <summary>
/// The gateway's durable store-and-forward buffer.
/// <para>
/// <b>On disk, deliberately.</b> An outage long enough to need a 24-hour buffer is an
/// outage long enough to include a gateway restart, a power cut or a container
/// replacement, and an in-memory queue survives none of them. CH1-COM-PRO-0001 says flow
/// control caps "memory <em>and disk</em>", which only means anything if the disk is used.
/// </para>
/// <para>
/// <b>SQLite rather than a hand-written log.</b> The Modbus master in this gateway is
/// written by hand on purpose — there, two independent implementations agreeing is itself
/// the evidence about a wire format. Nothing of the kind applies to a local file, and what
/// does apply is crash consistency: an eviction that must remove one record and admit
/// another without ever losing both is a transaction, and hand-rolling that is where
/// silent data loss lives. The bundled provider is used so the container needs no
/// system library.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-FR-0007, CH1-COM-PRO-0001</requirements>
public sealed class SqliteEdgeBuffer : IEdgeBuffer
{
    private readonly EdgeBufferOptions _options;
    private readonly SqliteConnection _connection;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly TimeProvider _time;

    private SqliteEdgeBuffer(EdgeBufferOptions options, SqliteConnection connection, TimeProvider time)
    {
        _options = options;
        _connection = connection;
        _time = time;
    }

    public static async ValueTask<SqliteEdgeBuffer> OpenAsync(
        EdgeBufferOptions options,
        TimeProvider? timeProvider = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(options);
        options.Validate();

        var directory = Path.GetDirectoryName(Path.GetFullPath(options.Path));
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        var connection = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = options.Path,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Pooling = false,
        }.ToString());
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

        // WAL for crash consistency across a restart, and FULL synchronous because the
        // whole point of this file is to survive the loss of power that took the link with
        // it. A buffer that loses its newest records exactly when the machine goes down is
        // the one case it exists for.
        await ExecuteAsync(connection, "PRAGMA journal_mode=WAL;", cancellationToken).ConfigureAwait(false);
        await ExecuteAsync(connection, "PRAGMA synchronous=FULL;", cancellationToken).ConfigureAwait(false);
        await ExecuteAsync(
            connection,
            """
            CREATE TABLE IF NOT EXISTS edge_buffer (
                sequence     INTEGER PRIMARY KEY AUTOINCREMENT,
                record_class INTEGER NOT NULL CHECK (record_class IN (0, 1)),
                message_type TEXT    NOT NULL,
                device_id    TEXT    NOT NULL,
                occurred_at  TEXT    NOT NULL,
                enqueued_at  TEXT    NOT NULL,
                payload      BLOB    NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_edge_buffer_class_sequence ON edge_buffer(record_class, sequence);
            """,
            cancellationToken).ConfigureAwait(false);

        return new SqliteEdgeBuffer(options, connection, timeProvider ?? TimeProvider.System);
    }

    public string Description =>
        $"{_options.Path} ({_options.TelemetryCapacity} telemetry records = " +
        $"{_options.RetentionFloor.TotalHours:0.##} h at {_options.FeedRecordsPerSecond:0.##}/s, " +
        $"plus {_options.CriticalHeadroomRecords} critical)";

    public long TelemetryCapacity => _options.TelemetryCapacity;

    /// <summary>
    /// Admits a record, evicting only what the policy permits.
    /// <para>
    /// The order of the two eviction rules is the requirement itself. Telemetry gives way
    /// to telemetry, oldest first. A critical event never gives way to telemetry — when the
    /// buffer holds nothing but critical events, new telemetry is refused rather than
    /// admitted at the cost of evidence. Only a <em>newer critical event</em> may displace
    /// an older one, which is CH1-COM-PRO-0001's "preserving newest critical events".
    /// </para>
    /// </summary>
    public async ValueTask<BufferAdmission> EnqueueAsync(
        EdgeRecordClass recordClass,
        string messageType,
        string deviceId,
        DateTimeOffset occurredAt,
        ReadOnlyMemory<byte> payload,
        CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            await using var transaction = await _connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);

            var telemetry = await CountAsync(EdgeRecordClass.Telemetry, transaction, cancellationToken).ConfigureAwait(false);
            var critical = await CountAsync(EdgeRecordClass.CriticalEvent, transaction, cancellationToken).ConfigureAwait(false);

            var evictedTelemetry = 0;
            var evictedCritical = 0;

            if (recordClass == EdgeRecordClass.Telemetry)
            {
                if (telemetry >= _options.TelemetryCapacity)
                {
                    evictedTelemetry = await EvictOldestAsync(
                        EdgeRecordClass.Telemetry,
                        telemetry - _options.TelemetryCapacity + 1,
                        transaction,
                        cancellationToken).ConfigureAwait(false);

                    if (evictedTelemetry == 0)
                    {
                        // Nothing to give way. The buffer is at its telemetry capacity with
                        // no telemetry in it, which can only mean the capacity is zero.
                        await transaction.RollbackAsync(cancellationToken).ConfigureAwait(false);
                        return new BufferAdmission(false, 0, 0, "BUFFER_TELEMETRY_CAPACITY_EXHAUSTED");
                    }
                }
            }
            else if (critical >= _options.CriticalHeadroomRecords)
            {
                // The newest critical events are preserved, so the oldest gives way. This is
                // evidence being lost and is reported as such rather than counted quietly.
                evictedCritical = await EvictOldestAsync(
                    EdgeRecordClass.CriticalEvent,
                    critical - _options.CriticalHeadroomRecords + 1,
                    transaction,
                    cancellationToken).ConfigureAwait(false);
            }

            // The byte bound, enforced rather than merely validated at startup.
            // CH1-COM-PRO-0001 caps "memory and disk", and a bound that is only checked
            // against a nominal per-record size is a configuration check, not flow control:
            // one deployment whose readings are larger than the nominal allowance would
            // pass validation and then grow past its disk allowance during the outage the
            // buffer exists for. Telemetry gives way first and critical events are never
            // evicted for space, which is the same ordering the record bound uses.
            var incoming = payload.Length;
            var bytes = await ByteSizeAsync(transaction, cancellationToken).ConfigureAwait(false);
            while (bytes + incoming > _options.MaximumBytes)
            {
                var freed = await EvictOldestAsync(EdgeRecordClass.Telemetry, 1, transaction, cancellationToken)
                    .ConfigureAwait(false);
                if (freed == 0)
                {
                    // Nothing evictable is left. Refusing is the only honest answer: the
                    // alternative is discarding evidence to store a reading.
                    await transaction.RollbackAsync(cancellationToken).ConfigureAwait(false);
                    return new BufferAdmission(false, evictedTelemetry, 0, "BUFFER_BYTE_BOUND_EXHAUSTED");
                }

                evictedTelemetry += freed;
                bytes = await ByteSizeAsync(transaction, cancellationToken).ConfigureAwait(false);
            }

            await using (var insert = _connection.CreateCommand())
            {
                insert.Transaction = (SqliteTransaction)transaction;
                insert.CommandText =
                    """
                    INSERT INTO edge_buffer(record_class, message_type, device_id, occurred_at, enqueued_at, payload)
                    VALUES($class, $type, $device, $occurred, $enqueued, $payload);
                    """;
                insert.Parameters.AddWithValue("$class", (int)recordClass);
                insert.Parameters.AddWithValue("$type", messageType);
                insert.Parameters.AddWithValue("$device", deviceId);
                insert.Parameters.AddWithValue("$occurred", occurredAt.UtcDateTime.ToString("O"));
                insert.Parameters.AddWithValue("$enqueued", _time.GetUtcNow().UtcDateTime.ToString("O"));
                insert.Parameters.AddWithValue("$payload", payload.ToArray());
                await insert.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            }

            await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
            return new BufferAdmission(
                true,
                evictedTelemetry,
                evictedCritical,
                evictedCritical > 0 ? "BUFFER_CRITICAL_EVIDENCE_EVICTED"
                    : evictedTelemetry > 0 ? "BUFFER_TELEMETRY_EVICTED"
                    : "BUFFER_ADMITTED");
        }
        finally
        {
            _gate.Release();
        }
    }

    /// <summary>
    /// The next records to deliver, oldest first across both classes.
    /// <para>
    /// One order, not one queue per class. CH1-VVT-TC-0026 requires telemetry to recover
    /// <em>in order</em>, and a critical event that jumped the queue would arrive before
    /// readings that preceded it — which is a different history from the one that happened.
    /// </para>
    /// </summary>
    public async ValueTask<IReadOnlyList<BufferedRecord>> PeekAsync(int maximum, CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            await using var command = _connection.CreateCommand();
            command.CommandText =
                """
                SELECT sequence, record_class, message_type, device_id, occurred_at, enqueued_at, payload
                FROM edge_buffer ORDER BY sequence LIMIT $limit;
                """;
            command.Parameters.AddWithValue("$limit", maximum);

            var records = new List<BufferedRecord>(Math.Min(maximum, 256));
            await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
            while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
            {
                records.Add(new BufferedRecord(
                    reader.GetInt64(0),
                    (EdgeRecordClass)reader.GetInt32(1),
                    reader.GetString(2),
                    reader.GetString(3),
                    DateTimeOffset.Parse(reader.GetString(4), System.Globalization.CultureInfo.InvariantCulture),
                    DateTimeOffset.Parse(reader.GetString(5), System.Globalization.CultureInfo.InvariantCulture),
                    (byte[])reader["payload"]));
            }

            return records;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async ValueTask RemoveAsync(IReadOnlyList<long> sequences, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sequences);
        if (sequences.Count == 0)
        {
            return;
        }

        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            await using var transaction = await _connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);
            await using (var command = _connection.CreateCommand())
            {
                command.Transaction = (SqliteTransaction)transaction;
                command.CommandText = "DELETE FROM edge_buffer WHERE sequence = $sequence;";
                var parameter = command.CreateParameter();
                parameter.ParameterName = "$sequence";
                command.Parameters.Add(parameter);
                foreach (var sequence in sequences)
                {
                    parameter.Value = sequence;
                    await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
                }
            }

            await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async ValueTask<BufferStatistics> StatisticsAsync(CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            await using var command = _connection.CreateCommand();
            command.CommandText =
                """
                SELECT
                  COALESCE(SUM(CASE WHEN record_class = 0 THEN 1 ELSE 0 END), 0),
                  COALESCE(SUM(CASE WHEN record_class = 1 THEN 1 ELSE 0 END), 0),
                  COALESCE(SUM(LENGTH(payload)), 0),
                  MIN(occurred_at),
                  MAX(occurred_at)
                FROM edge_buffer;
                """;
            await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
            if (!await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
            {
                return new BufferStatistics(0, 0, 0, null, null);
            }

            return new BufferStatistics(
                reader.GetInt64(0),
                reader.GetInt64(1),
                reader.GetInt64(2),
                reader.IsDBNull(3) ? null : DateTimeOffset.Parse(reader.GetString(3), System.Globalization.CultureInfo.InvariantCulture),
                reader.IsDBNull(4) ? null : DateTimeOffset.Parse(reader.GetString(4), System.Globalization.CultureInfo.InvariantCulture));
        }
        finally
        {
            _gate.Release();
        }
    }

    private async ValueTask<long> CountAsync(
        EdgeRecordClass recordClass,
        System.Data.Common.DbTransaction transaction,
        CancellationToken cancellationToken)
    {
        await using var command = _connection.CreateCommand();
        command.Transaction = (SqliteTransaction)transaction;
        command.CommandText = "SELECT COUNT(*) FROM edge_buffer WHERE record_class = $class;";
        command.Parameters.AddWithValue("$class", (int)recordClass);
        return (long)(await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false) ?? 0L);
    }

    private async ValueTask<long> ByteSizeAsync(
        System.Data.Common.DbTransaction transaction,
        CancellationToken cancellationToken)
    {
        await using var command = _connection.CreateCommand();
        command.Transaction = (SqliteTransaction)transaction;
        command.CommandText = "SELECT COALESCE(SUM(LENGTH(payload)), 0) FROM edge_buffer;";
        return (long)(await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false) ?? 0L);
    }

    private async ValueTask<int> EvictOldestAsync(
        EdgeRecordClass recordClass,
        long count,
        System.Data.Common.DbTransaction transaction,
        CancellationToken cancellationToken)
    {
        await using var command = _connection.CreateCommand();
        command.Transaction = (SqliteTransaction)transaction;
        command.CommandText =
            """
            DELETE FROM edge_buffer WHERE sequence IN (
                SELECT sequence FROM edge_buffer WHERE record_class = $class ORDER BY sequence LIMIT $count);
            """;
        command.Parameters.AddWithValue("$class", (int)recordClass);
        command.Parameters.AddWithValue("$count", count);
        return await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    private static async ValueTask ExecuteAsync(
        SqliteConnection connection,
        string sql,
        CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = sql;
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask DisposeAsync()
    {
        await _connection.DisposeAsync().ConfigureAwait(false);
        _gate.Dispose();
    }
}
