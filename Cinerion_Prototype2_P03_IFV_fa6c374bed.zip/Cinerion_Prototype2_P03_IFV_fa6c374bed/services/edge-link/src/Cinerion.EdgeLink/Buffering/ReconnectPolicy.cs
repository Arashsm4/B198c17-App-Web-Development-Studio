// Reconnect backoff with jitter, so a room full of gateways doesn't all knock at once.

namespace Cinerion.EdgeLink.Buffering;

/// <summary>
/// Bounded exponential reconnect backoff with jitter.
/// <para>
/// CH1-COM-FR-0010 requires the gateway to apply "duplicate suppression, bounded retry and
/// exponential reconnect backoff with jitter", and CH1-COM-PRO-0001 restates it: "Retries
/// use exponential backoff with jitter and stop at expiry." Duplicate suppression existed
/// at three layers; the backoff did not exist at all, so a gateway whose link went down
/// hammered Control Core once per publication cycle for as long as the outage lasted.
/// </para>
/// <para>
/// <b>Jitter is not decoration.</b> Every gateway on a site loses the same link at the same
/// moment, and without it they would all return in step — turning one outage into a
/// thundering herd against the service that has just come back. The jitter is full-range
/// rather than a small percentage, because a small percentage of a synchronised delay is
/// still synchronised.
/// </para>
/// <para>
/// <b>It is bounded and it never gives up.</b> "Stop at expiry" governs a <em>command</em>,
/// which expires and must never be retried afterwards. Telemetry has no expiry — that is
/// what the buffer is for — so the delay is capped and reconnection continues. A gateway
/// that stopped trying would hold 24 hours of readings and never deliver them.
/// </para>
/// </summary>
/// <requirements>CH1-COM-FR-0010, CH1-COM-PRO-0001</requirements>
public sealed class ReconnectPolicy(
    TimeSpan initialDelay,
    TimeSpan maximumDelay,
    Random? random = null)
{
    private readonly Random _random = random ?? Random.Shared;
    private int _consecutiveFailures;

    /// <summary>The delay before the first retry, doubled on each further failure.</summary>
    public static readonly TimeSpan DefaultInitialDelay = TimeSpan.FromSeconds(1);

    /// <summary>
    /// The ceiling. Chosen so a gateway rediscovers a restored link well inside the window
    /// a cell's permissive would need to be re-established in, rather than leaving an
    /// operator waiting for a backoff to unwind.
    /// </summary>
    public static readonly TimeSpan DefaultMaximumDelay = TimeSpan.FromSeconds(30);

    public int ConsecutiveFailures => _consecutiveFailures;

    /// <summary>
    /// Records a failure and returns how long to wait before trying again.
    /// <para>
    /// The returned delay is uniform in <c>(0, bounded]</c> where <c>bounded</c> doubles
    /// with each consecutive failure up to the maximum. Reporting the bound alongside the
    /// delay is what lets a log say why the gateway is quiet.
    /// </para>
    /// </summary>
    public ReconnectDelay NextDelay()
    {
        _consecutiveFailures = _consecutiveFailures == int.MaxValue ? _consecutiveFailures : _consecutiveFailures + 1;

        // Doubling is computed in ticks and clamped before it can overflow, because an
        // outage lasting days would otherwise shift a long past its width and produce a
        // negative delay — which Task.Delay answers with an exception rather than a wait.
        var exponent = Math.Min(_consecutiveFailures - 1, 32);
        var scaled = initialDelay.Ticks * Math.Pow(2, exponent);
        var boundedTicks = (long)Math.Min(scaled, maximumDelay.Ticks);
        var bounded = TimeSpan.FromTicks(Math.Max(boundedTicks, TimeSpan.FromMilliseconds(1).Ticks));

        var jittered = TimeSpan.FromTicks(_random.NextInt64(1, bounded.Ticks + 1));
        return new ReconnectDelay(jittered, bounded, _consecutiveFailures);
    }

    /// <summary>
    /// The link answered. The next failure starts from the initial delay again, so a link
    /// that flaps is not treated as one that has been down for an hour.
    /// </summary>
    public void Succeeded() => _consecutiveFailures = 0;
}

/// <param name="Delay">How long to actually wait.</param>
/// <param name="Bound">The un-jittered ceiling this delay was drawn from.</param>
/// <param name="ConsecutiveFailures">How many attempts have failed in a row.</param>
public sealed record ReconnectDelay(TimeSpan Delay, TimeSpan Bound, int ConsecutiveFailures);
