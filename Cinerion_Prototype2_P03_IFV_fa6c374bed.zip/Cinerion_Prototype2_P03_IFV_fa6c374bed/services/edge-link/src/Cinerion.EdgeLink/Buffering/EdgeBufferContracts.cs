// What a buffered record is, and what may happen to it when the buffer gets crowded.

namespace Cinerion.EdgeLink.Buffering;

/// <summary>
/// What a buffered record is, and therefore what may happen to it under pressure.
/// <para>
/// CH1-COM-PRO-0001 makes the distinction: "QoS is chosen by semantics: telemetry
/// tolerates bounded loss where declared; critical events require confirmed delivery",
/// and "flow control caps memory and disk, <b>preserving newest critical events according
/// to policy</b>". CH1-NFR-REL-0001 states the consequence as the requirement: 24 hours of
/// telemetry, "without overwriting newer critical events".
/// </para>
/// </summary>
public enum EdgeRecordClass
{
    /// <summary>A reading. Evictable oldest-first when the buffer is full.</summary>
    Telemetry,

    /// <summary>
    /// A controller transition or a command acknowledgement. Never evicted to make room
    /// for telemetry, whatever the pressure.
    /// </summary>
    CriticalEvent,
}

/// <summary>One record awaiting delivery, exactly as it would have been sent.</summary>
/// <remarks>
/// The payload is the serialised protobuf message, not a re-encoding of it. That keeps the
/// buffer transport-agnostic and, more importantly, preserves the message identifier: a
/// publication that reached Control Core but whose receipt was lost is replayed with the
/// same identifier and refused as a duplicate, which is the correct answer rather than a
/// second copy of the reading.
/// </remarks>
public sealed record BufferedRecord(
    long Sequence,
    EdgeRecordClass Class,
    string MessageType,
    string DeviceId,
    DateTimeOffset OccurredAt,
    DateTimeOffset EnqueuedAt,
    byte[] Payload);

/// <summary>What admitting a record actually did, so the caller can report it rather than assume.</summary>
/// <param name="Admitted">False only when the buffer refused the record outright.</param>
/// <param name="EvictedTelemetry">Telemetry discarded to make room.</param>
/// <param name="EvictedCritical">
/// Critical events discarded. Non-zero only when the buffer holds nothing but critical
/// events and a newer one has arrived — the "preserving newest critical events" case.
/// Every occurrence is worth a warning in the gateway's log, because it means the link has
/// been down long enough to lose evidence.
/// </param>
/// <param name="ReasonCode">A stable code, in the same style the ingress answers with.</param>
public sealed record BufferAdmission(
    bool Admitted,
    int EvictedTelemetry,
    int EvictedCritical,
    string ReasonCode);

/// <summary>What the buffer currently holds. Counted, never estimated.</summary>
public sealed record BufferStatistics(
    long TelemetryRecords,
    long CriticalRecords,
    long Bytes,
    DateTimeOffset? OldestOccurredAt,
    DateTimeOffset? NewestOccurredAt)
{
    public long TotalRecords => TelemetryRecords + CriticalRecords;

    /// <summary>
    /// How much history the buffer is actually holding. This is the number
    /// CH1-NFR-REL-0001 is about, and it is measured from the records rather than derived
    /// from the configured capacity — a buffer sized for 24 hours that is silently dropping
    /// at six would report the same capacity and a very different span.
    /// </summary>
    public TimeSpan RetainedSpan => OldestOccurredAt is { } oldest && NewestOccurredAt is { } newest
        ? newest - oldest
        : TimeSpan.Zero;
}

/// <summary>
/// Bounded store-and-forward for the gateway.
/// <para>
/// There is deliberately no way to put a command in here. CH1-SYS-CON-0001 is explicit —
/// "Telemetry may buffer, but commands are not stored for future execution" — and
/// CH1-COM-FR-0007 says the same. That is enforced by the shape of this interface rather
/// than by a check inside it: <see cref="EdgeRecordClass"/> has two members and neither is
/// a command, so there is no call a future caller could make.
/// </para>
/// </summary>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-FR-0007, CH1-SYS-CON-0001</requirements>
public interface IEdgeBuffer : IAsyncDisposable
{
    /// <summary>Where the records live, for the gateway to state at startup.</summary>
    string Description { get; }

    /// <summary>How many telemetry records this buffer is sized to hold.</summary>
    long TelemetryCapacity { get; }

    ValueTask<BufferAdmission> EnqueueAsync(
        EdgeRecordClass recordClass,
        string messageType,
        string deviceId,
        DateTimeOffset occurredAt,
        ReadOnlyMemory<byte> payload,
        CancellationToken cancellationToken);

    /// <summary>
    /// The next records to deliver, oldest first. Peek rather than dequeue: a record is
    /// removed only once Control Core has answered, so a gateway that dies mid-flight
    /// replays rather than loses.
    /// </summary>
    ValueTask<IReadOnlyList<BufferedRecord>> PeekAsync(int maximum, CancellationToken cancellationToken);

    /// <summary>Removes records that have been answered for.</summary>
    ValueTask RemoveAsync(IReadOnlyList<long> sequences, CancellationToken cancellationToken);

    ValueTask<BufferStatistics> StatisticsAsync(CancellationToken cancellationToken);
}
