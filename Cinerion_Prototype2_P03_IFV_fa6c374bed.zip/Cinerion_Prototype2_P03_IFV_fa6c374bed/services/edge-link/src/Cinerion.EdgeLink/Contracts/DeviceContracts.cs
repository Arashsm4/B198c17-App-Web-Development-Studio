// The shapes devices declare: channels, endpoints and capability manifests.

namespace Cinerion.EdgeLink.Contracts;

public sealed record CapabilityChannel(string ChannelId, string Unit, bool Writable = false);

public sealed record ProtocolEndpoint(string Protocol, string ProfileVersion);

public sealed record DeviceCapabilityManifest(
    string SchemaVersion,
    string DeviceId,
    string DeviceType,
    string FirmwareVersion,
    string ConfigurationRevision,
    IReadOnlyList<string> SupportedCommands,
    IReadOnlyList<CapabilityChannel> TelemetryChannels,
    IReadOnlyList<ProtocolEndpoint> ProtocolEndpoints,
    string SecurityProfile);

public sealed record SemanticCommandEnvelope(
    string SchemaVersion,
    Guid MessageId,
    Guid CorrelationId,
    Guid CommandId,
    Guid ProjectId,
    Guid CellId,
    Guid AssetId,
    long Sequence,
    string ExpectedStateHash,
    string ConfigurationRevision,
    DateTimeOffset ExpiresAt,
    string CommandType,
    IReadOnlyDictionary<string, object> Parameters);

public sealed record AdapterAcknowledgement(
    Guid CommandId,
    bool Accepted,
    string ControllerState,
    string ReasonCode,
    DateTimeOffset ObservedAt,
    string AdapterId,
    /// <summary>
    /// What the CONTROLLER declared about the clock that stamped
    /// <paramref name="ObservedAt"/>. Same rule as <see cref="TelemetryPoint"/>.
    /// </summary>
    string? SourceTimeQuality = null);

public sealed record TelemetryPoint(
    string DeviceId,
    string ChannelId,
    double Value,
    string Unit,
    string Quality,
    DateTimeOffset SampledAt,
    long Sequence,
    /// <summary>
    /// What the SOURCE declared about the clock that stamped <paramref name="SampledAt"/>.
    /// <para>
    /// This is the device's own opinion of its clock, not the gateway's. Until it existed
    /// the MQTT adapter decoded a CH1 envelope's <c>timeQuality</c> and then dropped it,
    /// and the gateway stamped every publication it forwarded as <c>Qualified</c> - so a
    /// controller honestly reporting <c>Unsynchronised</c>, which since defect 58 is what
    /// a controller with no disciplined clock does report, arrived at Control Core
    /// indistinguishable from one that had been disciplined. Defect 59, conflict 27.
    /// </para>
    /// <para>
    /// <c>null</c> when the source declared nothing. Where the GATEWAY takes the sample
    /// itself - the OPC UA and Modbus adapters read a register and stamp it here - the
    /// source of <paramref name="SampledAt"/> IS the gateway's clock, so the gateway's own
    /// declaration is the honest value and is passed explicitly rather than defaulted.
    /// </para>
    /// </summary>
    string? SourceTimeQuality = null)
{
    /// <summary>
    /// What an adapter declares when the GATEWAY stamped <see cref="SampledAt"/> itself -
    /// a Modbus register read, an OPC UA monitored item, the simulator - rather than
    /// receiving a time from the device.
    /// <para>
    /// It is a sentinel rather than a value because the adapter knows WHOSE clock stamped
    /// the sample and does not know what that clock is worth; the gateway's own declared
    /// quality is resolved once, at the ingress boundary, from
    /// <c>ControlCoreIngressOptions.GatewayTimeQuality</c>. The alternative - letting the
    /// null default silently pick up the gateway's quality - is the substitution defect 59
    /// was, and it would attribute the gateway's clock to a device that had declared
    /// nothing.
    /// </para>
    /// </summary>
    public const string GatewayStamped = "GatewayStamped";
}

/// <summary>
/// The local inputs a controller reports, and whether it reported them at all.
/// <para>
/// <see cref="Reported"/> exists because the honest answer is often "not answered". The
/// controlled OPC UA and Modbus profiles both declare <c>207 PRELIMINARY_PERMISSIVE_INVALID</c>
/// as a deferred check: <c>UDT_CH1_Permissives</c> is read from wired inputs, and a
/// stand-in has none. A gateway must be able to pass that on, because the alternative is
/// inventing the answer that decides whether a machine may move.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-SAF-FR-0003, CH1-AUT-FDS-0001</requirements>
public sealed record ControllerPermissives(
    bool Reported,
    bool ControllerOnline,
    bool StartEnable,
    bool StopCircuitHealthy,
    bool GuardHealthy,
    bool ActuatorHome,
    bool ButtonPressed,
    bool FaultCauseActive,
    IReadOnlyList<uint> DeferredCheckCodes)
{
    public static readonly ControllerPermissives NotReported =
        new(false, false, false, false, false, false, false, false, []);
}

/// <summary>What an adapter observed about the controller itself, rather than about a channel.</summary>
public sealed record ControllerStateObservation(
    string ControllerId,
    Guid ControllerBootId,
    string OperatingState,
    string ConfigurationRevision,
    ControllerPermissives Permissives,
    string SecurityProfile,
    string FirmwareVersion,
    string Freshness,
    DateTimeOffset ObservedAt,
    /// <summary>
    /// What the CONTROLLER declared about its own clock. <c>null</c> when it declared
    /// nothing, which is the honest answer for a Modbus zone and for an OPC UA stand-in:
    /// neither protocol carries a time quality, and the gateway must not invent one on
    /// the controller's behalf. Defect 59, conflict 27.
    /// </summary>
    string? SourceTimeQuality = null);

/// <summary>
/// An adapter that can report the controller's own state, not merely its channels.
/// <para>
/// Deliberately separate from <see cref="IProtocolAdapter"/> rather than added to it. An
/// adapter that cannot read a controller's operating state and permissives must not be
/// obliged to return something shaped like one — the interface being optional is what
/// keeps "this controller does not answer that" expressible, instead of every adapter
/// having to produce a value it does not have.
/// </para>
/// </summary>
/// <requirements>CH1-COM-IF-0003, CH1-COM-FR-0001</requirements>
public interface IControllerStateSource
{
    ValueTask<ControllerStateObservation> ReadControllerStateAsync(CancellationToken cancellationToken);
}

