// Tests for the OPC UA edge failing closed when it isn't configured.

using Cinerion.EdgeLink.Protocols;
using Microsoft.Extensions.Configuration;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// The fail-closed decision on the OPC UA edge, and the gated adapter's contract while the
/// edge is not configured.
/// </summary>
/// <remarks>
/// The live behaviour of this adapter cannot be asserted here and deliberately is not: it
/// needs a real OPC UA server, a real secure channel and a real certificate trust list, so
/// it is exercised by <c>scripts/check-opcua-edge.sh</c> against a running controller. What
/// belongs in a unit test is the decision that governs whether the live adapter is
/// registered at all, because that decision is what stands between an unconfigured
/// deployment and one talking to a controller over an unsecured channel.
/// </remarks>
/// <requirements>CH1-COM-IF-0007, CH1-COM-IF-0022, CH1-COM-FR-0002, CH1-CYB-CSRS-0001</requirements>
public sealed class OpcUaEdgeTests
{
    private static readonly Dictionary<string, string?> Complete = new()
    {
        ["CINERION_OPCUA_ENDPOINT"] = "opc.tcp://opcua-plc:4840/ch1",
        ["CINERION_OPCUA_CA_CERT"] = "/run/secrets/opcua/ca.crt",
        ["CINERION_OPCUA_CLIENT_CERT"] = "/run/secrets/opcua/edgelink.crt",
        ["CINERION_OPCUA_CLIENT_KEY"] = "/run/secrets/opcua/edgelink.key",
    };

    public static TheoryData<string> RequiredSettings() => new()
    {
        "CINERION_OPCUA_ENDPOINT",
        "CINERION_OPCUA_CA_CERT",
        "CINERION_OPCUA_CLIENT_CERT",
        "CINERION_OPCUA_CLIENT_KEY",
    };

    /// <summary>
    /// All four or none. Any one of them missing leaves the edge unconfigured, so the
    /// gateway registers the gated adapter instead of a live one — the same fail-closed
    /// direction the MQTT edge, the identity directory and the storage mode all take.
    /// </summary>
    [Theory]
    [MemberData(nameof(RequiredSettings))]
    public void Ch1ComIf0007_AnIncompletelyConfiguredEdgeIsNotConfiguredAtAll(string omitted)
    {
        var settings = Complete.Where(entry => entry.Key != omitted);

        var options = OpcUaAdapterOptions.FromConfiguration(
            new ConfigurationBuilder().AddInMemoryCollection(settings).Build());

        Assert.Null(options);
    }

    /// <summary>
    /// And the positive half, so the refusal above is about completeness rather than about
    /// the reader never returning anything.
    /// </summary>
    [Fact]
    public void Ch1ComIf0007_ACompletelyConfiguredEdgeIsAccepted()
    {
        var options = OpcUaAdapterOptions.FromConfiguration(
            new ConfigurationBuilder().AddInMemoryCollection(Complete).Build());

        Assert.NotNull(options);
        Assert.Equal("opc.tcp://opcua-plc:4840/ch1", options.EndpointUrl);
        // The application URI is what the controller checks the gateway's certificate
        // subjectAltName against, so a default that did not match would fail closed too.
        Assert.Equal("urn:cinerion:ch1:edgelink", options.ApplicationUri);
        Assert.Equal("CH1-DEV-CELL-0001", options.DeviceId);
        Assert.True(options.CallTimeout > TimeSpan.Zero);
    }

    /// <summary>
    /// The gated OPC UA adapter answers on the same identity as the live one, so a
    /// deployment that has not been commissioned is not a different adapter with a
    /// different name — it is the same edge, refusing.
    /// </summary>
    [Fact]
    public async Task Ch1ComFr0002_TheGatedAndLiveOpcUaAdaptersShareOneIdentity()
    {
        var gated = new OpcUaGatedAdapter();

        Assert.Equal("CH1-ADP-OPCUA-0001", gated.AdapterId);
        Assert.Equal("OPCUA", gated.Protocol);

        var results = await AdapterConformance.RunGatedAsync(gated, TestContext.Current.CancellationToken);
        Assert.All(results, result => Assert.True(result.Passed, result.ToString()));
    }
}
