// Tests for the envelope, including the one byte string both implementations must agree on.

using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Protocols;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// The CH1 envelope, and the one literal that binds two independent implementations of it.
/// </summary>
/// <remarks>
/// <para>
/// <c>firmware/shared/src/ch1_envelope.cpp</c> encodes the same controlled format for the
/// ESP32-S3, written against CH1-COM-ICD-0001 rather than against this code. Two
/// implementations of one format agree only if something says so, and the only honest
/// form of that statement is the bytes: this test asserts a hex literal, and
/// <c>firmware/tests/ch1_envelope_test.cpp</c> asserts the same literal from the other
/// side. Either implementation drifting fails one of the two.
/// </para>
/// <para>
/// The value is not a fixture somebody typed. It is what a canonical CBOR encoder
/// produces for a stated envelope, and the firmware has to reach it by encoding the same
/// fields in the same canonical order — which is the property that matters, because the
/// gateway decodes in Canonical mode and refuses anything else.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-ICD-0001, CH1-COM-IF-0004, CH1-COM-IF-0005</requirements>
public sealed class Ch1MessageEnvelopeTests
{
    private static readonly Guid Project = new("00000000-0000-4000-8000-000000000101");
    private static readonly Guid Cell = new("00000000-0000-4000-8000-000000000103");
    private static readonly Guid Asset = new("00000000-0000-4000-8000-000000000104");
    private static readonly Guid Message = new("11111111-2222-3333-4444-555555555555");
    private static readonly Guid Correlation = new("66666666-7777-8888-9999-aaaaaaaaaaaa");

    /// <summary>The same envelope firmware/tests/ch1_envelope_test.cpp builds.</summary>
    private static byte[] ReferenceTelemetry() => Ch1MessageEnvelope.EncodeTelemetry(
        new TelemetryPoint(
            "CH1-DEV-CELL-0001",
            "temperature",
            22.5,
            "degC",
            "Good",
            DateTimeOffset.FromUnixTimeMilliseconds(1_700_000_000_000),
            42),
        "CH1-DEV-CELL-0001",
        "ch1-edgelink",
        Project,
        Cell,
        Asset,
        Correlation,
        Message,
        DateTimeOffset.FromUnixTimeMilliseconds(1_700_000_001_000));

    /// <summary>
    /// The agreed encoding of the reference envelope, asserted from both sides.
    /// firmware/tests/ch1_envelope_test.cpp holds the same literal.
    /// </summary>
    private const string ExpectedHex =
        "AD64747970656974656C656D657472796663656C6C4964500000000000000040800000000000" +
        "010366736368656D6165312E302E306673656E7441741B0000018BCFE56BE866736F75726365" +
        "714348312D4445562D43454C4C2D303030316761737365744964500000000000000040800000" +
        "0000000104677061796C6F6164A564756E697464646567436576616C7565F94DA0677175616C" +
        "69747964476F6F64696368616E6E656C49646B74656D70657261747572656973616D706C6564" +
        "41741B0000018BCFE568006873657175656E6365182A696D6573736167654964501111111122" +
        "22333344445555555555556970726F6A65637449645000000000000000408000000000000101" +
        "6B64657374696E6174696F6E6C6368312D656467656C696E6B6B74696D655175616C6974796C" +
        "53796E6368726F6E697365646D636F7272656C6174696F6E49645066666666777788889999AA" +
        "AAAAAAAAAA";

    [Fact]
    [VerificationCase("CH1-VVT-TC-0022")]
    public void Ch1ComIcd0001_TheReferenceTelemetryEnvelopeEncodesToTheAgreedBytes()
    {
        // If this literal changes, the firmware's copy must change with it and both sides
        // must be re-run. That is the intended cost of altering a controlled wire format.
        Assert.Equal(ExpectedHex, Convert.ToHexString(ReferenceTelemetry()));
    }

    [Fact]
    public void Ch1ComIcd0001_TheEnvelopeRoundTripsThroughItsOwnDecoder()
    {
        var decoded = Ch1MessageEnvelope.Decode(ReferenceTelemetry());

        Assert.Equal(Ch1MessageEnvelope.SchemaVersion, decoded.Schema);
        Assert.Equal(Ch1MessageEnvelope.Types.Telemetry, decoded.Type);
        Assert.Equal(Message, decoded.MessageId);
        Assert.Equal(Correlation, decoded.CorrelationId);
        Assert.Equal(Project, decoded.ProjectId);
        Assert.Equal(Cell, decoded.CellId);
        Assert.Equal(Asset, decoded.AssetId);
        Assert.Equal(42, decoded.Sequence);
        Assert.Equal("Synchronised", decoded.TimeQuality);
        Assert.Equal(22.5, Ch1MessageEnvelope.PayloadNumber(decoded.Payload, "value"));
        Assert.Equal("degC", Ch1MessageEnvelope.PayloadText(decoded.Payload, "unit"));
        // The source sample time, not the send time. Store-and-forward makes them differ,
        // and a reader that could not tell them apart would age a buffered reading from
        // the moment it happened to arrive.
        Assert.Equal(
            1_700_000_000_000,
            (long)Ch1MessageEnvelope.PayloadNumber(decoded.Payload, "sampledAt"));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(7)]
    [InlineData(19)]
    public void Ch1ComIcd0001_ATruncatedEnvelopeIsRefusedRatherThanPartiallyRead(int keep)
    {
        // A truncated message that happened to parse would be a different message. The
        // decoder must refuse with a stable code rather than return a half-read envelope.
        var truncated = ReferenceTelemetry().AsSpan(0, keep).ToArray();
        var error = Assert.Throws<Ch1EnvelopeException>(() => Ch1MessageEnvelope.Decode(truncated));
        Assert.StartsWith("ENVELOPE_", error.Code, StringComparison.Ordinal);
    }

    [Fact]
    public void Ch1ComIcd0001_AnAlteredByteIsRefused()
    {
        var altered = ReferenceTelemetry();
        // The schema version's first character. Anything the decoder cannot recognise as
        // the supported major version fails closed.
        var index = Array.IndexOf(altered, (byte)'1');
        altered[index] = (byte)'9';

        var error = Assert.Throws<Ch1EnvelopeException>(() => Ch1MessageEnvelope.Decode(altered));
        Assert.Equal("ENVELOPE_SCHEMA_UNSUPPORTED", error.Code);
    }
}
