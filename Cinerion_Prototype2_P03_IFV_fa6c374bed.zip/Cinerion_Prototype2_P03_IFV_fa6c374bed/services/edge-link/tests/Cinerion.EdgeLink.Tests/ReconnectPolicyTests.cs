// Tests for retry and backoff timing, jitter included.

using Cinerion.Contracts.EdgeLink.V1;
using Cinerion.EdgeLink.Buffering;
using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Runtime;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// Bounded retry and exponential reconnect backoff with jitter, CH1-COM-FR-0010.
/// </summary>
/// <remarks>
/// Until the buffer existed there was nothing to back off <em>for</em>: a gateway whose
/// link went down simply published into the void once per cycle. CH1-VVT-TC-0029's note
/// recorded that the backoff "is still not implemented and has nothing to bind".
/// </remarks>
/// <requirements>CH1-COM-FR-0010, CH1-COM-PRO-0001</requirements>
public sealed class ReconnectPolicyTests
{
    private static ReconnectPolicy Policy(int seed = 1979) =>
        new(TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(30), new Random(seed));

    /// <summary>
    /// The bound doubles with each consecutive failure. Asserted on the bound rather than
    /// on the delay, because the delay is jittered and asserting on it would be asserting
    /// on the seed.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void Ch1ComFr0010_TheBoundDoublesWithEachConsecutiveFailure()
    {
        var policy = Policy();

        Assert.Equal(TimeSpan.FromSeconds(1), policy.NextDelay().Bound);
        Assert.Equal(TimeSpan.FromSeconds(2), policy.NextDelay().Bound);
        Assert.Equal(TimeSpan.FromSeconds(4), policy.NextDelay().Bound);
        Assert.Equal(TimeSpan.FromSeconds(8), policy.NextDelay().Bound);
        Assert.Equal(TimeSpan.FromSeconds(16), policy.NextDelay().Bound);
    }

    /// <summary>
    /// It is bounded, and it stays bounded across an outage lasting days. The doubling is
    /// computed in ticks and clamped, so a long that shifted past its own width could not
    /// produce a negative delay — which <c>Task.Delay</c> answers with an exception rather
    /// than a wait, turning a backoff into a crash loop.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void Ch1ComFr0010_TheDelayIsCappedAndNeverGoesNegative()
    {
        var policy = Policy();

        for (var i = 0; i < 5_000; i++)
        {
            var delay = policy.NextDelay();

            Assert.True(delay.Bound <= TimeSpan.FromSeconds(30), $"Bound {delay.Bound} exceeded the cap.");
            Assert.True(delay.Delay > TimeSpan.Zero, $"Delay {delay.Delay} was not positive.");
            Assert.True(delay.Delay <= delay.Bound, $"Delay {delay.Delay} exceeded its own bound {delay.Bound}.");
        }
    }

    /// <summary>
    /// <b>The jitter is real and it is full-range.</b> Every gateway on a site loses the
    /// same link at the same moment; without jitter they return in step and turn one outage
    /// into a thundering herd. A small percentage of a synchronised delay is still
    /// synchronised, so the delay must be spread across the whole interval rather than
    /// clustered near the bound.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void Ch1ComFr0010_TheDelayIsJitteredAcrossTheWholeBound()
    {
        // A fresh policy per draw, so every draw is the same failure count and the spread
        // measured is the jitter rather than the doubling.
        var draws = Enumerable.Range(0, 400)
            .Select(seed =>
            {
                var policy = new ReconnectPolicy(
                    TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(30), new Random(seed));
                policy.NextDelay();
                policy.NextDelay();
                policy.NextDelay();
                return policy.NextDelay();
            })
            .ToArray();

        var bound = TimeSpan.FromSeconds(8);
        Assert.All(draws, draw => Assert.Equal(bound, draw.Bound));

        var distinct = draws.Select(draw => draw.Delay).Distinct().Count();
        Assert.True(distinct > 300, $"Only {distinct} distinct delays in 400 draws: the jitter is not doing its job.");

        // Spread over the whole interval, not merely varied within a corner of it.
        Assert.Contains(draws, draw => draw.Delay < bound * 0.25);
        Assert.Contains(draws, draw => draw.Delay > bound * 0.75);
    }

    /// <summary>
    /// A link that answers resets the ladder, so a link that flaps is not treated as one
    /// that has been down for an hour.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void Ch1ComFr0010_ASuccessfulPublicationResetsTheLadder()
    {
        var policy = Policy();
        policy.NextDelay();
        policy.NextDelay();
        policy.NextDelay();
        Assert.Equal(3, policy.ConsecutiveFailures);

        policy.Succeeded();

        Assert.Equal(0, policy.ConsecutiveFailures);
        Assert.Equal(TimeSpan.FromSeconds(1), policy.NextDelay().Bound);
    }
}

/// <summary>
/// What the gateway decides changed between two readings of a controller.
/// </summary>
/// <remarks>
/// This lives at the gateway because only the gateway sees both sides of a transition
/// during an outage. A guard that opened and closed while the link was down leaves no
/// evidence anywhere unless something at the edge noticed and kept it.
/// </remarks>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-FR-0009, CH1-CMD-FR-0009</requirements>
public sealed class ControllerTransitionTests
{
    private static ControllerPermissives Healthy(bool reported = true) => new(
        Reported: reported,
        ControllerOnline: true,
        StartEnable: true,
        StopCircuitHealthy: true,
        GuardHealthy: true,
        ActuatorHome: true,
        ButtonPressed: false,
        FaultCauseActive: false,
        DeferredCheckCodes: []);

    private static ControllerStateObservation Observation(
        ControllerPermissives permissives,
        Guid? bootId = null,
        string operatingState = "Idle",
        string configurationRevision = "1.0.0") => new(
            ControllerId: "CH1-DEV-CELL-0001",
            ControllerBootId: bootId ?? Guid.Parse("11111111-1111-1111-1111-111111111111"),
            OperatingState: operatingState,
            ConfigurationRevision: configurationRevision,
            Permissives: permissives,
            SecurityProfile: "SignAndEncrypt",
            FirmwareVersion: "1.0.0",
            Freshness: "Simulated",
            ObservedAt: DateTimeOffset.UtcNow);

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void TheFirstSightOfAControllerIsItsOwnTransition()
    {
        var transitions = ControllerTransitions.Between(null, Observation(Healthy()));

        Assert.Single(transitions);
        Assert.Equal(ControllerEventKind.LinkEstablished, transitions[0].Kind);
    }

    /// <summary>
    /// The event names the input that went. Which one opened is the whole content of the
    /// record for anyone reading it after the fact.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void APermissiveLostNamesTheInputThatOpened()
    {
        var previous = Observation(Healthy());
        var current = Observation(Healthy() with { GuardHealthy = false });

        var transitions = ControllerTransitions.Between(previous, current);

        var lost = Assert.Single(transitions, t => t.Kind == ControllerEventKind.PermissiveLost);
        Assert.Equal("GUARD_INTERLOCK_OPENED", lost.ReasonCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void APermissiveRestoredIsItsOwnTransition()
    {
        var previous = Observation(Healthy() with { GuardHealthy = false });
        var current = Observation(Healthy());

        var transitions = ControllerTransitions.Between(previous, current);

        Assert.Single(transitions, t => t.Kind == ControllerEventKind.PermissiveRestored);
    }

    /// <summary>
    /// A controller that stops answering its permissives is a different fact from one that
    /// answers "no". Both leave the cell not permissive, and an investigator needs to know
    /// which happened.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void PermissivesNoLongerAnsweredIsDistinctFromAPermissiveLost()
    {
        var previous = Observation(Healthy());
        var current = Observation(Healthy(reported: false));

        var transitions = ControllerTransitions.Between(previous, current);

        Assert.Single(transitions, t => t.Kind == ControllerEventKind.PermissivesNoLongerAnswered);
        Assert.DoesNotContain(transitions, t => t.Kind == ControllerEventKind.PermissiveLost);
    }

    /// <summary>
    /// A reboot voids anything prepared before it, which is CH1-CMD-FR-0009, so it is the
    /// transition a reader most needs to find.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void ARebootIsReportedAndSaysWhatItCost()
    {
        var previous = Observation(Healthy());
        var current = Observation(Healthy(), bootId: Guid.Parse("22222222-2222-2222-2222-222222222222"));

        var transitions = ControllerTransitions.Between(previous, current);

        var reboot = Assert.Single(transitions, t => t.Kind == ControllerEventKind.ControllerRebooted);
        Assert.Contains("UNCOMMITTED_PREPARES_ARE_VOID", reboot.ReasonCode, StringComparison.Ordinal);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void AFaultLatchingIsItsOwnTransition()
    {
        var previous = Observation(Healthy());
        var current = Observation(Healthy() with { FaultCauseActive = true });

        var transitions = ControllerTransitions.Between(previous, current);

        Assert.Single(transitions, t => t.Kind == ControllerEventKind.FaultLatched);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void AConfigurationRevisionChangeIsItsOwnTransition()
    {
        var previous = Observation(Healthy());
        var current = Observation(Healthy(), configurationRevision: "1.1.0");

        var transitions = ControllerTransitions.Between(previous, current);

        Assert.Single(transitions, t => t.Kind == ControllerEventKind.ConfigurationRevisionChanged);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void AnOperatingStateChangeNamesBothSidesOfIt()
    {
        var previous = Observation(Healthy(), operatingState: "Idle");
        var current = Observation(Healthy(), operatingState: "Running");

        var transitions = ControllerTransitions.Between(previous, current);

        var changed = Assert.Single(transitions, t => t.Kind == ControllerEventKind.OperatingStateChanged);
        Assert.Equal("OPERATING_STATE_IDLE_TO_RUNNING", changed.ReasonCode);
    }

    /// <summary>
    /// A reboot that also lost a permissive is two facts. Collapsing them into one would
    /// make the second unfindable.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void SeveralTransitionsBetweenTwoReadingsAreSeveralRecords()
    {
        var previous = Observation(Healthy());
        var current = Observation(
            Healthy() with { GuardHealthy = false },
            bootId: Guid.Parse("33333333-3333-3333-3333-333333333333"),
            operatingState: "Fault");

        var transitions = ControllerTransitions.Between(previous, current);

        Assert.Equal(3, transitions.Count);
        Assert.Contains(transitions, t => t.Kind == ControllerEventKind.ControllerRebooted);
        Assert.Contains(transitions, t => t.Kind == ControllerEventKind.PermissiveLost);
        Assert.Contains(transitions, t => t.Kind == ControllerEventKind.OperatingStateChanged);
    }

    /// <summary>Two identical readings are not a transition, or the audit chain would fill.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void AnUnchangedControllerProducesNoTransition()
    {
        var observation = Observation(Healthy());

        Assert.Empty(ControllerTransitions.Between(observation, observation));
    }
}
