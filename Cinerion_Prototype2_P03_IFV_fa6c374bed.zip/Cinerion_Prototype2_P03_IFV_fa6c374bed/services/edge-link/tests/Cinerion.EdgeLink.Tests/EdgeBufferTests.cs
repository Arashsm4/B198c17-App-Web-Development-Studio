// Tests for the store-and-forward buffer, under pressure and after restarts.

using Cinerion.EdgeLink.Buffering;
using Microsoft.Data.Sqlite;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// The gateway's store-and-forward buffer, CH1-NFR-REL-0001.
/// </summary>
/// <remarks>
/// <para>
/// What belongs here is everything that can be decided without a running Control Core:
/// the eviction policy in both directions, ordering, survival across a reopen, the derived
/// capacity, and the configuration refusals. The end-to-end half — an outage, a gateway
/// restart during it, and every buffered record arriving in order afterwards — needs two
/// live services and is exercised by <c>scripts/check-gateway-buffer.sh</c>.
/// </para>
/// <para>
/// These tests use a real SQLite file in a temporary directory rather than a fake, because
/// the properties under test are properties of the storage: an eviction and an admission
/// that must be one transaction, and a buffer that must still hold its records after the
/// process that wrote them has gone.
/// </para>
/// </remarks>
/// <requirements>CH1-NFR-REL-0001, CH1-COM-FR-0007, CH1-COM-PRO-0001, CH1-SYS-CON-0001</requirements>
public sealed class EdgeBufferTests : IDisposable
{
    private readonly string _directory = Directory.CreateTempSubdirectory("cinerion-edge-buffer").FullName;

    private string Path(string name) => System.IO.Path.Combine(_directory, name);

    private static EdgeBufferOptions Options(
        string path,
        double feedRate = 4d,
        long headroom = 8,
        long maximumBytes = 256L * 1024 * 1024,
        double retentionHours = 24d) =>
        new(path, TimeSpan.FromHours(retentionHours), feedRate, headroom, maximumBytes);

    private static ValueTask<SqliteEdgeBuffer> OpenAsync(EdgeBufferOptions options) =>
        SqliteEdgeBuffer.OpenAsync(options, TimeProvider.System, TestContext.Current.CancellationToken);

    private static ValueTask<BufferAdmission> AddAsync(
        SqliteEdgeBuffer buffer,
        EdgeRecordClass recordClass,
        DateTimeOffset occurredAt,
        int payloadBytes = 32) =>
        buffer.EnqueueAsync(
            recordClass,
            recordClass == EdgeRecordClass.Telemetry ? "Telemetry" : "ControllerEvent",
            "CH1-DEV-CELL-0001",
            occurredAt,
            new byte[payloadBytes],
            TestContext.Current.CancellationToken);

    // ---------------------------------------------------------------------------------
    // The controlled floor, refused at startup by name.
    // ---------------------------------------------------------------------------------

    /// <summary>
    /// A deployment cannot configure itself below the controlled floor. This is the check
    /// that stops CH1-NFR-REL-0001 being met on paper and not in the running system, and it
    /// must name the setting: "buffer too small" is not actionable.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void Ch1NfrRel0001_ARetentionFloorUnderTwentyFourHoursIsRefusedByName()
    {
        var error = Assert.Throws<InvalidOperationException>(
            () => Options(Path("a.db"), retentionHours: 23.5).Validate());

        Assert.Contains("CINERION_EDGE_BUFFER_RETENTION_HOURS", error.Message, StringComparison.Ordinal);
        Assert.Contains("24", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void Ch1NfrRel0001_ANonPositiveFeedRateIsRefused()
    {
        var error = Assert.Throws<InvalidOperationException>(() => Options(Path("b.db"), feedRate: 0).Validate());

        Assert.Contains("CINERION_EDGE_BUFFER_FEED_RECORDS_PER_SECOND", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void Ch1NfrRel0001_ANonPositiveCriticalHeadroomIsRefused()
    {
        var error = Assert.Throws<InvalidOperationException>(() => Options(Path("c.db"), headroom: 0).Validate());

        Assert.Contains("CINERION_EDGE_BUFFER_CRITICAL_HEADROOM", error.Message, StringComparison.Ordinal);
    }

    /// <summary>
    /// CH1-COM-PRO-0001 caps memory <em>and</em> disk. A byte bound that cannot hold the
    /// deployment's own retention floor is a contradiction, and it is refused at startup
    /// rather than discovered part-way through the outage the buffer exists for.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void Ch1ComPro0001_AByteBoundTooSmallForItsOwnRetentionFloorIsRefused()
    {
        var error = Assert.Throws<InvalidOperationException>(
            () => Options(Path("d.db"), maximumBytes: 1024).Validate());

        Assert.Contains("CINERION_EDGE_BUFFER_MAX_BYTES", error.Message, StringComparison.Ordinal);
        Assert.Contains("345601", error.Message, StringComparison.Ordinal);
    }

    /// <summary>
    /// The capacity is derived, so there is no second number that could disagree with the
    /// requirement. 24 h at 4 records/s is 345 600 intervals and therefore 345 601 records:
    /// n records span n-1 intervals, and it is the span CH1-NFR-REL-0001 is about.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public void Ch1NfrRel0001_CapacityIsDerivedFromTheRetentionFloorAndTheFeedRate()
    {
        Assert.Equal(345_601, Options(Path("e.db")).TelemetryCapacity);
        Assert.Equal(172_801, Options(Path("e.db"), feedRate: 2d).TelemetryCapacity);
        Assert.Equal(TimeSpan.FromHours(24), EdgeBufferOptions.ControlledRetentionFloor);
    }

    // ---------------------------------------------------------------------------------
    // The eviction policy, in both directions.
    // ---------------------------------------------------------------------------------

    /// <summary>
    /// Telemetry gives way to telemetry, oldest first. The buffer never exceeds its
    /// capacity and never holds the wrong end of the history.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1NfrRel0001_TelemetryIsEvictedOldestFirstAtCapacity()
    {
        // A tiny capacity, reached by lowering the feed rate rather than the floor: the
        // 24-hour floor is the controlled part and must never be the thing a test relaxes.
        var options = Options(Path("evict.db"), feedRate: 4d / 86_400d, maximumBytes: 1024 * 1024);
        await using var buffer = await OpenAsync(options);
        Assert.Equal(5, buffer.TelemetryCapacity);

        var start = DateTimeOffset.UtcNow.AddHours(-1);
        for (var i = 0; i < 5; i++)
        {
            var admission = await AddAsync(buffer, EdgeRecordClass.Telemetry, start.AddMinutes(i));
            Assert.True(admission.Admitted);
            Assert.Equal(0, admission.EvictedTelemetry);
        }

        var overflow = await AddAsync(buffer, EdgeRecordClass.Telemetry, start.AddMinutes(5));

        Assert.True(overflow.Admitted);
        Assert.Equal(1, overflow.EvictedTelemetry);
        Assert.Equal(0, overflow.EvictedCritical);
        Assert.Equal("BUFFER_TELEMETRY_EVICTED", overflow.ReasonCode);

        var statistics = await buffer.StatisticsAsync(TestContext.Current.CancellationToken);
        Assert.Equal(5, statistics.TelemetryRecords);

        // The oldest went, not the newest. Stated as the record that is gone rather than
        // as a count, because a buffer that evicted the newest would report the same count.
        var held = await buffer.PeekAsync(16, TestContext.Current.CancellationToken);
        Assert.Equal(start.AddMinutes(1), held[0].OccurredAt);
        Assert.Equal(start.AddMinutes(5), held[^1].OccurredAt);
    }

    /// <summary>
    /// <b>The requirement itself.</b> "Without overwriting newer critical events": under
    /// telemetry pressure far past capacity, every critical event is still there.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1NfrRel0001_NoCriticalEventIsEvictedByTelemetryPressure()
    {
        var options = Options(Path("critical.db"), feedRate: 4d / 86_400d, headroom: 8, maximumBytes: 1024 * 1024);
        await using var buffer = await OpenAsync(options);

        var start = DateTimeOffset.UtcNow.AddHours(-2);
        for (var i = 0; i < 5; i++)
        {
            await AddAsync(buffer, EdgeRecordClass.CriticalEvent, start.AddMinutes(i));
        }

        // Fifty times the telemetry capacity, which is what an outage does.
        for (var i = 0; i < 200; i++)
        {
            await AddAsync(buffer, EdgeRecordClass.Telemetry, start.AddMinutes(10 + i));
        }

        var statistics = await buffer.StatisticsAsync(TestContext.Current.CancellationToken);

        Assert.Equal(5, statistics.CriticalRecords);
        Assert.Equal(5, statistics.TelemetryRecords);

        var held = await buffer.PeekAsync(64, TestContext.Current.CancellationToken);
        Assert.Equal(5, held.Count(record => record.Class == EdgeRecordClass.CriticalEvent));
    }

    /// <summary>
    /// The buffer holding nothing but critical events refuses new telemetry rather than
    /// admitting it at the cost of evidence.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1NfrRel0001_TelemetryIsRefusedRatherThanEvictingEvidence()
    {
        // A buffer holding nothing but critical events and no room for anything else is
        // reached through the byte bound: the record capacity governs telemetry alone, so
        // it can never be the thing that leaves no telemetry to evict. The bound is set to
        // exactly what the startup check requires, and the four critical events fill it.
        var options = Options(Path("refuse.db"), feedRate: 1d / 86_400d, headroom: 4, maximumBytes: 1536);
        await using var buffer = await OpenAsync(options);
        Assert.Equal(1536, options.RequiredBytes);

        var start = DateTimeOffset.UtcNow.AddHours(-1);
        for (var i = 0; i < 4; i++)
        {
            Assert.True((await AddAsync(buffer, EdgeRecordClass.CriticalEvent, start.AddMinutes(i), 384)).Admitted);
        }

        var refused = await AddAsync(buffer, EdgeRecordClass.Telemetry, start.AddMinutes(10), 48);

        Assert.False(refused.Admitted);
        Assert.Equal("BUFFER_BYTE_BOUND_EXHAUSTED", refused.ReasonCode);
        Assert.Equal(0, refused.EvictedCritical);

        var statistics = await buffer.StatisticsAsync(TestContext.Current.CancellationToken);
        Assert.Equal(4, statistics.CriticalRecords);
        Assert.Equal(0, statistics.TelemetryRecords);
    }

    /// <summary>
    /// Only a newer critical event may displace an older one — "preserving newest critical
    /// events according to policy" — and the buffer says so rather than losing it quietly.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1ComPro0001_OnlyANewerCriticalEventDisplacesAnOlderOne()
    {
        var options = Options(Path("newest.db"), feedRate: 4d / 86_400d, headroom: 3, maximumBytes: 1024 * 1024);
        await using var buffer = await OpenAsync(options);

        var start = DateTimeOffset.UtcNow.AddHours(-1);
        for (var i = 0; i < 3; i++)
        {
            await AddAsync(buffer, EdgeRecordClass.CriticalEvent, start.AddMinutes(i));
        }

        var displacing = await AddAsync(buffer, EdgeRecordClass.CriticalEvent, start.AddMinutes(3));

        Assert.True(displacing.Admitted);
        Assert.Equal(1, displacing.EvictedCritical);
        Assert.Equal("BUFFER_CRITICAL_EVIDENCE_EVICTED", displacing.ReasonCode);

        var held = await buffer.PeekAsync(16, TestContext.Current.CancellationToken);
        Assert.Equal(3, held.Count);
        Assert.Equal(start.AddMinutes(1), held[0].OccurredAt);
        Assert.Equal(start.AddMinutes(3), held[^1].OccurredAt);
    }

    /// <summary>
    /// CH1-COM-PRO-0001 caps disk, and the cap is enforced while running rather than only
    /// checked at startup: the startup check uses a nominal per-record size, and a
    /// deployment whose readings are larger than nominal would otherwise pass validation
    /// and then grow past its allowance.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1ComPro0001_TheByteBoundIsEnforcedWhileRunning()
    {
        var options = Options(Path("bytes.db"), feedRate: 4d / 86_400d, headroom: 4, maximumBytes: 4096);
        await using var buffer = await OpenAsync(options);

        var start = DateTimeOffset.UtcNow.AddHours(-1);
        for (var i = 0; i < 40; i++)
        {
            await AddAsync(buffer, EdgeRecordClass.Telemetry, start.AddMinutes(i), 1024);
        }

        var statistics = await buffer.StatisticsAsync(TestContext.Current.CancellationToken);

        Assert.True(
            statistics.Bytes <= options.MaximumBytes,
            $"The buffer holds {statistics.Bytes} bytes against a {options.MaximumBytes} byte bound.");
    }

    // ---------------------------------------------------------------------------------
    // Order, survival, and the shape that cannot carry a command.
    // ---------------------------------------------------------------------------------

    /// <summary>
    /// One order across both classes. CH1-VVT-TC-0026 requires recovery <em>in order</em>,
    /// and a critical event that jumped the queue would arrive before readings that
    /// preceded it — a different history from the one that happened.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0026")]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1ComFr0007_RecordsAreOfferedInOneOrderAcrossBothClasses()
    {
        await using var buffer = await OpenAsync(Options(Path("order.db")));

        var start = DateTimeOffset.UtcNow.AddHours(-1);
        var classes = new[]
        {
            EdgeRecordClass.Telemetry,
            EdgeRecordClass.Telemetry,
            EdgeRecordClass.CriticalEvent,
            EdgeRecordClass.Telemetry,
            EdgeRecordClass.CriticalEvent,
            EdgeRecordClass.Telemetry,
        };

        for (var i = 0; i < classes.Length; i++)
        {
            await AddAsync(buffer, classes[i], start.AddMinutes(i));
        }

        var held = await buffer.PeekAsync(64, TestContext.Current.CancellationToken);

        Assert.Equal(classes, held.Select(record => record.Class));
        Assert.Equal(
            Enumerable.Range(0, classes.Length).Select(i => start.AddMinutes(i)),
            held.Select(record => record.OccurredAt));
    }

    /// <summary>
    /// A record leaves the buffer only once it has been answered for, so a drain that
    /// removes part of a batch leaves the rest — in order — for the next attempt.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0026")]
    public async Task Ch1ComFr0007_RemovingTheAnsweredRecordsLeavesTheRestInOrder()
    {
        await using var buffer = await OpenAsync(Options(Path("remove.db")));

        var start = DateTimeOffset.UtcNow.AddHours(-1);
        for (var i = 0; i < 6; i++)
        {
            await AddAsync(buffer, EdgeRecordClass.Telemetry, start.AddMinutes(i));
        }

        var first = await buffer.PeekAsync(3, TestContext.Current.CancellationToken);
        await buffer.RemoveAsync(
            [.. first.Select(record => record.Sequence)], TestContext.Current.CancellationToken);

        var remaining = await buffer.PeekAsync(64, TestContext.Current.CancellationToken);

        Assert.Equal(3, remaining.Count);
        Assert.Equal(start.AddMinutes(3), remaining[0].OccurredAt);
        Assert.Equal(start.AddMinutes(5), remaining[^1].OccurredAt);
    }

    /// <summary>
    /// <b>The reason the buffer is on disk.</b> An outage long enough to need 24 hours of
    /// buffering is long enough to include a restart, and an in-memory queue survives none.
    /// The payload is compared byte for byte, because a replay must carry the original
    /// message identifier for the ingress to recognise it as a duplicate.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    [VerificationCase("CH1-VVT-TC-0026")]
    public async Task Ch1NfrRel0001_TheBufferSurvivesTheProcessThatWroteIt()
    {
        var options = Options(Path("restart.db"));
        var start = DateTimeOffset.UtcNow.AddHours(-3);
        var payload = new byte[] { 9, 8, 7, 6, 5 };

        await using (var first = await OpenAsync(options))
        {
            await first.EnqueueAsync(
                EdgeRecordClass.Telemetry, "Telemetry", "CH1-DEV-CELL-0001", start, payload,
                TestContext.Current.CancellationToken);
            await first.EnqueueAsync(
                EdgeRecordClass.CriticalEvent, "ControllerEvent", "CH1-DEV-CELL-0001", start.AddMinutes(1), payload,
                TestContext.Current.CancellationToken);
        }

        await using var reopened = await OpenAsync(options);
        var held = await reopened.PeekAsync(64, TestContext.Current.CancellationToken);

        Assert.Equal(2, held.Count);
        Assert.Equal(EdgeRecordClass.Telemetry, held[0].Class);
        Assert.Equal(EdgeRecordClass.CriticalEvent, held[1].Class);
        Assert.Equal(payload, held[0].Payload);
        Assert.Equal(start, held[0].OccurredAt);
    }

    /// <summary>
    /// <b>The 24 hours, measured rather than claimed.</b> The buffer is filled to its own
    /// derived capacity with back-dated records at the configured rate, and the span it
    /// actually retains is read back from the records. A buffer sized for 24 hours that was
    /// silently dropping at six would report the same capacity and a very different span.
    /// </summary>
    /// <remarks>
    /// The rate here is one record per twenty seconds, which is close to what this gateway
    /// really produces: telemetry is enqueued as one batched publication per device every
    /// five seconds, not one record per reading. The full-rate fill — 345 600 records at
    /// 4/s — belongs to <c>scripts/check-gateway-buffer.sh</c>, where it is not paying for
    /// a per-commit fsync on a developer workstation.
    /// </remarks>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0093")]
    public async Task Ch1NfrRel0001_AFullBufferRetainsAtLeastTwentyFourHours()
    {
        var options = Options(Path("twentyfour.db"), feedRate: 1d / 20d, maximumBytes: 64L * 1024 * 1024);
        await using var buffer = await OpenAsync(options);
        Assert.Equal(4_321, buffer.TelemetryCapacity);

        // Back-dated at exactly the configured rate, so the span the records describe is
        // the span the capacity is supposed to buy.
        var newest = DateTimeOffset.UtcNow;
        var oldest = newest - TimeSpan.FromSeconds(20 * (options.TelemetryCapacity - 1));
        for (var i = 0; i < options.TelemetryCapacity; i++)
        {
            await AddAsync(buffer, EdgeRecordClass.Telemetry, oldest.AddSeconds(20 * i));
        }

        var statistics = await buffer.StatisticsAsync(TestContext.Current.CancellationToken);

        Assert.Equal(options.TelemetryCapacity, statistics.TelemetryRecords);
        Assert.True(
            statistics.RetainedSpan >= EdgeBufferOptions.ControlledRetentionFloor,
            $"CH1-NFR-REL-0001 requires at least 24 h; a full buffer retained {statistics.RetainedSpan}.");
    }

    /// <summary>
    /// CH1-SYS-CON-0001: "Telemetry may buffer, but commands are not stored for future
    /// execution." That is enforced by the shape of the interface rather than by a check
    /// inside it — there are two record classes and neither is a command, so there is no
    /// call a future caller could make. Asserted so that adding a third is a failing test
    /// rather than a quiet widening.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0026")]
    public void Ch1SysCon0001_TheBufferHasNoRecordClassThatCouldCarryACommand()
    {
        var classes = Enum.GetNames<EdgeRecordClass>();

        Assert.Equal(["Telemetry", "CriticalEvent"], classes);
        Assert.DoesNotContain(
            typeof(IEdgeBuffer).GetMethods(),
            method => method.Name.Contains("Command", StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// The native SQLite the buffer actually loaded, asserted rather than inferred from a
    /// package version. GHSA-2m69-gcr7-jv3q / CVE-2025-6965 is a memory-corruption defect
    /// in SQLite before 3.50.2, and <c>Directory.Packages.props</c> pins the SQLitePCLRaw
    /// family past it. A pin is a claim about resolution; this is a measurement of what is
    /// in the process.
    /// </summary>
    [Fact]
    public async Task TheLoadedSqliteIsPastTheControlledAdvisory()
    {
        await using var buffer = await OpenAsync(Options(Path("version.db")));
        await using var connection = new SqliteConnection($"Data Source={Path("version.db")}");
        await connection.OpenAsync(TestContext.Current.CancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT sqlite_version();";
        var reported = (string)(await command.ExecuteScalarAsync(TestContext.Current.CancellationToken))!;

        Assert.True(
            Version.Parse(reported) >= new Version(3, 50, 2),
            $"SQLite {reported} is inside GHSA-2m69-gcr7-jv3q (CVE-2025-6965), which is fixed in 3.50.2.");
    }

    public void Dispose()
    {
        try
        {
            Directory.Delete(_directory, recursive: true);
        }
        catch (IOException)
        {
            // A temporary directory that outlives one test run is not a test failure.
        }
    }
}
