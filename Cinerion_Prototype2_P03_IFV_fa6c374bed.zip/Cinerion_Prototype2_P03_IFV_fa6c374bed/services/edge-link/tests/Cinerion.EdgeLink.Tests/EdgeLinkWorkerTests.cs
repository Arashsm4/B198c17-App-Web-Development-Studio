// Tests that the gateway refuses to start when an adapter fails conformance.

using System.Runtime.CompilerServices;
using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Protocols;
using Cinerion.EdgeLink.Runtime;
using Microsoft.Extensions.Logging.Abstractions;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// The startup gate: EdgeLink runs the conformance suites against whatever this
/// deployment registered, and refuses to serve anything that fails.
/// </summary>
/// <remarks>
/// Conformance evidence produced only in a test assembly says nothing about the adapter a
/// running gateway was configured with, which may be a different one. The check that
/// matters is therefore in the worker, and the check that the check works is here: a
/// provider that quietly alters the bytes it carries must stop the gateway, not be logged
/// and served anyway.
/// </remarks>
/// <requirements>CH1-COM-FR-0002, CH1-COM-FR-0005, CH1-NFR-REL-0001</requirements>
public sealed class EdgeLinkWorkerTests
{
    [Fact]
    [VerificationCase("CH1-VVT-TC-0024")]
    public async Task Ch1ComFr0005_AConformantDeploymentStartsAndReportsEveryCheck()
    {
        using var worker = new EdgeLinkWorker(
            [new SimulatorProtocolAdapter()],
            [new LoopbackTransportProvider(), new FramedSerialTransportProvider()],
            new EdgeLinkWorkerOptions(MeasureAcknowledgementLatency: false),
            NullLogger<EdgeLinkWorker>.Instance);
        using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(45));

        // The worker waits for ever once it is up, so still running after the suites have
        // had time to complete is the pass. ExecuteTask is where a conformance failure
        // surfaces; StartAsync returns as soon as the worker first yields.
        await worker.StartAsync(cancellation.Token);
        await Task.Delay(TimeSpan.FromSeconds(3), TestContext.Current.CancellationToken);

        Assert.NotNull(worker.ExecuteTask);
        Assert.False(worker.ExecuteTask!.IsFaulted, worker.ExecuteTask.Exception?.Message);
        Assert.False(worker.ExecuteTask.IsCompleted);
        await cancellation.CancelAsync();
    }

    /// <summary>
    /// A provider that alters the message it carries is exactly the failure the boundary
    /// exists to prevent, and it is invisible to every other check in this repository.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0024")]
    public async Task Ch1ComFr0005_AProviderThatAltersTheMessageStopsTheGateway()
    {
        using var worker = new EdgeLinkWorker(
            [new SimulatorProtocolAdapter()],
            [new CorruptingTransportProvider()],
            new EdgeLinkWorkerOptions(MeasureAcknowledgementLatency: false),
            NullLogger<EdgeLinkWorker>.Instance);
        using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(45));

        await worker.StartAsync(cancellation.Token);
        var failure = await Assert.ThrowsAsync<InvalidOperationException>(() => worker.ExecuteTask!);

        Assert.Contains("failed conformance", failure.Message, StringComparison.Ordinal);
        Assert.Contains("TRN-02-ROUND-TRIP", failure.Message, StringComparison.Ordinal);
        Assert.Contains("ALTERED", failure.Message, StringComparison.Ordinal);
    }

    /// <summary>
    /// An adapter that acknowledges an expired command would have the domain believe a
    /// controller had accepted work it will never do.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public async Task Ch1ComFr0002_AnAdapterThatAcceptsAnExpiredCommandStopsTheGateway()
    {
        using var worker = new EdgeLinkWorker(
            [new PermissiveProtocolAdapter()],
            [new LoopbackTransportProvider()],
            new EdgeLinkWorkerOptions(MeasureAcknowledgementLatency: false),
            NullLogger<EdgeLinkWorker>.Instance);
        using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(45));

        await worker.StartAsync(cancellation.Token);
        var failure = await Assert.ThrowsAsync<InvalidOperationException>(() => worker.ExecuteTask!);

        Assert.Contains("ADP-05-EXPIRED-REFUSED", failure.Message, StringComparison.Ordinal);
    }

    /// <summary>Carries messages, but flips one bit on the way through.</summary>
    private sealed class CorruptingTransportProvider : ITransportProvider
    {
        private readonly System.Threading.Channels.Channel<byte[]> _wire =
            System.Threading.Channels.Channel.CreateUnbounded<byte[]>();

        public string ProviderId => "CH1-TRN-CORRUPTING-0001";

        public ValueTask SendAsync(ReadOnlyMemory<byte> versionedEnvelope, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var copy = versionedEnvelope.ToArray();
            if (copy.Length > 0)
            {
                copy[^1] ^= 0x01;
            }

            _wire.Writer.TryWrite(copy);
            return ValueTask.CompletedTask;
        }

        public IAsyncEnumerable<ReadOnlyMemory<byte>> ReceiveAsync(CancellationToken cancellationToken) =>
            Read(cancellationToken);

        private async IAsyncEnumerable<ReadOnlyMemory<byte>> Read(
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            await foreach (var item in _wire.Reader.ReadAllAsync(cancellationToken).ConfigureAwait(false))
            {
                yield return item;
            }
        }
    }

    /// <summary>Answers yes to everything, which is the one thing an adapter must not do.</summary>
    private sealed class PermissiveProtocolAdapter : IProtocolAdapter
    {
        public string AdapterId => "CH1-ADP-PERMISSIVE-0001";

        public string Protocol => "PERMISSIVE";

        public ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken) =>
            ValueTask.FromResult(new DeviceCapabilityManifest(
                "1.0.0", "CH1-DEV-PERMISSIVE-0001", "Test", "0.0.0", "CFG-TEST",
                ["RUN_ANYTHING"], [new CapabilityChannel("temperature", "degC")],
                [new ProtocolEndpoint("PERMISSIVE", "1.0.0")], "TEST-ONLY"));

        public ValueTask<AdapterAcknowledgement> PrepareAsync(
            SemanticCommandEnvelope command,
            CancellationToken cancellationToken) =>
            ValueTask.FromResult(new AdapterAcknowledgement(
                command.CommandId, true, "AwaitingCredential", "ACCEPTED", DateTimeOffset.UtcNow, AdapterId));

        public async IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            await Task.CompletedTask.ConfigureAwait(false);
            cancellationToken.ThrowIfCancellationRequested();
            yield break;
        }

        public ValueTask ReconcileAsync(CancellationToken cancellationToken) => ValueTask.CompletedTask;
    }
}
