// Tests for what the gateway may claim about a clock it doesn't own. Mostly: less than you'd
// hope.

using Microsoft.Extensions.Configuration;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Cinerion.Contracts.EdgeLink.V1;
using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Ingress;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// What the gateway may say about a clock it does not own.
/// </summary>
/// <remarks>
/// <para>
/// <c>ControlCoreIngressClient.NewEnvelope</c> set <c>TimeQuality.Qualified</c> on every
/// message it sent, unconditionally, and the MQTT adapter decoded the device's own
/// <c>timeQuality</c> and threw it away. A controller honestly reporting
/// <c>Unsynchronised</c> — which, since defect 58, is what a controller with no disciplined
/// clock reports — therefore arrived at Control Core looking exactly like one that had been
/// disciplined, with its <c>sampled_at</c> stored as though it were trustworthy.
/// </para>
/// <para>
/// CH1-COM-ICD-0001 is explicit about why that matters: "Clock offset and time quality are
/// observable so audit and TOTP decisions are not silently made on invalid time." An
/// unconditional assertion is the opposite of observable. Recorded as defect 59 and
/// conflict 27, and resolved the way the same document prescribes — "Contracts use additive
/// evolution within a supported major version" — by giving the publication a field for the
/// source's own declaration rather than by taking the worse of two figures and losing both.
/// </para>
/// <para>
/// Every assertion here is about a REFUSAL to improve on what the gateway was told. The
/// mapping under-claims in every direction and nothing reaches <c>Trusted</c>: no clock in
/// this deployment is traceable to an attested source, so nothing may claim to be.
/// </para>
/// </remarks>
/// <requirements>CH1-COM-ICD-0001, CH1-COM-FR-0009, CH1-COM-IF-0003</requirements>
public sealed class SourceTimeQualityTests
{
    [Theory]
    // The firmware's own vocabulary — conditioned_io.hpp — which is what a CH1 device
    // actually puts in the envelope.
    [InlineData("Unsynchronised", TimeQuality.Unknown)]
    [InlineData("Stale", TimeQuality.Unknown)]
    [InlineData("Holdover", TimeQuality.Degraded)]
    [InlineData("Synchronised", TimeQuality.Qualified)]
    public void DeviceDeclarationIsCarried(string declared, TimeQuality expected) =>
        Assert.Equal(expected, ControlCoreIngressClient.MapTimeQuality(declared));

    [Fact]
    public void UndisciplinedIsNeverReadAsQualified()
    {
        // The defect in one line: this is the value the gateway used to send for a
        // controller in exactly this state.
        Assert.NotEqual(TimeQuality.Qualified, ControlCoreIngressClient.MapTimeQuality("Unsynchronised"));
        Assert.NotEqual(TimeQuality.Trusted, ControlCoreIngressClient.MapTimeQuality("Unsynchronised"));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("probably fine")]
    public void SilenceIsUnspecifiedRatherThanADefault(string? declared)
    {
        // Not Qualified, and not Unknown either: "the source said nothing" and "the source
        // said its clock is unusable" are different facts, and Control Core stores the
        // first as nothing rather than inventing the second.
        Assert.Equal(TimeQuality.Unspecified, ControlCoreIngressClient.MapTimeQuality(declared));
    }

    [Fact]
    public void NothingReachesTrusted()
    {
        // Trusted would mean a clock traceable to an attested source. Nothing in this
        // deployment has one — not the gateway, not the node, not the PLC — so no input
        // to this mapping may produce it. A future deployment that genuinely has one
        // declares it, and this test is the thing that has to be revised deliberately.
        string[] everything =
        [
            "Unsynchronised", "Unsynchronized", "Stale", "Holdover", "Degraded",
            "Synchronised", "Synchronized", "Qualified", "Unknown", "", "anything else",
        ];

        Assert.DoesNotContain(
            everything.Select(ControlCoreIngressClient.MapTimeQuality),
            quality => quality == TimeQuality.Trusted);
    }

    [Fact]
    public void GatewayDeclarationDefaultsToUnknownRatherThanQualified()
    {
        // The gateway's own clock, read from configuration rather than asserted. An
        // unconfigured deployment under-claims; the previous behaviour was to claim
        // Qualified with nothing at all behind it.
        var unset = ControlCoreIngressOptions.FromConfiguration(
            Configuration(new Dictionary<string, string?>(StringComparer.Ordinal)));
        Assert.Null(unset); // an unconfigured gateway publishes nothing at all

        var configured = Options(null);
        Assert.Equal("Unknown", configured.GatewayTimeQuality);
        Assert.Equal(TimeQuality.Unknown, ControlCoreIngressClient.MapTimeQuality(configured.GatewayTimeQuality));
    }

    [Fact]
    public void GatewayDeclarationIsHonouredWhenTheDeploymentStatesOne()
    {
        Assert.Equal("Qualified", Options("Qualified").GatewayTimeQuality);
        Assert.Equal("Trusted", Options("Trusted").GatewayTimeQuality);
        // And a value the contract does not contain is refused rather than passed through
        // as a string nobody downstream would recognise.
        Assert.Equal("Unknown", Options("excellent").GatewayTimeQuality);
    }

    [Fact]
    public void AGatewayStampedSampleIsDistinguishableFromASilentDevice()
    {
        // The two are not the same fact and must not collapse into one another. A Modbus
        // register read is stamped by this gateway and says so; an MQTT device that sent
        // no timeQuality has declared nothing, and nothing is what is stored.
        var stamped = new TelemetryPoint(
            "CH1-DEV-CELL-0001", "temperature", 22.4, "degC", "Good",
            DateTimeOffset.UnixEpoch, 1, TelemetryPoint.GatewayStamped);
        var silent = new TelemetryPoint(
            "CH1-DEV-CELL-0001", "temperature", 22.4, "degC", "Good",
            DateTimeOffset.UnixEpoch, 1);

        Assert.NotEqual(stamped.SourceTimeQuality, silent.SourceTimeQuality);
        Assert.Null(silent.SourceTimeQuality);
        // The sentinel is resolved at the ingress boundary and is never itself a quality.
        Assert.Equal(TimeQuality.Unspecified, ControlCoreIngressClient.MapTimeQuality(TelemetryPoint.GatewayStamped));
    }

    private static ControlCoreIngressOptions Options(string? declaredTimeQuality)
    {
        var material = KeyMaterial.Value;
        var settings = new Dictionary<string, string?>(StringComparer.Ordinal)
        {
            ["CINERION_EDGE_GRPC_ENDPOINT"] = "https://control-core:5443",
            ["CINERION_EDGE_GRPC_CA_CERT"] = material.CertificatePath,
            ["CINERION_EDGE_GRPC_CLIENT_CERT"] = material.CertificatePath,
            ["CINERION_EDGE_GRPC_CLIENT_KEY"] = material.KeyPath,
            ["CINERION_EDGE_GRPC_GATEWAY_IDENTITY"] = "CH1-GW-EDGE-0001",
            ["CINERION_EDGE_GRPC_PROJECT_ID"] = Guid.Empty.ToString(),
            ["CINERION_EDGE_GRPC_CELL_ID"] = Guid.Empty.ToString(),
        };
        if (declaredTimeQuality is not null)
        {
            settings["CINERION_EDGE_GATEWAY_TIME_QUALITY"] = declaredTimeQuality;
        }

        return ControlCoreIngressOptions.FromConfiguration(Configuration(settings))!;
    }

    private static IConfiguration Configuration(IReadOnlyDictionary<string, string?> settings) =>
        new ConfigurationBuilder().AddInMemoryCollection(settings).Build();

    /// <summary>
    /// A throwaway key pair on disk, because <see cref="ControlCoreIngressOptions"/> loads
    /// its certificates while reading configuration and there is no configuration without
    /// them. Nothing here is trusted by anything: these tests never open a channel.
    /// </summary>
    private sealed record TestKeyMaterial(string CertificatePath, string KeyPath);

    private static readonly Lazy<TestKeyMaterial> KeyMaterial = new(() =>
    {
        var directory = Directory.CreateTempSubdirectory("cinerion-time-quality").FullName;
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest("CN=CH1-GW-EDGE-0001", key, HashAlgorithmName.SHA256);
        using var certificate = request.CreateSelfSigned(
            DateTimeOffset.UtcNow.AddMinutes(-5), DateTimeOffset.UtcNow.AddMinutes(5));

        var certificatePath = Path.Combine(directory, "gateway.crt");
        var keyPath = Path.Combine(directory, "gateway.key");
        File.WriteAllText(certificatePath, certificate.ExportCertificatePem());
        File.WriteAllText(keyPath, key.ExportPkcs8PrivateKeyPem());
        return new TestKeyMaterial(certificatePath, keyPath);
    });
}
