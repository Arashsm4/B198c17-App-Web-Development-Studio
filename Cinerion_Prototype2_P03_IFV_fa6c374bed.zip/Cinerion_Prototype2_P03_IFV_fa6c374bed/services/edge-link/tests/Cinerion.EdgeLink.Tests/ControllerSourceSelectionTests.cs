// Tests what happens when two adapters claim the same cell. Spoiler: neither wins.

using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Protocols;
using Cinerion.EdgeLink.Runtime;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// One cell has one controller, and what happens when two adapters claim it.
/// </summary>
/// <remarks>
/// <para>
/// Written <b>before</b> a second controller-state source exists, which is the point. The
/// envelope carries a single configured <c>CellId</c>, so every controller-state source in
/// a gateway publishes into the same cell. Adding a second one — the natural next increment
/// on this edge — would have made a deployment holding both publish alternating reports
/// every two seconds: the simulator saying the permissives are answered and healthy, a
/// Modbus zone saying they were never answered. Each is newer than the last, so
/// <c>CellRuntimeProjection</c> accepts both and the cell flaps between permissive and not
/// permissive.
/// </para>
/// <para>
/// A cell whose interlocks alternate is one no operator and no command check can rely on.
/// These tests fix the resolution as <b>refuse rather than guess</b>, so the second source
/// can be added without introducing the defect.
/// </para>
/// </remarks>
/// <requirements>CH1-SAF-FR-0003, CH1-MON-FR-0003, CH1-COM-IF-0003</requirements>
public sealed class ControllerSourceSelectionTests
{
    /// <summary>An adapter that can speak for a controller. Only its identity matters here.</summary>
    private sealed class SpeakingAdapter(string adapterId) : IProtocolAdapter, IControllerStateSource
    {
        public string AdapterId => adapterId;

        public string Protocol => "TEST";

        public ValueTask<ControllerStateObservation> ReadControllerStateAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException("Selection is decided before any controller is read.");

        public ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public ValueTask<AdapterAcknowledgement> PrepareAsync(
            SemanticCommandEnvelope command, CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public ValueTask ReconcileAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException();
    }

    /// <summary>An adapter that cannot. It must never be selected, and must not create ambiguity.</summary>
    private sealed class SilentAdapter(string adapterId) : IProtocolAdapter
    {
        public string AdapterId => adapterId;

        public string Protocol => "TEST";

        public ValueTask<DeviceCapabilityManifest> ReadCapabilityAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public ValueTask<AdapterAcknowledgement> PrepareAsync(
            SemanticCommandEnvelope command, CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public IAsyncEnumerable<TelemetryPoint> ReadTelemetryAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public ValueTask ReconcileAsync(CancellationToken cancellationToken) =>
            throw new NotSupportedException();
    }

    /// <summary>Today's deployment, unchanged: one source, selected, no configuration needed.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void TheOnlyControllerStateSourceIsSelectedWithoutConfiguration()
    {
        var simulator = new SpeakingAdapter("CH1-ADP-SIM-0001");

        var selection = IngressPublisher.SelectControllerStateSource(
            [simulator, new SilentAdapter("CH1-ADP-MQTT-0001")], configuredAdapterId: null);

        Assert.Same(simulator, selection.Source);
    }

    /// <summary>
    /// <b>The property this whole guard exists for.</b> Two sources and no explicit choice
    /// resolves to <em>no controller state at all</em>, so the cell reads as not permissive
    /// rather than alternating between two controllers' answers.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void Ch1SafFr0003_TwoSourcesWithNoExplicitChoiceProduceNoControllerStateAtAll()
    {
        var selection = IngressPublisher.SelectControllerStateSource(
            [new SpeakingAdapter("CH1-ADP-SIM-0001"), new SpeakingAdapter("CH1-ADP-MODBUS-0001")],
            configuredAdapterId: null);

        Assert.Null(selection.Source);

        // The refusal has to be actionable: it names both claimants and the setting that
        // resolves them, because "no controller state" with no reason is indistinguishable
        // from a gateway that is simply broken.
        Assert.Contains("CH1-ADP-MODBUS-0001", selection.Reason, StringComparison.Ordinal);
        Assert.Contains("CH1-ADP-SIM-0001", selection.Reason, StringComparison.Ordinal);
        Assert.Contains("CINERION_EDGE_CONTROLLER_ADAPTER", selection.Reason, StringComparison.Ordinal);
    }

    /// <summary>Naming one resolves it, and the named one is the one selected.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void NamingOneAdapterResolvesTheAmbiguity()
    {
        var modbus = new SpeakingAdapter("CH1-ADP-MODBUS-0001");

        var selection = IngressPublisher.SelectControllerStateSource(
            [new SpeakingAdapter("CH1-ADP-SIM-0001"), modbus], "CH1-ADP-MODBUS-0001");

        Assert.Same(modbus, selection.Source);
    }

    /// <summary>
    /// A name that matches nothing selects nothing. Falling back to "the only other one"
    /// would silently publish a different controller's permissives than the deployment
    /// asked for, which is the failure this refuses to make convenient.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void AConfiguredAdapterThatIsNotRegisteredSelectsNothingRatherThanSomethingElse()
    {
        var selection = IngressPublisher.SelectControllerStateSource(
            [new SpeakingAdapter("CH1-ADP-SIM-0001")], "CH1-ADP-OPCUA-0001");

        Assert.Null(selection.Source);
        Assert.Contains("CH1-ADP-OPCUA-0001", selection.Reason, StringComparison.Ordinal);
    }

    /// <summary>An adapter that cannot read a controller never counts towards ambiguity.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void AdaptersThatCannotReadAControllerAreNotClaimants()
    {
        var selection = IngressPublisher.SelectControllerStateSource(
            [
                new SilentAdapter("CH1-ADP-MQTT-0001"),
                new SpeakingAdapter("CH1-ADP-SIM-0001"),
                new SilentAdapter("CH1-ADP-MODBUS-0001"),
            ],
            configuredAdapterId: null);

        Assert.NotNull(selection.Source);
        Assert.Equal("CH1-ADP-SIM-0001", ((IProtocolAdapter)selection.Source!).AdapterId);
    }

    /// <summary>No source at all is the same safe outcome, and says so.</summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public void NoSourceAtAllIsTheSameSafeOutcome()
    {
        var selection = IngressPublisher.SelectControllerStateSource([], configuredAdapterId: null);

        Assert.Null(selection.Source);
        Assert.Contains("not permissive", selection.Reason, StringComparison.Ordinal);
    }
}
