// Tests for the Modbus map's rules and the fail-closed config decision.

using Cinerion.EdgeLink.Protocols;
using Microsoft.Extensions.Configuration;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// The controlled Modbus map's own invariants, and the fail-closed configuration decision.
/// </summary>
/// <remarks>
/// The live behaviour of this adapter needs a real Modbus server and is exercised by
/// <c>scripts/check-modbus-edge.sh</c>. What belongs here is what can be decided without
/// one: whether the gateway registers a live adapter at all, and whether the map it holds
/// still says what it is supposed to say. The second matters more than it looks — every
/// security argument on this edge rests on where in the map a register sits.
/// </remarks>
/// <requirements>CH1-COM-IF-0008, CH1-COM-PRO-0001, CH1-CYB-TMD-0001, CH1-COM-FR-0002</requirements>
public sealed class ModbusEdgeTests
{
    /// <summary>
    /// An unset host leaves the edge unconfigured, so the gateway registers the gated
    /// adapter — the same fail-closed direction the other three edges take.
    /// </summary>
    [Fact]
    public void Ch1ComIf0008_AnUnconfiguredEdgeIsNotConfiguredAtAll()
    {
        var options = ModbusAdapterOptions.FromConfiguration(
            new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>()).Build());

        Assert.Null(options);
    }

    [Fact]
    public void Ch1ComIf0008_AConfiguredEdgeIsAcceptedWithControlledDefaults()
    {
        var options = ModbusAdapterOptions.FromConfiguration(
            new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?> { ["CINERION_MODBUS_HOST"] = "modbus-plc" })
                .Build());

        Assert.NotNull(options);
        Assert.Equal("modbus-plc", options.Host);
        Assert.Equal(502, options.Port);
        Assert.Equal(Ch1ModbusMap.UnitIdentifier, options.UnitIdentifier);
        Assert.True(options.ExchangeTimeout > TimeSpan.Zero);
    }

    /// <summary>
    /// The three bands CH1-COM-PRO-0001 requires the map to separate do not overlap.
    /// A register belonging to two bands is a register whose access rules depend on which
    /// check ran first.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0022")]
    public void Ch1ComPro0001_TheMapSeparatesTelemetryConfigurationAndTheCommandHandshake()
    {
        // Input registers: telemetry below, the guard's answer above, no overlap.
        Assert.True(Ch1ModbusMap.TelemetrySampleCounter < Ch1ModbusMap.AnswerBandStart);
        Assert.True(Ch1ModbusMap.AnswerDeferredCheckSecond < Ch1ModbusMap.InputRegisterCount);

        // Holding registers: configuration below, the one writable window above, no overlap.
        Assert.True(Ch1ModbusMap.ConfigurationBandEnd < Ch1ModbusMap.HandshakeBandStart);
        Assert.True(Ch1ModbusMap.HandshakeTrigger <= Ch1ModbusMap.HandshakeBandEnd);
    }

    /// <summary>
    /// CH1-CYB-TMD-0001 names "direct Modbus write bypassing CommandGuard" as a priority
    /// threat case, and the answer is structural: the guard's outputs are input registers,
    /// which the protocol gives no function code to write. This asserts the structure rather
    /// than the argument, so moving one of them into the holding file fails here as well as
    /// in <c>scripts/check-modbus-map.mjs</c>.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0022")]
    public void Ch1CybTmd0001_TheGuardsOutputsAreNotInAWritableRegisterFile()
    {
        ushort[] answers =
        [
            Ch1ModbusMap.AnswerState,
            Ch1ModbusMap.AnswerReasonCode,
            Ch1ModbusMap.AnswerAccepted,
            Ch1ModbusMap.AnswerExecutePermit,
            Ch1ModbusMap.AnswerLastSequenceHigh,
            Ch1ModbusMap.AnswerLastSequenceLow,
            Ch1ModbusMap.AnswerCounter,
        ];

        Assert.All(answers, address =>
        {
            Assert.InRange(address, Ch1ModbusMap.AnswerBandStart, (ushort)(Ch1ModbusMap.InputRegisterCount - 1));
            // And nowhere near the only window a write function is permitted to reach.
            Assert.True(
                address < Ch1ModbusMap.HandshakeBandStart,
                $"register {address} sits inside the writable handshake window.");
        });
    }

    /// <summary>
    /// The gated Modbus adapter answers on the same identity as the live one, so an
    /// uncommissioned deployment is the same edge refusing rather than a different adapter.
    /// </summary>
    [Fact]
    public async Task Ch1ComFr0002_TheGatedAndLiveModbusAdaptersShareOneIdentity()
    {
        var gated = new ModbusGatedAdapter();

        Assert.Equal("CH1-ADP-MODBUS-0001", gated.AdapterId);
        Assert.Equal("MODBUS", gated.Protocol);

        var results = await AdapterConformance.RunGatedAsync(gated, TestContext.Current.CancellationToken);
        Assert.All(results, result => Assert.True(result.Passed, result.ToString()));
    }

    /// <summary>
    /// The text encoding both ends of the map use: ASCII, two characters per register, high
    /// byte first. A round trip here is the byte order the wire actually carries.
    /// </summary>
    [Fact]
    public void Ch1ComIf0008_ControlledTextRoundTripsInModbusRegisterOrder()
    {
        Span<ushort> registers = stackalloc ushort[Ch1ModbusMap.LongTextRegisters];
        Ch1ModbusEncoding.WriteText(registers, "CH1-DEV-CELL-0001");

        // 'C' is 0x43 and 'H' is 0x48: the first character occupies the high byte.
        Assert.Equal(0x4348, registers[0]);
        Assert.Equal("CH1-DEV-CELL-0001", Ch1ModbusEncoding.ReadText(registers));
    }
}
