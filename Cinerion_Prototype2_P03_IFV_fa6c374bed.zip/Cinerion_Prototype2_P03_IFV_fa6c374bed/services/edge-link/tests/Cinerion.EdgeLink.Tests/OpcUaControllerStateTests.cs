// Tests what the OPC UA adapter reports about the controller, and what it refuses to report.

using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Protocols;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// What the OPC UA adapter reports about the controller itself — and above all what it
/// refuses to report.
/// </summary>
/// <remarks>
/// <para>
/// The live half needs a running controller stand-in and is exercised by
/// <c>scripts/check-opcua-edge.sh</c>. What belongs here is the safety-relevant property,
/// which is a property of the decoding rather than of the wire: <b>this adapter can never
/// report an answered permissive</b>, whatever the address space contains. The stand-in
/// fronts the same FB_CH1_CommandGuard translation the Modbus zone does, and that guard
/// declares check 207 deferred because the real S7-1200 G2 reads
/// <c>UDT_CH1_Permissives</c> from wired inputs a stand-in has none of. A gateway that
/// produced an answered permissive would be inventing one.
/// </para>
/// <para>
/// The value of this adapter sourcing controller state at all is not that a cell becomes
/// permissive. It is that it becomes observably <i>not</i> permissive, end to end: before
/// it, a gateway in front of an OPC UA controller reported nothing about the controller,
/// and the "no controller has answered" path was reached by absence rather than by an
/// answer. Defect 47 was two screens rendering a cell as fully permissive because a
/// protobuf default read as a fact, which is the same mistake one layer up.
/// </para>
/// </remarks>
/// <requirements>CH1-SAF-FR-0003, CH1-MON-FR-0003, CH1-COM-IF-0003, CH1-COM-IF-0008</requirements>
public sealed class OpcUaControllerStateTests
{
    /// <summary>
    /// The seven values the adapter reads, in the order it reads them: DeviceId,
    /// ControllerBootId, ConfigurationRevision, SecurityProfile, FirmwareVersion,
    /// Handshake State, Handshake DeferredChecks.
    /// </summary>
    private static object?[] Values(
        string deviceId = "CH1-DEV-CELL-0001",
        string? bootId = "9f2a1c4e6b8d47f1a2c3d4e5f60718a9",
        ushort? state = 0,
        string[]? deferred = null) =>
    [
        deviceId,
        bootId,
        "CFG-REFAB-P01-R01",
        "OPCUA-SIGNANDENCRYPT-BASIC256SHA256-CERTIFICATE-TRUSTLIST",
        "S7-1200-G2-STANDIN/0.1.0-prototype.2",
        state,
        deferred ??
        [
            "206 EXPECTED_STATE_MISMATCH — decided by the CPU against CurrentStateHash32",
            "207 PRELIMINARY_PERMISSIVE_INVALID — decided by the CPU against UDT_CH1_Permissives",
        ],
    ];

    /// <summary>
    /// The property that matters most, asserted against every shape the address space could
    /// take - including one that has tried to claim the interlocks are healthy.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void Ch1SafFr0003_TheOpcUaAdapterNeverReportsAnAnsweredPermissive()
    {
        foreach (var deferred in new string[]?[]
                 {
                     null,
                     [],
                     ["999 SOMETHING_ELSE"],
                     ["206 EXPECTED_STATE_MISMATCH"],
                 })
        {
            var observation = OpcUaProtocolAdapter.BuildControllerState(
                Values(deferred: deferred!), DateTimeOffset.UnixEpoch);

            Assert.False(observation.Permissives.Reported);
            Assert.False(observation.Permissives.ControllerOnline);
            Assert.False(observation.Permissives.StartEnable);
            Assert.False(observation.Permissives.StopCircuitHealthy);
            Assert.False(observation.Permissives.GuardHealthy);
            Assert.False(observation.Permissives.ActuatorHome);
            Assert.False(observation.Permissives.ButtonPressed);
            Assert.False(observation.Permissives.FaultCauseActive);
        }
    }

    /// <summary>
    /// A reader needs to know WHY the permissives are unanswered, not merely that they are.
    /// 207 is stated whether or not the read carried it.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void Ch1MonFr0003_TheDeferredPermissiveCheckIsAlwaysNamed()
    {
        var silent = OpcUaProtocolAdapter.BuildControllerState(
            Values(deferred: []), DateTimeOffset.UnixEpoch);
        Assert.Contains(207u, silent.Permissives.DeferredCheckCodes);

        var stated = OpcUaProtocolAdapter.BuildControllerState(Values(), DateTimeOffset.UnixEpoch);
        Assert.Contains(207u, stated.Permissives.DeferredCheckCodes);
        Assert.Contains(206u, stated.Permissives.DeferredCheckCodes);

        // Named once, not twice, when the controller reported it itself.
        Assert.Single(stated.Permissives.DeferredCheckCodes, code => code == 207u);
    }

    /// <summary>
    /// The codes come from the guard's own lines rather than from a list held in the
    /// adapter, so a guard that deferred a further check is carried without anyone editing
    /// the gateway.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void DeferredChecksTheGuardReportedAreCarriedRatherThanFilteredToAKnownSet()
    {
        var observation = OpcUaProtocolAdapter.BuildControllerState(
            Values(deferred: ["301 A_CHECK_ADDED_LATER — decided by the CPU"]),
            DateTimeOffset.UnixEpoch);

        Assert.Contains(301u, observation.Permissives.DeferredCheckCodes);
        Assert.Contains(207u, observation.Permissives.DeferredCheckCodes);
    }

    /// <summary>
    /// A boot identity that will not parse is empty, never fresh. A random one would change
    /// on every read and void every prepared command on a healthy controller, which is the
    /// opposite of what CH1-CMD-FR-0009 asks it to do.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void Ch1CmdFr0009_TheBootIdentityIsStableAcrossReadsAndNeverInvented()
    {
        var first = OpcUaProtocolAdapter.BuildControllerState(Values(), DateTimeOffset.UnixEpoch);
        var second = OpcUaProtocolAdapter.BuildControllerState(Values(), DateTimeOffset.UnixEpoch.AddMinutes(5));
        Assert.Equal(first.ControllerBootId, second.ControllerBootId);
        Assert.NotEqual(Guid.Empty, first.ControllerBootId);

        var rebooted = OpcUaProtocolAdapter.BuildControllerState(
            Values(bootId: "0123456789abcdef0123456789abcdef"), DateTimeOffset.UnixEpoch);
        Assert.NotEqual(first.ControllerBootId, rebooted.ControllerBootId);

        var unreadable = OpcUaProtocolAdapter.BuildControllerState(
            Values(bootId: "not-a-guid"), DateTimeOffset.UnixEpoch);
        Assert.Equal(Guid.Empty, unreadable.ControllerBootId);
    }

    /// <summary>
    /// The identity is read from the controller, and the freshness is never Live: this is a
    /// stand-in and says so all the way through to what a screen renders.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void TheReportedIdentityIsReadFromTheControllerAndNeverReadsAsLive()
    {
        var observation = OpcUaProtocolAdapter.BuildControllerState(
            Values(deviceId: "CH1-DEV-CELL-0009"), DateTimeOffset.UnixEpoch);

        Assert.Equal("CH1-DEV-CELL-0009", observation.ControllerId);
        Assert.Equal("CFG-REFAB-P01-R01", observation.ConfigurationRevision);
        Assert.Equal("S7-1200-G2-STANDIN/0.1.0-prototype.2", observation.FirmwareVersion);
        Assert.Equal("Simulated", observation.Freshness);
        Assert.NotEqual("Live", observation.Freshness);
    }

    /// <summary>
    /// The guard's own state numbering, and an unrecognised code reported as Unknown rather
    /// than as the first state in the list.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void TheGuardStateIsDecodedAndAnUnknownCodeIsNotReportedAsIdle()
    {
        Assert.Equal(
            "Idle",
            OpcUaProtocolAdapter.BuildControllerState(Values(state: 0), DateTimeOffset.UnixEpoch).OperatingState);
        Assert.Equal(
            "AwaitingLocalConfirmation",
            OpcUaProtocolAdapter.BuildControllerState(Values(state: 3), DateTimeOffset.UnixEpoch).OperatingState);
        Assert.Equal(
            "Unknown",
            OpcUaProtocolAdapter.BuildControllerState(Values(state: 42), DateTimeOffset.UnixEpoch).OperatingState);

        // A read that returned nothing for the state is Unknown too, never Idle. Idle is a
        // claim about a controller; absence is not.
        Assert.Equal(
            "Unknown",
            OpcUaProtocolAdapter.BuildControllerState(Values(state: null), DateTimeOffset.UnixEpoch).OperatingState);
    }

    /// <summary>
    /// A short read - fewer values than the adapter asked for - produces an observation that
    /// claims nothing, rather than one that indexes past the end.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void AShortReadClaimsNothingRatherThanFailing()
    {
        var observation = OpcUaProtocolAdapter.BuildControllerState(
            ["CH1-DEV-CELL-0001"], DateTimeOffset.UnixEpoch);

        Assert.Equal("CH1-DEV-CELL-0001", observation.ControllerId);
        Assert.Equal(Guid.Empty, observation.ControllerBootId);
        Assert.Equal("Unknown", observation.OperatingState);
        Assert.False(observation.Permissives.Reported);
        Assert.Contains(207u, observation.Permissives.DeferredCheckCodes);
    }

    /// <summary>
    /// This adapter now speaks about the controller, so a gateway running it beside another
    /// source has two claimants for one cell and must publish neither.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void ThisAdapterIsAControllerStateSource()
    {
        var adapter = typeof(OpcUaProtocolAdapter);
        Assert.Contains(typeof(IControllerStateSource), adapter.GetInterfaces());
    }
}
