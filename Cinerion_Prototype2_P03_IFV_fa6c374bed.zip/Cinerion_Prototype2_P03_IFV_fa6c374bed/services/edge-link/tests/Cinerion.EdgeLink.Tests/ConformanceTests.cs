// Runs the conformance suites against more than one implementation, so the boundary is real.

using System.Text;
using Cinerion.EdgeLink.Protocols;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// The provider boundary and the adapter boundary, each demonstrated by more than one
/// implementation passing one suite.
/// </summary>
/// <remarks>
/// Before this, "EdgeLink supports replaceable protocol adapters" and "a transport
/// overlay connects through a stable provider boundary" rested on an interface with a
/// single implementation behind it — which shows only that the interface was shaped
/// around the one thing that implements it. The suites are run here against every
/// provider and every adapter the service holds, including the three that are gated,
/// because refusing correctly is their contract while they are gated.
/// </remarks>
/// <requirements>CH1-COM-FR-0001, CH1-COM-FR-0002, CH1-COM-FR-0004, CH1-COM-FR-0005</requirements>
public sealed class ConformanceTests
{
    public static TheoryData<string> Providers() => new() { "loopback", "framed" };

    private static ITransportProvider Provider(string name) => name switch
    {
        "loopback" => new LoopbackTransportProvider(),
        "framed" => new FramedSerialTransportProvider(),
        _ => throw new ArgumentOutOfRangeException(nameof(name)),
    };

    /// <summary>
    /// CH1-VVT-TC-0024: a reference alternate provider passes the conformance tests. Two
    /// providers sharing no code — one that hands the bytes across, one that frames,
    /// segments, checksums and sequences them — carry the same domain message unchanged.
    /// </summary>
    [Theory]
    [MemberData(nameof(Providers))]
    [VerificationCase("CH1-VVT-TC-0024")]
    public async Task Ch1ComFr0005_EveryTransportProviderPassesTheSameConformanceSuite(string name)
    {
        var results = await TransportConformance.RunAsync(
            Provider(name), TestContext.Current.CancellationToken);

        Assert.NotEmpty(results);
        Assert.All(results, result => Assert.True(result.Passed, result.ToString()));
        // The suite must actually be running its checks, not returning an empty pass.
        Assert.Contains(results, result => result.CheckId == "TRN-02-ROUND-TRIP");
        Assert.Contains(results, result => result.CheckId == "TRN-03-SEGMENTED-MESSAGE");
    }

    /// <summary>
    /// The property the boundary exists for, asserted directly rather than inferred from
    /// two suite runs: the identical domain message crosses both providers and comes back
    /// byte for byte, with nothing in the message aware of which one carried it.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0024")]
    public async Task Ch1ComFr0005_TheSameDomainMessageCrossesBothProvidersUnchanged()
    {
        var envelope = TransportConformance.ReferenceEnvelope();
        var viaLoopback = await RoundTripAsync(new LoopbackTransportProvider(), envelope);
        var viaFramed = await RoundTripAsync(new FramedSerialTransportProvider(), envelope);

        Assert.Equal(envelope, viaLoopback);
        Assert.Equal(envelope, viaFramed);
        Assert.Equal(viaLoopback, viaFramed);
    }

    /// <summary>
    /// CH1-VVT-TC-0021: replaceable adapters without changing domain or inspection logic.
    /// The suite is the inspection logic, and it does not know which adapter it holds.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public async Task Ch1ComFr0002_AnOperationalAdapterPassesTheAdapterConformanceSuite()
    {
        var results = await AdapterConformance.RunAsync(
            new SimulatorProtocolAdapter(), TestContext.Current.CancellationToken);

        Assert.NotEmpty(results);
        Assert.All(results, result => Assert.True(result.Passed, result.ToString()));
        Assert.Contains(results, result => result.CheckId == "ADP-06-REPLAY-REFUSED");
        Assert.Contains(results, result => result.CheckId == "ADP-09-RECONCILE-REPLAYS-NOTHING");
    }

    public static TheoryData<string> GatedAdapters() => new() { "MQTT5", "OPCUA", "MODBUS" };

    /// <summary>
    /// A gated adapter is held to the stricter contract, not skipped. An uncommissioned
    /// adapter that acknowledged a command would have the domain believe a controller had
    /// accepted it, which is the failure the whole gating scheme exists to prevent.
    /// </summary>
    /// <remarks>
    /// Deliberately carries no <c>[VerificationCase]</c>. CH1-VVT-TC-0022 asks that data
    /// and command semantics remain consistent <em>across</em> MQTT, OPC UA and Modbus;
    /// evidence that all three refuse while uncommissioned is not evidence of that, and
    /// claiming it would be the overstatement the verification map exists to prevent.
    /// The case stays hardware-gated.
    /// </remarks>
    [Theory]
    [MemberData(nameof(GatedAdapters))]
    public async Task Ch1ComFr0003_AGatedAdapterRefusesEveryPathAndSaysWhy(string protocol)
    {
        IProtocolAdapter adapter = protocol switch
        {
            "MQTT5" => new Mqtt5ProtocolAdapter(),
            "OPCUA" => new OpcUaGatedAdapter(),
            "MODBUS" => new ModbusGatedAdapter(),
            _ => throw new ArgumentOutOfRangeException(nameof(protocol)),
        };

        var results = await AdapterConformance.RunGatedAsync(adapter, TestContext.Current.CancellationToken);

        Assert.All(results, result => Assert.True(result.Passed, result.ToString()));
        Assert.Equal(protocol, adapter.Protocol);
        // The refusal names what is not commissioned, so an operator reading it learns
        // what would have to be true rather than only that something went wrong.
        var capability = Assert.Single(results, result => result.CheckId == "GATE-03-CAPABILITY-REFUSED");
        Assert.Contains("commissioned", capability.Observation, StringComparison.OrdinalIgnoreCase);
    }

    // ---------------------------------------------------------------- frame format

    /// <summary>
    /// The frame is a contract between two independent implementations, so the vectors
    /// here are the ones <c>firmware/tests/frame_codec_test.cpp</c> exercises on the
    /// other side. A change to either implementation that is not matched in the other
    /// shows up as a CRC or length disagreement rather than as a field failure.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0023")]
    public void Ch1ComFr0004_TheFrameCodecAgreesWithTheFirmwareImplementation()
    {
        // CRC-16/CCITT-FALSE published check value: "123456789" hashes to 0x29B1.
        Assert.Equal(0x29B1, FrameCodec.Crc16Ccitt("123456789"u8));

        var payload = Encoding.ASCII.GetBytes("CH1");
        var frame = FrameCodec.Encode(FrameCodec.TypeSingle, 7, payload);

        Assert.Equal(FrameCodec.HeaderBytes + payload.Length + FrameCodec.CrcBytes, frame.Length);
        Assert.Equal(0xC1, frame[0]);
        Assert.Equal(0xA1, frame[1]);
        Assert.Equal(1, frame[2]);
        Assert.Equal(FrameCodec.TypeSingle, frame[3]);
        Assert.Equal(0, frame[4]);
        Assert.Equal(payload.Length, frame[5]);
        Assert.Equal(7, frame[9]);

        Assert.Equal(FrameCodec.FrameRejection.None, FrameCodec.TryDecode(frame, 0, out var decoded));
        Assert.Equal(FrameCodec.TypeSingle, decoded.Type);
        Assert.Equal(7u, decoded.Sequence);
        Assert.Equal(payload, decoded.Payload);
    }

    /// <summary>
    /// Every way a frame can fail to add up, each named for what it is. A decoder that
    /// reported one cause for another would send an operator to the wrong fault.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0023")]
    [VerificationCase("CH1-VVT-TC-0029")]
    public void Ch1ComFr0004_EveryMalformedFrameIsRefusedForItsOwnReason()
    {
        var good = FrameCodec.Encode(FrameCodec.TypeSingle, 5, "payload"u8);

        Assert.Equal(FrameCodec.FrameRejection.TooShort, Decode(good.AsSpan(0, 6).ToArray(), 0));

        var badPreamble = (byte[])good.Clone();
        badPreamble[0] ^= 0xFF;
        Assert.Equal(FrameCodec.FrameRejection.PreambleInvalid, Decode(badPreamble, 0));

        var badVersion = (byte[])good.Clone();
        badVersion[2] = 9;
        Assert.Equal(FrameCodec.FrameRejection.VersionUnsupported, Decode(badVersion, 0));

        var badType = (byte[])good.Clone();
        badType[3] = 0x7F;
        Assert.Equal(FrameCodec.FrameRejection.TypeUnknown, Decode(badType, 0));

        var badLength = (byte[])good.Clone();
        badLength[5] = 200;
        Assert.Equal(FrameCodec.FrameRejection.LengthInvalid, Decode(badLength, 0));

        // Replay: a frame numbered below the window is refused rather than accepted late.
        Assert.Equal(FrameCodec.FrameRejection.SequenceNotAdvancing, Decode(good, 6));

        var corrupted = (byte[])good.Clone();
        corrupted[FrameCodec.HeaderBytes] ^= 0x01;
        Assert.Equal(FrameCodec.FrameRejection.CrcMismatch, Decode(corrupted, 0));

        // And the genuine frame still passes, so the checks above are not simply refusing
        // everything.
        Assert.Equal(FrameCodec.FrameRejection.None, Decode(good, 0));
    }

    /// <summary>
    /// Malformed bytes arriving on the link are counted and dropped, and the message
    /// being reassembled around them is abandoned rather than delivered with a hole in it.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0024")]
    public async Task Ch1ComFr0010_ARefusedFrameAbandonsItsMessageAndIsCounted()
    {
        var provider = new FramedSerialTransportProvider();
        using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(10));
        var received = new List<byte[]>();
        var pump = Task.Run(
            async () =>
            {
                try
                {
                    await foreach (var message in provider.ReceiveAsync(cancellation.Token).ConfigureAwait(false))
                    {
                        lock (received)
                        {
                            received.Add(message.ToArray());
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                }
            },
            CancellationToken.None);

        // Rubbish that is not a frame at all, then a genuine message.
        Assert.True(provider.InjectRawFrame(new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B }));
        await provider.SendAsync("after the rubbish"u8.ToArray(), cancellation.Token);

        var deadline = DateTimeOffset.UtcNow.AddSeconds(5);
        while (DateTimeOffset.UtcNow < deadline)
        {
            lock (received)
            {
                if (received.Count >= 1) break;
            }

            await Task.Delay(10, cancellation.Token);
        }

        await cancellation.CancelAsync();
        await pump;

        lock (received)
        {
            var message = Assert.Single(received);
            Assert.Equal("after the rubbish"u8.ToArray(), message);
        }

        Assert.True(provider.FramesObserved >= 2, $"observed {provider.FramesObserved} frames");
        Assert.Contains(FrameCodec.FrameRejection.PreambleInvalid, provider.Rejections.Keys);
    }

    private static FrameCodec.FrameRejection Decode(byte[] frame, uint minimumSequence) =>
        FrameCodec.TryDecode(frame, minimumSequence, out _);

    private static async Task<byte[]> RoundTripAsync(ITransportProvider provider, byte[] message)
    {
        using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(10));
        await provider.SendAsync(message, cancellation.Token);
        await foreach (var received in provider.ReceiveAsync(cancellation.Token))
        {
            return received.ToArray();
        }

        throw new InvalidOperationException("The provider delivered nothing.");
    }
}
