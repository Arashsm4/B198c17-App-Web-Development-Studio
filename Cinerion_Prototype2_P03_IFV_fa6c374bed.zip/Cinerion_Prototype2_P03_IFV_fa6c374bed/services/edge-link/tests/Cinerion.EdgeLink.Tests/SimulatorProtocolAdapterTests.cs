// Tests for the built-in simulator adapter.

using Cinerion.EdgeLink.Contracts;
using Cinerion.EdgeLink.Protocols;

namespace Cinerion.EdgeLink.Tests;

public sealed class SimulatorProtocolAdapterTests
{
    [Fact]
    [VerificationCase("CH1-VVT-TC-0020")]
    [VerificationCase("CH1-VVT-TC-0021")]
    public async Task Ch1VvtTc0020_ManifestUsesTheCommonCapabilityModel()
    {
        var adapter = new SimulatorProtocolAdapter();
        var manifest = await adapter.ReadCapabilityAsync(CancellationToken.None);
        Assert.Equal("1.0.0", manifest.SchemaVersion);
        Assert.StartsWith("CH1-DEV-", manifest.DeviceId);
        Assert.NotEmpty(manifest.SupportedCommands);
        Assert.All(manifest.TelemetryChannels, channel => Assert.False(channel.Writable));
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0025")]
    public async Task Ch1VvtTc0025_ExpiredCommandIsNotQueuedOrAccepted()
    {
        var adapter = new SimulatorProtocolAdapter();
        var command = Command(1, DateTimeOffset.UtcNow.AddSeconds(-1));
        var result = await adapter.PrepareAsync(command, CancellationToken.None);
        Assert.False(result.Accepted);
        Assert.Equal("COMMAND_EXPIRED", result.ReasonCode);
    }

    [Fact]
    [VerificationCase("CH1-VVT-TC-0029")]
    public async Task Ch1VvtTc0029_DuplicateSequenceIsSuppressed()
    {
        var adapter = new SimulatorProtocolAdapter();
        var expiry = DateTimeOffset.UtcNow.AddMinutes(1);
        Assert.True((await adapter.PrepareAsync(Command(10, expiry), CancellationToken.None)).Accepted);
        var duplicate = await adapter.PrepareAsync(Command(10, expiry), CancellationToken.None);
        Assert.False(duplicate.Accepted);
        Assert.Equal("SEQUENCE_REPLAY_OR_DUPLICATE", duplicate.ReasonCode);
    }

    private static SemanticCommandEnvelope Command(long sequence, DateTimeOffset expiry) => new(
        "1.0.0",
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        sequence,
        new string('a', 64),
        "CFG-REFAB-P01-R01",
        expiry,
        "RUN_DIMENSIONAL_TEST",
        new Dictionary<string, object>());
}
