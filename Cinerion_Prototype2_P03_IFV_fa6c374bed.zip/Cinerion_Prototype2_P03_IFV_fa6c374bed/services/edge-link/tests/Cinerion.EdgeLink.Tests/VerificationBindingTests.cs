// Checks this assembly's verification-case tags against the controlled list.

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// Reconciles this assembly's <c>[VerificationCase]</c> bindings with
/// <c>traceability/verification-map.json</c>, in both directions. See the same class in
/// Cinerion.Api.Tests for why the map is checked rather than trusted.
/// </summary>
/// <requirements>CH1-VVT-VMP-0001, CH1-SYS-RTM-0001</requirements>
public sealed class VerificationBindingTests
{
    private const string Harness = "Cinerion.EdgeLink.Tests";

    [Fact]
    public void TheMapAndThisAssemblyAgreeOnEveryControlledCase()
    {
        var failures = VerificationBinding.Reconcile(typeof(VerificationBindingTests).Assembly, Harness);

        Assert.True(failures.Count == 0, string.Join(Environment.NewLine, failures));
    }

    /// <summary>Guards the reflection itself, so the check above cannot pass over nothing.</summary>
    [Fact]
    public void TheBindingsAreActuallyBeingFound()
    {
        var observed = VerificationBinding.ObservedIn(typeof(VerificationBindingTests).Assembly);

        Assert.True(observed.Count >= 3, $"Expected this assembly's controlled-case bindings; found {observed.Count}.");
        Assert.Contains("CH1-VVT-TC-0020", observed.Keys);
        Assert.Contains("CH1-VVT-TC-0029", observed.Keys);
    }

    /// <summary>Records what actually ran, as evidence a report can cite.</summary>
    [Fact]
    public void ObservedBindingsArePublishedAsEvidence()
    {
        var path = VerificationBinding.WriteObservedBindings(typeof(VerificationBindingTests).Assembly, Harness);

        Assert.True(File.Exists(path), path);
    }

    /// <summary>Every binding must sit on something the runner will actually execute.</summary>
    [Fact]
    public void EveryBindingSitsOnAnExecutableTest()
    {
        var suspect = VerificationBinding.ObservedIn(typeof(VerificationBindingTests).Assembly)
            .SelectMany(pair => pair.Value.Select(test => $"{pair.Key}: {test}"))
            .Where(entry => entry.Contains("(not a test)", StringComparison.Ordinal)
                         || entry.Contains("(no test method)", StringComparison.Ordinal))
            .ToArray();

        Assert.True(suspect.Length == 0, string.Join(Environment.NewLine, suspect));
    }
}
