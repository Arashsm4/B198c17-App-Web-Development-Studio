// Tests what the Modbus adapter reports about the controller, and what it refuses to report.

using Cinerion.EdgeLink.Protocols;
using Microsoft.Extensions.Logging.Abstractions;

namespace Cinerion.EdgeLink.Tests;

/// <summary>
/// What the Modbus adapter reports about the controller itself — and above all what it
/// refuses to report.
/// </summary>
/// <remarks>
/// <para>
/// The live half needs a running controlled zone and is exercised by
/// <c>scripts/check-modbus-edge.sh</c>. What belongs here is the safety-relevant property,
/// which is a property of the decoding rather than of the wire: <b>this adapter can never
/// report an answered permissive</b>, whatever the controller puts in its registers. The
/// controlled Modbus map carries no interlock register at all — check 207 is deferred
/// because the real S7-1200 G2 reads <c>UDT_CH1_Permissives</c> from wired inputs and a
/// zone stand-in has none — so a gateway that produced one would be inventing it.
/// </para>
/// <para>
/// Asserted here rather than only at the CH1-COM-IF-0003 probe, because until this adapter
/// implemented <c>IControllerStateSource</c> the unanswered-permissive path could only be
/// produced by an attack client. A safe behaviour proven only against a synthetic message
/// is not proven against the controller that actually cannot answer.
/// </para>
/// </remarks>
/// <requirements>CH1-SAF-FR-0003, CH1-MON-FR-0003, CH1-COM-IF-0003, CH1-COM-IF-0008</requirements>
public sealed class ModbusControllerStateTests
{
    private static ModbusProtocolAdapter Adapter() => new(
        new ModbusAdapterOptions("modbus-plc", 502, 1, "CH1-DEV-CELL-0001", TimeSpan.FromSeconds(2)),
        NullLogger<ModbusProtocolAdapter>.Instance,
        TimeProvider.System);

    /// <summary>
    /// A configuration band as the controlled zone presents it. Only the fields the
    /// controller state reads are populated; the rest stay zero, which is what a short or
    /// partly-decoded band would look like.
    /// </summary>
    private static ushort[] Configuration(ushort bootId = 7, ushort securityProfile = 1)
    {
        var band = new ushort[72];
        band[Ch1ModbusMap.ConfigControllerBootIdLow] = bootId;
        band[Ch1ModbusMap.ConfigSecurityProfileCode] = securityProfile;
        Ch1ModbusEncoding.WriteText(
            band.AsSpan(Ch1ModbusMap.ConfigDeviceId, Ch1ModbusMap.LongTextRegisters), "CH1-DEV-CELL-0001");
        Ch1ModbusEncoding.WriteText(
            band.AsSpan(Ch1ModbusMap.ConfigFirmwareVersion, Ch1ModbusMap.LongTextRegisters), "1.4.2");
        Ch1ModbusEncoding.WriteText(
            band.AsSpan(Ch1ModbusMap.ConfigConfigurationRevision, Ch1ModbusMap.LongTextRegisters),
            "CFG-REFAB-P01-R01");
        return band;
    }

    private static ushort[] Answer(ushort state = 0, ushort firstDeferred = 0, ushort secondDeferred = 0)
    {
        var answer = new ushort[Ch1ModbusMap.InputRegisterCount - Ch1ModbusMap.AnswerBandStart];
        answer[Ch1ModbusMap.AnswerState - Ch1ModbusMap.AnswerBandStart] = state;
        answer[Ch1ModbusMap.AnswerDeferredCheckFirst - Ch1ModbusMap.AnswerBandStart] = firstDeferred;
        answer[Ch1ModbusMap.AnswerDeferredCheckSecond - Ch1ModbusMap.AnswerBandStart] = secondDeferred;
        return answer;
    }

    /// <summary>
    /// <b>The property the whole change exists for.</b> Every interlock is false and, more
    /// importantly, <c>Reported</c> is false — which is what makes Control Core resolve the
    /// cell as not permissive whatever the individual fields say.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void Ch1SafFr0003_TheModbusAdapterNeverReportsAnAnsweredPermissive()
    {
        var observation = Adapter().BuildControllerState(
            Configuration(), Answer(), DateTimeOffset.UnixEpoch);

        Assert.False(observation.Permissives.Reported);
        Assert.False(observation.Permissives.ControllerOnline);
        Assert.False(observation.Permissives.StartEnable);
        Assert.False(observation.Permissives.StopCircuitHealthy);
        Assert.False(observation.Permissives.GuardHealthy);
        Assert.False(observation.Permissives.ActuatorHome);
        Assert.False(observation.Permissives.ButtonPressed);
    }

    /// <summary>
    /// It says <em>why</em> the permissives are unanswered. "Not permissive" and "nobody has
    /// told us whether it is" are different states, and CH1-MON-FR-0003 is precisely about
    /// keeping them apart in an operational view.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void Ch1MonFr0003_TheDeferredPermissiveCheckIsAlwaysNamed()
    {
        var observation = Adapter().BuildControllerState(
            Configuration(), Answer(), DateTimeOffset.UnixEpoch);

        Assert.Contains(207u, observation.Permissives.DeferredCheckCodes);
    }

    /// <summary>
    /// A guard that reported its own deferred checks has them carried through, and 207 is
    /// not duplicated when the guard already named it. The controlled document is the
    /// reason 207 is stated; the guard's answer is additional evidence, not a replacement.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void DeferredChecksTheGuardReportedAreCarriedWithoutDuplicatingTheControlledOne()
    {
        var observation = Adapter().BuildControllerState(
            Configuration(), Answer(firstDeferred: 206, secondDeferred: 207), DateTimeOffset.UnixEpoch);

        Assert.Equal([206u, 207u], observation.Permissives.DeferredCheckCodes);
    }

    /// <summary>
    /// The boot identity is derived from the controller's own boot register, and it must be
    /// <b>stable across reads and different across restarts</b>. A random identity would
    /// change on every read and void every prepared command on a healthy controller, which
    /// is the opposite of what CH1-CMD-FR-0009 asks for.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void Ch1CmdFr0009_TheBootIdentityIsStableAcrossReadsAndChangesWithTheController()
    {
        var adapter = Adapter();

        var first = adapter.BuildControllerState(Configuration(bootId: 7), Answer(), DateTimeOffset.UnixEpoch);
        var again = adapter.BuildControllerState(Configuration(bootId: 7), Answer(), DateTimeOffset.UnixEpoch);
        var restarted = adapter.BuildControllerState(Configuration(bootId: 8), Answer(), DateTimeOffset.UnixEpoch);

        Assert.Equal(first.ControllerBootId, again.ControllerBootId);
        Assert.NotEqual(first.ControllerBootId, restarted.ControllerBootId);
        Assert.NotEqual(Guid.Empty, first.ControllerBootId);
    }

    /// <summary>
    /// Identity, revision and firmware are read from the controller rather than composed by
    /// the gateway, and the freshness is never upgraded past what a stand-in can honestly
    /// claim.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void TheReportedIdentityIsReadFromTheControllerAndNeverReadsAsLive()
    {
        var observation = Adapter().BuildControllerState(
            Configuration(), Answer(state: 2), DateTimeOffset.UnixEpoch);

        Assert.Equal("CH1-DEV-CELL-0001", observation.ControllerId);
        Assert.Equal("CFG-REFAB-P01-R01", observation.ConfigurationRevision);
        Assert.Equal("1.4.2", observation.FirmwareVersion);
        Assert.Equal("AwaitingCredential", observation.OperatingState);
        Assert.Equal("MODBUS-ZONED-ALLOWLIST-NO-GENERAL-ROUTING", observation.SecurityProfile);
        Assert.Equal("Simulated", observation.Freshness);
    }

    /// <summary>
    /// An unrecognised security profile code is reported as unknown rather than as the one
    /// profile this edge can honestly claim. The zone and the allowlist are the entire
    /// security control on Modbus, so claiming them for a controller that did not say so
    /// would be the claim least able to defend itself.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void AnUnrecognisedSecurityProfileIsNotReportedAsTheControlledOne()
    {
        var observation = Adapter().BuildControllerState(
            Configuration(securityProfile: 99), Answer(), DateTimeOffset.UnixEpoch);

        Assert.Equal("MODBUS-PROFILE-UNKNOWN", observation.SecurityProfile);
    }

    /// <summary>
    /// The gateway now holds two controller-state sources — the simulator and this one — so
    /// the ambiguity guard is what stops a deployment fronting both from making a cell flap.
    /// Named here as well as in its own tests, because this adapter is the reason it matters.
    /// </summary>
    [Fact]
    [VerificationCase("CH1-VVT-TC-0021")]
    public void ThisAdapterAndTheSimulatorTogetherAreAmbiguousAndAreRefused()
    {
        var selection = Cinerion.EdgeLink.Runtime.IngressPublisher.SelectControllerStateSource(
            [Adapter(), new SimulatorProtocolAdapter()], configuredAdapterId: null);

        Assert.Null(selection.Source);
        Assert.Contains("CH1-ADP-MODBUS-0001", selection.Reason, StringComparison.Ordinal);

        var chosen = Cinerion.EdgeLink.Runtime.IngressPublisher.SelectControllerStateSource(
            [Adapter(), new SimulatorProtocolAdapter()], "CH1-ADP-MODBUS-0001");
        Assert.NotNull(chosen.Source);
    }
}
