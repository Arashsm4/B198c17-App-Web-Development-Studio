#!/usr/bin/env python3
"""Build the Cinerion codebase engineering manual as a styled Word document.

The manual is deliberately generated from the repository it explains.  That
keeps paths, line numbers, file counts, and code listings synchronized with the
actual Prototype 1 source rather than with a hand-maintained copy.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Iterable, Sequence

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "docs" / "guides" / "Cinerion_Codebase_Engineering_Manual_P03_IFV.docx"
PROJECT = "Cinerion"
REVISION = "P03 / IFV"
SOFTWARE = "Prototype 1 · 0.1.0"
OWNER = "IR"

NAVY = "102A43"
BLUE = "2E74B5"
TEAL = "148A8A"
PALE_BLUE = "E8EEF5"
PALE_TEAL = "E8F4F3"
PALE_AMBER = "FFF4D6"
PALE_RED = "FDEBEC"
PALE_GREEN = "EAF5EC"
INK = "1D2733"
MID = "5B6775"
WHITE = "FFFFFF"
GRID = "AAB6C2"
CODE_BG = "F4F6F8"


@dataclass(frozen=True)
class SourceFile:
    path: Path
    rel: str
    kind: str
    generated: bool
    binary: bool
    lines: int
    size: int


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_cell_width(cell, width_dxa: int) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(width_dxa))
    tc_w.set(qn("w:type"), "dxa")


def set_table_width(table, width_dxa: int = 9360, indent_dxa: int = 120) -> None:
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(width_dxa))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent_dxa))
    tbl_ind.set(qn("w:type"), "dxa")
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def add_field(run, instruction: str) -> None:
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    fld_separate = OxmlElement("w:fldChar")
    fld_separate.set(qn("w:fldCharType"), "separate")
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.extend((fld_begin, instr, fld_separate, fld_end))


def bookmark(paragraph, name: str, number: int) -> None:
    start = OxmlElement("w:bookmarkStart")
    start.set(qn("w:id"), str(number))
    start.set(qn("w:name"), name)
    end = OxmlElement("w:bookmarkEnd")
    end.set(qn("w:id"), str(number))
    paragraph._p.insert(0, start)
    paragraph._p.append(end)


def add_internal_link(paragraph, text: str, anchor: str, color: str = BLUE) -> None:
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("w:anchor"), anchor)
    run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    r_style = OxmlElement("w:rStyle")
    r_style.set(qn("w:val"), "Hyperlink")
    color_node = OxmlElement("w:color")
    color_node.set(qn("w:val"), color)
    r_pr.extend((r_style, color_node))
    text_node = OxmlElement("w:t")
    text_node.text = text
    run.extend((r_pr, text_node))
    hyperlink.append(run)
    paragraph._p.append(hyperlink)


def set_update_fields(document: Document) -> None:
    settings = document.settings._element
    node = settings.find(qn("w:updateFields"))
    if node is None:
        node = OxmlElement("w:updateFields")
        settings.append(node)
    node.set(qn("w:val"), "true")


def configure_document(document: Document) -> None:
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    section.different_first_page_header_footer = True

    styles = document.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    for name, size, color, before, after in (
        ("Title", 28, NAVY, 0, 12),
        ("Subtitle", 13, MID, 0, 12),
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 14, 7),
        ("Heading 3", 12, "1F4D78", 10, 5),
        ("Heading 4", 11, TEAL, 8, 4),
    ):
        style = styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.font.bold = name != "Subtitle"
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    if "Code Block" not in styles:
        code = styles.add_style("Code Block", WD_STYLE_TYPE.PARAGRAPH)
    else:
        code = styles["Code Block"]
    code.font.name = "Consolas"
    code._element.rPr.rFonts.set(qn("w:eastAsia"), "Consolas")
    code.font.size = Pt(7.2)
    code.font.color.rgb = RGBColor.from_string("253442")
    code.paragraph_format.space_before = Pt(0)
    code.paragraph_format.space_after = Pt(2)
    code.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    code.paragraph_format.line_spacing = Pt(9.2)

    if "Caption" in styles:
        cap = styles["Caption"]
        cap.font.name = "Calibri"
        cap.font.size = Pt(9)
        cap.font.italic = True
        cap.font.color.rgb = RGBColor.from_string(MID)
        cap.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap.paragraph_format.space_after = Pt(8)

    for section in document.sections:
        configure_header_footer(section)
    set_update_fields(document)


def configure_header_footer(section) -> None:
    header = section.header
    p = header.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.tab_stops.add_tab_stop(Inches(3.25), WD_TAB_ALIGNMENT.CENTER)
    p.paragraph_format.tab_stops.add_tab_stop(Inches(6.5), WD_TAB_ALIGNMENT.RIGHT)
    for index, text_value in enumerate(("CINERION", "CODEBASE ENGINEERING MANUAL", REVISION)):
        if index:
            p.add_run("\t")
        r = p.add_run(text_value)
        r.bold = True
        r.font.name = "Calibri"
        r.font.size = Pt(8)
        r.font.color.rgb = RGBColor.from_string(TEAL if index == 0 else MID)
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run("CONFIDENTIAL ENGINEERING SOURCE · IR · ")
    r.font.size = Pt(7.5)
    r.font.color.rgb = RGBColor.from_string(MID)
    page_run = p.add_run()
    page_run.font.size = Pt(7.5)
    add_field(page_run, "PAGE")
    p.add_run(" of ")
    pages_run = p.add_run()
    pages_run.font.size = Pt(7.5)
    add_field(pages_run, "NUMPAGES")


def add_heading(document: Document, text: str, level: int, anchor: str | None = None, number: int = 0):
    p = document.add_heading(text, level=level)
    if anchor:
        bookmark(p, anchor, number)
    return p


def add_para(document: Document, text: str = "", *, bold_lead: str | None = None, style=None):
    p = document.add_paragraph(style=style)
    if bold_lead and text.startswith(bold_lead):
        r = p.add_run(bold_lead)
        r.bold = True
        p.add_run(text[len(bold_lead):])
    else:
        p.add_run(text)
    return p


def add_bullets(document: Document, items: Sequence[str], *, numbered: bool = False) -> None:
    style = "List Number" if numbered else "List Bullet"
    for item in items:
        p = document.add_paragraph(style=style)
        p.paragraph_format.left_indent = Inches(0.375)
        p.paragraph_format.first_line_indent = Inches(-0.188)
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.line_spacing = 1.25
        p.add_run(item)


def add_callout(document: Document, title: str, body: str, *, kind: str = "info") -> None:
    fills = {"info": PALE_BLUE, "safe": PALE_GREEN, "warn": PALE_AMBER, "danger": PALE_RED, "concept": PALE_TEAL}
    p = document.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.12)
    p.paragraph_format.right_indent = Inches(0.08)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p_pr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fills.get(kind, PALE_BLUE))
    p_pr.append(shd)
    borders = OxmlElement("w:pBdr")
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), "18")
    left.set(qn("w:space"), "8")
    left.set(qn("w:color"), TEAL if kind in {"safe", "concept"} else BLUE)
    borders.append(left)
    p_pr.append(borders)
    r = p.add_run(title.upper())
    r.bold = True
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor.from_string(TEAL if kind in {"safe", "concept"} else BLUE)
    p.add_run("\n")
    body_run = p.add_run(body)
    body_run.font.size = Pt(10)


def add_table(document: Document, headers: Sequence[str], rows: Sequence[Sequence[str]], widths: Sequence[int] | None = None):
    table = document.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_table_width(table, 9360, 120)
    if widths is None:
        widths = [9360 // len(headers)] * len(headers)
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        set_cell_width(cell, widths[index])
        set_cell_shading(cell, PALE_BLUE)
        set_cell_margins(cell)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(header)
        r.bold = True
        r.font.size = Pt(9)
        r.font.color.rgb = RGBColor.from_string(NAVY)
    set_repeat_table_header(table.rows[0])
    for row_data in rows:
        row = table.add_row()
        for index, value in enumerate(row_data):
            cell = row.cells[index]
            set_cell_width(cell, widths[index])
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(str(value))
            r.font.size = Pt(8.5)
    document.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_code(document: Document, code: str, *, numbered: bool = False, start: int = 1, chunk_size: int = 36) -> None:
    lines = code.splitlines() or [""]
    width = len(str(start + len(lines)))
    for offset in range(0, len(lines), chunk_size):
        group = lines[offset : offset + chunk_size]
        if numbered:
            rendered = "\n".join(f"{start + offset + i:>{width}} | {line}" for i, line in enumerate(group))
        else:
            rendered = "\n".join(group)
        p = document.add_paragraph(style="Code Block")
        p.paragraph_format.keep_together = False
        p.paragraph_format.keep_with_next = False
        p.paragraph_format.left_indent = Inches(0.12)
        p.paragraph_format.right_indent = Inches(0.08)
        p.paragraph_format.space_before = Pt(2 if offset == 0 else 0)
        p.paragraph_format.space_after = Pt(1)
        p_pr = p._p.get_or_add_pPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:fill"), CODE_BG)
        p_pr.append(shd)
        r = p.add_run(rendered)
        r.font.name = "Consolas"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "Consolas")
        r.font.size = Pt(7.2)


def add_figure(document: Document, path: Path, caption: str, alt_text: str, width: float = 6.2) -> None:
    if not path.exists():
        return
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    shape = run.add_picture(str(path), width=Inches(width))
    doc_pr = shape._inline.docPr
    doc_pr.set("descr", alt_text)
    doc_pr.set("title", caption)
    cap = document.add_paragraph(caption, style="Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER


def safe_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


TEXT_SUFFIXES = {
    ".cs", ".csproj", ".slnx", ".props", ".json", ".yaml", ".yml", ".ts", ".tsx", ".mjs", ".js",
    ".sh", ".ps1", ".sql", ".cpp", ".hpp", ".scl", ".conf", ".acl", ".css", ".md", ".svg", ".txt",
    ".py",
}


def classify(rel: str) -> str:
    if rel.startswith("services/control-core/"):
        return "Control Core (.NET)"
    if rel.startswith("services/edge-link/"):
        return "EdgeLink (.NET)"
    if rel.startswith("apps/operator-portal/"):
        return "Operator portal"
    if rel.startswith("packages/contracts/"):
        return "Contracts"
    if rel.startswith("simulators/state-model/"):
        return "Executable model"
    if rel.startswith("infrastructure/"):
        return "Infrastructure"
    if rel.startswith("firmware/"):
        return "Embedded firmware"
    if rel.startswith("plc/"):
        return "PLC"
    if rel.startswith("scripts/"):
        return "Developer automation"
    if rel.startswith("traceability/"):
        return "Traceability"
    if rel.startswith(".github/"):
        return "CI and governance"
    if rel.startswith("docs/implementation/") or rel.startswith("docs/guides/"):
        return "Implementation guidance"
    if rel.startswith("docs/baseline/"):
        return "Frozen P03 baseline"
    return "Repository foundation"


def should_inventory(path: Path) -> bool:
    rel = path.relative_to(REPO).as_posix()
    excluded_parts = {"node_modules", ".local", "artifacts", "release", ".expo", "dist", "bin", "obj", "__pycache__"}
    if any(part in excluded_parts for part in path.relative_to(REPO).parts):
        return False
    if rel == OUT.relative_to(REPO).as_posix():
        return False
    if rel == OUT.with_suffix(".manifest.json").relative_to(REPO).as_posix():
        return False
    if rel.startswith("docs/baseline/P03_IFV/sources/"):
        return False
    if rel.startswith("docs/baseline/P03_IFV/data/"):
        return False
    if rel.startswith("docs/baseline/P03_IFV/config/"):
        return False
    if rel.startswith("docs/baseline/P03_IFV/assets/"):
        return False
    return path.is_file()


def inventory() -> list[SourceFile]:
    result: list[SourceFile] = []
    for path in sorted(REPO.rglob("*")):
        if not should_inventory(path):
            continue
        rel = path.relative_to(REPO).as_posix()
        suffix = path.suffix.lower()
        binary = suffix not in TEXT_SUFFIXES and path.name not in {
            "Dockerfile", ".env.example", ".gitignore", ".dockerignore", ".editorconfig", 
            ".gitattributes", ".npmrc", "sdkconfig.defaults", "acl",
        }
        generated = (
            rel in {"package-lock.json", "traceability/implementation-map.json", "packages/contracts/openapi/openapi.generated.yaml", "RELEASE_MANIFEST.json"}
            or rel.startswith("evidence/generated/")
        )
        text = "" if binary else safe_text(path)
        result.append(SourceFile(path, rel, classify(rel), generated, binary, len(text.splitlines()), path.stat().st_size))
    return result


def plain_language_kind(source: SourceFile) -> str:
    suffix = source.path.suffix.lower()
    mapping = {
        ".cs": "C# source", ".csproj": ".NET project file", ".slnx": ".NET solution", ".props": ".NET shared build properties",
        ".ts": "TypeScript source", ".tsx": "React/TypeScript screen or component", ".mjs": "Node.js module",
        ".js": "JavaScript", ".json": "JSON configuration/data", ".yaml": "YAML configuration", ".yml": "YAML configuration",
        ".sh": "POSIX shell automation", ".ps1": "PowerShell automation", ".sql": "PostgreSQL migration",
        ".cpp": "C++ source", ".hpp": "C++ header", ".scl": "Siemens Structured Control Language",
        ".conf": "service configuration", ".acl": "access-control list", ".css": "style sheet", ".md": "Markdown guidance",
        ".svg": "vector graphic", ".txt": "text manifest",
    }
    if source.path.name == "Dockerfile":
        return "container build recipe"
    if source.path.name == ".env.example":
        return "environment-variable template"
    return mapping.get(suffix, "project artifact")


PURPOSES = {
    "services/control-core/src/Cinerion.Api/Program.cs": "The API composition root. It selects the runtime profile, registers dependencies, configures authentication and middleware, seeds Prototype 1 data, and maps every HTTP endpoint.",
    "services/control-core/src/Cinerion.Domain/Commands/CommandTransaction.cs": "The production command aggregate. It is the central non-bypass authority for prepare, credential proof, local commit, execution, cancellation, restart handling, fault latching, and local recovery.",
    "services/control-core/src/Cinerion.Domain/Commands/CommandContracts.cs": "Strongly typed command, cell, credential, button, and snapshot messages shared by the command domain.",
    "services/control-core/src/Cinerion.Domain/Security/ActorContext.cs": "The authenticated subject model: actor kind, strength of authentication, roles, and project/cell scope.",
    "services/control-core/src/Cinerion.Domain/Audit/AuditChain.cs": "A hash-linked append-only audit model used to make mutation history tamper-evident during Prototype 1.",
    "services/control-core/src/Cinerion.Domain/Quality/QualityRecords.cs": "Quality-domain rules for measurements, calibration validity, NCR hold, linked retest, and independent release.",
    "services/control-core/src/Cinerion.Application/Commands/CommandService.cs": "Application orchestration around the command aggregate, storage ports, idempotency, locking, and allow/reject audit evidence.",
    "services/control-core/src/Cinerion.Application/Quality/QualityService.cs": "Application orchestration for measurements, NCRs, retests, and release decisions.",
    "services/control-core/src/Cinerion.Infrastructure/InMemory/InMemoryCinerionStore.cs": "Prototype-only adapter that implements persistence ports in process memory with optimistic version checks.",
    "services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0001_ch1_foundation.sql": "The target PostgreSQL foundation: project-scoped keys, operational and evidence tables, row-level security, indexes, and immutability triggers.",
    "packages/contracts/src/index.ts": "The TypeScript contract surface for identifiers, command messages, acknowledgements, telemetry, and device capabilities.",
    "packages/contracts/scripts/generate-openapi.mjs": "Builds the OpenAPI catalogue deterministically from the controlled endpoint register.",
    "simulators/state-model/src/model.ts": "An executable reference model of CommandGuard used to prove happy and negative paths independently of production .NET code.",
    "simulators/state-model/src/audit.ts": "A small TypeScript hash-chain model for deterministic audit tests and demonstrations.",
    "simulators/state-model/src/quality.ts": "An executable quality lifecycle model used to prove hold/rework/retest/release behavior.",
    "services/edge-link/src/Cinerion.EdgeLink/Protocols/SimulatorProtocolAdapter.cs": "The only enabled Prototype 1 protocol adapter. It models bounded request/acknowledgement traffic without granting live industrial authority.",
    "services/edge-link/src/Cinerion.EdgeLink/Protocols/GatedIndustrialAdapters.cs": "Fail-closed placeholders for MQTT, OPC UA, and Modbus. They make an unapproved live protocol impossible to mistake for an implemented feature.",
    "firmware/shared/src/cell_state_machine.cpp": "Portable controller logic that enforces freshness, one-shot sequences, rising-edge local input, final permissive sampling, output-off defaults, and local-only reset.",
    "firmware/shared/include/cinerion/cell_state_machine.hpp": "The allocation-free firmware types and state-machine public API.",
    "firmware/arduino-io/src/frame_codec.cpp": "A deterministic serial frame encoder/decoder with sequence handling and CRC-16 integrity checking.",
    "firmware/esp32/main/app_main.cpp": "A deliberately inert ESP32 entry point. All inputs begin false, no actuator GPIO is assigned, and the portable state machine is merely ticked.",
    "plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl": "The Siemens-side semantic mirror of command preparation and local commitment. It has no safety credit and must be validated in PLCSIM/HIL before use.",
    "plc/s7-1200-g2/01_Blocks/FB_CH1_Procedure.scl": "A small controlled procedure skeleton with permissive, stop, watchdog, timed-step, and fault-latch behavior.",
    "apps/operator-portal/src/components/app-shell.tsx": "The portal frame: responsive navigation, environment visibility, page identity, and consistent status presentation.",
    "apps/operator-portal/src/components/primitives.tsx": "Reusable visual primitives that keep colors, cards, badges, metrics, and section layouts consistent.",
    "apps/operator-portal/src/data/prototype.ts": "Clearly labelled representative display data. It must be replaced by a generated authenticated API client in the next increment.",
    "infrastructure/compose.yaml": "The simulator-first local topology. Optional profiles add PostgreSQL, Keycloak, or protocol laboratory services; hardening defaults reduce container privileges.",
    "infrastructure/keycloak/cinerion-realm.json": "Importable identity-realm baseline with no seed users, strong password/brute-force policy, roles, OIDC clients, PKCE, TOTP, and WebAuthn requirements.",
    "scripts/doctor.sh": "Read-only Ubuntu/WSL prerequisite diagnosis. It identifies version drift, partial .NET installs, missing Docker integration, and an unreachable Docker daemon.",
    "scripts/verify.sh": "The single local release gate. It proves baseline integrity, contracts, models, traceability, repository policy, portal, firmware, .NET, and Compose when strict mode is requested.",
    "scripts/run-local.sh": "Starts the local Compose topology only after the Docker CLI, Compose v2, and engine all answer correctly.",
    "scripts/package-release.sh": "Constructs the source release, excludes secrets/build products, writes SHA-256 checksums, and verifies a fresh extraction.",
    ".github/workflows/ci.yml": "The machine-enforced release gate in GitHub Actions, including verification, tests, dependency evidence, and packaging checks.",
    "docs/implementation/WSL_SETUP.md": "The exact Ubuntu/WSL recovery runbook for the broken .NET host and missing Docker Desktop integration shown in the supplied screenshot.",
}


def inferred_purpose(source: SourceFile) -> str:
    if source.rel in PURPOSES:
        return PURPOSES[source.rel]
    name = source.path.name
    stem = source.path.stem
    kind = plain_language_kind(source)
    if name.endswith("Tests.cs") or "/test/" in source.rel or "/tests/" in source.rel:
        return f"A {kind} that proves the behavior named by {stem}; it is executable evidence and should change with the production rule it protects."
    if name.endswith("Endpoints.cs"):
        return f"HTTP route mappings for the {stem.removesuffix('Endpoints')} area, translating requests into application-service calls and typed responses."
    if name.endswith(".csproj"):
        return "Defines one .NET project, its target framework, references, test role, and package dependencies."
    if name == "Dockerfile":
        return "Builds a least-privilege application container from a repeatable multi-stage recipe."
    if name in {"package.json", "tsconfig.json", "tsconfig.base.json", "app.json"}:
        return f"Controls {source.kind.lower()} tools, commands, dependencies, compilation, or application metadata."
    if source.rel.startswith("apps/operator-portal/src/app/"):
        return f"An Expo Router screen. Its filename defines the route and its component renders the {stem} operator workflow."
    if source.rel.startswith("packages/contracts/schemas/"):
        return "A fail-closed JSON Schema that constrains a message crossing a trust or process boundary."
    if source.rel.startswith("scripts/"):
        return f"Developer automation for {stem.replace('-', ' ')}; it exists so the same controlled procedure is repeated locally and in CI."
    if source.rel.startswith("docs/implementation/"):
        return f"Implementation guidance for {stem.replace('_', ' ').lower()}, kept beside the code and versioned with it."
    if source.rel.startswith("plc/") and source.path.suffix == ".scl":
        return "Siemens SCL source that mirrors a bounded controller responsibility without claiming certified safety behavior."
    return f"A {kind} in the {source.kind} area. Its role is determined by its directory boundary and the consumers shown in the source listing."


def change_rule(source: SourceFile) -> tuple[str, str, str]:
    rel = source.rel
    if source.generated:
        return (
            "Change its controlling source or generator, never the generated output directly.",
            "Hand-editing creates drift that the next generation step will overwrite.",
            "Run the named generator and the strict verification gate; the diff must be deterministic.",
        )
    if rel.startswith("services/control-core/src/Cinerion.Domain/"):
        return (
            "Change here when a business invariant or state transition changes; add a domain test first.",
            "Do not import HTTP, database, UI, or industrial-protocol concerns into the domain.",
            "Run Domain.Tests, state-model tests when the rule is mirrored, traceability, and the full strict gate.",
        )
    if rel.startswith("services/control-core/src/Cinerion.Application/"):
        return (
            "Change orchestration, transaction boundaries, port calls, idempotency, and audit sequencing here.",
            "Do not duplicate domain rules or bind the layer directly to a particular database implementation.",
            "Run domain and API tests, then prove allow and reject paths both emit correct audit evidence.",
        )
    if rel.startswith("services/control-core/src/Cinerion.Api/"):
        return (
            "Change transport mapping, authentication wiring, request validation, or response contracts here.",
            "Never make a browser route capable of synthesizing a local physical commitment.",
            "Regenerate OpenAPI if the controlled contract changes; run API tests and smoke checks.",
        )
    if rel.endswith("0001_ch1_foundation.sql"):
        return (
            "Leave this applied migration immutable; create the next numbered forward migration for a schema change.",
            "Never edit production history, weaken RLS, or make evidence tables mutable to simplify an application bug.",
            "Test clean migration, upgrade migration, rollback/recovery plan, tenant isolation, backup, and restore.",
        )
    if rel.startswith("apps/operator-portal/"):
        return (
            "Change presentation and operator interaction here; keep authority on the server and controller boundary.",
            "Do not treat hidden buttons, disabled CSS, or client-side checks as security controls.",
            "Run type-check, lint, web export, accessibility review, and authenticated integration tests.",
        )
    if rel.startswith("firmware/"):
        return (
            "Change only after defining the input/output contract and adding host tests for every fail-closed path.",
            "Do not assign live actuator pins or remove output-off startup behavior during simulator work.",
            "Run both host suites, static analysis, device tests, then HIL before any controlled bench energisation.",
        )
    if rel.startswith("plc/"):
        return (
            "Change in an isolated TIA Portal project, retain semantic contract IDs, and update PLCSIM scenarios.",
            "Do not claim this standard PLC logic is a certified safety function or bypass external safety circuitry.",
            "Compile in the selected STEP 7/TIA version, run PLCSIM, code review, HIL, and independent review at the later gate.",
        )
    if rel.startswith("infrastructure/"):
        return (
            "Change images, ports, profiles, secrets references, and policies through reviewed configuration.",
            "Never commit real passwords, private keys, recovery codes, or permissive production defaults.",
            "Validate Compose, scan images, test health checks, exercise recovery, and inspect effective configuration.",
        )
    if rel.startswith("packages/contracts/"):
        return (
            "Change the controlled contract source first and treat compatibility as an explicit engineering decision.",
            "Never silently reuse a field with a new meaning or accept unknown authority-bearing fields.",
            "Regenerate outputs, validate schemas, add compatibility vectors, and update every producer/consumer.",
        )
    return (
        "Change this file only for the responsibility stated above and keep the modification narrowly scoped.",
        "Do not mix secrets, generated output, or unrelated cleanup into the same engineering change.",
        "Run the nearest focused test followed by ./scripts/verify.sh --strict before release.",
    )


def notable_lines(text: str, suffix: str, limit: int = 12) -> list[tuple[int, str, str]]:
    notes: list[tuple[int, str, str]] = []
    patterns = (
        r"^(public |internal |private |protected )?(sealed )?(class|record|interface|enum|struct)\b",
        r"^(export )?(async )?(function|const|class|interface|type|enum)\b",
        r"^(CREATE|ALTER|GRANT|REVOKE|DO\s|INSERT|CREATE POLICY|CREATE TRIGGER)\b",
        r"^(IF|ELSIF|CASE|FUNCTION_BLOCK|TYPE|VAR_INPUT|VAR_OUTPUT)\b",
        r"^(if |case |for |while |docker |dotnet |npm |node |g\+\+|curl |sudo )",
        r"Map(Get|Post|Put|Delete|Patch)|RequireAuthorization|AddAuthentication|AddAuthorization",
    )
    for number, raw in enumerate(text.splitlines(), 1):
        stripped = raw.strip()
        if not stripped or stripped.startswith(("//", "#", "/*", "*")):
            continue
        if any(re.search(pattern, stripped, re.IGNORECASE) for pattern in patterns):
            if "RequireAuthorization" in stripped:
                why = "This line applies server-side authorization; UI visibility is never accepted as the security boundary."
            elif "Map" in stripped and ("Get" in stripped or "Post" in stripped or "Put" in stripped or "Delete" in stripped):
                why = "This line declares an HTTP operation and is part of the externally testable API surface."
            elif stripped.upper().startswith("CREATE POLICY") or "ROW LEVEL SECURITY" in stripped.upper():
                why = "This line establishes a database-enforced tenant isolation rule, independent of application filtering."
            elif stripped.startswith(("class ", "public class", "public sealed class", "internal sealed class")):
                why = "This type owns the responsibility suggested by its name; its public methods define the allowed collaboration surface."
            elif stripped.startswith(("interface ", "public interface", "export interface")):
                why = "This interface is a contract boundary. Implementations may change without changing its callers when semantics remain stable."
            elif stripped.startswith(("record ", "public record", "public sealed record", "export type", "type ")):
                why = "This declaration makes data shape and permitted values explicit so invalid combinations are harder to represent."
            elif stripped.startswith(("if ", "IF ", "Guard.", "case ", "CASE ")):
                why = "This is a decision point. Tests must cover both the accepted and rejected branch, especially when it guards authority."
            elif stripped.startswith(("docker ", "dotnet ", "npm ", "node ", "g++ ", "curl ", "sudo ")):
                why = "This invokes an external tool; successful exit status and clear diagnostic output are part of the automation contract."
            else:
                why = "This is a structural or control-flow line that defines how the file exposes behavior."
            notes.append((number, stripped[:110], why))
            if len(notes) >= limit:
                break
    if not notes:
        for number, raw in enumerate(text.splitlines(), 1):
            stripped = raw.strip()
            if stripped:
                notes.append((number, stripped[:110], "This line contributes configuration or data consumed by the file's owning subsystem."))
                if len(notes) >= min(limit, 6):
                    break
    return notes


def add_cover(document: Document) -> None:
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(64)
    r = p.add_run("CINERION")
    r.bold = True
    r.font.name = "Calibri"
    r.font.size = Pt(18)
    r.font.color.rgb = RGBColor.from_string(TEAL)

    p = document.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Codebase Engineering Manual")
    r.bold = True
    r.font.color.rgb = RGBColor.from_string(NAVY)

    p = document.add_paragraph(style="Subtitle")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Zero knowledge → professional implementation, operation, testing, and controlled evolution")

    add_figure(
        document,
        REPO / "docs" / "baseline" / "P03_IFV" / "assets" / "system-architecture.png",
        "Cinerion system architecture at the Prototype 1 boundary",
        "Architecture diagram showing the operator portal, Control Core, EdgeLink, database and identity services, controller layer, and physical-cell boundary.",
        width=6.15,
    )

    meta = add_table(
        document,
        ["Field", "Value"],
        [
            ["Project", "Cinerion (permanent engineering namespace CH1)"],
            ["Software baseline", SOFTWARE],
            ["Governing baseline", REVISION],
            ["Owner", OWNER],
            ["Manual scope", "Application, infrastructure, contracts, simulator, embedded, PLC, tests, and developer workflows"],
            ["Generated", date.today().isoformat()],
            ["Classification", "Confidential engineering source — redaction review required before publication"],
        ],
        [2300, 7060],
    )
    for row in meta.rows:
        row.cells[0].paragraphs[0].runs[0].bold = True
    add_callout(
        document,
        "Safe starting boundary",
        "This manual teaches the complete codebase, but it does not authorise hazardous energisation. Prototype 1 is simulator-first. No PLC output, ESP32 actuator GPIO, RFID reader, machine I/O, or hazardous power is connected until the later hardware, safety, HIL/FAT, and independent-review gates are satisfied.",
        kind="safe",
    )
    document.add_page_break()


CHAPTERS = [
    ("ch1", "1. How to use this manual"),
    ("ch2", "2. Repair Ubuntu and complete setup"),
    ("ch3", "3. Foundations from zero knowledge"),
    ("ch4", "4. What Cinerion is and what it must never do"),
    ("ch5", "5. Architecture and trust boundaries"),
    ("ch6", "6. Repository, languages, and build system"),
    ("ch7", "7. Contracts, HTTP API, and versioning"),
    ("ch8", "8. CommandGuard and the production domain"),
    ("ch9", "9. Quality records and tamper-evident audit"),
    ("ch10", "10. PostgreSQL persistence and tenant isolation"),
    ("ch11", "11. Authentication, authorization, and credentials"),
    ("ch12", "12. EdgeLink and industrial communications"),
    ("ch13", "13. Operator portal and universal UI"),
    ("ch14", "14. Containers and local infrastructure"),
    ("ch15", "15. Embedded controller and Arduino I/O"),
    ("ch16", "16. Siemens PLC source"),
    ("ch17", "17. Testing, traceability, CI, and releases"),
    ("ch18", "18. How to change the project safely"),
    ("ch19", "19. Roadmap from Prototype 1 to the final system"),
    ("ch20", "20. Troubleshooting playbook"),
    ("ch21", "21. Professional learning path"),
    ("ch22", "22. Complete file-by-file code atlas"),
    ("ch23", "23. Glossary and authoritative references"),
]


def add_navigation(document: Document, sources: Sequence[SourceFile]) -> None:
    add_heading(document, "Navigation and scope", 1, "navigation", 1)
    add_para(
        document,
        "This manual is written in learning order. Read Chapters 1–6 before changing code; use Chapters 7–17 while implementing; use Chapter 18 as the change checklist; and use Chapter 22 when you need to understand one exact file or line. The source atlas is generated from this repository, so paths and line numbers correspond to the delivered baseline.",
    )
    add_heading(document, "Clickable chapter map", 2)
    for anchor, title in CHAPTERS:
        p = document.add_paragraph(style="List Number")
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.first_line_indent = Inches(-0.15)
        add_internal_link(p, title, anchor)

    categories: dict[str, list[SourceFile]] = {}
    for source in sources:
        categories.setdefault(source.kind, []).append(source)
    add_heading(document, "Coverage statement", 2)
    add_table(
        document,
        ["Area", "Files", "Source lines", "How covered"],
        [
            [kind, str(len(files)), f"{sum(f.lines for f in files):,}", "Purpose, change rules, notable lines, and source listing or regeneration rule"]
            for kind, files in sorted(categories.items())
        ],
        [2800, 900, 1200, 4460],
    )
    add_callout(
        document,
        "What is intentionally not reproduced",
        "The 42 controlled-document bodies, package dependencies under node_modules, compiled binaries, cache folders, and generated Expo bundles are not copied into this manual. They are inputs or products, not authored application logic. Their controlling files, checksums, generation commands, and safe modification rules are explained. Every meaningful authored code/configuration file is covered individually.",
        kind="info",
    )
    document.add_page_break()


def chapter_1(document: Document) -> None:
    add_heading(document, CHAPTERS[0][1], 1, "ch1", 101)
    add_para(document, "You do not need to understand the complete stack before you begin. You do need to know which layer owns a decision and how to prove a change did not weaken another layer. That is the professional habit this manual teaches.")
    add_heading(document, "Three reading modes", 2)
    add_table(
        document,
        ["Mode", "Use it when", "Read"],
        [
            ["First setup", "The workstation or project will not start", "Chapter 2, then Chapter 20"],
            ["Learning", "A term or technology is unfamiliar", "Chapters 3–17 in order"],
            ["Making a change", "You know the goal and need exact paths", "Chapter 18 recipe, then Chapter 22 file entry"],
            ["Release review", "You need evidence that an increment is ready", "Chapters 17 and 19"],
        ],
        [1600, 3420, 4340],
    )
    add_heading(document, "The five questions to ask before editing", 2)
    add_bullets(
        document,
        [
            "What requirement or user outcome is changing? A file edit without an intended behavior is just activity.",
            "Which layer owns the rule: UI, API transport, application orchestration, domain, persistence, EdgeLink, firmware, PLC, or infrastructure?",
            "Which trust boundary is crossed? Any boundary requires validation, authentication, freshness, and explicit failure behavior.",
            "What is the negative test? A guarded system is defined as much by what it rejects as by what it accepts.",
            "What evidence proves completion? Code review, tests, traceability, build output, and—later—HIL/FAT evidence are different things.",
        ],
        numbered=True,
    )
    add_callout(document, "Rule of ownership", "Put a rule in the lowest layer that has enough information to enforce it reliably. The portal may explain why a command is blocked; the browser must not be the only place that blocks it. Production authority belongs in the Control Core and local controller boundary.", kind="concept")


def chapter_2(document: Document) -> None:
    add_heading(document, CHAPTERS[1][1], 1, "ch2", 102)
    add_para(document, "The supplied screenshot shows two separate workstation problems. Node.js, npm, and g++ are healthy. The .NET executable starts but cannot find `/usr/lib/dotnet/host/fxr`; Docker is not available inside this WSL distribution. Neither fault is caused by Cinerion source code.")
    add_heading(document, "2.1 Diagnose before changing packages", 2)
    add_code(document, ". /etc/os-release\nprintf 'Ubuntu: %s (%s)\\n' \"$PRETTY_NAME\" \"$VERSION_CODENAME\"\ntype -a dotnet || true\nreadlink -f \"$(command -v dotnet)\" || true\ndpkg -l | awk '/dotnet|aspnetcore|netstandard/ {print $1, $2, $3}'\napt-cache policy dotnet-sdk-10.0 dotnet-hostfxr-10.0 dotnet-host\nprintf 'DOTNET_ROOT=%s\\n' \"${DOTNET_ROOT:-<unset>}\"")
    add_para(document, "The first two lines identify the distribution and codename. `type -a` finds every launcher on PATH. `readlink` resolves a symlink to its real executable. `dpkg -l` shows installed Debian packages. `apt-cache policy` shows which repository would supply the repair. `DOTNET_ROOT` reveals a user-level override that can hide or conflict with system packages.")

    add_heading(document, "2.2 Repair .NET 10 on Ubuntu 26.04", 2)
    add_code(document, "sudo dpkg --configure -a\nsudo apt-get --fix-broken install -y\nsudo add-apt-repository --remove -y ppa:dotnet/backports || true\nsudo apt-get update\nsudo apt-get install --reinstall -y \\\n+  dotnet-host \\\n+  dotnet-hostfxr-10.0 \\\n+  dotnet-runtime-10.0 \\\n+  aspnetcore-runtime-10.0 \\\n+  dotnet-sdk-10.0\n\nunset DOTNET_ROOT\nhash -r\ndotnet --info\ndotnet --list-sdks\ndotnet --list-runtimes")
    add_table(
        document,
        ["Command", "Why it is present"],
        [
            ["dpkg --configure -a", "Completes an interrupted package configuration before another install is attempted."],
            ["apt-get --fix-broken install", "Repairs dependency relationships that APT already knows are incomplete."],
            ["remove ppa:dotnet/backports", "Ubuntu 26.04 provides .NET 10 from its built-in feed; avoiding mixed feeds prevents mismatched host/runtime packages."],
            ["--reinstall host + hostfxr + runtimes + SDK", "Repairs the complete chain rather than replacing only the top-level SDK package."],
            ["unset DOTNET_ROOT; hash -r", "Stops the shell from selecting a stale user install or cached executable location."],
            ["--list-sdks / --list-runtimes", "Proves that both the compiler SDK and execution runtimes are present."],
        ],
        [2850, 6510],
    )
    add_callout(document, "Expected result", "`dotnet --version` must return a 10.x version. Cinerion's `global.json` asks for 10.0.100 and permits roll-forward within .NET 10. If the package repair fails, follow the user-local `dotnet-install.sh` fallback in `docs/implementation/WSL_SETUP.md`; do not keep adding unverified package feeds.", kind="safe")

    add_heading(document, "2.3 Enable Docker Desktop for this Ubuntu distribution", 2)
    add_para(document, "Open an Administrator PowerShell window on Windows, not an Ubuntu shell:")
    add_code(document, "wsl --update\nwsl --set-default-version 2\nwsl --list --verbose")
    add_bullets(document, [
        "In Docker Desktop, enable Settings → General → Use the WSL 2 based engine.",
        "Open Settings → Resources → WSL Integration and enable the exact Ubuntu distribution shown by `wsl --list --verbose`.",
        "Apply and restart Docker Desktop. If the integration page is absent, switch Docker Desktop to Linux containers.",
        "Run `wsl --shutdown` in PowerShell, reopen Ubuntu, and wait until Docker Desktop says the engine is running.",
    ], numbered=True)
    add_code(document, "docker version\ndocker compose version\ndocker info --format '{{.ServerVersion}}'\ndocker run --rm hello-world")
    add_callout(document, "One engine only", "Do not install a second Docker Engine inside Ubuntu while Docker Desktop is the selected engine. Two competing engines create different networks, volumes, contexts, and permissions, making failures appear random.", kind="warn")

    add_heading(document, "2.4 Finish Cinerion setup", 2)
    add_code(document, "cd ~/projects/Cinerion_Prototype1_0.1.0_P03_IFV\nchmod +x scripts/*.sh\n./scripts/doctor.sh\nnpm ci\n./scripts/verify.sh --strict\n./scripts/run-local.sh\n./scripts/smoke-api.sh")
    add_table(document, ["Checkpoint", "Pass condition", "If it fails"], [
        ["doctor", "Zero FAIL lines", "Repair the named prerequisite; do not continue with strict verification."],
        ["npm ci", "Exit code 0; lockfile unchanged", "Check Node 24.14.x, registry connectivity, and whether the extraction is complete."],
        ["strict verification", "Ends with `Cinerion Prototype 1 verification completed.`", "Read the first failing gate; later failures may be consequences."],
        ["startup", "Compose services become healthy", "Run `docker compose -f infrastructure/compose.yaml ps` and `logs --tail=200`."],
        ["smoke API", "Ends with `Cinerion API smoke checks passed.`", "Inspect API health and Control Core logs with the correlation ID."],
    ], [1700, 3600, 4060])
    add_heading(document, "2.5 Safe addresses", 2)
    add_bullets(document, [
        "Portal: http://localhost:8081",
        "API health: http://localhost:5080/api/v1/system/health",
        "Swagger catalogue: http://localhost:5080/swagger",
        "Stop without deleting named volumes: `./scripts/stop-local.sh`",
    ])
    add_para(document, "The portal and health response must visibly identify Simulation. If they do not, stop and inspect the runtime profile before sending any command.")


def chapter_3(document: Document) -> None:
    add_heading(document, CHAPTERS[2][1], 1, "ch3", 103)
    add_heading(document, "3.1 Files, processes, ports, and exit status", 2)
    add_para(document, "A file is stored data. A process is a running program with memory, environment variables, open files, and an exit status. A service is a long-running process that accepts work. A port is a numbered network endpoint on one computer. `localhost` means the same machine from the caller's network context. In WSL/Docker, understanding which context owns a port prevents most setup confusion.")
    add_table(document, ["Term", "Cinerion example", "Professional habit"], [
        ["Source file", "`CommandTransaction.cs`", "Edit intentionally, review the diff, and keep it under version control."],
        ["Process", "`dotnet Cinerion.Api.dll`", "Check exit code and logs; do not infer success because a window stayed open."],
        ["Container", "Control Core image", "Treat it as an isolated process package, not a smaller virtual machine."],
        ["Port", "5080 → HTTP API", "Bind locally in the laboratory; expose externally only behind reviewed controls."],
        ["Environment variable", "`CINERION_RUNTIME_PROFILE`", "Validate at startup; never put secrets in source or committed `.env` files."],
    ], [1700, 3000, 4660])
    add_heading(document, "3.2 Git and a controlled change", 2)
    add_para(document, "Git records content history. A commit should answer one engineering question and be reviewable. A branch isolates work; a tag marks an immutable release claim. Git is not a backup of secrets and it does not prove that code is correct—tests and review provide that evidence.")
    add_code(document, "git switch -c feat/persistent-command-store\ngit status --short\ngit diff --check\n./scripts/verify.sh --strict\ngit add <intentional-files>\ngit commit -m \"feat(control-core): persist command transactions\"")
    add_heading(document, "3.3 Compiler, runtime, package manager, and build", 2)
    add_table(document, ["Tool", "Meaning", "Cinerion use"], [
        ["Compiler", "Transforms source into executable or intermediate code", "C# compiler, TypeScript compiler, g++ for host firmware tests, TIA Portal SCL compiler"],
        ["Runtime", "Executes compiled or interpreted behavior", ".NET runtime, Node.js, browser/React Native, ESP-IDF/FreeRTOS, PLC scan cycle"],
        ["Package manager", "Resolves versioned third-party dependencies", "npm and NuGet; APT installs workstation tools"],
        ["Build", "Repeatable transformation from inputs to outputs", "Portal export, .NET publish, firmware host binaries, container images"],
    ], [1600, 3300, 4460])
    add_heading(document, "3.4 HTTP, JSON, API, and contracts", 2)
    add_para(document, "HTTP carries a request method, path, headers, and optional body; the server returns a status, headers, and body. JSON is a text encoding of objects, arrays, strings, numbers, booleans, and null. An API is the intentionally supported interaction surface—not every public method in the code. A contract defines shapes and meanings on both sides of a boundary.")
    add_table(document, ["Status family", "Meaning", "Cinerion interpretation"], [
        ["2xx", "Request accepted or completed", "The response still carries domain state; HTTP success does not mean machinery is permitted."],
        ["4xx", "Caller input, authentication, authorization, or state is invalid", "Reject with stable error code and attributable audit evidence where appropriate."],
        ["5xx", "Server or dependency failure", "Fail closed; preserve correlation ID and avoid leaking secrets."],
        ["501", "Operation is deliberately not implemented", "Used for controlled P03 operations that exist in the catalogue but are gated from Prototype 1."],
    ], [1400, 3300, 4660])
    add_heading(document, "3.5 State machines and invariants", 2)
    add_para(document, "A state machine names allowed states and transitions. An invariant is a condition that must always be true at a specific boundary. For Cinerion, a prepared command may exist without execution authority; execution requires a fresh credential, a new physical rising edge, a final interlock resample, and matching bindings. Writing this as a state machine makes forbidden shortcuts testable.")
    add_heading(document, "3.6 Hashes, signatures, encryption, and idempotency", 2)
    add_table(document, ["Concept", "What it provides", "What it does not provide"], [
        ["Cryptographic hash", "Fixed-size fingerprint; detects content change", "Identity, confidentiality, or proof of who created the data"],
        ["Digital signature", "Integrity plus proof from control of a private key", "Secrecy of the signed message"],
        ["Encryption", "Confidentiality to authorized key holders", "Truth, authorization, or protection after a recipient decrypts and leaks content"],
        ["Idempotency key", "Safe retry maps to the same logical mutation", "Permission to perform the mutation or freshness of a physical event"],
    ], [1800, 3600, 3960])
    add_heading(document, "3.7 Database transaction and tenant", 2)
    add_para(document, "A database transaction groups operations so they commit together or not at all. A tenant is an isolated project or customer boundary. Cinerion uses project-scoped composite keys and PostgreSQL row-level security so an application bug is less able to connect or read records across projects. Application filtering remains useful but is not the only boundary.")
    add_heading(document, "3.8 Authentication versus authorization", 2)
    add_para(document, "Authentication answers who or what is presenting a credential. Authorization answers whether that authenticated subject may perform this operation on this resource in this state. Step-up authentication asks for stronger recent proof before a sensitive operation. Cinerion further binds local action to a physical credential/device and button event; those facts cannot be replaced by a browser role.")


def chapter_4(document: Document) -> None:
    add_heading(document, CHAPTERS[3][1], 1, "ch4", 104)
    add_para(document, "Cinerion is a modular industrial operations, quality, engineering, and command-control platform. Prototype 1 proves the architecture and difficult invariants against simulators. It is not a finished machine controller, safety PLC, validated manufacturing system, or production identity vault.")
    add_heading(document, "Non-negotiable invariants", 2)
    add_bullets(document, [
        "Remote software may prepare or cancel intent; it may not emulate local commitment.",
        "A local commit is valid only for the same project, cell, controller boot, command, challenge, sequence, state hash, and unexpired transaction.",
        "A held button is not a new confirmation. A fresh rising edge is required after preparation and credential proof.",
        "Permissives and relevant revisions are sampled again at the edge immediately before commitment.",
        "Restart, timeout, replay, mismatch, invalid calibration, NCR hold, or lost authority fails closed.",
        "`FAULT_LATCHED` is not remotely cleared; recovery is local and controlled.",
        "Audit evidence remains attributable and append-only; corrected facts create new records rather than rewriting history.",
        "The Siemens block and ESP32 prototype carry no safety credit. Independent machinery safety remains external and separately engineered.",
    ])
    add_figure(document, REPO / "docs/baseline/P03_IFV/assets/prepare-local-commit.png", "Prepare → credential → local commit authority sequence", "Sequence diagram showing remote command preparation, credential proof, physical button event, final interlock sampling, and local commitment.")
    add_heading(document, "Runtime profiles", 2)
    add_table(document, ["Profile", "Purpose", "Allowed authority"], [
        ["Development", "Fast local code development with explicit development headers", "No hazardous output; development identity only"],
        ["Simulation", "End-to-end behavior against simulated EdgeLink/controller", "Simulator injection may stand in for physical input only inside the labelled simulation boundary"],
        ["Production", "Future controlled deployment", "Prototype 1 fails startup because persistence, identity, devices, and release controls are incomplete"],
    ], [1600, 3600, 4160])


def chapter_5(document: Document) -> None:
    add_heading(document, CHAPTERS[4][1], 1, "ch5", 105)
    add_para(document, "Architecture is the allocation of responsibility and trust, not a drawing of folders. Each Cinerion component has a bounded reason to exist. If one component is compromised or unavailable, the remaining layers should fail predictably and avoid granting extra authority.")
    add_figure(document, REPO / "docs/baseline/P03_IFV/assets/security-zones.png", "Security zones and controlled conduits", "Security zoning diagram separating public presentation, application, identity, data, edge, controller, and physical zones.")
    add_table(document, ["Component", "Owns", "Does not own"], [
        ["Operator portal", "Presentation, navigation, operator comprehension, request initiation", "Authorization truth, local commitment, interlock authority"],
        ["Control Core", "Domain invariants, API, application orchestration, audit intent", "Live protocol details or certified safety"],
        ["PostgreSQL", "Transactional persistence, project isolation, immutable evidence", "Human identity proof or physical truth"],
        ["Keycloak", "Authentication, tokens, role claims, step-up mechanisms", "Machine permissives or command state"],
        ["EdgeLink", "Industrial protocol isolation, device capability, command/ack translation", "Business authorization or browser interaction"],
        ["ESP32/controller core", "Freshness, one-shot local input, final permissive sample, outputs-off default", "Enterprise identity or safety certification"],
        ["Siemens PLC", "Procedure sequencing and bounded handshake mirror", "Platform authorization or independent safety function"],
        ["Safety system", "Emergency stop and risk-reduction functions determined by machine assessment", "Implemented in this Prototype 1 repository"],
    ], [1850, 3750, 3760])
    add_heading(document, "Data flow of a guarded command", 2)
    add_bullets(document, [
        "The portal submits an authenticated prepare request with semantic command name, target, revisions, idempotency key, and expected state hash.",
        "Control Core authorizes the actor, validates scope and state, creates a short-lived transaction and challenge, and records audit evidence.",
        "A local cryptographic reader/device proves a fresh credential bound to that transaction and cell.",
        "The local controller observes a new physical button edge, resamples all required permissives and bindings, and commits only if every input still matches.",
        "EdgeLink transports acknowledgements and telemetry; Control Core advances the business state and preserves evidence.",
        "Any timeout, mismatch, restart, replay, link loss, or negative permissive cancels or faults without turning an output on.",
    ], numbered=True)
    add_figure(document, REPO / "docs/baseline/P03_IFV/assets/deployment-topology.png", "Simulator-first deployment topology", "Deployment diagram showing local portal and services, identity/data/protocol laboratory profiles, edge components, and a disabled physical boundary.")


def chapter_6(document: Document) -> None:
    add_heading(document, CHAPTERS[5][1], 1, "ch6", 106)
    add_para(document, "Cinerion is a monorepo: related services, applications, contracts, firmware, PLC source, infrastructure, tests, and traceability are versioned together. This makes an interface change reviewable across every producer and consumer.")
    add_table(document, ["Path", "Technology", "Responsibility"], [
        ["services/control-core", ".NET 10 / C#", "API, domain rules, application use cases, prototype store, target SQL"],
        ["services/edge-link", ".NET 10 / C#", "Industrial protocol boundary and simulator adapter"],
        ["apps/operator-portal", "Expo SDK 57 / React Native / TypeScript", "Universal web, Android, and iOS operator surfaces"],
        ["packages/contracts", "TypeScript / JSON Schema / OpenAPI", "Versioned shapes crossing processes and trust boundaries"],
        ["simulators/state-model", "TypeScript", "Independent executable specification and negative-path proof"],
        ["infrastructure", "Docker Compose / Keycloak / MQTT / nginx", "Reproducible laboratory services and hardening defaults"],
        ["firmware", "Portable C++ / ESP-IDF / Arduino", "Controller invariant core and framed I/O"],
        ["plc", "Siemens SCL", "S7-1200 G2 handshake and procedure skeleton"],
        ["scripts", "shell / PowerShell / Node", "One-command diagnosis, verification, startup, smoke test, packaging"],
        ["traceability", "generated JSON", "Requirement → test → implementation mapping"],
    ], [2550, 2800, 4010])
    add_heading(document, "Root dependency model", 2)
    add_para(document, "npm workspaces link the portal, contracts, and state model while preserving separate package scripts. NuGet central package management fixes .NET dependency versions in `Directory.Packages.props`. `Directory.Build.props` applies warnings-as-errors and analyzers consistently. `global.json` pins the .NET major baseline. This prevents each subproject from inventing a subtly incompatible toolchain.")
    add_heading(document, "Daily commands", 2)
    add_code(document, "npm run doctor\nnpm run verify\nnpm run contracts:generate\nnpm run contracts:validate\nnpm run test:state\nnpm run portal:typecheck\nnpm run portal:lint\nnpm run portal:export\n./scripts/verify.sh --strict")
    add_callout(document, "Do not develop in generated folders", "Never edit `node_modules`, `dist`, `.local`, `artifacts`, generated OpenAPI, generated traceability, or an extracted release copy when a clean source checkout exists. Edit the controlling source and regenerate.", kind="warn")


def chapter_7(document: Document) -> None:
    add_heading(document, CHAPTERS[6][1], 1, "ch7", 107)
    add_para(document, "A contract is a promise between independently changing components. Cinerion represents contracts in TypeScript for compile-time use, JSON Schema for runtime validation, and OpenAPI for HTTP discovery and client generation. Domain types remain richer than transport types: transport validates shape; domain validates meaning and state.")
    add_heading(document, "Contract workflow", 2)
    add_bullets(document, [
        "Decide whether the change is additive, compatible, conditionally compatible, or breaking.",
        "Update the controlled contract source and semantic documentation—not the generated OpenAPI output.",
        "Add valid and invalid examples, especially unknown fields, stale identifiers, wrong scope, replay, and boundary values.",
        "Regenerate and validate contracts deterministically.",
        "Update .NET request mapping, EdgeLink/device consumers, portal client types, simulator fixtures, and traceability.",
        "Retain old version support during an intentional migration window or publish a new major contract version.",
    ], numbered=True)
    add_heading(document, "HTTP boundary rules", 2)
    add_bullets(document, [
        "Use nouns for resources and HTTP methods for intent; use command endpoints for domain operations that are not CRUD.",
        "Require authentication by default and add explicit policies for role, project, cell, and step-up strength.",
        "Return stable machine-readable error codes, a human explanation, and the correlation ID; do not expose stack traces or secrets.",
        "Use idempotency keys for retryable mutations and reject a reused key with different payload semantics.",
        "Do not equate `202 Accepted` or `200 OK` with local execution. Command state remains explicit.",
        "Keep every P03 catalogue operation represented. A gated operation returns controlled `501`, not invented success.",
    ])
    add_heading(document, "Where to change an endpoint", 2)
    add_table(document, ["Concern", "File area"], [
        ["Transport schema", "packages/contracts and the controlled API catalogue source"],
        ["Route/method/status mapping", "services/control-core/src/Cinerion.Api/Endpoints"],
        ["Use-case orchestration", "services/control-core/src/Cinerion.Application"],
        ["Invariant", "services/control-core/src/Cinerion.Domain"],
        ["Persistence", "ICinerionStore plus an Infrastructure adapter and forward SQL migration"],
        ["Portal consumption", "generated client/data layer, then the relevant Expo Router screen"],
        ["Proof", "Domain/API tests, schema vectors, smoke test, traceability map"],
    ], [2900, 6460])


def chapter_8(document: Document) -> None:
    add_heading(document, CHAPTERS[7][1], 1, "ch8", 108)
    add_para(document, "CommandGuard is the hardest and most important code in Prototype 1. It intentionally separates remote intent from local physical authority. Its .NET aggregate, TypeScript executable model, portable C++ controller, and Siemens block share semantics but do not share authority. Independent implementations reduce the chance that one accidental shortcut becomes the specification.")
    add_figure(document, REPO / "docs/baseline/P03_IFV/assets/cell-state-machine.png", "Command and cell state model", "State diagram showing idle, prepared, credentialed, committed, executing, completed, cancelled, and fault-latched states with fail-closed transitions.")
    add_heading(document, "Prepare validation", 2)
    add_bullets(document, [
        "The actor is a human with the command role, strong/recent authentication, and matching project/cell scope.",
        "Project, cell, controller, command, challenge, idempotency, semantic command, and revision identifiers are well formed.",
        "The requested TTL is inside policy and the controller clock/state is acceptable.",
        "The button is not already held, required permissives are true, and the caller's expected state hash matches the canonical snapshot.",
    ])
    add_heading(document, "Credential proof validation", 2)
    add_para(document, "Credential proof is more than an RFID serial number. The intended final design uses a cryptographic credential and authenticated reader/device. The proof must bind the user, reader/device, transaction, challenge, cell, controller boot, time window, and cryptographic result. Copying a previously valid proof to a new transaction must fail.")
    add_heading(document, "Local commitment validation", 2)
    add_para(document, "The controller accepts a real physical observation—or an explicitly labelled simulator injection only in the simulation profile. It demands a fresh rising edge and matches every transaction binding. Immediately before commit it resamples project/cell scope, boot identifier, revisions, permissives, and state hash. This closes the time-of-check/time-of-use gap between remote preparation and local action.")
    add_heading(document, "Restart and fault behavior", 2)
    add_para(document, "A restart destroys transient authority. Prepared or credentialed transactions are cancelled because local memory, clocks, and physical conditions may no longer match. A fault becomes latched and cannot be cleared by a remote browser call. Local recovery is a separate operation with its own safe conditions and evidence.")
    add_callout(document, "Testing standard", "For every accepted transition, add at least one test for each rejected binding: wrong actor kind, role, project, cell, controller, boot ID, command ID, challenge, sequence, state hash, revision, credential, edge, permissive, time, and lifecycle state. This is why negative tests are part of the design, not optional cleanup.", kind="concept")


def chapter_9(document: Document) -> None:
    add_heading(document, CHAPTERS[8][1], 1, "ch9", 109)
    add_heading(document, "Quality lifecycle", 2)
    add_para(document, "Measurements are facts captured under a test definition and calibration context. A failure does not disappear after rework. It creates or contributes to an NCR hold. A controlled retest is linked to the same failed characteristic; the latest controlled result determines current disposition while historical failures remain immutable. Final release requires an independent authorized actor, preserving segregation of duties.")
    add_bullets(document, [
        "Validate units, limits, characteristic identity, equipment identity, calibration validity, part/work-order scope, and actor authority before recording a measurement.",
        "Preserve failed evidence. Rework and retest append new evidence; they never overwrite the first result.",
        "Require the retest characteristic to match the failed characteristic and link it explicitly to the NCR/rework decision.",
        "Determine current acceptance from the latest controlled result for each required characteristic, not from any historical pass or fail in isolation.",
        "Prevent the same actor from performing incompatible preparation, approval, or release duties where policy requires separation.",
    ])
    add_heading(document, "Tamper-evident versus immutable", 2)
    add_para(document, "The in-memory audit chain hashes each event together with the previous hash, making later alteration detectable if a trusted checkpoint exists. The target database adds append-only permissions and triggers, making ordinary mutation unavailable. Neither mechanism alone is magic: production evidence also needs trusted time, identities, key management, backup, monitoring, external anchoring, retention, and recovery tests.")
    add_table(document, ["Evidence property", "Prototype 1 mechanism", "Final-system addition"], [
        ["Attribution", "Actor context and audit metadata", "Strong OIDC/WebAuthn, device mTLS identity, identity lifecycle"],
        ["Integrity", "Canonical JSON + SHA-256 chain", "Signed checkpoints/external anchor and verified key custody"],
        ["Immutability", "No mutation methods in in-memory model", "Restricted DB roles, immutable triggers, WORM/retention controls where required"],
        ["Availability", "Process memory only", "Replicated backups, restore drills, evidence export, disaster recovery"],
        ["Interpretability", "Typed event and correlation fields", "Versioned schemas, controlled dictionaries, long-term reader tooling"],
    ], [1800, 3300, 4260])


def chapter_10(document: Document) -> None:
    add_heading(document, CHAPTERS[9][1], 1, "ch10", 110)
    add_para(document, "Prototype 1 currently uses `InMemoryCinerionStore`; restarting the Control Core loses operational state. The SQL migration is the designed target, not yet wired to an Npgsql adapter. The next engineering milestone is to make persistence real without moving domain rules into SQL or weakening database-enforced isolation.")
    add_heading(document, "Schema design principles", 2)
    add_bullets(document, [
        "Use UUID identifiers and project-scoped composite foreign keys so a row from Project A cannot reference a parent in Project B.",
        "Use narrow enums/check constraints for states whose allowed values are controlled.",
        "Store timestamps in UTC with timezone-aware types and retain the source/device time context when needed.",
        "Index foreign keys and the query shapes used by operator screens, queues, and evidence retrieval.",
        "Enable and force row-level security on project data; application roles must not own the tables or have `BYPASSRLS`.",
        "Treat applied migrations as history. Add `0002_...sql`; do not edit `0001_ch1_foundation.sql` after release use.",
    ])
    add_heading(document, "Request-scoped tenant context", 2)
    add_para(document, "After authentication, the server derives the project identity from trusted token/scope mapping—not from a free caller-selected header—and opens a transaction. It executes `SET LOCAL` for a project setting, then uses a non-owner database role subject to RLS. Every query in the transaction inherits the database policy. Connection-pool reuse makes `LOCAL` important: a persistent session setting could leak into the next request.")
    add_heading(document, "Npgsql adapter sequence", 2)
    add_bullets(document, [
        "Create `PostgresCinerionStore` under Infrastructure and implement the existing application port.",
        "Add Npgsql through central package management and configuration validation; never hard-code the connection string.",
        "Open a transaction, set trusted project context, load the aggregate plus version, apply the domain method, then update with an optimistic version predicate.",
        "Append audit/evidence within the same transaction as the protected mutation so business state cannot commit without its evidence.",
        "Map unique/version/RLS errors to stable domain/application outcomes; do not leak raw SQL messages to callers.",
        "Add clean-start, upgrade, restart-persistence, concurrency, cross-project, backup, and restore tests before replacing the prototype store by default.",
    ], numbered=True)
    add_callout(document, "RLS caveat", "PostgreSQL table owners and roles with `BYPASSRLS` can bypass row-level security unless carefully configured. `FORCE ROW LEVEL SECURITY`, non-owner runtime roles, privilege review, and explicit cross-tenant tests are all required.", kind="warn")


def chapter_11(document: Document) -> None:
    add_heading(document, CHAPTERS[10][1], 1, "ch11", 111)
    add_para(document, "Development headers are intentionally available only in Development/Simulation. They are not authentication and must never be exposed in a production profile. The target uses Keycloak OIDC for people, WebAuthn/passkeys and step-up for sensitive actions, and separate device identities with mTLS/hardware-backed keys.")
    add_table(document, ["Identity", "Credential", "Typical authorization input"], [
        ["Human operator", "OIDC session + passkey/WebAuthn or TOTP step-up", "Role, project, site/cell, authentication strength/age, segregation constraints"],
        ["Reader/controller device", "mTLS certificate + hardware-protected private key", "Registered device, project/cell assignment, capability, health, boot identity"],
        ["Service", "Workload identity/mTLS or tightly scoped client credentials", "Named service audience and least-privilege operation set"],
        ["Document recipient", "Vault authentication + per-document key envelope", "Classification, need-to-know, time/purpose, redaction release"],
    ], [1900, 3100, 4360])
    add_heading(document, "Authorization evaluation order", 2)
    add_bullets(document, [
        "Validate token signature, issuer, audience, expiry, not-before, and accepted algorithm.",
        "Resolve the internal actor and active assignment; do not trust arbitrary role strings without mapping.",
        "Check project/cell/resource scope and least-privilege role/policy.",
        "For sensitive operations, require fresh stronger authentication and compatible actor kind.",
        "Apply domain state, two-person/segregation, device, calibration, and physical-interlock conditions.",
        "Audit the decision without storing secrets, raw credentials, or unnecessary personal data.",
    ], numbered=True)
    add_heading(document, "Security is layered, not absolute", 2)
    add_para(document, "Professional security avoids a literal 100% guarantee. Cinerion targets defense in depth and zero implicit trust: strong identities, least privilege, segmented zones and conduits, encrypted transport and storage, hardware-backed keys, signed artifacts, secure boot/flash protection on suitable devices, monitoring, tamper-evident audit, controlled recovery, and redacted publication. Residual risk remains and is managed transparently.")


def chapter_12(document: Document) -> None:
    add_heading(document, CHAPTERS[11][1], 1, "ch12", 112)
    add_para(document, "EdgeLink prevents industrial protocol libraries and device-specific timing from leaking into the business domain. Control Core sends a versioned semantic command; an adapter translates only after device capability and deployment policy permit it. Prototype 1 enables the loopback simulator and makes live adapters throw a gated/not-authorized failure.")
    add_heading(document, "Protocol responsibilities", 2)
    add_table(document, ["Protocol", "Intended use", "Required gate"], [
        ["MQTT 5", "Authenticated device messages, telemetry, acknowledgements", "Per-device mTLS, ACL, topic/version rules, QoS/retry/idempotency tests"],
        ["OPC UA", "Structured PLC/device data and controlled methods where supported", "Certificate trust, namespace model, subscription recovery, PLC/licence confirmation"],
        ["Modbus TCP/RTU", "Legacy register access behind explicit mapping", "Read/write allowlist, range/type/endian definition, serial timing, HIL fault tests"],
        ["Simulator", "Deterministic integration and failure injection", "Simulation profile label and absolute separation from live authority"],
    ], [1450, 3500, 4410])
    add_heading(document, "Reliable message design", 2)
    add_bullets(document, [
        "Include protocol/schema version, message ID, correlation ID, project/cell/device identity, device boot ID, sequence, creation/expiry time, and semantic payload.",
        "Authenticate the connection and validate the message. Transport encryption alone does not prove the message is fresh or authorized.",
        "Deduplicate by bounded identifiers, reject stale sequence/boot combinations, and make acknowledgements name the exact accepted/rejected command.",
        "Use bounded queues, timeouts, backpressure, and circuit behavior. Infinite retries can become an unsafe command storm.",
        "Define connection-loss behavior per message class. Telemetry may be buffered; authority-bearing commands normally expire or cancel.",
    ])


def chapter_13(document: Document) -> None:
    add_heading(document, CHAPTERS[12][1], 1, "ch13", 113)
    add_para(document, "The operator portal is an Expo SDK 57 universal React Native application. Files under `src/app` become routes through Expo Router. Shared primitives and the application shell keep information hierarchy consistent across web, Android, and iOS. Prototype screens currently use labelled representative data; the next increment replaces it with an authenticated generated client.")
    add_heading(document, "Screen architecture", 2)
    add_table(document, ["Route", "Purpose", "Next integration"], [
        ["/", "Operations overview", "Live work orders, cell status, alarms, and freshness"],
        ["/command", "CommandGuard explanation and simulated interaction", "Prepare/cancel API only; local commit remains physically external"],
        ["/quality", "Measurements, holds, NCR and release visibility", "Authenticated quality endpoints and optimistic refresh"],
        ["/assets", "Assets and devices", "Live asset/device capability and maintenance data"],
        ["/explore", "Engineering gates and subsystem status", "Release gates and evidence links"],
        ["/audit", "Hash-chain and attributable event view", "Paged verified audit API with integrity status"],
    ], [1500, 3300, 4560])
    add_heading(document, "UI security and safety rules", 2)
    add_bullets(document, [
        "Make the runtime environment, connection/freshness, project/cell scope, and authority state continuously visible.",
        "Explain why an action is blocked and what safe next action is available. Never hide a critical state behind color alone.",
        "Treat all client data and route parameters as untrusted. Server authorization remains mandatory.",
        "Do not store long-lived secrets in JavaScript bundles or unprotected browser storage. Use the platform-appropriate secure token flow.",
        "A portal action may prepare/cancel intent; no route, debug flag, or development API may fabricate a physical button or credential event in Production.",
        "Meet keyboard, focus, contrast, label, screen-reader, motion, and responsive-layout requirements before release.",
    ])
    add_heading(document, "Replacing representative data", 2)
    add_bullets(document, [
        "Generate or write one typed API client from the controlled OpenAPI contract.",
        "Introduce an authentication/session provider and explicit loading, empty, stale, error, forbidden, and offline states.",
        "Move queries/mutations into a data layer; keep screens focused on rendering and interaction.",
        "Use abort/cancellation and correlation IDs; never let an old response overwrite a newer scope or command state.",
        "Add component, accessibility, contract-mock, and end-to-end tests before removing the Simulation representative-data banner.",
    ], numbered=True)


def chapter_14(document: Document) -> None:
    add_heading(document, CHAPTERS[13][1], 1, "ch14", 114)
    add_para(document, "Docker Compose defines a reproducible multi-service laboratory. The default profile remains small and safe. Optional profiles add PostgreSQL, Keycloak, and protocol services when their dependencies are being developed. Health checks and dependency conditions describe readiness; container startup order alone does not mean a service is usable.")
    add_heading(document, "Compose security defaults", 2)
    add_bullets(document, [
        "Bind laboratory ports to loopback rather than every network interface.",
        "Run as a non-root user where the image supports it; drop Linux capabilities and set `no-new-privileges`.",
        "Use read-only filesystems plus explicit writable temporary/volume mounts.",
        "Separate internal networks so databases and identity internals are not directly public.",
        "Load secrets from ignored local files or a secret manager; `.env.example` contains names and safe placeholders only.",
        "Pin and scan images, record SBOMs, and review upgrades—especially identity, database, broker, and reverse proxy images.",
    ])
    add_heading(document, "Profiles", 2)
    add_table(document, ["Profile", "Adds", "Use"], [
        ["default", "Control Core, EdgeLink simulator, portal", "Daily safe vertical-slice development"],
        ["data-lab", "PostgreSQL", "Persistence, migration, RLS, backup/restore work"],
        ["identity-lab", "Keycloak", "OIDC, roles, WebAuthn/step-up and token-mapping work"],
        ["protocol-lab", "Mosquitto and related protocol services", "mTLS, ACL, retry, disconnect, and device simulation"],
    ], [1600, 3000, 4760])


def chapter_15(document: Document) -> None:
    add_heading(document, CHAPTERS[14][1], 1, "ch15", 115)
    add_para(document, "The portable C++ state machine is deliberately independent of ESP-IDF and Arduino. This makes its fail-closed behavior testable on a normal workstation with warnings-as-errors. The ESP32 entry point adapts real time and inputs later; the Arduino codec handles bounded framed I/O. Hardware bindings are intentionally absent in this release.")
    add_heading(document, "Controller design principles", 2)
    add_bullets(document, [
        "Initialize every output off and every permissive false. Safe startup is explicit, not an assumption.",
        "Use fixed-size data and bounded queues in authority paths; avoid heap allocation, unbounded strings, and blocking network work in the control loop.",
        "Track controller boot identity and monotonic sequence. A reboot invalidates previous transient command authority.",
        "Debounce physical inputs while preserving the difference between a held level and a new rising edge.",
        "Use watchdogs, brownout behavior, timeouts, and deterministic fault states. Network loss must not continue an unconfirmed sequence.",
        "Keep cryptographic verification and key use in reviewed components, with device keys protected by hardware features where feasible.",
    ])
    add_heading(document, "From host model to ESP32-S3", 2)
    add_bullets(document, [
        "Keep `cell_state_machine` platform-neutral; add a thin ESP-IDF adapter for GPIO, monotonic time, storage, networking, and secure element/reader.",
        "Define the low-voltage bench I/O list and electrical protection before assigning pins. Use dummy loads and current-limited supply.",
        "Enable and validate secure boot, flash encryption, signed firmware, anti-rollback, protected provisioning, and debug-lock policy for the selected hardware lifecycle.",
        "Add unit, property/fuzz, restart/power-loss, replay, timing, noisy-input, watchdog, and HIL tests.",
        "Do not connect actuators or machinery until the separate safety, wiring, HIL/FAT, and review gates are closed.",
    ], numbered=True)


def chapter_16(document: Document) -> None:
    add_heading(document, CHAPTERS[15][1], 1, "ch16", 116)
    add_para(document, "The PLC source targets the entry-level Siemens SIMATIC S7-1200 G2 CPU 1212C class and is intended for STEP 7 Basic/TIA Portal. The exact order code, output type, supply, expansion, communications, and licensing remain procurement decisions. SCL files in the repository are source representations; they still need a controlled TIA project, compile, symbol allocation, PLCSIM, HIL, and later independent review.")
    add_heading(document, "PLC scan-cycle mental model", 2)
    add_para(document, "A PLC repeatedly reads inputs, executes program logic, and updates outputs. State persists in function-block instance data. Edge detection therefore requires memory of the previous scan. Timers are IEC blocks with state. Code order within a scan matters, but external physical safety must not depend on ordinary standard logic executing perfectly.")
    add_heading(document, "Block allocation", 2)
    add_table(document, ["Source", "Responsibility", "Key rule"], [
        ["UDT_CH1_Command", "Transaction/command bindings", "Carry exact identifiers, sequence, expiry, revisions, and expected state"],
        ["UDT_CH1_Permissives", "Named permissive set", "A missing/unknown permissive resolves false"],
        ["FB_CH1_CommandGuard", "Prepare/proof/local-edge/recheck handshake", "Replay, held input, mismatch, timeout, or changed permissive rejects"],
        ["FB_CH1_Procedure", "Bounded example procedure", "Stop/watchdog/permissive loss drives output off and may latch fault"],
    ], [2400, 3450, 3510])
    add_callout(document, "No safety credit", "These blocks demonstrate application control semantics. Emergency stop, guard monitoring, safe torque off, safety integrity/performance level, reset behavior, and contactor feedback require machine-specific risk assessment and appropriate safety-rated architecture.", kind="danger")


def chapter_17(document: Document) -> None:
    add_heading(document, CHAPTERS[16][1], 1, "ch17", 117)
    add_para(document, "A professional release is a claim supported by reproducible evidence. Cinerion's verification script orders checks from cheap structural proofs to compiled tests, then infrastructure validation. Strict mode refuses to skip .NET or Docker. CI repeats the gate in a clean environment and records dependency/security evidence.")
    add_table(document, ["Gate", "What it proves", "What it cannot prove"], [
        ["Baseline checksum", "Frozen P03 inputs did not change unnoticed", "That the baseline itself is correct or approved for production"],
        ["Schema/OpenAPI validation", "Contracts are structurally consistent", "That every consumer implements the semantics correctly"],
        ["Domain/model tests", "Specified transitions and rejections behave in code", "Real timing, wiring, electromagnetic behavior, or human factors"],
        ["Portal type/lint/export", "UI source compiles and routes export", "Accessibility, usability, authenticated integration, or operator competence"],
        ["Firmware host tests", "Portable state logic compiles and passes vectors", "ESP32 electrical behavior or HIL conditions"],
        ["Compose config/smoke", "Topology resolves and API responds", "Long-duration reliability, recovery, scale, or security accreditation"],
        ["HIL/FAT later", "Real components and failure scenarios satisfy acceptance criteria", "All future field conditions; operational monitoring remains necessary"],
    ], [1800, 3500, 4060])
    add_heading(document, "Traceability", 2)
    add_para(document, "The implementation map gives each of 87 requirements one or more code/evidence locations and one controlled verification case. It is generated from controlled data plus repository mappings and then checked for missing, duplicate, or orphaned identifiers. Traceability is a navigation and completeness control; a mapping does not mean the test has passed.")
    add_heading(document, "Definition of done for a code change", 2)
    add_bullets(document, [
        "Requirement/outcome and acceptance criteria are explicit.",
        "Threat, safety, privacy, data, and compatibility impacts are assessed at the appropriate depth.",
        "Focused tests cover success, boundary, rejection, restart/retry, and authorization behavior.",
        "Documentation, contracts, migration, portal states, and traceability change together where applicable.",
        "No secrets, caches, build products, debug authority, or unexplained dependency drift enter the diff.",
        "Strict verification, review, and required later-stage evidence pass; remaining limitations are stated honestly.",
    ])


CHANGE_RECIPES = [
    ("Add a domain field", "Contract/domain/storage/UI must evolve together only if the field crosses those boundaries.", [
        "Define its meaning, owner, source, units/format, required/optional rule, sensitivity, lifecycle, and compatibility default.",
        "Add the domain value/validation first; add focused tests for missing, invalid, boundary, and old-version input.",
        "If persisted, create a forward SQL migration and update the store adapter. Backfill only with a justified value or nullable migration stage.",
        "If transported, update controlled schema/OpenAPI and every producer/consumer. Regenerate rather than editing generated output.",
        "Expose it in the portal with loading/error/stale/permission behavior and accessible labeling.",
    ]),
    ("Add a new API operation", "Use this only when the operation cannot be represented by an existing controlled endpoint.", [
        "Add/approve the operation in the controlled API catalogue with method, path, request, response, errors, roles, audit, idempotency, and rate policy.",
        "Add schema/types, generate OpenAPI, and create contract vectors.",
        "Implement domain invariant and application use case before mapping the endpoint.",
        "Require authentication/authorization explicitly and return stable problem responses with correlation ID.",
        "Add API/domain tests, smoke coverage where appropriate, and requirement/test/implementation traceability.",
    ]),
    ("Add a database entity", "Persistence is an adapter for a domain concept, not a shortcut around domain modeling.", [
        "Model identity, project ownership, lifecycle, constraints, retention, privacy/classification, and deletion/legal-hold rules.",
        "Create the next numbered migration with composite tenant foreign keys, constraints, indexes, RLS, grants, and immutability where required.",
        "Implement port methods with parameterized SQL, transaction context, cancellation, optimistic concurrency, and safe error mapping.",
        "Test clean migration, upgrade, cross-tenant rejection, concurrency, backup, restore, and query plans for expected workloads.",
    ]),
    ("Add a portal screen", "A route should expose an operator task, not merely mirror a database table.", [
        "Create the file under `apps/operator-portal/src/app`; the filename becomes the Expo Router route.",
        "Build from shared primitives and theme tokens; define permission, loading, empty, stale, offline, error, and success states.",
        "Use the authenticated typed API data layer. Never put authorization or physical-commit authority only in the component.",
        "Add navigation, deep-link behavior, keyboard/focus/screen-reader tests, responsive checks, and route export validation.",
    ]),
    ("Add a role or permission", "Roles are a manageable input to policy, not a complete policy by themselves.", [
        "Define the business duty, incompatible duties, resource scope, step-up requirement, approval owner, review interval, and emergency-access rule.",
        "Add it to Keycloak configuration and server-side mapping; reject unknown/unmapped claims.",
        "Enforce it at the endpoint/application/domain boundary and ensure database/device access remains least privilege.",
        "Test allowed, denied, cross-project, stale assignment, disabled user, and segregation scenarios. Update the portal only for comprehension.",
    ]),
    ("Add an industrial protocol adapter", "An adapter is enabled only after its contract, threat, failure, and HIL evidence exist.", [
        "Implement `IProtocolAdapter` behind a deployment feature gate and explicit device capability.",
        "Define certificates/keys, endpoint trust, message/register namespace, type/endian/unit mapping, timeouts, retries, idempotency, reconnect, and loss behavior.",
        "Use bounded channels and observability without logging secrets or authority-bearing raw credentials.",
        "Create simulators and negative tests for malformed, stale, replayed, duplicated, delayed, reordered, unauthorized, and disconnected traffic.",
        "Pass security review and HIL before changing the gated live adapter to an enabled implementation.",
    ]),
    ("Add a controller input or output", "This is a hardware/safety-impacting change even when the code edit looks small.", [
        "Update the controlled I/O list, electrical drawing, polarity, safe state, diagnostic coverage, power domain, and risk assessment first.",
        "Add a named typed input to the portable model; default it false/off and define debounce, timeout, plausibility, and fault behavior.",
        "Add host tests and simulator vectors before mapping any ESP32 pin or PLC address.",
        "Verify on a current-limited extra-low-voltage bench with dummy loads, then HIL/FAT and independent review before hazardous use.",
    ]),
    ("Change the command handshake", "Treat this as a high-risk architecture change requiring cross-implementation proof.", [
        "State the attack/failure being solved and update the invariant and threat model before code.",
        "Update the .NET aggregate, TypeScript executable model, C++ controller, PLC semantic mirror, contracts, and documentation independently.",
        "Add adversarial vectors for every binding and time/restart/replay condition; never weaken a check to make integration easier.",
        "Require focused security/safety review, strict CI, simulator evidence, and later HIL before release.",
    ]),
]


def chapter_18(document: Document) -> None:
    add_heading(document, CHAPTERS[17][1], 1, "ch18", 118)
    add_para(document, "Use the following recipes as impact maps. They tell you what normally changes together and prevent the common mistake of modifying only the visible screen or only the database. Exact file entries and line-numbered source are in Chapter 22.")
    for title, lead, steps in CHANGE_RECIPES:
        add_heading(document, title, 2)
        add_para(document, lead)
        add_bullets(document, steps, numbered=True)
        add_para(document, "Verification: run the nearest focused tests throughout development, then `./scripts/verify.sh --strict`; add HIL/FAT or independent review when the recipe crosses those gates.", bold_lead="Verification:")


def chapter_19(document: Document) -> None:
    add_heading(document, CHAPTERS[18][1], 1, "ch19", 119)
    add_para(document, "Prototype 1 proves structure and invariants but intentionally leaves production authority gated. The roadmap below is ordered by dependency and risk. A later phase may be designed in parallel, but it should not be declared complete before its predecessor evidence exists.")
    add_table(document, ["Phase", "Build", "Exit evidence"], [
        ["0 — Workstation", "Repair .NET/Docker, strict verification, private Git baseline", "Doctor and strict gate pass on a clean WSL workstation"],
        ["1 — Persistent authenticated slice", "Npgsql store, migrations, Keycloak OIDC/WebAuthn, server policies, live portal client", "Restart persistence, tenant isolation, authorization, backup/restore, end-to-end command prepare/cancel"],
        ["2 — Edge simulation", "Control Core ↔ EdgeLink contracts, device registry, simulator fault injection, telemetry", "Replay/disconnect/restart/capability/queue tests and operational observability"],
        ["3 — Extra-low-voltage bench", "ESP32-S3, cryptographic reader, button, lamps, dummy loads", "Reviewed wiring, host/device/HIL evidence, secure provisioning, outputs remain non-hazardous"],
        ["4 — PLC laboratory", "Exact S7-1200 G2 variant, TIA project, PLCSIM and bench I/O", "Procurement decisions closed, compiled project, PLCSIM/HIL scenarios and protocol evidence"],
        ["5 — Prototype 1 review", "Integrated demo, failure campaign, independent technical reviewer appointed", "Blocking review actions closed; updated controlled baseline/release record"],
        ["6 — Machine-specific engineering", "Risk assessment, safety functions, guarded cell, procedures, operator training", "Approved safety design, FAT/SAT, regulatory/organizational evidence"],
        ["7 — Production hardening", "HA/DR, monitoring, key/document vault, privacy/retention, signed releases, operations", "Pen test, restore drill, incident/recovery exercise, production approval"],
        ["8 — Controlled publication", "Metadata-scrubbed redacted showcase extracts", "Four-eyes redaction review proves confidential backbone is absent"],
    ], [1450, 4250, 3660])
    add_heading(document, "The next step after setup", 2)
    add_callout(document, "Recommended Increment 0.2", "Implement the persistent authenticated vertical slice: wire PostgreSQL/Npgsql, Keycloak OIDC and WebAuthn step-up, project/cell policies, a generated portal client, and EdgeLink simulator integration. Prove state survives restart, cross-project access is denied by both server and database, backup/restore works, and the browser still cannot perform local commitment.", kind="safe")


def chapter_20(document: Document) -> None:
    add_heading(document, CHAPTERS[19][1], 1, "ch20", 120)
    issues = [
        ("dotnet: host/fxr does not exist", "Partial/mixed .NET host installation", "Run the package-chain repair in Chapter 2; inspect `type -a dotnet` and `DOTNET_ROOT`; then prove SDK and runtimes."),
        ("docker: command not found in this WSL 2 distro", "Docker Desktop WSL integration is disabled for this Ubuntu instance", "Enable the exact distribution, Apply & restart, `wsl --shutdown`, reopen Ubuntu."),
        ("Cannot connect to the Docker daemon", "CLI is integrated but Docker Desktop engine is stopped/not ready or context is wrong", "Start Docker Desktop, wait for Engine running, inspect `docker context show` and `docker info`."),
        ("npm ci says lockfile/package mismatch", "A package manifest changed without refreshing the lockfile or wrong Node/npm is selected", "Select Node 24.14.x, intentionally run npm install only when updating dependencies, review lockfile diff, then rerun npm ci."),
        ("global.json SDK not found", "No compatible .NET 10 SDK or PATH selects a different install", "Run `dotnet --list-sdks`, repair/install .NET 10, remove stale `DOTNET_ROOT`, restart shell."),
        ("Port already allocated", "Another process/container owns 5080 or 8081", "Run `docker compose ... ps`, `ss -ltnp`, stop the intended owner, or change a laboratory host binding consistently."),
        ("API 401", "Missing/invalid authentication", "In Development use only documented dev headers; in identity profile inspect issuer/audience/expiry/clock and login flow."),
        ("API 403", "Authenticated actor lacks role/scope/step-up or violates segregation", "Inspect policy inputs and correlation ID. Do not weaken the policy; fix assignment or requested scope."),
        ("API 409", "State, revision, idempotency, or optimistic-concurrency conflict", "Reload current resource, compare expected state/hash/revision, and retry only with the correct semantic intent."),
        ("API 501", "Operation is intentionally gated in Prototype 1", "Find the endpoint in the deferred catalogue and complete its implementation/review gate; do not replace 501 with fake success."),
        ("Command expires/cancels", "TTL, restart, lost scope, changed permissive/hash/revision, or stale local event", "Treat as correct fail-closed behavior; identify which binding changed and prepare a new transaction after conditions are safe."),
        ("Portal shows data but API is down", "Prototype screens still contain representative data", "Use the Simulation label; implement the authenticated live data layer before treating a screen as operational truth."),
        ("RLS returns no rows", "Project context missing/wrong or policy denies access", "Inspect trusted request-to-database context and runtime DB role; never bypass RLS as a quick fix."),
        ("Firmware test compile fails", "Compiler missing or warnings-as-errors found a portability defect", "Install build-essential; read the first warning/error; fix source rather than suppressing broad warning classes."),
    ]
    add_table(document, ["Symptom", "Likely cause", "Safe response"], issues, [2550, 3100, 3710])
    add_heading(document, "Evidence to send when asking for help", 2)
    add_bullets(document, [
        "The exact command, working directory, and complete output from the first failure.",
        "`./scripts/doctor.sh --soft` output and the relevant service logs, with secrets removed.",
        "Ubuntu version/codename, `wsl --list --verbose`, Docker Desktop version/status, Node/npm, and `dotnet --info`.",
        "The correlation ID for an API error and the smallest reproducible request with credentials/tokens redacted.",
        "What changed since the last passing strict gate and the focused test you expected to pass.",
    ])


def chapter_21(document: Document) -> None:
    add_heading(document, CHAPTERS[20][1], 1, "ch21", 121)
    add_para(document, "Professional skill grows fastest when each concept is read, changed in a safe exercise, and proved by a test. The sequence below uses Cinerion as the laboratory while keeping hardware authority disabled.")
    curriculum = [
        ("1. Linux/WSL and shell", "Paths, permissions, processes, environment, pipes, exit status", "Explain every line of doctor.sh; add one read-only check and test both pass/fail output."),
        ("2. Git and review", "Branches, commits, diffs, tags, ignore rules", "Make the doctor change in a branch; produce a focused diff and commit message."),
        ("3. TypeScript", "Types, modules, unions, async, tests", "Add a non-authority display field to the executable model and tests."),
        ("4. HTTP/contracts", "Methods, status, JSON Schema, OpenAPI, compatibility", "Add an optional read-only response field through generator, validation, and a mock client."),
        ("5. C#/.NET architecture", "DI, records, exceptions, async, layered design", "Trace one command request from endpoint to service to aggregate/store and back."),
        ("6. Domain modeling", "Invariants, aggregates, state machines, idempotency", "Write a failing replay test, then identify the exact guard that makes it pass."),
        ("7. PostgreSQL", "DDL, keys, transactions, indexes, RLS", "Start data-lab; create a disposable schema copy and prove Project A cannot read Project B."),
        ("8. Identity/security", "OIDC, tokens, WebAuthn, mTLS, least privilege", "Configure two test users and prove role, scope, and step-up denial paths."),
        ("9. React Native/Expo", "Components, state, file routing, accessibility", "Replace one representative metric with a typed mocked query and all UI states."),
        ("10. Containers/operations", "Images, networks, volumes, health, logs", "Draw effective Compose networks and intentionally observe/recover one service failure."),
        ("11. Embedded C++", "Fixed data, timing, edges, watchdogs, host tests", "Add a noisy/held-button vector without assigning any GPIO."),
        ("12. PLC", "Scan cycle, FB/UDT/timer/edge, PLCSIM", "Import blocks into an isolated project and execute only published PLCSIM scenarios."),
        ("13. Systems engineering", "Traceability, hazards, V&V, evidence, release", "Take one requirement through design, code, negative test, evidence, and review record."),
    ]
    add_table(document, ["Stage", "Learn", "Safe exercise"], curriculum, [1750, 3100, 4510])
    add_heading(document, "How to know you understand a file", 2)
    add_bullets(document, [
        "You can state its single responsibility and name the layer that owns it.",
        "You can identify its inputs, outputs, trust assumptions, and failure behavior.",
        "You can name which file calls it and which dependency it calls.",
        "You can predict the effect of a change and the tests that should fail first.",
        "You can explain what must not be added to it because another layer owns that concern.",
        "You can make a small change, prove it, review its diff, and reverse it without damaging unrelated work.",
    ])


GUIDED_BLOCKS: dict[str, list[tuple[str, str]]] = {
    "services/control-core/src/Cinerion.Api/Program.cs": [
        ("Startup/profile selection", "Reads the runtime profile and refuses an incomplete Production configuration. This protects deployment from silently inheriting permissive development behavior."),
        ("Dependency registration", "Maps interfaces to application/domain/infrastructure implementations. Prototype 1 chooses the in-memory adapter; the next slice will choose PostgreSQL by validated configuration."),
        ("Authentication and authorization", "Development headers are registered only in allowed profiles; OIDC is the target identity path. Every endpoint group still applies authorization."),
        ("Middleware and endpoints", "Correlation, exception handling, CORS, Swagger, seeding, and route mapping execute in intentional order. Middleware order is observable behavior."),
    ],
    "services/control-core/src/Cinerion.Domain/Commands/CommandTransaction.cs": [
        ("Aggregate creation", "A prepared transaction captures every authority-bearing binding as immutable data and creates a short expiry window."),
        ("Credential proof", "Advances only when user, credential device, cryptographic result, transaction, challenge, scope, and time all match."),
        ("Local commit", "Demands a new local edge and a final recheck of boot, sequence, revisions, state hash, scope, and permissives."),
        ("Lifecycle/fault/restart", "State-specific methods prevent impossible transitions. Timeout or restart removes authority; remote code cannot clear a latched fault."),
    ],
    "services/control-core/src/Cinerion.Application/Commands/CommandService.cs": [
        ("Input orchestration", "Loads actor/cell/transaction data through ports and delegates authority decisions to the aggregate."),
        ("Concurrency/idempotency", "Serializes a guarded mutation path and maps retries to one logical transaction without accepting a changed payload."),
        ("Audit on allow and reject", "Records attributable decisions, including denied attempts, without turning the audit component into the domain authority."),
        ("Persistence boundary", "Saves the updated aggregate with expected version so concurrent callers cannot silently overwrite one another."),
    ],
    "services/control-core/src/Cinerion.Domain/Quality/QualityRecords.cs": [
        ("Measurement validation", "Checks units, limits, calibration validity, identities, and result semantics before recording evidence."),
        ("NCR and retest", "Preserves original failure, links controlled rework/retest, and ensures the retest addresses the same characteristic."),
        ("Release", "Uses the latest controlled result per required characteristic and requires an independent authorized release actor."),
    ],
    "services/control-core/src/Cinerion.Domain/Audit/AuditChain.cs": [
        ("Canonical event", "Stable field ordering and serialization prevent harmless map-order differences from changing the event fingerprint."),
        ("Append", "Each event includes the previous hash, creating a chain whose later modification is detectable."),
        ("Verify", "Recomputes the chain from genesis and reports any mismatch; production still needs an external trusted checkpoint."),
    ],
    "services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0001_ch1_foundation.sql": [
        ("Extensions/schema/types", "Creates the isolated namespace and controlled database types used by later tables."),
        ("Core master/operations tables", "Projects, sites, cells, assets, devices, products, work orders, parts, and commands use project-scoped identity."),
        ("Quality/evidence tables", "Measurements, calibration, NCR, release, telemetry, resources, documents, and audit retain attributable history."),
        ("Foreign keys and indexes", "Composite project foreign keys prevent cross-tenant linkage; indexes support expected retrieval paths."),
        ("Row-level security", "Policies default-deny rows outside the trusted project setting and are forced for runtime access."),
        ("Immutability", "Triggers reject update/delete on selected evidence tables; a correction must append a new controlled record."),
    ],
    "simulators/state-model/src/model.ts": [
        ("Types and canonical snapshot", "Defines a platform-independent vocabulary and state fingerprint matching the intended production semantics."),
        ("Prepare", "Rejects invalid identity/scope/freshness/revision/permissive/button conditions before issuing a challenge."),
        ("Credential and commit", "Proves transaction bindings, physical rising-edge semantics, and final state resampling."),
        ("Failure transitions", "Timeout, restart, cancellation, and local-only recovery make fail-closed behavior executable."),
    ],
    "firmware/shared/src/cell_state_machine.cpp": [
        ("Constructor/reset", "Sets outputs off and transient authority empty; reset semantics do not inherit an old transaction."),
        ("Prepare/proof", "Copies only bounded identifiers and accepts fresh sequences/bindings within the controller state."),
        ("Input edge/commit", "Observes physical level history and requires a new edge after the command is ready."),
        ("Tick/fault", "Monotonic time, expiry, permissive loss, fault latch, and local reset determine deterministic outputs."),
    ],
    "plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl": [
        ("Interface/state", "UDTs and retained instance variables make scan-to-scan bindings explicit."),
        ("Prepare", "Validates sequence, expiry, revision, state hash, permissives, and held-input conditions."),
        ("Credential/local edge", "Matches proof and detects a new physical input edge before committing."),
        ("Timeout/restart/fault", "Clears transient authority and commands outputs off when continuity cannot be trusted."),
    ],
    "infrastructure/compose.yaml": [
        ("Default services", "Runs only the simulator-safe portal, Control Core, and EdgeLink path required for everyday development."),
        ("Optional profiles", "Adds data, identity, and protocol laboratories only when their work is active."),
        ("Hardening", "Loopback ports, internal networks, dropped capabilities, read-only roots, and health checks limit accidental exposure."),
        ("Persistence", "Named volumes make laboratory service state explicit; stop and destructive volume removal are separate actions."),
    ],
    "apps/operator-portal/src/components/app-shell.tsx": [
        ("Navigation model", "Defines the universal route set and presents one stable information architecture."),
        ("Responsive shell", "Adapts navigation and content layout without changing authority or hiding environment state."),
        ("Environment/freshness", "Prominent labels help prevent representative simulation data from being mistaken for live machinery truth."),
    ],
    "scripts/doctor.sh": [
        ("Read-only checks", "Commands collect versions and availability without changing the workstation."),
        ("Semantic version checks", "Node and .NET are executed, not merely found, so a broken launcher is caught."),
        ("Docker three-part check", "CLI, Compose plug-in, and daemon are separate dependencies and receive different repair instructions."),
        ("Soft/strict behavior", "Interactive diagnosis may report all failures; strict setup returns non-zero so automation stops."),
    ],
    "scripts/verify.sh": [
        ("Preflight", "Runs the workstation doctor before spending time on project builds."),
        ("Fast deterministic gates", "Checks frozen inputs, contracts, executable model, traceability, and repository policy first."),
        ("Compiled gates", "Builds/tests portal, firmware, and .NET; strict mode treats missing tools as failure."),
        ("Infrastructure gate", "Validates Compose and makes Docker availability mandatory for a release claim."),
    ],
}


def generator_rule(source: SourceFile) -> tuple[str, str]:
    rules = {
        "package-lock.json": ("Root/workspace `package.json` files", "Use the verified Node/npm version, change dependency intent in package.json, run npm install, review the lock diff, and prove `npm ci`."),
        "packages/contracts/openapi/openapi.generated.yaml": ("Controlled API catalogue + `packages/contracts/scripts/generate-openapi.mjs`", "Run `npm run contracts:generate`; then `npm run contracts:validate` and verify the generated diff is deterministic."),
        "traceability/implementation-map.json": ("P03 requirement/test data + `scripts/generate-implementation-map.mjs`", "Run the implementation-map generator and `scripts/check-traceability.mjs`; never hand-edit a mapping result."),
        "RELEASE_MANIFEST.json": ("Release packaging process", "Regenerate during controlled packaging after all source and manual changes pass verification."),
    }
    return rules.get(source.rel, ("The owning generator or build process", "Regenerate from reviewed inputs and verify a clean deterministic diff."))


def add_source_entry(document: Document, source: SourceFile, index: int) -> None:
    anchor = f"file_{index}"
    add_heading(document, source.rel, 3, anchor, 2200 + index)
    mode = "Generated" if source.generated else ("Binary/non-text" if source.binary else "Authored text/source")
    add_table(document, ["Property", "Value"], [
        ["Area", source.kind],
        ["Type", plain_language_kind(source)],
        ["Status", mode],
        ["Size", f"{source.size:,} bytes; {source.lines:,} text lines"],
        ["SHA-256", file_sha256(source.path)],
    ], [1800, 7560])
    add_para(document, "Purpose: " + inferred_purpose(source), bold_lead="Purpose:")
    do, dont, verify = change_rule(source)
    add_table(document, ["Change guidance", "Rule"], [["Change here when", do], ["Do not", dont], ["Prove the change", verify]], [1900, 7460])

    if source.binary:
        add_callout(document, "Binary artifact", "There are no source lines to explain. Replace it only from an approved editable source at an appropriate resolution, preserve licensing/provenance, optimize the output, and rerun the consuming application build plus visual review.", kind="info")
        return

    text = safe_text(source.path)
    if source.generated:
        controller, command = generator_rule(source)
        add_heading(document, "How this file is produced", 4)
        add_para(document, f"Controlling source: {controller}", bold_lead="Controlling source:")
        add_para(document, f"Regeneration rule: {command}", bold_lead="Regeneration rule:")
        preview = text.splitlines()
        excerpt_lines = preview[:40] + (["… generated content omitted …"] if len(preview) > 80 else []) + (preview[-40:] if len(preview) > 80 else preview[40:])
        add_heading(document, "Representative generated excerpt", 4)
        add_code(document, "\n".join(excerpt_lines), numbered=False)
        return

    if source.rel in GUIDED_BLOCKS:
        add_heading(document, "Guided reading blocks", 4)
        add_table(document, ["Block", "How to reason about it"], GUIDED_BLOCKS[source.rel], [2500, 6860])

    notes = notable_lines(text, source.path.suffix)
    if notes:
        add_heading(document, "Notable lines", 4)
        add_table(document, ["Line", "Code", "Teaching note"], [[str(n), code, why] for n, code, why in notes], [700, 3500, 5160])

    add_heading(document, "Complete line-numbered source", 4)
    if source.size <= 40_000:
        add_code(document, text, numbered=True)
    else:
        add_callout(document, "Long supporting source", "This file is larger than the manual's full-listing threshold. It is not a runtime authority file. The manual preserves its exact checksum and shows the beginning/end; open the repository copy for the complete text so it remains searchable and editable.", kind="info")
        lines = text.splitlines()
        add_code(document, "\n".join(lines[:160]), numbered=True)
        add_para(document, f"… {max(0, len(lines) - 320):,} middle lines are available in the repository copy …")
        add_code(document, "\n".join(lines[-160:]), numbered=True, start=max(1, len(lines) - 159))


def chapter_22(document: Document, sources: Sequence[SourceFile]) -> None:
    add_heading(document, CHAPTERS[21][1], 1, "ch22", 122)
    add_para(document, "This atlas accounts for each meaningful file in the delivered source tree. Every authored text file receives its purpose, modification boundary, verification path, notable line explanations, and a complete line-numbered listing unless it is unusually large supporting tooling. Generated files receive their controlling source and regeneration rule. Binary assets receive provenance/replacement guidance.")
    add_callout(document, "Line-number rule", "Line numbers describe this P03/IFV Prototype 1 snapshot. They will move as the code evolves; use the path, symbol name, tests, and version-control diff as the durable references.", kind="info")
    grouped: dict[str, list[SourceFile]] = {}
    for source in sources:
        grouped.setdefault(source.kind, []).append(source)
    index = 0
    for kind in sorted(grouped):
        add_heading(document, kind, 2)
        add_para(document, f"{len(grouped[kind])} inventoried file(s) in this area.")
        for source in grouped[kind]:
            index += 1
            add_source_entry(document, source, index)


GLOSSARY = [
    ("Aggregate", "A domain object boundary that protects invariants across related state changes."),
    ("API", "An intentionally supported interface through which software components communicate."),
    ("Authentication", "Proof of an asserted human, device, or workload identity."),
    ("Authorization", "Decision that an authenticated actor may perform a particular action on a resource under current conditions."),
    ("Canonical JSON", "A deterministic JSON representation used so semantically equal data hashes to the same value."),
    ("Cell", "A bounded physical/automation work area in the Cinerion project hierarchy."),
    ("CI", "Continuous Integration: clean automated build/test/security checks for every controlled change."),
    ("Conduit", "A controlled communication path between security zones."),
    ("Correlation ID", "Identifier carried across logs/events so one operation can be traced through components."),
    ("Credential proof", "Fresh cryptographic evidence that an authorized local person/device participated in one transaction."),
    ("Domain", "The business/engineering rules and language independent of UI, transport, and storage details."),
    ("EdgeLink", "Cinerion service boundary that isolates industrial protocol and device integration."),
    ("Fail closed", "On ambiguity, error, missing data, restart, or loss of authority, deny action or move to a safer non-energized state."),
    ("HIL", "Hardware-in-the-loop testing using real controller/interface hardware with simulated or bounded plant behavior."),
    ("Idempotency", "Property that safe retry of one logical request does not create duplicate effects."),
    ("Invariant", "A condition that must remain true at a defined domain or control boundary."),
    ("JWT", "Signed token format commonly used to carry OIDC claims; possession is not sufficient unless signature and all validation rules pass."),
    ("Local commit", "Fresh physical/controller-side event that authorizes one prepared Cinerion command after final revalidation."),
    ("mTLS", "Mutual TLS, where both endpoints authenticate with certificates while encrypting transport."),
    ("NCR", "Nonconformance report/record controlling a product or process result that does not meet requirements."),
    ("OIDC", "OpenID Connect, an identity layer over OAuth 2.0 used for human login and identity claims."),
    ("Optimistic concurrency", "Update succeeds only if the stored version still equals the version previously read."),
    ("Permissive", "A required condition that must be true before and during a controlled action; unknown is treated as false."),
    ("PKCE", "OAuth proof-key mechanism protecting authorization-code exchange by public clients."),
    ("RLS", "PostgreSQL Row-Level Security, database policies restricting which rows a role may see or modify."),
    ("SBOM", "Software Bill of Materials: inventory of components/dependencies in a build."),
    ("Segregation of duties", "Preventing one actor from performing incompatible preparation, approval, execution, or release roles."),
    ("State hash", "Canonical fingerprint of relevant current cell/controller state bound to a command transaction."),
    ("State machine", "Explicit set of allowed states, events, guards, and transitions."),
    ("Step-up authentication", "Fresh stronger authentication requested for a sensitive operation."),
    ("TTL", "Time to live: bounded validity period after which transient authority expires."),
    ("WebAuthn/passkey", "Public-key authentication protocol using a platform or roaming authenticator; resistant to password phishing when correctly deployed."),
    ("Zero trust", "Security approach that grants no implicit trust based solely on network location and evaluates identity, device, resource, and context per access."),
]


REFERENCES = [
    ("Ubuntu installation of .NET", "https://learn.microsoft.com/en-us/dotnet/core/install/linux-ubuntu-install", "Current Ubuntu-specific package sources and .NET 10 installation/compatibility guidance."),
    ("Microsoft dotnet-install script", "https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-install-script", "Supported user-local fallback installer and its intended non-admin/CI uses."),
    ("Docker Desktop WSL 2 backend", "https://docs.docker.com/desktop/features/wsl/", "WSL requirements and enabling Docker Desktop integration per distribution."),
    ("Docker Compose", "https://docs.docker.com/compose/", "Compose model, commands, and multi-container application lifecycle."),
    ("Compose startup order and health", "https://docs.docker.com/compose/how-tos/startup-order/", "Dependency order and health-based readiness behavior."),
    ("ASP.NET Core minimal APIs", "https://learn.microsoft.com/en-us/aspnet/core/fundamentals/minimal-apis?view=aspnetcore-10.0", "Official .NET 10 route/application guidance."),
    ("Minimal API authentication/authorization", "https://learn.microsoft.com/en-us/aspnet/core/fundamentals/minimal-apis/security?view=aspnetcore-10.0", "Official server-side identity and authorization setup."),
    ("Testing minimal APIs", "https://learn.microsoft.com/en-us/aspnet/core/fundamentals/minimal-apis/test-min-api?view=aspnetcore-10.0", "Official integration testing patterns."),
    ("Expo SDK 57", "https://docs.expo.dev/versions/v57.0.0/", "Version-specific SDK, React Native/React, and Node compatibility reference."),
    ("Expo Router", "https://docs.expo.dev/router/introduction/", "File-based universal routing and route behavior."),
    ("PostgreSQL 18 row security", "https://www.postgresql.org/docs/18/ddl-rowsecurity.html", "Official default-deny, policy, owner, FORCE RLS, and BYPASSRLS behavior."),
    ("Keycloak Server Administration", "https://www.keycloak.org/docs/latest/server_admin/index.html", "Realm, authentication flow, WebAuthn, roles, sessions, and administrative controls."),
    ("NIST SP 800-207", "https://csrc.nist.gov/pubs/sp/800/207/final", "Zero Trust Architecture principles."),
    ("MQTT Version 5.0", "https://docs.oasis-open.org/mqtt/mqtt/v5.0/mqtt-v5.0.html", "Authoritative OASIS protocol standard."),
    ("ESP32-S3 security overview", "https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/security/security.html", "Official ESP-IDF secure boot, flash encryption, and device security feature overview."),
    ("Siemens S7-1200 G2 system manual", "https://support.industry.siemens.com/cs/attachments/109972011/S71200_G2_system_manual_en-US.pdf", "Official controller family configuration, programming, communications, and operating constraints."),
]


def chapter_23(document: Document) -> None:
    add_heading(document, CHAPTERS[22][1], 1, "ch23", 123)
    add_heading(document, "Glossary", 2)
    add_table(document, ["Term", "Meaning in this project"], GLOSSARY, [2100, 7260])
    add_heading(document, "Authoritative technical references", 2)
    add_para(document, "Use version-specific official documentation when changing the stack. Blog posts and examples can teach, but a release decision should be checked against the primary vendor/standard source and the exact deployed version.")
    add_table(document, ["Reference", "URL", "Use"], REFERENCES, [2250, 3920, 3190])
    add_heading(document, "Manual limitations and maintenance", 2)
    add_para(document, "This manual explains the delivered Prototype 1 code and the intended path to a final system. It does not replace machine-specific risk assessment, hardware design verification, certified safety engineering, procurement confirmation, privacy/legal review, penetration testing, HIL/FAT/SAT, operational procedures, or independent approval. Regenerate it after material source restructuring, then visually inspect the DOCX and review technical statements before release.")
    add_callout(document, "End state", "A professional final Cinerion release is not the moment every placeholder has code. It is the moment each intended capability has controlled requirements, secure design, implemented and reviewed code, migration/recovery behavior, negative tests, traceability, operational evidence, and an honest statement of residual limitations.", kind="safe")


def append_build_record(document: Document, sources: Sequence[SourceFile]) -> None:
    document.add_page_break()
    add_heading(document, "Generation record", 1)
    total_lines = sum(s.lines for s in sources)
    authored = sum(1 for s in sources if not s.generated and not s.binary)
    generated = sum(1 for s in sources if s.generated)
    binary = sum(1 for s in sources if s.binary)
    add_table(document, ["Metric", "Value"], [
        ["Repository root", str(REPO)],
        ["Inventoried files", str(len(sources))],
        ["Authored text/source files", str(authored)],
        ["Generated files", str(generated)],
        ["Binary/non-text files", str(binary)],
        ["Inventoried text lines", f"{total_lines:,}"],
        ["Builder", "tools/build_code_manual.py"],
        ["Output", OUT.relative_to(REPO).as_posix()],
    ], [3000, 6360])
    add_para(document, "The checksum below is intentionally calculated after the DOCX is saved and is written to the companion manifest rather than into the DOCX itself, avoiding a self-referential checksum.")


def build() -> Path:
    sources = inventory()
    document = Document()
    configure_document(document)
    properties = document.core_properties
    properties.title = "Cinerion Codebase Engineering Manual"
    properties.subject = "Prototype 1 source, setup, architecture, implementation, testing, and professional learning guide"
    properties.author = OWNER
    properties.keywords = "Cinerion, CH1, codebase, .NET, Expo, PostgreSQL, EdgeLink, ESP32, Siemens PLC, engineering manual"
    properties.comments = "Generated from the Cinerion Prototype 1 P03/IFV source tree."

    add_cover(document)
    add_navigation(document, sources)
    chapter_1(document)
    chapter_2(document)
    chapter_3(document)
    chapter_4(document)
    chapter_5(document)
    chapter_6(document)
    chapter_7(document)
    chapter_8(document)
    chapter_9(document)
    chapter_10(document)
    chapter_11(document)
    chapter_12(document)
    chapter_13(document)
    chapter_14(document)
    chapter_15(document)
    chapter_16(document)
    chapter_17(document)
    chapter_18(document)
    chapter_19(document)
    chapter_20(document)
    chapter_21(document)
    chapter_22(document, sources)
    chapter_23(document)
    append_build_record(document, sources)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    document.save(OUT)
    manifest = {
        "document": OUT.name,
        "sha256": file_sha256(OUT),
        "bytes": OUT.stat().st_size,
        "inventoried_files": len(sources),
        "inventoried_lines": sum(s.lines for s in sources),
        "generated_on": date.today().isoformat(),
        "baseline": REVISION,
        "software": SOFTWARE,
    }
    manifest_path = OUT.with_suffix(".manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    return OUT


if __name__ == "__main__":
    build()
