# Confidentiality and ownership notice

This repository contains confidential and proprietary Cinerion project
information. Access is limited to authorised recipients for controlled
engineering, research, development, and verification.

Copyright © 2026 IR. All rights reserved. Possession or access grants no
licence, assignment, publication right, or transfer of intellectual-property
rights. Copying, extraction, redistribution, training use, or publication is
prohibited except through the approved redaction and release workflow defined
by `CH1-PMG-ICP-0001`.

Public showcase material must be created as a separate derivative from an
allowlisted redaction profile, scrubbed of metadata and secrets, visually
reviewed, approved by IR, and issued with its own checksum. The confidential
engineering backbone must not be published.

