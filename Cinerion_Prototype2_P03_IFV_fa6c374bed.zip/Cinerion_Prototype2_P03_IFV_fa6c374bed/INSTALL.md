# Installing Cinerion

> **CONFIDENTIAL — PROJECT INTERNAL**  
> Copyright © 2026 IR. All rights reserved.

This guide gets the Cinerion lab running on one computer: the operator portal, the API, the
identity provider, the database, the edge gateway and a **simulated** cell controller. Nothing
here connects to or can move real equipment.

The short version:

| You are on | Do this |
|---|---|
| **Windows** | Unzip, then **double-click `install.cmd`** |
| **Linux, macOS or WSL** | Unzip, then run `sh install.sh` in the folder |

When it finishes it opens <http://localhost:8081> and tells you how to sign in. The rest of
this page is what it checks, what to do when something is missing, and how to use the lab
day to day.

---

## 1. What the computer needs

| | Needed | Why |
|---|---|---|
| Operating system | Windows 10/11 (64-bit), a recent Linux, or macOS | |
| **Docker** | Docker Desktop (Windows, macOS) or Docker Engine with Compose v2 (Linux) | Every service runs in a container |
| **Git** | Git for Windows on Windows (it brings `sh`, `curl` and `openssl` with it); `git`, `curl`, `openssl` elsewhere | The lab's setup scripts are shell scripts |
| **Node.js** | 22.13 or newer (the LTS release is fine) | A few setup steps are small Node scripts |
| Memory | 8 GB minimum, 16 GB comfortable | Seven containers at once |
| Disk | About 15 GB free | Container images and data |
| Free ports | 5080, 8081, 8180, 5085 | API, portal, identity provider, simulated cell |
| Internet | **Only for the first install** | To download container images and packages. After that it runs fully offline |

You do **not** need the .NET SDK, a C++ compiler or Chrome just to run the lab — everything is
built inside Docker. Those are only for developers running the full test pipeline (section 7).

On Windows, Docker Desktop uses WSL 2. If Docker Desktop has never been started on the
machine, start it once and let it finish its own setup before installing.

## 2. Install

### Windows

1. **Extract the whole archive first** — right-click the zip, *Extract All…* — somewhere you
   have write access, for example `C:\Cinerion`. Double-clicking `install.cmd` while browsing
   *inside* the zip won't work, because Windows then unpacks only that one file (it tells you
   so if you try). Avoid a synced folder (OneDrive): Docker and file sync don't get along.
2. Double-click **`install.cmd`** in the extracted folder.

That's it. The installer:

1. checks for Git, Node.js and Docker (and offers to install any that are missing with
   `winget` — it asks first);
2. starts Docker Desktop if it's installed but asleep, and waits for it;
3. checks the four ports are free — and if one is held by a stale `wslrelay` process (a known
   Windows quirk), offers to stop it;
4. generates local secrets into `infrastructure\.env.local` (on this machine only; never
   overwritten on later runs);
5. builds and starts the whole lab — **10 to 20 minutes the first time**, about a minute after.
   If the package carries a **lab data snapshot** (`lab-snapshot\`, see *Moving to another PC*
   in section 4), it's loaded into the new, empty database on the way, so the lab opens with
   the same records as the machine it was packed on;
6. runs the lab's own health check, prints where to sign in, and opens the portal.

Everything it prints is also saved to `install.log` in the same folder.

Options, if you run it from a terminal:

```powershell
.\install.cmd -CheckOnly               # check the machine, change nothing
.\install.cmd -InstallPrerequisites    # install missing tools with winget without asking
.\install.cmd -Yes -NoBrowser          # fully unattended
```

### Linux, macOS, WSL

```bash
cd Cinerion_Prototype2_P03_IFV_<version>
sh install.sh                # or: sh install.sh --check-only
```

It checks the same things, but it won't `sudo` anything for you: if a tool is missing it
tells you exactly what to install and stops. Docker's engine must be running
(`sudo systemctl start docker`, or start Docker Desktop on macOS).

## 3. First sign-in

Open <http://localhost:8081> and sign in with one of the two lab identities:

| User | What it's for |
|---|---|
| `ch1-portal-demo` | Almost every role one person may hold: operations, engineering, quality, administration |
| `ch1-portal-security` | The cybersecurity roles, which the rules forbid combining with the ones above |

Both use the same password, generated on your machine during install. To see it:

```powershell
Select-String CINERION_PORTAL_DEMO_PASSWORD infrastructure\.env.local     # Windows
```

```bash
grep CINERION_PORTAL_DEMO_PASSWORD infrastructure/.env.local               # elsewhere
```

**What works with a password sign-in:** every screen and all the live data, plus alarm
acknowledgement, object-linked messages, audit-chain verification and reports.

**What does not, yet:** the acts that change controlled state and so ask you to prove it's you
a second time — reserving capacity, releasing a part or a work order, preparing a command,
registering a credential, enrolling or revoking a device, changing someone's roles. Those need
a *step-up*, and every step-up needs a session that is already multi-factor. In this build a
password sign-in is single-factor: the identity provider isn't configured to ask for a second
factor, nor to tell Control Core that one was used. The portal says so when you try (the
refusal reads `AUTH_STRONGER_AUTHENTICATOR_REQUIRED`), rather than pretending. Turning it on
is an identity-design decision waiting on the project owner — see "What remains" in
`README.md`. Passkeys, once that's decided, are registered by a Cybersecurity Administrator
on the Security screen (never self-service, by design).

Everything you'll see is a simulation, and the portal says so where it matters: the cell
controller is a stand-in, readings are marked simulated, and no screen can make anything
physical happen.

## 4. Day to day

| To | Run |
|---|---|
| Start the lab again | Run the installer again (it's idempotent), or `npm run lab:up` |
| Check it's healthy | `npm run lab:check` — twelve quick checks, a few seconds |
| Stop it (keeps your data) | `npm run lab:down` |
| Snapshot the data to carry elsewhere | `npm run lab:export` |
| Build a release zip (carries the snapshot) | `npm run package:release` |
| See container logs | `docker compose -f infrastructure/compose.yaml logs -f control-core` |

Your data lives in Docker volumes named `cinerion_cinerion-*` and survives stopping,
restarting and rebooting.

**Starting over from nothing** — this deletes every record in the lab, and cannot be undone:

```bash
docker compose --env-file infrastructure/.env.local -f infrastructure/compose.yaml -f infrastructure/compose.lab.yaml --profile data-lab --profile identity-lab down -v
```

Keep `infrastructure/.env.local` when you do this: the next install creates fresh volumes
initialised with the same secrets. Delete that file only if you are also deleting the volumes.

### Upgrading to a newer version

Unzip the new version into its own folder, then **copy `infrastructure/.env.local` from the
old folder into the new one** before running the installer. Your data lives in Docker, not in
the folder, and it was created with those secrets — a fresh set would lock the database and
the identity provider out of it. The installer checks for exactly this and stops, before
changing anything, if it finds lab data but no secrets file.

### Moving to another PC

A package made with `npm run lab:export` followed by `npm run package:release` carries a
snapshot of the lab's data in `lab-snapshot\`. `BUILD_INFO.txt` says whether yours has one,
when it was taken and how many rows it holds. On the new PC the installer loads it into the
fresh database before Control Core first starts, then checks every table's row count against
the snapshot and prints `PASS  lab data restored: …`.

**What comes across:** every record — the telemetry history, alarms, the audit trail, test
runs, NCRs, work orders, experiments, parts, reports, device records. The sign-in accounts are
recreated from the realm file with the **same IDs** on every install, so anything recorded
against a signed-in user still points at that same user on the new PC.

**What doesn't, on purpose:**

- *Passwords and keys.* The new PC generates its own `.env.local` and its own device
  certificates, and the stand-in controller is re-enrolled with the new certificate
  automatically. To keep the **same sign-in password** as the old PC, copy
  `infrastructure\.env.local` from the old folder into the new one before installing.
- *Sign-in sessions.* You sign in again on the new PC.

The snapshot is only ever loaded into an **empty** database — never over a lab that already
has data, so it can't overwrite or mix with anything. To replace a lab's data with a
snapshot, start over from nothing (above) and install again. `npm run lab:import` does the
same load by hand.

## 5. Offline use

After the first successful install the lab needs no internet at all: nothing in it calls a
public service (this is checked by `npm run portal:egress` and `npm run offline:verify`), and
there is no AI service anywhere in it (checked by `npm run ai:prohibition`).

To install on a machine that **never** has internet, do the first install on a connected
machine, then carry the images across:

```bash
docker save -o cinerion-images.tar $(docker images --format '{{.Repository}}:{{.Tag}}' | grep -E '^(cinerion|postgres|quay.io/keycloak|nginx)')
# on the offline machine:
docker load -i cinerion-images.tar
```

## 6. Troubleshooting

| You see | What it means, and the fix |
|---|---|
| `ports are not available ... bind: Only one usage of each socket address` while `docker ps` shows nothing on that port | A stale `wslrelay` from Docker Desktop is holding it. The Windows installer offers to stop it; by hand: `Get-NetTCPConnection -LocalPort 5080 -State Listen \| % { Stop-Process -Id $_.OwningProcess -Force }` |
| The API answers **400** at `http://127.0.0.1:5080` | Working as designed. Use `http://localhost:5080` — the service only answers its own host name |
| `FAIL  CINERION_APP_PASSWORD is not in infrastructure/.env.local` | An older secrets file. Run the installer again: it adds the missing values and never changes existing ones |
| Keycloak logs `password authentication failed for user "keycloak"` | The identity database was created with a different secrets file than the one present now. Put the original `.env.local` back, or start over (section 4) |
| The lab stopped by itself right after `verify.sh --strict` | Expected — the performance test stops the lab's services so it can measure alone. Run `npm run lab:up` |
| Builds fail with odd errors, or the disk is nearly full | Docker's cache. `docker builder prune -f` and `docker volume prune -f` are safe (they keep the lab's named volumes). Don't add `--all` unless you mean to wipe the lab |
| A button answers `AUTH_STRONGER_AUTHENTICATOR_REQUIRED` | Expected in this build: that act needs a multi-factor session, which a password sign-in can't give yet (see section 3). Every read and every non-step-up action still works |
| Docker Desktop was just installed and nothing works | It needs one full start (and often a sign-out or restart) to finish setting up WSL 2. Then run the installer again |

`npm run lab:check` is the fastest way to see what's wrong: it prints PASS or FAIL for each
piece of the running lab.

## 7. For developers

To run the full verification pipeline (every gate the project has):

1. Install the .NET 10 SDK, a C++20 compiler (`g++`), and Chrome or Edge.
2. `npm ci`
3. `./scripts/doctor.sh` — says what's missing.
4. `./scripts/verify.sh --strict` — about 50 minutes; nothing may be skipped.

`docs/implementation/PROTOTYPE2_PROGRESS.md` is the full engineering record, and its
"Resuming work in a new session" section is required reading before changing anything.
`docs/implementation/DEVELOPMENT_GATES.md` explains every gate and what it refuses.

To build a release archive like the one this came in: commit your work, then
`npm run package:release`. It packs exactly the committed tree, writes a SHA-256 manifest,
and re-verifies every checksum before publishing it to `release/`.

## 8. Uninstalling

1. Stop and delete the lab and its data (the command in section 4).
2. Remove the images if you want the disk back: `docker image prune -a` (this removes every
   unused image on the machine, not only Cinerion's).
3. Delete the folder.
