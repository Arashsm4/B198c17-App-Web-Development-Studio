// The I/O node's brain, minus the pins. It reports what it sees and never takes orders to move
// anything.

#pragma once

// The Arduino I/O node's decision logic.
//
// CH1-EMB-FDS-0001: "Arduino-compatible boards are restricted to secondary, replaceable I/O
// nodes with no independent authority to start a procedure." That is the whole design of
// this type. It composes REPORTS and it has no method that composes anything else — not a
// request, not an acknowledgement, not a command. The closed set lives in the frame codec
// and is refused on both sides of the wire; this is the node that cannot reach past it.
//
// It owns CH1-IO-SPI-0001, the part RFID reader, whose controlled diagnostic action is
// "Identification only". CH1-HWE-HDS-0001 permits an RC522-class UID reader for part
// identification and nothing else, and CH1-HWE-IOL-0001 keeps part identification and human
// authentication on separate channels. A UID that reaches the cell controller identifies a
// part; it authenticates nobody and authorises nothing.
//
// Portable and allocation-free, like the cell state machine, so the Arduino sketch is a
// thin shell around it and every decision here is host-testable with no board present.

#include "cinerion/frame_codec.hpp"

#include <cstddef>
#include <cstdint>
#include <span>

namespace cinerion::io {

/// The largest part identifier this link carries. ISO 14443 UIDs are 4, 7 or 10 bytes;
/// the bound is generous and, more importantly, ENFORCED — see `compose_part_identity`.
inline constexpr std::size_t maximum_part_identifier = 16;

/// The discrete inputs the node carries on behalf of the cell controller. Raw levels: the
/// node reports what it saw and the controller conditions and judges it, because a node with
/// no authority to start a procedure should not be the thing that decides an input is valid.
struct NodeInputs {
    bool auxiliary_guard_return{};
    bool tray_present{};
    bool fixture_clamped{};
    bool reader_healthy{};
};

/// Composes the node's reports.
class NodeApplication final {
  public:
    /// One conditioned-input report.
    [[nodiscard]] std::size_t compose_input_state(
        std::span<std::uint8_t> into, const NodeInputs& inputs) noexcept;

    /// One part identifier read by the RFID reader.
    ///
    /// Refuses an identifier longer than `maximum_part_identifier` rather than truncating
    /// it. This is not defensive tidiness: a truncated UID is a VALID identifier for a
    /// DIFFERENT part, so a node that shortened one would silently attribute work,
    /// measurements and genealogy to the wrong component — and every downstream record
    /// would be internally consistent and wrong. Refusing produces a gap somebody notices.
    [[nodiscard]] std::size_t compose_part_identity(
        std::span<std::uint8_t> into, std::span<const std::uint8_t> identifier) noexcept;

    /// The node's own health.
    [[nodiscard]] std::size_t compose_node_status(
        std::span<std::uint8_t> into,
        std::uint32_t uptime_seconds,
        std::uint16_t frames_rejected) noexcept;

    /// The sequence the next frame will carry. Never repeats and never goes backwards, which
    /// is what makes the receiver's replay check meaningful.
    [[nodiscard]] std::uint32_t next_sequence() const noexcept { return sequence_; }

    /// Frames this node declined to compose. Reported in the status frame, so a reader that
    /// has started returning identifiers the link cannot carry is visible rather than quiet.
    [[nodiscard]] std::uint16_t refused() const noexcept { return refused_; }

  private:
    /// Advances only when a frame was actually built. A sequence consumed by a refused frame
    /// would leave a hole the receiver reads as a lost report.
    [[nodiscard]] std::size_t emit(
        std::span<std::uint8_t> into, FrameType type, std::span<const std::uint8_t> payload) noexcept;

    std::uint32_t sequence_{1};
    std::uint16_t refused_{0};
};

}  // namespace cinerion::io
