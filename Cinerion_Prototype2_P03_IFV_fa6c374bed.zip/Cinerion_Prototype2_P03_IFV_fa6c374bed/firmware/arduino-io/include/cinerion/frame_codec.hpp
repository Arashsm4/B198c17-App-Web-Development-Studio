// The CH1 serial frame, header side: what goes on the wire and how the receiver checks it.

#pragma once

// CH1-COM-IF-0006, the RS-485 node bus between the ESP32-S3 cell controller and the Arduino
// I/O node (CH1-IO-SER-0001, controlled diagnostic action "CRC/sequence/timeout").
//
// The load-bearing property of this link is NEGATIVE: a frame on it reports local input
// state and can never be a command. CH1-EMB-FDS-0001 restricts Arduino boards to "secondary,
// replaceable I/O nodes with no independent authority to start a procedure", and
// CH1-SYS-CON-0001 keeps commands out of anything that stores or forwards.
//
// That property used to be a COMMENT. `validate_frame` checked the preamble, the version,
// the declared length, the sequence and the CRC, and never read the type byte at all — so
// every frame type from 0 to 255 was accepted, and the claim that a frame "can never be a
// command" rested on nobody having defined one yet. The type is now a closed set of report
// kinds, refused on both sides of the wire: this codec will not build a frame outside it and
// will not accept one.

#include <cstddef>
#include <cstdint>
#include <span>

namespace cinerion::io {

constexpr std::uint16_t frame_preamble = 0xC1A1;
constexpr std::uint8_t frame_version = 1;
constexpr std::size_t maximum_payload = 128;
constexpr std::size_t frame_header_size = 10;
constexpr std::size_t frame_crc_size = 2;
constexpr std::size_t frame_overhead = frame_header_size + frame_crc_size;

/// Every frame type this link carries, and there are no others.
///
/// All three are REPORTS. There is deliberately no request, no command and no acknowledgement
/// that could carry an intent: the node observes and says what it saw, and the cell
/// controller decides. Adding a type here is a reviewed change to a controlled interface,
/// which is the point of it being a closed set rather than a convention.
enum class FrameType : std::uint8_t {
    /// Conditioned discrete input state at the node.
    InputState = 0x10,
    /// A part identifier read by the RFID reader (CH1-IO-SPI-0001, "Identification only").
    /// A UID identifies a part. It authenticates nobody and authorises nothing.
    PartIdentity = 0x11,
    /// The node's own health: uptime, reader state, frame errors seen.
    NodeStatus = 0x12,
};

[[nodiscard]] constexpr bool is_report_type(const std::uint8_t type) noexcept {
    return type == static_cast<std::uint8_t>(FrameType::InputState)
        || type == static_cast<std::uint8_t>(FrameType::PartIdentity)
        || type == static_cast<std::uint8_t>(FrameType::NodeStatus);
}

struct FrameHeader {
    std::uint16_t preamble{};
    std::uint8_t version{};
    std::uint8_t type{};
    std::uint16_t payload_length{};
    std::uint32_t sequence{};
};

[[nodiscard]] std::uint16_t crc16_ccitt(std::span<const std::uint8_t> bytes) noexcept;

/// Validates one received frame. The header is checked before the payload is interpreted,
/// and a frame that fails any check is discarded rather than repaired.
[[nodiscard]] bool validate_frame(std::span<const std::uint8_t> frame, std::uint32_t minimum_sequence) noexcept;

/// Reads the type of a frame that has already been validated. Undefined for one that has not.
[[nodiscard]] FrameType frame_type(std::span<const std::uint8_t> frame) noexcept;

/// Reads the payload of a frame that has already been validated.
[[nodiscard]] std::span<const std::uint8_t> frame_payload(std::span<const std::uint8_t> frame) noexcept;

/// Builds one frame into `into`, and returns the number of bytes written, or 0.
///
/// Returns 0 rather than writing a partial frame, for the same reason the CH1 envelope
/// encoder does: a truncated frame that happened to pass its CRC would be a different
/// message. It also returns 0 for a type outside the closed set above — the node cannot
/// build a command even by mistake, which is the producer half of the property this link
/// rests on.
[[nodiscard]] std::size_t build_frame(
    std::span<std::uint8_t> into,
    FrameType type,
    std::uint32_t sequence,
    std::span<const std::uint8_t> payload) noexcept;

}  // namespace cinerion::io
