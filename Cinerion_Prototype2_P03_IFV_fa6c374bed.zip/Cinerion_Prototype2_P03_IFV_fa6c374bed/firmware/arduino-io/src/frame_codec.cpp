// Packs and unpacks CH1 serial frames. Bad CRC, bad length, bad type: all politely refused.

#include "cinerion/frame_codec.hpp"

namespace cinerion::io {

namespace {

[[nodiscard]] std::uint16_t read_u16(const std::span<const std::uint8_t> frame, const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(frame[offset]) << 8U) | frame[offset + 1]);
}

[[nodiscard]] std::uint32_t read_u32(const std::span<const std::uint8_t> frame, const std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(frame[offset]) << 24U) |
           (static_cast<std::uint32_t>(frame[offset + 1]) << 16U) |
           (static_cast<std::uint32_t>(frame[offset + 2]) << 8U) |
           static_cast<std::uint32_t>(frame[offset + 3]);
}

void write_u16(const std::span<std::uint8_t> into, const std::size_t offset, const std::uint16_t value) noexcept {
    into[offset] = static_cast<std::uint8_t>(value >> 8U);
    into[offset + 1] = static_cast<std::uint8_t>(value & 0xFFU);
}

void write_u32(const std::span<std::uint8_t> into, const std::size_t offset, const std::uint32_t value) noexcept {
    into[offset] = static_cast<std::uint8_t>(value >> 24U);
    into[offset + 1] = static_cast<std::uint8_t>((value >> 16U) & 0xFFU);
    into[offset + 2] = static_cast<std::uint8_t>((value >> 8U) & 0xFFU);
    into[offset + 3] = static_cast<std::uint8_t>(value & 0xFFU);
}

}  // namespace

std::uint16_t crc16_ccitt(const std::span<const std::uint8_t> bytes) noexcept {
    std::uint16_t crc = 0xFFFF;
    for (const auto byte : bytes) {
        crc ^= static_cast<std::uint16_t>(byte) << 8U;
        for (std::uint8_t bit = 0; bit < 8; ++bit) {
            crc = static_cast<std::uint16_t>((crc & 0x8000U) != 0U ? (crc << 1U) ^ 0x1021U : crc << 1U);
        }
    }
    return crc;
}

bool validate_frame(const std::span<const std::uint8_t> frame, const std::uint32_t minimum_sequence) noexcept {
    if (frame.size() < frame_overhead) {
        return false;
    }
    if (read_u16(frame, 0) != frame_preamble || frame[2] != frame_version) {
        return false;
    }
    // The type, which nothing used to read. A frame outside the closed set of report kinds
    // is refused here rather than being passed to a handler that would have to know not to
    // act on it — CH1-EMB-FDS-0001 gives the node no authority to start a procedure, and
    // this is where that stops being a comment.
    if (!is_report_type(frame[3])) {
        return false;
    }
    const auto payload_length = read_u16(frame, 4);
    if (payload_length > maximum_payload || frame.size() != frame_overhead + payload_length) {
        return false;
    }
    // Replay and reordering. The receiver holds the last sequence it accepted and a frame
    // that does not advance it is discarded.
    if (read_u32(frame, 6) < minimum_sequence) {
        return false;
    }
    const auto expected_crc = read_u16(frame, frame.size() - frame_crc_size);
    return crc16_ccitt(frame.first(frame.size() - frame_crc_size)) == expected_crc;
}

FrameType frame_type(const std::span<const std::uint8_t> frame) noexcept {
    return static_cast<FrameType>(frame[3]);
}

std::span<const std::uint8_t> frame_payload(const std::span<const std::uint8_t> frame) noexcept {
    return frame.subspan(frame_header_size, frame.size() - frame_overhead);
}

std::size_t build_frame(
    const std::span<std::uint8_t> into,
    const FrameType type,
    const std::uint32_t sequence,
    const std::span<const std::uint8_t> payload) noexcept {
    // The producer half of the same closed set. A node cannot build a frame the receiver
    // would refuse, and — more to the point — cannot build a command even by mistake.
    if (!is_report_type(static_cast<std::uint8_t>(type))) {
        return 0;
    }
    if (payload.size() > maximum_payload) {
        return 0;
    }
    const std::size_t total = frame_overhead + payload.size();
    if (into.size() < total) {
        // Refused rather than truncated. A short frame that happened to pass its CRC would
        // be a different message.
        return 0;
    }

    write_u16(into, 0, frame_preamble);
    into[2] = frame_version;
    into[3] = static_cast<std::uint8_t>(type);
    write_u16(into, 4, static_cast<std::uint16_t>(payload.size()));
    write_u32(into, 6, sequence);
    for (std::size_t index = 0; index < payload.size(); ++index) {
        into[frame_header_size + index] = payload[index];
    }
    write_u16(into, total - frame_crc_size, crc16_ccitt(into.first(total - frame_crc_size)));
    return total;
}

}  // namespace cinerion::io
