// The I/O node's logic: conditioned inputs in, report frames out. Read-only by design.

#include "cinerion/node_application.hpp"

#include <array>

namespace cinerion::io {

std::size_t NodeApplication::emit(
    const std::span<std::uint8_t> into,
    const FrameType type,
    const std::span<const std::uint8_t> payload) noexcept {
    const std::size_t written = build_frame(into, type, sequence_, payload);
    if (written == 0) {
        // The sequence is NOT consumed. A number spent on a frame that never went out would
        // leave a hole the receiver reads as a report lost in transit, which is a different
        // fault from the one that actually happened.
        refused_ += 1;
        return 0;
    }
    sequence_ += 1;
    return written;
}

std::size_t NodeApplication::compose_input_state(
    const std::span<std::uint8_t> into, const NodeInputs& inputs) noexcept {
    // One byte of packed levels. Raw, not judged: the node reports what it saw and the cell
    // controller conditions it, because a node with no authority to start a procedure should
    // not be the thing that decides an input is valid.
    const std::uint8_t packed = static_cast<std::uint8_t>(
        (inputs.auxiliary_guard_return ? 0x01U : 0U) |
        (inputs.tray_present ? 0x02U : 0U) |
        (inputs.fixture_clamped ? 0x04U : 0U) |
        (inputs.reader_healthy ? 0x08U : 0U));

    const std::array<std::uint8_t, 1> payload{packed};
    return emit(into, FrameType::InputState, payload);
}

std::size_t NodeApplication::compose_part_identity(
    const std::span<std::uint8_t> into, const std::span<const std::uint8_t> identifier) noexcept {
    if (identifier.empty() || identifier.size() > maximum_part_identifier) {
        // Refused rather than truncated, and refused rather than padded. A shortened UID is
        // a valid identifier for a DIFFERENT part, so a node that trimmed one would attribute
        // work, measurements and genealogy to the wrong component — and every record
        // downstream would be internally consistent and wrong. CH1-MFG-FR-0002 makes the part
        // identity permanent; there is no recovering from having recorded the wrong one.
        refused_ += 1;
        return 0;
    }
    return emit(into, FrameType::PartIdentity, identifier);
}

std::size_t NodeApplication::compose_node_status(
    const std::span<std::uint8_t> into,
    const std::uint32_t uptime_seconds,
    const std::uint16_t frames_rejected) noexcept {
    const std::array<std::uint8_t, 6> payload{
        static_cast<std::uint8_t>(uptime_seconds >> 24U),
        static_cast<std::uint8_t>((uptime_seconds >> 16U) & 0xFFU),
        static_cast<std::uint8_t>((uptime_seconds >> 8U) & 0xFFU),
        static_cast<std::uint8_t>(uptime_seconds & 0xFFU),
        static_cast<std::uint8_t>(frames_rejected >> 8U),
        static_cast<std::uint8_t>(frames_rejected & 0xFFU),
    };
    return emit(into, FrameType::NodeStatus, payload);
}

}  // namespace cinerion::io
