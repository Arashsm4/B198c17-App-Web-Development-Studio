# Cinerion controller firmware

The portable core is allocation-free and host tested. It owns the readiness
state machine, local credential/button binding, final permissive sample,
non-energising defaults, watchdog response, and fault latch. It does not replace
machine-specific safety functions.

`esp32/main/app_main.cpp` deliberately configures no actuator GPIO. Exact pins,
electrical conditioning, credential reader, watchdog output path, and local
display will be added only after the Prototype 1 schematic and I/O schedule are
reviewed.

Never burn secure-boot, flash-encryption, anti-rollback, or debug-disable eFuses
from an automated general build. Provisioning is an irreversible controlled
operation performed on dedicated hardware after recovery and signing keys are
verified.

