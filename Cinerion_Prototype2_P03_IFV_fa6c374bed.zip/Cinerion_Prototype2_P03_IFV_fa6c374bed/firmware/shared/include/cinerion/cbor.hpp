// A small CBOR writer and reader. Just enough CBOR to speak the CH1 envelope and not a byte
// more.

#pragma once

// Canonical CBOR (RFC 8949 §4.2) for the CH1 device edge.
//
// CH1-COM-IF-0005 names CBOR between the broker and the ESP32-S3, and the same bytes
// cross CH1-COM-IF-0004 to EdgeLink unchanged. This is the device half of that encoding.
//
// It is deliberately a small subset: definite lengths only, and the value kinds the CH1
// envelope actually uses. An embedded decoder that accepted indefinite lengths, tags or
// arbitrary nesting would be a larger attack surface for no benefit, and CH1-COM-ICD-0001
// makes unknown mandatory semantics fail closed rather than be skipped over.
//
// Everything writes into a caller-owned buffer and reports whether it fitted. There is no
// allocation anywhere in this file: a controller that could fail to allocate while
// encoding a heartbeat would fail at the moment its state most needs reporting.

#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace cinerion::cbor {

/// Major types, as RFC 8949 numbers them.
enum class MajorType : std::uint8_t {
    unsigned_integer = 0,
    negative_integer = 1,
    byte_string = 2,
    text_string = 3,
    array = 4,
    map = 5,
    simple = 7,
};

/// Writes canonical CBOR into a fixed buffer, refusing rather than truncating.
class Writer {
  public:
    explicit Writer(std::span<std::uint8_t> buffer) noexcept : buffer_(buffer) {}

    /// Bytes written so far. Meaningless if `overflowed()`.
    [[nodiscard]] std::size_t size() const noexcept { return position_; }

    /// True once anything did not fit. A partial message is never emitted.
    [[nodiscard]] bool overflowed() const noexcept { return overflowed_; }

    [[nodiscard]] std::span<const std::uint8_t> encoded() const noexcept {
        return buffer_.subspan(0, position_);
    }

    void unsigned_value(std::uint64_t value) noexcept;
    void signed_value(std::int64_t value) noexcept;
    void boolean(bool value) noexcept;
    void null_value() noexcept;
    /// IEEE-754 double, always the 64-bit form: shortest-float encoding would make the
    /// same reading encode differently depending on its value.
    void double_value(double value) noexcept;
    void text(std::string_view value) noexcept;
    void bytes(std::span<const std::uint8_t> value) noexcept;
    void array_header(std::size_t count) noexcept;
    void map_header(std::size_t count) noexcept;

  private:
    void head(MajorType type, std::uint64_t argument) noexcept;
    void raw(std::uint8_t byte) noexcept;
    void raw(std::span<const std::uint8_t> data) noexcept;

    std::span<std::uint8_t> buffer_;
    std::size_t position_{0};
    bool overflowed_{false};
};

/// One decoded item's kind, as far as this subset is concerned.
enum class ItemKind : std::uint8_t {
    invalid,
    unsigned_integer,
    negative_integer,
    byte_string,
    text_string,
    array,
    map,
    boolean,
    null_item,
    double_item,
};

/// A reader that validates as it goes and never runs past the end of the buffer.
class Reader {
  public:
    explicit Reader(std::span<const std::uint8_t> buffer) noexcept : buffer_(buffer) {}

    [[nodiscard]] bool exhausted() const noexcept { return position_ >= buffer_.size(); }
    [[nodiscard]] bool failed() const noexcept { return failed_; }
    [[nodiscard]] std::size_t position() const noexcept { return position_; }

    /// The kind of the next item without consuming it.
    [[nodiscard]] ItemKind peek() const noexcept;

    /// Reads a definite-length map header and returns the pair count.
    [[nodiscard]] std::size_t map_header() noexcept;
    [[nodiscard]] std::size_t array_header() noexcept;
    [[nodiscard]] std::uint64_t unsigned_value() noexcept;
    [[nodiscard]] std::int64_t signed_value() noexcept;
    [[nodiscard]] bool boolean() noexcept;
    [[nodiscard]] double double_value() noexcept;
    /// Returns a view into the caller's buffer; no copy and no allocation.
    [[nodiscard]] std::string_view text() noexcept;
    [[nodiscard]] std::span<const std::uint8_t> bytes() noexcept;

    /// Steps over one item of any supported kind, including nested containers.
    void skip() noexcept;

  private:
    [[nodiscard]] bool head(MajorType& type, std::uint64_t& argument) noexcept;
    void fail() noexcept { failed_ = true; }

    std::span<const std::uint8_t> buffer_;
    std::size_t position_{0};
    bool failed_{false};
};

}  // namespace cinerion::cbor
