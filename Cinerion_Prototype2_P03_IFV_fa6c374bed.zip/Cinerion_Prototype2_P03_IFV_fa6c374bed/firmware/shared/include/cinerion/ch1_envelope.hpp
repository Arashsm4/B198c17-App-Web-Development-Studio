// The CH1 message envelope, firmware edition: readings, acknowledgements and heartbeats.

#pragma once

// The CH1 message envelope, device side.
//
// CH1-COM-ICD-0001 states what every controlled message carries: schema version, message
// type, message id, correlation id, source and destination identities, project/cell/asset
// scope, timestamp, time quality, sequence, expiry where relevant and payload. Commands
// add expected state, configuration revision and an idempotency key; telemetry adds
// engineering unit, quality and source sample time.
//
// This is the same envelope services/edge-link/.../Ch1MessageEnvelope.cs encodes, and it
// is a genuinely separate implementation of it — one written against the controlled
// document, not against the other. firmware/tests/ch1_envelope_test.cpp asserts the exact
// bytes, and a .NET test asserts the same literal from the other side, so the two cannot
// drift apart without one of them failing.
//
// Map keys are emitted in canonical order (RFC 8949 §4.2.1: shorter key first, then
// bytewise) because the gateway decodes in Canonical mode and would refuse anything else.

#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace cinerion::ch1 {

constexpr std::string_view schema_version = "1.0.0";

/// The largest any encoded CH1 envelope can be, for a caller sizing a buffer.
///
/// This exists because guessing was wrong three times out of three. app_main.cpp sized its
/// telemetry and heartbeat buffers at 320 bytes and its acknowledgement buffer at 384; the
/// three messages encode to 355, 365 and 438. Every message the controller could send would
/// have been refused — the encoder returns 0 rather than truncating, so the device fails
/// safe and goes SILENT, which for a heartbeat CH1-COM-FR-0009 requires is its own fault.
/// Nothing caught it: the host tests encode into 512-byte buffers of their own, and
/// app_main was never compiled, let alone run, until the simulator ran it.
///
/// Derived rather than guessed. The envelope's fixed header is thirteen keys carrying three
/// 16-byte identifiers, two 16-byte message identifiers, a timestamp, a sequence and four
/// short texts; the largest payload is an acknowledgement carrying
/// PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION with a controller state beside it. The
/// measured worst case is 438 bytes and this is 512, leaving room for a longer reason code
/// without another silent failure — and firmware/tests/ch1_envelope_test.cpp asserts the
/// bound against the actual worst case of every message type, so a reason code that outgrows
/// it fails a gate instead of a deployment.
inline constexpr std::size_t maximum_envelope_bytes = 512;

/// A 16-byte identifier, as the envelope carries them: raw bytes, not text.
using Uuid = std::span<const std::uint8_t, 16>;

/// The scope and identity every message on this link repeats.
struct Origin {
    std::string_view source;       ///< this device's identity, matching its certificate
    std::string_view destination;  ///< the gateway
    Uuid project;
    Uuid cell;
    Uuid asset;
};

/// One reading, with the three things CH1-COM-ICD-0001 requires of telemetry.
struct Reading {
    std::string_view channel;
    double value;
    std::string_view unit;
    std::string_view quality;             ///< Good, Uncertain, Bad — the source's own judgement
    std::int64_t sampled_at_milliseconds; ///< when the source observed it, never when it was sent
};

/// What a controller may say about a prepared command. It acknowledges an intent and
/// stops there: the credential proof and the physical button edge are observed locally,
/// and no value here may claim an execution.
struct Acknowledgement {
    Uuid command_id;
    bool accepted;
    std::string_view controller_state;
    std::string_view reason_code;
};

struct Heartbeat {
    std::string_view firmware_version;
    std::string_view configuration_revision;
    std::int64_t uptime_seconds;
};

/// A decoded command. Views point into the caller's buffer and are valid while it is.
struct Command {
    bool valid{false};
    std::string_view refusal_code{};  ///< set when `valid` is false; a stable code, never prose
    std::span<const std::uint8_t> idempotency_key{};
    std::string_view command_type{};
    std::string_view configuration_revision{};
    std::string_view expected_state_hash{};
    std::int64_t expires_at_milliseconds{0};
    std::int64_t sequence{0};
    std::span<const std::uint8_t> correlation_id{};
};

/// Every encoder takes the controller's own judgement of its clock and writes it into the
/// envelope's `timeQuality` field.
///
/// It used to write the literal "Synchronised" on every message, which was a claim nothing
/// supported: `wall_clock_milliseconds()` returns -1 at this checkpoint, so the same
/// firmware refused every command as CONTROLLER_TIME_NOT_TRUSTED while telling the gateway
/// its clock was disciplined. CH1-COM-ICD-0001 requires time quality to be visible
/// precisely so audit decisions are not silently made on invalid time, and a constant is
/// not a report. `cinerion::io::time_quality_name` produces the value.
///
/// Encoders. Each returns the number of bytes written, or 0 if the buffer was too small —
/// a partial envelope is never emitted, because a truncated message that happened to
/// parse would be a different message.
[[nodiscard]] std::size_t encode_telemetry(
    std::span<std::uint8_t> buffer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sent_at_milliseconds,
    std::int64_t sequence,
    std::string_view time_quality,
    const Reading& reading) noexcept;

[[nodiscard]] std::size_t encode_acknowledgement(
    std::span<std::uint8_t> buffer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sent_at_milliseconds,
    std::int64_t sequence,
    std::string_view time_quality,
    const Acknowledgement& acknowledgement) noexcept;

[[nodiscard]] std::size_t encode_heartbeat(
    std::span<std::uint8_t> buffer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sent_at_milliseconds,
    std::int64_t sequence,
    std::string_view time_quality,
    const Heartbeat& heartbeat) noexcept;

/// Decodes and validates a command envelope.
///
/// The header is checked before the payload is interpreted, in this order: schema, type,
/// scope, then expiry. CH1-COM-ICD-0001 makes the receiver responsible for schema,
/// authority, state and bounds, and that order is what stops a malformed payload from
/// being parsed by a message that had no business being accepted.
///
/// `now_milliseconds` is compared against the expiry. A controller with no trustworthy
/// clock must pass a negative value, which refuses every command rather than accepting
/// one whose expiry it cannot judge.
[[nodiscard]] Command decode_command(
    std::span<const std::uint8_t> envelope,
    const Origin& expected,
    std::int64_t now_milliseconds) noexcept;

}  // namespace cinerion::ch1
