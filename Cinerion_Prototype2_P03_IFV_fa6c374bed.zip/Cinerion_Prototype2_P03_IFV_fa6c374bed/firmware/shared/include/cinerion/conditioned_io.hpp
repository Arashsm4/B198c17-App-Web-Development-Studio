// Debounce, range checks and fault detection for the cell's inputs. Raw pins in, signals you
// can trust out.

#pragma once

// Conditioned I/O for the CH1 cell controller.
//
// This is the layer CH1-EMB-FDS-0001 calls for between the pins and the state machine:
// "Discrete 24 V signals use designed isolation and conditioning. Confirmation input
// implements debounce, edge-only acceptance and stuck detection. Sensors carry range,
// plausibility, freshness and quality. Outputs default off and are commanded through
// bounded drivers."
//
// It configures no GPIO and drives nothing. Every type here takes a sample it is given and
// returns a decision, so the whole layer is host-testable with no board present — which is
// what CH1-EMB-FDS-0001 means by "Hardware abstraction permits deterministic test doubles",
// and what lets CH1-VVT-TC-0072 and CH1-VVT-TC-0073 be exercised rather than argued.
//
// The safety position is CH1-SAF-FR-0001's and it is unchanged: the entry point configures
// no GPIO as an actuator output, and nothing below it energises anything. `OutputPlan` is
// an intent, not an act. `firmware/pinmap/esp32s3-r01.json` records which signals are
// actuators and that none of them is energisable at this hardware revision, and
// scripts/check-io-map.mjs refuses a map that says otherwise while the wiring is unfrozen.
//
// The signal identifiers below are the firmware's own copy of the controlled register in
// docs/baseline/P03_IFV/data/io.json. Two copies, deliberately: the firmware must not read
// JSON at build time, and a list that agrees only because nobody checked is not a contract.
// scripts/check-io-map.mjs reconciles this header against the pin map and the pin map
// against the controlled table.

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace cinerion::io {

/// The controlled signals this controller conditions. Names describe physical meaning;
/// the GPIO number appears only in the pin map (CH1-HWE-IOL-0001).
namespace signals {
constexpr std::string_view start_enable = "CH1-IO-DI-0001";
constexpr std::string_view stop_request = "CH1-IO-DI-0002";
constexpr std::string_view local_reset = "CH1-IO-DI-0003";
constexpr std::string_view confirmation_button = "CH1-IO-DI-0004";
constexpr std::string_view guard_interlock = "CH1-IO-DI-0005";
constexpr std::string_view actuator_home = "CH1-IO-DI-0006";

constexpr std::string_view confirmation_lamp = "CH1-IO-DO-0001";
constexpr std::string_view green_indicator = "CH1-IO-DO-0002";
constexpr std::string_view amber_indicator = "CH1-IO-DO-0003";
constexpr std::string_view red_indicator = "CH1-IO-DO-0004";
constexpr std::string_view buzzer = "CH1-IO-DO-0005";
constexpr std::string_view actuator_enable = "CH1-IO-DO-0006";

constexpr std::string_view servo_stepper = "CH1-IO-PWM-0001";

constexpr std::string_view temperature = "CH1-IO-AI-0001";
constexpr std::string_view relative_humidity = "CH1-IO-AI-0002";
constexpr std::string_view position = "CH1-IO-AI-0003";
constexpr std::string_view vibration = "CH1-IO-AI-0004";

constexpr std::string_view node_bus = "CH1-IO-SER-0001";
constexpr std::string_view mqtt_uplink = "CH1-IO-NET-0001";
constexpr std::string_view local_display = "CH1-IO-HMI-0001";
}  // namespace signals

/// The source's own judgement of a reading, as CH1-COM-ICD-0001 carries it. A substituted
/// value is Bad, never Good with a plausible number in it.
enum class Quality : std::uint8_t { Good, Uncertain, Bad };

[[nodiscard]] std::string_view quality_name(Quality quality) noexcept;

// ---------------------------------------------------------------------------------------
// Discrete inputs
// ---------------------------------------------------------------------------------------

/// How the field circuit is wired. CH1-HWE-IOL-0001 requires normally closed circuits to be
/// identified explicitly, because it is what makes a cut conductor read as the demand
/// rather than as silence.
enum class Circuit : std::uint8_t { NormallyOpen, NormallyClosed };

struct DiscreteInputConfig {
    std::string_view signal_id{};
    Circuit circuit{Circuit::NormallyOpen};
    /// A level must hold for this long before it is believed.
    std::uint32_t debounce_milliseconds{20};
    /// A signal asserted continuously for longer than this is declared stuck, and its
    /// assertion is withheld until it is seen to release. 0 disables the check.
    ///
    /// CH1-IO-DI-0004's controlled diagnostic action is "Debounce + stuck detection", and
    /// this is the half that matters: a welded contact or a shorted conductor reads as a
    /// permanent press, and without this it would present a confirmation edge on the first
    /// sample after every restart.
    std::uint32_t stuck_asserted_milliseconds{0};
};

/// One conditioned 24 V discrete input.
///
/// Sampling is the caller's job and the only thing it must get right is the raw electrical
/// level; everything the controlled table asks for happens here.
class DiscreteInput final {
  public:
    explicit DiscreteInput(DiscreteInputConfig config) noexcept;

    /// Offers one raw electrical level. Safe to call at any cadence: the debounce is a time
    /// bound, not a sample count, so a task that runs late does not shorten it.
    void sample(bool raw_level, std::uint64_t monotonic_now_milliseconds) noexcept;

    /// The debounced electrical level, before the circuit's meaning is applied.
    [[nodiscard]] bool level() const noexcept { return level_; }

    /// The condition this signal names, with the circuit applied and a stuck signal
    /// withheld. For a normally closed circuit that is the loop having opened.
    [[nodiscard]] bool asserted() const noexcept;

    /// True while the loop is intact. Meaningless for a normally open signal, which makes
    /// no claim about its own conductor, and always true there.
    [[nodiscard]] bool circuit_healthy() const noexcept;

    /// True once the signal has been asserted for longer than its configured bound. Latches
    /// until the signal is seen to release, so the fault survives the operator letting go
    /// of nothing.
    [[nodiscard]] bool stuck() const noexcept { return stuck_; }

    /// True until a level has been believed at all. Before that, `asserted()` answers from
    /// the de-energised state rather than from the first raw sample, so a controller that
    /// booted with a shorted input does not read it as a press.
    [[nodiscard]] bool settled() const noexcept { return settled_; }

    [[nodiscard]] std::string_view signal_id() const noexcept { return config_.signal_id; }

  private:
    DiscreteInputConfig config_{};
    bool level_{false};
    bool candidate_{false};
    bool settled_{false};
    bool stuck_{false};
    std::uint64_t candidate_since_{0};
    std::uint64_t asserted_since_{0};
};

// ---------------------------------------------------------------------------------------
// Analogue channels
// ---------------------------------------------------------------------------------------

/// The conditioning a channel's controlled diagnostic action calls for. The mapping from
/// one to the other is held in scripts/check-io-map.mjs, so a diagnostic action cannot be
/// changed in the baseline without the firmware being told.
enum class Conditioning : std::uint8_t { RangeRate, Median, WindowedRms };

/// The longest window any controlled channel declares. Fixed so the whole layer allocates
/// nothing: CH1-EMB-FDS-0001 bounds heap use in control tasks.
inline constexpr std::size_t maximum_window = 32;

struct AnalogueChannelConfig {
    std::string_view signal_id{};
    /// The controlled telemetry channel this feeds. Same catalogue the gateway enforces.
    std::string_view channel_id{};
    std::string_view unit{};
    Conditioning conditioning{Conditioning::RangeRate};
    double valid_minimum{0.0};
    double valid_maximum{0.0};
    /// RangeRate only. A step larger than this per second is implausible for the physical
    /// quantity and is reported Uncertain rather than hidden.
    double maximum_rate_per_second{0.0};
    /// Median and WindowedRms only. Clamped to `maximum_window`.
    std::size_t window{1};
    /// A channel with no sample newer than this is Bad. CH1-EMB-FDS-0001 requires sensors
    /// to carry freshness, and an old number presented as current is worse than none.
    std::uint32_t stale_after_milliseconds{5000};
};

/// One conditioned reading, carrying everything CH1-COM-ICD-0001 requires of telemetry and
/// CH1-VVT-TC-0041 requires of a measurement.
struct ConditionedReading {
    std::string_view channel_id{};
    double value{0.0};
    std::string_view unit{};
    Quality quality{Quality::Bad};
    std::int64_t sampled_at_milliseconds{-1};
    /// True when `value` is a stand-in rather than a measurement. Always Bad quality.
    bool substituted{false};
    /// True when the channel has enough samples to answer at all. A window that has not
    /// filled publishes nothing rather than a partial average.
    bool publishable{false};
};

/// One conditioned analogue channel.
class AnalogueChannel final {
  public:
    explicit AnalogueChannel(AnalogueChannelConfig config) noexcept;

    /// Offers one raw engineering-unit sample.
    ///
    /// `sampled_at_milliseconds` is the SOURCE time — when the sensor observed it, not when
    /// this ran. A negative value means the controller could not judge the time, and the
    /// sample is rejected: a reading whose age is unknown cannot carry freshness.
    void sample(
        double raw_value,
        std::int64_t sampled_at_milliseconds,
        std::uint64_t monotonic_now_milliseconds) noexcept;

    /// What this channel would publish now, staleness applied.
    [[nodiscard]] ConditionedReading read(std::uint64_t monotonic_now_milliseconds) const noexcept;

    [[nodiscard]] std::string_view signal_id() const noexcept { return config_.signal_id; }

  private:
    [[nodiscard]] bool in_range(double value) const noexcept;
    [[nodiscard]] std::size_t window() const noexcept;
    [[nodiscard]] double median() const noexcept;
    [[nodiscard]] double root_mean_square() const noexcept;

    AnalogueChannelConfig config_{};
    std::array<double, maximum_window> history_{};
    std::size_t filled_{0};
    std::size_t next_{0};
    double last_accepted_{0.0};
    std::int64_t last_accepted_at_{-1};
    std::uint64_t last_sample_monotonic_{0};
    bool has_sample_{false};
    bool rate_exceeded_{false};
    bool out_of_range_{false};
};

// ---------------------------------------------------------------------------------------
// Watchdog
// ---------------------------------------------------------------------------------------

/// The most supervised tasks the controller declares. Fixed, for the same reason as
/// `maximum_window`.
inline constexpr std::size_t maximum_supervised_tasks = 8;

/// Supervises the tasks whose liveness the actuator enable depends on.
///
/// CH1-VVT-TC-0073 requires a simulated task failure to remove the actuator enable, and
/// CH1-EMB-FDS-0001 places the watchdog in firmware against real timing. The timing is real
/// on the board; the DECISION is here, where it can be exercised on a host by advancing a
/// clock that never runs.
class OutputWatchdog final {
  public:
    /// Registers a supervised task and returns its handle. Returns `maximum_supervised_tasks`
    /// if the table is full, which `healthy` then treats as unhealthy rather than silently
    /// supervising one task fewer.
    std::size_t supervise(
        std::string_view name,
        std::uint32_t deadline_milliseconds,
        std::uint64_t monotonic_now_milliseconds) noexcept;

    void check_in(std::size_t handle, std::uint64_t monotonic_now_milliseconds) noexcept;

    [[nodiscard]] bool healthy(std::uint64_t monotonic_now_milliseconds) const noexcept;

    /// The first task past its deadline, for the diagnostic. Empty when healthy.
    [[nodiscard]] std::string_view first_overdue(std::uint64_t monotonic_now_milliseconds) const noexcept;

    [[nodiscard]] std::size_t count() const noexcept { return count_; }
    [[nodiscard]] bool overflowed() const noexcept { return overflowed_; }

  private:
    struct Task {
        std::string_view name{};
        std::uint32_t deadline{0};
        std::uint64_t last_check_in{0};
    };

    std::array<Task, maximum_supervised_tasks> tasks_{};
    std::size_t count_{0};
    bool overflowed_{false};
};

// ---------------------------------------------------------------------------------------
// Time quality
// ---------------------------------------------------------------------------------------

/// CH1-COM-FR-0009 requires every device to report time-quality status, and
/// CH1-COM-ICD-0001 requires time quality to be visible so audit decisions are not silently
/// made on invalid time.
enum class TimeQuality : std::uint8_t {
    /// Never disciplined. The controller cannot judge an expiry and says so.
    Unsynchronised,
    /// Disciplined recently enough that its own clock is trusted.
    Synchronised,
    /// Disciplined once, and drifting since. Good enough to stamp a sample, not good enough
    /// to judge a command's expiry.
    Holdover,
    /// Disciplined so long ago that the drift is no longer bounded by anything.
    Stale,
};

[[nodiscard]] std::string_view time_quality_name(TimeQuality quality) noexcept;

struct TimeSourceConfig {
    /// Beyond this since the last discipline, the clock is in holdover.
    std::uint32_t synchronised_for_milliseconds{3600000};
    /// Beyond this since the last discipline, the clock is stale and carries nothing.
    std::uint32_t holdover_for_milliseconds{86400000};
};

/// The controller's wall clock and its honest opinion of itself.
///
/// Two accessors, deliberately different in strictness. `report_clock` stamps a telemetry
/// sample and accepts holdover, because a sample carrying a slightly drifted time and
/// saying so is more useful than no sample. `command_clock` judges a prepared command's
/// expiry and accepts nothing but a synchronised clock, because a command accepted on a
/// drifted clock is an intent with no bound on how long it was in flight.
class TimeSource final {
  public:
    TimeSource() noexcept = default;
    explicit TimeSource(TimeSourceConfig config) noexcept : config_{config} {}

    /// Records a successful discipline — an SNTP sync on the board.
    void disciplined(std::int64_t wall_clock_milliseconds, std::uint64_t monotonic_now_milliseconds) noexcept;

    [[nodiscard]] TimeQuality quality(std::uint64_t monotonic_now_milliseconds) const noexcept;

    /// Wall-clock milliseconds for stamping an observation, or -1 when the clock carries
    /// nothing. Accepts Synchronised and Holdover.
    [[nodiscard]] std::int64_t report_clock(std::uint64_t monotonic_now_milliseconds) const noexcept;

    /// Wall-clock milliseconds for judging a command expiry, or -1. Accepts Synchronised
    /// only, so a command met by a drifting clock is refused rather than guessed at.
    [[nodiscard]] std::int64_t command_clock(std::uint64_t monotonic_now_milliseconds) const noexcept;

  private:
    TimeSourceConfig config_{};
    std::int64_t wall_at_discipline_{-1};
    std::uint64_t monotonic_at_discipline_{0};
    bool disciplined_{false};
};

// ---------------------------------------------------------------------------------------
// Output plan
// ---------------------------------------------------------------------------------------

/// CH1-IO-DO-0005's controlled diagnostic action is "Pattern controlled". A buzzer that
/// sounds continuously is silenced by the operator on the first day and then means nothing,
/// so there is no continuous member here to select.
enum class BuzzerPattern : std::uint8_t {
    Silent,
    /// One short beep, once, on entering the state. Completion.
    SingleBeep,
    /// 1 Hz. A confirmation is now available and the button is live.
    SlowPulse,
    /// 4 Hz. A latched fault, or a watchdog that has stopped being fed.
    FastPulse,
};

[[nodiscard]] std::string_view buzzer_pattern_name(BuzzerPattern pattern) noexcept;

/// What the outputs SHOULD be. Computing this is not driving it: nothing in this tree
/// applies a plan to a pin, and `firmware/pinmap/esp32s3-r01.json` records that no actuator
/// output is energisable at this hardware revision.
struct OutputPlan {
    bool confirmation_lamp{false};
    bool green_indicator{false};
    bool amber_indicator{false};
    bool red_indicator{false};
    BuzzerPattern buzzer_pattern{BuzzerPattern::Silent};
    /// The instantaneous level the pattern calls for at this moment.
    bool buzzer{false};
    /// CH1-IO-DO-0006. False in every state but Executing, and false regardless when the
    /// watchdog is unhealthy.
    bool actuator_enable{false};
    /// CH1-IO-PWM-0001. Never true without `actuator_enable`, and rate-limited.
    bool step_enable{false};
    std::int32_t step_rate_per_second{0};
    /// Why the actuator enable was withheld when the state alone would have granted it.
    /// Empty when nothing was withheld.
    std::string_view inhibit_reason{};
};

struct OutputPlannerConfig {
    /// CH1-IO-PWM-0001's controlled diagnostic action is "Rate and travel limited".
    std::int32_t maximum_steps_per_second{2000};
    std::uint32_t single_beep_milliseconds{200};
};

/// The state the planner is asked about. Deliberately not `cell::State` — this header is
/// the I/O layer and must not depend on the command state machine, so the caller maps one
/// to the other and the mapping is visible where it is made.
enum class CellCondition : std::uint8_t {
    Initialising,
    Idle,
    AwaitCredential,
    AwaitButton,
    Committed,
    Executing,
    Complete,
    FaultLatched,
    /// CH1-AUT-FDS-0001's state diagram puts Recovery between FaultLatched and Idle: the
    /// cause has gone and the reset edge has been seen, and the work-order state has not
    /// yet been reconciled. Neither ready nor faulted, and not energisable.
    Recovery,
};

/// Everything outside the command state machine that can withhold an output.
struct Diagnostics {
    bool watchdog_healthy{true};
    /// Any conditioned discrete input that has latched a stuck fault.
    bool discrete_input_stuck{false};
    /// A permissive whose conditioned circuit is open — a cut conductor, not a demand.
    bool permissive_circuit_open{false};
    std::string_view detail{};
};

/// Maps a cell condition and the diagnostics onto the six controlled outputs.
///
/// Stateless except for the beep it has to remember it started, so a caller may build one
/// per tick if that reads better. The indicator conditions are the controlled table's own,
/// one for one: the confirmation lamp is lit in AwaitButton and nowhere else, green is
/// ready or complete, amber is prepared or warning, red is a latched fault.
class OutputPlanner final {
  public:
    OutputPlanner() noexcept = default;
    explicit OutputPlanner(OutputPlannerConfig config) noexcept : config_{config} {}

    [[nodiscard]] OutputPlan plan(
        CellCondition condition,
        const Diagnostics& diagnostics,
        std::uint64_t monotonic_now_milliseconds) noexcept;

  private:
    OutputPlannerConfig config_{};
    CellCondition previous_{CellCondition::Initialising};
    std::uint64_t beep_started_{0};
    bool beeping_{false};
};

}  // namespace cinerion::io
