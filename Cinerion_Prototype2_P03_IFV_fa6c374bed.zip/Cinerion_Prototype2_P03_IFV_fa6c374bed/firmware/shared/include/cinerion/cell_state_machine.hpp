// The cell state machine the controller runs. Same states and arrows as the controlled
// diagram.

#pragma once

#include <cstdint>

namespace cinerion::cell {

/// The states of CH1-AUT-FDS-0001's local cell-controller state machine, as the
/// controlled diagram draws them. `firmware/statemap/cell-state-machine-r01.json`
/// binds each name here to that diagram and `npm run cell:map` refuses drift in
/// either direction, so a state added or removed below has to come from the
/// controlled source.
enum class State : std::uint8_t {
    Initialising,
    Idle,
    AwaitCredential,
    AwaitButton,
    Committed,
    Executing,
    Complete,
    FaultLatched,
    Recovery,
};

enum class Result : std::uint8_t {
    Accepted,
    StateInvalid,
    ScopeMismatch,
    RevisionMismatch,
    SequenceReplay,
    Expired,
    ButtonHeld,
    CredentialInvalid,
    CredentialExpired,
    PhysicalEdgeRequired,
    InterlockInvalid,
    ControllerRestarted,
    FaultCauseActive,
    LocalResetRequired,
    /// The work order, part or configuration revision offered to close a recovery is
    /// not the one this controller is bound to. CH1-AUT-FDS-0001 requires recovery to
    /// verify "reconciled work-order state"; a controller that returned to Idle without
    /// it would accept the next PREPARE for a part whose state nobody had established.
    WorkOrderNotReconciled,
};

struct LocalInputs {
    bool start_enable{};
    bool stop_circuit_healthy{};
    bool guard_healthy{};
    bool actuator_home{};
    bool confirmation_button{};
    bool reset_button{};
    bool fault_cause_active{};
};

struct PrepareRequest {
    std::uint64_t command_id{};
    std::uint64_t confirmation_id{};
    std::uint64_t cell_id{};
    std::uint64_t asset_id{};
    std::uint64_t work_order_id{};
    std::uint64_t part_id{};
    std::uint64_t sequence{};
    std::uint32_t configuration_revision{};
    std::uint64_t controller_boot_id{};
    std::uint64_t expires_at_ms{};
};

struct CredentialProof {
    std::uint64_t command_id{};
    std::uint64_t confirmation_id{};
    std::uint64_t cell_id{};
    bool cryptographically_verified{};
    bool user_verified{};
    std::uint64_t expires_at_ms{};
};

struct CellBinding {
    std::uint64_t cell_id{};
    std::uint64_t asset_id{};
    std::uint64_t work_order_id{};
    std::uint64_t part_id{};
    std::uint32_t configuration_revision{};
};

/// What is offered to close out a completed procedure. CH1-AUT-FDS-0001's state
/// diagram leaves `Complete` on "acknowledge completion / new order"; binding the
/// acknowledgement to the command it acknowledges keeps a stale or misdirected one
/// from clearing a different procedure's completion.
struct CompletionAcknowledgement {
    std::uint64_t command_id{};
    std::uint64_t cell_id{};
};

/// What is offered to close out a recovery. CH1-AUT-FDS-0001: "Recovery verifies cause
/// removed, local authority, reset edge and reconciled work-order state; interrupted
/// execution never resumes automatically." The first three are established by the local
/// reset edge that entered Recovery; this carries the fourth.
struct RecoveryReconciliation {
    std::uint64_t cell_id{};
    std::uint64_t asset_id{};
    std::uint64_t work_order_id{};
    std::uint64_t part_id{};
    std::uint32_t configuration_revision{};
    std::uint64_t controller_boot_id{};
};

struct Outputs {
    bool confirmation_lamp{};
    bool green_indicator{};
    bool amber_indicator{};
    bool red_indicator{};
    bool actuator_enable{};
};

/// Portable, allocation-free command state machine. Machine safety functions
/// remain external and independently authoritative.
class StateMachine final {
  public:
    explicit StateMachine(CellBinding binding, std::uint64_t controller_boot_id) noexcept;

    [[nodiscard]] Result initialise(const LocalInputs& inputs) noexcept;

    /// requirements: CH1-CMD-FR-0002, CH1-CMD-FR-0004, CH1-CMD-FR-0006
    [[nodiscard]] Result prepare(
        const PrepareRequest& request,
        const LocalInputs& inputs,
        std::uint64_t monotonic_now_ms) noexcept;

    /// requirements: CH1-CMD-FR-0003, CH1-IAM-FR-0005, CH1-IAM-FR-0007
    [[nodiscard]] Result accept_credential(
        const CredentialProof& proof,
        std::uint64_t monotonic_now_ms) noexcept;

    /// This entry point is for the conditioned physical DI sample only. Network
    /// and protocol tasks shall not call it.
    /// requirements: CH1-CMD-FR-0003, CH1-CMD-FR-0005, CH1-CMD-FR-0007, CH1-CMD-FR-0008
    [[nodiscard]] Result sample_physical_confirmation(
        const LocalInputs& inputs,
        std::uint64_t monotonic_now_ms) noexcept;

    [[nodiscard]] Result begin_execution() noexcept;
    [[nodiscard]] Result complete_execution() noexcept;
    [[nodiscard]] Result latch_fault() noexcept;

    /// Leaves `Complete` for `Idle`, which is the transition CH1-AUT-FDS-0001's state
    /// diagram labels "acknowledge completion / new order". Without it a controller
    /// accepts exactly one procedure per boot.
    ///
    /// It confers nothing. `Idle` is the least privileged state in this machine: the
    /// next procedure still needs a valid PREPARE, a verified credential, a new physical
    /// button edge and healthy interlocks, every one of which is re-evaluated from
    /// scratch. What it does preserve is the replay bound — the sequence high-water mark
    /// survives, so the command that has just run cannot be offered again.
    /// requirements: CH1-CMD-FR-0002, CH1-AUT-FDS-0001
    [[nodiscard]] Result acknowledge_completion(
        const CompletionAcknowledgement& acknowledgement) noexcept;

    /// This entry point is for the conditioned physical reset DI sample only.
    /// Leaves `FaultLatched` for `Recovery` — not for `Idle`. The reset edge establishes
    /// three of the four things CH1-AUT-FDS-0001 requires of a recovery; the fourth is
    /// the work-order reconciliation `accept_recovery` carries.
    /// requirements: CH1-CMD-FR-0010
    [[nodiscard]] Result sample_physical_reset(const LocalInputs& inputs) noexcept;

    /// Leaves `Recovery` for `Idle` once the work-order state offered matches the one
    /// this controller is bound to. Interrupted execution never resumes: this returns
    /// the cell to `Idle`, never to `Executing`.
    /// requirements: CH1-CMD-FR-0010, CH1-AUT-FDS-0001
    [[nodiscard]] Result accept_recovery(
        const RecoveryReconciliation& reconciliation,
        const LocalInputs& inputs) noexcept;

    /// Cancels pending work on timeout; never auto-continues.
    void tick(std::uint64_t monotonic_now_ms) noexcept;

    [[nodiscard]] State state() const noexcept { return state_; }
    [[nodiscard]] Outputs outputs() const noexcept;
    [[nodiscard]] std::uint64_t last_sequence() const noexcept { return last_sequence_; }

  private:
    [[nodiscard]] bool binding_matches(const PrepareRequest& request) const noexcept;
    [[nodiscard]] static bool permissives_valid(const LocalInputs& inputs) noexcept;
    void cancel_pending() noexcept;

    CellBinding binding_{};
    PrepareRequest prepared_{};
    State state_{State::Initialising};
    std::uint64_t controller_boot_id_{};
    std::uint64_t last_sequence_{};
    std::uint64_t credential_expires_at_ms_{};
    bool previous_confirmation_state_{};
    bool previous_reset_state_{};
};

}  // namespace cinerion::cell

