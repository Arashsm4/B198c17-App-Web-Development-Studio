// Where the cell decides what happens next. No credential and no button press means no commit.
// Full stop.

#include "cinerion/cell_state_machine.hpp"

namespace cinerion::cell {

StateMachine::StateMachine(const CellBinding binding, const std::uint64_t controller_boot_id) noexcept
    : binding_{binding}, controller_boot_id_{controller_boot_id} {}

Result StateMachine::initialise(const LocalInputs& inputs) noexcept {
    previous_confirmation_state_ = inputs.confirmation_button;
    previous_reset_state_ = inputs.reset_button;
    state_ = permissives_valid(inputs) && !inputs.confirmation_button ? State::Idle : State::Initialising;
    return state_ == State::Idle ? Result::Accepted : Result::InterlockInvalid;
}

Result StateMachine::prepare(
    const PrepareRequest& request,
    const LocalInputs& inputs,
    const std::uint64_t monotonic_now_ms) noexcept {
    if (state_ != State::Idle) {
        return Result::StateInvalid;
    }
    if (!binding_matches(request)) {
        return Result::ScopeMismatch;
    }
    if (request.configuration_revision != binding_.configuration_revision) {
        return Result::RevisionMismatch;
    }
    if (request.controller_boot_id != controller_boot_id_) {
        return Result::ControllerRestarted;
    }
    if (request.sequence <= last_sequence_) {
        return Result::SequenceReplay;
    }
    if (request.expires_at_ms <= monotonic_now_ms) {
        return Result::Expired;
    }
    if (inputs.confirmation_button) {
        previous_confirmation_state_ = true;
        return Result::ButtonHeld;
    }
    if (!permissives_valid(inputs)) {
        return Result::InterlockInvalid;
    }

    prepared_ = request;
    last_sequence_ = request.sequence;
    previous_confirmation_state_ = false;
    credential_expires_at_ms_ = 0;
    state_ = State::AwaitCredential;
    return Result::Accepted;
}

Result StateMachine::accept_credential(
    const CredentialProof& proof,
    const std::uint64_t monotonic_now_ms) noexcept {
    if (state_ != State::AwaitCredential) {
        return Result::StateInvalid;
    }
    if (prepared_.expires_at_ms <= monotonic_now_ms) {
        cancel_pending();
        return Result::Expired;
    }
    if (proof.command_id != prepared_.command_id || proof.confirmation_id != prepared_.confirmation_id ||
        proof.cell_id != prepared_.cell_id) {
        return Result::ScopeMismatch;
    }
    if (!proof.cryptographically_verified || !proof.user_verified) {
        return Result::CredentialInvalid;
    }
    if (proof.expires_at_ms <= monotonic_now_ms) {
        return Result::CredentialExpired;
    }

    credential_expires_at_ms_ = proof.expires_at_ms;
    state_ = State::AwaitButton;
    return Result::Accepted;
}

Result StateMachine::sample_physical_confirmation(
    const LocalInputs& inputs,
    const std::uint64_t monotonic_now_ms) noexcept {
    const bool rising_edge = !previous_confirmation_state_ && inputs.confirmation_button;
    previous_confirmation_state_ = inputs.confirmation_button;

    if (state_ != State::AwaitButton) {
        return Result::StateInvalid;
    }
    if (prepared_.expires_at_ms <= monotonic_now_ms) {
        cancel_pending();
        return Result::Expired;
    }
    if (credential_expires_at_ms_ <= monotonic_now_ms) {
        cancel_pending();
        return Result::CredentialExpired;
    }
    if (!rising_edge) {
        return Result::PhysicalEdgeRequired;
    }
    if (!permissives_valid(inputs)) {
        cancel_pending();
        return Result::InterlockInvalid;
    }

    state_ = State::Committed;
    return Result::Accepted;
}

Result StateMachine::begin_execution() noexcept {
    if (state_ != State::Committed) {
        return Result::StateInvalid;
    }
    state_ = State::Executing;
    return Result::Accepted;
}

Result StateMachine::complete_execution() noexcept {
    if (state_ != State::Executing) {
        return Result::StateInvalid;
    }
    state_ = State::Complete;
    return Result::Accepted;
}

Result StateMachine::latch_fault() noexcept {
    if (state_ != State::Committed && state_ != State::Executing) {
        return Result::StateInvalid;
    }
    state_ = State::FaultLatched;
    return Result::Accepted;
}

// CH1-AUT-FDS-0001's state diagram: Complete --acknowledge completion / new order--> Idle.
// The acknowledgement is bound to the command it acknowledges, for the same reason the
// credential proof is bound to the preparation: an acknowledgement that named nothing
// could clear a completion it had never seen.
//
// The sequence high-water mark is deliberately NOT reset. It is the replay bound, and a
// procedure that has run must not be offerable again.
Result StateMachine::acknowledge_completion(const CompletionAcknowledgement& acknowledgement) noexcept {
    if (state_ != State::Complete) {
        return Result::StateInvalid;
    }
    if (acknowledgement.command_id != prepared_.command_id || acknowledgement.cell_id != binding_.cell_id) {
        return Result::ScopeMismatch;
    }

    prepared_ = {};
    credential_expires_at_ms_ = 0;
    state_ = State::Idle;
    return Result::Accepted;
}

Result StateMachine::sample_physical_reset(const LocalInputs& inputs) noexcept {
    const bool rising_edge = !previous_reset_state_ && inputs.reset_button;
    previous_reset_state_ = inputs.reset_button;
    if (state_ != State::FaultLatched) {
        return Result::StateInvalid;
    }
    if (!rising_edge) {
        return Result::LocalResetRequired;
    }
    if (inputs.fault_cause_active) {
        return Result::FaultCauseActive;
    }
    if (!inputs.stop_circuit_healthy || !inputs.guard_healthy) {
        return Result::InterlockInvalid;
    }
    // Recovery, not Idle. The reset edge establishes cause removed, local authority and
    // the edge itself; CH1-AUT-FDS-0001 requires a fourth thing — reconciled work-order
    // state — and a controller that went straight to Idle here would accept the next
    // PREPARE for a part whose state nobody had re-established after the fault.
    state_ = State::Recovery;
    return Result::Accepted;
}

// CH1-AUT-FDS-0001's state diagram: Recovery --recovery accepted--> Idle.
Result StateMachine::accept_recovery(
    const RecoveryReconciliation& reconciliation,
    const LocalInputs& inputs) noexcept {
    if (state_ != State::Recovery) {
        return Result::StateInvalid;
    }
    if (reconciliation.controller_boot_id != controller_boot_id_) {
        return Result::ControllerRestarted;
    }
    if (reconciliation.cell_id != binding_.cell_id || reconciliation.asset_id != binding_.asset_id) {
        return Result::ScopeMismatch;
    }
    if (reconciliation.work_order_id != binding_.work_order_id || reconciliation.part_id != binding_.part_id) {
        return Result::WorkOrderNotReconciled;
    }
    if (reconciliation.configuration_revision != binding_.configuration_revision) {
        return Result::RevisionMismatch;
    }
    if (inputs.fault_cause_active) {
        return Result::FaultCauseActive;
    }
    if (!permissives_valid(inputs)) {
        return Result::InterlockInvalid;
    }

    // Interrupted execution never resumes automatically: this returns the cell to Idle,
    // where the whole handshake has to run again, and never to Executing.
    prepared_ = {};
    credential_expires_at_ms_ = 0;
    previous_confirmation_state_ = inputs.confirmation_button;
    state_ = State::Idle;
    return Result::Accepted;
}

void StateMachine::tick(const std::uint64_t monotonic_now_ms) noexcept {
    if ((state_ == State::AwaitCredential || state_ == State::AwaitButton) &&
        prepared_.expires_at_ms <= monotonic_now_ms) {
        cancel_pending();
    }
}

Outputs StateMachine::outputs() const noexcept {
    return Outputs{
        .confirmation_lamp = state_ == State::AwaitButton,
        .green_indicator = state_ == State::Idle || state_ == State::Complete,
        // CH1-IO-DO-0003 is the "prepared/warning indication". Recovery is a warning: the
        // cause has gone and the reset edge has been seen, and the cell is still not ready.
        .amber_indicator = state_ == State::AwaitCredential || state_ == State::AwaitButton ||
                           state_ == State::Committed || state_ == State::Recovery,
        .red_indicator = state_ == State::FaultLatched,
        .actuator_enable = state_ == State::Executing,
    };
}

bool StateMachine::binding_matches(const PrepareRequest& request) const noexcept {
    return request.cell_id == binding_.cell_id && request.asset_id == binding_.asset_id &&
           request.work_order_id == binding_.work_order_id && request.part_id == binding_.part_id;
}

bool StateMachine::permissives_valid(const LocalInputs& inputs) noexcept {
    return inputs.start_enable && inputs.stop_circuit_healthy && inputs.guard_healthy && inputs.actuator_home &&
           !inputs.fault_cause_active;
}

void StateMachine::cancel_pending() noexcept {
    prepared_ = {};
    credential_expires_at_ms_ = 0;
    previous_confirmation_state_ = false;
    if (state_ != State::FaultLatched) {
        state_ = State::Idle;
    }
}

}  // namespace cinerion::cell

