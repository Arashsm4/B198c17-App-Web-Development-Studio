// CBOR encoding and decoding for the envelope. Byte for byte what the gateway expects, and a
// test makes sure.

#include "cinerion/cbor.hpp"

#include <cstring>

namespace cinerion::cbor {
namespace {

constexpr std::uint8_t kFalse = 0xF4;
constexpr std::uint8_t kTrue = 0xF5;
constexpr std::uint8_t kNull = 0xF6;
constexpr std::uint8_t kHalf = 0xF9;
constexpr std::uint8_t kSingle = 0xFA;
constexpr std::uint8_t kDouble = 0xFB;

std::uint64_t load_big_endian(std::span<const std::uint8_t> data, std::size_t width) noexcept {
    std::uint64_t value = 0;
    for (std::size_t index = 0; index < width; ++index) {
        value = (value << 8) | data[index];
    }
    return value;
}

}  // namespace

// ------------------------------------------------------------------------ Writer

void Writer::raw(std::uint8_t byte) noexcept {
    if (overflowed_ || position_ >= buffer_.size()) {
        overflowed_ = true;
        return;
    }
    buffer_[position_++] = byte;
}

void Writer::raw(std::span<const std::uint8_t> data) noexcept {
    if (overflowed_ || position_ + data.size() > buffer_.size()) {
        overflowed_ = true;
        return;
    }
    std::memcpy(buffer_.data() + position_, data.data(), data.size());
    position_ += data.size();
}

// Canonical encoding requires the shortest head that can express the argument. A longer
// one is legal CBOR and would encode the same value differently, which would break the
// byte-for-byte agreement this format is checked by.
void Writer::head(MajorType type, std::uint64_t argument) noexcept {
    const auto major = static_cast<std::uint8_t>(static_cast<std::uint8_t>(type) << 5);
    if (argument < 24) {
        raw(static_cast<std::uint8_t>(major | argument));
    } else if (argument <= 0xFF) {
        raw(static_cast<std::uint8_t>(major | 24));
        raw(static_cast<std::uint8_t>(argument));
    } else if (argument <= 0xFFFF) {
        raw(static_cast<std::uint8_t>(major | 25));
        raw(static_cast<std::uint8_t>(argument >> 8));
        raw(static_cast<std::uint8_t>(argument));
    } else if (argument <= 0xFFFFFFFF) {
        raw(static_cast<std::uint8_t>(major | 26));
        for (int shift = 24; shift >= 0; shift -= 8) {
            raw(static_cast<std::uint8_t>(argument >> shift));
        }
    } else {
        raw(static_cast<std::uint8_t>(major | 27));
        for (int shift = 56; shift >= 0; shift -= 8) {
            raw(static_cast<std::uint8_t>(argument >> shift));
        }
    }
}

void Writer::unsigned_value(std::uint64_t value) noexcept {
    head(MajorType::unsigned_integer, value);
}

void Writer::signed_value(std::int64_t value) noexcept {
    if (value < 0) {
        head(MajorType::negative_integer, static_cast<std::uint64_t>(-(value + 1)));
    } else {
        head(MajorType::unsigned_integer, static_cast<std::uint64_t>(value));
    }
}

void Writer::boolean(bool value) noexcept { raw(value ? kTrue : kFalse); }

void Writer::null_value() noexcept { raw(kNull); }

// Canonical CBOR requires the SHORTEST floating-point form that represents the value
// exactly: half if it round-trips, then single, then double. This is not an optimisation.
// The gateway decodes in Canonical mode and refuses a longer encoding of a value that
// would have fitted in a shorter one, so a controller that always emitted 64-bit doubles
// would have every reading rejected — and would only discover that against real hardware.
// 22.5 degC encodes as a half, which is exactly the case that found this.
void Writer::double_value(double value) noexcept {
    const auto emit = [this](std::uint8_t head_byte, std::uint64_t bits, int width) noexcept {
        raw(head_byte);
        for (int shift = (width - 1) * 8; shift >= 0; shift -= 8) {
            raw(static_cast<std::uint8_t>(bits >> shift));
        }
    };

    const auto single = static_cast<float>(value);
    if (static_cast<double>(single) != value) {
        std::uint64_t bits = 0;
        static_assert(sizeof(bits) == sizeof(value), "double must be 64-bit");
        std::memcpy(&bits, &value, sizeof(bits));
        // NaN and infinities never round-trip through the comparison above, so they land
        // here and are emitted in full rather than being silently narrowed.
        emit(kDouble, bits, 8);
        return;
    }

    std::uint32_t single_bits = 0;
    static_assert(sizeof(single_bits) == sizeof(single), "float must be 32-bit");
    std::memcpy(&single_bits, &single, sizeof(single_bits));

    const std::uint32_t exponent = (single_bits >> 23) & 0xFF;
    const std::uint32_t mantissa = single_bits & 0x7FFFFF;
    const std::uint32_t sign = (single_bits >> 16) & 0x8000;

    // A single narrows to a half exactly when its exponent is in the half's normal range
    // and the low 13 mantissa bits are zero. Zero is the other exact case.
    if (single_bits == 0 || single_bits == 0x80000000u) {
        emit(kHalf, sign, 2);
        return;
    }

    if (exponent >= 113 && exponent <= 142 && (mantissa & 0x1FFF) == 0) {
        const std::uint32_t half =
            sign | ((exponent - 112) << 10) | (mantissa >> 13);
        emit(kHalf, half, 2);
        return;
    }

    emit(kSingle, single_bits, 4);
}

void Writer::text(std::string_view value) noexcept {
    head(MajorType::text_string, value.size());
    raw({reinterpret_cast<const std::uint8_t*>(value.data()), value.size()});
}

void Writer::bytes(std::span<const std::uint8_t> value) noexcept {
    head(MajorType::byte_string, value.size());
    raw(value);
}

void Writer::array_header(std::size_t count) noexcept { head(MajorType::array, count); }

void Writer::map_header(std::size_t count) noexcept { head(MajorType::map, count); }

// ------------------------------------------------------------------------ Reader

bool Reader::head(MajorType& type, std::uint64_t& argument) noexcept {
    if (failed_ || position_ >= buffer_.size()) {
        fail();
        return false;
    }

    const std::uint8_t initial = buffer_[position_++];
    type = static_cast<MajorType>(initial >> 5);
    const std::uint8_t additional = initial & 0x1F;

    if (additional < 24) {
        argument = additional;
        return true;
    }

    std::size_t width = 0;
    switch (additional) {
        case 24: width = 1; break;
        case 25: width = 2; break;
        case 26: width = 4; break;
        case 27: width = 8; break;
        // 28-30 are reserved and 31 is indefinite length. A controlled envelope is
        // definite-length, so both are refused rather than tolerated.
        default: fail(); return false;
    }

    if (position_ + width > buffer_.size()) {
        fail();
        return false;
    }

    argument = load_big_endian(buffer_.subspan(position_, width), width);
    position_ += width;
    return true;
}

ItemKind Reader::peek() const noexcept {
    if (failed_ || position_ >= buffer_.size()) return ItemKind::invalid;
    const std::uint8_t initial = buffer_[position_];
    switch (static_cast<MajorType>(initial >> 5)) {
        case MajorType::unsigned_integer: return ItemKind::unsigned_integer;
        case MajorType::negative_integer: return ItemKind::negative_integer;
        case MajorType::byte_string: return ItemKind::byte_string;
        case MajorType::text_string: return ItemKind::text_string;
        case MajorType::array: return ItemKind::array;
        case MajorType::map: return ItemKind::map;
        case MajorType::simple:
            if (initial == kFalse || initial == kTrue) return ItemKind::boolean;
            if (initial == kNull) return ItemKind::null_item;
            if (initial == kDouble) return ItemKind::double_item;
            return ItemKind::invalid;
        default: return ItemKind::invalid;
    }
}

std::size_t Reader::map_header() noexcept {
    MajorType type{};
    std::uint64_t argument = 0;
    if (!head(type, argument) || type != MajorType::map) {
        fail();
        return 0;
    }
    return static_cast<std::size_t>(argument);
}

std::size_t Reader::array_header() noexcept {
    MajorType type{};
    std::uint64_t argument = 0;
    if (!head(type, argument) || type != MajorType::array) {
        fail();
        return 0;
    }
    return static_cast<std::size_t>(argument);
}

std::uint64_t Reader::unsigned_value() noexcept {
    MajorType type{};
    std::uint64_t argument = 0;
    if (!head(type, argument) || type != MajorType::unsigned_integer) {
        fail();
        return 0;
    }
    return argument;
}

std::int64_t Reader::signed_value() noexcept {
    MajorType type{};
    std::uint64_t argument = 0;
    if (!head(type, argument)) {
        fail();
        return 0;
    }
    if (type == MajorType::unsigned_integer) return static_cast<std::int64_t>(argument);
    if (type == MajorType::negative_integer) return -1 - static_cast<std::int64_t>(argument);
    fail();
    return 0;
}

bool Reader::boolean() noexcept {
    if (failed_ || position_ >= buffer_.size()) {
        fail();
        return false;
    }
    const std::uint8_t initial = buffer_[position_];
    if (initial != kTrue && initial != kFalse) {
        fail();
        return false;
    }
    ++position_;
    return initial == kTrue;
}

double Reader::double_value() noexcept {
    if (failed_ || position_ + 9 > buffer_.size() || buffer_[position_] != kDouble) {
        fail();
        return 0.0;
    }
    ++position_;
    const std::uint64_t bits = load_big_endian(buffer_.subspan(position_, 8), 8);
    position_ += 8;
    double value = 0.0;
    std::memcpy(&value, &bits, sizeof(value));
    return value;
}

std::string_view Reader::text() noexcept {
    MajorType type{};
    std::uint64_t argument = 0;
    if (!head(type, argument) || type != MajorType::text_string ||
        position_ + argument > buffer_.size()) {
        fail();
        return {};
    }
    const auto view = std::string_view(
        reinterpret_cast<const char*>(buffer_.data() + position_), static_cast<std::size_t>(argument));
    position_ += static_cast<std::size_t>(argument);
    return view;
}

std::span<const std::uint8_t> Reader::bytes() noexcept {
    MajorType type{};
    std::uint64_t argument = 0;
    if (!head(type, argument) || type != MajorType::byte_string ||
        position_ + argument > buffer_.size()) {
        fail();
        return {};
    }
    const auto view = buffer_.subspan(position_, static_cast<std::size_t>(argument));
    position_ += static_cast<std::size_t>(argument);
    return view;
}

void Reader::skip() noexcept {
    switch (peek()) {
        case ItemKind::unsigned_integer:
        case ItemKind::negative_integer: {
            MajorType type{};
            std::uint64_t argument = 0;
            (void)head(type, argument);
            break;
        }
        case ItemKind::byte_string: (void)bytes(); break;
        case ItemKind::text_string: (void)text(); break;
        case ItemKind::boolean: (void)boolean(); break;
        case ItemKind::double_item: (void)double_value(); break;
        case ItemKind::null_item: ++position_; break;
        case ItemKind::array: {
            const std::size_t count = array_header();
            for (std::size_t index = 0; index < count && !failed_; ++index) skip();
            break;
        }
        case ItemKind::map: {
            const std::size_t count = map_header();
            for (std::size_t index = 0; index < count && !failed_; ++index) {
                skip();
                skip();
            }
            break;
        }
        case ItemKind::invalid:
        default: fail(); break;
    }
}

}  // namespace cinerion::cbor
