// The input conditioning itself. A twitchy switch is not a real press.

#include "cinerion/conditioned_io.hpp"

#include <algorithm>
#include <cmath>

namespace cinerion::io {

std::string_view quality_name(const Quality quality) noexcept {
    switch (quality) {
        case Quality::Good:
            return "Good";
        case Quality::Uncertain:
            return "Uncertain";
        case Quality::Bad:
            break;
    }
    return "Bad";
}

// ---------------------------------------------------------------------------------------
// Discrete inputs
// ---------------------------------------------------------------------------------------

DiscreteInput::DiscreteInput(const DiscreteInputConfig config) noexcept : config_{config} {
    // A normally closed circuit reads high when it is intact, and intact is the state it
    // must start in for `asserted()` to mean "the loop has opened" from the first sample.
    // A normally open one starts low. Either way the starting value is the de-energised
    // one, which is the whole point of CH1-VVT-TC-0072's safe startup.
    level_ = config_.circuit == Circuit::NormallyClosed;
    candidate_ = level_;
}

void DiscreteInput::sample(const bool raw_level, const std::uint64_t monotonic_now_milliseconds) noexcept {
    if (raw_level != candidate_) {
        candidate_ = raw_level;
        candidate_since_ = monotonic_now_milliseconds;
        return;
    }

    // The candidate has held. A time bound rather than a sample count, so a task that ran
    // late does not shorten the debounce it was supposed to apply.
    const bool held_long_enough =
        monotonic_now_milliseconds - candidate_since_ >= config_.debounce_milliseconds;
    if (!held_long_enough) {
        return;
    }

    if (level_ != candidate_ || !settled_) {
        const bool was_asserted = asserted();
        level_ = candidate_;
        settled_ = true;
        if (asserted() && !was_asserted) {
            asserted_since_ = monotonic_now_milliseconds;
        }
        if (!asserted()) {
            // Seen to release. A stuck fault is cleared only here, never by time passing:
            // an input that is still asserted has not proved anything.
            stuck_ = false;
        }
    }

    if (config_.stuck_asserted_milliseconds == 0 || !asserted() || stuck_) {
        return;
    }
    if (monotonic_now_milliseconds - asserted_since_ >= config_.stuck_asserted_milliseconds) {
        stuck_ = true;
    }
}

bool DiscreteInput::asserted() const noexcept {
    if (stuck_) {
        // A stuck signal asserts nothing. A welded confirmation contact reads as a
        // permanent press, and without this it would offer an edge on the first sample
        // after every restart — which is exactly the confirmation CH1-CMD-FR-0003 requires
        // a person to make.
        return false;
    }
    return config_.circuit == Circuit::NormallyClosed ? !level_ : level_;
}

bool DiscreteInput::circuit_healthy() const noexcept {
    return config_.circuit == Circuit::NormallyClosed ? level_ : true;
}

// ---------------------------------------------------------------------------------------
// Analogue channels
// ---------------------------------------------------------------------------------------

AnalogueChannel::AnalogueChannel(const AnalogueChannelConfig config) noexcept : config_{config} {}

std::size_t AnalogueChannel::window() const noexcept {
    return std::clamp<std::size_t>(config_.window, 1, maximum_window);
}

bool AnalogueChannel::in_range(const double value) const noexcept {
    return std::isfinite(value) && value >= config_.valid_minimum && value <= config_.valid_maximum;
}

void AnalogueChannel::sample(
    const double raw_value,
    const std::int64_t sampled_at_milliseconds,
    const std::uint64_t monotonic_now_milliseconds) noexcept {
    if (sampled_at_milliseconds < 0) {
        // The controller could not judge the time. A reading whose age is unknown cannot
        // carry freshness, and CH1-COM-ICD-0001 requires telemetry to carry the source
        // sample time — so it is refused rather than stamped with the send time.
        return;
    }

    out_of_range_ = !in_range(raw_value);
    if (out_of_range_) {
        // Plausibility failed. Nothing enters the window: one impossible number would
        // otherwise drag a median or an RMS for the whole window's length.
        last_sample_monotonic_ = monotonic_now_milliseconds;
        has_sample_ = true;
        return;
    }

    rate_exceeded_ = false;
    if (config_.conditioning == Conditioning::RangeRate && last_accepted_at_ >= 0 &&
        config_.maximum_rate_per_second > 0.0) {
        const double elapsed_seconds =
            static_cast<double>(sampled_at_milliseconds - last_accepted_at_) / 1000.0;
        if (elapsed_seconds > 0.0) {
            const double rate = std::abs(raw_value - last_accepted_) / elapsed_seconds;
            // Reported Uncertain rather than dropped. A genuine fast transient is data; a
            // sensor that has started lying is not, and the receiver is told which it might
            // be rather than being shown only one of the two.
            rate_exceeded_ = rate > config_.maximum_rate_per_second;
        }
    }

    history_[next_] = raw_value;
    next_ = (next_ + 1) % window();
    filled_ = std::min(filled_ + 1, window());
    last_accepted_ = raw_value;
    last_accepted_at_ = sampled_at_milliseconds;
    last_sample_monotonic_ = monotonic_now_milliseconds;
    has_sample_ = true;
}

double AnalogueChannel::median() const noexcept {
    std::array<double, maximum_window> sorted{};
    for (std::size_t index = 0; index < filled_; ++index) {
        sorted[index] = history_[index];
    }
    std::sort(sorted.begin(), sorted.begin() + static_cast<std::ptrdiff_t>(filled_));
    // An even window has no single middle sample. The lower of the two is taken rather than
    // their mean, because the mean of two samples is a value the sensor never reported and
    // a median filter exists precisely to publish only values it did.
    return sorted[(filled_ - 1) / 2];
}

double AnalogueChannel::root_mean_square() const noexcept {
    double sum = 0.0;
    for (std::size_t index = 0; index < filled_; ++index) {
        sum += history_[index] * history_[index];
    }
    return std::sqrt(sum / static_cast<double>(filled_));
}

ConditionedReading AnalogueChannel::read(const std::uint64_t monotonic_now_milliseconds) const noexcept {
    ConditionedReading reading{};
    reading.channel_id = config_.channel_id;
    reading.unit = config_.unit;
    reading.quality = Quality::Bad;
    reading.sampled_at_milliseconds = last_accepted_at_;

    if (!has_sample_) {
        // Nothing has ever been offered. The controlled table's normal state for every
        // analogue channel is "Invalid", and this is it: no value, nothing publishable.
        reading.substituted = true;
        return reading;
    }

    const bool stale = monotonic_now_milliseconds - last_sample_monotonic_ >= config_.stale_after_milliseconds;
    if (stale || out_of_range_ || filled_ == 0) {
        // Substituted, and Bad. Never Good with a plausible number in it: a held-over value
        // presented as current is the failure CH1-EMB-FDS-0001 asks freshness to expose.
        reading.value = 0.0;
        reading.substituted = true;
        return reading;
    }

    switch (config_.conditioning) {
        case Conditioning::Median:
            reading.value = median();
            break;
        case Conditioning::WindowedRms:
            reading.value = root_mean_square();
            break;
        case Conditioning::RangeRate:
            reading.value = last_accepted_;
            break;
    }

    const bool window_full = filled_ >= window();
    if (!window_full) {
        // A window that has not filled publishes nothing rather than a partial average that
        // would read as a measurement.
        reading.quality = Quality::Uncertain;
        reading.publishable = false;
        return reading;
    }

    reading.quality = rate_exceeded_ ? Quality::Uncertain : Quality::Good;
    reading.publishable = true;
    return reading;
}

// ---------------------------------------------------------------------------------------
// Watchdog
// ---------------------------------------------------------------------------------------

std::size_t OutputWatchdog::supervise(
    const std::string_view name,
    const std::uint32_t deadline_milliseconds,
    const std::uint64_t monotonic_now_milliseconds) noexcept {
    if (count_ >= maximum_supervised_tasks) {
        // Refused, and remembered. Supervising one task fewer than the controller believes
        // is supervised is worse than refusing to start: the enable would then depend on a
        // check nobody was running.
        overflowed_ = true;
        return maximum_supervised_tasks;
    }
    tasks_[count_] = Task{name, deadline_milliseconds, monotonic_now_milliseconds};
    return count_++;
}

void OutputWatchdog::check_in(const std::size_t handle, const std::uint64_t monotonic_now_milliseconds) noexcept {
    if (handle >= count_) {
        return;
    }
    tasks_[handle].last_check_in = monotonic_now_milliseconds;
}

bool OutputWatchdog::healthy(const std::uint64_t monotonic_now_milliseconds) const noexcept {
    return !overflowed_ && first_overdue(monotonic_now_milliseconds).empty();
}

std::string_view OutputWatchdog::first_overdue(const std::uint64_t monotonic_now_milliseconds) const noexcept {
    for (std::size_t index = 0; index < count_; ++index) {
        const Task& task = tasks_[index];
        if (monotonic_now_milliseconds - task.last_check_in > task.deadline) {
            return task.name;
        }
    }
    return {};
}

// ---------------------------------------------------------------------------------------
// Time quality
// ---------------------------------------------------------------------------------------

std::string_view time_quality_name(const TimeQuality quality) noexcept {
    switch (quality) {
        case TimeQuality::Synchronised:
            return "Synchronised";
        case TimeQuality::Holdover:
            return "Holdover";
        case TimeQuality::Stale:
            return "Stale";
        case TimeQuality::Unsynchronised:
            break;
    }
    return "Unsynchronised";
}

void TimeSource::disciplined(
    const std::int64_t wall_clock_milliseconds,
    const std::uint64_t monotonic_now_milliseconds) noexcept {
    if (wall_clock_milliseconds < 0) {
        return;
    }
    wall_at_discipline_ = wall_clock_milliseconds;
    monotonic_at_discipline_ = monotonic_now_milliseconds;
    disciplined_ = true;
}

TimeQuality TimeSource::quality(const std::uint64_t monotonic_now_milliseconds) const noexcept {
    if (!disciplined_) {
        return TimeQuality::Unsynchronised;
    }
    const std::uint64_t since = monotonic_now_milliseconds - monotonic_at_discipline_;
    if (since < config_.synchronised_for_milliseconds) {
        return TimeQuality::Synchronised;
    }
    if (since < config_.holdover_for_milliseconds) {
        return TimeQuality::Holdover;
    }
    return TimeQuality::Stale;
}

std::int64_t TimeSource::report_clock(const std::uint64_t monotonic_now_milliseconds) const noexcept {
    const TimeQuality current = quality(monotonic_now_milliseconds);
    if (current != TimeQuality::Synchronised && current != TimeQuality::Holdover) {
        return -1;
    }
    return wall_at_discipline_ +
           static_cast<std::int64_t>(monotonic_now_milliseconds - monotonic_at_discipline_);
}

std::int64_t TimeSource::command_clock(const std::uint64_t monotonic_now_milliseconds) const noexcept {
    // Stricter than `report_clock`, and deliberately so. A prepared command carries an
    // expiry measured in seconds; a clock in holdover has drifted by an unknown amount that
    // is only bounded by policy. Accepting one would be accepting an intent with no bound on
    // how long it had been in flight, which is what CH1-COM-FR-0008's expiry exists to stop.
    if (quality(monotonic_now_milliseconds) != TimeQuality::Synchronised) {
        return -1;
    }
    return report_clock(monotonic_now_milliseconds);
}

// ---------------------------------------------------------------------------------------
// Output plan
// ---------------------------------------------------------------------------------------

std::string_view buzzer_pattern_name(const BuzzerPattern pattern) noexcept {
    switch (pattern) {
        case BuzzerPattern::SingleBeep:
            return "SingleBeep";
        case BuzzerPattern::SlowPulse:
            return "SlowPulse";
        case BuzzerPattern::FastPulse:
            return "FastPulse";
        case BuzzerPattern::Silent:
            break;
    }
    return "Silent";
}

namespace {

/// A square wave from the monotonic clock alone, so the pattern is a pure function of time
/// and a host test can assert both halves of it by advancing a clock that never runs.
[[nodiscard]] bool pulse(const std::uint64_t now, const std::uint64_t period) noexcept {
    return (now % period) < (period / 2);
}

}  // namespace

OutputPlan OutputPlanner::plan(
    const CellCondition condition,
    const Diagnostics& diagnostics,
    const std::uint64_t monotonic_now_milliseconds) noexcept {
    if (condition != previous_) {
        if (condition == CellCondition::Complete) {
            beeping_ = true;
            beep_started_ = monotonic_now_milliseconds;
        }
        previous_ = condition;
    }

    OutputPlan plan{};

    // The indicator conditions are the controlled table's own, one for one.
    // CH1-IO-DO-0001: "Only AwaitButton state".
    plan.confirmation_lamp = condition == CellCondition::AwaitButton;
    // CH1-IO-DO-0002: "Ready/complete indication".
    plan.green_indicator = condition == CellCondition::Idle || condition == CellCondition::Complete;
    // CH1-IO-DO-0003: "Prepared/warning indication".
    plan.amber_indicator = condition == CellCondition::AwaitCredential ||
                           condition == CellCondition::AwaitButton ||
                           condition == CellCondition::Committed ||
                           condition == CellCondition::Recovery;
    // CH1-IO-DO-0004: "Fault-latched indication".
    plan.red_indicator = condition == CellCondition::FaultLatched;

    const bool degraded =
        !diagnostics.watchdog_healthy || diagnostics.discrete_input_stuck || diagnostics.permissive_circuit_open;

    if (degraded) {
        // A condition the operator must see, shown on the indicator the controlled table
        // gives to warnings rather than by inventing a new one. Green is withdrawn: a cell
        // with a stuck confirmation contact is not ready, whatever the command state says.
        plan.amber_indicator = true;
        plan.green_indicator = false;
    }

    // CH1-IO-DO-0006: "Drops on watchdog/fault". Executing is the only state that grants the
    // enable, and the watchdog can take it away from every state.
    plan.actuator_enable = condition == CellCondition::Executing;
    if (plan.actuator_enable && !diagnostics.watchdog_healthy) {
        plan.actuator_enable = false;
        plan.inhibit_reason = "WATCHDOG_UNHEALTHY";
    } else if (plan.actuator_enable && diagnostics.permissive_circuit_open) {
        plan.actuator_enable = false;
        plan.inhibit_reason = "PERMISSIVE_CIRCUIT_OPEN";
    } else if (plan.actuator_enable && diagnostics.discrete_input_stuck) {
        plan.actuator_enable = false;
        plan.inhibit_reason = "DISCRETE_INPUT_STUCK";
    }

    // CH1-IO-PWM-0001 is gated behind the enable in software as well as in the wiring, and
    // rate limited. A stepper that could be commanded without the enable would be a second
    // way to move the machine.
    plan.step_enable = plan.actuator_enable;
    plan.step_rate_per_second = plan.step_enable ? config_.maximum_steps_per_second : 0;

    if (!diagnostics.watchdog_healthy || condition == CellCondition::FaultLatched) {
        plan.buzzer_pattern = BuzzerPattern::FastPulse;
    } else if (condition == CellCondition::AwaitButton) {
        plan.buzzer_pattern = BuzzerPattern::SlowPulse;
    } else if (beeping_) {
        plan.buzzer_pattern = BuzzerPattern::SingleBeep;
    }

    switch (plan.buzzer_pattern) {
        case BuzzerPattern::FastPulse:
            plan.buzzer = pulse(monotonic_now_milliseconds, 250);
            break;
        case BuzzerPattern::SlowPulse:
            plan.buzzer = pulse(monotonic_now_milliseconds, 1000);
            break;
        case BuzzerPattern::SingleBeep:
            plan.buzzer = monotonic_now_milliseconds - beep_started_ < config_.single_beep_milliseconds;
            if (!plan.buzzer) {
                beeping_ = false;
                plan.buzzer_pattern = BuzzerPattern::Silent;
            }
            break;
        case BuzzerPattern::Silent:
            plan.buzzer = false;
            break;
    }

    return plan;
}

}  // namespace cinerion::io
