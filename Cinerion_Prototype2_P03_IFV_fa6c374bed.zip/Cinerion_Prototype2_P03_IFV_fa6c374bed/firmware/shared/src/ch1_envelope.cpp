// Builds and parses CH1 envelopes on the controller side.

#include "cinerion/ch1_envelope.hpp"

#include "cinerion/cbor.hpp"

#include <algorithm>

namespace cinerion::ch1 {
namespace {

using cbor::ItemKind;
using cbor::Reader;
using cbor::Writer;

constexpr std::string_view type_command = "command";
constexpr std::string_view type_telemetry = "telemetry";
constexpr std::string_view type_acknowledgement = "acknowledgement";
constexpr std::string_view type_heartbeat = "heartbeat";

/// The twelve header pairs plus the payload key, in CANONICAL order.
///
/// Canonical CBOR (RFC 8949 §4.2.1) orders map keys by encoded length first and only then
/// bytewise, which is not alphabetical: "type" precedes "cellId" because it is shorter.
/// The gateway decodes in Canonical mode and refuses any other ordering, so this is a
/// requirement rather than a tidiness. Alphabetical order was written here first and the
/// cross-check against the reference bytes is what caught it.
///
/// The payload key is emitted by the caller immediately after this, because "payload" is
/// seven characters and sorts between "assetId" and "sequence".
void write_header_through_payload_key(
    Writer& writer,
    std::string_view type,
    const Origin& origin,
    std::int64_t sent_at_milliseconds) noexcept {
    writer.text("type");           // 4
    writer.text(type);
    writer.text("cellId");         // 6
    writer.bytes(origin.cell);
    writer.text("schema");
    writer.text(schema_version);
    writer.text("sentAt");
    writer.signed_value(sent_at_milliseconds);
    writer.text("source");
    writer.text(origin.source);
    writer.text("assetId");        // 7
    writer.bytes(origin.asset);
    writer.text("payload");        // 7 — the caller writes the value next
}

/// The header pairs that sort after "payload".
void write_header_after_payload(
    Writer& writer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sequence,
    std::string_view time_quality) noexcept {
    writer.text("sequence");       // 8
    writer.signed_value(sequence);
    writer.text("messageId");      // 9
    writer.bytes(message_id);
    writer.text("projectId");
    writer.bytes(origin.project);
    writer.text("destination");    // 11
    writer.text(origin.destination);
    // Observable rather than assumed: CH1-COM-ICD-0001 requires time quality to be
    // visible so audit decisions are not silently made on invalid time. A controller
    // whose clock has not been disciplined must say so here rather than claim otherwise.
    //
    // It did claim otherwise. This wrote the literal "Synchronised" on every message while
    // wall_clock_milliseconds() returned -1, so the same firmware refused every prepared
    // command as CONTROLLER_TIME_NOT_TRUSTED and simultaneously told the gateway its clock
    // was disciplined. The caller now supplies what the clock actually reports.
    writer.text("timeQuality");    // 11
    writer.text(time_quality);
    writer.text("correlationId");  // 13
    writer.bytes(correlation_id);
}

[[nodiscard]] std::size_t finish(Writer& writer) noexcept {
    return writer.overflowed() ? 0 : writer.size();
}

[[nodiscard]] bool same(std::span<const std::uint8_t> left, std::span<const std::uint8_t> right) noexcept {
    return left.size() == right.size() && std::equal(left.begin(), left.end(), right.begin());
}

}  // namespace

std::size_t encode_telemetry(
    std::span<std::uint8_t> buffer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sent_at_milliseconds,
    std::int64_t sequence,
    std::string_view time_quality,
    const Reading& reading) noexcept {
    Writer writer(buffer);
    writer.map_header(13);
    write_header_through_payload_key(writer, type_telemetry, origin, sent_at_milliseconds);
    // Payload keys are canonical too: unit(4), value(5), quality(7), then channelId and
    // sampledAt, both 9 and ordered bytewise.
    writer.map_header(5);
    writer.text("unit");
    writer.text(reading.unit);
    writer.text("value");
    writer.double_value(reading.value);
    writer.text("quality");
    writer.text(reading.quality);
    writer.text("channelId");
    writer.text(reading.channel);
    writer.text("sampledAt");
    writer.signed_value(reading.sampled_at_milliseconds);
    write_header_after_payload(writer, origin, message_id, correlation_id, sequence, time_quality);
    return finish(writer);
}

std::size_t encode_acknowledgement(
    std::span<std::uint8_t> buffer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sent_at_milliseconds,
    std::int64_t sequence,
    std::string_view time_quality,
    const Acknowledgement& acknowledgement) noexcept {
    Writer writer(buffer);
    writer.map_header(13);
    write_header_through_payload_key(writer, type_acknowledgement, origin, sent_at_milliseconds);
    // accepted(8), adapterId(9), commandId(9), reasonCode(10), controllerState(15).
    writer.map_header(5);
    writer.text("accepted");
    writer.boolean(acknowledgement.accepted);
    writer.text("adapterId");
    writer.text(origin.source);
    writer.text("commandId");
    writer.bytes(acknowledgement.command_id);
    writer.text("reasonCode");
    writer.text(acknowledgement.reason_code);
    writer.text("controllerState");
    writer.text(acknowledgement.controller_state);
    write_header_after_payload(writer, origin, message_id, correlation_id, sequence, time_quality);
    return finish(writer);
}

std::size_t encode_heartbeat(
    std::span<std::uint8_t> buffer,
    const Origin& origin,
    Uuid message_id,
    Uuid correlation_id,
    std::int64_t sent_at_milliseconds,
    std::int64_t sequence,
    std::string_view time_quality,
    const Heartbeat& heartbeat) noexcept {
    Writer writer(buffer);
    writer.map_header(13);
    write_header_through_payload_key(writer, type_heartbeat, origin, sent_at_milliseconds);
    // CH1-COM-ICD-0001: heartbeats include firmware and configuration revision, so a
    // controller running something other than the released baseline is visible without
    // anybody having to ask it. uptimeSeconds(13), firmwareVersion(15),
    // configurationRevision(21).
    writer.map_header(3);
    writer.text("uptimeSeconds");
    writer.signed_value(heartbeat.uptime_seconds);
    writer.text("firmwareVersion");
    writer.text(heartbeat.firmware_version);
    writer.text("configurationRevision");
    writer.text(heartbeat.configuration_revision);
    write_header_after_payload(writer, origin, message_id, correlation_id, sequence, time_quality);
    return finish(writer);
}

Command decode_command(
    std::span<const std::uint8_t> envelope,
    const Origin& expected,
    std::int64_t now_milliseconds) noexcept {
    Command command{};
    Reader reader(envelope);

    const std::size_t pairs = reader.map_header();
    if (reader.failed()) {
        command.refusal_code = "ENVELOPE_NOT_CBOR";
        return command;
    }

    std::string_view schema{};
    std::string_view type{};
    std::span<const std::uint8_t> project{};
    std::span<const std::uint8_t> cell{};
    bool have_expiry = false;
    bool have_payload = false;

    for (std::size_t index = 0; index < pairs && !reader.failed(); ++index) {
        if (reader.peek() != ItemKind::text_string) {
            command.refusal_code = "ENVELOPE_MALFORMED";
            return command;
        }

        const std::string_view key = reader.text();
        if (key == "schema") {
            schema = reader.text();
        } else if (key == "type") {
            type = reader.text();
        } else if (key == "projectId") {
            project = reader.bytes();
        } else if (key == "cellId") {
            cell = reader.bytes();
        } else if (key == "correlationId") {
            command.correlation_id = reader.bytes();
        } else if (key == "sequence") {
            command.sequence = reader.signed_value();
        } else if (key == "expiresAt") {
            command.expires_at_milliseconds = reader.signed_value();
            have_expiry = true;
        } else if (key == "payload") {
            const std::size_t fields = reader.map_header();
            for (std::size_t field = 0; field < fields && !reader.failed(); ++field) {
                const std::string_view name = reader.text();
                if (name == "commandType") {
                    command.command_type = reader.text();
                } else if (name == "configurationRevision") {
                    command.configuration_revision = reader.text();
                } else if (name == "expectedStateHash") {
                    command.expected_state_hash = reader.text();
                } else if (name == "idempotencyKey") {
                    command.idempotency_key = reader.bytes();
                } else {
                    // An unknown optional field is ignored safely, which is the
                    // compatibility rule CH1-COM-ICD-0001 states. Unknown *mandatory*
                    // semantics are what fail closed, and every mandatory one is checked
                    // by name below.
                    reader.skip();
                }
            }
            have_payload = true;
        } else {
            reader.skip();
        }
    }

    if (reader.failed()) {
        command.refusal_code = "ENVELOPE_MALFORMED";
        return command;
    }

    if (schema != schema_version) {
        command.refusal_code = "ENVELOPE_SCHEMA_UNSUPPORTED";
        return command;
    }

    if (type != type_command) {
        command.refusal_code = "ENVELOPE_TYPE_UNKNOWN";
        return command;
    }

    // Scope before payload. A command naming another project or cell is not a command
    // this controller serves, whatever the broker let through — the topic ACL and this
    // check are two independent boundaries, and neither is allowed to assume the other.
    if (!same(project, expected.project) || !same(cell, expected.cell)) {
        command.refusal_code = "COMMAND_OUT_OF_SCOPE";
        return command;
    }

    if (!have_payload || command.command_type.empty() || command.idempotency_key.size() != 16 ||
        command.configuration_revision.empty() || command.expected_state_hash.empty()) {
        command.refusal_code = "COMMAND_INCOMPLETE";
        return command;
    }

    // A command type is a semantic name, never a register address. A controller that
    // forwarded "write:40001" to something downstream would be the register-poking path
    // CH1-CMD-FR-0001 exists to forbid.
    for (const char character : command.command_type) {
        const bool permitted = (character >= 'A' && character <= 'Z') ||
                               (character >= '0' && character <= '9') || character == '_';
        if (!permitted) {
            command.refusal_code = "SEMANTIC_COMMAND_INVALID";
            return command;
        }
    }

    if (!have_expiry) {
        command.refusal_code = "COMMAND_HAS_NO_EXPIRY";
        return command;
    }

    // A controller that cannot judge the time refuses rather than guesses. Commands
    // expire and are never replayed after reconnect, so accepting one whose expiry
    // cannot be evaluated would defeat the only bound on how long an intent lives.
    if (now_milliseconds < 0) {
        command.refusal_code = "CONTROLLER_TIME_NOT_TRUSTED";
        return command;
    }

    if (command.expires_at_milliseconds <= now_milliseconds) {
        command.refusal_code = "COMMAND_EXPIRED";
        return command;
    }

    command.valid = true;
    return command;
}

}  // namespace cinerion::ch1
