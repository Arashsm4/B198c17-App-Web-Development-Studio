// SNTP clock discipline for the CH1 cell controller.
//
// *** UNVERIFIED ON THIS WORKSTATION. *** ESP-IDF is not installed here, so this
// translation unit has never been compiled and never been run. It is deliberately NOT in
// the host build: `esp_netif_sntp.h` is a macro-heavy header, and a hand-written stub of it
// would let this file compile against something the real header does not agree with —
// coverage that looks like coverage and is not. It is in the ESP-IDF component
// (firmware/esp32/main/CMakeLists.txt) and nowhere else, and the one function it exports is
// the only thing app_main.cpp knows about it.
//
// Everything this feeds is tested. `cinerion::io::TimeSource` holds the whole decision —
// Unsynchronised, Synchronised, holdover, stale, and the two clocks of different strictness
// — and firmware/tests/conditioned_io_test.cpp exercises all of it by advancing a clock that
// never runs. What is unverified here is the four ESP-IDF calls that fetch a number.
//
// CH1-COM-FR-0009 requires each device to report time-quality status, and CH1-COM-ICD-0001
// requires time quality to be visible so audit decisions are not silently made on invalid
// time. Since defect 58 the envelope reports what the clock actually says; this is what
// gives it something better than Unsynchronised to say.
//
// THE SERVER IS NOT A DEFAULT AND THERE IS NO PUBLIC ONE.
//
// CH1-VVT-TC-0080 requires the core demonstration to complete with no public internet, and
// `npm run offline:verify` refuses any controlled runtime setting naming a public host. A
// controller reaching for a public time source would be the single setting that broke the
// isolation everything else preserves — and worse, a cell whose clock depends on the public
// internet is a cell whose command path closes when the site's uplink does. The server is
// provisioned with the device identity, from inside the control zone. With none provisioned
// the controller stays Unsynchronised, refuses every prepared command as
// CONTROLLER_TIME_NOT_TRUSTED, and says so on every message. That is the correct behaviour,
// not a degraded one.

#include "cinerion/conditioned_io.hpp"

#include "esp_err.h"
#include "esp_log.h"
#include "esp_netif_sntp.h"
#include "freertos/FreeRTOS.h"
#include "nvs.h"
#include "nvs_flash.h"

#include <cstring>
#include <ctime>

namespace {

constexpr char tag[] = "CH1_TIME";

/// Where the provisioned time server lives. Written with the device identity, alongside the
/// certificate, and never compiled in.
constexpr char namespace_name[] = "ch1_cfg";
constexpr char server_key[] = "sntp_server";

/// How long to wait for a first answer. A cell controller does not block its safety loop on
/// a network service, so this is short and failure is ordinary: the clock stays
/// Unsynchronised and the next attempt happens on the next interval.
constexpr int sync_timeout_milliseconds = 10000;

/// Reads the provisioned server. Returns false when none is provisioned, which is the
/// state a controller ships in.
bool provisioned_server(char* into, std::size_t capacity) {
    nvs_handle_t handle{};
    if (nvs_open(namespace_name, NVS_READONLY, &handle) != ESP_OK) {
        return false;
    }

    std::size_t length = capacity;
    const esp_err_t result = nvs_get_str(handle, server_key, into, &length);
    nvs_close(handle);
    return result == ESP_OK && length > 1;
}

}  // namespace

/// Attempts one clock discipline, and reports whether it succeeded.
///
/// On success `wall_clock_milliseconds` carries the disciplined time and the caller hands it
/// to `TimeSource::disciplined`, which is what moves the controller from Unsynchronised to
/// Synchronised and opens the command path. On failure nothing is written and the caller's
/// clock is unchanged — never guessed at, never approximated from uptime.
extern "C" bool ch1_discipline_clock(std::int64_t* wall_clock_milliseconds) {
    if (wall_clock_milliseconds == nullptr) {
        return false;
    }

    char server[128]{};
    if (!provisioned_server(server, sizeof(server))) {
        // Said once per attempt rather than silently. A controller with no provisioned time
        // source is a controller whose command path is closed, and an operator should be
        // able to see why from the log rather than from the refusals.
        ESP_LOGW(tag, "no provisioned control-zone time server; the clock stays Unsynchronised");
        return false;
    }

    esp_sntp_config_t config = ESP_NETIF_SNTP_DEFAULT_CONFIG(server);
    // The controller asks, once, when this function runs. It does not install a background
    // poller: a clock that is stepped underneath a running command path would move an
    // expiry the guard has already judged.
    config.start = true;
    config.server_from_dhcp = false;
    config.renew_servers_after_new_IP = false;

    if (esp_netif_sntp_init(&config) != ESP_OK) {
        ESP_LOGE(tag, "the SNTP client could not be started against the provisioned server");
        return false;
    }

    const esp_err_t waited = esp_netif_sntp_sync_wait(pdMS_TO_TICKS(sync_timeout_milliseconds));
    esp_netif_sntp_deinit();

    if (waited != ESP_OK) {
        ESP_LOGW(tag, "the provisioned time server did not answer within %d ms", sync_timeout_milliseconds);
        return false;
    }

    timespec now{};
    if (clock_gettime(CLOCK_REALTIME, &now) != 0) {
        return false;
    }

    // A server that answered with an implausible epoch is refused rather than believed. A
    // controller that accepted 1970 would then judge every command's expiry against it and
    // accept intents that had been in flight for decades.
    constexpr std::int64_t plausible_floor_milliseconds = 1'767'225'600'000;  // 2026-01-01
    const std::int64_t answered =
        static_cast<std::int64_t>(now.tv_sec) * 1000 + now.tv_nsec / 1'000'000;
    if (answered < plausible_floor_milliseconds) {
        ESP_LOGE(tag, "the time server answered with an implausible epoch; the clock stays Unsynchronised");
        return false;
    }

    *wall_clock_milliseconds = answered;
    ESP_LOGI(tag, "clock disciplined from the provisioned control-zone time server");
    return true;
}
