// CH1 cell controller, ESP32-S3.
//
// Two controlled edges meet here. CH1-COM-IF-0005 carries the CH1 CBOR envelope over
// MQTT 5/TLS with this device's own certificate; CH1-COM-IF-0006 carries framed binary
// with a CRC over RS-485 to the Arduino I/O node. The state machine between them is
// CH1-AUT-FDS-0001's, and the safety position is CH1-SAF-FR-0001's: this checkpoint
// configures no GPIO as an actuator output, and nothing below can energise anything.
//
// What is deliberate and load-bearing:
//
//   * the controller ACKNOWLEDGES a prepared command and stops there. The credential
//     proof and the physical button edge are observed locally, and no code path here
//     reports an execution;
//   * a command is refused unless it is in scope, complete, semantically named and
//     unexpired, and refused outright if this controller cannot judge the time;
//   * telemetry carries the SOURCE sample time, never the send time;
//   * the heartbeat carries firmware and configuration revision, so a controller running
//     something other than the released baseline is visible without being asked;
//   * every message carries the controller's OWN judgement of its clock, which is not a
//     constant.
//
// Outputs are PLANNED and not driven. `cinerion::io::OutputPlanner` computes what the six
// controlled outputs should be from the cell condition and the diagnostics, and this file
// hands that plan to nothing: `firmware/pinmap/esp32s3-r01.json` records that no actuator
// output is energisable at hardware revision R01, and scripts/check-io-map.mjs refuses a
// map that says otherwise while the wiring is unfrozen. The board driver that applies a
// plan is HIL work and follows independent review, per CH1-EMB-FDS-0001's P03 verification
// boundary.
//
// The decisions are all host-tested elsewhere — firmware/tests/ch1_envelope_test.cpp
// cross-checks the wire format against the gateway byte for byte,
// firmware/tests/cell_state_machine_test.cpp holds the permissive logic, and
// firmware/tests/conditioned_io_test.cpp holds the conditioning, the indicator patterns
// and the watchdog. THIS FILE is now compiled by verify.sh too, against the stubs in
// firmware/tests/host-stubs: until that existed nothing in the pipeline built it at all,
// and it did not in fact build. See `publish` below.

#include "cinerion/cell_state_machine.hpp"
#include "cinerion/ch1_envelope.hpp"
#include "cinerion/conditioned_io.hpp"
#include "cinerion/frame_codec.hpp"

#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <array>
#include <cstdint>
#include <cstring>

namespace {

constexpr char tag[] = "CH1_CELL";

// Reported in every heartbeat and capability announcement. The MQTT device simulator in
// services/edge-link reports the same pair, so a reader cannot tell from the wire which
// of the two answered — which is the point of both speaking one controlled format.
constexpr std::string_view firmware_version = "0.1.0-prototype.2";
constexpr std::string_view configuration_revision = "CFG-REFAB-P01-R01";
constexpr std::string_view device_id = "CH1-DEV-CELL-0001";
constexpr std::string_view gateway_id = "ch1-edgelink";

cinerion::cell::StateMachine machine{{1, 2, 3, 4, 1}, 1};

/// The controller's clock and its opinion of itself.
///
/// There is deliberately no default time server: CH1-VVT-TC-0080 requires the core
/// demonstration to complete with no public internet, so a controller that reached for a
/// public time host would be the one setting that breaks the isolation everything else
/// preserves — and a cell whose clock depends on the public internet is a cell whose command
/// path closes when the site's uplink does. The server is provisioned with the device
/// identity, from inside the control zone. With none provisioned, `quality()` is
/// Unsynchronised, every prepared command is refused as CONTROLLER_TIME_NOT_TRUSTED, and
/// every message says so.
cinerion::io::TimeSource clock_source{};

/// One SNTP discipline attempt against the provisioned control-zone server.
///
/// Defined in time_sync.cpp, which is in the ESP-IDF component and NOT in the host build:
/// `esp_netif_sntp.h` is macro-heavy and a hand-written stub of it would let that file
/// compile against something the real header does not agree with, which is coverage that
/// looks like coverage. Everything it feeds — the whole Unsynchronised/Synchronised/
/// holdover/stale decision and the two clocks of different strictness — is in
/// cinerion::io::TimeSource and is host-tested.
extern "C" bool ch1_discipline_clock(std::int64_t* wall_clock_milliseconds);

/// Supervises the tasks the actuator enable depends on. CH1-VVT-TC-0073.
cinerion::io::OutputWatchdog watchdog{};
std::size_t control_task{};

cinerion::io::OutputPlanner planner{};

// The six conditioned discrete inputs, configured exactly as firmware/pinmap/esp32s3-r01.json
// declares them. Two copies of one contract, reconciled by scripts/check-io-map.mjs.
namespace signals = cinerion::io::signals;
using cinerion::io::Circuit;

cinerion::io::DiscreteInput start_enable{{signals::start_enable, Circuit::NormallyOpen, 20, 0}};
cinerion::io::DiscreteInput stop_request{{signals::stop_request, Circuit::NormallyClosed, 20, 0}};
cinerion::io::DiscreteInput local_reset{{signals::local_reset, Circuit::NormallyOpen, 30, 10'000}};
cinerion::io::DiscreteInput confirmation{{signals::confirmation_button, Circuit::NormallyOpen, 30, 5'000}};
cinerion::io::DiscreteInput guard{{signals::guard_interlock, Circuit::NormallyClosed, 10, 0}};
cinerion::io::DiscreteInput actuator_home{{signals::actuator_home, Circuit::NormallyOpen, 20, 0}};

// The four conditioned analogue channels, with the conditioning each one's controlled
// diagnostic action calls for.
using cinerion::io::Conditioning;

std::array<cinerion::io::AnalogueChannel, 4> analogue_channels{
    cinerion::io::AnalogueChannel{{signals::temperature, "temperature", "degC",
                                   Conditioning::RangeRate, -40.0, 125.0, 5.0, 1, 5'000}},
    cinerion::io::AnalogueChannel{{signals::relative_humidity, "relative-humidity", "%RH",
                                   Conditioning::RangeRate, 0.0, 100.0, 20.0, 1, 5'000}},
    cinerion::io::AnalogueChannel{{signals::position, "position", "mm",
                                   Conditioning::Median, 0.0, 4'000.0, 0.0, 5, 1'000}},
    cinerion::io::AnalogueChannel{{signals::vibration, "vibration", "m/s2",
                                   Conditioning::WindowedRms, -160.0, 160.0, 0.0, 16, 500}},
};

/// Scope this controller serves. Provisioned with the device identity, never taken from
/// a message: a controller that adopted the scope named in an incoming command would
/// accept every command ever addressed to anything.
constexpr std::array<std::uint8_t, 16> project_id{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01};
constexpr std::array<std::uint8_t, 16> cell_id{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x03};
constexpr std::array<std::uint8_t, 16> asset_id{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x04};

cinerion::ch1::Origin origin() {
    return {
        .source = device_id,
        .destination = gateway_id,
        .project = cinerion::ch1::Uuid(project_id),
        .cell = cinerion::ch1::Uuid(cell_id),
        .asset = cinerion::ch1::Uuid(asset_id),
    };
}

/// Monotonic milliseconds since boot. Always available, and never used to judge expiry.
std::uint64_t uptime_milliseconds() {
    return static_cast<std::uint64_t>(esp_timer_get_time() / 1000);
}

/// Wall-clock milliseconds for judging a command expiry, or negative when the clock cannot
/// carry one.
///
/// This is not a convenience. `decode_command` refuses every command when it is negative,
/// because a controller that cannot judge an expiry would otherwise accept an intent with
/// no bound on how long it had been in flight. It is deliberately the STRICTER of the two
/// clocks: a source in holdover may stamp an observation and may not judge a command.
std::int64_t wall_clock_milliseconds() {
    return clock_source.command_clock(uptime_milliseconds());
}

/// What this controller currently says about its own clock, for the envelope.
std::string_view time_quality() {
    return cinerion::io::time_quality_name(clock_source.quality(uptime_milliseconds()));
}

/// How many messages this controller could not put on the wire. Reported in the log rather
/// than discarded, because a controller that is publishing nothing and says nothing is
/// indistinguishable from one nobody is listening to.
std::uint32_t undelivered = 0;

/// Publishes one encoded message.
///
/// **This function had no definition at all.** It was declared in this anonymous namespace
/// and odr-used by the heartbeat and acknowledgement paths, which means `firmware/esp32`
/// could never have linked — and nothing noticed, because no gate built it. It is built now
/// (verify.sh step [9/14], against firmware/tests/host-stubs) and this is the definition.
///
/// The MQTT client is provisioned with this device's certificate, so the broker's topic ACL
/// is what decides where it may publish; nothing here chooses a topic it has not been
/// granted. That client does not exist at this checkpoint, so this counts the message as
/// undelivered and says so. It does not return success: a transport that reported delivery
/// it had not performed would be exactly the fake success AGENTS.md forbids.
void publish(const std::string_view topic, const std::span<const std::uint8_t> payload) {
    undelivered += 1;
    ESP_LOGW(tag,
             "no provisioned MQTT client: %u byte message for %.*s was NOT published (%u undelivered)",
             static_cast<unsigned>(payload.size()),
             static_cast<int>(topic.size()),
             topic.data(),
             static_cast<unsigned>(undelivered));
}

void report_telemetry(const std::int64_t sequence, const std::uint64_t now) {
    // A reading this controller has not actually taken is never invented. The conditioned
    // channels above hold the range, rate, filter and freshness rules each controlled
    // channel declares, and nothing samples the I2C bus yet — the sensor drivers are
    // board-specific and belong with the frozen pin map. So every channel answers Bad,
    // substituted and not publishable, and nothing goes on the wire.
    //
    // That is now a property the code states and a host test proves, rather than an empty
    // function: an unpublishable channel and a channel nobody wrote are the same thing to
    // this loop, which is what makes the sensor driver a drop-in rather than a rewrite.
    std::int64_t message_sequence = sequence;
    for (const auto& channel : analogue_channels) {
        const auto reading = channel.read(now);
        if (!reading.publishable) {
            continue;
        }

        std::array<std::uint8_t, cinerion::ch1::maximum_envelope_bytes> buffer{};
        std::array<std::uint8_t, 16> message_id{};
        std::array<std::uint8_t, 16> correlation_id{};
        const cinerion::ch1::Reading wire{
            .channel = reading.channel_id,
            .value = reading.value,
            .unit = reading.unit,
            .quality = cinerion::io::quality_name(reading.quality),
            .sampled_at_milliseconds = reading.sampled_at_milliseconds,
        };

        const std::size_t written = cinerion::ch1::encode_telemetry(
            buffer,
            origin(),
            cinerion::ch1::Uuid(message_id),
            cinerion::ch1::Uuid(correlation_id),
            clock_source.report_clock(now),
            ++message_sequence,
            time_quality(),
            wire);

        if (written == 0) {
            ESP_LOGE(tag, "telemetry did not fit its buffer; nothing published");
            continue;
        }

        publish("ch1/v1/devices/CH1-DEV-CELL-0001/telemetry",
                std::span<const std::uint8_t>(buffer.data(), written));
    }
}

void report_heartbeat(const std::int64_t sequence) {
    std::array<std::uint8_t, cinerion::ch1::maximum_envelope_bytes> buffer{};
    const cinerion::ch1::Heartbeat heartbeat{
        .firmware_version = firmware_version,
        .configuration_revision = configuration_revision,
        .uptime_seconds = static_cast<std::int64_t>(uptime_milliseconds() / 1000),
    };

    std::array<std::uint8_t, 16> message_id{};
    std::array<std::uint8_t, 16> correlation_id{};
    // Identifiers come from the hardware RNG on a real build; zeroed here so this file
    // contains no source of entropy it has not been given.
    const std::size_t written = cinerion::ch1::encode_heartbeat(
        buffer,
        origin(),
        cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation_id),
        static_cast<std::int64_t>(uptime_milliseconds()),
        sequence,
        // CH1-COM-FR-0009 requires the heartbeat to carry time-quality status. It carries
        // what the clock reports, which at this checkpoint is Unsynchronised.
        time_quality(),
        heartbeat);

    if (written == 0) {
        // Refused rather than truncated. A partial envelope that happened to parse would
        // be a different message.
        ESP_LOGE(tag, "heartbeat did not fit its buffer; nothing published");
        return;
    }

    publish("ch1/v1/devices/CH1-DEV-CELL-0001/heartbeat",
            std::span<const std::uint8_t>(buffer.data(), written));
}

/// Handles one command envelope from the gateway and answers it.
///
/// Every refusal is answered, never dropped. A command that vanished would leave the
/// gateway waiting for an acknowledgement that never came, and CH1-COM-IF-0004 makes that
/// a timeout the gateway must report as a refusal — correct, but far less useful than the
/// stable code this returns.
void on_command(std::span<const std::uint8_t> envelope) {
    const auto command =
        cinerion::ch1::decode_command(envelope, origin(), wall_clock_milliseconds());

    std::array<std::uint8_t, 16> command_id{};
    if (command.idempotency_key.size() == command_id.size()) {
        std::memcpy(command_id.data(), command.idempotency_key.data(), command_id.size());
    }

    // The controller acknowledges an intent and stops. AwaitingCredential is the honest
    // state: what follows is a cryptographic credential proof and a new physical button
    // edge, neither of which anything on this link can supply.
    const cinerion::ch1::Acknowledgement acknowledgement{
        .command_id = cinerion::ch1::Uuid(command_id),
        .accepted = command.valid,
        .controller_state = command.valid ? "AwaitingCredential" : "Idle",
        .reason_code = command.valid ? "PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION"
                                     : command.refusal_code,
    };

    std::array<std::uint8_t, cinerion::ch1::maximum_envelope_bytes> buffer{};
    std::array<std::uint8_t, 16> message_id{};
    std::array<std::uint8_t, 16> correlation{};
    if (command.correlation_id.size() == correlation.size()) {
        std::memcpy(correlation.data(), command.correlation_id.data(), correlation.size());
    }

    const std::size_t written = cinerion::ch1::encode_acknowledgement(
        buffer,
        origin(),
        cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation),
        static_cast<std::int64_t>(uptime_milliseconds()),
        command.sequence,
        time_quality(),
        acknowledgement);

    if (written == 0) {
        ESP_LOGE(tag, "acknowledgement did not fit its buffer; nothing published");
        return;
    }

    publish("ch1/v1/devices/CH1-DEV-CELL-0001/acks",
            std::span<const std::uint8_t>(buffer.data(), written));
}

void on_command(std::span<const std::uint8_t> envelope);

/// Reads one command envelope from the gateway, or nothing.
///
/// The MQTT client is not provisioned at this checkpoint, so this returns nothing and
/// `on_command` is reached with nothing. It exists for the same reason `read_node_bus`
/// does: `on_command` was defined and never called, so the entire command receive path was
/// unreachable — and the compiler said so the moment anything built this file.
std::size_t read_command_envelope(std::span<std::uint8_t> into) {
    (void)into;
    return 0;
}

void poll_command_topic() {
    std::array<std::uint8_t, 512> envelope{};
    const std::size_t read = read_command_envelope(envelope);
    if (read == 0) {
        return;
    }
    on_command(std::span<const std::uint8_t>(envelope.data(), read));
}

/// One RS-485 frame from the Arduino I/O node (CH1-COM-IF-0006).
///
/// The frame's own preamble, length, CRC and sequence are validated by the shared codec
/// before anything reads its payload, and a frame that fails is discarded rather than
/// repaired. Physical-zone trust does not grant command authority: a valid frame reports
/// local input state and can never be a command.
void on_serial_frame(std::span<const std::uint8_t> frame, std::uint32_t minimum_sequence) {
    if (!cinerion::io::validate_frame(frame, minimum_sequence)) {
        // Includes a frame whose TYPE the interface does not define. That check used not to
        // exist — validate_frame never read the type byte, so all 256 were accepted and the
        // claim below rested on nobody having defined a command yet.
        ESP_LOGW(tag, "discarded an invalid RS-485 frame");
        return;
    }

    // Physical-zone trust does not grant command authority. Every branch here consumes a
    // REPORT, and there is no branch that could start, arm, confirm or advance anything —
    // CH1-EMB-FDS-0001 gives the node no independent authority to start a procedure, and
    // the codec now refuses any type outside the three report kinds on both sides of the
    // wire, so a fourth branch could not be written without a reviewed interface change.
    switch (cinerion::io::frame_type(frame)) {
        case cinerion::io::FrameType::InputState:
            // Conditioned input decoding belongs with the approved Prototype 1 pin map,
            // which is not frozen. The node's inputs are conditioned by the same
            // cinerion::io::DiscreteInput types this controller uses for its own.
            break;
        case cinerion::io::FrameType::PartIdentity:
            // A UID identifies a part. CH1-HWE-HDS-0001 permits an RC522-class reader for
            // part identification only, and CH1-HWE-IOL-0001 keeps part identification and
            // human authentication on separate channels: this can never satisfy a
            // credential, and no code path here lets it.
            break;
        case cinerion::io::FrameType::NodeStatus:
            // Reported onward as diagnostics. A node that has stopped talking is a
            // communication fault, not a permissive.
            break;
    }
}

/// Reads one frame from the node bus, or nothing.
///
/// The UART is not provisioned at this checkpoint, so this returns no frame and
/// `on_serial_frame` is reached with nothing. It exists because `on_serial_frame` was
/// previously unreachable — defined, never called, and therefore never compiled into
/// anything that could run — and a receive path nothing calls is a receive path nobody
/// will notice has broken.
std::size_t read_node_bus(std::span<std::uint8_t> into) {
    (void)into;
    return 0;
}

void poll_node_bus(std::uint32_t& minimum_sequence) {
    std::array<std::uint8_t, cinerion::io::maximum_payload + 12> frame{};
    const std::size_t read = read_node_bus(frame);
    if (read == 0) {
        return;
    }
    on_serial_frame(std::span<const std::uint8_t>(frame.data(), read), minimum_sequence);
    minimum_sequence += 1;
}

/// Maps the command state machine's state onto the condition the output planner reasons
/// about. The two enumerations are deliberately separate — the I/O layer must not depend on
/// the command state machine — so the mapping is made once, here, where it can be read.
cinerion::io::CellCondition condition_of(const cinerion::cell::State state) {
    switch (state) {
        case cinerion::cell::State::Idle:
            return cinerion::io::CellCondition::Idle;
        case cinerion::cell::State::AwaitCredential:
            return cinerion::io::CellCondition::AwaitCredential;
        case cinerion::cell::State::AwaitButton:
            return cinerion::io::CellCondition::AwaitButton;
        case cinerion::cell::State::Committed:
            return cinerion::io::CellCondition::Committed;
        case cinerion::cell::State::Executing:
            return cinerion::io::CellCondition::Executing;
        case cinerion::cell::State::Complete:
            return cinerion::io::CellCondition::Complete;
        case cinerion::cell::State::FaultLatched:
            return cinerion::io::CellCondition::FaultLatched;
        case cinerion::cell::State::Recovery:
            return cinerion::io::CellCondition::Recovery;
        case cinerion::cell::State::Initialising:
            break;
    }
    return cinerion::io::CellCondition::Initialising;
}

/// Everything outside the command state machine that can withhold an output.
cinerion::io::Diagnostics diagnostics(const std::uint64_t now) {
    return cinerion::io::Diagnostics{
        .watchdog_healthy = watchdog.healthy(now),
        .discrete_input_stuck = confirmation.stuck() || local_reset.stuck(),
        // A normally closed permissive whose loop has opened. Distinguished from the
        // permissive simply being absent, because a cut conductor is a fault and an open
        // guard is an operator having opened the guard.
        .permissive_circuit_open = !stop_request.circuit_healthy() || !guard.circuit_healthy(),
        .detail = watchdog.first_overdue(now),
    };
}

/// The conditioned discrete inputs, in the form the command state machine takes them.
cinerion::cell::LocalInputs local_inputs() {
    return cinerion::cell::LocalInputs{
        .start_enable = start_enable.asserted(),
        // The NC circuit is healthy when it is intact; `asserted()` on it is the stop being
        // demanded, which is the same fact the other way up.
        .stop_circuit_healthy = !stop_request.asserted(),
        .guard_healthy = !guard.asserted(),
        .actuator_home = actuator_home.asserted(),
        // A stuck contact asserts nothing, so a welded confirmation button cannot commit.
        .confirmation_button = confirmation.asserted(),
        .reset_button = local_reset.asserted(),
        .fault_cause_active = confirmation.stuck() || local_reset.stuck(),
    };
}

/// Offers each conditioned input its raw electrical level.
///
/// The board driver that reads the pins does not exist at this hardware revision, so every
/// input is offered its de-energised level: a normally open contact open, a normally closed
/// loop intact. Nothing is invented and nothing is energised. This is the one function a
/// board bring-up replaces, and the conditioning above it does not change when it does.
void sample_discrete_inputs(const std::uint64_t now) {
    start_enable.sample(false, now);
    stop_request.sample(true, now);
    local_reset.sample(false, now);
    confirmation.sample(false, now);
    guard.sample(true, now);
    actuator_home.sample(false, now);
}

}  // namespace

extern "C" void app_main() {
    // Prototype integration intentionally starts with all external permissives false.
    // Board-specific conditioned I/O drivers must replace this fixture and pass HIL tests
    // before any output pin is configured as an actuator.
    const std::uint64_t booted_at = uptime_milliseconds();
    sample_discrete_inputs(booted_at);
    // Attempted here so the boot log states the position, and attempted again on every
    // pass of the loop below until it succeeds — see the note there.
    const auto result = machine.initialise(local_inputs());
    ESP_LOGW(
        tag,
        "Cinerion P03/IFV booted in non-energising state; initialisation result=%u; actuator=%u",
        static_cast<unsigned>(result),
        static_cast<unsigned>(machine.outputs().actuator_enable));

    // The control task is supervised from the first tick, so a loop that never runs is
    // indistinguishable from one that stopped — which is the point.
    control_task = watchdog.supervise("control", 500, booted_at);

    // The command path is closed until the clock is disciplined, and says so once at boot
    // rather than refusing silently every time the gateway tries.
    if (wall_clock_milliseconds() < 0) {
        ESP_LOGW(tag,
                 "no disciplined clock: every prepared command will be refused as "
                 "CONTROLLER_TIME_NOT_TRUSTED until a control-zone time source is provisioned. "
                 "Every message reports timeQuality=%.*s until then.",
                 static_cast<int>(time_quality().size()),
                 time_quality().data());
    }

    std::int64_t sequence = 0;
    std::uint64_t heartbeat_due = 0;
    std::uint64_t telemetry_due = 0;
    std::uint64_t discipline_due = 0;
    std::uint32_t node_bus_sequence = 0;

    while (true) {
        const std::uint64_t now = uptime_milliseconds();

        sample_discrete_inputs(now);

        // Re-attempt initialisation while the machine is still in Initialising.
        //
        // It used to be attempted ONCE, at boot, and Initialising has no other exit — so a
        // controller powered up with any permissive absent was stuck there forever. That is
        // not an edge case: the ordinary state of a cell before an operator arrives is the
        // start-enable key off and the guard open, and every one of those controllers would
        // have needed a power cycle at exactly the right moment to ever reach Idle.
        // CH1-EMB-FDS-0001 says startup "enters Idle only when permissives are valid", which
        // is a condition to keep testing, not an instant to test once.
        //
        // The state machine is unchanged and is right to refuse: initialise() still admits
        // Idle only with every permissive valid and the confirmation button not already
        // held. What changes is that it is asked again.
        if (machine.state() == cinerion::cell::State::Initialising) {
            if (machine.initialise(local_inputs()) == cinerion::cell::Result::Accepted) {
                ESP_LOGW(tag, "permissives became valid; the cell has entered Idle");
            }
        }

        poll_command_topic();
        poll_node_bus(node_bus_sequence);
        machine.tick(now);
        watchdog.check_in(control_task, now);

        // Computed, logged, and applied to nothing. See the note at the head of this file:
        // the plan is an intent, and `firmware/pinmap/esp32s3-r01.json` records that no
        // actuator output is energisable at this hardware revision.
        const auto plan = planner.plan(condition_of(machine.state()), diagnostics(now), now);
        if (!plan.inhibit_reason.empty()) {
            ESP_LOGW(tag,
                     "actuator enable withheld: %.*s",
                     static_cast<int>(plan.inhibit_reason.size()),
                     plan.inhibit_reason.data());
        }

        // Re-disciplined on a cadence well inside the hour that separates Synchronised from
        // holdover, so an ordinary run never drifts out of the command path, and a controller
        // that loses its time server degrades through holdover rather than falling off a
        // cliff. The attempt never blocks the loop: a failure is ordinary and the clock
        // simply keeps whatever quality it had.
        if (now >= discipline_due) {
            std::int64_t disciplined_at = -1;
            if (ch1_discipline_clock(&disciplined_at)) {
                clock_source.disciplined(disciplined_at, now);
            }
            discipline_due = now + 900'000;
        }

        if (now >= heartbeat_due) {
            report_heartbeat(++sequence);
            heartbeat_due = now + 15'000;
        }

        if (now >= telemetry_due) {
            report_telemetry(sequence, now);
            telemetry_due = now + 5'000;
        }

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}
