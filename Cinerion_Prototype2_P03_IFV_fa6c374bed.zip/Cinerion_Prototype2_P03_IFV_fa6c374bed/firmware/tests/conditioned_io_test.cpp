// Host tests for the conditioned I/O layer.
//
// Nothing here needs a board. That is the point: CH1-EMB-FDS-0001 asks for hardware
// abstraction that permits deterministic test doubles, and the whole layer takes a sample
// and a clock reading and returns a decision — so the decisions the controlled I/O table
// requires can be executed rather than argued about.
//
// The clock never runs. Every test advances it by hand, which is what makes a 5-second
// stuck bound and a 24-hour holdover window testable in the same millisecond.

#include "cinerion/conditioned_io.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>

using cinerion::io::AnalogueChannel;
using cinerion::io::AnalogueChannelConfig;
using cinerion::io::BuzzerPattern;
using cinerion::io::CellCondition;
using cinerion::io::Circuit;
using cinerion::io::Conditioning;
using cinerion::io::Diagnostics;
using cinerion::io::DiscreteInput;
using cinerion::io::DiscreteInputConfig;
using cinerion::io::OutputPlanner;
using cinerion::io::OutputPlannerConfig;
using cinerion::io::OutputWatchdog;
using cinerion::io::Quality;
using cinerion::io::TimeQuality;
using cinerion::io::TimeSource;
using cinerion::io::TimeSourceConfig;

namespace signals = cinerion::io::signals;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(EXIT_FAILURE);
}

void expect(const bool condition, const char* message) {
    if (!condition) {
        fail(message);
    }
}

void expect_near(const double actual, const double expected, const char* message) {
    if (std::abs(actual - expected) > 1e-9) {
        std::cerr << "  expected " << expected << ", got " << actual << '\n';
        fail(message);
    }
}

// Announces the controlled verification case a block is offered as evidence for. Printed
// only after the block's assertions have held, so scripts/check-verification.mjs cannot
// read a claim for a check that did not execute.
void verification_case(const char* test_case_id) {
    std::cout << "VERIFICATION-CASE " << test_case_id << '\n';
}

/// Holds a level for long enough that the debounce believes it.
void hold(DiscreteInput& input, const bool level, std::uint64_t& now, const std::uint64_t milliseconds) {
    const std::uint64_t until = now + milliseconds;
    while (now < until) {
        input.sample(level, now);
        now += 5;
    }
    input.sample(level, now);
}

DiscreteInputConfig confirmation_config() {
    // CH1-IO-DI-0004, exactly as firmware/pinmap/esp32s3-r01.json declares it.
    return DiscreteInputConfig{signals::confirmation_button, Circuit::NormallyOpen, 30, 5000};
}

}  // namespace

int main() {
    // -- Debounce: a bouncing contact is not a press. -------------------------------------
    {
        DiscreteInput button{confirmation_config()};
        std::uint64_t now = 1'000;

        expect(!button.asserted(), "a discrete input starts de-energised");
        expect(!button.settled(), "nothing has been believed yet");

        // 25 ms of chatter, below the 30 ms bound. Nothing is believed.
        for (std::uint64_t tick = 0; tick < 5; ++tick) {
            button.sample(tick % 2 == 0, now);
            now += 5;
        }
        expect(!button.asserted(), "a bouncing contact must not read as a press");

        hold(button, true, now, 40);
        expect(button.asserted(), "a level held past the debounce bound is believed");
        expect(button.settled(), "the input has now settled");

        hold(button, false, now, 40);
        expect(!button.asserted(), "release is debounced the same way");
    }

    // -- A late task does not shorten the debounce. ---------------------------------------
    // A sample count would: five samples at a 5 ms cadence is 25 ms, and five samples from
    // a task that ran late is 250 ms. The bound is time, so both answer the same.
    {
        DiscreteInput button{confirmation_config()};
        std::uint64_t now = 0;
        button.sample(true, now);
        now += 20;
        button.sample(true, now);
        expect(!button.asserted(), "20 ms is short of the 30 ms bound however few samples it took");
        now += 15;
        button.sample(true, now);
        expect(button.asserted(), "35 ms is past it");
    }

    // -- Stuck detection: CH1-IO-DI-0004's controlled diagnostic action. -------------------
    {
        DiscreteInput button{confirmation_config()};
        std::uint64_t now = 1'000;

        hold(button, true, now, 40);
        expect(button.asserted(), "pressed");
        expect(!button.stuck(), "a press is not yet stuck");

        // Held for the configured 5 seconds. A welded contact or a shorted conductor looks
        // exactly like this, and there is no way to tell them apart from a person leaning
        // on the button — which is why both are refused.
        hold(button, true, now, 5'200);
        expect(button.stuck(), "a signal asserted past its bound is stuck");
        expect(!button.asserted(), "a stuck signal asserts nothing");

        // Time passing does not clear it. Only release does.
        hold(button, true, now, 10'000);
        expect(button.stuck(), "a stuck signal that is still asserted has proved nothing");

        hold(button, false, now, 40);
        expect(!button.stuck(), "release clears the fault");
        hold(button, true, now, 40);
        expect(button.asserted(), "and a fresh press is believed again");
    }

    // -- A controller that booted with a shorted button never offers a confirmation. -------
    // The state machine detects the confirmation edge itself, so a level that reads as
    // pressed from the first sample would present one. This is the conditioning that stops
    // it: 5 seconds after boot the input is stuck, and a stuck input asserts nothing.
    {
        DiscreteInput button{confirmation_config()};
        std::uint64_t now = 0;
        hold(button, true, now, 6'000);
        expect(button.stuck(), "a button shorted before boot is stuck");
        expect(!button.asserted(), "and cannot confirm anything");
    }

    // -- A normally closed circuit fails to the demand, not to silence. --------------------
    {
        // CH1-IO-DI-0005, the guard. Controlled normal state "Healthy/NC".
        DiscreteInput guard{{signals::guard_interlock, Circuit::NormallyClosed, 10, 0}};
        std::uint64_t now = 0;

        expect(guard.circuit_healthy(), "a normally closed input starts intact");
        expect(!guard.asserted(), "and asserts nothing while it is");

        hold(guard, false, now, 20);
        expect(!guard.circuit_healthy(), "an opened loop is not healthy");
        expect(guard.asserted(), "and the guard demand is asserted");

        hold(guard, true, now, 20);
        expect(guard.circuit_healthy(), "restored");
    }

    // -- Range and rate validation: CH1-IO-AI-0001. ----------------------------------------
    {
        AnalogueChannel temperature{{
            signals::temperature, "CH1-TEL-TEMPERATURE", "degC", Conditioning::RangeRate,
            -40.0, 125.0, 5.0, 1, 5'000}};

        auto reading = temperature.read(0);
        expect(reading.quality == Quality::Bad, "a channel with no sample is Bad");
        expect(reading.substituted, "and substituted");
        expect(!reading.publishable, "and publishes nothing");
        expect(reading.sampled_at_milliseconds < 0, "with no source time to offer");

        temperature.sample(21.5, 1'000, 1'000);
        reading = temperature.read(1'000);
        expect(reading.quality == Quality::Good, "an in-range sample is Good");
        expect_near(reading.value, 21.5, "the value is the measurement");
        expect(reading.unit == "degC", "the engineering unit travels with it");
        expect(reading.sampled_at_milliseconds == 1'000, "and the SOURCE sample time, not the read time");

        // Out of range. Substituted and Bad — never Good with a plausible number in it.
        temperature.sample(400.0, 2'000, 2'000);
        reading = temperature.read(2'000);
        expect(reading.quality == Quality::Bad, "an implausible sample is Bad");
        expect(reading.substituted, "and substituted rather than published");

        temperature.sample(21.6, 3'000, 3'000);
        expect(temperature.read(3'000).quality == Quality::Good, "and the channel recovers");

        // 40 degrees in one second, against a 5 deg/s bound.
        temperature.sample(61.6, 4'000, 4'000);
        reading = temperature.read(4'000);
        expect(reading.quality == Quality::Uncertain, "a step past the rate bound is Uncertain");
        expect(!reading.substituted, "but reported: a genuine transient is data");
        expect_near(reading.value, 61.6, "and reported as measured");
    }

    // -- Freshness: an old number presented as current is worse than none. -----------------
    {
        AnalogueChannel humidity{{
            signals::relative_humidity, "CH1-TEL-HUMIDITY", "percentRH", Conditioning::RangeRate,
            0.0, 100.0, 20.0, 1, 5'000}};
        humidity.sample(44.0, 1'000, 1'000);
        expect(humidity.read(5'900).quality == Quality::Good, "still fresh at 4.9 s");
        const auto stale = humidity.read(6'100);
        expect(stale.quality == Quality::Bad, "stale past the configured bound");
        expect(stale.substituted, "and substituted");
        expect(!stale.publishable, "and not published");
    }

    // -- A sample the controller cannot time is refused. -----------------------------------
    {
        AnalogueChannel humidity{{
            signals::relative_humidity, "CH1-TEL-HUMIDITY", "percentRH", Conditioning::RangeRate,
            0.0, 100.0, 20.0, 1, 5'000}};
        humidity.sample(44.0, -1, 1'000);
        const auto reading = humidity.read(1'000);
        expect(reading.quality == Quality::Bad, "a sample with no trustworthy source time is refused");
        expect(reading.sampled_at_milliseconds < 0, "and stamps nothing");
    }

    // -- Median filter: CH1-IO-AI-0003. -----------------------------------------------------
    {
        AnalogueChannel position{{
            signals::position, "CH1-TEL-POSITION", "mm", Conditioning::Median,
            0.0, 4'000.0, 0.0, 5, 1'000}};

        const double samples[] = {100.0, 101.0, 99.0, 100.5};
        std::int64_t at = 0;
        for (const double sample : samples) {
            at += 100;
            position.sample(sample, at, static_cast<std::uint64_t>(at));
            expect(!position.read(static_cast<std::uint64_t>(at)).publishable,
                   "a window that has not filled publishes nothing");
            expect(position.read(static_cast<std::uint64_t>(at)).quality == Quality::Uncertain,
                   "and says so as Uncertain rather than Bad");
        }

        // A single 900 mm outlier in a window of five. The median rejects it; a mean would
        // have moved the answer by 160 mm.
        at += 100;
        position.sample(900.0, at, static_cast<std::uint64_t>(at));
        const auto reading = position.read(static_cast<std::uint64_t>(at));
        expect(reading.publishable, "a full window publishes");
        expect(reading.quality == Quality::Good, "and is Good");
        expect_near(reading.value, 100.5, "the median rejects a single outlier");
    }

    // -- Windowed RMS: CH1-IO-AI-0004. ------------------------------------------------------
    {
        AnalogueChannel vibration{{
            signals::vibration, "CH1-TEL-VIBRATION", "m/s2", Conditioning::WindowedRms,
            -160.0, 160.0, 0.0, 4, 1'000}};

        // A symmetric oscillation whose mean is zero. An averaging filter would report no
        // vibration at all; RMS reports its magnitude, which is the quantity that matters.
        const double samples[] = {3.0, -3.0, 3.0, -3.0};
        std::int64_t at = 0;
        for (const double sample : samples) {
            at += 20;
            vibration.sample(sample, at, static_cast<std::uint64_t>(at));
        }
        const auto reading = vibration.read(static_cast<std::uint64_t>(at));
        expect(reading.publishable, "a full window publishes");
        expect_near(reading.value, 3.0, "RMS of a symmetric oscillation is its amplitude");
        expect(reading.unit == "m/s2", "carrying the controlled engineering unit");
    }

    // -- The output plan follows the controlled I/O table, condition by condition. ----------
    {
        OutputPlanner planner{OutputPlannerConfig{2'000, 200}};
        const Diagnostics healthy{};

        const auto idle = planner.plan(CellCondition::Idle, healthy, 1'000);
        expect(idle.green_indicator, "Idle is ready, and green");
        expect(!idle.confirmation_lamp, "the lamp is not lit outside AwaitButton");
        expect(!idle.actuator_enable, "and nothing is enabled");

        const auto awaiting = planner.plan(CellCondition::AwaitButton, healthy, 2'000);
        expect(awaiting.confirmation_lamp, "the lamp is lit in AwaitButton");
        expect(awaiting.amber_indicator, "which is a prepared state");
        expect(!awaiting.green_indicator, "and not a ready one");
        expect(awaiting.buzzer_pattern == BuzzerPattern::SlowPulse, "and the buzzer draws attention to it");
        expect(!awaiting.actuator_enable, "a confirmation offered is not an execution");

        const auto committed = planner.plan(CellCondition::Committed, healthy, 3'000);
        expect(!committed.confirmation_lamp, "the lamp goes out once the press is taken");
        expect(!committed.actuator_enable, "and a commit alone still energises nothing");

        const auto executing = planner.plan(CellCondition::Executing, healthy, 4'000);
        expect(executing.actuator_enable, "Executing is the one condition that grants the enable");
        expect(executing.step_enable, "and the stepper follows it");
        expect(executing.step_rate_per_second == 2'000, "rate limited to the configured maximum");
        expect(executing.inhibit_reason.empty(), "with nothing withheld");

        const auto fault = planner.plan(CellCondition::FaultLatched, healthy, 5'000);
        expect(fault.red_indicator, "a latched fault is red");
        expect(!fault.green_indicator, "and not green");
        expect(!fault.actuator_enable, "and energises nothing");
        expect(fault.buzzer_pattern == BuzzerPattern::FastPulse, "and is audible");

        // Every condition but Executing withholds the enable. Stated as a sweep rather than
        // as five separate assertions, so a condition added later is covered by construction.
        const CellCondition all[] = {
            CellCondition::Initialising, CellCondition::Idle, CellCondition::AwaitCredential,
            CellCondition::AwaitButton, CellCondition::Committed, CellCondition::Complete,
            CellCondition::FaultLatched};
        for (const CellCondition condition : all) {
            OutputPlanner sweep{OutputPlannerConfig{2'000, 200}};
            const auto planned = sweep.plan(condition, healthy, 6'000);
            expect(!planned.actuator_enable, "no condition but Executing energises the actuator");
            expect(!planned.step_enable, "nor the stepper");
            expect(planned.step_rate_per_second == 0, "which is commanded no rate");
        }
    }
    verification_case("CH1-VVT-TC-0072");

    // -- The watchdog takes the enable away: CH1-VVT-TC-0073. -------------------------------
    {
        OutputWatchdog watchdog{};
        const auto control = watchdog.supervise("control", 250, 0);
        const auto telemetry = watchdog.supervise("telemetry", 2'000, 0);
        expect(watchdog.count() == 2, "two supervised tasks");
        expect(watchdog.healthy(100), "both are within their deadlines");

        // The control task stops checking in. The telemetry task keeps going, so this is a
        // single task failing rather than the controller stopping.
        watchdog.check_in(telemetry, 300);
        expect(!watchdog.healthy(300), "a task past its deadline is not healthy");
        expect(watchdog.first_overdue(300) == "control", "and the diagnostic names it");

        OutputPlanner planner{OutputPlannerConfig{2'000, 200}};
        Diagnostics failing{};
        failing.watchdog_healthy = false;

        const auto planned = planner.plan(CellCondition::Executing, failing, 300);
        expect(!planned.actuator_enable, "a failed task removes the actuator enable");
        expect(!planned.step_enable, "and the stepper with it");
        expect(planned.inhibit_reason == "WATCHDOG_UNHEALTHY", "and says why");
        expect(planned.buzzer_pattern == BuzzerPattern::FastPulse, "audibly");
        expect(planned.amber_indicator, "and visibly");

        watchdog.check_in(control, 400);
        expect(watchdog.healthy(400), "a task that resumes is healthy again");
        expect(watchdog.first_overdue(400).empty(), "with nothing overdue");

        // A watchdog table that overflowed supervises fewer tasks than the controller
        // believes. That is worse than refusing, so it is never healthy again.
        OutputWatchdog crowded{};
        for (std::size_t index = 0; index <= cinerion::io::maximum_supervised_tasks; ++index) {
            crowded.supervise("task", 1'000, 0);
        }
        expect(crowded.overflowed(), "the table refused a task it could not hold");
        expect(!crowded.healthy(0), "and a watchdog that could not supervise everything is not healthy");
    }
    verification_case("CH1-VVT-TC-0073");

    // -- The other two things that withhold the enable. -------------------------------------
    {
        OutputPlanner planner{OutputPlannerConfig{2'000, 200}};
        Diagnostics open{};
        open.permissive_circuit_open = true;
        const auto cut = planner.plan(CellCondition::Executing, open, 1'000);
        expect(!cut.actuator_enable, "a cut permissive conductor withholds the enable");
        expect(cut.inhibit_reason == "PERMISSIVE_CIRCUIT_OPEN", "and says so");

        OutputPlanner second{OutputPlannerConfig{2'000, 200}};
        Diagnostics stuck{};
        stuck.discrete_input_stuck = true;
        const auto welded = second.plan(CellCondition::Executing, stuck, 1'000);
        expect(!welded.actuator_enable, "a stuck discrete input withholds it too");
        expect(welded.inhibit_reason == "DISCRETE_INPUT_STUCK", "and says so");
    }

    // -- The buzzer is pattern controlled, and has no continuous setting to select. ---------
    {
        OutputPlanner planner{OutputPlannerConfig{2'000, 200}};
        const Diagnostics healthy{};

        // A pure function of the monotonic clock, so both halves of the wave are assertable.
        expect(planner.plan(CellCondition::AwaitButton, healthy, 10'000).buzzer, "slow pulse, on");
        expect(!planner.plan(CellCondition::AwaitButton, healthy, 10'600).buzzer, "slow pulse, off");
        expect(planner.plan(CellCondition::FaultLatched, healthy, 10'000).buzzer, "fast pulse, on");
        expect(!planner.plan(CellCondition::FaultLatched, healthy, 10'200).buzzer, "fast pulse, off");

        // Completion beeps once and then stops, rather than sounding until acknowledged.
        OutputPlanner completing{OutputPlannerConfig{2'000, 200}};
        expect(completing.plan(CellCondition::Executing, healthy, 1'000).buzzer_pattern == BuzzerPattern::Silent,
               "executing is silent");
        expect(completing.plan(CellCondition::Complete, healthy, 2'000).buzzer, "completion beeps");
        expect(completing.plan(CellCondition::Complete, healthy, 2'100).buzzer, "for its configured length");
        expect(!completing.plan(CellCondition::Complete, healthy, 2'300).buzzer, "and then stops");
        expect(completing.plan(CellCondition::Complete, healthy, 9'000).buzzer_pattern == BuzzerPattern::Silent,
               "and stays stopped, so a buzzer nobody silences keeps its meaning");
    }

    // -- Time quality, and the two clocks that answer differently. --------------------------
    {
        TimeSource clock{TimeSourceConfig{3'600'000, 86'400'000}};

        expect(clock.quality(0) == TimeQuality::Unsynchronised, "a controller starts with no trusted clock");
        expect(clock.report_clock(0) < 0, "and can stamp nothing");
        expect(clock.command_clock(0) < 0, "and judge no expiry");
        expect(cinerion::io::time_quality_name(clock.quality(0)) == "Unsynchronised",
               "and says which, rather than claiming otherwise");

        // SNTP answers 1 September 2026, 12:00:00 UTC, 60 s after boot.
        clock.disciplined(1'788'609'600'000, 60'000);
        expect(clock.quality(60'000) == TimeQuality::Synchronised, "disciplined");
        expect(clock.report_clock(65'000) == 1'788'609'605'000, "and the wall clock advances with the monotonic one");
        expect(clock.command_clock(65'000) == 1'788'609'605'000, "and a command may be judged against it");

        // An hour later, with no further discipline.
        const std::uint64_t holdover_at = 60'000 + 3'600'001;
        expect(clock.quality(holdover_at) == TimeQuality::Holdover, "an undisciplined hour is holdover");
        expect(clock.report_clock(holdover_at) > 0, "a sample may still be stamped, and says Holdover");
        expect(clock.command_clock(holdover_at) < 0,
               "and a command expiry may NOT be judged on a clock that has drifted by an unknown amount");

        const std::uint64_t stale_at = 60'000 + 86'400'001;
        expect(clock.quality(stale_at) == TimeQuality::Stale, "a day later it is stale");
        expect(clock.report_clock(stale_at) < 0, "and carries nothing at all");

        // A discipline that offers no time disciplines nothing.
        TimeSource refused{};
        refused.disciplined(-1, 1'000);
        expect(refused.quality(1'000) == TimeQuality::Unsynchronised, "a failed sync is not a sync");
    }

    std::cout << "Cinerion conditioned-I/O host tests passed.\n";
    return EXIT_SUCCESS;
}
