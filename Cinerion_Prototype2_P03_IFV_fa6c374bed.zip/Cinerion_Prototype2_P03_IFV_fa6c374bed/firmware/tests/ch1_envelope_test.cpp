// Host test for the CH1 envelope and its CBOR encoding.
//
// The point of this file is the hex literal below. It is what the .NET canonical encoder
// produces for a stated envelope, and services/edge-link/tests/.../Ch1MessageEnvelopeTests
// asserts the same literal from the other side. Two independent implementations of one
// controlled wire format agree only if something says so, and the bytes are the only
// honest form of that statement.
//
// Two things this cross-check caught before any hardware existed, both of which would
// have had the gateway reject every message this firmware sent:
//
//   * canonical map keys sort by LENGTH first and only then bytewise, so "type" precedes
//     "cellId". The first version of the encoder emitted them alphabetically;
//   * canonical floats use the SHORTEST form that is exact, so 22.5 is a half, not a
//     double. The first version always emitted 64-bit doubles.
//
// Neither would have been visible from reading the firmware, and neither would have
// appeared until a real controller was talking to a real broker.

#include "cinerion/cbor.hpp"
#include "cinerion/ch1_envelope.hpp"

#include <array>
#include <cstdio>
#include <cstring>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace {

int failures = 0;

void check(bool condition, std::string_view what) {
    if (condition) {
        std::printf("PASS  %.*s\n", static_cast<int>(what.size()), what.data());
        return;
    }
    std::printf("FAIL  %.*s\n", static_cast<int>(what.size()), what.data());
    ++failures;
}

std::string hex(std::span<const std::uint8_t> bytes) {
    static constexpr char digits[] = "0123456789ABCDEF";
    std::string out;
    out.reserve(bytes.size() * 2);
    for (const std::uint8_t byte : bytes) {
        out.push_back(digits[byte >> 4]);
        out.push_back(digits[byte & 0x0F]);
    }
    return out;
}

/// A UUID as the envelope carries it: 16 raw bytes in .NET Guid byte order, which is what
/// Guid.ToByteArray produces and what the gateway reads back with new Guid(bytes).
constexpr std::array<std::uint8_t, 16> project_id{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01};
constexpr std::array<std::uint8_t, 16> cell_id{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x03};
constexpr std::array<std::uint8_t, 16> asset_id{
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x04};
constexpr std::array<std::uint8_t, 16> message_id{
    0x11, 0x11, 0x11, 0x11, 0x22, 0x22, 0x33, 0x33, 0x44, 0x44, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55};
constexpr std::array<std::uint8_t, 16> correlation_id{
    0x66, 0x66, 0x66, 0x66, 0x77, 0x77, 0x88, 0x88, 0x99, 0x99, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA};

cinerion::ch1::Origin reference_origin() {
    return {
        .source = "CH1-DEV-CELL-0001",
        .destination = "ch1-edgelink",
        .project = cinerion::ch1::Uuid(project_id),
        .cell = cinerion::ch1::Uuid(cell_id),
        .asset = cinerion::ch1::Uuid(asset_id),
    };
}

/// The agreed encoding. Cinerion.EdgeLink.Tests holds the same literal.
constexpr std::string_view expected_telemetry_hex =
    "AD64747970656974656C656D657472796663656C6C49645000000000000000408000000000000103"
    "66736368656D6165312E302E306673656E7441741B0000018BCFE56BE866736F7572636571434831"
    "2D4445562D43454C4C2D303030316761737365744964500000000000000040800000000000010467"
    "7061796C6F6164A564756E697464646567436576616C7565F94DA0677175616C69747964476F6F64"
    "696368616E6E656C49646B74656D70657261747572656973616D706C656441741B0000018BCFE568"
    "006873657175656E6365182A696D6573736167654964501111111122223333444455555555555569"
    "70726F6A656374496450000000000000004080000000000001016B64657374696E6174696F6E6C63"
    "68312D656467656C696E6B6B74696D655175616C6974796C53796E6368726F6E697365646D636F72"
    "72656C6174696F6E49645066666666777788889999AAAAAAAAAAAA";

void telemetry_matches_the_gateway_byte_for_byte() {
    std::array<std::uint8_t, 512> buffer{};
    const cinerion::ch1::Reading reading{
        .channel = "temperature",
        .value = 22.5,
        .unit = "degC",
        .quality = "Good",
        .sampled_at_milliseconds = 1'700'000'000'000,
    };

    const std::size_t written = cinerion::ch1::encode_telemetry(
        buffer,
        reference_origin(),
        cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation_id),
        1'700'000'001'000,
        42,
        "Synchronised",
        reading);

    check(written > 0, "the reference telemetry envelope fits its buffer");
    const std::string produced = hex(std::span<const std::uint8_t>(buffer.data(), written));

    const bool agrees = produced == expected_telemetry_hex;
    if (!agrees) {
        std::printf("      expected prefix: %.*s\n",
                    static_cast<int>(expected_telemetry_hex.size()), expected_telemetry_hex.data());
        std::printf("      produced:        %s\n", produced.substr(0, expected_telemetry_hex.size()).c_str());
    }
    check(agrees, "the firmware encodes the reference telemetry exactly as the gateway does");

    // 22.5 must be a half-precision float (0xF9), not a double. If this regresses the
    // gateway's canonical reader refuses the message.
    check(produced.find("76616C7565F94DA0") != std::string::npos,
          "value 22.5 is encoded in the shortest exact float form, a half");
}

void a_command_out_of_scope_is_refused() {
    // Built with the writer directly, because the device never encodes commands: this is
    // what a gateway would put on the wire, with one field changed.
    std::array<std::uint8_t, 512> buffer{};
    cinerion::cbor::Writer writer(buffer);
    constexpr std::array<std::uint8_t, 16> other_cell{
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x09};

    writer.map_header(4);
    writer.text("type");
    writer.text("command");
    writer.text("cellId");
    writer.bytes(other_cell);
    writer.text("schema");
    writer.text("1.0.0");
    writer.text("projectId");
    writer.bytes(project_id);

    const auto command = cinerion::ch1::decode_command(
        std::span<const std::uint8_t>(buffer.data(), writer.size()), reference_origin(), 1'700'000'000'000);

    check(!command.valid, "a command naming another cell is refused");
    check(command.refusal_code == "COMMAND_OUT_OF_SCOPE",
          "the refusal names the scope, not a parse failure");
}

void a_controller_without_trusted_time_refuses_every_command() {
    std::array<std::uint8_t, 512> buffer{};
    cinerion::cbor::Writer writer(buffer);
    writer.map_header(6);
    writer.text("type");
    writer.text("command");
    writer.text("cellId");
    writer.bytes(cell_id);
    writer.text("schema");
    writer.text("1.0.0");
    writer.text("payload");
    writer.map_header(4);
    writer.text("commandType");
    writer.text("RUN_DIMENSIONAL_TEST");
    writer.text("expectedStateHash");
    writer.text("abc");
    writer.text("idempotencyKey");
    writer.bytes(message_id);
    writer.text("configurationRevision");
    writer.text("CFG-REFAB-P01-R01");
    writer.text("expiresAt");
    writer.signed_value(1'900'000'000'000);
    writer.text("projectId");
    writer.bytes(project_id);

    const std::span<const std::uint8_t> envelope(buffer.data(), writer.size());

    const auto trusted = cinerion::ch1::decode_command(envelope, reference_origin(), 1'700'000'000'000);
    check(trusted.valid, "a complete, in-scope, unexpired command is accepted");
    check(trusted.command_type == "RUN_DIMENSIONAL_TEST", "the semantic command name is read back");

    const auto expired = cinerion::ch1::decode_command(envelope, reference_origin(), 1'950'000'000'000);
    check(!expired.valid && expired.refusal_code == "COMMAND_EXPIRED",
          "the same command after its expiry is refused");

    // A controller that cannot judge the time refuses rather than guesses. Commands
    // expire and are never replayed after reconnect, so accepting one whose expiry cannot
    // be evaluated would remove the only bound on how long an intent lives.
    const auto untrusted = cinerion::ch1::decode_command(envelope, reference_origin(), -1);
    check(!untrusted.valid && untrusted.refusal_code == "CONTROLLER_TIME_NOT_TRUSTED",
          "a controller with no trustworthy clock refuses the command");
}

void a_register_write_is_not_a_command() {
    std::array<std::uint8_t, 512> buffer{};
    cinerion::cbor::Writer writer(buffer);
    writer.map_header(6);
    writer.text("type");
    writer.text("command");
    writer.text("cellId");
    writer.bytes(cell_id);
    writer.text("schema");
    writer.text("1.0.0");
    writer.text("payload");
    writer.map_header(4);
    writer.text("commandType");
    writer.text("write:40001");
    writer.text("expectedStateHash");
    writer.text("abc");
    writer.text("idempotencyKey");
    writer.bytes(message_id);
    writer.text("configurationRevision");
    writer.text("CFG-REFAB-P01-R01");
    writer.text("expiresAt");
    writer.signed_value(1'900'000'000'000);
    writer.text("projectId");
    writer.bytes(project_id);

    const auto command = cinerion::ch1::decode_command(
        std::span<const std::uint8_t>(buffer.data(), writer.size()), reference_origin(), 1'700'000'000'000);

    check(!command.valid && command.refusal_code == "SEMANTIC_COMMAND_INVALID",
          "a register address is refused as a command type");
}

void a_truncated_envelope_is_refused_rather_than_partly_read() {
    std::array<std::uint8_t, 512> buffer{};
    const cinerion::ch1::Reading reading{
        .channel = "temperature", .value = 22.5, .unit = "degC", .quality = "Good",
        .sampled_at_milliseconds = 1'700'000'000'000};
    const std::size_t written = cinerion::ch1::encode_telemetry(
        buffer, reference_origin(), cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation_id), 1'700'000'001'000, 42, "Synchronised", reading);

    bool every_prefix_refused = true;
    for (std::size_t keep = 1; keep < written; keep += 7) {
        const auto command = cinerion::ch1::decode_command(
            std::span<const std::uint8_t>(buffer.data(), keep), reference_origin(), 1'700'000'000'000);
        if (command.valid) every_prefix_refused = false;
    }

    check(every_prefix_refused, "no truncation of a valid envelope decodes as a valid command");
}

void the_writer_refuses_rather_than_truncating() {
    std::array<std::uint8_t, 8> tiny{};
    const cinerion::ch1::Heartbeat heartbeat{
        .firmware_version = "0.1.0-prototype.2",
        .configuration_revision = "CFG-REFAB-P01-R01",
        .uptime_seconds = 120};

    const std::size_t written = cinerion::ch1::encode_heartbeat(
        tiny, reference_origin(), cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation_id), 1'700'000'001'000, 1, "Synchronised", heartbeat);

    check(written == 0, "a message that does not fit its buffer is refused, never truncated");
}

/// A controller must report the clock it has, not the clock it would like.
///
/// This encoder wrote the literal "Synchronised" into every envelope while the same
/// firmware's `wall_clock_milliseconds()` returned -1 and refused every prepared command as
/// CONTROLLER_TIME_NOT_TRUSTED. Both statements cannot be true, and the one on the wire was
/// the false one. CH1-COM-ICD-0001 requires time quality to be visible so audit decisions
/// are not silently made on invalid time; a constant is not a report.
void an_undisciplined_controller_says_so_on_the_wire() {
    std::array<std::uint8_t, 512> buffer{};
    const cinerion::ch1::Reading reading{
        .channel = "temperature",
        .value = 22.5,
        .unit = "degC",
        .quality = "Good",
        .sampled_at_milliseconds = 1'700'000'000'000,
    };

    const std::size_t written = cinerion::ch1::encode_telemetry(
        buffer, reference_origin(), cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation_id), 1'700'000'001'000, 42, "Unsynchronised", reading);
    check(written > 0, "an envelope from an undisciplined controller still encodes");

    const std::string produced = hex(std::span<const std::uint8_t>(buffer.data(), written));
    // "timeQuality" then "Unsynchronised": 0x6B + the key, 0x6E + the value.
    check(produced.find("6B74696D655175616C697479") != std::string::npos,
          "the envelope carries a timeQuality field");
    check(produced.find("6E556E73796E6368726F6E69736564") != std::string::npos,
          "and it reads Unsynchronised, because that is what the clock reports");
    check(produced.find("6C53796E6368726F6E69736564") == std::string::npos,
          "and it does not also claim Synchronised");

    // The pinned reference vector is the same message with a disciplined clock, so the two
    // differ in exactly one field. If they did not, the parameter would be decorative.
    const std::size_t reference_written = cinerion::ch1::encode_telemetry(
        buffer, reference_origin(), cinerion::ch1::Uuid(message_id),
        cinerion::ch1::Uuid(correlation_id), 1'700'000'001'000, 42, "Synchronised", reading);
    check(hex(std::span<const std::uint8_t>(buffer.data(), reference_written)) == expected_telemetry_hex,
          "and the disciplined form is still the byte-for-byte vector the gateway agrees on");
}

/// The declared buffer bound covers the worst case of every message type.
///
/// This is the check that would have caught defect 64. app_main.cpp sized its telemetry and
/// heartbeat buffers at 320 bytes and its acknowledgement buffer at 384; the three messages
/// encode to 355, 365 and 438. Every message the controller could send would have been
/// refused — the encoder returns 0 rather than truncating, so the device fails safe and goes
/// SILENT, which for the heartbeat CH1-COM-FR-0009 requires is a fault in itself.
///
/// Nothing caught it because every test here encodes into a buffer of its own choosing. A
/// test that picks its own buffer proves the encoder works; it says nothing about whether
/// the CALLER gave it enough room. This asserts the bound the callers now use, against the
/// largest message each type can produce.
void the_declared_bound_covers_every_message_type() {
    constexpr std::array<std::uint8_t, 16> id{
        0x11, 0x11, 0x11, 0x11, 0x22, 0x22, 0x33, 0x33, 0x44, 0x44, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55};
    std::array<std::uint8_t, 2048> roomy{};

    // The longest channel identifier the controlled catalogue contains, its longest unit,
    // and the longest quality word.
    const cinerion::ch1::Reading widest_reading{
        .channel = "CH1-IO-AI-0001",
        .value = -123.456789,
        .unit = "m/s2",
        .quality = "Uncertain",
        .sampled_at_milliseconds = 1'788'609'600'000,
    };
    const std::size_t telemetry = cinerion::ch1::encode_telemetry(
        roomy, reference_origin(), cinerion::ch1::Uuid(id), cinerion::ch1::Uuid(id),
        1'788'609'601'000, 999'999, "Unsynchronised", widest_reading);

    const cinerion::ch1::Heartbeat widest_heartbeat{
        .firmware_version = "0.1.0-prototype.2",
        .configuration_revision = "CFG-REFAB-P01-R01",
        .uptime_seconds = 999'999'999,
    };
    const std::size_t heartbeat = cinerion::ch1::encode_heartbeat(
        roomy, reference_origin(), cinerion::ch1::Uuid(id), cinerion::ch1::Uuid(id),
        1'788'609'601'000, 999'999, "Unsynchronised", widest_heartbeat);

    // The longest reason code and controller state the controller can answer with.
    const cinerion::ch1::Acknowledgement widest_acknowledgement{
        .command_id = cinerion::ch1::Uuid(id),
        .accepted = true,
        .controller_state = "AwaitingCredential",
        .reason_code = "PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION",
    };
    const std::size_t acknowledgement = cinerion::ch1::encode_acknowledgement(
        roomy, reference_origin(), cinerion::ch1::Uuid(id), cinerion::ch1::Uuid(id),
        1'788'609'601'000, 999'999, "Unsynchronised", widest_acknowledgement);

    std::printf("      worst case: telemetry %zu, heartbeat %zu, acknowledgement %zu; bound %zu\n",
                telemetry, heartbeat, acknowledgement, cinerion::ch1::maximum_envelope_bytes);

    check(telemetry > 0 && telemetry <= cinerion::ch1::maximum_envelope_bytes,
          "the widest telemetry envelope fits the declared bound");
    check(heartbeat > 0 && heartbeat <= cinerion::ch1::maximum_envelope_bytes,
          "the widest heartbeat fits it");
    check(acknowledgement > 0 && acknowledgement <= cinerion::ch1::maximum_envelope_bytes,
          "the widest acknowledgement fits it");

    // And the refusal is real: one byte short of the actual size must produce nothing at
    // all. Otherwise the bound above could be satisfied by an encoder that truncates.
    std::vector<std::uint8_t> tight(acknowledgement - 1);
    check(cinerion::ch1::encode_acknowledgement(
              tight, reference_origin(), cinerion::ch1::Uuid(id), cinerion::ch1::Uuid(id),
              1'788'609'601'000, 999'999, "Unsynchronised", widest_acknowledgement) == 0,
          "and a buffer one byte short of the message is refused, never truncated");
}

}  // namespace

int main() {
    telemetry_matches_the_gateway_byte_for_byte();
    the_declared_bound_covers_every_message_type();
    an_undisciplined_controller_says_so_on_the_wire();
    a_command_out_of_scope_is_refused();
    a_controller_without_trusted_time_refuses_every_command();
    a_register_write_is_not_a_command();
    a_truncated_envelope_is_refused_rather_than_partly_read();
    the_writer_refuses_rather_than_truncating();

    if (failures == 0) {
        std::printf("\nCH1 envelope: firmware and gateway agree on the wire format.\n");
        // Announced only after every assertion above has held.
        std::printf("VERIFICATION-CASE CH1-VVT-TC-0023\n");
        return 0;
    }

    std::printf("\n%d check(s) failed.\n", failures);
    return 1;
}
