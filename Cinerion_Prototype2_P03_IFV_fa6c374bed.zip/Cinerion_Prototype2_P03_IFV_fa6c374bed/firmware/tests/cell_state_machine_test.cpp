// Host tests for the cell state machine. Pokes every transition and checks the refusals too.

#include "cinerion/cell_state_machine.hpp"

#include <cstdlib>
#include <iostream>

using cinerion::cell::CellBinding;
using cinerion::cell::CompletionAcknowledgement;
using cinerion::cell::CredentialProof;
using cinerion::cell::LocalInputs;
using cinerion::cell::PrepareRequest;
using cinerion::cell::Result;
using cinerion::cell::State;
using cinerion::cell::StateMachine;

namespace {

constexpr std::uint64_t now_ms = 10'000;
constexpr CellBinding binding{1, 2, 3, 4, 7};
constexpr LocalInputs healthy{true, true, true, true, false, false, false};

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(EXIT_FAILURE);
}

void expect(const bool condition, const char* message) {
    if (!condition) {
        fail(message);
    }
}

// Announces the controlled verification case a block is offered as evidence for. The
// line is printed only after the block's assertions have held, and
// scripts/check-verification.mjs reads these from an actual run - so a case cannot be
// claimed for a check that did not execute.
void verification_case(const char* test_case_id) {
    std::cout << "VERIFICATION-CASE " << test_case_id << '\n';
}

PrepareRequest request(const std::uint64_t sequence = 1) {
    return PrepareRequest{100, 200, 1, 2, 3, 4, sequence, 7, 99, now_ms + 60'000};
}

CredentialProof proof() {
    return CredentialProof{100, 200, 1, true, true, now_ms + 20'000};
}

StateMachine prepared_machine() {
    StateMachine machine{binding, 99};
    expect(machine.initialise(healthy) == Result::Accepted, "initialise");
    expect(machine.prepare(request(), healthy, now_ms) == Result::Accepted, "prepare");
    expect(machine.accept_credential(proof(), now_ms + 1'000) == Result::Accepted, "credential");
    return machine;
}

/// The work-order state CH1-AUT-FDS-0001 requires a recovery to reconcile: the binding
/// this controller already holds, restated by whoever is closing the recovery out.
cinerion::cell::RecoveryReconciliation reconciliation() {
    return cinerion::cell::RecoveryReconciliation{1, 2, 3, 4, 7, 99};
}

StateMachine executing_machine() {
    auto machine = prepared_machine();
    auto pressed = healthy;
    pressed.confirmation_button = true;
    expect(machine.sample_physical_confirmation(pressed, now_ms + 2'000) == Result::Accepted, "commit");
    expect(machine.begin_execution() == Result::Accepted, "begin");
    return machine;
}

StateMachine completed_machine() {
    auto machine = executing_machine();
    expect(machine.complete_execution() == Result::Accepted, "complete");
    return machine;
}

StateMachine faulted_machine() {
    auto machine = executing_machine();
    expect(machine.latch_fault() == Result::Accepted, "latch");
    return machine;
}

}  // namespace

int main() {
    {
        auto machine = prepared_machine();
        auto pressed = healthy;
        pressed.confirmation_button = true;
        expect(machine.sample_physical_confirmation(pressed, now_ms + 2'000) == Result::Accepted, "physical commit");
        expect(machine.state() == State::Committed, "committed state");
        expect(!machine.outputs().actuator_enable, "commit does not energise before execution state");
        expect(machine.begin_execution() == Result::Accepted, "begin execution");
        expect(machine.outputs().actuator_enable, "actuator enabled only while executing");
        expect(machine.complete_execution() == Result::Accepted, "complete execution");
        expect(!machine.outputs().actuator_enable, "actuator disabled on completion");
        verification_case("CH1-VVT-TC-0011");
        verification_case("CH1-VVT-TC-0012");
        verification_case("CH1-VVT-TC-0072");
    }
    {
        StateMachine machine{binding, 99};
        auto held = healthy;
        held.confirmation_button = true;
        expect(machine.initialise(healthy) == Result::Accepted, "initialise held-button case");
        expect(machine.prepare(request(), held, now_ms) == Result::ButtonHeld, "held button rejected");
        verification_case("CH1-VVT-TC-0016");
    }
    {
        auto machine = prepared_machine();
        auto changed = healthy;
        changed.guard_healthy = false;
        changed.confirmation_button = true;
        expect(machine.sample_physical_confirmation(changed, now_ms + 2'000) == Result::InterlockInvalid,
               "changed guard blocks commit");
        expect(machine.state() == State::Idle, "invalid commit cancels prepare");
        verification_case("CH1-VVT-TC-0017");
    }
    {
        auto machine = prepared_machine();
        machine.tick(now_ms + 61'000);
        expect(machine.state() == State::Idle, "expiry cancels pending transaction");
        verification_case("CH1-VVT-TC-0015");
    }
    {
        StateMachine restarted{binding, 100};
        expect(restarted.initialise(healthy) == Result::Accepted, "restart initialise");
        expect(restarted.prepare(request(), healthy, now_ms) == Result::ControllerRestarted,
               "old prepare boot identity rejected");
        verification_case("CH1-VVT-TC-0018");
    }
    {
        StateMachine machine{binding, 99};
        expect(machine.initialise(healthy) == Result::Accepted, "sequence initialise");
        expect(machine.prepare(request(10), healthy, now_ms) == Result::Accepted, "sequence accepted");
        machine.tick(now_ms + 61'000);
        expect(machine.prepare(request(10), healthy, now_ms + 62'000) == Result::SequenceReplay,
               "duplicate sequence rejected after expiry");
    }
    {
        auto machine = prepared_machine();
        auto pressed = healthy;
        pressed.confirmation_button = true;
        expect(machine.sample_physical_confirmation(pressed, now_ms + 2'000) == Result::Accepted, "fault path commit");
        expect(machine.begin_execution() == Result::Accepted, "fault path begin");
        expect(machine.latch_fault() == Result::Accepted, "latch fault");
        expect(!machine.outputs().actuator_enable && machine.outputs().red_indicator, "fault outputs safe");
        auto reset = healthy;
        reset.reset_button = true;
        reset.fault_cause_active = true;
        expect(machine.sample_physical_reset(reset) == Result::FaultCauseActive, "active fault blocks reset");
        reset.reset_button = false;
        expect(machine.sample_physical_reset(reset) == Result::LocalResetRequired, "reset rearm");
        reset.reset_button = true;
        reset.fault_cause_active = false;
        expect(machine.sample_physical_reset(reset) == Result::Accepted, "local reset accepted");
        // CH1-AUT-FDS-0001's state diagram puts Recovery between FaultLatched and Idle,
        // and requires recovery to verify "cause removed, local authority, reset edge and
        // reconciled work-order state". The reset edge establishes the first three; until
        // the fourth is offered the cell is not Idle and no PREPARE is accepted.
        expect(machine.state() == State::Recovery, "local reset reaches Recovery, not Idle");
        expect(machine.prepare(request(2), healthy, now_ms + 3'000) == Result::StateInvalid,
               "a cell in Recovery accepts no preparation");
        expect(!machine.outputs().actuator_enable && !machine.outputs().red_indicator &&
                   machine.outputs().amber_indicator,
               "Recovery is neither energised nor reported as a latched fault nor as ready");
        expect(machine.accept_recovery(reconciliation(), healthy) == Result::Accepted, "recovery accepted");
        expect(machine.state() == State::Idle, "fault recovered to idle through Recovery");
        verification_case("CH1-VVT-TC-0019");
    }
    {
        // CH1-AUT-FDS-0001: "Recovery verifies cause removed, local authority, reset edge
        // and reconciled work-order state." The work-order half is the one a controller
        // could most easily skip, so each way of getting it wrong is refused by name and
        // leaves the cell in Recovery rather than falling through to Idle.
        auto machine = faulted_machine();
        auto reset = healthy;
        reset.reset_button = true;
        expect(machine.sample_physical_reset(reset) == Result::Accepted, "reconciliation reset");

        auto other_order = reconciliation();
        other_order.work_order_id = 999;
        expect(machine.accept_recovery(other_order, healthy) == Result::WorkOrderNotReconciled,
               "recovery onto another work order refused");
        auto other_part = reconciliation();
        other_part.part_id = 999;
        expect(machine.accept_recovery(other_part, healthy) == Result::WorkOrderNotReconciled,
               "recovery onto another part refused");
        auto other_revision = reconciliation();
        other_revision.configuration_revision = 8;
        expect(machine.accept_recovery(other_revision, healthy) == Result::RevisionMismatch,
               "recovery under another configuration revision refused");
        auto other_cell = reconciliation();
        other_cell.cell_id = 999;
        expect(machine.accept_recovery(other_cell, healthy) == Result::ScopeMismatch,
               "recovery naming another cell refused");
        auto rebooted = reconciliation();
        rebooted.controller_boot_id = 100;
        expect(machine.accept_recovery(rebooted, healthy) == Result::ControllerRestarted,
               "recovery quoting another boot identity refused");
        auto still_faulted = healthy;
        still_faulted.fault_cause_active = true;
        expect(machine.accept_recovery(reconciliation(), still_faulted) == Result::FaultCauseActive,
               "recovery while the cause is active again refused");
        auto guard_open = healthy;
        guard_open.guard_healthy = false;
        expect(machine.accept_recovery(reconciliation(), guard_open) == Result::InterlockInvalid,
               "recovery with an open guard refused");
        expect(machine.state() == State::Recovery, "every refusal left the cell in Recovery");

        expect(machine.accept_recovery(reconciliation(), healthy) == Result::Accepted,
               "reconciled recovery accepted");
        expect(machine.state() == State::Idle, "and only then Idle");
        verification_case("CH1-VVT-TC-0019");
    }
    {
        // CH1-AUT-FDS-0001's state diagram: Complete --acknowledge completion / new
        // order--> Idle. Until this transition existed a controller accepted exactly one
        // procedure per boot and answered StateInvalid to every later preparation
        // (defect 66). The acknowledgement is bound to the command it acknowledges.
        auto machine = completed_machine();
        expect(machine.state() == State::Complete, "the first procedure completed");
        expect(machine.prepare(request(2), healthy, now_ms + 4'000) == Result::StateInvalid,
               "a completed cell accepts no preparation until completion is acknowledged");

        auto misdirected = CompletionAcknowledgement{101, 1};
        expect(machine.acknowledge_completion(misdirected) == Result::ScopeMismatch,
               "an acknowledgement naming another command is refused");
        auto other_cell = CompletionAcknowledgement{100, 999};
        expect(machine.acknowledge_completion(other_cell) == Result::ScopeMismatch,
               "an acknowledgement naming another cell is refused");
        expect(machine.state() == State::Complete, "a refused acknowledgement changes nothing");

        expect(machine.acknowledge_completion(CompletionAcknowledgement{100, 1}) == Result::Accepted,
               "the bound acknowledgement is accepted");
        expect(machine.state() == State::Idle, "and the cell is Idle again");
        expect(machine.acknowledge_completion(CompletionAcknowledgement{100, 1}) == Result::StateInvalid,
               "acknowledging twice is refused");
        verification_case("CH1-VVT-TC-0011");
    }
    {
        // The whole point of the transition: a SECOND procedure runs on the same boot,
        // through the same guard, with nothing weakened. The replayed sequence is still
        // refused, so returning to Idle did not reset the anti-replay bound.
        auto machine = completed_machine();
        expect(machine.acknowledge_completion(CompletionAcknowledgement{100, 1}) == Result::Accepted,
               "first completion acknowledged");
        expect(machine.prepare(request(1), healthy, now_ms + 5'000) == Result::SequenceReplay,
               "the sequence just executed cannot be offered again after the acknowledgement");

        auto second = request(2);
        second.command_id = 300;
        second.confirmation_id = 400;
        expect(machine.prepare(second, healthy, now_ms + 5'000) == Result::Accepted, "second prepare");
        auto second_proof = proof();
        second_proof.command_id = 300;
        second_proof.confirmation_id = 400;
        expect(machine.accept_credential(second_proof, now_ms + 6'000) == Result::Accepted, "second credential");
        auto pressed = healthy;
        pressed.confirmation_button = true;
        expect(machine.sample_physical_confirmation(pressed, now_ms + 7'000) == Result::Accepted,
               "second physical edge still required and still sufficient");
        expect(machine.begin_execution() == Result::Accepted, "second execution begins");
        expect(machine.outputs().actuator_enable, "and the enable is planned for it");
        expect(machine.complete_execution() == Result::Accepted, "second execution completes");
        verification_case("CH1-VVT-TC-0012");
    }

    {
        // CH1-VVT-TC-0014: nothing but the wired button can supply the edge. Sampling
        // with the button open leaves the transaction waiting rather than committing it,
        // and there is no other input through which a remote caller could substitute.
        auto machine = prepared_machine();
        expect(machine.sample_physical_confirmation(healthy, now_ms + 2'000) == Result::PhysicalEdgeRequired,
               "no remote substitute for the local button");
        expect(machine.state() == State::AwaitButton, "still awaiting the physical edge");
        verification_case("CH1-VVT-TC-0014");
    }
    {
        // CH1-VVT-TC-0005: the credential proof is bound to the prepared command,
        // confirmation and cell; one naming another command, or one that was not
        // cryptographically verified, is refused.
        StateMachine machine{binding, 99};
        expect(machine.initialise(healthy) == Result::Accepted, "credential binding initialise");
        expect(machine.prepare(request(), healthy, now_ms) == Result::Accepted, "credential binding prepare");
        auto other = proof();
        other.command_id = 101;
        expect(machine.accept_credential(other, now_ms + 1'000) == Result::ScopeMismatch,
               "proof for another command refused");
        auto unverified = proof();
        unverified.cryptographically_verified = false;
        expect(machine.accept_credential(unverified, now_ms + 1'000) == Result::CredentialInvalid,
               "unverified proof refused");
        expect(machine.accept_credential(proof(), now_ms + 1'000) == Result::Accepted, "bound proof accepted");
        verification_case("CH1-VVT-TC-0005");
    }

    std::cout << "Cinerion firmware host tests passed.\n";
    return EXIT_SUCCESS;
}
