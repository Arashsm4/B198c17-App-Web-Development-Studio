// Pretend ESP-IDF timer for host builds. Test-only.

#pragma once

#include <cstdint>

/// Microseconds since boot. On the board this is the high-resolution timer; here it is a
/// declaration with no definition, because app_main is compiled and never linked or run.
std::int64_t esp_timer_get_time();
