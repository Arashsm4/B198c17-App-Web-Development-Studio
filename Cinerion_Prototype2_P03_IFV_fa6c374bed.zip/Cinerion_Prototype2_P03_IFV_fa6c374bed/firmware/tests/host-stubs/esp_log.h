// Pretend ESP-IDF logging so the firmware compiles on a desktop. Test-only, never shipped.

#pragma once

// Host stubs for the ESP-IDF headers firmware/esp32/main/app_main.cpp includes.
//
// These exist for ONE reason: so the entry point is compiled by a gate. Until this, nothing
// in the pipeline built app_main.cpp at all — ESP-IDF is not installed on the authoring
// workstation — so the file was checked only by a grep in scripts/check-repository-policy.mjs
// and a typo in it would have shipped. It is compiled here under the same
// -Wall -Wextra -Werror -pedantic as every other host binary.
//
// They are stubs, not an emulator, and nothing in the pipeline RUNS app_main: the loop never
// terminates and the transport does not exist here. Every decision the entry point makes is
// in cell_state_machine.cpp, conditioned_io.cpp and ch1_envelope.cpp, each host-tested
// directly. What this adds is that the glue between them has to compile.

#include <cstdio>

// The real macros are variadic and format-checked. These keep the format checking, which is
// most of what a compile is worth here, and discard the output.
#define ESP_LOGE(tag, format, ...) ((void)(tag), (void)std::snprintf(nullptr, 0, format __VA_OPT__(,) __VA_ARGS__))
#define ESP_LOGW(tag, format, ...) ((void)(tag), (void)std::snprintf(nullptr, 0, format __VA_OPT__(,) __VA_ARGS__))
#define ESP_LOGI(tag, format, ...) ((void)(tag), (void)std::snprintf(nullptr, 0, format __VA_OPT__(,) __VA_ARGS__))
#define ESP_LOGD(tag, format, ...) ((void)(tag), (void)std::snprintf(nullptr, 0, format __VA_OPT__(,) __VA_ARGS__))
