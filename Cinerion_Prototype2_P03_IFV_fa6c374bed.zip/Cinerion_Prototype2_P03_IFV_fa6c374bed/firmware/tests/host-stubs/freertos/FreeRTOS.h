// Pretend FreeRTOS header for host builds. No real time, just real enough.

#pragma once

#include <cstdint>

using TickType_t = std::uint32_t;

/// The real macro divides by portTICK_PERIOD_MS. One tick per millisecond is the
/// configuration this firmware assumes; the value is irrelevant to a compile.
#define pdMS_TO_TICKS(milliseconds) (static_cast<TickType_t>(milliseconds))
