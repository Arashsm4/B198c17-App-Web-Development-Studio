// Pretend FreeRTOS task header for host builds.

#pragma once

#include "freertos/FreeRTOS.h"

void vTaskDelay(TickType_t ticks);
