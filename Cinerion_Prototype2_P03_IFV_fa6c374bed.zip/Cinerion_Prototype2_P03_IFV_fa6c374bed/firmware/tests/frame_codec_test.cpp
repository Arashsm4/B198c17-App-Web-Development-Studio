// CH1-COM-IF-0006 host tests: the RS-485 node bus between the Arduino I/O node and the
// ESP32-S3 cell controller.
//
// The property under test is mostly negative. A frame on this link reports local input state
// and can never be a command, and until this file said so nothing did: `validate_frame`
// never read the type byte, so all 256 of them were accepted and the claim rested on nobody
// having defined a command yet.

#include "cinerion/frame_codec.hpp"

#include <array>
#include <cstdlib>
#include <iostream>
#include <vector>

using cinerion::io::FrameType;

namespace {

int failures = 0;

void check(const bool condition, const char* message) {
    if (condition) {
        std::cout << "PASS  " << message << '\n';
        return;
    }
    std::cerr << "FAIL  " << message << '\n';
    failures += 1;
}

}  // namespace

int main() {
    // -- The producer and the receiver agree, which is the whole contract. -----------------
    {
        const std::array<std::uint8_t, 2> payload{0x12, 0x34};
        std::array<std::uint8_t, 64> frame{};
        const std::size_t written =
            cinerion::io::build_frame(frame, FrameType::InputState, 42, payload);

        check(written == cinerion::io::frame_overhead + payload.size(),
              "a built frame is exactly its header, payload and CRC");
        const auto built = std::span<const std::uint8_t>(frame.data(), written);
        check(cinerion::io::validate_frame(built, 42),
              "and the receiver accepts what the node built");
        check(cinerion::io::frame_type(built) == FrameType::InputState,
              "the type survives the round trip");
        const auto read_back = cinerion::io::frame_payload(built);
        check(read_back.size() == payload.size() && read_back[0] == 0x12 && read_back[1] == 0x34,
              "and so does the payload, byte for byte");
    }

    // -- A corrupted frame is discarded rather than repaired. -------------------------------
    {
        const std::array<std::uint8_t, 2> payload{0x12, 0x34};
        std::array<std::uint8_t, 64> frame{};
        const std::size_t written =
            cinerion::io::build_frame(frame, FrameType::InputState, 42, payload);
        frame[cinerion::io::frame_header_size] ^= 0x01U;
        check(!cinerion::io::validate_frame(std::span<const std::uint8_t>(frame.data(), written), 42),
              "a single flipped payload bit fails the CRC");
    }

    // -- THE NEGATIVE PROPERTY: no frame on this link can be a command. ---------------------
    //
    // CH1-EMB-FDS-0001 gives the Arduino node no independent authority to start a procedure,
    // and CH1-SYS-CON-0001 keeps commands out of anything that stores or forwards. Both rest
    // on the type being a closed set of REPORTS, checked on both sides.
    {
        const std::array<std::uint8_t, 1> payload{0x01};
        std::array<std::uint8_t, 64> frame{};

        // The producer will not build one. 0x20 is what a "prepare" type would plausibly be
        // if somebody added one without reviewing the interface.
        check(cinerion::io::build_frame(frame, static_cast<FrameType>(0x20), 1, payload) == 0,
              "the node cannot BUILD a frame outside the closed set of report kinds");
        check(cinerion::io::build_frame(frame, static_cast<FrameType>(0x00), 1, payload) == 0,
              "nor one with a zero type");

        // And the receiver will not accept one, however it was produced — which is the half
        // that matters, because the other end of a physical link is not this code.
        bool every_foreign_type_refused = true;
        for (int type = 0; type <= 0xFF; ++type) {
            const auto candidate = static_cast<std::uint8_t>(type);
            if (cinerion::io::is_report_type(candidate)) {
                continue;
            }
            // Built by hand, because build_frame correctly refuses to make one.
            std::array<std::uint8_t, 13> forged{
                0xC1, 0xA1, 0x01, candidate, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2A, 0x77, 0, 0};
            const auto crc = cinerion::io::crc16_ccitt(std::span<const std::uint8_t>(forged.data(), 11));
            forged[11] = static_cast<std::uint8_t>(crc >> 8U);
            forged[12] = static_cast<std::uint8_t>(crc & 0xFFU);
            if (cinerion::io::validate_frame(forged, 42)) {
                std::cerr << "      accepted foreign frame type 0x" << std::hex << type << std::dec << '\n';
                every_foreign_type_refused = false;
            }
        }
        check(every_foreign_type_refused,
              "and the receiver refuses all 253 frame types the interface does not define, "
              "with a valid preamble, length, sequence and CRC");
    }

    // -- Every report kind the interface DOES define is accepted. ---------------------------
    // Otherwise the check above would pass by refusing everything, which is not a contract.
    {
        const std::array<std::uint8_t, 1> payload{0x07};
        std::array<std::uint8_t, 64> frame{};
        bool every_report_accepted = true;
        for (const FrameType type : {FrameType::InputState, FrameType::PartIdentity, FrameType::NodeStatus}) {
            const std::size_t written = cinerion::io::build_frame(frame, type, 42, payload);
            if (written == 0 ||
                !cinerion::io::validate_frame(std::span<const std::uint8_t>(frame.data(), written), 42)) {
                every_report_accepted = false;
            }
        }
        check(every_report_accepted,
              "all three declared report kinds round-trip, so the refusal above is a closed set "
              "and not a closed door");
    }

    // -- Replay and reordering. --------------------------------------------------------------
    {
        const std::array<std::uint8_t, 1> payload{0x01};
        std::array<std::uint8_t, 64> frame{};
        const std::size_t written = cinerion::io::build_frame(frame, FrameType::InputState, 41, payload);
        const auto built = std::span<const std::uint8_t>(frame.data(), written);
        check(!cinerion::io::validate_frame(built, 42),
              "a frame that does not advance the sequence is discarded, so a replay is refused");
        check(cinerion::io::validate_frame(built, 41),
              "and the same frame is accepted at the sequence it actually carries");
    }

    // -- Refused rather than truncated. -------------------------------------------------------
    {
        const std::array<std::uint8_t, 2> payload{0x12, 0x34};
        std::array<std::uint8_t, 8> tiny{};
        check(cinerion::io::build_frame(tiny, FrameType::InputState, 1, payload) == 0,
              "a frame that does not fit its buffer is refused, never truncated");

        std::vector<std::uint8_t> oversized(cinerion::io::maximum_payload + 1, 0xAA);
        std::array<std::uint8_t, 256> room{};
        check(cinerion::io::build_frame(room, FrameType::InputState, 1, oversized) == 0,
              "and a payload past the interface's bound is refused rather than split");
    }

    // -- A declared length that disagrees with the frame is refused. --------------------------
    // The length is what a reader would trust to find the CRC, so a frame whose declared and
    // actual lengths differ is the shape a parser is most easily walked off the end by.
    {
        std::array<std::uint8_t, 13> lying{
            0xC1, 0xA1, 0x01, 0x10, 0x00, 0x7F, 0x00, 0x00, 0x00, 0x2A, 0x77, 0, 0};
        const auto crc = cinerion::io::crc16_ccitt(std::span<const std::uint8_t>(lying.data(), 11));
        lying[11] = static_cast<std::uint8_t>(crc >> 8U);
        lying[12] = static_cast<std::uint8_t>(crc & 0xFFU);
        check(!cinerion::io::validate_frame(lying, 42),
              "a frame declaring 127 payload bytes and carrying one is refused");
    }

    if (failures == 0) {
        std::cout << "\nCinerion frame-codec host tests passed.\n";
        // Announced only after every assertion above has held. CH1-VVT-TC-0014 is the
        // no-remote-bypass case: this is the physical-zone half of it, where a link inside
        // the cell is shown to carry no path that could start a procedure.
        std::cout << "VERIFICATION-CASE CH1-VVT-TC-0014\n";
        return EXIT_SUCCESS;
    }

    std::cout << "\n" << failures << " check(s) failed.\n";
    return EXIT_FAILURE;
}
