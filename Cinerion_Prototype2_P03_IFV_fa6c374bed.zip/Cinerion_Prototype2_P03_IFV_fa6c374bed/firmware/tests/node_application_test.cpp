// Host tests for the Arduino I/O node's decision logic.
//
// The node is the second controller in the controlled architecture and, until now, the only
// one with no code: firmware/arduino-io held a frame codec and nothing that used it.
//
// Every property here is negative or about not losing track of something, which is what a
// secondary I/O node with no authority to start a procedure ought to be made of.

#include "cinerion/node_application.hpp"

#include <array>
#include <cstdlib>
#include <iostream>
#include <vector>

using cinerion::io::FrameType;
using cinerion::io::NodeApplication;
using cinerion::io::NodeInputs;

namespace {

int failures = 0;

void check(const bool condition, const char* message) {
    if (condition) {
        std::cout << "PASS  " << message << '\n';
        return;
    }
    std::cerr << "FAIL  " << message << '\n';
    failures += 1;
}

}  // namespace

int main() {
    // -- Every report the node composes is one the cell controller accepts. -----------------
    {
        NodeApplication node{};
        std::array<std::uint8_t, 64> frame{};
        const NodeInputs inputs{true, true, false, true};

        const std::size_t written = node.compose_input_state(frame, inputs);
        check(written > 0, "the node composes an input-state report");
        const auto built = std::span<const std::uint8_t>(frame.data(), written);
        check(cinerion::io::validate_frame(built, 1),
              "and the cell controller accepts it");
        check(cinerion::io::frame_type(built) == FrameType::InputState,
              "as an input-state report");

        const auto payload = cinerion::io::frame_payload(built);
        check(payload.size() == 1 && payload[0] == 0x0B,
              "carrying the levels it observed, packed and unjudged");
    }

    // -- The sequence always advances, which is what makes the replay check mean anything. --
    {
        NodeApplication node{};
        std::array<std::uint8_t, 64> frame{};
        const NodeInputs inputs{};

        std::uint32_t previous = 0;
        bool always_advanced = true;
        for (int report = 0; report < 8; ++report) {
            const std::uint32_t sequence = node.next_sequence();
            if (sequence <= previous) {
                always_advanced = false;
            }
            previous = sequence;
            const std::size_t written = node.compose_input_state(frame, inputs);
            if (written == 0) {
                always_advanced = false;
            }
        }
        check(always_advanced, "the sequence advances on every report and never repeats");

        // And the receiver refuses the one before it, which is the point.
        const std::size_t written = node.compose_input_state(frame, inputs);
        const auto built = std::span<const std::uint8_t>(frame.data(), written);
        check(!cinerion::io::validate_frame(built, node.next_sequence()),
              "so a frame replayed after a newer one has arrived is refused");
    }

    // -- A part identifier is never truncated. -----------------------------------------------
    //
    // The load-bearing one. A shortened UID is a VALID identifier for a different part, so a
    // node that trimmed one would attribute work, measurements and genealogy to the wrong
    // component, and every record downstream would be internally consistent and wrong.
    {
        NodeApplication node{};
        std::array<std::uint8_t, 64> frame{};

        const std::array<std::uint8_t, 7> uid{0x04, 0xA2, 0x2B, 0x1C, 0x55, 0x60, 0x80};
        const std::size_t written = node.compose_part_identity(frame, uid);
        check(written > 0, "a 7-byte ISO 14443 UID is carried");
        const auto built = std::span<const std::uint8_t>(frame.data(), written);
        check(cinerion::io::validate_frame(built, 1), "and the frame validates");
        const auto payload = cinerion::io::frame_payload(built);
        check(payload.size() == uid.size(),
              "the identifier arrives at its full length");
        bool identical = true;
        for (std::size_t index = 0; index < uid.size(); ++index) {
            if (payload[index] != uid[index]) identical = false;
        }
        check(identical, "byte for byte, with nothing dropped and nothing added");

        const std::uint32_t sequence_before = node.next_sequence();
        const std::vector<std::uint8_t> oversized(cinerion::io::maximum_part_identifier + 1, 0xAB);
        check(node.compose_part_identity(frame, oversized) == 0,
              "an identifier longer than the link can carry is REFUSED, not truncated");
        check(node.next_sequence() == sequence_before,
              "and a refused frame does not consume a sequence, so it leaves no hole a "
              "receiver would read as a lost report");
        check(node.refused() == 1, "the refusal is counted, so a misbehaving reader is visible");

        check(node.compose_part_identity(frame, std::span<const std::uint8_t>{}) == 0,
              "an empty identifier is refused: a part with no identity is not a part");
    }

    // -- The status report carries what a reader needs to spot a failing node. ---------------
    {
        NodeApplication node{};
        std::array<std::uint8_t, 64> frame{};
        const std::size_t written = node.compose_node_status(frame, 0x01020304, 0x0506);
        check(written > 0, "the node reports its own health");
        const auto built = std::span<const std::uint8_t>(frame.data(), written);
        check(cinerion::io::validate_frame(built, 1), "and the frame validates");
        const auto payload = cinerion::io::frame_payload(built);
        check(payload.size() == 6 && payload[0] == 0x01 && payload[3] == 0x04 &&
                  payload[4] == 0x05 && payload[5] == 0x06,
              "carrying uptime and the count of frames it refused, big-endian");
    }

    // -- A buffer too small refuses rather than emitting a partial frame. ---------------------
    {
        NodeApplication node{};
        std::array<std::uint8_t, 8> tiny{};
        const std::uint32_t sequence_before = node.next_sequence();
        check(node.compose_input_state(tiny, NodeInputs{}) == 0,
              "a report that does not fit its buffer is refused, never truncated");
        check(node.next_sequence() == sequence_before,
              "and that refusal consumes no sequence either");
    }

    if (failures == 0) {
        std::cout << "\nCinerion I/O node host tests passed.\n";
        return EXIT_SUCCESS;
    }

    std::cout << "\n" << failures << " check(s) failed.\n";
    return EXIT_FAILURE;
}
