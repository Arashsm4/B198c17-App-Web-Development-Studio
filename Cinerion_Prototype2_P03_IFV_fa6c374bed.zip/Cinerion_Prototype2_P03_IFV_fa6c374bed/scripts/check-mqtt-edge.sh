#!/usr/bin/env sh
# CH1-VVT-TC-0021 — "EdgeLink must support replaceable protocol adapters without changing
#                    domain or inspection logic."
# CH1-VVT-TC-0022 — "Data and command semantics remain consistent across adapters."
#
# Until now the protocol boundary had ONE operational adapter behind it and three that
# refused, which shows only that the interface was shaped around the one thing
# implementing it. This raises the real broker from the controlled compose model, runs
# EdgeLink against it in the control zone with mutual TLS, and asserts:
#
#   * the MQTT adapter passes the SAME nine conformance checks as the simulator, run by
#     the same code, with the domain unchanged between them;
#   * its capability manifest came from the device over the wire, not from the adapter;
#   * a command round trip really happened — published to the broker, received by a
#     separately-authenticated device, acknowledged, and correlated back;
#   * and the security controls CH1-COM-IF-0004/0005 name actually refuse: no
#     certificate, a foreign certificate, and a device reaching outside its own topics.
#
# Two protocol facts this depends on, both learned the hard way and both worth stating.
# The broker is on an internal network with no host port, deliberately, so every client
# here joins that network. And an unauthorised publish under MQTT 3.1.1 is silently
# acknowledged as success — only MQTT 5 answers "135 Not authorized" — so every probe
# below forces -V 5. A check that cannot see a refusal cannot report one.
#
# Usage: scripts/check-mqtt-edge.sh
set -eu

# Git Bash rewrites POSIX-looking values in arguments and the environment into Windows
# paths before docker sees them, which turns /run/secrets/mqtt/ca.crt into a path inside
# the Git installation. Harmless elsewhere.
MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

secrets="$repo_dir/infrastructure/secrets/mqtt"
network=cinerion_control
mosquitto_image=eclipse-mosquitto:2.1.2-alpine
failures=0

log() { printf '%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

if ! docker version >/dev/null 2>&1; then
  echo "check-mqtt-edge.sh: the Docker daemon is unreachable. This gate runs a real broker" >&2
  echo "and a real gateway against it; there is no meaningful way to run it without one." >&2
  exit 1
fi

log "[1/5] Laboratory PKI"
./scripts/bootstrap-mqtt-pki.sh > /dev/null
for artefact in ca.crt broker.crt broker.key edgelink.crt edgelink.key device.crt device.key; do
  [ -f "$secrets/$artefact" ] || { fail "the PKI is incomplete: $artefact is missing"; exit 1; }
done
pass "certificate authority, broker, gateway and device certificates present"

log "[2/5] Raising the broker and the gateway from the controlled compose model"
cd "$repo_dir/infrastructure"
# shellcheck disable=SC1091
[ -f .env.local ] && { set -a; . ./.env.local; set +a; }
CINERION_MQTT_HOST=mqtt
CINERION_MQTT_CLIENT_ID=ch1-edgelink
CINERION_MQTT_DEVICE_ID=CH1-DEV-CELL-0001
CINERION_MQTT_CA_CERT=/run/secrets/mqtt/ca.crt
CINERION_MQTT_CLIENT_CERT=/run/secrets/mqtt/edgelink.crt
CINERION_MQTT_CLIENT_KEY=/run/secrets/mqtt/edgelink.key
CINERION_MQTT_DEVICE_CERT=/run/secrets/mqtt/device.crt
CINERION_MQTT_DEVICE_KEY=/run/secrets/mqtt/device.key
CINERION_MQTT_DEVICE_SIMULATOR=true
CINERION_MQTT_PROJECT_ID=00000000-0000-4000-8000-000000000101
CINERION_MQTT_CELL_ID=00000000-0000-4000-8000-000000000103
CINERION_MQTT_ASSET_ID=00000000-0000-4000-8000-000000000104
export CINERION_MQTT_HOST CINERION_MQTT_CLIENT_ID CINERION_MQTT_DEVICE_ID \
  CINERION_MQTT_CA_CERT CINERION_MQTT_CLIENT_CERT CINERION_MQTT_CLIENT_KEY \
  CINERION_MQTT_DEVICE_CERT CINERION_MQTT_DEVICE_KEY CINERION_MQTT_DEVICE_SIMULATOR \
  CINERION_MQTT_PROJECT_ID CINERION_MQTT_CELL_ID CINERION_MQTT_ASSET_ID

docker compose -f compose.yaml --profile protocol-lab up -d --build --force-recreate mqtt edge-link \
  > /dev/null 2>&1
cd "$repo_dir"

# The gateway runs its conformance suites at startup and stops the host if any check
# fails, so waiting for it to still be running is itself part of the assertion.
attempt=0
until docker logs cinerion-edge-link-1 2>&1 | grep -q "CH1-ADP-MQTT-0001 ADP-09"; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 60 ] && { fail "the gateway never completed MQTT conformance"; break; }
  sleep 2
done
gateway_log=$(docker logs cinerion-edge-link-1 2>&1)

log "[3/5] The same suite, unchanged, against a second operational adapter"
simulator_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-SIM-0001 ADP-.*passed=True" || true)
mqtt_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-MQTT-0001 ADP-.*passed=True" || true)
any_failed=$(printf '%s' "$gateway_log" | grep -c "passed=False" || true)

[ "$simulator_passes" -eq 9 ] && [ "$mqtt_passes" -eq 9 ] \
  && pass "both operational adapters passed all nine checks (simulator $simulator_passes, MQTT $mqtt_passes)" \
  || fail "simulator passed $simulator_passes and MQTT passed $mqtt_passes of nine"

[ "$any_failed" -eq 0 ] \
  && pass "no conformance check failed anywhere in the gateway" \
  || fail "$any_failed conformance checks failed"

# The manifest is the sharpest of the nine: it can only have come over the wire from the
# device's own retained capability topic, published under the device's own certificate.
printf '%s' "$gateway_log" | grep -q "CH1-ADP-MQTT-0001 online as MQTT5.*MTLS-DEVICE-CERTIFICATE-TOPIC-ACL" \
  && pass "the MQTT manifest came from the device over the broker, not from the adapter" \
  || fail "the MQTT adapter did not report a device-published manifest"

# ADP-06 and ADP-07 together mean a command was published, received by a separately
# authenticated client, acknowledged, and correlated back — a real round trip.
printf '%s' "$gateway_log" | grep -q "CH1-ADP-MQTT-0001 ADP-07-NO-PHYSICAL-CLAIM passed=True: state AwaitingCredential, reason PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION" \
  && pass "a command round trip completed and the controller claimed no physical effect" \
  || fail "no acknowledged command round trip is evidenced"

# The gated adapters are registered and refusing, at runtime, on this gateway.
gated=$(printf '%s' "$gateway_log" | grep -c "gated adapter.*GATE-.*passed=True" || true)
[ "$gated" -eq 8 ] \
  && pass "OPC UA and Modbus are registered and held to the gated contract (8 checks)" \
  || fail "expected 8 gated-adapter checks, observed $gated"

log "[4/5] Attacking the transport security"
probe() {
  docker run --rm --network "$network" -v "$secrets:/c:ro" "$mosquitto_image" "$@" 2>&1
}

anonymous=$(probe mosquitto_pub -h mqtt -p 8883 -V 5 --cafile /c/ca.crt \
  -t 'ch1/v1/devices/CH1-DEV-CELL-0001/telemetry/x' -m x -q 1 || true)
printf '%s' "$anonymous" | grep -qi "connection\|error" \
  && pass "a client with no certificate cannot connect" \
  || fail "a client with no certificate was accepted: $anonymous"

# A certificate this authority never signed, with the right common name. Identity is not
# a name a client picks; it is a name this CA attested.
docker run --rm -v "$secrets:/c" alpine sh -c \
  "apk add --no-cache openssl >/dev/null 2>&1; openssl req -x509 -newkey rsa:2048 -nodes -days 1 \
   -keyout /c/rogue.key -out /c/rogue.crt -subj '/CN=CH1-DEV-CELL-0001' >/dev/null 2>&1" >/dev/null 2>&1
foreign=$(probe mosquitto_pub -h mqtt -p 8883 -V 5 --cafile /c/ca.crt --cert /c/rogue.crt --key /c/rogue.key \
  -t 'ch1/v1/devices/CH1-DEV-CELL-0001/telemetry/x' -m x -q 1 || true)
printf '%s' "$foreign" | grep -qi "connection\|error" \
  && pass "a certificate this authority never signed cannot connect, even with the right name" \
  || fail "a foreign certificate was accepted: $foreign"
rm -f "$secrets/rogue.crt" "$secrets/rogue.key"

device_certs="--cafile /c/ca.crt --cert /c/device.crt --key /c/device.key"
foreign_topic=$(probe mosquitto_pub -h mqtt -p 8883 -V 5 $device_certs \
  -t 'ch1/v1/devices/CH1-DEV-CELL-0099/telemetry/temperature' -m x -q 1 -d | grep -oE 'RC:[0-9]+' | tail -1)
[ "$foreign_topic" = "RC:135" ] \
  && pass "a device publishing into another device's telemetry is refused (135 Not authorized)" \
  || fail "publishing into another device's telemetry answered ${foreign_topic:-nothing}"

own_command=$(probe mosquitto_pub -h mqtt -p 8883 -V 5 $device_certs \
  -t 'ch1/v1/devices/CH1-DEV-CELL-0001/commands/forged' -m x -q 1 -d | grep -oE 'RC:[0-9]+' | tail -1)
[ "$own_command" = "RC:135" ] \
  && pass "a device cannot publish a command to itself; only the gateway may (135 Not authorized)" \
  || fail "a device publishing its own command answered ${own_command:-nothing}"

own_telemetry=$(probe mosquitto_pub -h mqtt -p 8883 -V 5 $device_certs \
  -t 'ch1/v1/devices/CH1-DEV-CELL-0001/telemetry/temperature' -m x -q 1 -d | grep -oE 'RC:[0-9]+' | tail -1)
[ "$own_telemetry" = "RC:0" ] || [ "$own_telemetry" = "RC:16" ] \
  && pass "its own telemetry path is still permitted, so the refusals above are about scope" \
  || fail "the device's own telemetry answered ${own_telemetry:-nothing}"

log "[5/5] Result"
echo
if [ "$failures" -eq 0 ]; then
  echo "The MQTT edge is operational and its controls refuse."
  echo "  adapters passing the same suite : simulator and MQTT 5, nine checks each"
  echo "  transport                       : TLS 1.3, mutual, identity from the certificate"
  echo "  refused                         : no certificate, a foreign certificate, and"
  echo "                                    a device reaching outside its own topics"
  echo "VERIFICATION-CASE CH1-VVT-TC-0021"
  echo "VERIFICATION-CASE CH1-VVT-TC-0022"
  exit 0
fi

echo "$failures check(s) failed. Neither case is announced."
exit 1
