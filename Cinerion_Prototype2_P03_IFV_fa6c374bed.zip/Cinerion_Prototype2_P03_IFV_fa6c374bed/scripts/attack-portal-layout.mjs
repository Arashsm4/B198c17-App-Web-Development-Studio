// Attacks the portal layout gate by putting each of today's layout bugs back, one at a
// time, in the real source - then re-rendering the real screen and asking the gate.
//
// A gate that only ever sees fixed screens has never been shown to notice anything. So:
// break it on purpose, check the gate refuses FOR THE RIGHT REASON, put it back, and check
// the file really went back. Every attack also checks its mutation changed something,
// because an attack that edits nothing passes by doing nothing (defect 75).
//
//   npm run layout:attack

import { execFile } from 'node:child_process';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const run = promisify(execFile);
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

const files = {
  appShell: 'apps/operator-portal/src/components/app-shell.tsx',
  primitives: 'apps/operator-portal/src/components/primitives.tsx',
  security: 'apps/operator-portal/src/app/security.tsx',
  actAuthority: 'apps/operator-portal/src/components/act-authority.tsx',
  resources: 'apps/operator-portal/src/app/resources.tsx',
  gate: 'scripts/check-portal-layout.mjs',
};
const originals = new Map();
for (const [key, path] of Object.entries(files)) originals.set(key, await readFile(resolve(root, path), 'utf8'));

let attacks = 0;
let holes = 0;

async function restoreAll() {
  for (const [key, path] of Object.entries(files)) await writeFile(resolve(root, path), originals.get(key), 'utf8');
}

/** Renders one scenario into a fresh snapshot folder and runs the layout gate on it. */
async function renderAndJudge(scenario) {
  const dir = await mkdtemp(join(tmpdir(), 'cinerion-layout-attack-'));
  try {
    await run(process.execPath, ['apps/operator-portal/harness/run.mjs', '--scenario', scenario], {
      cwd: root,
      env: { ...process.env, CINERION_RENDER_SNAPSHOT_DIR: dir },
      maxBuffer: 32 * 1024 * 1024,
    }).catch(() => { /* the scenario's own text checks may fail on a mutation; the snapshot is what we want */ });
    try {
      const { stdout } = await run(process.execPath, ['scripts/check-portal-layout.mjs', dir], { cwd: root, maxBuffer: 32 * 1024 * 1024 });
      return { refused: false, output: stdout };
    } catch (cause) {
      return { refused: true, output: `${cause.stdout ?? ''}${cause.stderr ?? ''}` };
    }
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/**
 * One attack. `mutations` is a list of [fileKey, (source) => newSource]. Every one of them
 * must change its file, or the attack is a hole: it would be testing nothing.
 */
async function attack(name, mutations, scenario, expectation) {
  attacks += 1;
  try {
    for (const [key, mutate] of mutations) {
      const before = originals.get(key);
      const after = mutate(before);
      if (after === before) {
        holes += 1;
        console.log(`HOLE  ${name} - the mutation to ${files[key]} changed nothing, so nothing was tested.`);
        return;
      }
      await writeFile(resolve(root, files[key]), after, 'utf8');
    }
    const result = await renderAndJudge(scenario);
    if (!result.refused) {
      holes += 1;
      console.log(`HOLE  ${name} - the gate ACCEPTED it.`);
    } else if (!result.output.includes(expectation)) {
      holes += 1;
      console.log(`HOLE  ${name} - refused, but not for the stated reason. Expected: ${expectation}`);
    } else {
      console.log(`ok    ${name}`);
    }
  } finally {
    await restoreAll();
  }
}

// The old Security aside: every role glued into one shouting pill.
const gluedPill = (source) => source.replace(
  'aside={<RoleChips roles={session.claims?.roles} />}',
  "aside={<StatusPill label={(session.claims?.roles ?? []).join(' · ').toUpperCase()} tone=\"info\" />}");

// The pill's cap on its own width. A regex, not a literal, so a CRLF file can't make this
// quietly match nothing (handover item 46).
const dropPillMaxWidth = (source) => source.replace(/( {4}alignSelf: 'flex-start',)\r?\n {4}maxWidth: '100%',/, '$1');

const SECURITY = 'security-intro-survives-every-role-the-lab-identity-holds';

console.log('Attacking the portal layout gate.\n');

// 1. The owner's screenshot, exactly: the old intro row and the old glued pill.
await attack(
  'the page intro that let a pill squash the title (the screenshot)',
  [
    ['security', gluedPill],
    ['appShell', (s) => s
      .replace("flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-end'", "flexDirection: 'row', alignItems: 'flex-end'")
      .replace('pageIntroCopy: { flexGrow: 1, flexShrink: 1, flexBasis: 420, minWidth: 260, maxWidth: 780, gap: 7 }', 'pageIntroCopy: { flex: 1, maxWidth: 780, gap: 7 }')
      .replace("{aside ? <View style={styles.pageIntroAside}>{aside}</View> : null}", '{aside}')],
    ['primitives', dropPillMaxWidth],
  ],
  SECURITY,
  'squeezed-text',
);

// 2. The pill's width cap, where it actually carries weight: a pill sitting directly in a
//    ROW (a section heading's action slot). The first version of this attack put the long
//    pill in the page intro instead - where it sits in a column, CSS already sizes it to
//    fit, the page was genuinely fine, and the gate rightly accepted it. An attack that
//    expects a correct layout to be refused is testing the attacker, not the gate.
await attack(
  'a long pill in a heading row with no cap on its width',
  [
    ['security', (s) => s.replace(
      "action={<StatusPill label={page ? `${page.count} LISTED` : 'NOT RETRIEVED'} tone={page ? 'info' : 'neutral'} />}",
      "action={<StatusPill label={'EVERY ROLE ON ONE LINE · '.repeat(12)} tone=\"info\" />}")],
    ['primitives', dropPillMaxWidth],
  ],
  SECURITY,
  'past-window',
);

// 2b. And the same long pill WITH the cap stays on screen - the control for attack 2, so
//     we know it's the cap doing the work and not something else in the row.
attacks += 1;
{
  const longPill = (s) => s.replace(
    "action={<StatusPill label={page ? `${page.count} LISTED` : 'NOT RETRIEVED'} tone={page ? 'info' : 'neutral'} />}",
    "action={<StatusPill label={'EVERY ROLE ON ONE LINE · '.repeat(12)} tone=\"info\" />}");
  const mutated = longPill(originals.get('security'));
  if (mutated === originals.get('security')) {
    holes += 1;
    console.log('HOLE  the capped long pill control changed nothing.');
  } else {
    await writeFile(resolve(root, files.security), mutated, 'utf8');
    try {
      const result = await renderAndJudge(SECURITY);
      if (result.refused) {
        holes += 1;
        console.log(`HOLE  the same long pill WITH its width cap was refused, so the cap is not what decides it:\n${result.output}`);
      } else {
        console.log('ok    the same long pill WITH its width cap stays on screen (the control for attack 2)');
      }
    } finally {
      await restoreAll();
    }
  }
}

// 3. The "another role owns this act" notice with no flex rules: it keeps its whole
//    paragraph on one line and walks off the right edge.
await attack(
  'the authority notice that would not shrink',
  [['actAuthority', (s) => s.replace(/ {4}flexGrow: 1,\r?\n {4}flexShrink: 1,\r?\n {4}flexBasis: 'auto',\r?\n {4}minWidth: 0,\r?\n/, '')]],
  SECURITY,
  'past-window',
);

// 4. The capacity bar that parked its red overshoot past the end of the track.
await attack(
  'the capacity bar whose red segment was never on screen',
  [['resources', (s) => s.replace(
    /const ratio = over\r?\n\s+\? \(committed > 0 \? Math\.max\(0, capacity\) \/ committed : 0\)\r?\n\s+: capacity <= 0 \? 0 : committed \/ capacity;\r?\n\s+const overRatio = over \? 1 - ratio : 0;/,
    'const ratio = capacity <= 0 ? (committed > 0 ? 1 : 0) : Math.min(1, committed / capacity);\n  const overRatio = over && capacity > 0 ? Math.min(1, (committed - capacity) / capacity) : 0;')]],
  'resources-board',
  'past-window',
);

// 5. The gate's own eyesight. Put back the exact flaw the first version had - "width > 0" -
//    and the positive control must catch it, because nothing else would.
await attack(
  'the squeezed-text rule blinded to zero-width boxes',
  [['gate', (s) => s.replace('if (r.width < 30 && r.height > 4 * size) {', 'if (r.width > 0 && r.width < 30 && r.height > 4 * size) {')]],
  SECURITY,
  'POSITIVE CONTROL FAILED',
);

// -- Everything back where it was? ----------------------------------------------------------

let unrestored = 0;
for (const [key, path] of Object.entries(files)) {
  if ((await readFile(resolve(root, path), 'utf8')) !== originals.get(key)) {
    unrestored += 1;
    holes += 1;
    console.log(`HOLE  ${path} was NOT restored.`);
  }
}
if (unrestored === 0) {
  attacks += 1;
  console.log(`ok    all ${Object.keys(files).length} touched files are byte-identical to how the suite found them`);
}

console.log();
if (holes > 0) {
  console.error(`Portal layout gate: ${attacks} attacks, ${holes} HOLES.`);
  process.exitCode = 1;
} else {
  console.log(`Portal layout gate: ${attacks} attacks, 0 holes.`);
}
