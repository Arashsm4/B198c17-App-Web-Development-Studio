#!/usr/bin/env sh
# Builds firmware/esp32 with the real ESP-IDF toolchain.
#
# *** DELIBERATELY NOT IN verify.sh, AND THAT IS THE POINT. ***
#
# Defect 51 was a harness that could not be run printing `SKIPPED locally` while the
# pipeline exited 0 — a gate reporting success for something that never happened. An
# optional step inside the strict pipeline is exactly that shape, so this is not one. It is
# run on demand, and on a workstation that has the toolchain; its result belongs in the
# handover as a dated observation, not in a pipeline that would quietly pass without it.
#
# What it establishes that nothing else can: `firmware/esp32/main/time_sync.cpp` is
# compiled. That file has never been built by anything. It is excluded from the host build
# for a stated reason — `esp_netif_sntp.h` is macro-heavy and a hand-written stub would let
# it compile against something the real header does not agree with, which is coverage that
# looks like coverage — so the only honest way to compile it is the real toolchain. Defect
# 33 is the precedent: `app_main.cpp` was likewise never compiled by anything, and when it
# finally was, it did not build.
#
# It also compiles the component's dependency declaration for the first time. `REQUIRES` in
# main/CMakeLists.txt names driver, esp_timer, esp_task_wdt, mqtt, esp-tls and nvs_flash;
# whether that set is sufficient for the headers the sources include is a question only a
# build can answer.
#
# This flashes nothing and drives nothing. There is no board attached and no actuator, and
# CH1-EMB-FDS-0001's P03 verification boundary defers independent review until before
# hazardous energisation.

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

# On Windows this script cannot do the job, and says so rather than reporting a missing
# toolchain. ESP-IDF's export.ps1 exposes idf.py as a POWERSHELL FUNCTION rather than as an
# executable on PATH, IDF_PATH holds a Windows path that [ -d ] cannot resolve, and
# idf_tools.py refuses MSys outright. All three were observed against a correctly installed
# ESP-IDF v6.0.3, and the preflight below then blamed the toolchain. Use the PowerShell
# sibling there; it runs the same build and checks the same object files.
case "${OS:-}${MSYSTEM:-}" in
  *Windows*|*MINGW*|*MSYS*)
    echo "ESP-IDF BUILD: NOT RUN HERE - this shell cannot drive ESP-IDF on Windows."
    echo "  export.ps1 defines idf.py as a PowerShell function, not an executable, and"
    echo "  idf_tools.py refuses MSys/Mingw outright. Run the PowerShell sibling instead:"
    echo "    . \$env:IDF_PATH\export.ps1"
    echo "    .\scripts\check-esp-idf-build.ps1"
    exit 2
    ;;
esac

if [ -z "${IDF_PATH:-}" ] || [ ! -d "${IDF_PATH:-/nonexistent}" ]; then
  echo "ESP-IDF BUILD: NOT RUN — IDF_PATH is unset or does not name a directory."
  echo "  This is a statement, not a pass. Nothing in this repository has compiled"
  echo "  firmware/esp32/main/time_sync.cpp, and this script is the only thing that can."
  echo "  Install ESP-IDF, source its export script, and run this again."
  exit 2
fi

if ! command -v idf.py >/dev/null 2>&1; then
  echo "ESP-IDF BUILD: NOT RUN — IDF_PATH is set but idf.py is not on PATH."
  echo "  Source \$IDF_PATH/export.sh first; setting IDF_PATH alone does not configure the"
  echo "  toolchain, and a build attempted without it fails for a reason that has nothing"
  echo "  to do with this firmware."
  exit 2
fi

echo "ESP-IDF at $IDF_PATH"
idf.py --version

# The target is the module the controlled pin map names. Stated here rather than left to
# whatever a stale sdkconfig holds: firmware/pinmap/esp32s3-r01.json is the
# hardware-revision-controlled derivative of the controlled I/O table, and a build for
# another target would be a build of different code.
echo "Target: esp32s3, from the controlled pin map's module"
idf.py -C firmware/esp32 set-target esp32s3
idf.py -C firmware/esp32 build

echo
echo "ESP-IDF BUILD: COMPLETED."
echo "  Compiled, and NOT flashed, NOT linked against a board, NOT run. No hardware is"
echo "  attached. What this establishes is that the component builds with the real headers"
echo "  — including time_sync.cpp, which nothing had ever compiled — and that its REQUIRES"
echo "  set is sufficient for the headers its sources include."
echo "  It establishes nothing about behaviour on the board. CH1-VVT-HIL-0001's cases still"
echo "  need the rig, and CH1-EMB-FDS-0001 defers independent review until before hazardous"
echo "  energisation."
