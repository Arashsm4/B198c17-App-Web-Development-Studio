#!/usr/bin/env sh
# CH1-DBA-DD-0001 — telemetry retention, downsampling and authorised disposal.
#
#   "High-rate telemetry enters a bounded pipeline with freshness and quality, then is
#    retained raw or aggregated according to declared need. Critical events and acceptance
#    measurements are never lost through telemetry downsampling. Retention is based on
#    evidence, legal and project needs; deletion is authorised, logged and compatible with
#    immutable-release obligations."
#
# Nothing implemented any of it: raw samples accumulated forever, and the entity register's
# "Configurable; summary permanent" had no summary behind it. This runs the real thing
# against a real database and then attacks it:
#
#   1. a database is raised, every controlled migration applied, and Control Core run
#      against it with the simulated cell feeding the ORDINARY ingestion path, so the
#      samples are real records rather than rows somebody inserted;
#   2. a controlled measurement is produced through the ordinary API;
#   3. the samples are aged. This is the one fixture: the clock is moved, not the data,
#      because a seven-day floor cannot be exercised in a gate that runs in minutes;
#   4. two protections are set up - an alarm bracketing part of the aged window, and a
#      sample aligned to the measurement's own source sample time;
#   5. disposal is refused for every reason it should be: no authoriser, no reason, a
#      window under the floor, the wrong project, and the wrong database role;
#   6. disposal runs, and the counts are checked against the database rather than believed;
#   7. what survived is checked: the alarm's evidence, the measurement's sample, the alarm
#      itself, the measurement itself, and the audit chain;
#   8. every deleted sample is shown to be represented by a permanent hourly summary, and
#      the summary is shown to be immutable;
#   9. the retention role is attacked directly - it must not be able to delete an alarm, a
#      measurement or an audit event, whatever the procedure does.
#
# It announces NO controlled verification case. data/tests.json contains none for retention
# or disposal, which is recorded as a conflict rather than papered over by binding this to a
# case about something else.
#
# Usage: scripts/check-telemetry-retention.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

image=postgres:18.4-alpine3.24
container=cinerion-retention-verify
db_port=55442
# Kestrel is told to take any free port. A fixed one is not safe on Windows: Hyper-V
# reserves large blocks of the 5000-5700 range at boot, a bind into one of them fails
# with SocketException 10013, and the excluded ranges move between reboots. Dynamic
# binding is refused on the "localhost" name - Kestrel requires the literal - so the
# service BINDS 127.0.0.1 and is ADDRESSED as localhost, because AllowedHosts=localhost
# answers the literal with 400.
api_url=""
work_dir="$repo_dir/artifacts/retention-verification"
owner_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
app_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
retention_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)

project_id=00000000-0000-4000-8000-000000000101
other_project_id=00000000-0000-4000-8000-000000000201
cell_id=00000000-0000-4000-8000-000000000103
part_id=00000000-0000-4000-8000-000000000106

api_pid=""
failures=0

log() { printf '%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

cleanup() {
  [ -n "$api_pid" ] && kill "$api_pid" 2>/dev/null || true
  docker rm -f "$container" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

if ! docker version >/dev/null 2>&1; then
  echo "check-telemetry-retention.sh: the Docker daemon is unreachable. This gate disposes of" >&2
  echo "real telemetry in a real database; there is no meaningful way to run it without one." >&2
  exit 1
fi

# As the owner: fixtures and observations only. Everything the procedure itself does runs
# as cinerion_retention.
sql() { docker exec "$container" psql -U cinerion_owner -d cinerion -tAc "$1" | tr -d ' \r'; }

# The same, but preserving internal spaces. A timestamp read through sql() above arrives as
# "2026-07-1710:24:05" with the space stripped out, and PostgreSQL then rejects it as a
# date out of range — which is how both protections in step [3] silently failed to be set up
# the first time this gate ran, while the disposal below quite correctly took everything.
value() {
  docker exec "$container" psql -U cinerion_owner -d cinerion -tAc "$1" \
    | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'
}

# As the retention role, over TCP, so its grants and row-level security actually apply.
retention_sql() {
  docker exec -e PGPASSWORD="$retention_password" "$container" \
    psql -h 127.0.0.1 -U cinerion_retention -d cinerion -tAc "$1" 2>&1 | tr -d '\r'
}

json() { node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{try{const v=JSON.parse(s);const r=$1;console.log(r===undefined||r===null?'':r)}catch{console.log('')}})"; }

call() {
  method=$1; path=$2; body=${3:-}
  if [ -n "$body" ]; then
    curl --silent --show-error --request "$method" \
      -H "X-CH1-Actor: USR-RETENTION-VERIFY" -H "X-CH1-Project: $project_id" \
      -H "X-CH1-Roles: Engineer,Inspector,Auditor,ProjectManager" -H "X-CH1-Cells: $cell_id" \
      -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-retention" \
      -H "Content-Type: application/json" --data "$body" "$api_url$path"
  else
    curl --silent --show-error --request "$method" \
      -H "X-CH1-Actor: USR-RETENTION-VERIFY" -H "X-CH1-Project: $project_id" \
      -H "X-CH1-Roles: Engineer,Inspector,Auditor,ProjectManager" -H "X-CH1-Cells: $cell_id" \
      -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-retention" \
      "$api_url$path"
  fi
}

rm -rf "$work_dir"
mkdir -p "$work_dir"

# --------------------------------------------------------------------------------------

log "[1/9] Raising a database and applying every controlled migration"
docker rm -f "$container" >/dev/null 2>&1 || true
docker run -d --name "$container" \
  -e POSTGRES_DB=cinerion -e POSTGRES_USER=cinerion_owner -e POSTGRES_PASSWORD="$owner_password" \
  -p "127.0.0.1:$db_port:5432" "$image" >/dev/null

attempt=0
settled=0
while [ "$settled" -lt 3 ]; do
  if docker exec "$container" psql -U cinerion_owner -d cinerion -tAc "select 1" >/dev/null 2>&1; then
    settled=$((settled + 1))
  else
    settled=0
  fi
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "the database did not become ready"; exit 1; }
  sleep 1
done

for migration in services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/*.sql; do
  docker exec -i "$container" psql -U cinerion_owner -d cinerion --set ON_ERROR_STOP=on --quiet \
    < "$migration" > /dev/null
done
docker exec "$container" psql -U cinerion_owner -d cinerion -qc \
  "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password'; ALTER ROLE cinerion_retention LOGIN PASSWORD '$retention_password';" > /dev/null
pass "$(sql "select count(*) from information_schema.tables where table_schema='ch1'") controlled tables, including telemetry_summaries and telemetry_disposals"

log "[2/9] Producing real telemetry through the ordinary ingestion path"
CINERION_DATABASE_MODE=Postgres \
CINERION_POSTGRES_CONNECTION="Host=127.0.0.1;Port=$db_port;Database=cinerion;Username=cinerion_app;Password=$app_password" \
CINERION_ALLOW_DEVELOPMENT_IDENTITY=true \
CINERION_RUNTIME_PROFILE=Simulation \
CINERION_SIMULATED_TELEMETRY=true \
ASPNETCORE_ENVIRONMENT=Development \
  dotnet run --project services/control-core/src/Cinerion.Api \
  --no-launch-profile --urls "http://127.0.0.1:0" > "$work_dir/api.log" 2>&1 &
api_pid=$!
attempt=0
while [ -z "$api_url" ]; do
  api_port=$(sed -n 's|.*Now listening on: http://127\.0\.0\.1:\([0-9][0-9]*\).*|\1|p' "$work_dir/api.log" | head -1)
  [ -n "$api_port" ] && api_url="http://localhost:$api_port"
  [ -n "$api_url" ] && break
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "Control Core never reported a listening address"; tail -20 "$work_dir/api.log" >&2; exit 1; }
  sleep 1
done
log "Control Core is listening on $api_url"
attempt=0
until curl --silent --fail --max-time 2 "$api_url/api/v1/system/health" >/dev/null 2>&1; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "Control Core did not start"; tail -20 "$work_dir/api.log" >&2; exit 1; }
  sleep 1
done

# The simulated source publishes every 5 s through device trust, cell assignment and the
# channel allowlist, exactly as a gateway does.
sleep 25

run_id=$(call POST /api/v1/test-runs \
  "{\"partId\":\"$part_id\",\"procedureId\":\"CH1-REFAB-PROC-0001\",\"procedureRevision\":\"R01\"}" \
  | json "v.testRunId")
call POST "/api/v1/test-runs/$run_id/measurements" \
  "{\"partId\":\"$part_id\",\"characteristic\":\"Coating thickness\",\"value\":10.1,\"unit\":\"um\",\"lowerLimit\":9.5,\"upperLimit\":10.5,\"mandatory\":true,\"sourceDeviceId\":\"CH1-INS-THK-0001\",\"calibrationRecordId\":\"00000000-0000-4000-8000-000000000108\",\"calibrationValid\":true}" \
  > /dev/null

kill "$api_pid" 2>/dev/null || true
api_pid=""
sleep 3

raw_before=$(sql "select count(*) from ch1.telemetry_samples")
measurements_before=$(sql "select count(*) from ch1.measurements")
audit_before=$(sql "select count(*) from ch1.audit_events")
if [ "$raw_before" -lt 10 ] || [ "$measurements_before" -lt 1 ]; then
  fail "the database holds $raw_before samples and $measurements_before measurements; there is nothing to dispose of and every check below would pass for the wrong reason"
  exit 1
fi
pass "$raw_before telemetry samples and $measurements_before measurements are in the database, written by the service"

log "[3/9] Ageing the samples, and setting up the two protections"
# The one fixture in this gate, and it is the clock rather than the data: the retention
# floor is seven days and this runs in minutes. Every sample below was produced by the
# service through the ordinary path; only sampled_at is moved.
sql "UPDATE ch1.telemetry_samples SET sampled_at = sampled_at - interval '30 days'" > /dev/null

# A critical event: an alarm bracketing the oldest third of the aged window on the device
# that produced the samples. The alarm-raising path itself is verified elsewhere; what is
# under test here is that disposal will not remove the samples that evidence one.
alarm_from=$(value "select min(sampled_at) from ch1.telemetry_samples")
alarm_to=$(value "select min(sampled_at) + interval '20 seconds' from ch1.telemetry_samples")
sql "INSERT INTO ch1.alarms (alarm_id, project_id, cell_id, source_id, alarm_code, priority, state, activated_at, cleared_at, cause_clear)
     VALUES (gen_random_uuid(), '$project_id', '$cell_id', 'CH1-DEV-CELL-0001', 'CH1-ALM-TEMP-HIGH', 3, 'Cleared', '$alarm_from', '$alarm_to', true)" > /dev/null

# An acceptance measurement: the controlled record already exists, produced through the
# ordinary API against a real instrument and a real calibration record, and it is immutable
# — ch1.measurements refuses UPDATE, so nothing here can bend the measurement to fit. Its
# own source device and source sample time are what identify the raw sample behind it, so
# one aged sample is moved onto them.
# The measurement's own source sample time is "now", so a sample aligned to it would be
# newer than any cutoff and would survive on age rather than on protection. Attacking this
# gate found exactly that: with both protections removed the measurement's sample still
# survived, which would have made that check pass for the wrong reason forever. The
# measurement is aged with the samples — the clock again, not the data — and the immutability
# trigger is put back and asserted, because a fixture that left controlled evidence editable
# would be worse than the hole it closed.
sql "ALTER TABLE ch1.measurements DISABLE TRIGGER USER" > /dev/null
sql "UPDATE ch1.measurements SET source_sample_time = source_sample_time - interval '30 days'" > /dev/null
sql "ALTER TABLE ch1.measurements ENABLE TRIGGER USER" > /dev/null
still_immutable=$(sql "update ch1.measurements set value = 0" 2>&1 || true)
printf '%s' "$still_immutable" | grep -qi "immutable evidence"   || { fail "the measurement immutability trigger was left disabled by the fixture"; exit 1; }

measurement_device=$(value "select source_device_id from ch1.measurements limit 1")
measurement_time=$(value "select source_sample_time from ch1.measurements limit 1")
# The instrument is a measurement source rather than a telemetry publisher, so it may not
# be in ch1.devices; telemetry carries a foreign key to it. Stated as a fixture.
sql "INSERT INTO ch1.devices (device_id, project_id, cell_id, device_type, firmware_version,
        configuration_revision, trust_state, capability_manifest)
     VALUES ('$measurement_device', '$project_id', '$cell_id', 'Instrument', '0.0.0', 'CFG-REFAB-P01-R01',
             'Trusted', '{}'::jsonb)
     ON CONFLICT (device_id) DO NOTHING" > /dev/null
measurement_sample=$(value "select sample_id from ch1.telemetry_samples order by sampled_at desc limit 1")
sql "UPDATE ch1.telemetry_samples SET device_id = '$measurement_device', sampled_at = '$measurement_time'
     WHERE sample_id = '$measurement_sample'" > /dev/null

alarms_seeded=$(sql "select count(*) from ch1.alarms")
[ "$alarms_seeded" = "1" ] || { fail "the alarm fixture was not created, so the protection could not be set up"; exit 1; }

alarm_evidence=$(sql "select count(*) from ch1.telemetry_samples s join ch1.alarms a
    on a.project_id = s.project_id and a.cell_id = s.cell_id and a.source_id = s.device_id
   where s.sampled_at >= a.activated_at and s.sampled_at <= coalesce(a.cleared_at, s.sampled_at)")
# Both protected sets must be OLDER than the cutoff a seven-day window produces, or they
# survive on age and the protections are never exercised at all. Attacking this gate found
# exactly that: with both protections removed from the procedure, the measurement's sample
# still survived, because its source sample time was "now". That check would have passed
# for the wrong reason indefinitely.
protected_and_old=$(sql "select count(*) from ch1.telemetry_samples s
   where s.sampled_at < clock_timestamp() - interval '7 days'
     and (exists (select 1 from ch1.alarms a where a.project_id = s.project_id
                    and a.cell_id = s.cell_id and a.source_id = s.device_id
                    and s.sampled_at >= a.activated_at
                    and s.sampled_at <= coalesce(a.cleared_at, s.sampled_at))
       or exists (select 1 from ch1.measurements m where m.project_id = s.project_id
                    and m.source_device_id = s.device_id
                    and m.source_sample_time = s.sampled_at))")
[ "$alarm_evidence" -gt 0 ] && [ "$protected_and_old" -gt "$alarm_evidence" ] \
  && pass "$alarm_evidence samples lie inside the alarm's window and one more is the measurement's own; all $protected_and_old are older than the cutoff, so only the protection can save them" \
  || fail "the protected samples are not all older than the cutoff ($protected_and_old older, $alarm_evidence in the alarm window): they would survive on age and the protection would never be exercised"

log "[4/9] Disposal refuses every way it should"
refused() {
  observed=$(retention_sql "SET ch1.project_id = '$2'; SELECT * FROM ch1.dispose_telemetry($3);")
  printf '%s' "$observed" | grep -qi "$4" \
    && pass "$1" \
    || fail "$1 — observed: $(printf '%s' "$observed" | tr '\n' ' ' | cut -c1-160)"
}

refused "a window under the seven-day floor is refused" "$project_id" \
  "'$project_id'::uuid, 1, 'ops', 'too short'" "at least 7 days"
refused "an unnamed authoriser is refused" "$project_id" \
  "'$project_id'::uuid, 30, '   ', 'no name'" "named authoriser"
refused "a disposal with no reason is refused" "$project_id" \
  "'$project_id'::uuid, 30, 'ops', ''" "named authoriser"
refused "a project other than the session's is refused" "$project_id" \
  "'$other_project_id'::uuid, 30, 'ops', 'wrong project'" "scoped to the session project"

# The application role must not be able to do this at all.
app_attempt=$(docker exec -e PGPASSWORD="$app_password" "$container" \
  psql -h 127.0.0.1 -U cinerion_app -d cinerion -tAc \
  "SET ch1.project_id = '$project_id'; SELECT * FROM ch1.dispose_telemetry('$project_id'::uuid, 30, 'app', 'attempt');" 2>&1 || true)
printf '%s' "$app_attempt" | grep -qi "permission denied" \
  && pass "the application role cannot execute the disposal procedure at all" \
  || fail "the application role was permitted to dispose of telemetry: $(printf '%s' "$app_attempt" | tr '\n' ' ' | cut -c1-160)"

app_delete=$(docker exec -e PGPASSWORD="$app_password" "$container" \
  psql -h 127.0.0.1 -U cinerion_app -d cinerion -tAc \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.telemetry_samples;" 2>&1 || true)
printf '%s' "$app_delete" | grep -qi "permission denied" \
  && pass "the application role cannot delete telemetry directly either" \
  || fail "the application role deleted telemetry with no authorisation and no record: $(printf '%s' "$app_delete" | tr '\n' ' ' | cut -c1-160)"

log "[5/9] The authorised disposal"
result=$(retention_sql "SET ch1.project_id = '$project_id';
  SELECT samples_summarised || '|' || samples_deleted || '|' || samples_retained_as_evidence || '|' || buckets_written
  FROM ch1.dispose_telemetry('$project_id'::uuid, 7, 'USR-RETENTION-VERIFY', 'CH1-DBA-DD-0001 scheduled disposal');" \
  | tail -1)
summarised=$(printf '%s' "$result" | cut -d'|' -f1)
deleted=$(printf '%s' "$result" | cut -d'|' -f2)
protected=$(printf '%s' "$result" | cut -d'|' -f3)
buckets=$(printf '%s' "$result" | cut -d'|' -f4)

[ -n "$deleted" ] && [ "$deleted" -gt 0 ] \
  && pass "disposal removed $deleted samples, retained $protected as evidence, and wrote $buckets permanent summaries" \
  || fail "disposal deleted nothing, so nothing below would mean anything (result: $result)"

raw_after=$(sql "select count(*) from ch1.telemetry_samples")
[ "$raw_after" = "$((raw_before - deleted))" ] \
  && pass "the database agrees with the disposal record: $raw_before - $deleted = $raw_after" \
  || fail "the disposal reported $deleted deleted but the database went from $raw_before to $raw_after"

log "[6/9] What survived, and why"
alarm_evidence_after=$(sql "select count(*) from ch1.telemetry_samples s join ch1.alarms a
    on a.project_id = s.project_id and a.cell_id = s.cell_id and a.source_id = s.device_id
   where s.sampled_at >= a.activated_at and s.sampled_at <= coalesce(a.cleared_at, s.sampled_at)")
[ "$alarm_evidence_after" = "$alarm_evidence" ] \
  && pass "every sample inside the alarm's window survived: $alarm_evidence_after of $alarm_evidence" \
  || fail "the alarm's evidence was disposed of: $alarm_evidence_after of $alarm_evidence remain"

measurement_evidence=$(sql "select count(*) from ch1.telemetry_samples s join ch1.measurements m
   on m.project_id = s.project_id and m.source_device_id = s.device_id and m.source_sample_time = s.sampled_at")
[ "$measurement_evidence" -gt 0 ] \
  && pass "the sample the acceptance measurement was taken from survived" \
  || fail "the acceptance measurement's raw sample was disposed of"

alarms_after=$(sql "select count(*) from ch1.alarms")
measurements_after=$(sql "select count(*) from ch1.measurements")
audit_after=$(sql "select count(*) from ch1.audit_events")
[ "$measurements_after" = "$measurements_before" ] && [ "$audit_after" = "$audit_before" ] && [ "$alarms_after" = "$alarms_seeded" ] \
  && pass "disposal touched nothing else: $alarms_after alarm, $measurements_after measurements, $audit_after audit events, all unchanged" \
  || fail "disposal changed records outside telemetry: alarms $alarms_after, measurements $measurements_after (was $measurements_before), audit $audit_after (was $audit_before)"

log "[7/9] Nothing disappeared without a permanent summary standing in for it"
orphans=$(sql "select count(*) from ch1.telemetry_summaries")
[ "$orphans" -gt 0 ] \
  && pass "$orphans hourly summaries written, each carrying count, minimum, maximum, average and the worst quality and freshness in its bucket" \
  || fail "no summary was written, so the deleted samples left no aggregate"

summarised_total=$(sql "select coalesce(sum(sample_count), 0) from ch1.telemetry_summaries")
[ "$summarised_total" -ge "$deleted" ] \
  && pass "the summaries account for $summarised_total samples, at least the $deleted that were deleted" \
  || fail "the summaries account for $summarised_total samples but $deleted were deleted"

worst=$(sql "select count(*) from ch1.telemetry_summaries where worst_freshness <> 'Simulated'")
[ "$worst" = "0" ] \
  && pass "every summary reports the worst freshness in its bucket — Simulated, never upgraded to Live" \
  || fail "$worst summaries report a freshness the raw samples did not have"

summary_update=$(sql "update ch1.telemetry_summaries set average = 0" 2>&1 || true)
printf '%s' "$summary_update" | grep -qi "immutable evidence" \
  && pass "a summary cannot be rewritten after the raw rows behind it are gone" \
  || fail "a permanent summary was editable: $summary_update"

disposal_update=$(sql "update ch1.telemetry_disposals set authorised_by = 'somebody else'" 2>&1 || true)
printf '%s' "$disposal_update" | grep -qi "immutable evidence" \
  && pass "the disposal record is append-only, so the authorisation cannot be rewritten afterwards" \
  || fail "a disposal record was editable: $disposal_update"

log "[8/9] Attacking the retention role directly"
for target in alarms measurements audit_events release_records; do
  attempt=$(retention_sql "SET ch1.project_id = '$project_id'; DELETE FROM ch1.$target;")
  printf '%s' "$attempt" | grep -qi "permission denied" \
    && pass "the retention role cannot delete from ch1.$target" \
    || fail "the retention role deleted from ch1.$target: $(printf '%s' "$attempt" | tr '\n' ' ' | cut -c1-120)"
done

bypass=$(sql "select rolsuper or rolbypassrls from pg_roles where rolname = 'cinerion_retention'")
[ "$bypass" = "f" ] \
  && pass "the retention role is neither a superuser nor able to bypass row-level security" \
  || fail "the retention role bypasses row-level security, so project isolation does not apply to a disposal"

log "[9/9] A second run is not a second disposal"
second=$(retention_sql "SET ch1.project_id = '$project_id';
  SELECT samples_deleted FROM ch1.dispose_telemetry('$project_id'::uuid, 7, 'USR-RETENTION-VERIFY', 'CH1-DBA-DD-0001 repeat');" \
  | tail -1)
summaries_after=$(sql "select count(*) from ch1.telemetry_summaries")
[ "$second" = "0" ] && [ "$summaries_after" = "$orphans" ] \
  && pass "re-running deleted 0 further samples and wrote no duplicate summary; what is left is evidence, not backlog" \
  || fail "a repeat run deleted $second more samples and left $summaries_after summaries (was $orphans)"

disposals=$(sql "select count(*) from ch1.telemetry_disposals")
[ "$disposals" = "2" ] \
  && pass "both disposals are logged with their authoriser, reason, window and counts" \
  || fail "expected 2 disposal records, observed $disposals"

echo
if [ "$failures" -eq 0 ]; then
  echo "Telemetry retention is executed, authorised and logged."
  echo "  disposed        : $deleted raw samples, older than the declared window"
  echo "  retained        : $protected as evidence for an alarm or an acceptance measurement"
  echo "  summarised      : $orphans permanent hourly buckets covering $summarised_total samples"
  echo "  refused         : an unnamed authoriser, no reason, a window under the floor, another"
  echo "                    project, the application role, and every table but telemetry"
  echo
  echo "This gate announces no controlled verification case, and that is a finding rather than"
  echo "an omission: CH1-DBA-DD-0001 states the retention obligation and the entity register"
  echo "states TelemetrySample's retention, but data/tests.json contains no case for either."
  echo "Binding this evidence to an unrelated case would be the overstatement the verification"
  echo "map exists to prevent. Recorded as a conflict for the owner."
  exit 0
fi

echo "$failures check(s) failed."
exit 1
