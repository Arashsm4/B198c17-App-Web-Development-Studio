// Reconciles traceability/verification-map.json with the frozen baseline, and with the
// harnesses that announce their own bindings when they run.
//
// CH1-VVT-VMP-0001 gives every baseline requirement a primary case and asks for
// identified evidence per case. The requirement half has been machine-checked since
// traceability/implementation-map.json existed. The case half had not been: nothing
// stated how many of the 87 controlled cases had an executable form, and nothing failed
// when a case had none. This closes that, and refuses the two ways such a record rots -
// claiming evidence that does not exist, and quietly dropping a case.
//
// The .NET half is reconciled inside each test assembly by VerificationBindingTests,
// because attributes on loaded types prove a test exists where a source scan would only
// prove a string is present in a file. The harnesses below cannot do that, so each one
// prints the cases it covers only after its own checks have held, and this gate reads
// those lines from an actual run.

import { exec } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const run = promisify(exec);
const errors = [];
const strict = process.argv.includes('--strict') || process.env.CI === 'true';

const load = async (path) => JSON.parse(await readFile(resolve(root, path), 'utf8'));
const baseline = await load('docs/baseline/P03_IFV/data/tests.json');
const requirements = await load('docs/baseline/P03_IFV/data/requirements.json');
const map = await load('traceability/verification-map.json');

const CASE_PATTERN = /CH1-VVT-TC-\d{4}/g;
const statuses = new Set(Object.keys(map.executionStatuses ?? {}));
const harnesses = new Set(Object.keys(map.harnesses ?? {}));
const baselineById = new Map(baseline.map((row) => [row[0], { title: row[1], level: row[2], expected: row[4] }]));

// -- 1. The map covers the controlled case list exactly, and does not paraphrase it. --

if (map.project !== 'Cinerion' || map.namespace !== 'CH1' || map.governingBaseline !== 'P03/IFV') {
  errors.push('Verification map identity must remain Cinerion / CH1 / P03/IFV.');
}

const seen = new Set();
for (const entry of map.cases ?? []) {
  const { testCaseId } = entry;
  if (seen.has(testCaseId)) errors.push(`Duplicate case in the verification map: ${testCaseId}`);
  seen.add(testCaseId);

  const controlled = baselineById.get(testCaseId);
  if (!controlled) {
    errors.push(`Verification map contains a case the baseline does not: ${testCaseId}`);
    continue;
  }
  if (entry.title !== controlled.title) errors.push(`Title drift for ${testCaseId}.`);
  if (entry.level !== controlled.level) errors.push(`Level drift for ${testCaseId}.`);
  if (entry.expected !== controlled.expected) errors.push(`Expected-result drift for ${testCaseId}.`);

  if (!statuses.has(entry.executionStatus)) {
    errors.push(`${testCaseId} has status "${entry.executionStatus}", which the map does not define.`);
  }
  if (!Array.isArray(entry.bindings)) {
    errors.push(`${testCaseId} declares no bindings array.`);
  } else {
    for (const binding of entry.bindings) {
      if (!harnesses.has(binding)) errors.push(`${testCaseId} names an undeclared harness: ${binding}`);
    }
  }
  if (!entry.note || entry.note.length < 40) {
    errors.push(`${testCaseId} has no note. Every case must say what is exercised and what is not.`);
  }

  // A status has to match the evidence. "automated" without a binding is a claim with
  // nothing behind it; a case declared hardware-gated, deferred or unexecuted while
  // tests bind to it is a record that understates what exists.
  if (entry.executionStatus === 'automated' && (entry.bindings?.length ?? 0) === 0) {
    errors.push(`${testCaseId} is recorded as automated but binds no harness.`);
  }
  if (['hardware_gated', 'future_controlled_phase', 'not_executed'].includes(entry.executionStatus)
      && (entry.bindings?.length ?? 0) > 0) {
    errors.push(
      `${testCaseId} is recorded as ${entry.executionStatus} but binds ${entry.bindings.join(', ')}. ` +
      'A case with executable evidence is at least partially automated.');
  }
}

for (const [testCaseId] of baselineById) {
  if (!seen.has(testCaseId)) errors.push(`Controlled case is absent from the verification map: ${testCaseId}`);
}
if (map.testCaseCount !== baseline.length || seen.size !== baseline.length) {
  errors.push(`Case count mismatch: declared ${map.testCaseCount}, mapped ${seen.size}, controlled ${baseline.length}.`);
}

// Every requirement's primary case must be one the map carries, so the two traceability
// records cannot drift apart.
for (const requirement of requirements) {
  if (!seen.has(requirement.test_case)) {
    errors.push(`${requirement.id} names primary case ${requirement.test_case}, which the verification map lacks.`);
  }
}

// -- 2. The announcing harnesses are run, and their bindings compared with the map. ---

const declaredFor = (harness) => new Set(
  (map.cases ?? []).filter((entry) => entry.bindings?.includes(harness)).map((entry) => entry.testCaseId));

async function observe(command, { cwd = root } = {}) {
  try {
    const { stdout, stderr } = await run(command, { cwd, maxBuffer: 32 * 1024 * 1024 });
    return `${stdout}\n${stderr}`;
  } catch (error) {
    // A harness that fails is not a harness whose bindings can be believed.
    throw new Error(`${command} failed: ${(error.stdout || '') + (error.stderr || error.message)}`);
  }
}

const observations = [
  {
    harness: 'state-model',
    // The reporter prints one line per passing test, so a case named by a test that
    // failed or never ran is not observed.
    command: 'node --experimental-strip-types --test --test-reporter=tap test/*.test.ts',
    cwd: resolve(root, 'simulators/state-model'),
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => /^ok \d+ - /.test(line))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    harness: 'firmware-host',
    command: process.platform === 'win32'
      ? 'artifacts\\host-tests\\cell_state_machine_test.exe'
      : './artifacts/host-tests/cell_state_machine_test',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // CH1-COM-IF-0006, the RS-485 node bus. Its own harness for the same reason as
    // `firmware-io`: a separate binary announcing a separate case, and folding it into
    // another one would let either binary's silence be covered by the other's output.
    harness: 'firmware-frame',
    command: process.platform === 'win32'
      ? 'artifacts\\host-tests\\frame_codec_test.exe'
      : './artifacts/host-tests/frame_codec_test',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // The conditioned I/O layer. A separate harness from `firmware-host` because it is a
    // separate binary announcing separate cases, and folding it into that one would let
    // either binary's silence be covered by the other's output.
    harness: 'firmware-io',
    command: process.platform === 'win32'
      ? 'artifacts\\host-tests\\conditioned_io_test.exe'
      : './artifacts/host-tests/conditioned_io_test',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Built by verify.sh step [9/14], like the other host binaries. It announces its case
    // only after the firmware's encoding of the CH1 envelope matches, byte for byte, what
    // the gateway produces for the same message.
    harness: 'firmware-envelope',
    command: process.platform === 'win32'
      ? 'artifacts\\host-tests\\ch1_envelope_test.exe'
      : './artifacts/host-tests/ch1_envelope_test',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // The controlled SCL cannot be executed here, so this runs the faithful translation
    // of it in plc/host-model. scripts/check-plc-model.mjs is what stops that translation
    // from drifting; this is what stops the scenarios from going unexecuted.
    harness: 'plc-scenarios',
    command: process.platform === 'win32'
      ? 'artifacts\\host-tests\\plc_scenario_test.exe'
      : './artifacts/host-tests/plc_scenario_test',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    harness: 'policy-gate',
    command: 'node scripts/check-repository-policy.mjs',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // CH1-VVT-TC-0066's second binding. `policy-gate` proves no AI ROLE exists; this one
    // proves no AI CLIENT, host, model identifier, credential, actor kind, realm identity
    // or architecture component does either, over the whole deployable tree. Kept a
    // separate harness rather than folded into the policy gate for the reason recorded on
    // `firmware-io`: one harness's silence must not be covered by another's output.
    harness: 'ai-prohibition',
    command: 'node scripts/check-ai-authority-prohibition.mjs',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // CH1-VVT-TC-0080's portal half. `offline-workflow` drives the controlled demonstration
    // on a network proven to have no route out, and covers the SERVICE; a browser is a
    // general-purpose fetching machine, and a font declaration or a redirect through a
    // hosted auth proxy is an egress no server-side test would see. Reads the EXPORTED
    // bundle, so it must run after step [8/14] has produced one - which is the same
    // ordering constraint item 32(d) records for `artifacts/` and the .NET step.
    harness: 'portal-egress',
    command: 'node scripts/check-portal-egress.mjs',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    harness: 'baseline-gate',
    command: 'node scripts/check-baseline-integrity.mjs',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Heavier than the others by far: two PostgreSQL containers and two service starts.
    // It is still run here rather than left to a separate command, because a binding no
    // harness verifies is exactly the hole this gate exists to close, and a case bound to
    // a harness nobody runs is indistinguishable from one with no evidence at all. The
    // strict/soft split below already says the right thing about it — skippable while
    // working, mandatory in CI.
    harness: 'backup-restore',
    command: 'sh scripts/check-backup-restore.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Raises the MQTT broker and the gateway from the controlled compose model, so what
    // is reconciled is the adapter a running deployment was configured with rather than
    // one constructed inside a test. Heavy for the same reason and skippable on the same
    // terms: a harness that cannot run is a stated skip locally and an error in CI.
    harness: 'mqtt-edge',
    command: 'sh scripts/check-mqtt-edge.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Raises the OPC UA controller stand-in beside the broker and runs one gateway against
    // both, so CH1-VVT-TC-0022's "across adapters" is answered by three operational
    // adapters in one process rather than by one. Heaviest of the harnesses and skippable
    // on the same terms.
    harness: 'opcua-edge',
    command: 'sh scripts/check-opcua-edge.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Raises all three controller peers and runs one gateway against every one of them, so
    // CH1-VVT-TC-0022's "across adapters" is answered by the three protocols it actually
    // names rather than by a subset. Heaviest of the harnesses and skippable on the same
    // terms: a stated skip locally, an error in CI.
    // Runs the core demonstration on a Docker network created with --internal, having
    // first proven that network cannot reach a public host. CH1-OPS-FR-0001 is a Must
    // verified by Test, and "the networks are declared internal" is a claim rather than
    // evidence.
    harness: 'offline-workflow',
    command: 'sh scripts/check-offline-workflow.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Raises Control Core and the gateway from the controlled compose model on PostgreSQL
    // and attacks the mutually authenticated edge between them. It is the only harness that
    // executes a command transaction against a cell reporting live permissives, so it is
    // also the only place the PostgreSQL command path runs at all.
    harness: 'grpc-edge',
    command: 'sh scripts/check-grpc-edge.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Takes the link away from a running gateway, replaces the gateway container while it
    // is away, and gives the link back. It is the only harness that proves records survive
    // the process that wrote them, which is the whole reason CH1-NFR-REL-0001's buffer is
    // on disk rather than in memory.
    harness: 'gateway-buffer',
    command: 'sh scripts/check-gateway-buffer.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // Mounts the portal's own screen modules in a DOM, answers their fetches from
    // responses captured from a real service, and reads the rendered text back. It is
    // the only harness that executes the interface at all: everything else establishes
    // what the service sends and what the portal declares it reads, neither of which is
    // a statement about what an operator ends up looking at. Needs no Docker and no
    // database, so unlike the edge harnesses it is cheap enough to run every time.
    harness: 'portal-render',
    command: 'node scripts/check-portal-render.mjs',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    harness: 'modbus-edge',
    command: 'sh scripts/check-modbus-edge.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
  {
    // The only harness that measures rather than asserts. It offers CH1-NFR-PER-0001's
    // baseline over the real edge, using the gateway's own client, against Control Core on
    // PostgreSQL, and announces nothing unless the rig is first shown to have offered the
    // required rate. For two sessions it announced nothing at all, which was the honest
    // answer while the rate was 21 msg/s; it is in this list now because the requirement is
    // carried, and it belongs here precisely so that it goes back to announcing nothing the
    // moment it stops being.
    harness: 'baseline-load',
    command: 'sh scripts/check-baseline-load.sh',
    extract: (output) => output
      .split(/\r?\n/)
      .filter((line) => line.startsWith('VERIFICATION-CASE'))
      .flatMap((line) => line.match(CASE_PATTERN) ?? []),
  },
];

// A harness the map declares but nothing here runs is unverified evidence wearing the same
// clothes as verified evidence — the exact failure this gate exists to remove, one level
// up. It was not hypothetical: `opcua-edge` was added to the map and to the case bindings
// before it was added to the list above, and the gate reported green. The .NET assemblies
// are exempt because they are reconciled inside themselves by VerificationBindingTests.
const announcing = new Set(observations.map((observation) => observation.harness));
for (const harness of harnesses) {
  if (!harness.endsWith('.Tests') && !announcing.has(harness)) {
    errors.push(
      `The verification map declares harness "${harness}", which check-verification.mjs never runs. ` +
      'A binding to a harness nobody executes is indistinguishable from a case with no evidence.');
  }
}

let observedHarnesses = 0;
for (const { harness, command, cwd, extract } of observations) {
  let output;
  try {
    output = await observe(command, { cwd });
  } catch (error) {
    // The firmware binary only exists once verify.sh has built it. Locally that is a
    // stated skip; in CI it is mandatory, exactly as the .NET and Compose steps are.
    //
    // WHAT THE HARNESS ACTUALLY SAID, not its first line. This used to take
    // error.message.split('\n')[0], and a shell gate's output begins with a blank line, so
    // a real failure reported as "could not be run ()" - the reason present in the buffer
    // and thrown away one character before it. An undiagnosed failure that recurs is a
    // failure nobody is learning anything from. A gate states its refusals as FAIL lines
    // and its verdict last, so both are carried.
    const lines = error.message.split('\n').map((line) => line.trimEnd()).filter(Boolean);
    const refusals = lines.filter((line) => /^FAIL\b/.test(line));
    const detail = [...refusals.slice(-4), ...lines.slice(-3)]
      .filter((line, index, all) => all.indexOf(line) === index)
      .join(' | ');
    const message = `${harness}: could not be run (${detail || 'the harness produced no output at all'})`;
    if (strict) {
      errors.push(`${message}. CI treats every harness as mandatory; a skipped harness is not a passed harness.`);
    } else {
      console.log(`SKIPPED locally: ${message}. Run ./scripts/verify.sh first; CI treats this as mandatory.`);
    }
    continue;
  }

  observedHarnesses += 1;
  const observed = new Set(extract(output));
  const declared = declaredFor(harness);
  for (const testCaseId of observed) {
    if (!baselineById.has(testCaseId)) {
      errors.push(`${harness} announced ${testCaseId}, which is not a controlled case.`);
    } else if (!declared.has(testCaseId)) {
      errors.push(`${harness} announced ${testCaseId}, but the verification map does not bind that case to it.`);
    }
  }
  for (const testCaseId of declared) {
    if (!observed.has(testCaseId)) {
      errors.push(`The verification map binds ${testCaseId} to ${harness}, but the run announced no such case.`);
    }
  }
}

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  const counts = Object.groupBy(map.cases, (entry) => entry.executionStatus);
  const withEvidence = map.cases.filter((entry) => entry.bindings.length > 0).length;
  console.log(
    `Verification map valid: ${map.cases.length} controlled cases, ${withEvidence} with executable evidence, ` +
    `${observedHarnesses} of ${observations.length} announcing harnesses reconciled against a real run.`);
  console.log(JSON.stringify(Object.fromEntries(
    Object.entries(counts).map(([status, entries]) => [status, entries.length]))));
  console.log('The .NET bindings are reconciled inside each test assembly by VerificationBindingTests.');
  console.log(
    'Obligations with no controlled case are counted separately, by npm run obligations, and are ' +
    'never counted here.');
}
