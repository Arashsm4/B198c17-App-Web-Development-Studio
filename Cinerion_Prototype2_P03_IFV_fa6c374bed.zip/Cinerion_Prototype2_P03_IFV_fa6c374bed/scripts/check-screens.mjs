// Reconciles the operator portal's routes with the screens screens.json declares.
//
// "N of 22 declared screens exist" had been a hand-count in the progress document that
// nothing checked, and it was wrong in both directions: several routes implement a
// declared screen without naming it, and a screen could be claimed twice or claimed
// under an identifier that does not exist. CH1-UXD-DSG-0001 makes the screen register
// the controlled statement of what the interface must offer, so the count of what has
// been built against it should be measured, not asserted — the same argument that put
// traceability/verification-map.json behind a gate.
//
// Each route source declares what it implements with a marker line:
//
//   // @screen CH1-UX-SCR-0004 — Site and cell hierarchy
//   // @screen none — reason this route implements no declared screen
//
// The marker is a comment, so it has no runtime effect and cannot change what the route
// renders. What it does is make the claim checkable.

import { readdir, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const routeDirectory = 'apps/operator-portal/src/app';
const errors = [];

const screens = JSON.parse(
  await readFile(resolve(root, 'docs/baseline/P03_IFV/data/screens.json'), 'utf8'));
const declared = new Map(screens.map((row) => [row[0], { title: row[1], audience: row[2], purpose: row[3] }]));

// Routes that are not screens. expo-router requires the layout, and the not-found page
// is a framework page rather than a declared one.
const notScreens = new Set(['_layout.tsx', '+not-found.tsx']);

const files = (await readdir(resolve(root, routeDirectory)))
  .filter((name) => name.endsWith('.tsx') && !notScreens.has(name))
  .sort();

const claims = new Map();
for (const file of files) {
  const text = await readFile(resolve(root, routeDirectory, file), 'utf8');
  const markers = [...text.matchAll(/^\s*\/\/ @screen (CH1-UX-SCR-\d{4}|none)\b(.*)$/gm)];

  if (markers.length === 0) {
    errors.push(
      `${routeDirectory}/${file} declares no screen. Add "// @screen CH1-UX-SCR-nnnn — title", ` +
      'or "// @screen none — reason" if it implements no declared screen.');
    continue;
  }

  for (const [, id, rest] of markers) {
    if (rest.trim().length < 4) {
      errors.push(`${routeDirectory}/${file} declares ${id} with no explanation after it.`);
    }
    if (id === 'none') continue;
    if (!declared.has(id)) {
      errors.push(`${routeDirectory}/${file} claims ${id}, which screens.json does not declare.`);
      continue;
    }

    const existing = claims.get(id);
    if (existing) {
      errors.push(`${id} is claimed by both ${existing} and ${file}. One screen, one route.`);
      continue;
    }

    claims.set(id, file);
  }
}

// A route may implement more than one declared screen — quality.tsx carries both the
// inspection dashboard and the nonconformity workflow — but a screen implemented by two
// routes would leave a reader unable to say which one is the controlled surface.

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  const absent = [...declared.keys()].filter((id) => !claims.has(id));
  console.log(
    `Screen register reconciled: ${claims.size} of ${declared.size} declared screens implemented ` +
    `across ${files.length} portal routes.`);
  console.log(`Not yet implemented: ${absent.length === 0 ? 'none' : absent.join(', ')}`);
}
