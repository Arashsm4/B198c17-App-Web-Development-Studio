#!/usr/bin/env sh
# Restores a controlled backup, and refuses one it cannot vouch for.
#
# CH1-OPS-FR-0002 asks for restore and rollback as well as backup, and the refusals here
# are the part that makes it a controlled procedure rather than a copy:
#
#   * a dump whose SHA-256 no longer matches its manifest is refused outright. A backup
#     that has been altered since it was taken is not the artefact the manifest describes,
#     and restoring it would put unverifiable records into a controlled database;
#   * a manifest that is absent is refused too. An unaccompanied dump cannot be checked
#     at all, and "it looked like a database" is not integrity verification;
#   * restoring over a database that already holds controlled records requires --replace.
#     A restore is a replacement, not a merge, and doing it silently would produce a
#     database that is neither the backup nor what was there before.
#
# Rollback is this same operation naming an earlier backup: --list shows what is held.
#
# Usage:
#   scripts/restore.sh --backup artifacts/backups/cinerion-<label>.sql \
#     (--dsn <libpq-url> | --container <name> [--database cinerion] [--user cinerion_owner]) \
#     [--replace]
#   scripts/restore.sh --list [--out artifacts/backups]
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out_dir="$repo_dir/artifacts/backups"
backup=""
dsn=""
container=""
database="cinerion"
user="cinerion_owner"
replace=false
list=false

while [ $# -gt 0 ]; do
  case "$1" in
    --backup) backup=$2; shift 2 ;;
    --dsn) dsn=$2; shift 2 ;;
    --container) container=$2; shift 2 ;;
    --database) database=$2; shift 2 ;;
    --user) user=$2; shift 2 ;;
    --out) out_dir=$2; shift 2 ;;
    --replace) replace=true; shift ;;
    --list) list=true; shift ;;
    *) echo "restore.sh: unknown argument $1" >&2; exit 2 ;;
  esac
done

if [ "$list" = true ]; then
  echo "Backups held in $out_dir (newest last):"
  ls -1 "$out_dir"/*.manifest.json 2>/dev/null | while read -r item; do
    echo "  $(basename "$item" .manifest.json)  $(grep -o '"takenAt": "[^"]*"' "$item" | cut -d'"' -f4)"
  done
  exit 0
fi

if [ -z "$backup" ]; then
  echo "restore.sh: --backup is required. Use --list to see what is held." >&2
  exit 2
fi

if [ -z "$dsn" ] && [ -z "$container" ]; then
  echo "restore.sh: one of --dsn or --container is required." >&2
  exit 2
fi

manifest="${backup%.sql}.manifest.json"

if [ ! -f "$backup" ]; then
  echo "restore.sh: no such backup: $backup" >&2
  exit 1
fi

# Integrity verification, before anything is written.
if [ ! -f "$manifest" ]; then
  echo "restore.sh: $backup has no manifest at $manifest." >&2
  echo "            An unaccompanied dump cannot be verified, so it is refused rather than restored." >&2
  exit 1
fi

recorded=$(grep -o '"sha256": "[^"]*"' "$manifest" | cut -d'"' -f4)
actual=$(sha256sum "$backup" | cut -d' ' -f1)

if [ "$recorded" != "$actual" ]; then
  echo "restore.sh: INTEGRITY CHECK FAILED for $backup." >&2
  echo "            manifest: $recorded" >&2
  echo "            actual:   $actual" >&2
  echo "            The backup is not the artefact its manifest describes. Refusing to restore it." >&2
  exit 1
fi

echo "Integrity verified: $(basename "$backup") matches its manifest ($actual)."

count_query="select count(*) from information_schema.tables where table_schema='ch1'"

if [ -n "$container" ]; then
  existing=$(docker exec "$container" psql --username="$user" --dbname="$database" -tAc "$count_query")
else
  existing=$(psql "$dsn" -tAc "$count_query")
fi
existing=$(printf '%s' "$existing" | tr -d ' \r')

if [ "$existing" -gt 0 ] && [ "$replace" != true ]; then
  echo "restore.sh: the target database already holds $existing controlled tables." >&2
  echo "            A restore replaces controlled state rather than merging into it." >&2
  echo "            Pass --replace to proceed, having decided that is what you mean." >&2
  exit 1
fi

echo "Restoring $(basename "$backup") into $database…"
if [ -n "$container" ]; then
  docker exec -i "$container" psql --username="$user" --dbname="$database" \
    --set ON_ERROR_STOP=on --quiet < "$backup" > /dev/null
else
  psql "$dsn" --set ON_ERROR_STOP=on --quiet --file "$backup" > /dev/null
fi

if [ -n "$container" ]; then
  restored=$(docker exec "$container" psql --username="$user" --dbname="$database" -tAc "$count_query")
else
  restored=$(psql "$dsn" -tAc "$count_query")
fi
restored=$(printf '%s' "$restored" | tr -d ' \r')

echo "Restored: $restored controlled tables."

# The application role is a cluster object and its grants are schema objects, so neither
# is inside this dump — deliberately. A backup should not carry an authorisation decision:
# restoring one taken before a grant was tightened would quietly reinstate the looser one.
# The controlled role and its grants are therefore re-asserted from migration 0002, which
# is their single definition, and it runs *after* the restore because it grants on a ch1
# schema the restore has just created.
#
# This is not tidying. Row-level security is enforced against cinerion_app, and defect 13
# in this repository was that role not existing — every isolation policy was inert while
# appearing to be in force. A restored database without it is in exactly that state.
#
# 0011 is re-asserted for the same reason and one more: the REVOKE it carries is itself an
# authorisation decision the dump does not hold, so a restore without it hands cinerion_app
# back the unlogged DELETE on telemetry that 0011 exists to remove.
migrations_dir="$repo_dir/services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations"
for role_migration in "$migrations_dir/0002_application_role.sql" "$migrations_dir/0011_retention_role.sql"; do
  echo "Re-asserting controlled roles and grants from $(basename "$role_migration")…"
  if [ -n "$container" ]; then
    docker exec -i "$container" psql --username="$user" --dbname="$database" \
      --set ON_ERROR_STOP=on --quiet < "$role_migration" > /dev/null
  else
    psql "$dsn" --set ON_ERROR_STOP=on --quiet --file "$role_migration" > /dev/null
  fi
done

attributes_query="select bool_or(rolsuper)::text || ' ' || bool_or(rolbypassrls)::text from pg_roles where rolname in ('cinerion_app', 'cinerion_retention')"
if [ -n "$container" ]; then
  attributes=$(docker exec "$container" psql --username="$user" --dbname="$database" -tAc "$attributes_query")
else
  attributes=$(psql "$dsn" -tAc "$attributes_query")
fi
attributes=$(printf '%s' "$attributes" | tr -d '\r' | sed 's/^ *//;s/ *$//')

if [ "$attributes" != "false false" ]; then
  echo "restore.sh: CONTROLLED ROLES NOT CONTROLLED — cinerion_app/cinerion_retention report" >&2
  echo "            super/bypassrls '$attributes'." >&2
  echo "            Row-level security has no effect on a superuser or a BYPASSRLS role, so project" >&2
  echo "            isolation would appear to be in force while doing nothing. Refusing to report success." >&2
  exit 1
fi

echo "Application and retention roles present, NOSUPERUSER and NOBYPASSRLS: row-level security applies to both."

# The one grant decision a restore could quietly undo. CH1-DBA-DD-0001 makes deletion of
# telemetry authorised and logged, and cinerion_app holding DELETE on it would make that
# untrue again without anything failing.
delete_query="select count(*) from information_schema.role_table_grants where grantee='cinerion_app' and table_schema='ch1' and table_name='telemetry_samples' and privilege_type='DELETE'"
if [ -n "$container" ]; then
  app_delete=$(docker exec "$container" psql --username="$user" --dbname="$database" -tAc "$delete_query")
else
  app_delete=$(psql "$dsn" -tAc "$delete_query")
fi
app_delete=$(printf '%s' "$app_delete" | tr -d ' \r')
if [ "$app_delete" != "0" ]; then
  echo "restore.sh: cinerion_app still holds DELETE on ch1.telemetry_samples after the restore." >&2
  echo "            Telemetry disposal would then be possible with no authorisation and no record," >&2
  echo "            which CH1-DBA-DD-0001 forbids. Refusing to report success." >&2
  exit 1
fi
echo "Telemetry disposal remains the retention role's alone: cinerion_app holds no DELETE on it."
echo
echo "Two things remain, and only the deployment can do them:"
echo "  1. ALTER ROLE cinerion_app LOGIN PASSWORD '<from controlled secret storage>';"
echo "     A password never travels inside a backup artefact."
echo "  2. Start Control Core against this database. It refuses at start if the schema is"
echo "     behind its build and names the migration, so a partly restored database fails"
echo "     before an operator rather than in front of one. Then verify the audit chain with"
echo "     POST /api/v1/audit/chain-verifications: a chain that no longer verifies means the"
echo "     restored evidence is not the evidence that was recorded."
