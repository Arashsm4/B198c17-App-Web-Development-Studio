#!/usr/bin/env sh
# Generates the laboratory PKI the OPC UA edge needs, and nothing beyond it.
#
# CH1-COM-IF-0007 puts "SignAndEncrypt + certificates" on the EdgeLink-to-PLC edge and
# CH1-COM-IF-0022 puts "OPC UA SignAndEncrypt or zoned allowlist" on the edge to the real
# S7-1200 G2 CPU. Both ends therefore need an application instance certificate, and OPC UA
# is stricter about what one looks like than TLS alone: the certificate must carry the
# application's own URI in a subjectAltName, and the client checks the server's certificate
# against the host name in the endpoint URL. A certificate that is merely valid is refused.
#
# This is a LABORATORY certificate authority, on exactly the same terms as the MQTT one.
# It is not the PKI CH1-CYB-IAM-0001 describes: that keeps root credentials hardware-backed
# and issues device certificates through a controlled provisioning ceremony. Every artefact
# here says so in its subject organisational unit.
#
# Output goes to infrastructure/secrets/opcua, which .gitignore excludes. No key is ever
# printed, committed, or written anywhere else.
#
# Usage: scripts/bootstrap-opcua-pki.sh [--force]
set -eu

# Git Bash rewrites any argument that looks like a POSIX path into a Windows one before the
# process sees it, so "/O=Cinerion/OU=…/CN=…" arrives at openssl as "C:/Program Files/Git/…"
# and the subject is rejected. Both variables are needed: the first governs MSYS2 builds,
# the second older MSYS. Harmless everywhere else.
MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out="$repo_dir/infrastructure/secrets/opcua"
force=false
[ "${1:-}" = "--force" ] && force=true

if [ -f "$out/ca.crt" ] && [ "$force" != true ]; then
  echo "OPC UA laboratory PKI already present in $out. Pass --force to regenerate."
  exit 0
fi

mkdir -p "$out"
cd "$out"

plc_host=${CINERION_OPCUA_HOSTNAME:-opcua-plc}
plc_device=${CINERION_OPCUA_DEVICE_ID:-CH1-DEV-CELL-0001}
plc_uri="urn:cinerion:ch1:plc:$plc_device"
edgelink_uri=${CINERION_OPCUA_CLIENT_URI:-urn:cinerion:ch1:edgelink}

echo "Generating a laboratory certificate authority…"
openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
  -keyout ca.key -out ca.crt \
  -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=Cinerion CH1 OPC UA Laboratory CA" \
  -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

# An OPC UA application instance certificate is not an ordinary TLS certificate. The stack
# checks the application URI in the subjectAltName against the ApplicationUri the peer
# declares, and refuses BadCertificateUriInvalid when they disagree — which is what stops a
# certificate issued for one application being presented by another. Both ends here carry
# clientAuth and serverAuth, because an OPC UA application may open a channel in either
# direction.
issue() {
  name=$1
  common_name=$2
  alternative=$3
  echo "Issuing $name as CN=$common_name…"
  openssl req -newkey rsa:3072 -sha256 -nodes \
    -keyout "$name.key" -out "$name.csr" \
    -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=$common_name"
  printf '%s\n' "subjectAltName=$alternative
extendedKeyUsage=serverAuth,clientAuth
keyUsage=critical,digitalSignature,nonRepudiation,keyEncipherment,dataEncipherment
basicConstraints=critical,CA:FALSE" > "$name.ext"
  openssl x509 -req -in "$name.csr" -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out "$name.crt" -days 365 -sha256 -extfile "$name.ext"
  rm -f "$name.csr" "$name.ext"
}

issue plc "Cinerion CH1 PLC stand-in" "URI:$plc_uri,DNS:$plc_host,DNS:localhost,IP:127.0.0.1"
issue edgelink "Cinerion CH1 EdgeLink" "URI:$edgelink_uri,DNS:edge-link,DNS:localhost,IP:127.0.0.1"

chmod 644 ./*.crt 2>/dev/null || true
chmod 600 ./*.key 2>/dev/null || true
rm -f ca.srl

echo
echo "OPC UA laboratory PKI written to infrastructure/secrets/opcua (git-ignored):"
echo "  ca.crt           the trust anchor both ends validate against"
echo "  plc.crt/key      $plc_uri, host $plc_host"
echo "  edgelink.crt/key $edgelink_uri — the gateway's application identity and its user identity"
echo
echo "These are laboratory credentials for exercising the interface. CH1-CYB-IAM-0001 keeps"
echo "real controller keys non-exportable in hardware, and this platform is a trust registry"
echo "rather than a certificate authority."
