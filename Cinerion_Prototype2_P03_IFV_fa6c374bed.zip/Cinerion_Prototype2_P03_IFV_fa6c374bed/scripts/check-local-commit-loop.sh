#!/usr/bin/env sh
# CH1-AUT-FDS-0001 — the controlled local-commit sequence, executed end to end.
# CH1-CMD-FR-0003, CH1-CMD-FR-0005 — physical confirmation, and no remote start.
# CH1-IAM-FR-0008 — device identities authenticate by mutual TLS, never through the human realm.
#
# WHAT THIS EXECUTES, AND WHY NOTHING COULD BEFORE. The controlled sequence is: prepare
# intent, present a credential proof, observe a NEW button edge, re-sample the interlocks,
# commit locally. All five were implemented and tested in Control Core, and the whole thing
# could never be run outside a unit test, because `ValidateController` requires an
# mTLS-authenticated device identity holding DeviceController — and the only way to present
# one was the development identity handler, which is mutually exclusive with OIDC and is
# not a production authentication mechanism. A prepared command in a real lab therefore sat
# at AwaitingCredential for ever.
#
# This raises a real Control Core on PostgreSQL with the device listener configured, enrols
# a device certificate through the controlled enrolment operation, starts the stand-in
# controller against it, prepares a command, and asks the stand-in to confirm. Then it
# ATTACKS the listener four ways, because a new authentication surface is worth exactly
# what it refuses.
#
# WHAT IT DOES NOT ESTABLISH. Nothing physical. The button edge is marked
# SimulatorInjection and the presence is marked SimulatedPresence; both are refused outside
# the Simulation profile and both are audited as marked. No output is energised anywhere —
# the pin map declares two actuator signals and neither is energisable at hardware revision
# R01, and `npm run policy` refuses a firmware source that would drive one.
#
# Usage: scripts/check-local-commit-loop.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

project_id=00000000-0000-4000-8000-000000000101
site_id=00000000-0000-4000-8000-000000000102
cell_id=00000000-0000-4000-8000-000000000103
asset_id=00000000-0000-4000-8000-000000000104
work_order_id=00000000-0000-4000-8000-000000000105
part_id=00000000-0000-4000-8000-000000000106
controller_boot_id=00000000-0000-4000-8000-000000000107
controller_id=CH1-DEV-CELL-0001

# The .NET processes below are Windows binaries when this runs under Git Bash, and a
# POSIX path handed to one arrives as "C:\c\Users\..." - a directory that does not
# exist, reported as a missing certificate file. MSYS_NO_PATHCONV above stops the shell
# rewriting arguments, which is right for the openssl subjects and wrong for these, so the
# conversion is done explicitly where it is wanted.
native() {
  if command -v cygpath >/dev/null 2>&1; then cygpath -w "$1"; else printf '%s' "$1"; fi
}
pki="$repo_dir/infrastructure/secrets/device"
# The same directory, relative to the repository root this script has cd'd into. curl
# here is a Windows binary that cannot open the POSIX absolute path above, and a Windows
# absolute path would collide with `--cert path:password` splitting on a colon.
pki_relative="infrastructure/secrets/device"
pki_native=$(native "$pki")
failures=0
checks=0
log() { printf '\n%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); checks=$((checks + 1)); }
pass() { printf 'PASS  %s\n' "$*"; checks=$((checks + 1)); }

[ -f "$pki/ca.crt" ] || {
  echo "check-local-commit-loop.sh: the device laboratory PKI is absent." >&2
  echo "Run scripts/bootstrap-device-pki.sh first; this gate needs a client certificate to" >&2
  echo "present and an authority for the service to validate it against." >&2
  exit 2
}

# Ports. Windows reserves large TCP ranges at boot and they MOVE (item 25, item 52), so
# nothing here is hardcoded from a number written down in a handover: a free port is taken
# and the loopback literal is bound, because Kestrel will not take a dynamic port on the
# `localhost` name and AllowedHosts then rejects a request addressed to the literal.
free_port() {
  python -c "import socket;s=socket.socket();s.bind(('127.0.0.1',0));print(s.getsockname()[1]);s.close()" 2>/dev/null \
    || node -e "const s=require('net').createServer();s.listen(0,'127.0.0.1',()=>{console.log(s.address().port);s.close();});"
}
api_port=$(free_port)
device_port=$(free_port)
confirmer_port=$(free_port)

api_pid=""
confirmer_pid=""
cleanup() {
  [ -n "$confirmer_pid" ] && kill "$confirmer_pid" 2>/dev/null || true
  [ -n "$api_pid" ] && kill "$api_pid" 2>/dev/null || true
  wait 2>/dev/null || true
}
trap cleanup EXIT INT TERM

log "[1/6] Building Control Core and the stand-in controller"
dotnet build Cinerion.slnx -c Release --nologo -v q >/dev/null

log "[2/6] Starting Control Core with the device listener on $device_port"
# Development identity is ON here and that is deliberate: this gate needs a HUMAN with a
# phishing-resistant step-up to enrol a device and to prepare a command, and obtaining one
# over OIDC needs a person at a keyboard. What it does NOT stand in for is the device
# identity — that is a real client certificate resolved to a real enrolled record, which is
# the whole subject of this gate. The two schemes now coexist, which is itself something
# this run establishes.
#
# The store is IN-MEMORY, and that is a scoping decision worth stating rather than
# discovering. On PostgreSQL the cell's interlocks are not persisted at all - the seed's
# own comment says so - so a cell reports its controller OFFLINE until something reports
# through CH1-COM-IF-0003, and a command cannot be prepared against it. Raising EdgeLink
# as well would make this gate a second copy of check-grpc-edge.sh, which already
# exercises the PostgreSQL command path including SaveCommandAsync's optimistic-concurrency
# branch. The subject HERE is device authentication and the controlled sequence, and
# neither of those is a property of the store.
CINERION_ALLOW_DEVELOPMENT_IDENTITY=true \
CINERION_DATABASE_MODE=InMemory \
CINERION_SIMULATED_TELEMETRY=false \
CINERION_DEVICE_MTLS_PORT="$device_port" \
CINERION_DEVICE_MTLS_CA_CERT="$pki_native/ca.crt" \
CINERION_DEVICE_MTLS_SERVER_CERT="$pki_native/control-core.crt" \
CINERION_DEVICE_MTLS_SERVER_KEY="$pki_native/control-core.key" \
CINERION_DEVICE_MTLS_PROJECT_ID="$project_id" \
ASPNETCORE_ENVIRONMENT=Development \
ASPNETCORE_HTTP_PORTS="$api_port" \
  dotnet run --project services/control-core/src/Cinerion.Api --no-build -c Release --no-launch-profile \
  > /tmp/cinerion-commit-loop-api.log 2>&1 &
api_pid=$!

api="http://localhost:$api_port"
ready=false
i=0
while [ $i -lt 60 ]; do
  if curl -fsS "$api/api/v1/system/health" >/dev/null 2>&1; then ready=true; break; fi
  sleep 1
  i=$((i + 1))
done
[ "$ready" = true ] || { fail "Control Core did not become healthy"; tail -30 /tmp/cinerion-commit-loop-api.log >&2; exit 1; }

health=$(curl -fsS "$api/api/v1/system/health")
case "$health" in
  *'"deviceIdentityListenerEnabled":true'*) pass "health reports the device listener is enabled" ;;
  *) fail "health does not report the device listener: $health" ;;
esac

step_up() {
  curl -sS -X POST "$api/api/v1/auth/step-up" \
    -H "X-CH1-Actor: $1" -H "X-CH1-Project: $project_id" -H "X-CH1-Roles: $2" \
    -H "X-CH1-Cells: $cell_id" -H "X-CH1-Auth-Strength: StepUpPhishingResistant" \
    -H "X-CH1-Session: session-$1" -H 'Content-Type: application/json' \
    -d "{\"purpose\":\"$3\"}" \
    | sed -n 's/.*"grantId":"\([0-9a-f-]\{36\}\)".*/\1/p'
}

log "[3/6] Enrolling the stand-in controller's certificate through the controlled operation"
certificate=$(awk 'BEGIN{ORS="\\n"} {print}' "$pki/cell-confirmer.crt")
grant=$(step_up USR-CYBER-LOOP CybersecurityAdministrator DeviceTrust)
[ -n "$grant" ] || { fail "no step-up grant was issued for device trust"; exit 1; }

enrolment=$(curl -sS -w '\n%{http_code}' -X POST "$api/api/v1/devices/$controller_id/enrolment" \
  -H "X-CH1-Actor: USR-CYBER-LOOP" -H "X-CH1-Project: $project_id" \
  -H "X-CH1-Roles: CybersecurityAdministrator" -H "X-CH1-Cells: $cell_id" \
  -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-USR-CYBER-LOOP" \
  -H "X-CH1-Step-Up: $grant" -H 'Content-Type: application/json' \
  -d "{\"certificate\":\"$certificate\",\"schemaVersion\":\"1.0.0\",\"deviceType\":\"Esp32CellController\",\"firmwareVersion\":\"0.1.0-prototype.1\",\"configurationRevision\":\"CFG-REFAB-P01-R01\",\"telemetryChannels\":[{\"channelId\":\"temperature\",\"unit\":\"degC\"},{\"channelId\":\"humidity\",\"unit\":\"%RH\"},{\"channelId\":\"position\",\"unit\":\"mm\"},{\"channelId\":\"vibration_rms\",\"unit\":\"m/s2\"}],\"supportedCommands\":[\"RUN_COATING_CYCLE\"],\"securityProfile\":\"SIMULATION-NO-PHYSICAL-AUTHORITY\"}")
enrol_status=$(printf '%s' "$enrolment" | tail -1)
enrol_body=$(printf '%s' "$enrolment" | sed '$d')
case "$enrol_status:$enrol_body" in
  201:*)
    pass "the controller's certificate is enrolled (201)" ;;
  400:*DEVICE_CERTIFICATE_UNCHANGED*)
    # A second run against the same database meets the refusal that makes re-enrolment a
    # DECISION rather than a repeat. The device is enrolled either way, which is what the
    # rest of this gate needs, and the refusal is itself the control working.
    pass "the certificate was already enrolled, and re-presenting it is refused rather than reapplied" ;;
  *)
    fail "enrolment answered $enrol_status: $(printf '%s' "$enrol_body" | head -c 400)"
    exit 1 ;;
esac

log "[4/6] Starting the stand-in controller"
CINERION_CONFIRMER_CONTROL_CORE_URL="https://localhost:$device_port" \
CINERION_CONFIRMER_CONTROLLER_ID="$controller_id" \
CINERION_CONFIRMER_CELL_ID="$cell_id" \
CINERION_CONFIRMER_CONTROLLER_BOOT_ID="$controller_boot_id" \
CINERION_CONFIRMER_CLIENT_CERT="$pki_native/cell-confirmer.crt" \
CINERION_CONFIRMER_CLIENT_KEY="$pki_native/cell-confirmer.key" \
CINERION_CONFIRMER_CA_CERT="$pki_native/ca.crt" \
ASPNETCORE_HTTP_PORTS="$confirmer_port" \
  dotnet run --project simulators/cell-confirmer/src/Cinerion.CellConfirmer --no-build -c Release \
  > /tmp/cinerion-commit-loop-confirmer.log 2>&1 &
confirmer_pid=$!

confirmer="http://localhost:$confirmer_port"
ready=false
i=0
while [ $i -lt 40 ]; do
  if curl -fsS "$confirmer/health" >/dev/null 2>&1; then ready=true; break; fi
  sleep 1
  i=$((i + 1))
done
[ "$ready" = true ] || { fail "the stand-in controller did not start"; tail -20 /tmp/cinerion-commit-loop-confirmer.log >&2; exit 1; }

confirmer_health=$(curl -fsS "$confirmer/health")
case "$confirmer_health" in
  *'"physicalEdge":false'*) pass "the stand-in states in its own health that no physical edge is observed" ;;
  *) fail "the stand-in does not disclaim a physical edge: $confirmer_health" ;;
esac

log "[5/6] Preparing a command and asking the simulated cell to confirm it"
prepare_grant=$(step_up USR-ENG-LOOP Engineer PhysicalCommandPreparation)
[ -n "$prepare_grant" ] || { fail "no step-up grant was issued for command preparation"; exit 1; }

state_hash=$(curl -sS "$api/api/v1/cells/$cell_id/state" \
  -H "X-CH1-Actor: USR-ENG-LOOP" -H "X-CH1-Project: $project_id" -H "X-CH1-Roles: Engineer" \
  -H "X-CH1-Cells: $cell_id" -H "X-CH1-Auth-Strength: Mfa" -H "X-CH1-Session: session-USR-ENG-LOOP" \
  | sed -n 's/.*"stateHash":"\([^"]*\)".*/\1/p')
[ -n "$state_hash" ] || { fail "the cell state could not be read, so no command can be prepared"; exit 1; }
pass "the cell reports a state hash the preparation can be bound to"

# A prepared command lives between 5 and 120 seconds and the domain refuses anything
# outside that. 110 leaves room for the confirmation round trip without asking for a
# window the control would not grant - the first attempt asked for ten minutes and was
# refused with CMD_TTL_INVALID, which is the control working.
expires=$(date -u -d '+110 seconds' '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date -u -v+110S '+%Y-%m-%dT%H:%M:%SZ')
prepared=$(curl -sS -X POST "$api/api/v1/commands/prepare" \
  -H "X-CH1-Actor: USR-ENG-LOOP" -H "X-CH1-Project: $project_id" -H "X-CH1-Roles: Engineer" \
  -H "X-CH1-Cells: $cell_id" -H "X-CH1-Auth-Strength: StepUpPhishingResistant" \
  -H "X-CH1-Session: session-USR-ENG-LOOP" -H "X-CH1-Step-Up: $prepare_grant" \
  -H "Idempotency-Key: $(date +%s)-commit-loop" -H 'Content-Type: application/json' \
  -d "{\"commandType\":\"RUN_COATING_CYCLE\",\"projectId\":\"$project_id\",\"siteId\":\"$site_id\",\"cellId\":\"$cell_id\",\"assetId\":\"$asset_id\",\"workOrderId\":\"$work_order_id\",\"partId\":\"$part_id\",\"procedureRevision\":\"R01\",\"configurationRevision\":\"CFG-REFAB-P01-R01\",\"expectedStateHash\":\"$state_hash\",\"sequence\":1,\"expiresAt\":\"$expires\",\"parameters\":{}}")
command_id=$(printf '%s' "$prepared" | sed -n 's/.*"commandId":"\([0-9a-f-]\{36\}\)".*/\1/p')
if [ -n "$command_id" ]; then
  pass "a command was prepared: $command_id"
else
  fail "preparation answered: $(printf '%s' "$prepared" | head -c 500)"
  exit 1
fi

case "$prepared" in
  *'"state":"AwaitingCredential"'*) pass "the prepared command awaits a credential, not an execution" ;;
  *) fail "the prepared command is not awaiting a credential: $(printf '%s' "$prepared" | head -c 300)" ;;
esac

confirmed=$(curl -sS -w '\n%{http_code}' -X POST "$confirmer/confirm" \
  -H 'Content-Type: application/json' -d "{\"commandId\":\"$command_id\"}")
confirm_status=$(printf '%s' "$confirmed" | tail -1)
confirm_body=$(printf '%s' "$confirmed" | sed '$d')
if [ "$confirm_status" = "200" ]; then
  pass "the simulated cell confirmed the command ($confirm_status)"
else
  fail "the confirmation answered $confirm_status: $(printf '%s' "$confirm_body" | head -c 600)"
fi

case "$confirm_body" in
  *'"state":"Committed"'*) pass "the command reached Committed through the controlled sequence" ;;
  *) fail "the command did not reach Committed: $(printf '%s' "$confirm_body" | head -c 400)" ;;
esac
case "$confirm_body" in
  *'SIMULATED cell controller'*) pass "the confirmation says plainly that it was simulated" ;;
  *) fail "the confirmation does not disclose that it was simulated" ;;
esac

# The audit record is the thing that outlives this run, so it is what is checked. A
# confirmation recorded as CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED would be asserting that a
# person presented a credential at a cell when nobody did.
audit=$(curl -sS "$api/api/v1/audit/events?limit=50" \
  -H "X-CH1-Actor: USR-AUD-LOOP" -H "X-CH1-Project: $project_id" -H "X-CH1-Roles: Auditor" \
  -H "X-CH1-Cells: $cell_id" -H "X-CH1-Auth-Strength: Mfa" -H "X-CH1-Session: session-USR-AUD-LOOP")
case "$audit" in
  *MARKED_SIMULATED_PRESENCE_NO_PERSON_AND_NO_CREDENTIAL_PRESENT*)
    pass "the audit chain records the presence as SIMULATED, with no person and no credential" ;;
  *) fail "the audit chain does not mark the simulated presence" ;;
esac
case "$audit" in
  *MARKED_SIMULATOR_EDGE_AND_FINAL_PERMISSIVES_VALID*)
    pass "and records the button edge as a MARKED simulator edge rather than a physical one" ;;
  *) fail "the audit chain does not mark the simulated button edge" ;;
esac
case "$audit" in
  *CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED*)
    fail "the audit chain claims a cryptographic local presence was verified, which is false" ;;
  *) pass "and never claims a cryptographic local presence was verified" ;;
esac

log "[6/6] Attacking the device listener"

# The certificates are presented as PKCS#12 bundles, not PEM. curl here is built against
# schannel, schannel cannot import a PEM client certificate, and it closes the connection
# before presenting anything - so the first version of this section recorded a pass for
# every attack while the server had never seen a certificate at all. The passphrase is a
# laboratory constant written in bootstrap-device-pki.sh beside the keys it protects.
p12() { printf '%s/%s.p12:cinerion-lab' "$pki_relative" "$1"; }
# --ssl-revoke-best-effort because schannel refuses a certificate whose revocation status
# it cannot determine, and this laboratory authority publishes no CRL or OCSP responder.
# It relaxes nothing about WHICH authority is trusted: --cacert still names one.
device_get() {
  curl -s -o /dev/null -w '%{http_code}' --ssl-revoke-best-effort \
    --cert-type P12 --cert "$(p12 "$1")" --cacert "$pki_relative/ca.crt" \
    "https://localhost:$device_port$2" 2>/dev/null || true
}

# THE POSITIVE CONTROL, and it comes first deliberately. Everything below asserts that
# something is REFUSED, and a refusal proves nothing if the client could not have reached
# the listener anyway. This is the same discipline an attack suite here owes: assert the
# mutation changed something before judging the answer.
enrolled_status=$(device_get cell-confirmer "/api/v1/commands/$command_id")
[ -n "$enrolled_status" ] || enrolled_status=000
if [ "$enrolled_status" = "200" ]; then
  pass "POSITIVE CONTROL: the enrolled certificate reaches an authorised operation (200)"
else
  fail "POSITIVE CONTROL FAILED: the enrolled certificate answered $enrolled_status, so every refusal below establishes nothing"
fi

# A certificate this authority DID issue, for a device nobody enrolled. Trusting the
# authority and being an enrolled device are two independent controls, and this is what
# separates them: the handshake succeeds and the authentication does not.
unenrolled_status=$(device_get unenrolled "/api/v1/commands/$command_id")
[ -n "$unenrolled_status" ] || unenrolled_status=000
if [ "$unenrolled_status" = "401" ]; then
  pass "a trusted certificate for an UNENROLLED device authenticates as nothing (401)"
else
  fail "an unenrolled device certificate answered $unenrolled_status rather than 401"
fi

# A certificate the controlled authority never issued, carrying the real controller's
# common name. Identity here is what this authority attested, not a name a client chose -
# and this one does not even complete a handshake.
foreign_status=$(device_get foreign "/api/v1/commands/$command_id")
[ -n "$foreign_status" ] || foreign_status=000
if [ "$foreign_status" = "000" ]; then
  pass "a certificate from an untrusted authority does not complete the handshake"
else
  fail "a certificate from an untrusted authority answered $foreign_status"
fi

# No certificate at all on the device listener.
none_status=$(curl -s -o /dev/null -w '%{http_code}' --ssl-revoke-best-effort \
  --cacert "$pki_relative/ca.crt" "https://localhost:$device_port/api/v1/system/health" 2>/dev/null) || true
[ -n "$none_status" ] || none_status=000
if [ "$none_status" = "000" ]; then
  pass "a connection with no client certificate does not complete at all"
else
  fail "a connection with no client certificate answered $none_status"
fi

# The human surface must not have become reachable with a certificate, and must still
# refuse an unauthenticated read. A new authentication scheme is worth checking in both
# directions: what it lets in, and what it did not accidentally let in elsewhere.
human_status=$(curl -s -o /dev/null -w '%{http_code}' "$api/api/v1/commands/$command_id" 2>/dev/null) || true
[ -n "$human_status" ] || human_status=000
if [ "$human_status" = "401" ]; then
  pass "the REST API still refuses an unauthenticated read (401), so the new scheme opened no door"
else
  fail "the REST API answered $human_status to an unauthenticated read"
fi

# And a device certificate is worth nothing on the human surface, because the handler
# refuses to decide anything for a request that did not arrive on the device listener.
on_rest_status=$(curl -s -o /dev/null -w '%{http_code}' --ssl-revoke-best-effort \
  --cert-type P12 --cert "$(p12 cell-confirmer)" \
  "$api/api/v1/commands/$command_id" 2>/dev/null) || true
[ -n "$on_rest_status" ] || on_rest_status=000
if [ "$on_rest_status" = "401" ]; then
  pass "the enrolled device certificate authenticates nothing on the REST port (401)"
else
  fail "a device certificate on the REST port answered $on_rest_status rather than 401"
fi

log "Local commit loop: $checks checks, $failures failed."
if [ "$failures" -gt 0 ]; then
  exit 1
fi

echo
echo "The controlled sequence completed: prepare -> credential proof -> button edge ->"
echo "interlock re-sample -> LOCAL COMMIT, with the controller's half performed by a device"
echo "identity resolved from an enrolled certificate."
echo
echo "NOTHING PHYSICAL HAPPENED. The edge was marked SimulatorInjection and the presence was"
echo "marked SimulatedPresence; both are refused outside the Simulation profile and both are"
echo "recorded as marked in the audit chain. No output was energised: the pin map declares"
echo "two actuator signals and neither is energisable at hardware revision R01."
echo
echo "This gate announces NO controlled verification case, deliberately. CH1-VVT-TC-0011,"
echo "0014, 0016 and 0017 are the cases this sequence belongs to and every one of them is"
echo "classified HIL: their expected results are about a real card, a real button and real"
echo "wired permissives. A marked simulator edge is none of those, and announcing a"
echo "hardware-in-the-loop case from a run with no hardware in it would be the one thing"
echo "this gate exists to make impossible. What it establishes is recorded in"
echo "traceability/executable-obligations.json, with what it does not establish beside it."
