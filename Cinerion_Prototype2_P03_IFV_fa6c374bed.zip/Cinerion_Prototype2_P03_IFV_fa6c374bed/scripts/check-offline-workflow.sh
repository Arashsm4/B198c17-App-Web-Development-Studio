#!/usr/bin/env sh
# CH1-VVT-TC-0080 — "Core demonstration completes without public internet."
# CH1-OPS-FR-0001 — "Principal workflows shall operate on the local network without a
#                    public-internet dependency." Must, verified by Test, allocated to
#                    Deployment.
#
# The verification map recorded this honestly and uncomfortably: "The whole stack runs on an
# internal Compose network with no public egress ... Nothing executable asserts the absence
# of a public-internet dependency, so the case has no evidence." Believing a deployment is
# offline because its networks are declared `internal: true` is exactly the kind of claim
# this repository refuses elsewhere.
#
# So the demonstration is executed on a network that genuinely cannot reach the internet.
#
#   1. A Docker network is created with --internal. Nothing on it has a route out.
#   2. That is PROVEN before anything else runs: a container on that network is asked to
#      reach a public host and must fail. Without this the whole gate could pass because
#      the workflow never needed the internet AND the network was never isolated - two
#      independent reasons, one of which would be an illusion.
#   3. PostgreSQL and Control Core are raised on that network ALONE, from the controlled
#      images, with every controlled migration applied.
#   4. The core demonstration is driven from a third container on the same network: the
#      controlled quality path - test run, failing mandatory measurement, nonconformity,
#      passing retest - plus the part's genealogy, the cell's state and interlocks, a
#      bounded telemetry query and a verification of the audit chain. If any of it reached
#      for a public host it would fail here.
#   5. The controlled runtime configuration is then read, and every network endpoint it
#      names must be a loopback address, a private range or a Compose service name. A
#      demonstration that completes offline while the shipped configuration names a public
#      host would pass step 4 and still be a public-internet dependency.
#
# Usage: scripts/check-offline-workflow.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

network=cinerion-offline-verify
db_container=cinerion-offline-db
api_container=cinerion-offline-api
postgres_image=postgres:18.4-alpine3.24
client_image=curlimages/curl:8.11.1
owner_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
app_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)

project_id=00000000-0000-4000-8000-000000000101
cell_id=00000000-0000-4000-8000-000000000103
part_id=00000000-0000-4000-8000-000000000106
calibration_id=00000000-0000-4000-8000-000000000108

failures=0
log() { printf '%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

cleanup() {
  docker rm -f "$api_container" "$db_container" >/dev/null 2>&1 || true
  docker network rm "$network" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

if ! docker version >/dev/null 2>&1; then
  echo "check-offline-workflow.sh: the Docker daemon is unreachable. This gate runs the core" >&2
  echo "demonstration on a network with no route to the internet; there is no way to run it" >&2
  echo "without one." >&2
  exit 1
fi

# Everything the demonstration touches must already be local. Images are pulled and built
# BEFORE the isolated network exists, which is the honest boundary: CH1-OPS-FR-0001 is about
# principal workflows at run time, not about building software without a network.
log "[1/6] Preparing images while the host still has a network"
docker image inspect "$postgres_image" >/dev/null 2>&1 || docker pull -q "$postgres_image" >/dev/null
docker image inspect "$client_image" >/dev/null 2>&1 || docker pull -q "$client_image" >/dev/null
docker compose -f infrastructure/compose.yaml build control-core >/dev/null 2>&1 \
  || { fail "the Control Core image could not be built"; exit 1; }
api_image=$(docker compose -f infrastructure/compose.yaml config --images 2>/dev/null | grep -i "control-core" | head -1)
[ -n "$api_image" ] || api_image=cinerion-control-core
pass "PostgreSQL, the client and the controlled Control Core image are present locally"

log "[2/6] Creating a network with no route to the internet, and proving it has none"
docker network rm "$network" >/dev/null 2>&1 || true
docker network create --internal "$network" >/dev/null

# The load-bearing check. If this network could reach the internet, every result below would
# be compatible with a workflow that quietly depends on it.
egress=$(docker run --rm --network "$network" "$client_image" \
  curl --silent --show-error --max-time 8 https://example.com 2>&1 || true)
printf '%s' "$egress" | grep -qiE "could not resolve|resolve host|failed to connect|network is unreachable|connection timed out" \
  && pass "a container on this network cannot reach a public host: $(printf '%s' "$egress" | tr '\n' ' ' | cut -c1-90)" \
  || { fail "the isolated network reached the public internet, so nothing below would mean anything: $egress"; exit 1; }

log "[3/6] Raising PostgreSQL and Control Core on that network alone"
docker run -d --name "$db_container" --network "$network" \
  -e POSTGRES_DB=cinerion -e POSTGRES_USER=cinerion_owner -e POSTGRES_PASSWORD="$owner_password" \
  "$postgres_image" >/dev/null

attempt=0
settled=0
while [ "$settled" -lt 3 ]; do
  if docker exec "$db_container" psql -U cinerion_owner -d cinerion -tAc "select 1" >/dev/null 2>&1; then
    settled=$((settled + 1))
  else
    settled=0
  fi
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "the database did not become ready"; exit 1; }
  sleep 1
done

for migration in services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/*.sql; do
  docker exec -i "$db_container" psql -U cinerion_owner -d cinerion --set ON_ERROR_STOP=on --quiet \
    < "$migration" > /dev/null
done
docker exec "$db_container" psql -U cinerion_owner -d cinerion -qc \
  "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password';" > /dev/null

# Attached to the internal network and nothing else. No published port, no default bridge:
# the service has no route off this network at all.
docker run -d --name "$api_container" --network "$network" \
  -e ASPNETCORE_ENVIRONMENT=Development \
  -e CINERION_RUNTIME_PROFILE=Simulation \
  -e CINERION_ALLOW_DEVELOPMENT_IDENTITY=true \
  -e CINERION_SIMULATED_TELEMETRY=true \
  -e CINERION_DATABASE_MODE=Postgres \
  -e "CINERION_POSTGRES_CONNECTION=Host=$db_container;Port=5432;Database=cinerion;Username=cinerion_app;Password=$app_password" \
  "$api_image" >/dev/null

# Addressed as "localhost" in the Host header whatever the container is called: appsettings
# sets AllowedHosts=localhost, so host filtering answers anything else with 400.
client() {
  method=$1; path=$2; body=${3:-}
  if [ -n "$body" ]; then
    docker run --rm --network "$network" "$client_image" curl --silent --show-error --max-time 20 \
      --request "$method" -H "Host: localhost" \
      -H "X-CH1-Actor: USR-OFFLINE-VERIFY" -H "X-CH1-Project: $project_id" \
      -H "X-CH1-Roles: Engineer,Inspector,Auditor,ProjectManager,QualityManager" -H "X-CH1-Cells: $cell_id" \
      -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-offline" \
      -H "Content-Type: application/json" --data "$body" "http://$api_container:8080$path"
  else
    docker run --rm --network "$network" "$client_image" curl --silent --show-error --max-time 20 \
      --request "$method" -H "Host: localhost" \
      -H "X-CH1-Actor: USR-OFFLINE-VERIFY" -H "X-CH1-Project: $project_id" \
      -H "X-CH1-Roles: Engineer,Inspector,Auditor,ProjectManager,QualityManager" -H "X-CH1-Cells: $cell_id" \
      -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-offline" \
      "http://$api_container:8080$path"
  fi
}

attempt=0
until client GET /api/v1/system/health 2>/dev/null | grep -q "status"; do
  attempt=$((attempt + 1))
  if [ "$attempt" -gt 60 ]; then
    fail "Control Core did not become healthy on the isolated network"
    docker logs "$api_container" 2>&1 | tail -20 >&2
    exit 1
  fi
  sleep 2
done
pass "Control Core is serving on a network with no route to the internet, on PostgreSQL"

log "[4/6] The core demonstration, driven from inside the isolated network"
json() { node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{try{const v=JSON.parse(s);const r=$1;console.log(r===undefined||r===null?'':r)}catch{console.log('')}})"; }

run_id=$(client POST /api/v1/test-runs \
  "{\"partId\":\"$part_id\",\"procedureId\":\"CH1-REFAB-PROC-0001\",\"procedureRevision\":\"R01\"}" | json "v.testRunId")
[ -n "$run_id" ] && pass "a controlled test run was started offline" || fail "no test run could be started"

fail_body="{\"partId\":\"$part_id\",\"characteristic\":\"Coating thickness\",\"value\":8.2,\"unit\":\"um\",\"lowerLimit\":9.5,\"upperLimit\":10.5,\"mandatory\":true,\"sourceDeviceId\":\"CH1-INS-THK-0001\",\"calibrationRecordId\":\"$calibration_id\",\"calibrationValid\":true}"
client POST "/api/v1/test-runs/$run_id/measurements" "$fail_body" > /dev/null
ncr_id=$(client POST /api/v1/ncrs   "{\"partId\":\"$part_id\",\"title\":\"Coating below lower limit\",\"description\":\"Mandatory characteristic measured at 8.2 um against a 9.5-10.5 um limit.\"}" | json "v.ncrId")
[ -n "$ncr_id" ] && pass "the failing mandatory result raised a nonconformity offline ($ncr_id)" || fail "no nonconformity was raised"

retest_id=$(client POST /api/v1/test-runs   "{\"partId\":\"$part_id\",\"procedureId\":\"CH1-REFAB-PROC-0001\",\"procedureRevision\":\"R01\"}" | json "v.testRunId")
pass_body="{\"partId\":\"$part_id\",\"characteristic\":\"Coating thickness\",\"value\":10.1,\"unit\":\"um\",\"lowerLimit\":9.5,\"upperLimit\":10.5,\"mandatory\":true,\"sourceDeviceId\":\"CH1-INS-THK-0001\",\"calibrationRecordId\":\"$calibration_id\",\"calibrationValid\":true}"
retest=$(client POST "/api/v1/test-runs/$retest_id/measurements" "$pass_body")
printf '%s' "$retest" | grep -q "Pass"   && pass "the passing retest was recorded offline, beside the failure it supersedes"   || fail "the retest was not recorded: $(printf '%s' "$retest" | cut -c1-140)"

# The closing disposition is deliberately not driven here: CH1-CYB-ACP-0001 puts it behind a
# purpose-bound step-up grant, which other gates exercise and which has nothing to do with
# whether this workflow needs the public internet.

genealogy=$(client GET "/api/v1/parts/$part_id/genealogy")
measurements=$(printf '%s' "$genealogy" | json "(v.part.measurements||[]).length")
identity=$(printf '%s' "$genealogy" | json "v.part.controlledIdentity")
provenance=$(printf '%s' "$genealogy" | json "v.provenance")
[ -n "$measurements" ] && [ "$measurements" -ge 2 ] && [ -n "$provenance" ]   && pass "the part's genealogy is complete offline: ${identity:-identity present}, $measurements measurements including the superseded failure, provenance stated by the service"   || fail "the genealogy was not assembled: $(printf '%s' "$genealogy" | cut -c1-160)"

state=$(client GET "/api/v1/cells/$cell_id/state")
printf '%s' "$state" | grep -q "stateHash" \
  && pass "the cell reports its state and interlocks offline" \
  || fail "the cell state could not be read: $(printf '%s' "$state" | cut -c1-140)"

telemetry=$(client GET "/api/v1/telemetry?cellId=$cell_id&channel=temperature&from=$(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u +%Y-%m-%dT%H:%M:%SZ)&to=$(date -u +%Y-%m-%dT%H:%M:%SZ)")
printf '%s' "$telemetry" | grep -qE "samples|items|\[" \
  && pass "bounded telemetry is queryable offline, fed by the in-process simulated source" \
  || fail "telemetry could not be queried: $(printf '%s' "$telemetry" | cut -c1-140)"

chain=$(client POST /api/v1/audit/chain-verifications "{}")
valid=$(printf '%s' "$chain" | json "v.valid")
checked=$(printf '%s' "$chain" | json "v.checked")
[ "$valid" = "true" ] && [ -n "$checked" ] && [ "$checked" -gt 0 ] \
  && pass "the audit chain verifies offline: $checked events, hash-linked and valid" \
  || fail "the audit chain did not verify offline: $(printf '%s' "$chain" | cut -c1-140)"

log "[5/6] The network was still isolated while all of that ran"
egress_after=$(docker run --rm --network "$network" "$client_image" \
  curl --silent --show-error --max-time 8 https://example.com 2>&1 || true)
printf '%s' "$egress_after" | grep -qiE "could not resolve|resolve host|failed to connect|network is unreachable|connection timed out" \
  && pass "still no route to a public host after the demonstration completed" \
  || fail "the network gained public egress during the run: $egress_after"

log "[6/6] No controlled runtime configuration names a public host"
# Narrow on purpose: only settings that name a network endpoint. Namespace identifiers such
# as the OPC UA security-policy URIs are names rather than endpoints and are not scanned.
offenders=$(node -e '
const fs = require("node:fs");
const files = ["infrastructure/compose.yaml", ".env.example"];
const allowed = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|host\.docker\.internal$)/;
const services = new Set(["control-core","edge-link","operator-portal","postgres","identity","identity-db","mqtt","opcua-plc","modbus-plc"]);
const bad = [];
for (const file of files) {
  const text = fs.readFileSync(file, "utf8");
  for (const line of text.split(/\r?\n/)) {
    if (/^\s*#/.test(line)) continue;
    const m = line.match(/(CINERION_[A-Z0-9_]*(?:HOST|URL|URI|ENDPOINT|AUTHORITY)|EXPO_PUBLIC_[A-Z0-9_]*URL)\s*[:=]\s*(.+)$/);
    if (!m) continue;
    let value = m[2].trim().replace(/^\$\{[A-Z0-9_]+:-/, "").replace(/\}$/, "").replace(/^["\x27]|["\x27]$/g, "");
    if (!value || value.startsWith("$")) continue;
    if (/^urn:/.test(value)) continue;
    const host = value.replace(/^[a-z0-9.+-]+:\/\//i, "").split("/")[0].split("@").pop().split(":")[0];
    if (!host) continue;
    if (allowed.test(host) || services.has(host)) continue;
    bad.push(`${file}: ${m[1]} names ${host}`);
  }
}
console.log(bad.join("\n"));
')
[ -z "$offenders" ] \
  && pass "every controlled endpoint setting names a loopback address, a private range or a Compose service" \
  || fail "a controlled setting names a public host:
$offenders"

echo
if [ "$failures" -eq 0 ]; then
  echo "The core demonstration completes with no public internet."
  echo "  proven isolated : a container on this network cannot reach a public host, before"
  echo "                    the run and again after it"
  echo "  executed offline: test run, failing mandatory measurement, nonconformity, passing"
  echo "                    retest, part genealogy, cell state and interlocks, bounded"
  echo "                    telemetry, and a verified audit chain"
  echo "  configuration   : no controlled endpoint setting names a public host"
  echo "VERIFICATION-CASE CH1-VVT-TC-0080"
  exit 0
fi

echo "$failures check(s) failed. The case is not announced."
exit 1
