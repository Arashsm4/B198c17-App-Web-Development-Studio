// Attacks the controlled-authority reconciliation in scripts/check-repository-policy.mjs
// by reverting, one at a time, each control it exists for. Run from the repository root.
import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);
const registerPath = 'traceability/controlled-authorities.json';
const rolesPath = 'services/control-core/src/Cinerion.Domain/Security/ActorContext.cs';

const originalRegister = await readFile(registerPath, 'utf8');
const originalRoles = await readFile(rolesPath, 'utf8');

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-repository-policy.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

const attacks = [
  ['an authority the controlled documents name, deleted from the register', (register) => {
    delete register.authorities['IR plus Document Control review'];
  }, 'records no decision for it'],

  ['a register entry for a phrase no controlled document contains', (register) => {
    register.authorities['Chief Engineer'] = { roles: ['Engineer'] };
  }, 'which no controlled document names'],

  ['an authority mapped to a role that does not exist — conflict 23 restored', (register) => {
    register.authorities['Document Controller or IR'].roles = ['DocumentController', 'IR'];
  }, 'which CinerionRoles does not define'],

  ['an authority mapped to nothing at all', (register) => {
    register.authorities['Local Confirmer'] = {};
  }, 'mapped to neither a role nor a stated reason'],
];

let holes = 0;
const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
};

try {
  for (const [name, mutate, expected] of attacks) {
    const register = JSON.parse(originalRegister);
    mutate(register);
    await writeFile(registerPath, `${JSON.stringify(register, null, 2)}\n`);
    const { refused, output } = await gate();
    await writeFile(registerPath, originalRegister);
    judge(name, expected, refused, output);
  }

  // The role deleted from the code rather than from the register: the direction a
  // refactor would actually take, and the one that would leave an authority the
  // controlled documents name with nothing behind it.
  await writeFile(
    rolesPath,
    originalRoles
      .replace('    public const string ProjectOwner = "ProjectOwner";', '')
      .replace('        ProjectOwner,\n', ''));
  const { refused, output } = await gate();
  await writeFile(rolesPath, originalRoles);
  judge('the ProjectOwner role deleted from CinerionRoles', 'which CinerionRoles does not define', refused, output);
} finally {
  await writeFile(registerPath, originalRegister);
  await writeFile(rolesPath, originalRoles);
}

const restored = await gate();
console.log(`\n${attacks.length + 1} attacks, ${holes} holes.`);
console.log(`Restored files pass the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
