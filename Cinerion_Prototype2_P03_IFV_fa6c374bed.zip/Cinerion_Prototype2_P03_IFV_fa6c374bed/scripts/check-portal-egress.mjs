// CH1-OPS-FR-0001 - "Principal workflows shall operate on the local network without a
//                    public-internet dependency." Must, verified by Test, allocated to
//                    Deployment. Case CH1-VVT-TC-0080.
// CH1-AI-FR-0002   - no AI service in any authority path; every AI endpoint is also a
//                    public-internet host, so the two requirements meet here.
//
// WHAT THIS GATE COVERS THAT THE OFFLINE GATE DOES NOT.
//
// scripts/check-offline-workflow.sh is the behavioural proof and it is a good one: it
// creates a Docker network with --internal, PROVES a container on it cannot reach a public
// host, raises PostgreSQL and Control Core on that network alone, and drives the controlled
// quality path across it. Anything reaching for the internet would fail there.
//
// It covers the SERVICE. It does not cover the PORTAL, and the portal is the half an
// operator actually loads. A browser is a general-purpose fetching machine: a font
// declaration, an analytics beacon, a source-map reference or a redirect through a hosted
// auth proxy is a public-internet dependency that no server-side test would ever see, and
// one that arrives through a dependency upgrade rather than through anybody's decision.
//
// So this gate reads the artefact that actually ships:
//
//   1. The Content-Security-Policy literal, whose non-connect directives are the browser's
//      own enforcement. `default-src 'self'` with no public origin in img-src, font-src,
//      style-src or script-src means the page cannot load a CDN asset even if a bundle
//      asked it to.
//   2. The CONTROLLED compose model's EXPO_PUBLIC_* arguments, because the Dockerfile
//      derives connect-src from them - one place decides where the portal talks to, so
//      this is the place to check that everywhere it talks to is local.
//   3. Every absolute origin in the EXPORTED BUNDLE, each one either local or allowlisted
//      BY NAME with a reason. This is the check that catches an origin nobody chose.
//   4. `https://auth.expo.io` gets its own treatment, because unlike the other library
//      strings it is a real, live public service - Expo's hosted auth proxy. It is allowed
//      to be present and the two INDEPENDENT reasons it can never be reached are asserted
//      instead. Removing either one fails this gate.
//
// Requires the exported bundle, which verify.sh step [8/14] produces immediately before
// running this. A missing bundle is a FAILURE here and not a skip: defect 51 was a strict
// pipeline reporting a harness that could not run as though it had passed.
//
// Usage: npm run portal:egress   (after npm run build:portal)

import { readdir, readFile, stat } from 'node:fs/promises';
import { dirname, extname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseDocument } from 'yaml';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const distRoot = resolve(root, 'apps/operator-portal/dist');

// ---------------------------------------------------------------------------------------
// What counts as local.
//
// Loopback, the three private IPv4 ranges, link-local, and a bare name with no dot - which
// is what a Compose service name looks like. Deliberately NOT "any name that happens to
// resolve locally today": a name that resolves is a name that could stop resolving
// locally, and CH1-OPS-FR-0001 is about the deployment rather than about this workstation.
// ---------------------------------------------------------------------------------------

const isLocalHost = (host) => {
  const bare = host.replace(/:\d+$/, '').toLowerCase();
  if (bare === 'localhost' || bare === '127.0.0.1' || bare === '::1' || bare === '[::1]') return true;
  if (/^127\./.test(bare)) return true;
  if (/^10\./.test(bare)) return true;
  if (/^192\.168\./.test(bare)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(bare)) return true;
  if (/^169\.254\./.test(bare)) return true;
  if (bare.endsWith('.local') || bare.endsWith('.internal')) return true;
  // A Compose service name: no dot, so it cannot be a public DNS name.
  if (!bare.includes('.') && bare !== '') return true;
  return false;
};

// ---------------------------------------------------------------------------------------
// 1. The Content-Security-Policy literal.
// ---------------------------------------------------------------------------------------

const nginxConf = await readFile(resolve(root, 'infrastructure/nginx/operator-portal.conf'), 'utf8');
const policyLine = nginxConf.match(/add_header\s+Content-Security-Policy\s+"([^"]+)"/)?.[1];
if (!policyLine) {
  errors.push(
    'infrastructure/nginx/operator-portal.conf declares no Content-Security-Policy. Without one the ' +
    'browser will fetch whatever any bundle asks it to, and every check below is advisory.');
}

const directives = new Map();
for (const part of (policyLine ?? '').split(';')) {
  const tokens = part.trim().split(/\s+/).filter(Boolean);
  if (tokens.length === 0) continue;
  directives.set(tokens[0], tokens.slice(1));
}

// These four are what stop the page being turned into an exfiltration or framing surface.
const requiredDirectives = {
  'default-src': "'self'",
  'base-uri': "'self'",
  'form-action': "'self'",
  'frame-ancestors': "'none'",
};
for (const [directive, expected] of Object.entries(requiredDirectives)) {
  const sources = directives.get(directive);
  if (!sources) {
    errors.push(`The portal's Content-Security-Policy declares no ${directive}. It must be ${expected}.`);
  } else if (sources.length !== 1 || sources[0] !== expected) {
    errors.push(
      `The portal's Content-Security-Policy sets ${directive} to "${sources.join(' ')}" rather than ` +
      `${expected}. Anything wider is a place the browser may go that nobody chose.`);
  }
}

// Every source in every directive must be a keyword, a data: URI, or a LOCAL origin. This
// is the check that refuses a font service or a script CDN.
const keywordSources = new Set([
  "'self'", "'none'", "'unsafe-inline'", "'unsafe-eval'", "'strict-dynamic'", 'data:', 'blob:',
]);
let policySourcesChecked = 0;
for (const [directive, sources] of directives) {
  for (const source of sources) {
    policySourcesChecked += 1;
    if (keywordSources.has(source) || source.startsWith("'nonce-") || source.startsWith("'sha256-")) continue;
    const host = source.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!isLocalHost(host)) {
      errors.push(
        `The portal's Content-Security-Policy permits ${directive} to reach "${source}", which is not a ` +
        'local origin. CH1-OPS-FR-0001 forbids a public-internet dependency in a principal workflow.');
    }
  }
}
// 'unsafe-eval' would let a bundle build code at runtime, which is how an injected string
// becomes a fetch the static checks below cannot see.
for (const [directive, sources] of directives) {
  if (sources.includes("'unsafe-eval'")) {
    errors.push(`The portal's Content-Security-Policy allows 'unsafe-eval' in ${directive}.`);
  }
}

// ---------------------------------------------------------------------------------------
// 2. The controlled compose model's build arguments, which the Dockerfile turns into
//    connect-src. Item 72: the policy gate already requires the CONTROLLED model to pass
//    every EXPO_PUBLIC_* the Dockerfile declares, because Metro inlines them at build
//    time. This checks what they are pointed AT.
// ---------------------------------------------------------------------------------------

const composeModel = parseDocument(await readFile(resolve(root, 'infrastructure/compose.yaml'), 'utf8')).toJS();
const portalArgs = composeModel?.services?.['operator-portal']?.build?.args ?? {};

// Every argument in the controlled model is written `${NAME:-default}`, so the value the
// model DECIDES is the default inside the substitution - and an earlier revision of this
// gate skipped anything beginning with `${`, which meant it examined none of the four and
// still printed a count. Found by writing attack 7, which changed a value the gate was not
// reading. The lesson is item 63's in another costume: a check has to be pointed at the
// thing that decides, and a count of what it skipped reads exactly like a count of what it
// approved.
const substitutionDefault = (text) => {
  const match = text.match(/^\$\{[A-Za-z_][A-Za-z0-9_]*:-(.*)\}$/s);
  if (match) return { decided: true, value: match[1] };
  if (/^\$\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(text)) return { decided: false, value: '' };
  return { decided: true, value: text };
};

let argsChecked = 0;
let argsDeferred = 0;
for (const [name, value] of Object.entries(portalArgs)) {
  if (!name.startsWith('EXPO_PUBLIC_')) continue;
  const { decided, value: text } = substitutionDefault(String(value ?? ''));
  if (!decided) {
    // A substitution with no default leaves the value to the environment. Item 72 is why
    // that is not automatically wrong - but it is not something this gate can check, so it
    // is counted separately rather than counted as examined.
    argsDeferred += 1;
    continue;
  }
  argsChecked += 1;
  // An empty value is the documented way to declare an argument whose value belongs to a
  // laboratory overlay - deliberate for the cell simulator - so it is not a finding.
  if (text === '') continue;
  // A client id is not a URL. Only values that carry a scheme name a host.
  if (!/^https?:\/\//.test(text)) continue;
  const host = text.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!isLocalHost(host)) {
    errors.push(
      `The controlled compose model builds the portal with ${name}="${text}", whose host is not local. ` +
      'The Dockerfile derives connect-src from these arguments, so this would also widen the policy.');
  }
}
if (argsChecked === 0) {
  errors.push(
    `The controlled compose model passes the portal ${argsDeferred} EXPO_PUBLIC_* argument(s) and this gate ` +
    'could read a decided value for none of them, so the check established nothing. npm run policy requires ' +
    'the model to pass every one the Dockerfile declares.');
}

// ---------------------------------------------------------------------------------------
// 3. Every absolute origin in the exported bundle.
//
// Each entry below was produced by MEASURING the bundle, not by guessing what a bundle
// might contain, and each carries the reason it is not an egress. `npm run capabilities`
// records why a measured figure beats a remembered one: the portal's operation count was
// wrong three times from three different greps before it became a gate.
// ---------------------------------------------------------------------------------------

const allowedOrigins = new Map([
  ['http://www.w3.org', 'XML and SVG namespace identifiers. A namespace URI names a vocabulary and is never fetched.'],
  ['https://openid.net', 'OpenID Connect specification and claim identifiers carried as strings by the OIDC client.'],
  ['https://docs.expo.dev', 'Text inside an Expo library error message, pointing a developer at documentation.'],
  ['https://reactnavigation.org', 'Text inside React Navigation error and warning messages.'],
  ['https://react.dev', 'Text inside a React error message.'],
  ['https://github.com', 'Text inside library error messages, pointing at issue trackers.'],
  ['https://yourwebsite.com', 'A placeholder in Expo library documentation strings. Not a resolvable host anybody owns.'],
  ['https://phony.example', 'A deliberately unresolvable example host from the .example reserved TLD (RFC 2606), used by a library as a placeholder.'],
  ['http://hostname', 'A placeholder in a library documentation string.'],
  // The one that is a real service. Section 4 asserts why it cannot be reached.
  ['https://auth.expo.io', "Expo's hosted auth proxy. A REAL public service, and the only entry here that is. Section 4 asserts the two independent reasons this portal can never redirect through it."],
]);

let distFiles;
try {
  await stat(distRoot);
  const walk = async (directory) => {
    const entries = await readdir(directory, { withFileTypes: true });
    const found = [];
    for (const entry of entries) {
      const path = resolve(directory, entry.name);
      if (entry.isDirectory()) found.push(...await walk(path));
      else found.push(path);
    }
    return found;
  };
  distFiles = (await walk(distRoot))
    .filter((path) => ['.js', '.html', '.css', '.json', '.map'].includes(extname(path)));
} catch {
  console.error(
    'FAIL  The exported portal bundle is not present at apps/operator-portal/dist. This gate reads the ' +
    'artefact that ships, so it cannot run without it, and reporting that as a skip is defect 51. ' +
    'Run: npm run build:portal');
  process.exit(1);
}

if (distFiles.length === 0) {
  errors.push('apps/operator-portal/dist exists but contains no bundle, stylesheet or page to examine.');
}

const observedOrigins = new Map();
let bytesExamined = 0;
for (const path of distFiles) {
  const source = await readFile(path, 'utf8');
  bytesExamined += source.length;
  for (const match of source.matchAll(/\bhttps?:\/\/[A-Za-z0-9._-]+(?::\d+)?/g)) {
    const origin = match[0];
    if (!observedOrigins.has(origin)) observedOrigins.set(origin, new Set());
    observedOrigins.get(origin).add(relative(root, path).replaceAll('\\', '/'));
  }
}

let localOrigins = 0;
for (const [origin, inFiles] of observedOrigins) {
  const host = origin.replace(/^https?:\/\//, '');
  if (isLocalHost(host)) {
    localOrigins += 1;
    continue;
  }
  if (allowedOrigins.has(origin)) continue;
  errors.push(
    `The exported portal bundle names the public origin ${origin} (in ${[...inFiles].slice(0, 3).join(', ')}). ` +
    'CH1-OPS-FR-0001 forbids a public-internet dependency in a principal workflow. If this origin is inert - ' +
    'a namespace identifier, a documentation string in a library error - add it to allowedOrigins in this ' +
    'gate WITH the reason. If it is a service the portal would actually reach, it is an egress and has to go.');
}

// An allowlist entry for an origin the bundle no longer contains is a stale exemption, and
// a stale exemption is how a list stops describing the artefact it governs.
for (const origin of allowedOrigins.keys()) {
  if (!observedOrigins.has(origin)) {
    errors.push(
      `allowedOrigins exempts ${origin}, which the exported bundle no longer contains. Remove the ` +
      'exemption rather than leaving a permission nothing needs.');
  }
}

// The AI hosts, against the artefact rather than against the source. The static gate reads
// first-party files; a model endpoint arriving inside a dependency would appear only here.
const aiHosts = [
  'api.anthropic.com', 'api.openai.com', 'oai.azure.com', 'openai.azure.com',
  'generativelanguage.googleapis.com', 'aiplatform.googleapis.com', 'api.cohere.ai',
  'api.cohere.com', 'api.mistral.ai', 'api-inference.huggingface.co', 'api.groq.com',
  'api.together.xyz', 'api.replicate.com', 'api.perplexity.ai', 'api.deepseek.com',
  'api.x.ai', 'bedrock-runtime.',
];
for (const [origin] of observedOrigins) {
  for (const host of aiHosts) {
    if (origin.includes(host)) {
      errors.push(
        `The exported portal bundle names the AI service host ${origin}. access.json gives "Approve or ` +
        'command via AI" the role None at strength Not applicable, explicitly prohibited.');
    }
  }
}

// ---------------------------------------------------------------------------------------
// 4. The Expo auth proxy, and the two independent reasons it is unreachable.
//
// `auth.expo.io` is in the bundle because expo-auth-session carries it, and it would be
// used if - and only if - a redirect URI were built for the proxy. Two separate controls
// stop that, and this gate asserts BOTH, because either one alone is a single point of
// failure for a public-internet dependency in the sign-in path.
// ---------------------------------------------------------------------------------------

const session = await readFile(resolve(root, 'apps/operator-portal/src/auth/session.tsx'), 'utf8');
const redirectCalls = [...session.matchAll(/makeRedirectUri\(([^)]*)\)/g)].map((match) => match[1].trim());
if (redirectCalls.length === 0) {
  errors.push(
    'apps/operator-portal/src/auth/session.tsx no longer calls makeRedirectUri, so the check that it is ' +
    'called WITHOUT the hosted proxy established nothing.');
}
for (const argument of redirectCalls) {
  if (argument !== '') {
    errors.push(
      `makeRedirectUri is called with arguments (${argument}). It must be called with none: any option ` +
      "object is where useProxy would live, and the proxy is Expo's hosted public service at auth.expo.io.");
  }
}
if (/useProxy/.test(session)) {
  errors.push(
    "apps/operator-portal/src/auth/session.tsx mentions useProxy. Expo's auth proxy is a public-internet " +
    'host in the sign-in path, which CH1-OPS-FR-0001 forbids.');
}

// The second, independent reason: the controlled realm would refuse the redirect anyway.
const realm = JSON.parse(await readFile(resolve(root, 'infrastructure/keycloak/cinerion-realm.json'), 'utf8'));
const portalClient = (realm.clients ?? []).find((client) => client.clientId === 'cinerion-operator-portal');
if (!portalClient) {
  errors.push('The controlled realm declares no cinerion-operator-portal client, so the redirect check established nothing.');
}
const redirectUris = portalClient?.redirectUris ?? [];
const webOrigins = portalClient?.webOrigins ?? [];
if (redirectUris.length === 0) {
  errors.push('The portal client declares no redirectUris, so any redirect target would be refused or permitted by something this gate cannot see.');
}
for (const uri of [...redirectUris, ...webOrigins]) {
  const host = String(uri).replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!isLocalHost(host)) {
    errors.push(
      `The controlled realm permits the portal to redirect to "${uri}", whose host is not local. That is ` +
      'the second of the two controls that make a hosted auth proxy unreachable, and it has moved.');
  }
}

// ---------------------------------------------------------------------------------------
// 5. Telemetry off in the build path. Expo's CLI reports usage by default.
// ---------------------------------------------------------------------------------------

const verifySh = await readFile(resolve(root, 'scripts/verify.sh'), 'utf8');
if (!verifySh.includes('EXPO_NO_TELEMETRY=1')) {
  errors.push('scripts/verify.sh no longer sets EXPO_NO_TELEMETRY=1, so the portal build reports usage to a public host.');
}
const portalDockerfile = await readFile(resolve(root, 'apps/operator-portal/Dockerfile'), 'utf8');
if (!/EXPO_NO_TELEMETRY/.test(portalDockerfile)) {
  errors.push(
    'apps/operator-portal/Dockerfile does not set EXPO_NO_TELEMETRY, so the image build reports usage to a ' +
    'public host. The build happens inside the image, so setting it in verify.sh does not reach it.');
}

// ---------------------------------------------------------------------------------------
// Result.
// ---------------------------------------------------------------------------------------

if (errors.length > 0) {
  for (const error of errors) console.error(`FAIL  ${error}`);
  console.error(`\nPortal egress: ${errors.length} refusal(s).`);
  process.exit(1);
}

console.log(
  `Content-Security-Policy: ${directives.size} directives and ${policySourcesChecked} sources, every one a ` +
  "keyword, a data: URI or a local origin. default-src 'self', base-uri 'self', form-action 'self', " +
  "frame-ancestors 'none', and no 'unsafe-eval' anywhere.");
console.log(
  `Controlled build arguments: ${argsChecked} EXPO_PUBLIC_* values decided by infrastructure/compose.yaml ` +
  `(and ${argsDeferred} left to the environment), each decided one either empty, not a URL, or a local ` +
  'origin - and the Dockerfile derives connect-src from exactly these.');
console.log(
  `Exported bundle: ${distFiles.length} files, ${bytesExamined} characters, ${observedOrigins.size} distinct ` +
  `absolute origins. ${localOrigins} are local; the other ${observedOrigins.size - localOrigins} are ` +
  'allowlisted by name with a stated reason, and an exemption for an origin the bundle no longer contains ' +
  'is refused as a stale permission.');
console.log(
  `Hosted auth proxy: makeRedirectUri is called ${redirectCalls.length} time(s) with no arguments and the ` +
  `word useProxy appears nowhere, and the controlled realm permits ${redirectUris.length} redirect URI(s) ` +
  `and ${webOrigins.length} web origin(s), all local. Two independent reasons, both asserted.`);
console.log(
  'NOT ESTABLISHED by this gate: that a running browser makes no request to a public host. This reads the ' +
  'shipped artefact and the policy that governs it. The behavioural half for the SERVICE is ' +
  'scripts/check-offline-workflow.sh, which drives the controlled demonstration on a network proven to ' +
  'have no route out; there is no equivalent harness driving a real browser on such a network, and a ' +
  'browser run needs a person at the keyboard.');

// Controlled verification case this gate is offered as evidence for.
//   0080 - the portal half of "core demonstration completes without public internet": the
//          shipped bundle names no public origin that is not an inert identifier, the CSP
//          would refuse one, and the hosted auth proxy is unreachable for two independent
//          reasons.
console.log('VERIFICATION-CASE CH1-VVT-TC-0080');
