// Renders the operator portal's own screens and checks what they actually show.
//
// This closes the largest remaining hole in verification, which was never screen
// coverage. `npm run screens` counts which declared screens exist. `npm run
// contracts:portal` proves each field the portal reads is one the service really sends.
// `dotnet test` proves the service sends the right values. None of the three says
// anything about what an operator ends up looking at — and CH1-MON-FR-0003,
// CH1-COL-FR-0002 and CH1-UXD-DSG-0001 are statements about exactly that. Until now the
// only evidence for them was somebody driving a browser by hand, which cannot run in CI
// and needs a person to type a password.
//
// Each scenario mounts a shipped screen module in a DOM, answers its fetches from
// `artifacts/contracts/*.json` — real responses captured from a real service — and reads
// the rendered text back. Nothing about the screen is modified and nothing is mocked at
// the hook boundary: the screen's own `apiFetch`, `useObserved` and components all run.
//
// Every scenario runs in its own process, because the portal's modules are stateful at
// module scope in ways that are correct for a page load and wrong for a second test.

import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { readFile, readdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const runner = 'apps/operator-portal/harness/run.mjs';
const errors = [];

const screens = JSON.parse(
  await readFile(resolve(root, 'docs/baseline/P03_IFV/data/screens.json'), 'utf8'));
const declaredScreens = new Set(screens.map((row) => row[0]));

const controlledCases = JSON.parse(
  await readFile(resolve(root, 'docs/baseline/P03_IFV/data/tests.json'), 'utf8'));
const controlledCaseIds = new Set(controlledCases.map((row) => row[0]));

// The captured responses are written by PortalContractFixtureTests and are not committed
// (artifacts/ is ignored), so this gate runs after the .NET step. Saying so plainly beats
// five scenarios each failing to read the same missing directory.
if (!existsSync(resolve(root, 'artifacts/contracts'))) {
  console.error(
    'artifacts/contracts is absent, so there is nothing captured to render against. ' +
    'Run "dotnet test Cinerion.slnx -c Release" first; PortalContractFixtureTests writes it.');
  process.exit(1);
}

function run(args) {
  return new Promise((settle) => {
    const child = spawn(process.execPath, [runner, ...args], { cwd: root });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.on('close', (code) => settle({ code, stdout, stderr }));
  });
}

const listed = await run(['--list']);
if (listed.code !== 0) {
  console.error(`The scenario list could not be read.\n${listed.stdout}${listed.stderr}`);
  process.exit(1);
}

const scenarios = listed.stdout
  .split(/\r?\n/)
  .filter((line) => line.trim().length > 0)
  .map((line) => {
    const [id, screen, verificationCase, title] = line.split('\t');
    return { id, screen, verificationCase, title };
  });

if (scenarios.length === 0) {
  console.error('The portal render harness declares no scenarios, so it establishes nothing.');
  process.exit(1);
}

// A scenario claiming a screen the controlled register does not declare, or announcing a
// case the baseline does not contain, is the same class of error `npm run screens` and
// `npm run verification` each refuse one level up.
for (const scenario of scenarios) {
  if (!declaredScreens.has(scenario.screen)) {
    errors.push(`Scenario ${scenario.id} claims ${scenario.screen}, which screens.json does not declare.`);
  }
  if (scenario.verificationCase !== '-' && !controlledCaseIds.has(scenario.verificationCase)) {
    errors.push(
      `Scenario ${scenario.id} names verification case ${scenario.verificationCase}, ` +
      'which the controlled case list does not contain.');
  }
}

// Every screen that exists must be driven by at least one scenario.
//
// Coverage that is counted but not required is coverage that quietly regresses: a new
// route can be added, or an existing one left uncovered, and the gate would go on
// reporting a healthy number for the screens it happens to know about. The route sources
// declare what they implement — `npm run screens` already reconciles those declarations
// against the controlled register — so the set of built screens is knowable, and every one
// of them has to appear here.
const routeSources = await readdir(resolve(root, 'apps/operator-portal/src/app'));
const built = new Set();
for (const file of routeSources.filter((name) => name.endsWith('.tsx'))) {
  const routeSource = await readFile(resolve(root, 'apps/operator-portal/src/app', file), 'utf8');
  for (const [, id] of routeSource.matchAll(/^\s*\/\/ @screen (CH1-UX-SCR-\d{4})/gm)) {
    built.add(id);
  }
}
const driven = new Set(scenarios.map((scenario) => scenario.screen));
for (const id of [...built].sort()) {
  if (!driven.has(id)) {
    errors.push(
      `${id} is implemented by a portal route but no render scenario drives it. ` +
      'A screen that exists and is never rendered here is a screen whose behaviour nothing checks.');
  }
}

const announced = new Set();
let totalChecks = 0;
let failedScenarios = 0;

for (const scenario of scenarios) {
  const result = await run(['--scenario', scenario.id]);
  const output = `${result.stdout}${result.stderr}`;
  process.stdout.write(output.replace(/^onLayout relies on ResizeObserver.*$\r?\n?/gm, ''));

  const summary = output.match(/^\s+(\d+) checks, (\d+) failed/m);
  const checkCount = summary === null ? 0 : Number(summary[1]);
  totalChecks += checkCount;

  if (result.code !== 0) {
    failedScenarios += 1;
    errors.push(`Scenario ${scenario.id} failed.`);
    continue;
  }
  if (checkCount === 0) {
    errors.push(`Scenario ${scenario.id} passed while asserting nothing.`);
    continue;
  }
  for (const line of output.split(/\r?\n/)) {
    if (line.startsWith('VERIFICATION-CASE')) {
      for (const match of line.match(/CH1-VVT-TC-\d{4}/g) ?? []) announced.add(match);
    }
  }
}

if (errors.length > 0) {
  console.error(`\n${errors.join('\n')}`);
  process.exitCode = 1;
} else {
  const covered = [...new Set(scenarios.map((scenario) => scenario.screen))].sort();
  console.log(
    `\nPortal render gate: ${scenarios.length} scenarios, ${totalChecks} checks, ` +
    `${failedScenarios} scenarios failed. Screens exercised: ${covered.join(', ')}.`);
  console.log(
    'Rendered against responses captured from a real service by PortalContractFixtureTests; ' +
    'no screen, hook or API client was modified or mocked.');
  // Printed every run rather than left in a source comment: what was stood in for is part
  // of what this evidence is worth, and a reader of the output should not have to go
  // looking for it.
  const { STUBBED_MODULES } = await import('../apps/operator-portal/harness/loader.mjs');
  console.log(`Stood in for, each a host rather than a subject: ${Object.keys(STUBBED_MODULES).join(', ')}.`);
  console.log(
    'Authentication is not exercised here and is not claimed to be: the token is unsigned, ' +
    'the portal never verifies one, and Control Core re-evaluates scope on every request.');
  // Announced last, and only because every scenario above held.
  for (const testCaseId of [...announced].sort()) {
    console.log(`VERIFICATION-CASE ${testCaseId} exercised by the portal render harness.`);
  }
}
