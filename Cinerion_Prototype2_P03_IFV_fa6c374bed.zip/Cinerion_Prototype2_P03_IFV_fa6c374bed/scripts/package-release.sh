#!/usr/bin/env sh
# Packs a release archive with checksums. Secrets, keys and editor clutter stay home.
#
# Built from the COMMIT with git archive, not from whatever happens to be in the folder.
# That means no local secrets, build output, node_modules or scratch files can wander in,
# and the same commit always gives the same contents. It also means no `zip` program is
# needed: the first version of this script called one, and this workstation has never had
# it, so `npm run package:release` could not have worked here at all.
#
# Refuses to run with uncommitted changes, because they would silently be missing from the
# package, and a package that lacks your latest fix is worse than no package.
#
# The zip carries MANIFEST.sha256 (every file, sorted) and BUILD_INFO.txt (which commit).
# After building, it is unpacked again and every checksum is re-verified before it is
# published to release/.
#
# Usage: npm run package:release

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

if [ -n "$(git status --porcelain)" ]; then
  echo "FAIL  There are uncommitted changes. The package is built from the commit, so they" >&2
  echo "      would be missing from it. Commit or stash them first." >&2
  git status --short >&2
  exit 1
fi

commit=$(git rev-parse HEAD)
short=$(git rev-parse --short=10 HEAD)
name="Cinerion_Prototype2_P03_IFV_$short"
release_dir="$repo_dir/release"
final_archive="$release_dir/$name.zip"
working_dir=$(mktemp -d)

cleanup() { rm -rf "$working_dir"; }
trap cleanup EXIT HUP INT TERM

# Belt and braces. None of these should ever be tracked - the policy and AI gates refuse
# them - but the package leaves them out regardless. The committed MANIFEST.sha256 is an old
# snapshot; a fresh one is written below.
set -- . \
  ':(exclude)MANIFEST.sha256' \
  ':(exclude,glob)**/.claude/**' \
  ':(exclude,glob)**/.cursor/**' \
  ':(exclude,glob)**/.mcp.json' \
  ':(exclude,glob)**/AGENTS.md' \
  ':(exclude,glob)**/CLAUDE.md' \
  ':(exclude)infrastructure/.env.local' \
  ':(exclude,glob)infrastructure/secrets/**' \
  ':(exclude,glob)**/*.pem' \
  ':(exclude,glob)**/*.key' \
  ':(exclude,glob)**/*.pfx' \
  ':(exclude,glob)**/*.p12' \
  ':(exclude,glob)**/*.jks' \
  ':(exclude,glob)**/*.keystore' \
  ':(exclude,glob)**/*.pdf'

mkdir -p "$release_dir" "$working_dir/stage"

# 1. Unpack the commit once, to checksum exactly what will go in.
git archive --format=tar HEAD -- "$@" | tar -x -C "$working_dir/stage"

# The lab's data rides along when there's a snapshot of it (npm run lab:export). It isn't in
# git - it's generated, big and changes every five seconds - so it's added beside the commit,
# and lab-up.sh on the other machine loads it into the empty database there. No snapshot, no
# problem: the new lab just starts with fresh demonstration data.
snapshot_files="cinerion-lab-data.sql.gz counts.txt SNAPSHOT_INFO.txt"
has_snapshot=true
for f in $snapshot_files; do [ -f "lab-snapshot/$f" ] || has_snapshot=false; done
if [ "$has_snapshot" = true ]; then
  mkdir -p "$working_dir/stage/lab-snapshot"
  for f in $snapshot_files; do cp "lab-snapshot/$f" "$working_dir/stage/lab-snapshot/$f"; done
  snapshot_line="included - $(sed -n 's/^Rows: *//p' lab-snapshot/SNAPSHOT_INFO.txt) rows taken $(sed -n 's/^Taken (UTC): *//p' lab-snapshot/SNAPSHOT_INFO.txt), restored on first install"
  echo "      carrying the lab data snapshot: $snapshot_line"
else
  snapshot_line="none - the lab starts with fresh demonstration data (npm run lab:export makes one)"
  echo "      no lab data snapshot (npm run lab:export); the package will start with fresh demonstration data"
fi

version=$(node -e "process.stdout.write(require('./package.json').version)")
cat > "$working_dir/stage/BUILD_INFO.txt" <<EOF
Cinerion - Prototype 2 working build against the P03/IFV baseline

Commit:          $commit
Branch:          $(git rev-parse --abbrev-ref HEAD)
Built (UTC):     $(date -u +%Y-%m-%dT%H:%M:%SZ)
Version string:  $version  (what the code reports; unchanged by this build)
Lab data:        $snapshot_line

Install:  Windows  ->  double-click install.cmd
          Linux / macOS / WSL  ->  sh install.sh
Details:  INSTALL.md
Checks:   every file below this folder is listed in MANIFEST.sha256
EOF

(
  cd "$working_dir/stage"
  find . -type f ! -name MANIFEST.sha256 -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
) > "$working_dir/MANIFEST.sha256"
cp "$working_dir/stage/BUILD_INFO.txt" "$working_dir/BUILD_INFO.txt"
files=$(wc -l < "$working_dir/MANIFEST.sha256" | tr -d ' ')

# 2. The zip itself, straight from the commit plus the generated files. Each --add-file lands
#    under the --prefix in force just before it; tracked files take the LAST one, which is why
#    the snapshot's list ends by switching back to "$name/".
if [ "$has_snapshot" = true ]; then
  git archive --format=zip --prefix="$name/" \
    --add-file="$working_dir/BUILD_INFO.txt" \
    --add-file="$working_dir/MANIFEST.sha256" \
    --prefix="$name/lab-snapshot/" \
    --add-file="$working_dir/stage/lab-snapshot/cinerion-lab-data.sql.gz" \
    --add-file="$working_dir/stage/lab-snapshot/counts.txt" \
    --add-file="$working_dir/stage/lab-snapshot/SNAPSHOT_INFO.txt" \
    --prefix="$name/" \
    -o "$working_dir/$name.zip" HEAD -- "$@"
else
  git archive --format=zip --prefix="$name/" \
    --add-file="$working_dir/BUILD_INFO.txt" \
    --add-file="$working_dir/MANIFEST.sha256" \
    -o "$working_dir/$name.zip" HEAD -- "$@"
fi

# 3. Trust nothing: unpack it again and check every file against the manifest.
unzip -tqq "$working_dir/$name.zip"
mkdir "$working_dir/check"
unzip -qq "$working_dir/$name.zip" -d "$working_dir/check"
( cd "$working_dir/check/$name" && sha256sum -c --quiet MANIFEST.sha256 ) || {
  echo "FAIL  the archive does not match its own manifest" >&2
  exit 1
}

mv -f "$working_dir/$name.zip" "$final_archive"
( cd "$release_dir" && sha256sum "$name.zip" > "$name.zip.sha256" )

size=$(du -h "$final_archive" | cut -f1)
echo "PASS  $files files packed from commit $short, every checksum re-verified after unpacking"
echo "$final_archive ($size)"
