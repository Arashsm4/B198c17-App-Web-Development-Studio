#!/usr/bin/env sh
# CH1-VVT-TC-0081 — "Restored system passes integrity and functional smoke tests."
#
# CH1-OPS-FR-0002 is a Must with a verification method of Test, and until now nothing
# executed it: the durability observations in the progress document are service restarts,
# which prove that state was written, not that it can be recovered from an artefact.
#
# This does the real thing, end to end, and asserts what actually matters afterwards:
#
#   1. a source database is raised and migrated, and Control Core is run against it;
#   2. controlled records are produced through the ordinary API, so the audit chain has
#      genuinely linked events rather than rows somebody inserted;
#   3. scripts/backup.sh takes the backup and its manifest;
#   4. the backup is attacked -- one byte altered -- and scripts/restore.sh must refuse it;
#   5. a fresh, empty database is raised and the intact backup restored into it;
#   6. Control Core is run against the restored database and asked to verify the audit
#      chain. This is the integrity smoke test, and it is a sharp one: the chain is
#      hash-linked over field values including timestamps, and defect 15 in this
#      repository was exactly a storage round trip breaking it. A dump and restore
#      re-parses every timestamptz;
#   7. the controlled records are compared with what was recorded before the backup;
#   8. a new controlled write succeeds and chains onto the restored chain -- the
#      functional half, because a database that can be read but not written to is not a
#      restored system;
#   9. an event in the restored chain is altered directly in the database, and the chain
#      must then fail verification and say where. Without this the smoke test could be
#      passing for the same reason a broken regex passes: by never being able to fail.
#
# It is heavy -- two PostgreSQL containers and two service starts -- so it runs on demand
# and in CI rather than inside verify.sh, exactly as npm run audit:deps does.
#
# Usage: scripts/check-backup-restore.sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

image=postgres:18.4-alpine3.24
source_container=cinerion-backup-source
target_container=cinerion-backup-target
source_port=55440
target_port=55441
# Kestrel is told to take any free port. A fixed one is not safe on Windows: Hyper-V
# reserves large blocks of the 5000-5700 range at boot, a bind into one of them fails
# with SocketException 10013, and the excluded ranges move between reboots. Dynamic
# binding is refused on the "localhost" name - Kestrel requires the literal - so the
# service BINDS 127.0.0.1 and is ADDRESSED as localhost, because AllowedHosts=localhost
# answers the literal with 400.
api_url=""
work_dir="$repo_dir/artifacts/backup-verification"
owner_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
app_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)

project_id=00000000-0000-4000-8000-000000000101
cell_id=00000000-0000-4000-8000-000000000103
part_id=00000000-0000-4000-8000-000000000106
revision_id=00000000-0000-4000-8000-000000000109

api_pid=""
failures=0

log() { printf '%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

cleanup() {
  [ -n "$api_pid" ] && kill "$api_pid" 2>/dev/null || true
  docker rm -f "$source_container" "$target_container" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

require_docker() {
  if ! docker version >/dev/null 2>&1; then
    echo "check-backup-restore.sh: the Docker daemon is unreachable. This gate restores a real" >&2
    echo "database into a real database; there is no meaningful way to run it without one." >&2
    exit 1
  fi
}

start_database() {
  name=$1
  port=$2
  docker rm -f "$name" >/dev/null 2>&1 || true
  docker run -d --name "$name" \
    -e POSTGRES_DB=cinerion \
    -e POSTGRES_USER=cinerion_owner \
    -e POSTGRES_PASSWORD="$owner_password" \
    -p "127.0.0.1:$port:5432" "$image" >/dev/null
  # The postgres image runs a temporary server during initialisation and then shuts it
  # down, so a single successful probe means nothing: the first pg_isready lands on the
  # init server and the next statement meets "the database system is shutting down".
  # Readiness is therefore three consecutive successful connections one second apart.
  attempt=0
  settled=0
  while [ "$settled" -lt 3 ]; do
    if docker exec "$name" psql -U cinerion_owner -d cinerion -tAc "select 1" >/dev/null 2>&1; then
      settled=$((settled + 1))
    else
      settled=0
    fi
    attempt=$((attempt + 1))
    [ "$attempt" -gt 90 ] && { echo "$name did not become ready." >&2; exit 1; }
    sleep 1
  done
}

migrate() {
  name=$1
  for migration in services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/*.sql; do
    docker exec -i "$name" psql -U cinerion_owner -d cinerion --set ON_ERROR_STOP=on --quiet \
      < "$migration" > /dev/null
  done
  docker exec "$name" psql -U cinerion_owner -d cinerion -qc \
    "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password';" > /dev/null
}

start_api() {
  port=$1
  # Connect as cinerion_app, never as the bootstrap owner: the owner is a superuser and
  # bypasses every row-level security policy, so isolation would appear to work while
  # doing nothing. Host=127.0.0.1 avoids the Windows name-resolution fault that surfaces
  # as intermittent 500s under polling.
  CINERION_DATABASE_MODE=Postgres \
  CINERION_POSTGRES_CONNECTION="Host=127.0.0.1;Port=$port;Database=cinerion;Username=cinerion_app;Password=$app_password" \
  CINERION_ALLOW_DEVELOPMENT_IDENTITY=true \
  CINERION_RUNTIME_PROFILE=Simulation \
  CINERION_SIMULATED_TELEMETRY=false \
  ASPNETCORE_ENVIRONMENT=Development \
    dotnet run --project services/control-core/src/Cinerion.Api \
    --no-launch-profile --urls "http://127.0.0.1:0" > "$work_dir/api.log" 2>&1 &
  api_pid=$!
  api_url=""
  attempt=0
  while [ -z "$api_url" ]; do
    api_port=$(sed -n 's|.*Now listening on: http://127\.0\.0\.1:\([0-9][0-9]*\).*|\1|p' "$work_dir/api.log" | head -1)
    [ -n "$api_port" ] && api_url="http://localhost:$api_port"
    [ -n "$api_url" ] && break
    attempt=$((attempt + 1))
    if [ "$attempt" -gt 90 ]; then
      echo "Control Core never reported a listening address. Last lines of its log:" >&2
      tail -20 "$work_dir/api.log" >&2
      exit 1
    fi
    sleep 1
  done
  attempt=0
  until curl --silent --fail --max-time 2 "$api_url/api/v1/system/health" >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ "$attempt" -gt 90 ]; then
      echo "Control Core did not start. Last lines of its log:" >&2
      tail -20 "$work_dir/api.log" >&2
      exit 1
    fi
    sleep 1
  done
}

stop_api() {
  [ -n "$api_pid" ] && kill "$api_pid" 2>/dev/null || true
  api_pid=""
  sleep 3
}

# Every request is made by a named identity with an explicit scope, exactly as a real
# caller is: nothing here reaches around the service into the database to create records.
call() {
  method=$1; path=$2; body=${3:-}
  if [ -n "$body" ]; then
    curl --silent --show-error --request "$method" \
      -H "X-CH1-Actor: USR-BACKUP-VERIFY" -H "X-CH1-Project: $project_id" \
      -H "X-CH1-Roles: Engineer,Inspector,Auditor,ProjectManager" -H "X-CH1-Cells: $cell_id" \
      -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-backup" \
      -H "Content-Type: application/json" --data "$body" "$api_url$path"
  else
    curl --silent --show-error --request "$method" \
      -H "X-CH1-Actor: USR-BACKUP-VERIFY" -H "X-CH1-Project: $project_id" \
      -H "X-CH1-Roles: Engineer,Inspector,Auditor,ProjectManager" -H "X-CH1-Cells: $cell_id" \
      -H "X-CH1-Auth-Strength: StepUpPhishingResistant" -H "X-CH1-Session: session-backup" \
      "$api_url$path"
  fi
}

json() { node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{try{const v=JSON.parse(s);const r=$1;console.log(r===undefined||r===null?'':r)}catch{console.log('')}})"; }

sql() { docker exec "$1" psql -U cinerion_owner -d cinerion -tAc "$2" | tr -d ' \r'; }

# --------------------------------------------------------------------------------------

require_docker
rm -rf "$work_dir"
mkdir -p "$work_dir"

log "[1/9] Raising the source database and applying every controlled migration"
start_database "$source_container" "$source_port"
migrate "$source_container"
log "      $(sql "$source_container" "select count(*) from information_schema.tables where table_schema='ch1'") controlled tables"

log "[2/9] Producing controlled records through the ordinary API"
start_api "$source_port"

run_id=$(call POST /api/v1/test-runs \
  "{\"partId\":\"$part_id\",\"procedureId\":\"CH1-REFAB-PROC-0001\",\"procedureRevision\":\"R01\"}" \
  | json "v.testRunId")
[ -n "$run_id" ] || { fail "the source system could not start a test run; there is nothing to back up"; exit 1; }

call POST "/api/v1/test-runs/$run_id/measurements" \
  "{\"partId\":\"$part_id\",\"characteristic\":\"Coating thickness\",\"value\":10.1,\"unit\":\"um\",\"lowerLimit\":9.5,\"upperLimit\":10.5,\"mandatory\":true,\"sourceDeviceId\":\"CH1-INS-THK-0001\",\"calibrationRecordId\":\"00000000-0000-4000-8000-000000000108\",\"calibrationValid\":true}" \
  > /dev/null

call POST /api/v1/work-orders \
  "{\"workOrderNumber\":\"WO-BACKUP-0001\",\"revisionId\":\"$revision_id\",\"cellId\":\"$cell_id\",\"quantity\":1}" \
  > /dev/null

before_chain=$(call POST /api/v1/audit/chain-verifications "{}")
before_valid=$(printf '%s' "$before_chain" | json "v.valid")
before_checked=$(printf '%s' "$before_chain" | json "v.checked")
before_measurements=$(sql "$source_container" "select count(*) from ch1.measurements")
before_audit=$(sql "$source_container" "select count(*) from ch1.audit_events")

if [ "$before_valid" = "true" ]; then
  pass "the source chain verifies before the backup ($before_checked events checked, $before_audit stored)"
else
  fail "the source chain does not verify, so nothing after this would mean anything"
fi

# Everything below is about recovering records from an artefact, so a source database
# holding no records would make every later check pass while proving nothing. This caught
# a real mistake while the gate was being written: the storage-mode variable was named
# wrongly, the service fell back to in-memory storage -- which is permitted in
# Development -- and the backup was of an empty database that restored perfectly.
if [ "$before_audit" -lt 1 ] || [ "$before_measurements" -lt 1 ]; then
  fail "the source database holds $before_audit audit events and $before_measurements measurements."
  echo "      The service is not writing to PostgreSQL, so this would back up an empty database" >&2
  echo "      and every check after it would pass for the wrong reason." >&2
  exit 1
fi
pass "the records are in the source database, not only in the service: $before_audit audit events, $before_measurements measurements"

log "[3/9] Taking the backup"
./scripts/backup.sh --container "$source_container" --out "$work_dir" --label verification
backup="$work_dir/cinerion-verification.sql"
manifest="$work_dir/cinerion-verification.manifest.json"
[ -f "$backup" ] && [ -f "$manifest" ] || { fail "no backup artefact was written"; exit 1; }

stop_api

log "[4/9] Attacking the backup: one altered byte must be refused"
cp "$backup" "$work_dir/cinerion-tampered.sql"
cp "$manifest" "$work_dir/cinerion-tampered.manifest.json"
printf '\n-- an alteration nobody recorded\n' >> "$work_dir/cinerion-tampered.sql"

log "[5/9] Raising a fresh, empty target database"
start_database "$target_container" "$target_port"
empty_tables=$(sql "$target_container" "select count(*) from information_schema.tables where table_schema='ch1'")
if [ "$empty_tables" = "0" ]; then
  pass "the target database is genuinely empty ($empty_tables controlled tables), so what follows is a restore and not a no-op"
else
  fail "the target database already holds $empty_tables controlled tables"
fi

if ./scripts/restore.sh --backup "$work_dir/cinerion-tampered.sql" --container "$target_container" \
     > "$work_dir/tampered.log" 2>&1; then
  fail "the altered backup was RESTORED. The integrity check does not work."
else
  if grep -q "INTEGRITY CHECK FAILED" "$work_dir/tampered.log"; then
    pass "the altered backup was refused, naming the checksum mismatch"
  else
    fail "the altered backup was refused, but not for the integrity reason: $(head -3 "$work_dir/tampered.log")"
  fi
fi

still_empty=$(sql "$target_container" "select count(*) from information_schema.tables where table_schema='ch1'")
if [ "$still_empty" = "0" ]; then
  pass "the refused restore wrote nothing: the target is still empty"
else
  fail "the refused restore left $still_empty tables behind"
fi

log "[6/9] Restoring the intact backup"
./scripts/restore.sh --backup "$backup" --container "$target_container" | sed 's/^/      /'
restored_tables=$(sql "$target_container" "select count(*) from information_schema.tables where table_schema='ch1'")

# Defect 13 was the application role not existing, which left every row-level security
# policy inert while appearing to be in force. A restored database in that state would
# pass every functional check below and have no project isolation at all, so it is
# asserted rather than assumed.
role_attributes=$(sql "$target_container"   "select rolsuper::text || rolbypassrls::text from pg_roles where rolname='cinerion_app'")
if [ "$role_attributes" = "falsefalse" ]; then
  pass "the restored database has the controlled application role, NOSUPERUSER and NOBYPASSRLS"
else
  fail "the restored application role reports super/bypassrls '$role_attributes'; isolation would be inert"
fi

# The password is the one thing a backup deliberately never carries.
docker exec "$target_container" psql -U cinerion_owner -d cinerion -qc   "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password';" > /dev/null

log "[7/9] Integrity smoke test on the restored system"
start_api "$target_port"

after_chain=$(call POST /api/v1/audit/chain-verifications "{}")
after_valid=$(printf '%s' "$after_chain" | json "v.valid")
after_measurements=$(sql "$target_container" "select count(*) from ch1.measurements")
after_audit=$(sql "$target_container" "select count(*) from ch1.audit_events")

if [ "$after_valid" = "true" ]; then
  pass "the restored audit chain verifies -- the hash linkage survived the dump and reload"
else
  fail "the restored audit chain does NOT verify; restored evidence is not the evidence recorded"
fi

[ "$after_audit" = "$before_audit" ] \
  && pass "every audit event survived: $after_audit before and after" \
  || fail "audit events: $before_audit before, $after_audit after"

[ "$after_measurements" = "$before_measurements" ] \
  && pass "every measurement survived: $after_measurements before and after" \
  || fail "measurements: $before_measurements before, $after_measurements after"

genealogy=$(call GET "/api/v1/parts/$part_id/genealogy")
serial=$(printf '%s' "$genealogy" | json "v.part.serialNumber")
if [ -n "$serial" ]; then
  pass "the part's permanent identity is readable through the API after the restore: $serial"
else
  fail "the restored system could not answer for the part's genealogy"
fi

log "[8/9] Functional smoke test: the restored system still accepts controlled work"
new_run=$(call POST /api/v1/test-runs \
  "{\"partId\":\"$part_id\",\"procedureId\":\"CH1-REFAB-PROC-0001\",\"procedureRevision\":\"R01\"}" \
  | json "v.testRunId")
grown_audit=$(sql "$target_container" "select count(*) from ch1.audit_events")

if [ -n "$new_run" ]; then
  pass "a new controlled record was written after the restore ($new_run)"
else
  fail "the restored system is readable but will not accept new controlled work"
fi

chained=$(call POST /api/v1/audit/chain-verifications "{}" | json "v.valid")
if [ "$chained" = "true" ] && [ "$grown_audit" -gt "$after_audit" ]; then
  pass "the new event chained onto the restored chain, which still verifies ($after_audit -> $grown_audit)"
else
  fail "the chain did not extend cleanly after the restore (valid=$chained, $after_audit -> $grown_audit)"
fi

log "[9/9] Attacking the restored evidence: an altered event must break verification"
# Directly in the database, bypassing the append-only trigger the way only somebody with
# owner rights could. If verification still says "valid" after this, it is not checking.
#
# The alteration is asserted rather than assumed. The first attempt here set decision to
# 'Allowed' on an event whose decision was already 'Allowed', so nothing changed and the
# chain quite correctly still verified -- a check that cannot fail is exactly what the
# working method in this repository says to look for.
before_reason=$(sql "$target_container"   "select reason_code from ch1.audit_events order by sequence_number limit 1")

docker exec "$target_container" psql -U cinerion_owner -d cinerion --set ON_ERROR_STOP=on -qc   "ALTER TABLE ch1.audit_events DISABLE TRIGGER USER;
   UPDATE ch1.audit_events SET reason_code = reason_code || '-TAMPERED'
     WHERE event_id = (SELECT event_id FROM ch1.audit_events ORDER BY sequence_number LIMIT 1);
   ALTER TABLE ch1.audit_events ENABLE TRIGGER USER;" > /dev/null

after_reason=$(sql "$target_container"   "select reason_code from ch1.audit_events order by sequence_number limit 1")

if [ "$before_reason" = "$after_reason" ]; then
  fail "the alteration did not take effect ('$before_reason' unchanged), so this attack proves nothing"
else
  tampered_result=$(call POST /api/v1/audit/chain-verifications "{}")
  tampered_valid=$(printf '%s' "$tampered_result" | json "v.valid")
  tampered_at=$(printf '%s' "$tampered_result" | json "v.failureAt")
  if [ "$tampered_valid" = "false" ]; then
    pass "'$before_reason' altered to '$after_reason' breaks verification at position $tampered_at -- the integrity test can actually fail"
  else
    fail "'$before_reason' was altered to '$after_reason' and the chain still verified as '$tampered_valid'."
  fi
fi

stop_api

echo
if [ "$failures" -eq 0 ]; then
  echo "Backup, integrity verification, restore and rollback: verified end to end."
  echo "  source        : $before_audit audit events, $before_measurements measurements"
  echo "  restored into : a database that held $empty_tables controlled tables, now $restored_tables"
  echo "  refused       : an altered backup, before writing anything"
  echo "  proven to fail: an altered restored event"
  echo "VERIFICATION-CASE CH1-VVT-TC-0081"
  exit 0
fi

echo "$failures check(s) failed. CH1-VVT-TC-0081 is not satisfied and is not announced."
exit 1
