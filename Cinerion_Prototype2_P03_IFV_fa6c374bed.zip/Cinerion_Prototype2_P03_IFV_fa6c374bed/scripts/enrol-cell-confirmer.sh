#!/usr/bin/env sh
# Enrols the stand-in cell controller's certificate in a running lab.
#
# WHY THIS IS A SCRIPT AND NOT A SEED. A certificate alone authenticates nothing: Control
# Core resolves a presented certificate's thumbprint to an ENROLLED device record and takes
# the project, the cell and the DeviceController role from that record. A device whose
# certificate has never been enrolled is refused, and so is one whose trust has been
# withdrawn - which is the control CH1-CYB-IAM-0001 asks for, not an inconvenience to work
# around. So the certificate has to go through the controlled enrolment operation, and that
# operation needs a Cybersecurity Administrator holding a phishing-resistant step-up.
#
# WHICH IS WHY THIS NEEDS THE DEVELOPMENT IDENTITY, AND WHY THAT IS NOT A HOLE. Obtaining a
# phishing-resistant step-up over OIDC requires a person at a keyboard presenting a passkey;
# a lab bootstrap cannot do that and must not pretend to. So this runs against a
# SEPARATE, short-lived Control Core on the SAME database, started with development identity
# enabled and reachable only on loopback for the seconds it takes. The lab's own Control
# Core keeps CINERION_ALLOW_DEVELOPMENT_IDENTITY=false throughout and is never touched.
#
# The alternative - enrolling by writing a row into ch1.devices directly - would bypass
# every check the enrolment operation performs: that the certificate names the device, that
# its key is large enough, that its lifetime is bounded, that the thumbprint is computed
# from the bytes rather than supplied, and that a certificate already belonging to another
# device is refused. Going through the operation is the point.
#
# Usage: scripts/enrol-cell-confirmer.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

secrets="infrastructure/.env.local"
pki="infrastructure/secrets/device"
controller_id=${CINERION_CONFIRMER_CONTROLLER_ID:-CH1-DEV-CELL-0001}
project_id=00000000-0000-4000-8000-000000000101
cell_id=00000000-0000-4000-8000-000000000103

fail() { printf 'FAIL  %s\n' "$*" >&2; exit 1; }
pass() { printf 'PASS  %s\n' "$*"; }

[ -f "$pki/cell-confirmer.crt" ] || fail "$pki/cell-confirmer.crt is absent. Run scripts/bootstrap-device-pki.sh."
[ -f "$secrets" ] || fail "$secrets is absent. Run scripts/bootstrap-local.ps1 first."

read_secret() { grep "^$1=" "$secrets" | head -1 | cut -d= -f2-; }
app_password=$(read_secret CINERION_APP_PASSWORD)
[ -n "$app_password" ] || fail "CINERION_APP_PASSWORD is not in $secrets"

# The lab's PostgreSQL publishes no host port - the data network is internal: true - so the
# short-lived service is started INSIDE the lab's own network and talks to `postgres` by
# name, exactly as the real Control Core does.
compose() {
  docker compose --env-file "$secrets" \
    -f infrastructure/compose.yaml -f infrastructure/compose.lab.yaml \
    --profile data-lab --profile identity-lab "$@"
}

if ! compose ps --status running --services 2>/dev/null | grep -q '^control-core$'; then
  fail "the lab is not running. Raise it with npm run lab:up."
fi

# Already enrolled? The operation refuses a re-presented certificate with
# DEVICE_CERTIFICATE_UNCHANGED, which makes re-enrolment a decision rather than a repeat -
# so a second run of this script is not an error and does not need to be one.
attempt_enrolment() {
certificate=$(awk 'BEGIN{ORS="\\n"} {print}' "$pki/cell-confirmer.crt")

# ...but the refusal can't be SEEN from in here: busybox wget prints only "400 Bad Request"
# on failure, never the body carrying DEVICE_CERTIFICATE_UNCHANGED. So every re-run of the
# installer reported "FAIL the stand-in controller could not be enrolled" for a controller
# that was enrolled and working. Ask first instead: read the device record and compare its
# thumbprint with this certificate's. The server's thumbprint is lowercase hex SHA-256 of the
# certificate bytes, which openssl reproduces on any platform.
thumbprint=$(openssl x509 -in "$pki/cell-confirmer.crt" -noout -fingerprint -sha256 \
  | sed 's/.*=//; s/://g' | tr 'ABCDEF' 'abcdef')

enrol_port=15080
printf 'Enrolling %s through the controlled operation…\n' "$controller_id"

# One container, one purpose, removed on exit. `--rm` and a fixed name so an interrupted
# run leaves nothing behind holding a port or a connection.
output=$(compose run --rm --name cinerion-enrol-confirmer \
  -e CINERION_ALLOW_DEVELOPMENT_IDENTITY=true \
  -e ASPNETCORE_HTTP_PORTS="$enrol_port" \
  -e CINERION_DEVICE_MTLS_PORT= \
  -e CINERION_DEVICE_MTLS_CA_CERT= \
  -e CINERION_DEVICE_MTLS_SERVER_CERT= \
  -e CINERION_DEVICE_MTLS_SERVER_KEY= \
  -e CINERION_DEVICE_MTLS_PROJECT_ID= \
  --entrypoint /bin/sh control-core -c "
    set -eu
    dotnet /app/Cinerion.Api.dll --no-launch-profile >/tmp/enrol.log 2>&1 &
    api=\$!
    ready=false
    i=0
    while [ \$i -lt 60 ]; do
      if wget -qO- http://localhost:$enrol_port/api/v1/system/health >/dev/null 2>&1; then ready=true; break; fi
      sleep 1
      i=\$((i + 1))
    done
    if [ \"\$ready\" != true ]; then echo 'ENROL-FAIL the short-lived service did not start'; tail -20 /tmp/enrol.log; exit 1; fi

    existing=\$(wget -qO- \
      --header 'X-CH1-Actor: USR-LAB-ENROL' \
      --header 'X-CH1-Project: $project_id' \
      --header 'X-CH1-Roles: Engineer' \
      --header 'X-CH1-Cells: $cell_id' \
      --header 'X-CH1-Auth-Strength: Mfa' \
      --header 'X-CH1-Session: session-USR-LAB-ENROL' \
      http://localhost:$enrol_port/api/v1/devices/$controller_id 2>/dev/null || true)
    case \"\$existing\" in
      *'\"certificateThumbprint\":\"$thumbprint\"'*)
        case \"\$existing\" in
          *'\"trusted\":true'*) echo 'ENROL-ALREADY'; kill \$api 2>/dev/null || true; exit 0 ;;
        esac ;;
    esac

    grant=\$(wget -qO- --header 'Content-Type: application/json' \
      --header 'X-CH1-Actor: USR-LAB-ENROL' \
      --header 'X-CH1-Project: $project_id' \
      --header 'X-CH1-Roles: CybersecurityAdministrator' \
      --header 'X-CH1-Cells: $cell_id' \
      --header 'X-CH1-Auth-Strength: StepUpPhishingResistant' \
      --header 'X-CH1-Session: session-USR-LAB-ENROL' \
      --post-data '{\"purpose\":\"DeviceTrust\"}' \
      http://localhost:$enrol_port/api/v1/auth/step-up \
      | sed -n 's/.*\"grantId\":\"\([0-9a-f-]*\)\".*/\1/p')
    if [ -z \"\$grant\" ]; then echo 'ENROL-FAIL no step-up grant was issued'; exit 1; fi

    body='{\"certificate\":\"$certificate\",\"schemaVersion\":\"1.0.0\",\"deviceType\":\"Esp32CellController\",\"firmwareVersion\":\"0.1.0-prototype.1\",\"configurationRevision\":\"CFG-REFAB-P01-R01\",\"telemetryChannels\":[{\"channelId\":\"temperature\",\"unit\":\"degC\"},{\"channelId\":\"humidity\",\"unit\":\"%RH\"},{\"channelId\":\"position\",\"unit\":\"mm\"},{\"channelId\":\"vibration_rms\",\"unit\":\"m/s2\"}],\"supportedCommands\":[\"RUN_COATING_CYCLE\"],\"securityProfile\":\"SIMULATION-NO-PHYSICAL-AUTHORITY\"}'
    wget -qO- --header 'Content-Type: application/json' \
      --header 'X-CH1-Actor: USR-LAB-ENROL' \
      --header 'X-CH1-Project: $project_id' \
      --header 'X-CH1-Roles: CybersecurityAdministrator' \
      --header 'X-CH1-Cells: $cell_id' \
      --header 'X-CH1-Auth-Strength: StepUpPhishingResistant' \
      --header 'X-CH1-Session: session-USR-LAB-ENROL' \
      --header \"X-CH1-Step-Up: \$grant\" \
      --post-data \"\$body\" \
      http://localhost:$enrol_port/api/v1/devices/$controller_id/enrolment 2>/tmp/enrol-http.log \
      && echo 'ENROL-OK' \
      || { grep -q 'DEVICE_CERTIFICATE_UNCHANGED' /tmp/enrol-http.log 2>/dev/null && echo 'ENROL-ALREADY' || { echo 'ENROL-FAIL'; cat /tmp/enrol-http.log; }; }
    kill \$api 2>/dev/null || true
  " 2>&1) || true
}

attempt_enrolment

# "Already enrolled" can't tell a current manifest from a stale one: the device endpoint's
# view leaves the capability manifest out (it's a secret-free summary, catalogue entry 14).
# So the first version of this check went looking for "temperature" in that view, never
# found it, and rotated the certificate on EVERY run. The database has the manifest the
# enrolment operation stored - a read-only look there answers it.
manifest_current() {
  answer=$(compose exec -T postgres psql -U cinerion_owner -d cinerion -tAc "select capability_manifest @> '{\"telemetryChannels\":[{\"channelId\":\"temperature\"},{\"channelId\":\"humidity\"},{\"channelId\":\"position\"},{\"channelId\":\"vibration_rms\"}]}' from ch1.devices where device_id = '$controller_id'" 2>/dev/null | tr -d '[:space:]')
  [ "$answer" = t ]
}
case "$output" in
  *ENROL-ALREADY*) manifest_current || output='ENROL-STALE' ;;
esac

# Enrolled with THIS certificate but an old manifest - the one-channel manifest earlier
# versions declared ("CH1-CH-TEMP-01"), which named no channel the simulated source publishes,
# so every reading was refused from the day of enrolment. The operation won't take the same
# certificate twice, so re-declaring means rotating: a new certificate for this controller only,
# re-enrolled through the same controlled operation, then the stand-in restarted to present it.
rotated=false
case "$output" in
  *ENROL-STALE*)
    echo "      $controller_id is enrolled with an out-of-date capability manifest; rotating its certificate to re-declare it"
    sh scripts/bootstrap-device-pki.sh --reissue-controller >/dev/null 2>&1 \
      || fail "could not reissue the controller's certificate"
    attempt_enrolment
    rotated=true
    ;;
esac

case "$output" in
  *ENROL-OK*)
    if [ "$rotated" = true ]; then
      compose restart cell-confirmer >/dev/null 2>&1 || true
      pass "$controller_id re-enrolled with a new certificate and the full channel manifest; the stand-in restarted to present it"
    else
      pass "$controller_id is enrolled; the stand-in controller can now authenticate"
    fi ;;
  *ENROL-ALREADY*)
    pass "$controller_id was already enrolled with this certificate" ;;
  *)
    printf '%s\n' "$output" >&2
    fail "the stand-in controller could not be enrolled" ;;
esac
