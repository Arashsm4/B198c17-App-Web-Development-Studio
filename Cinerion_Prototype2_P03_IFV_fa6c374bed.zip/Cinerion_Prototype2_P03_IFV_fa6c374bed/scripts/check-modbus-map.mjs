// Reconciles the two halves of the controlled Modbus register map.
//
// CH1-COM-ICD-0001 versions Modbus maps like software APIs, and CH1-COM-PRO-0001 states the
// three bands they must separate. The map is therefore a contract between two programs that
// share no code: EdgeLink's master and the controlled zone stand-in. Each holds its own
// copy, deliberately — EdgeLink must not reference a simulator, and a shared file would make
// "both ends agree" true by construction rather than by check.
//
// A map that drifted would not fail loudly. The gateway would read the right addresses of
// the wrong map and report plausible numbers about the wrong things, which is why the
// runtime version check alone is not enough: a same-version map with a moved address passes
// it. So this fails when
//
//   * a constant exists in one copy and not the other;
//   * the same constant holds different values in the two copies;
//   * the three bands overlap, so a register would belong to two of them;
//   * the handshake answer sits anywhere a write function could reach it;
//   * or a band is declared but nothing in the map is inside it.

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const gatewayPath = 'services/edge-link/src/Cinerion.EdgeLink/Protocols/Ch1ModbusMap.cs';
const controllerPath = 'simulators/modbus-plc/src/Cinerion.ModbusPlc/Ch1ModbusMap.cs';

const parse = (source) => new Map(
  [...source.matchAll(/public const ushort (\w+) = (\d+);/g)].map((match) => [match[1], Number(match[2])]));

const gateway = parse(await readFile(resolve(root, gatewayPath), 'utf8'));
const controller = parse(await readFile(resolve(root, controllerPath), 'utf8'));

if (gateway.size === 0 || controller.size === 0) {
  errors.push('No constants were parsed from one of the two map copies; this check would pass over nothing.');
}

for (const [name, value] of gateway) {
  if (!controller.has(name)) {
    errors.push(`${gatewayPath} declares ${name} and the controller's map does not.`);
  } else if (controller.get(name) !== value) {
    errors.push(
      `${name} is ${value} in the gateway's map and ${controller.get(name)} in the controller's. ` +
      'A moved address passes the runtime version check and reads the wrong register.');
  }
}

for (const name of controller.keys()) {
  if (!gateway.has(name)) {
    errors.push(`${controllerPath} declares ${name} and the gateway's map does not.`);
  }
}

// -- The bands do not overlap, and the answer band is out of every write's reach. --------

const at = (name) => gateway.get(name);
const bands = [
  { name: 'telemetry (input registers)', start: 0, end: at('TelemetrySampleCounter') },
  { name: 'handshake answer (input registers)', start: at('AnswerBandStart'), end: at('InputRegisterCount') - 1 },
  { name: 'configuration (holding registers, read-only)', start: at('ConfigurationBandStart'), end: at('ConfigurationBandEnd') },
  { name: 'handshake window (holding registers, writable)', start: at('HandshakeBandStart'), end: at('HandshakeBandEnd') },
];

for (const band of bands) {
  if (!Number.isInteger(band.start) || !Number.isInteger(band.end) || band.end < band.start) {
    errors.push(`The ${band.name} band is not a range: ${band.start}..${band.end}.`);
  }
}

// Within one register file, two bands may not overlap. Input and holding registers are
// separate address spaces in Modbus, so only same-file pairs are compared.
const files = [[bands[0], bands[1]], [bands[2], bands[3]]];
for (const [first, second] of files) {
  if (first.start <= second.end && second.start <= first.end) {
    errors.push(
      `The ${first.name} and ${second.name} bands overlap. A register in two bands is a ` +
      'register whose access rules depend on which check ran first.');
  }
}

// The load-bearing one. CH1-CYB-TMD-0001 names "direct Modbus write bypassing CommandGuard"
// as a priority threat, and the answer is that the guard's outputs are input registers,
// which no Modbus function code writes. If any of them were ever moved into the holding
// file, that whole argument would evaporate silently.
for (const name of [
  'AnswerState', 'AnswerReasonCode', 'AnswerAccepted', 'AnswerExecutePermit',
  'AnswerLastSequenceHigh', 'AnswerLastSequenceLow', 'AnswerCounter',
  'AnswerDeferredCheckCount', 'AnswerDeferredCheckFirst', 'AnswerDeferredCheckSecond',
]) {
  const address = at(name);
  if (address === undefined) {
    errors.push(`The map no longer declares ${name}.`);
    continue;
  }

  if (address < at('AnswerBandStart') || address >= at('InputRegisterCount')) {
    errors.push(`${name} is outside the input-register answer band, so a write function could reach it.`);
  }
}

// Every writable address must be inside the one writable window, and the window must not
// reach into configuration.
for (const [name, address] of gateway) {
  if (!name.startsWith('Handshake') || name.endsWith('Registers') || name === 'HandshakeTriggerEvaluate') {
    continue;
  }

  if (address < at('HandshakeBandStart') || address > at('HandshakeBandEnd')) {
    errors.push(`${name} is at ${address}, outside the declared writable window.`);
  }
}

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(
    `Modbus map reconciled: ${gateway.size} constants identical in both copies, ` +
    `map version ${at('MapVersion')}, four bands with no overlap.`);
  console.log(
    'The handshake answer, including the execute permit, is in input registers that no ' +
    'Modbus function code can write.');
}
