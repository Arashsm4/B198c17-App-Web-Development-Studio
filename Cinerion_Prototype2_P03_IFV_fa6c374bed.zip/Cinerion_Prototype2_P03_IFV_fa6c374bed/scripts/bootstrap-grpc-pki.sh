#!/usr/bin/env sh
# Generates the laboratory PKI the CH1-COM-IF-0003 internal gRPC edge needs, and the two
# certificates that exist only so the edge can be attacked.
#
# The interface register puts mutual TLS on CommandGuard-to-EdgeLink, and mutual means
# both directions: Control Core validates the gateway against this authority, and the
# gateway validates Control Core against the same one. Neither consults the machine trust
# store, so a certificate from a public authority carrying the right name is refused at
# both ends.
#
# Four artefacts are issued for the edge itself and two more purely for verification:
#
#   control-core   serverAuth. Carries subjectAltName entries for every name the gateway
#                  might address it by; without them the gateway cannot check that it
#                  reached the service it intended rather than one that merely holds a
#                  certificate this CA signed.
#   edgelink       clientAuth, CN = the gateway identity Control Core is configured to
#                  accept. The certificate is not merely authentication here: the common
#                  name IS the authorisation, exactly as it is on the MQTT topic ACL.
#   other-gateway  clientAuth, signed by this authority but issued to a DIFFERENT gateway.
#                  It exists so the gate can prove that trusting the authority and
#                  accepting the gateway are two independent controls, rather than one
#                  doing the work of both.
#   foreign        clientAuth, CN identical to the real gateway, signed by a SECOND
#                  authority this deployment knows nothing about. It exists so the gate can
#                  prove that identity is what this authority attested and not a name a
#                  client chose.
#
# This is a LABORATORY certificate authority. CH1-CYB-IAM-0001 keeps root credentials
# hardware-backed and issues certificates through a controlled provisioning ceremony; what
# is produced here exists to exercise the transport, and every artefact says so in its
# subject organisational unit.
#
# Output goes to infrastructure/secrets/grpc, which .gitignore excludes. No key is ever
# printed, committed, or written anywhere else.
#
# Usage: scripts/bootstrap-grpc-pki.sh [--force]
set -eu

# Git Bash rewrites any argument that looks like a POSIX path into a Windows one before the
# process sees it, so "/O=Cinerion/OU=…/CN=…" arrives at openssl as "C:/Program Files/Git/…"
# and the subject is rejected. Both variables are needed: the first governs MSYS2 builds,
# the second older MSYS. Harmless everywhere else.
MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out="$repo_dir/infrastructure/secrets/grpc"
force=false
[ "${1:-}" = "--force" ] && force=true

if [ -f "$out/ca.crt" ] && [ "$force" != true ]; then
  echo "gRPC laboratory PKI already present in $out. Pass --force to regenerate."
  exit 0
fi

mkdir -p "$out"
cd "$out"

gateway_cn=${CINERION_EDGE_GRPC_GATEWAY_IDENTITY:-ch1-edgelink}
service_cn=${CINERION_EDGE_GRPC_SERVICE_CN:-control-core}

echo "Generating the laboratory certificate authority for the internal gRPC edge…"
openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
  -keyout ca.key -out ca.crt \
  -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=Cinerion CH1 Internal Edge CA" \
  -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

# A second, entirely separate authority. Nothing in the deployment trusts it, which is the
# whole point: PROBE-02 presents a certificate it signed carrying the real gateway's common
# name, and the edge must still refuse.
echo "Generating a second authority this deployment does not trust…"
openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
  -keyout foreign-ca.key -out foreign-ca.crt \
  -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=Untrusted Authority For Verification" \
  -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

issue() {
  name=$1
  common_name=$2
  authority=$3
  extension=$4
  echo "Issuing $name as CN=$common_name from $authority…"
  openssl req -newkey rsa:3072 -sha256 -nodes \
    -keyout "$name.key" -out "$name.csr" \
    -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=$common_name"
  printf '%s\n' "$extension" > "$name.ext"
  openssl x509 -req -in "$name.csr" -CA "$authority.crt" -CAkey "$authority.key" -CAcreateserial \
    -out "$name.crt" -days 365 -sha256 -extfile "$name.ext"
  rm -f "$name.csr" "$name.ext"
}

# Every name the gateway could reasonably address Control Core by inside the control zone,
# plus loopback for a host-side run. A missing entry reads as an impersonation attempt.
issue control-core "$service_cn" ca "subjectAltName=DNS:$service_cn,DNS:control-core,DNS:localhost,IP:127.0.0.1
extendedKeyUsage=serverAuth
keyUsage=critical,digitalSignature,keyEncipherment"

# Client certificates carry clientAuth only. One that also asserted serverAuth could be
# presented by something impersonating Control Core.
issue edgelink "$gateway_cn" ca "extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

issue other-gateway "ch1-edgelink-elsewhere" ca "extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

# Same common name as the real gateway, different authority.
issue foreign "$gateway_cn" foreign-ca "extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

chmod 644 ./*.crt 2>/dev/null || true
chmod 600 ./*.key 2>/dev/null || true
rm -f ca.srl foreign-ca.srl

echo
echo "Laboratory PKI written to infrastructure/secrets/grpc (git-ignored):"
echo "  ca.crt               the trust anchor both ends validate against, and only it"
echo "  control-core.crt/key CN=$service_cn, serverAuth"
echo "  edgelink.crt/key     CN=$gateway_cn, clientAuth — the gateway identity"
echo "  other-gateway.crt/key trusted authority, different gateway — for PROBE-03"
echo "  foreign.crt/key      CN=$gateway_cn from an untrusted authority — for PROBE-02"
echo
echo "These are laboratory credentials for exercising the transport. CH1-CYB-IAM-0001"
echo "keeps real credentials hardware-backed and issued through a controlled ceremony."
