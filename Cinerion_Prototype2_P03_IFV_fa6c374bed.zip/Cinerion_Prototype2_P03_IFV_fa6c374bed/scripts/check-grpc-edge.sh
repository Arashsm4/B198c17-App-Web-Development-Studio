#!/usr/bin/env sh
# CH1-COM-IF-0003 — "CommandGuard to EdgeLink | Internal gRPC | Bidirectional | Protobuf | mTLS"
# CH1-VVT-TC-0025 — "Communication-loss recovery: no execution or unsafe resume; state
#                    reconciles explicitly."
# CH1-VVT-TC-0101 — "Cross-layer state correlation: equipment state, alarm, procedure and
#                    resource state correlate to one asset and transaction without
#                    contradiction."
#
# Four operational adapters produced real telemetry and real acknowledgements, and none of
# it reached the domain: EdgeLink proved its conformance at startup and then sat idle. This
# raises both services from the controlled compose model, on PostgreSQL, and verifies that
# the edge between them carries what it should and refuses what it should not.
#
# The load-bearing arrangement is that the in-process simulated telemetry source is turned
# OFF. Control Core can feed itself in the Simulation profile, and with that running,
# telemetry appearing in the database would be evidence of nothing. With it off, every
# sample and every permissive in this run arrived over CH1-COM-IF-0003 or did not arrive.
#
# It then does something no gate here has been able to do: prepares and cancels a real
# command on PostgreSQL. That path needs a cell reporting live permissives, which is exactly
# what this edge supplies, and it exercises both branches of SaveCommandAsync — fixed as
# defect 21 and never executed until now.
#
# Usage: scripts/check-grpc-edge.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

project=cinerion-grpc-verify
network="${project}_control"
client_image=curlimages/curl:8.11.1

project_id=00000000-0000-4000-8000-000000000101
site_id=00000000-0000-4000-8000-000000000102
cell_id=00000000-0000-4000-8000-000000000103

failures=0
log() { printf '\n%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

compose() {
  docker compose -p "$project" \
    -f infrastructure/compose.yaml -f infrastructure/compose.grpc-verify.yaml "$@"
}

cleanup() {
  compose --profile data-lab down -v --remove-orphans >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

if ! docker version >/dev/null 2>&1; then
  echo "check-grpc-edge.sh: the Docker daemon is unreachable. This gate runs a real Control" >&2
  echo "Core and a real gateway against it over mutual TLS; there is no meaningful way to" >&2
  echo "run it without one." >&2
  exit 1
fi

docker image inspect "$client_image" >/dev/null 2>&1 || docker pull -q "$client_image" >/dev/null
# A project left behind by an interrupted run would leave the gateway publishing into a
# database this run is about to recreate, which is the mistake the OPC UA gate had to learn.
cleanup

app_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)

log "[1/9] Laboratory PKI for the internal edge, including the certificates that must be refused"
./scripts/bootstrap-grpc-pki.sh > /dev/null
for artefact in ca.crt control-core.crt control-core.key edgelink.crt edgelink.key \
                other-gateway.crt other-gateway.key foreign.crt foreign.key; do
  [ -f "infrastructure/secrets/grpc/$artefact" ] || fail "missing PKI artefact: $artefact"
done
[ "$failures" -eq 0 ] && pass "one trusted authority, one untrusted authority, and a certificate this authority signed for another gateway"

CINERION_POSTGRES_PASSWORD=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
CINERION_DATABASE_MODE=Postgres
CINERION_POSTGRES_CONNECTION="Host=postgres;Port=5432;Database=cinerion;Username=cinerion_app;Password=$app_password"
CINERION_SIMULATED_TELEMETRY=false
CINERION_EDGE_GRPC_PORT=8443
CINERION_EDGE_GRPC_CA_CERT=/run/secrets/grpc/ca.crt
CINERION_EDGE_GRPC_SERVER_CERT=/run/secrets/grpc/control-core.crt
CINERION_EDGE_GRPC_SERVER_KEY=/run/secrets/grpc/control-core.key
CINERION_EDGE_GRPC_GATEWAY_IDENTITY=ch1-edgelink
CINERION_EDGE_GRPC_ENDPOINT=https://control-core:8443
CINERION_EDGE_GRPC_CLIENT_CERT=/run/secrets/grpc/edgelink.crt
CINERION_EDGE_GRPC_CLIENT_KEY=/run/secrets/grpc/edgelink.key
CINERION_EDGE_GRPC_PROJECT_ID=$project_id
CINERION_EDGE_GRPC_SITE_ID=$site_id
CINERION_EDGE_GRPC_CELL_ID=$cell_id
CINERION_EDGE_GRPC_CONTROLLER_ID=CH1-DEV-CELL-0001
CINERION_EDGE_GRPC_FOREIGN_CERT=/run/secrets/grpc/foreign.crt
CINERION_EDGE_GRPC_FOREIGN_KEY=/run/secrets/grpc/foreign.key
CINERION_EDGE_GRPC_OTHER_GATEWAY_CERT=/run/secrets/grpc/other-gateway.crt
CINERION_EDGE_GRPC_OTHER_GATEWAY_KEY=/run/secrets/grpc/other-gateway.key
export CINERION_POSTGRES_PASSWORD CINERION_DATABASE_MODE CINERION_POSTGRES_CONNECTION \
  CINERION_SIMULATED_TELEMETRY CINERION_EDGE_GRPC_PORT CINERION_EDGE_GRPC_CA_CERT \
  CINERION_EDGE_GRPC_SERVER_CERT CINERION_EDGE_GRPC_SERVER_KEY CINERION_EDGE_GRPC_GATEWAY_IDENTITY \
  CINERION_EDGE_GRPC_ENDPOINT CINERION_EDGE_GRPC_CLIENT_CERT CINERION_EDGE_GRPC_CLIENT_KEY \
  CINERION_EDGE_GRPC_PROJECT_ID CINERION_EDGE_GRPC_SITE_ID CINERION_EDGE_GRPC_CELL_ID \
  CINERION_EDGE_GRPC_CONTROLLER_ID CINERION_EDGE_GRPC_FOREIGN_CERT CINERION_EDGE_GRPC_FOREIGN_KEY \
  CINERION_EDGE_GRPC_OTHER_GATEWAY_CERT CINERION_EDGE_GRPC_OTHER_GATEWAY_KEY

log "[2/9] The verification overlay changes one thing, and is made to prove it"
overlay_diff=$(node -e '
const { execSync } = require("node:child_process");
const read = (args) => JSON.parse(execSync(`docker compose ${args} config --format json`, { maxBuffer: 64e6 }));
const base = read("-f infrastructure/compose.yaml --profile data-lab");
const merged = read("-f infrastructure/compose.yaml -f infrastructure/compose.grpc-verify.yaml --profile data-lab");
const differences = [];
for (const [name, service] of Object.entries(base.services)) {
  for (const key of Object.keys(service)) {
    if (key === "ports" && name === "control-core") continue;
    if (JSON.stringify(service[key]) !== JSON.stringify(merged.services[name]?.[key])) {
      differences.push(`${name}.${key}`);
    }
  }
}
console.log(differences.join(", "));
')
[ -z "$overlay_diff" ] \
  && pass "the overlay removes Control Core's published host port and changes nothing else" \
  || fail "the verification overlay also changes: $overlay_diff"

log "[3/9] Raising PostgreSQL and Control Core from the controlled compose model"
compose --profile data-lab up -d --build postgres > /dev/null 2>&1 || {
  fail "PostgreSQL could not be raised"; exit 1; }

# Three consecutive successful queries, not one. The entrypoint starts the server, runs
# every controlled migration against it and then restarts it, so a single ready answer is
# followed by "the database system is shutting down" and everything after it fails.
attempt=0
settled=0
while [ "$settled" -lt 3 ]; do
  if compose --profile data-lab exec -T postgres psql -U cinerion_owner -d cinerion -tAc "select 1" >/dev/null 2>&1; then
    settled=$((settled + 1))
  else
    settled=0
  fi
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "PostgreSQL never became ready"; exit 1; }
  sleep 2
done

# Migration 0002 declares the application role with no password, exactly as nothing else in
# the controlled schema carries a secret; the deployment assigns one from controlled storage.
compose --profile data-lab exec -T postgres psql -U cinerion_owner -d cinerion -qc \
  "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password';" > /dev/null

# A query that could not be ASKED is not an answer of any kind.
#
# This used to pipe psql straight into `tr`, which discards both the exit code and stderr, so
# a database that was briefly unreachable produced an EMPTY STRING — and the checks below
# compared that against "0". A strict run duly reported
#
#     FAIL   command(s) reached an executing or committed state across a communication loss
#
# with an empty count where the number should be, beside a psql "the database system is
# starting up". Nothing had executed; the gate simply could not see. A safety check that
# reads an unreadable answer as a violation is worse than one that misses a violation,
# because it teaches its readers to disbelieve it.
#
# PostgreSQL is legitimately unreachable for a moment while it starts, restarts or recovers,
# so those are retried. Anything else, or a transient that never clears, says so loudly and
# returns a value no numeric comparison can mistake for a count.
sql() {
  sql_attempt=0
  while :; do
    if sql_output=$(compose --profile data-lab exec -T postgres psql -U cinerion_owner -d cinerion -tAc "$1" 2>&1); then
      printf '%s' "$sql_output" | tr -d '\r '
      return 0
    fi
    case "$sql_output" in
      *'starting up'*|*'could not connect'*|*'connection to server'*|*'Connection refused'*|*'recovery mode'*)
        sql_attempt=$((sql_attempt + 1))
        [ "$sql_attempt" -gt 30 ] && break
        sleep 2
        ;;
      *) break ;;
    esac
  done
  printf 'FAIL  the database could not be queried, so nothing below it is an observation: %s\n' \
    "$(printf '%s' "$sql_output" | tr '\n' ' ' | cut -c1-160)" >&2
  printf 'DATABASE-UNREADABLE'
  return 1
}

tables=$(sql "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'ch1';")
[ -n "$tables" ] && [ "$tables" -ge 33 ] \
  && pass "every controlled migration applied on a fresh database: $tables tables in ch1" \
  || fail "the controlled schema is incomplete: $tables tables"

compose up -d --build control-core > /dev/null 2>&1 || { fail "Control Core could not be raised"; exit 1; }

# Headers carry no spaces so they survive the word splitting that lets a caller add its own.
headers="-HHost:localhost -HX-CH1-Actor:USR-GRPC-VERIFY -HX-CH1-Project:$project_id"
headers="$headers -HX-CH1-Roles:Engineer,Inspector,Auditor,Viewer -HX-CH1-Cells:$cell_id"
headers="$headers -HX-CH1-Auth-Strength:StepUpPhishingResistant -HX-CH1-Session:session-grpc-verify"
headers="$headers -HContent-Type:application/json"

api() {
  method=$1; path=$2; body=${3:-}; extra=${4:-}
  if [ -n "$body" ]; then
    # shellcheck disable=SC2086
    docker run --rm --network "$network" "$client_image" curl -sS --max-time 20 \
      -X "$method" $headers $extra --data "$body" "http://control-core:8080$path"
  else
    # shellcheck disable=SC2086
    docker run --rm --network "$network" "$client_image" curl -sS --max-time 20 \
      -X "$method" $headers $extra "http://control-core:8080$path"
  fi
}

json() { node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{try{const v=JSON.parse(s);const r=$1;console.log(r===undefined||r===null?'':r)}catch{console.log('')}})"; }

attempt=0
until api GET /api/v1/system/health 2>/dev/null | grep -q "status"; do
  attempt=$((attempt + 1))
  if [ "$attempt" -gt 60 ]; then
    fail "Control Core did not become healthy"
    compose logs control-core 2>&1 | tail -25 >&2
    exit 1
  fi
  sleep 2
done
pass "Control Core is serving on PostgreSQL with the CH1-COM-IF-0003 ingress raised"

log "[4/9] The cell before any controller has reported"
before=$(api GET "/api/v1/cells/$cell_id/state")
before_enable=$(printf '%s' "$before" | json "v.interlocks.startEnable")
before_reported=$(printf '%s' "$before" | json "v.permissivesReported")
[ "$before_enable" = "false" ] && [ "$before_reported" = "false" ] \
  && pass "no controller has reported, so the cell is not permissive and says its permissives were never answered" \
  || fail "a cell nothing has reported for is already permissive: startEnable=$before_enable reported=$before_reported"

log "[5/9] Attacking the ingress, before the gateway connects"
# Built before it is run, and that ordering is load-bearing. `compose run` uses whatever
# image already exists, so a probe run before the build would attack this deployment with
# the previous revision of the attacking client — which is how a probe suite silently stops
# testing the code it was changed to test.
compose build edge-link > /dev/null 2>&1 || { fail "the gateway image could not be built"; exit 1; }
probe_log=$(compose run --rm --no-deps edge-link --probe 2>&1 || true)
printf '%s\n' "$probe_log" | grep -E '^PROBE ' || true

for check in \
  PROBE-01-NO-CLIENT-CERTIFICATE-REFUSED \
  PROBE-02-FOREIGN-CERTIFICATE-REFUSED \
  PROBE-03-OTHER-GATEWAY-REFUSED \
  PROBE-04-PLAINTEXT-REFUSED \
  PROBE-05-CORRECT-GATEWAY-ACCEPTED \
  PROBE-06-REPLAYED-MESSAGE-REFUSED \
  PROBE-07-BACKDATED-REPORT-REFUSED \
  PROBE-08-SOURCE-IDENTITY-MISMATCH-REFUSED \
  PROBE-09-UNKNOWN-SCHEMA-REFUSED \
  PROBE-10-EXPIRED-MESSAGE-REFUSED \
  PROBE-11-UNENROLLED-DEVICE-REFUSED \
  PROBE-12-DEVICE-CELL-MISMATCH-REFUSED \
  PROBE-13-UNANSWERED-PERMISSIVES-NOT-PERMISSIVE \
  PROBE-14-UNCATALOGUED-CHANNEL-REFUSED \
  PROBE-15-UNIT-MISMATCH-REFUSED \
  PROBE-16-UNKNOWN-COMMAND-ACKNOWLEDGEMENT-REFUSED
do
  printf '%s' "$probe_log" | grep -q "PROBE PASS $check" \
    || fail "$check did not pass: $(printf '%s' "$probe_log" | grep "$check" || echo 'not reported at all')"
done

# The reason code PROBE-13 checks is a label. This is the property behind it, measured
# through the controlled API: the last controller report the probe left standing is one
# whose permissives were NOT answered, and the cell must therefore read as not permissive
# even though a live report is current. A gateway in front of a real S7-1200 G2 stand-in is
# in exactly this position, because the guard declares check 207 deferred.
unanswered=$(api GET "/api/v1/cells/$cell_id/state")
unanswered_enable=$(printf '%s' "$unanswered" | json "v.interlocks.startEnable")
unanswered_reported=$(printf '%s' "$unanswered" | json "v.permissivesReported")
unanswered_codes=$(printf '%s' "$unanswered" | json "(v.deferredCheckCodes||[]).join('/')")
[ "$unanswered_reported" = "false" ] && [ "$unanswered_enable" = "false" ] && [ "$unanswered_codes" = "206/207" ] \
  && pass "a current report whose permissives the controller did not answer leaves the cell not permissive, naming deferred checks $unanswered_codes" \
  || fail "unanswered permissives produced startEnable=$unanswered_enable reported=$unanswered_reported codes=$unanswered_codes"

log "[6/9] The gateway publishing into the domain"
compose up -d --build edge-link > /dev/null 2>&1

attempt=0
until compose logs edge-link 2>&1 | grep -q "published controller state"; do
  attempt=$((attempt + 1))
  if [ "$attempt" -gt 60 ]; then
    fail "the gateway never published controller state"
    compose logs edge-link 2>&1 | tail -25 >&2
    break
  fi
  sleep 2
done
gateway_log=$(compose logs edge-link 2>&1)
core_log=$(compose logs control-core 2>&1)

printf '%s' "$gateway_log" | grep -q "CH1-COM-IF-0003 ingress configured: https://control-core:8443/ as ch1-edgelink" \
  && pass "the gateway opened the edge as ch1-edgelink over mutual TLS against the controlled authority" \
  || fail "the gateway did not report a configured ingress"

printf '%s' "$gateway_log" | grep -q "Control Core answered CONTROLLER_REPORT_ACCEPTED" \
  && pass "Control Core accepted the controller's report and said so in a stable reason code" \
  || fail "no accepted controller report is evidenced in the gateway's log"

printf '%s' "$core_log" | grep -q "permissives reported=True" \
  && pass "Control Core recorded a report whose permissives the controller actually answered" \
  || fail "Control Core did not record answered permissives"

refused=$(printf '%s' "$gateway_log" | grep -c "REFUSED as" || true)
[ "$refused" -eq 0 ] \
  && pass "nothing the running gateway published was refused" \
  || fail "$refused publication(s) from the running gateway were refused"

log "[7/9] What reached the domain, read back through the controlled API"
sleep 8
state=$(api GET "/api/v1/cells/$cell_id/state")
freshness=$(printf '%s' "$state" | json "v.freshness")
start_enable=$(printf '%s' "$state" | json "v.interlocks.startEnable")
guard=$(printf '%s' "$state" | json "v.interlocks.guardHealthy")
reported=$(printf '%s' "$state" | json "v.permissivesReported")
state_hash=$(printf '%s' "$state" | json "v.stateHash")
operating=$(printf '%s' "$state" | json "v.state")

[ "$start_enable" = "true" ] && [ "$guard" = "true" ] && [ "$reported" = "true" ] \
  && pass "the cell now reports live permissives, and they came from the controller rather than from the database" \
  || fail "the cell is still not permissive after the gateway connected: startEnable=$start_enable guard=$guard reported=$reported"

[ "$freshness" = "Simulated" ] \
  && pass "freshness is 'Simulated', never upgraded to 'Live' — the controller is a simulator and says so all the way through" \
  || fail "freshness reported as '$freshness'; a simulated controller must never read as Live"

[ "$operating" = "Idle" ] \
  && pass "the operating state is the controller's own, read over the edge" \
  || fail "operating state '$operating'"

# The interlocks are deliberately absent from ch1.cells. Were they there, a restart would
# restore a stale permissive as a current one, which CH1-SAF-FR-0003 forbids.
columns=$(sql "SELECT count(*) FROM information_schema.columns WHERE table_schema='ch1' AND table_name='cells' AND column_name IN ('start_enable','guard_healthy','controller_boot_id','button_pressed');")
[ "$columns" = "0" ] \
  && pass "no interlock, boot identity or button column exists in ch1.cells: the live answer is held in memory only" \
  || fail "ch1.cells carries $columns column(s) that would restore a stale permissive after a restart"

samples=$(sql "SELECT count(*) FROM ch1.telemetry_samples;")
[ -n "$samples" ] && [ "$samples" -gt 0 ] \
  && pass "$samples telemetry sample(s) are in PostgreSQL with the in-process simulated source turned off — every one arrived over CH1-COM-IF-0003" \
  || fail "no telemetry reached the database over the gRPC edge"

not_simulated=$(sql "SELECT count(*) FROM ch1.telemetry_samples WHERE freshness <> 'Simulated';")
[ "$not_simulated" = "0" ] \
  && pass "every stored sample is marked Simulated; the gateway's quality word survived the whole path" \
  || fail "$not_simulated stored sample(s) claim a freshness the controller did not report"

# Defect 59 / conflict 27, measured on a running system rather than argued from the code.
#
# The gateway used to stamp TimeQuality.Qualified on every message it sent, and to decode
# a device's own declaration and throw it away. CH1-COM-ICD-0001 requires time quality to
# be observable "so audit and TOTP decisions are not silently made on invalid time", and
# nothing here disciplines the gateway's clock against a traceable source - so a stored
# sample claiming a qualified source clock would be a claim nobody had established.
#
# These readings come from the simulator adapter, which stamps them with the gateway's own
# clock and says so; the gateway declares Unknown by default, so Unknown is what must be
# stored. The check is written as a REFUSAL of the old value rather than as equality with
# the new one, because the failure this exists to catch is an upgrade, in either direction.
qualified=$(sql "SELECT count(*) FROM ch1.telemetry_samples WHERE source_time_quality = 'Qualified';")
[ "$qualified" = "0" ] \
  && pass "no stored sample claims a Qualified source clock: the gateway carries what it was told and upgrades nothing (defect 59)" \
  || fail "$qualified stored sample(s) claim a Qualified source clock that nothing in this deployment established"

declared=$(sql "SELECT count(*) FROM ch1.telemetry_samples WHERE source_time_quality IS NOT NULL;")
[ -n "$declared" ] && [ "$declared" -gt 0 ] \
  && pass "$declared stored sample(s) carry the source's own declaration about the clock that stamped them" \
  || fail "no stored sample carries a source time quality; the device's declaration is being discarded again"

audited=$(sql "SELECT count(*) FROM ch1.audit_events WHERE event_type = 'ControllerStateReported';")
[ -n "$audited" ] && [ "$audited" -ge 1 ] && [ "$audited" -le 40 ] \
  && pass "$audited controller-state event(s) in the audit chain: material changes recorded, heartbeats not" \
  || fail "the audit chain holds $audited controller-state event(s); a heartbeat every two seconds must not become an audit event"

chain=$(api POST /api/v1/audit/chain-verifications '{}')
[ "$(printf '%s' "$chain" | json "v.valid")" = "true" ] \
  && pass "the audit chain still verifies with the gateway writing into it: $(printf '%s' "$chain" | json "v.checked") events" \
  || fail "the audit chain did not verify: $(printf '%s' "$chain" | cut -c1-160)"

log "[8/9] The command path, exercisable end to end for the first time"
grant=$(api POST /api/v1/auth/step-up '{"purpose":"PhysicalCommandPreparation"}' | json "v.grantId")
[ -n "$grant" ] \
  && pass "a purpose-bound single-use step-up grant was issued" \
  || fail "no step-up grant could be obtained"

asset_id=$(printf '%s' "$state" | json "v.assetId")
work_order_id=$(printf '%s' "$state" | json "v.workOrderId")
part_id=$(printf '%s' "$state" | json "v.partId")
configuration=$(printf '%s' "$state" | json "v.configurationRevision")
expires=$(date -u -d '+90 seconds' +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -v+90S +%Y-%m-%dT%H:%M:%SZ)

prepare_body="{\"commandType\":\"RUN_TENSION_CALIBRATION\",\"projectId\":\"$project_id\",\"siteId\":\"$site_id\",\"cellId\":\"$cell_id\",\"assetId\":\"$asset_id\",\"workOrderId\":\"$work_order_id\",\"partId\":\"$part_id\",\"procedureRevision\":\"R01\",\"configurationRevision\":\"$configuration\",\"expectedStateHash\":\"$state_hash\",\"sequence\":1,\"expiresAt\":\"$expires\",\"parameters\":{}}"

prepared=$(api POST /api/v1/commands/prepare "$prepare_body" \
  "-HIdempotency-Key:ch1-grpc-verify-prepare-0001 -HX-CH1-Step-Up:$grant")
command_id=$(printf '%s' "$prepared" | json "v.commandId")
command_state=$(printf '%s' "$prepared" | json "v.state")

[ -n "$command_id" ] && [ "$command_state" = "AwaitingCredential" ] \
  && pass "a command was PREPARED on PostgreSQL against a cell reporting live permissives: state $command_state" \
  || fail "preparation failed: $(printf '%s' "$prepared" | cut -c1-240)"

physical=$(printf '%s' "$prepared" | json "v.physicalConfirmationRequired")
remote=$(printf '%s' "$prepared" | json "v.remoteStartAvailable")
[ "$physical" = "true" ] && [ "$remote" = "false" ] \
  && pass "preparation is not authorisation: local confirmation required, no remote start" \
  || fail "a prepared command did not state that physical confirmation is required"

cancelled=$(api POST "/api/v1/commands/$command_id/cancel" '{"reason":"CH1-COM-IF-0003 verification"}')
cancelled_state=$(printf '%s' "$cancelled" | json "v.state")
cancelled_version=$(printf '%s' "$cancelled" | json "v.version")
[ "$cancelled_state" = "Cancelled" ] && [ "$cancelled_version" = "2" ] \
  && pass "the same command was CANCELLED at version 2 — the UPDATE branch of SaveCommandAsync executed on PostgreSQL for the first time" \
  || fail "cancellation failed: $(printf '%s' "$cancelled" | cut -c1-240)"

persisted=$(sql "SELECT state || ':' || version FROM ch1.command_transactions WHERE command_id = '$command_id';")
[ "$persisted" = "Cancelled:2" ] \
  && pass "the database agrees: the stored command is $persisted, so both branches wrote what they claimed" \
  || fail "the stored command is '$persisted', not Cancelled:2"

correlated=$(sql "SELECT count(*) FROM ch1.command_transactions t JOIN ch1.cells c ON c.cell_id = t.cell_id JOIN ch1.assets a ON a.asset_id = t.asset_id WHERE t.command_id = '$command_id' AND a.cell_id = c.cell_id;")
[ "$correlated" = "1" ] \
  && pass "equipment state, asset and procedure transaction resolve to one cell without contradiction" \
  || fail "the command, the cell and the asset do not correlate"

log "[9/9] Communication loss, and what does not happen"
compose stop edge-link > /dev/null 2>&1
sleep 14
after=$(api GET "/api/v1/cells/$cell_id/state")
after_enable=$(printf '%s' "$after" | json "v.interlocks.startEnable")
after_freshness=$(printf '%s' "$after" | json "v.freshness")
[ "$after_enable" = "false" ] && [ "$after_freshness" = "Stale" ] \
  && pass "with the link gone the cell reads as not permissive and Stale — a permissive expires rather than persisting" \
  || fail "the cell still reports startEnable=$after_enable freshness=$after_freshness after the gateway stopped"

grant2=$(api POST /api/v1/auth/step-up '{"purpose":"PhysicalCommandPreparation"}' | json "v.grantId")
refused_prepare=$(api POST /api/v1/commands/prepare "$prepare_body" \
  "-HIdempotency-Key:ch1-grpc-verify-prepare-0002 -HX-CH1-Step-Up:$grant2")
printf '%s' "$refused_prepare" | grep -q "INTERLOCK_" \
  && pass "preparation with no live controller is refused on an interlock: $(printf '%s' "$refused_prepare" | json "v.code")" \
  || fail "preparation with no live controller answered: $(printf '%s' "$refused_prepare" | cut -c1-200)"

# Reconnection reconciles rather than resumes. The gateway comes back with a NEW controller
# boot identity, so the state hash changes and anything prepared before the loss could never
# be committed after it - which is CH1-COM-FR-0006 stated as a property rather than a rule.
compose up -d edge-link > /dev/null 2>&1
attempt=0
until [ "$(api GET "/api/v1/cells/$cell_id/state" | json "v.interlocks.startEnable")" = "true" ]; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 30 ] && { fail "the cell never became permissive again after the gateway returned"; break; }
  sleep 2
done
resumed=$(api GET "/api/v1/cells/$cell_id/state")
resumed_hash=$(printf '%s' "$resumed" | json "v.stateHash")
[ -n "$resumed_hash" ] && [ "$resumed_hash" != "$state_hash" ] \
  && pass "the controller returned with a new boot identity, so the state hash changed and no command prepared before the loss could be committed after it" \
  || fail "the state hash is unchanged across a controller restart, so a stale preparation would still match"

executed=$(sql "SELECT count(*) FROM ch1.command_transactions WHERE state IN ('Executing','Completed','Committed');")
# Three outcomes, not two. "Nothing executed", "something executed" and "I could not tell"
# are different findings, and collapsing the third into the second is how this check reported
# a communication-loss safety violation that had not happened.
case "$executed" in
  0)
    pass "no command executed, resumed or continued anywhere across the loss and the reconnection" ;;
  ''|*[!0-9]*)
    fail "the command register could not be read, so whether anything executed across the loss is UNKNOWN (got '$executed')" ;;
  *)
    fail "$executed command(s) reached an executing or committed state across a communication loss" ;;
esac

log "Result"
echo
if [ "$failures" -eq 0 ]; then
  echo "CH1-COM-IF-0003 is operational: EdgeLink publishes into Control Core over internal"
  echo "gRPC with mutual TLS, and the domain acts on what it receives."
  echo "  transport         : one trust anchor at each end, no anonymous path, no plaintext"
  echo "  refused           : sixteen probes — an untrusted authority, another gateway's"
  echo "                      certificate, a claimed source, an unknown schema, an expired"
  echo "                      message, a replay, a back-dated report, an unenrolled device, a"
  echo "                      foreign cell, an uncatalogued channel, a wrong unit, and an"
  echo "                      acknowledgement for a command nobody prepared"
  echo "  reached the domain: live permissives, the controller's operating state, and"
  echo "                      telemetry stored in PostgreSQL with the in-process simulated"
  echo "                      source turned off"
  echo "  command path      : PREPARE and CANCEL executed on PostgreSQL, both branches of"
  echo "                      SaveCommandAsync, against a cell reporting live permissives"
  echo "  communication loss: the permissive expires, preparation is refused on an interlock,"
  echo "                      the controller returns with a new boot identity, and nothing"
  echo "                      executed, resumed or continued"
  echo "VERIFICATION-CASE CH1-VVT-TC-0025"
  echo "VERIFICATION-CASE CH1-VVT-TC-0101"
  exit 0
fi

echo "$failures check(s) failed. No case is announced."
exit 1
