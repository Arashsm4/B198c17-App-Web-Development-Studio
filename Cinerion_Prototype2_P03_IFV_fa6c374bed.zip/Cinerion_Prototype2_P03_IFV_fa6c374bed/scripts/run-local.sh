#!/usr/bin/env sh
# Starts the local stack for development.

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

if ! docker_version=$(docker --version 2>&1); then
  echo "Docker is not available inside this WSL distribution."
  echo "Detected failure: $docker_version"
  echo "Enable Docker Desktop > Settings > Resources > WSL Integration for Ubuntu."
  echo "Then apply/restart Docker Desktop and run 'wsl --shutdown' from PowerShell."
  exit 1
fi

if ! compose_version=$(docker compose version 2>&1); then
  echo "Docker Compose v2 is required."
  echo "Detected failure: $compose_version"
  exit 1
fi

if ! daemon_version=$(docker info --format '{{.ServerVersion}}' 2>&1); then
  echo "Docker Desktop is installed but its engine is not reachable."
  echo "Detected failure: $daemon_version"
  echo "Start Docker Desktop and wait until it reports Engine running."
  exit 1
fi

docker compose -f infrastructure/compose.yaml up --detach --build --wait

echo "Cinerion simulator-safe stack is healthy."
echo "Docker server: $daemon_version"
echo "Portal: http://localhost:8081"
echo "API:    http://localhost:5080/api/v1/system/health"
echo "Stop:   ./scripts/stop-local.sh"
