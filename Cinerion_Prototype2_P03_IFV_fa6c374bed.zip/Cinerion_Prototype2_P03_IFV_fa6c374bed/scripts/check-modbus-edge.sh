#!/usr/bin/env sh
# CH1-VVT-TC-0021 — "EdgeLink must support replaceable protocol adapters without changing
#                    domain or inspection logic."
# CH1-VVT-TC-0022 — "Data and command semantics remain consistent across adapters."
#
# CH1-VVT-TC-0022 names MQTT, OPC UA and Modbus. This raises all three peers from the
# controlled compose model — the broker, the OPC UA controller and the Modbus zone — and
# runs ONE gateway against all of them at once, so "consistent across adapters" is answered
# by four operational adapters in one process rather than argued from one.
#
# It then attacks the Modbus zone, where the controls are different in kind from the other
# two edges. Modbus authenticates nothing and encrypts nothing: CH1-COM-ICD-0001 terminates
# it inside a controlled zone with "allowlisted mappings and no general routing", and
# CH1-COM-PRO-0001 requires the map to separate read-only telemetry, configuration and the
# command handshake with "arbitrary function codes and address ranges denied". So what is
# attacked here is the map itself — and above all the threat CH1-CYB-TMD-0001 names by
# name, a direct Modbus write bypassing CommandGuard.
#
# Usage: scripts/check-modbus-edge.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

failures=0

log() { printf '%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

if ! docker version >/dev/null 2>&1; then
  echo "check-modbus-edge.sh: the Docker daemon is unreachable. This gate runs a real Modbus" >&2
  echo "zone and a real gateway against it; there is no meaningful way to run it without one." >&2
  exit 1
fi

log "[1/6] The controlled map, reconciled between the two ends that hold it"
node scripts/check-modbus-map.mjs
pass "the gateway's map and the controller's map are the same map"

log "[2/6] Laboratory PKI for the two edges that have one"
./scripts/bootstrap-opcua-pki.sh > /dev/null
./scripts/bootstrap-mqtt-pki.sh > /dev/null
pass "certificates present for the MQTT and OPC UA edges"

log "[3/6] Raising all three controller peers from the controlled compose model"
cd "$repo_dir/infrastructure"
# shellcheck disable=SC1091
[ -f .env.local ] && { set -a; . ./.env.local; set +a; }

CINERION_MQTT_HOST=mqtt
CINERION_MQTT_CLIENT_ID=ch1-edgelink
CINERION_MQTT_DEVICE_ID=CH1-DEV-CELL-0001
CINERION_MQTT_CA_CERT=/run/secrets/mqtt/ca.crt
CINERION_MQTT_CLIENT_CERT=/run/secrets/mqtt/edgelink.crt
CINERION_MQTT_CLIENT_KEY=/run/secrets/mqtt/edgelink.key
CINERION_MQTT_DEVICE_CERT=/run/secrets/mqtt/device.crt
CINERION_MQTT_DEVICE_KEY=/run/secrets/mqtt/device.key
CINERION_MQTT_DEVICE_SIMULATOR=true
CINERION_MQTT_PROJECT_ID=00000000-0000-4000-8000-000000000101
CINERION_MQTT_CELL_ID=00000000-0000-4000-8000-000000000103
CINERION_MQTT_ASSET_ID=00000000-0000-4000-8000-000000000104
CINERION_OPCUA_ENDPOINT=opc.tcp://opcua-plc:4840/ch1
CINERION_OPCUA_APPLICATION_URI=urn:cinerion:ch1:edgelink
CINERION_OPCUA_DEVICE_ID=CH1-DEV-CELL-0001
CINERION_OPCUA_CA_CERT=/run/secrets/opcua/ca.crt
CINERION_OPCUA_CLIENT_CERT=/run/secrets/opcua/edgelink.crt
CINERION_OPCUA_CLIENT_KEY=/run/secrets/opcua/edgelink.key
CINERION_OPCUA_PROJECT_ID=00000000-0000-4000-8000-000000000101
CINERION_OPCUA_CELL_ID=00000000-0000-4000-8000-000000000103
CINERION_OPCUA_ASSET_ID=00000000-0000-4000-8000-000000000104
CINERION_MODBUS_HOST=modbus-plc
CINERION_MODBUS_PORT=502
CINERION_MODBUS_UNIT=1
CINERION_MODBUS_DEVICE_ID=CH1-DEV-CELL-0001
export CINERION_MQTT_HOST CINERION_MQTT_CLIENT_ID CINERION_MQTT_DEVICE_ID \
  CINERION_MQTT_CA_CERT CINERION_MQTT_CLIENT_CERT CINERION_MQTT_CLIENT_KEY \
  CINERION_MQTT_DEVICE_CERT CINERION_MQTT_DEVICE_KEY CINERION_MQTT_DEVICE_SIMULATOR \
  CINERION_MQTT_PROJECT_ID CINERION_MQTT_CELL_ID CINERION_MQTT_ASSET_ID \
  CINERION_OPCUA_ENDPOINT CINERION_OPCUA_APPLICATION_URI CINERION_OPCUA_DEVICE_ID \
  CINERION_OPCUA_CA_CERT CINERION_OPCUA_CLIENT_CERT CINERION_OPCUA_CLIENT_KEY \
  CINERION_OPCUA_PROJECT_ID CINERION_OPCUA_CELL_ID CINERION_OPCUA_ASSET_ID \
  CINERION_MODBUS_HOST CINERION_MODBUS_PORT CINERION_MODBUS_UNIT CINERION_MODBUS_DEVICE_ID

# The gateway is removed first. Both controller stand-ins are stateful peers — a spent
# sequence stays spent and a prepared command stays prepared — so a gateway left running
# from an earlier run would complete its conformance suite against a freshly recreated
# controller and leave the probes below meeting a guard that is already Prepared.
docker compose -f compose.yaml --profile protocol-lab rm -sf edge-link > /dev/null 2>&1 || true
docker compose -f compose.yaml --profile protocol-lab up -d --build --force-recreate \
  mqtt opcua-plc modbus-plc > /dev/null 2>&1

attempt=0
until docker logs cinerion-modbus-plc-1 2>&1 | grep -q "CH1 Modbus stand-in online"; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 60 ] && { fail "the Modbus zone never came online"; break; }
  sleep 2
done
zone_log=$(docker logs cinerion-modbus-plc-1 2>&1)

printf '%s' "$zone_log" | grep -q "zoned allowlist, no general routing" \
  && pass "the zone reports the only security profile Modbus can honestly claim" \
  || fail "the zone did not report the zoned-allowlist profile"

printf '%s' "$zone_log" | grep -q "map version 1, telemetry 0..4, configuration 0..139, handshake 200..241" \
  && pass "the three bands CH1-COM-PRO-0001 requires are separated and published" \
  || fail "the zone did not publish the three separated bands"

log "[4/6] Attacking the map, against a fresh zone"
cd "$repo_dir"
probe_log=$(docker compose -f infrastructure/compose.yaml --profile protocol-lab run --rm --no-deps \
  modbus-plc --probe modbus-plc 2>&1 || true)
printf '%s\n' "$probe_log" | grep -E '^PROBE ' || true

for check in \
  PROBE-01-MAP-VERSION-PUBLISHED \
  PROBE-02-DECLARED-BANDS-READABLE \
  PROBE-03-ADDRESS-OUTSIDE-BANDS-DENIED \
  PROBE-04-STRADDLING-READ-DENIED \
  PROBE-05-COIL-FUNCTION-DENIED \
  PROBE-06-FILE-RECORD-FUNCTION-DENIED \
  PROBE-07-EXECUTE-PERMIT-UNREACHABLE \
  PROBE-08-CONFIGURATION-READ-ONLY \
  PROBE-09-DEVICE-IDENTITY-READ-ONLY \
  PROBE-10-HANDSHAKE-WINDOW-WRITABLE \
  PROBE-11-FOREIGN-UNIT-DENIED
do
  printf '%s' "$probe_log" | grep -q "PROBE PASS $check" \
    || fail "$check did not pass: $(printf '%s' "$probe_log" | grep "$check" || echo 'not reported at all')"
done
[ "$failures" -eq 0 ] && pass "all eleven map probes refused what they exist to refuse"

log "[5/6] The same suite, unchanged, against a fourth operational adapter"
cd "$repo_dir/infrastructure"
docker compose -f compose.yaml --profile protocol-lab up -d --build --force-recreate \
  edge-link > /dev/null 2>&1
cd "$repo_dir"

attempt=0
until docker logs cinerion-edge-link-1 2>&1 | grep -q "CH1-ADP-MODBUS-0001 ADP-09"; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "the gateway never completed Modbus conformance"; break; }
  sleep 2
done
gateway_log=$(docker logs cinerion-edge-link-1 2>&1)

simulator_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-SIM-0001 ADP-.*passed=True" || true)
mqtt_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-MQTT-0001 ADP-.*passed=True" || true)
opcua_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-OPCUA-0001 ADP-.*passed=True" || true)
modbus_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-MODBUS-0001 ADP-.*passed=True" || true)
any_failed=$(printf '%s' "$gateway_log" | grep -c "passed=False" || true)
gated=$(printf '%s' "$gateway_log" | grep -c "gated adapter.*GATE-.*passed=True" || true)

[ "$simulator_passes" -eq 9 ] && [ "$mqtt_passes" -eq 9 ] && [ "$opcua_passes" -eq 9 ] && [ "$modbus_passes" -eq 9 ] \
  && pass "four operational adapters passed all nine checks each (simulator $simulator_passes, MQTT $mqtt_passes, OPC UA $opcua_passes, Modbus $modbus_passes)" \
  || fail "simulator $simulator_passes, MQTT $mqtt_passes, OPC UA $opcua_passes, Modbus $modbus_passes of nine"

[ "$any_failed" -eq 0 ] \
  && pass "no conformance check failed anywhere in the gateway" \
  || fail "$any_failed conformance checks failed"

[ "$gated" -eq 0 ] \
  && pass "no adapter is gated: every protocol CH1-VVT-TC-0022 names has a live counterpart" \
  || fail "expected no gated adapters with all three protocols live, observed $gated checks"

log "[6/6] What the Modbus adapter read, and where it read it from"

printf '%s' "$gateway_log" | grep -q "Modbus adapter connected to modbus-plc:502; controlled map version 1" \
  && pass "the gateway checked the map version before decoding a single field" \
  || fail "the gateway did not report checking the controlled map version"

printf '%s' "$gateway_log" | grep -q "CH1-ADP-MODBUS-0001 online as MODBUS.*MODBUS-ZONED-ALLOWLIST-NO-GENERAL-ROUTING" \
  && pass "the capability model was read out of the controller's configuration band, and names the profile Modbus can actually claim" \
  || fail "the Modbus adapter did not report a read capability model"

printf '%s' "$gateway_log" | grep -q "CH1-ADP-MODBUS-0001 ADP-07-NO-PHYSICAL-CLAIM passed=True: state AwaitingCredential, reason PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION" \
  && pass "a semantic command round trip was evaluated by the guard and claimed no physical effect" \
  || fail "no evaluated command round trip is evidenced over Modbus"

samples=$(printf '%s' "$gateway_log" | grep -c "Modbus telemetry .* first sample .* quality Simulated" || true)
[ "$samples" -ge 3 ] \
  && pass "all three telemetry channels delivered a reading, each united and marked Simulated" \
  || fail "expected 3 first-sample lines from the Modbus telemetry band, observed $samples"

# The same guard, reached two ways. Its refusals are the SCL's own codes on both edges, and
# that is what CH1-VVT-TC-0022 means by consistent semantics across adapters.
printf '%s' "$gateway_log" | grep -q "Modbus controller deferred check: reason code 207" \
  && pass "the Modbus profile carries the same deferred checks the OPC UA profile reports" \
  || fail "the Modbus adapter did not report the controller's deferred checks"

log "Result"
echo
if [ "$failures" -eq 0 ]; then
  echo "All three controlled protocols are operational on one gateway."
  echo "  adapters passing the same suite : simulator, MQTT 5, OPC UA and Modbus TCP,"
  echo "                                    nine checks each, in one process"
  echo "  Modbus controls                 : zoned allowlist, deny by default, three"
  echo "                                    separated bands, versioned map"
  echo "  refused                         : arbitrary function codes, addresses outside"
  echo "                                    every band, a read straddling a band's end, a"
  echo "                                    write at the configuration, a foreign unit, and"
  echo "                                    every write function aimed at the execute permit"
  echo "VERIFICATION-CASE CH1-VVT-TC-0021"
  echo "VERIFICATION-CASE CH1-VVT-TC-0022"
  exit 0
fi

echo "$failures check(s) failed. Neither case is announced."
exit 1
