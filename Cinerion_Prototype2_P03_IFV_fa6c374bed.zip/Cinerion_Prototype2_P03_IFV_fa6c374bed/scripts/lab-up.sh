#!/usr/bin/env sh
# Raises the whole working lab: the controlled compose model, plus the developer overlay
# that puts it on PostgreSQL with demonstration data.
#
# One command, because the four things that have to be right are four different kinds of
# mistake and each one fails differently:
#
#   * --env-file infrastructure/.env.local, because Compose reads `.env` beside the compose
#     file and never `.env.local`. Without it Keycloak gets the literal default and dies
#     with "password authentication failed for user keycloak", which reads like a broken
#     realm (item 64);
#   * both profiles, because postgres and keycloak are profile-gated and silently absent
#     otherwise;
#   * compose.lab.yaml, because CINERION_DEMONSTRATION_DATA is not declared in the
#     controlled model and Compose passes only what a service declares, so exporting it in
#     the shell reaches nothing;
#   * cinerion_app's password, which the migrations create the role for but do not set —
#     the role exists and cannot log in until something sets it.
#
# Usage: npm run lab:up
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

secrets="infrastructure/.env.local"
[ -f "$secrets" ] || { echo "FAIL  $secrets is absent. Run scripts/bootstrap-local.ps1 first." >&2; exit 1; }

read_secret() { grep "^$1=" "$secrets" | head -1 | cut -d= -f2-; }
app_password=$(read_secret CINERION_APP_PASSWORD)
[ -n "$app_password" ] || { echo "FAIL  CINERION_APP_PASSWORD is not in $secrets." >&2; exit 1; }

compose() {
  docker compose --env-file "$secrets" \
    -f infrastructure/compose.yaml \
    -f infrastructure/compose.lab.yaml \
    --profile data-lab --profile identity-lab "$@"
}

# The device laboratory PKI, before anything is raised: control-core mounts it read-only
# and will not start without its server certificate. Idempotent - the bootstrap script
# refuses to overwrite an existing authority unless asked, because regenerating it would
# invalidate every certificate already enrolled.
echo "[0/6] Ensuring the device laboratory PKI exists"
sh scripts/bootstrap-device-pki.sh

echo "[1/6] Raising PostgreSQL and the identity provider"
compose up -d --wait postgres identity-db identity

# The migrations CREATE the application role; they do not give it a password, because a
# password in a committed migration is a committed secret. Until something sets one the
# role exists and cannot log in, and Control Core fails to start with a message about the
# connection rather than about the role. Idempotent: the same value each time.
echo "[2/6] Giving the application role its login"
printf "ALTER ROLE cinerion_app LOGIN PASSWORD '%s';\n" "$app_password" \
  | compose exec -T postgres psql -v ON_ERROR_STOP=1 -U cinerion_owner -d cinerion >/dev/null
echo "PASS  cinerion_app can log in"

# If this folder came as a release package carrying a snapshot of another lab's data, load
# it now: the database is up, Control Core hasn't started, so the seeds will find the data
# already there instead of writing fresh demonstration rows. Only ever into an empty database.
sh scripts/import-lab-data.sh

echo "[3/6] Raising Control Core, EdgeLink and the portal"
# The database entrypoint applies migrations on a FIRST run only, and the
# cinerion-postgres volume outlives every restart — so a lab created before a migration
# existed stays behind the build for ever. Control Core refuses to start against such a
# database and NAMES what is missing, which is the behaviour defect 18 exists for and
# which stays. This acts on that refusal instead of leaving a person to read it: it reads
# the names out of the service's own message and applies exactly those.
# --build, and it is not optional for this stack. Every EXPO_PUBLIC_* value the portal
# reads is inlined by Metro at BUILD time and derived into the Content-Security-Policy in
# the same build, so an image that already exists can never pick up a configuration change:
# the lab comes up healthy and the portal quietly addresses whatever it was built to
# address. That is item 42 with teeth. The first run pays for a build; the rest are cache
# hits.
if ! compose up -d --wait --build 2>/dev/null; then
  missing=$(compose logs control-core 2>/dev/null \
    | sed -n 's/.*the controlled schema is behind this build\. Apply: //p' \
    | tail -1 | tr -d '\r' | tr ',' ' ')
  if [ -n "$missing" ]; then
    echo "      the lab database is behind the build; applying: $missing"
    # shellcheck disable=SC2086
    sh scripts/apply-migrations.sh $missing
    compose up -d --wait --build
  else
    echo "FAIL  Control Core did not become healthy, and did not name a missing migration." >&2
    compose logs --tail 25 control-core >&2
    exit 1
  fi
fi

# The stand-in controller's certificate, enrolled through the controlled operation.
#
# A certificate alone authenticates NOTHING here: Control Core resolves its thumbprint to
# an enrolled device record and takes the project, the cell and the role from that. Without
# this step the confirmer starts, reaches the listener, and is refused - which is the
# control working and reads like a broken lab.
echo "[4/6] Enrolling the stand-in cell controller"
sh scripts/enrol-cell-confirmer.sh || {
  echo "WARN  the stand-in controller was not enrolled. The lab is up and every screen"
  echo "      renders; asking the simulated cell to confirm will be refused until it is."
}

echo "[5/6] Provisioning the portal identities"
sh scripts/provision-portal-identities.sh || {
  echo "WARN  identity provisioning did not complete. The lab is up and the portal will"
  echo "      render, but signing in will not work until this succeeds."
}

# Keycloak imports a realm only when that realm does not already exist, and the
# identity-db volume outlives every restart - so a lab that has ever been started ignores
# every later edit to cinerion-realm.json. That divergence went unnoticed for a month and
# is what npm run realm:drift exists to refuse. It is run HERE rather than in verify.sh
# because it needs a live provider, and an optional step inside a strict pipeline is
# defect 51's exact shape.
echo "[6/6] Reconciling the running realm against the file that declares it"
node scripts/check-realm-drift.mjs || {
  echo "WARN  the running realm is not what infrastructure/keycloak/cinerion-realm.json says."
  echo "      The lab is up. Read the differences above before trusting an authority decision."
}

echo
echo "Lab is up."
echo "  Portal      http://localhost:8081"
echo "  Control Core http://localhost:5080/api/v1/system/health"
echo "  Keycloak    http://localhost:8180/realms/cinerion"
echo "  Simulated cell http://localhost:5085/health"
echo
echo "Address the API as localhost, never 127.0.0.1: AllowedHosts=localhost answers the"
echo "literal with 400, which is the control working rather than a fault."
