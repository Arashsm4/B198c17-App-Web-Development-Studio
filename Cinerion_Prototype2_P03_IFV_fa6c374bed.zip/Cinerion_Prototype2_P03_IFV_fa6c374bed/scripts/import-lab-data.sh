#!/usr/bin/env sh
# Loads the lab data snapshot a release package carries, so a new machine opens with the
# same data as the one it came from. Called by lab-up.sh after the database is up and before
# Control Core first starts; also runnable on its own as `npm run lab:import`.
#
# Three rules, in order:
#   1. no snapshot in this folder  -> nothing to do; the lab starts with fresh demo data;
#   2. the database already has ANY row in the ch1 schema -> not loaded. A snapshot only ever
#      goes into an empty database, so it can never overwrite or mix with real work;
#   3. otherwise load it in ONE transaction (all of it or none of it), then check every
#      table's row count against counts.txt, which export-lab-data.sh took from the dump.
#
# Control Core's seeds then find their data already present and leave it alone.

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

fail() { printf 'FAIL  %s\n' "$*" >&2; exit 1; }
pass() { printf 'PASS  %s\n' "$*"; }

snapshot="lab-snapshot/cinerion-lab-data.sql.gz"
counts="lab-snapshot/counts.txt"
secrets="infrastructure/.env.local"

if [ ! -f "$snapshot" ]; then
  echo "      no lab data snapshot in this folder; the lab starts with fresh demonstration data"
  exit 0
fi
[ -f "$counts" ] || fail "$snapshot is here but $counts is not, so the restore couldn't be checked. Re-export it."

compose() {
  docker compose --env-file "$secrets" \
    -f infrastructure/compose.yaml -f infrastructure/compose.lab.yaml \
    --profile data-lab --profile identity-lab "$@"
}
sql() { compose exec -T postgres psql -U cinerion_owner -d cinerion -tA -v ON_ERROR_STOP=1 -c "$1" | tr -d '\r'; }

# Every table in ch1 with its exact row count, as table|count.
count_tables() {
  sql "select string_agg(t, E'\n' order by t) from (
         select format('%s|%s', c.relname,
                (xpath('/row/n/text()', query_to_xml(format('select count(*) as n from ch1.%I', c.relname), false, true, '')))[1]::text) as t
         from pg_class c join pg_namespace s on s.oid = c.relnamespace
         where s.nspname = 'ch1' and c.relkind = 'r') x"
}

existing=$(count_tables | awk -F'|' '$2 > 0 { n++ } END { print n + 0 }')
if [ "$existing" -gt 0 ]; then
  echo "      the lab database already has data ($existing tables with rows), so the snapshot was not loaded"
  echo "      (it only ever goes into an empty database)"
  exit 0
fi

taken=$(sed -n 's/^Taken (UTC): *//p' lab-snapshot/SNAPSHOT_INFO.txt 2>/dev/null || true)
echo "      loading the lab data snapshot${taken:+ taken $taken}..."
gunzip -c "$snapshot" \
  | compose exec -T postgres psql -U cinerion_owner -d cinerion -q -v ON_ERROR_STOP=1 --single-transaction >/dev/null \
  || fail "the snapshot did not load; nothing was changed (it runs as one transaction)."

# Check every table the snapshot names. Leaf partitions are ordinary tables here, so the
# telemetry rows are counted where they actually live.
now=$(count_tables)
mismatches=0
checked=0
total=0
while IFS='|' read -r table expected; do
  [ -n "$table" ] || continue
  checked=$((checked + 1))
  total=$((total + expected))
  actual=$(printf '%s\n' "$now" | awk -F'|' -v t="$table" '$1 == t { print $2 }')
  if [ "${actual:-missing}" != "$expected" ]; then
    printf 'FAIL  %s: the snapshot has %s rows, the database now has %s\n' "$table" "$expected" "${actual:-no such table}" >&2
    mismatches=$((mismatches + 1))
  fi
done < "$counts"
[ "$mismatches" -eq 0 ] || fail "$mismatches table(s) did not match the snapshot after loading."
pass "lab data restored: $total rows across $checked tables, every count matches the snapshot"
