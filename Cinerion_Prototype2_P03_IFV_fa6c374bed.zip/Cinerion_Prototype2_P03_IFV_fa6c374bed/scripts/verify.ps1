# The full verification pipeline on Windows. Same gates as verify.sh, so neither can quietly
# skip one.

param([switch]$Strict)
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Push-Location $Repo

# $ErrorActionPreference does not govern native commands in Windows PowerShell 5.1:
# `npm run policy` can exit 1 and the script carries straight on to the next line and
# finally prints "verification completed". Every gate below therefore goes through this
# helper, which inspects $LASTEXITCODE and throws. Without it this script is the same
# defect as `dotnet test` discovering zero tests and exiting 0 - a gate reporting success
# while running something that failed.
function Invoke-Gate {
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][scriptblock]$Command)
    Write-Host "== $Name"
    $global:LASTEXITCODE = 0
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE."
    }
}

try {
    Invoke-Gate 'Frozen P03/IFV baseline integrity' { npm run baseline }
    Invoke-Gate 'Generated contracts and catalogue' { npm run contracts }
    Invoke-Gate 'Executable command/audit/quality model' { npm run test:model }
    Invoke-Gate 'Simulator demonstration' { npm run demo:model }
    Invoke-Gate 'Baseline-to-code traceability' { npm run traceability }
    Invoke-Gate 'Repository policy and security boundaries' { npm run policy }
    Invoke-Gate 'Controlled cross-layer architecture' { npm run arch:map }
    Invoke-Gate 'Controlled cross-layer architecture (attack suite)' { npm run arch:attack }
    Invoke-Gate 'Controlled migration set' { npm run migrations }
    Invoke-Gate 'Declared screen register' { npm run screens }
    $env:EXPO_NO_TELEMETRY = '1'
    Invoke-Gate 'Operator portal type and lint' { npm run check:portal }
    Invoke-Gate 'Operator portal static export' { npm run build:portal }
    # Must follow the export: it reads the bundle that step produces. Item 19 again - added
    # to both entry points in the same change.
    Invoke-Gate 'Portal public-internet egress' { npm run portal:egress }
    Invoke-Gate 'Portal public-internet egress (attack suite)' { npm run portal:egress:attack }

    New-Item -ItemType Directory -Force -Path artifacts/host-tests | Out-Null
    Invoke-Gate 'Cell state machine (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic firmware/shared/src/cell_state_machine.cpp firmware/tests/cell_state_machine_test.cpp -Ifirmware/shared/include -o artifacts/host-tests/cell_state_machine_test
    }
    Invoke-Gate 'Cell state machine (host tests)' { & ./artifacts/host-tests/cell_state_machine_test }
    Invoke-Gate 'Frame codec (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic firmware/arduino-io/src/frame_codec.cpp firmware/tests/frame_codec_test.cpp -Ifirmware/arduino-io/include -o artifacts/host-tests/frame_codec_test
    }
    Invoke-Gate 'Frame codec (host tests)' { & ./artifacts/host-tests/frame_codec_test }
    Invoke-Gate 'I/O node application (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic firmware/arduino-io/src/frame_codec.cpp firmware/arduino-io/src/node_application.cpp firmware/tests/node_application_test.cpp -Ifirmware/arduino-io/include -o artifacts/host-tests/node_application_test
    }
    Invoke-Gate 'I/O node application (host tests)' { & ./artifacts/host-tests/node_application_test }
    Invoke-Gate 'Conditioned I/O (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic firmware/shared/src/conditioned_io.cpp firmware/tests/conditioned_io_test.cpp -Ifirmware/shared/include -o artifacts/host-tests/conditioned_io_test
    }
    Invoke-Gate 'Conditioned I/O (host tests)' { & ./artifacts/host-tests/conditioned_io_test }
    Invoke-Gate 'ESP32 entry point (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic -c firmware/esp32/main/app_main.cpp -Ifirmware/shared/include -Ifirmware/arduino-io/include -Ifirmware/tests/host-stubs -o artifacts/host-tests/app_main.o
    }
    Invoke-Gate 'Cell controller simulation (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic firmware/shared/src/cell_state_machine.cpp firmware/shared/src/conditioned_io.cpp firmware/shared/src/cbor.cpp firmware/shared/src/ch1_envelope.cpp firmware/arduino-io/src/frame_codec.cpp firmware/arduino-io/src/node_application.cpp simulators/cell-controller/src/main.cpp -Ifirmware/shared/include -Ifirmware/arduino-io/include -o artifacts/host-tests/cell_controller_simulator
    }
    Invoke-Gate 'Cell controller simulation (run)' { & ./artifacts/host-tests/cell_controller_simulator --quiet }
    Invoke-Gate 'Controlled I/O pin map' { npm run io:map }
    Invoke-Gate 'Controlled I/O pin map (attack suite)' { npm run io:attack }
    Invoke-Gate 'Controlled authority register (attack suite)' { npm run authorities:attack }
    # Item 19: a second entry point to the same gates is a second place for a gate to go
    # missing. Added here in the same change that added it to verify.sh, not afterwards.
    Invoke-Gate 'AI authority prohibition' { npm run ai:prohibition }
    Invoke-Gate 'AI authority prohibition (attack suite)' { npm run ai:attack }
    Invoke-Gate 'Executable obligations register' { npm run obligations }
    Invoke-Gate 'Executable obligations register (attack suite)' { npm run obligations:attack }
    Invoke-Gate 'Controlled cell state machine' { npm run cell:map }
    Invoke-Gate 'Controlled cell state machine (attack suite)' { npm run cell:attack }
    Invoke-Gate 'Controlled PREPARE / LOCAL COMMIT sequence' { npm run commit:map }
    Invoke-Gate 'Controlled PREPARE / LOCAL COMMIT sequence (attack suite)' { npm run commit:attack }
    # These four had drifted out of this entry point while verify.sh gained them, so the
    # Windows script silently covered less than the authoritative one while
    # DEVELOPMENT_GATES.md said the two differed only in the preflight and the Compose
    # model. Same class as the $LASTEXITCODE defect above: a gate that quietly is not there.
    Invoke-Gate 'CH1 envelope (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic firmware/shared/src/cbor.cpp firmware/shared/src/ch1_envelope.cpp firmware/tests/ch1_envelope_test.cpp -Ifirmware/shared/include -o artifacts/host-tests/ch1_envelope_test
    }
    Invoke-Gate 'CH1 envelope (host tests)' { & ./artifacts/host-tests/ch1_envelope_test }
    Invoke-Gate 'PLC scenarios (host build)' {
        g++ -std=c++20 -Wall -Wextra -Werror -pedantic plc/host-model/src/plc_command_guard.cpp plc/tests/plc_scenario_test.cpp -Iplc/host-model/include -o artifacts/host-tests/plc_scenario_test
    }
    Invoke-Gate 'PLC scenarios (host tests)' { & ./artifacts/host-tests/plc_scenario_test }
    Invoke-Gate 'PLC model against the controlled SCL' { npm run plc }
    Invoke-Gate 'Controlled Modbus register map' { npm run modbus:map }
    # `dotnet` resolves whenever any .NET host is installed, so presence of the
    # command is not evidence of an SDK. Match verify.sh and gate on the SDK
    # major version; a skipped gate is never reported as passed.
    $dotnetVersion = ''
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $dotnetVersion = (& dotnet --version 2>$null | Select-Object -First 1) } catch { $dotnetVersion = '' }
    $ErrorActionPreference = $previousPreference
    if ($LASTEXITCODE -ne 0) { $dotnetVersion = '' }

    if ($dotnetVersion -like '10.*') {
        Invoke-Gate '.NET restore' { dotnet restore Cinerion.slnx }
        Invoke-Gate '.NET tests' { dotnet test Cinerion.slnx --configuration Release --no-restore }
        Invoke-Gate 'Portal contracts against real responses' { npm run contracts:portal }
    } elseif (-not [string]::IsNullOrWhiteSpace($dotnetVersion)) {
        throw ".NET SDK $dotnetVersion is installed, but Cinerion requires .NET 10.x."
    } elseif ($Strict) {
        throw '.NET SDK 10 is required for strict verification. Run ./scripts/doctor.ps1.'
    } else {
        Write-Warning 'SKIPPED locally: .NET SDK 10 is unavailable. CI treats this check as mandatory.'
    }

    # After the .NET step, and necessarily so: the map's .NET half is reconciled inside each
    # test assembly, and the portal render harness renders against the responses those tests
    # capture into artifacts/contracts. Kept outside the branch above so it still runs, and
    # still states its own skips, on a workstation with no .NET.
    # Strictness has to travel: check-verification.mjs reads its own arguments to
    # decide whether a harness that could not be run is an error or a stated skip,
    # so a strict run that invoked it plainly would downgrade a genuine failure.
    Invoke-Gate 'Controlled verification-case binding' { npm run verification -- --strict }

    # Its own gate as well as an observation inside the one above, following the same
    # pattern as the baseline and policy gates: a harness that only runs inside
    # check-verification.mjs reports a genuine failure as "could not be run".
    # Snapshots on, so the layout gate below has something real to lay out. Same change as
    # verify.sh, same commit (item 19).
    Invoke-Gate 'Portal screens rendered and driven' {
        if (Test-Path artifacts/render-snapshots/pipeline) { Remove-Item -Recurse -Force artifacts/render-snapshots/pipeline }
        $env:CINERION_RENDER_SNAPSHOT_DIR = 'artifacts/render-snapshots/pipeline'
        try { npm run render:portal } finally { Remove-Item Env:CINERION_RENDER_SNAPSHOT_DIR }
    }
    Invoke-Gate 'Portal layout in a real browser' { npm run layout:portal }
    Invoke-Gate 'Portal layout in a real browser (attack suite)' { npm run layout:attack }

    # This entry point deliberately does not run the workstation preflight or the
    # Compose model; scripts/verify.sh is the gate CI runs and remains authoritative.
    Write-Host 'Cinerion verification completed (PowerShell entry point; see scripts/verify.sh for the CI gate).'
} finally {
    Pop-Location
}
