#!/usr/bin/env sh
# Applies named controlled migrations to the running data-lab database.
#
# WHY THIS EXISTS. The database entrypoint applies migrations only on a FIRST run, and the
# cinerion-postgres volume outlives every restart — so a lab created before a migration
# existed stays behind the build for ever. Control Core refuses to start against such a
# database and names exactly what is missing:
#
#   CINERION_DATABASE_MODE=Postgres: the controlled schema is behind this build.
#   Apply: 0012_role_assignments.sql, 0013_publication_packages.sql
#
# That refusal is correct and stays. This is how an operator acts on it.
#
# WHY IT TAKES NAMES RATHER THAN APPLYING EVERYTHING. Altering an existing controlled schema
# is a reviewed migration, not a startup side effect — CinerionDataSource.EnsureSchemaAsync
# says so in its own words and deliberately does nothing to a database that already has the
# ch1 schema. A script that replayed the whole directory would also fail: CREATE TRIGGER is
# not idempotent, so 0001 cannot be applied twice. Naming them keeps the act deliberate and
# keeps this script from becoming the general migration runner the design refuses to have.
#
# Usage: scripts/apply-migrations.sh 0012_role_assignments.sql 0013_publication_packages.sql
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

migrations_dir=services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations
container=${CINERION_POSTGRES_CONTAINER:-cinerion-postgres-1}

fail() { printf 'FAIL  %s\n' "$*" >&2; exit 1; }
pass() { printf 'PASS  %s\n' "$*"; }

[ "$#" -gt 0 ] || fail "name at least one migration. Control Core's startup error lists exactly the ones this database is missing."

docker inspect "$container" >/dev/null 2>&1 \
  || fail "container $container is not running. Bring the data lab up first, or set CINERION_POSTGRES_CONTAINER."

tables() {
  docker exec "$container" psql -U cinerion_owner -d cinerion -tAc \
    "SELECT count(*) FROM information_schema.tables WHERE table_schema='ch1'" | tr -d '\r '
}

before=$(tables)
pass "the lab database holds $before controlled table(s) before this"

for name in "$@"; do
  file="$migrations_dir/$name"
  [ -f "$file" ] || fail "$name is not a controlled migration. It must be a file in $migrations_dir."

  # ON_ERROR_STOP, so a migration that fails half way stops here rather than leaving the
  # schema in a state nobody named and letting the next one run on top of it.
  docker exec -i "$container" psql -U cinerion_owner -d cinerion -q -v ON_ERROR_STOP=1 < "$file" \
    || fail "$name did not apply. The database is unchanged by this migration; earlier ones in this run have been applied."
  pass "applied $name"
done

after=$(tables)
pass "the lab database now holds $after controlled table(s)"

echo
echo "Control Core probes the schema at startup and refuses a database behind its build."
echo "If it still refuses, it will name what is still missing; pass those names to this"
echo "script too. Restart it with:"
echo
echo "  docker compose -f infrastructure/compose.yaml -f infrastructure/compose.local.yaml \\"
echo "    --profile data-lab --profile identity-lab up -d control-core"
