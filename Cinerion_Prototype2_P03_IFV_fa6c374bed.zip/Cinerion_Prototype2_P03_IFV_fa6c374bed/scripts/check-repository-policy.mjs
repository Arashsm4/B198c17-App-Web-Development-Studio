// The house rules: no secrets, no uncontrolled API routes, no energised outputs. Breaks the
// build if any are broken.

import { readdir, readFile } from 'node:fs/promises';
import { dirname, extname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseDocument } from 'yaml';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
// 'build' is here because the firmware CAN now be built. Until this session nothing had
// ever run ESP-IDF, so firmware/esp32/build/ did not exist and the walk never met it;
// after one build the firmware-source count moved from 19 to 21 and the two extra files
// were CMake's own compiler-probe sources. A count that changes with whether somebody has
// built is a count nobody can reason about, and the actuator-output boundary below is
// enforced by scanning EVERY firmware source — so a vendored or generated file under a
// build tree would be blamed on this repository's firmware. Build trees are gitignored
// and hold nothing this gate is responsible for.
const ignoredDirectories = new Set(['.git', '.expo', '.local', 'artifacts', 'bin', 'build', 'dist', 'node_modules', 'obj', 'release']);
const textExtensions = new Set(['.conf', '.cpp', '.cs', '.csproj', '.css', '.hpp', '.json', '.md', '.mjs', '.props', '.ps1', '.scl', '.sh', '.slnx', '.ts', '.tsx', '.yaml', '.yml']);

async function walk(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue;
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(path));
    else files.push(path);
  }
  return files;
}

const files = await walk(root);
const relativeFiles = files.map((path) => relative(root, path).replaceAll('\\', '/'));

// Paths the identity/data/protocol laboratories are documented to generate locally.
// Each is excluded by .gitignore so it cannot be committed, and named explicitly in
// scripts/package-release.sh so it cannot be packaged. Without this the documented
// bootstrap-local workflow and ./scripts/verify.sh are mutually exclusive. Any other
// secret path still fails, including infrastructure/.env.* variants that packaging
// does not exclude.
const locallyGeneratedSecrets = (path) =>
  path === 'infrastructure/.env.local' || path.startsWith('infrastructure/secrets/');

for (const path of relativeFiles) {
  if ((/^infrastructure\/\.env(?:\.|$)/.test(path) || /(^|\/)secrets\//.test(path)) &&
      !locallyGeneratedSecrets(path)) {
    errors.push(`Local secret material must not be packaged: ${path}`);
  }
  // Same exemption, same reason, and it has to be the same set: the MQTT edge needs a
  // laboratory CA, a broker key and two client keys before the protocol lab can start at
  // all, and scripts/bootstrap-mqtt-pki.sh writes them into infrastructure/secrets/. That
  // directory is excluded by .gitignore, excluded by path in scripts/package-release.sh,
  // and every one of these extensions is excluded there again by name. Without this the
  // documented bootstrap workflow and ./scripts/verify.sh are mutually exclusive, which
  // is exactly the position the .env.local exemption above already resolved once.
  // A private key anywhere else still fails, including one force-added into that
  // directory's parent.
  if (/\.(?:pfx|p12|pem|key|jks|keystore)$/i.test(path) && !locallyGeneratedSecrets(path)) {
    errors.push(`Private-key or keystore file must not be packaged: ${path}`);
  }
  if (/\.pdf$/i.test(path)) {
    errors.push(`PDF output is excluded from this implementation handover: ${path}`);
  }
}

for (const file of files) {
  if (extname(file) !== '.json') continue;
  try {
    JSON.parse(await readFile(file, 'utf8'));
  } catch (error) {
    errors.push(`Invalid JSON ${relative(root, file)}: ${error.message}`);
  }
}

for (const file of files.filter((item) => ['.yaml', '.yml'].includes(extname(item)))) {
  const document = parseDocument(await readFile(file, 'utf8'), { prettyErrors: true, uniqueKeys: true });
  for (const error of document.errors) {
    errors.push(`Invalid YAML ${relative(root, file)}: ${error.message}`);
  }
}

const scanFiles = files.filter((file) => textExtensions.has(extname(file)) && !relative(root, file).startsWith('docs/baseline/'));
for (const file of scanFiles) {
  const text = await readFile(file, 'utf8');
  const path = relative(root, file).replaceAll('\\', '/');
  if (/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(text)) {
    errors.push(`Embedded private key marker in ${path}`);
  }
  if (/(?:AKIA|ASIA)[A-Z0-9]{16}/.test(text)) {
    errors.push(`Possible cloud access key in ${path}`);
  }
  if (/\b(?:password|secret|token)\s*[=:]\s*["'][^$<{][^"'\n]{11,}["']/i.test(text) && !path.endsWith('check-repository-policy.mjs')) {
    errors.push(`Possible committed credential in ${path}`);
  }
  if (/ControlHub One/.test(text) && !path.endsWith('check-repository-policy.mjs')) {
    errors.push(`Stale project name outside frozen baseline in ${path}`);
  }
  if (/\b100% secure\b/i.test(text)) {
    errors.push(`Indefensible absolute security claim in ${path}`);
  }
}

const portalFiles = scanFiles.filter((file) => relative(root, file).startsWith('apps/operator-portal/src/'));
for (const file of portalFiles) {
  const text = await readFile(file, 'utf8');
  if (/\/local-commits|\/credential-proofs/.test(text)) {
    errors.push(`Operator portal may not invoke controller-local proof/commit routes: ${relative(root, file)}`);
  }
}

const program = await readFile(resolve(root, 'services/control-core/src/Cinerion.Api/Program.cs'), 'utf8');
if (!/runtimeProfile == CommandRuntimeProfile\.Production && allowDevelopmentIdentity/.test(program)) {
  errors.push('API does not fail closed against development identity in Production.');
}
if (!/P03 does not authorise the Production runtime profile/.test(program)) {
  errors.push('P03 Production-profile prohibition is missing.');
}

// CH1-SAF-FR-0001 and CH1-VVT-TC-0070. The entry point must configure no GPIO as an
// actuator output, and NOTHING BELOW IT may energise anything.
//
// This checked one file. That was the right check while one file was all there was, and it
// became the wrong one the moment the conditioned I/O layer arrived: a driver added in a
// second file under firmware/ would have satisfied the letter of a check named after the
// entry point while breaking the position the check exists to hold. The boundary is
// therefore widened rather than worked around — the whole firmware tree, and the shared
// sources the ESP-IDF component compiles into the same binary.
//
// What replaces energising is PLANNING: cinerion::io::OutputPlanner computes what the six
// controlled outputs should be, firmware/pinmap/esp32s3-r01.json records that no actuator
// output is energisable at this hardware revision, and scripts/check-io-map.mjs holds the
// data half of the same boundary.
const esp32 = await readFile(resolve(root, 'firmware/esp32/main/app_main.cpp'), 'utf8');
if (/gpio_set_level|gpio_config|ledc_set_duty/.test(esp32)) {
  errors.push('P03 ESP32 entry point configures or energises physical outputs.');
}

const firmwareSources = scanFiles.filter((file) => {
  const path = relative(root, file).replaceAll('\\', '/');
  return path.startsWith('firmware/') && /\.(?:c|h|cc|cpp|hpp)$/.test(path);
});
if (firmwareSources.length === 0) {
  errors.push('No firmware sources were scanned for the actuator-output boundary; the check would pass over nothing.');
}
for (const file of firmwareSources) {
  const path = relative(root, file).replaceAll('\\', '/');
  const text = await readFile(file, 'utf8');
  if (/gpio_set_level|gpio_config|ledc_set_duty|ledc_channel_config|dac_output_voltage|mcpwm_/.test(text)) {
    errors.push(`P03 firmware configures or energises a physical output outside HIL review: ${path}`);
  }
}

// The data half. An actuator that became energisable by editing a JSON field would be
// exactly the quiet move both halves exist to stop, so the policy gate refuses it too
// rather than leaving it to a gate someone could forget to run.
const pinMap = JSON.parse(await readFile(resolve(root, 'firmware/pinmap/esp32s3-r01.json'), 'utf8'));
const energisable = (pinMap.signals ?? []).filter((signal) => signal.actuator && signal.energisable !== false);
if (energisable.length > 0 && pinMap.wiringFrozen !== true) {
  errors.push(
    'P03 pin map declares an actuator output energisable while the wiring is not frozen: ' +
    energisable.map((signal) => signal.signalId).join(', '));
}

const mqtt = await readFile(resolve(root, 'infrastructure/mosquitto/config/mosquitto.conf'), 'utf8');
for (const required of ['allow_anonymous false', 'require_certificate true', 'tls_version tlsv1.3']) {
  if (!mqtt.includes(required)) errors.push(`MQTT fail-closed control missing: ${required}`);
}

const compose = await readFile(resolve(root, 'infrastructure/compose.yaml'), 'utf8');
if (!compose.includes('127.0.0.1:5080:8080') || !compose.includes('CINERION_RUNTIME_PROFILE: Simulation')) {
  errors.push('Default Compose model must remain loopback-bound and Simulation-only.');
}

// The portal's endpoints are inlined at BUILD time. Metro bakes every EXPO_PUBLIC_*
// variable into the bundle, so an image built without one can never be configured
// afterwards, and the Dockerfile derives the Content-Security-Policy connect-src from
// the same two values — a build argument that is not passed silently produces both a
// portal that cannot reach its identity provider and a policy that would block it if it
// could. Defect 78 was exactly that: the compose service declared a build with no
// arguments at all, so every image it produced reported "identity provider not
// configured" while the same model raised a Keycloak holding the portal's own client.
//
// Reconciled rather than asserted: each ARG the Dockerfile declares must be passed, so a
// new one cannot be added and left unwired.
const composeModel = parseDocument(compose).toJS();
const portalDockerfile = await readFile(resolve(root, 'apps/operator-portal/Dockerfile'), 'utf8');
const portalBuildArgs = new Set(
  [...portalDockerfile.matchAll(/^ARG\s+(EXPO_PUBLIC_[A-Z0-9_]+)/gm)].map((match) => match[1]));
const portalService = composeModel?.services?.['operator-portal'] ?? {};
const passedArgs = portalService.build?.args ?? {};
for (const argument of portalBuildArgs) {
  if (!Object.hasOwn(passedArgs, argument)) {
    errors.push(
      `The operator-portal Compose build does not pass ${argument}, which its Dockerfile ` +
      'declares. EXPO_PUBLIC_* values are inlined at build time, so the image would carry ' +
      'the Dockerfile default for the life of that image and could not be configured later.');
  }
}

// And the identity endpoint it is built against must be the realm this same model
// imports. A portal built for another realm path authenticates against nothing, and the
// failure appears in the browser as a discovery error rather than as a misconfiguration.
const composedRealmFile = JSON.parse(
  await readFile(resolve(root, 'infrastructure/keycloak/cinerion-realm.json'), 'utf8'));
const composedRealm = composedRealmFile.realm;
const portalAuthority = String(passedArgs.EXPO_PUBLIC_CINERION_OIDC_AUTHORITY ?? '');
if (portalBuildArgs.has('EXPO_PUBLIC_CINERION_OIDC_AUTHORITY') &&
    !portalAuthority.includes(`/realms/${composedRealm}`)) {
  errors.push(
    `The operator-portal build's OIDC authority (${portalAuthority || 'unset'}) does not name ` +
    `the realm this Compose model imports (${composedRealm}).`);
}
const portalClientIds = new Set((composedRealmFile.clients ?? []).map((client) => client.clientId));
const portalClientId = String(passedArgs.EXPO_PUBLIC_CINERION_OIDC_CLIENT_ID ?? '')
  .replace(/^\$\{[^:}]+:-/, '').replace(/\}$/, '');
if (portalBuildArgs.has('EXPO_PUBLIC_CINERION_OIDC_CLIENT_ID') && !portalClientIds.has(portalClientId)) {
  errors.push(
    `The operator-portal build names the OIDC client "${portalClientId}", which the realm ` +
    'this Compose model imports does not define.');
}

// CH1-CYB-ACP-0001 requires audit to reconcile policy definitions with identity
// assignments and actual endpoint enforcement. The identity provider cannot be
// started in every environment, so the realm/code contract is reconciled statically.
const realm = JSON.parse(await readFile(resolve(root, 'infrastructure/keycloak/cinerion-realm.json'), 'utf8'));

// No "_note" fields in the realm. JSON has no comments, and Keycloak refuses any field it
// doesn't recognise: "_sessionLifetimeNote" stopped every fresh install cold - Keycloak never
// started - and hid for two days because an existing realm is never re-imported. Notes live in
// infrastructure/keycloak/README.md. This catches the note habit; a misspelled real field
// still needs a fresh import to find, which is what installing the release package does.
//
// And nothing longer than 255 characters: descriptions and names go into VARCHAR(255) columns,
// and the import then dies with "value too long for type character varying(255)". The
// identity-admin client's 505-character description did exactly that on every fresh install
// for six weeks. components.*.config is exempt - Keycloak keeps that in a text column, and its
// own user-profile setting is 1,801 characters.
const noteKeys = [];
const longValues = [];
const findRealmHazards = (value, path) => {
  if (typeof value === 'string') {
    if (value.length > 255 && !/^realm\.components\..*\.config\./.test(path)) longValues.push(`${path} (${value.length})`);
  } else if (Array.isArray(value)) value.forEach((item, index) => findRealmHazards(item, `${path}[${index}]`));
  else if (value && typeof value === 'object') {
    for (const [key, child] of Object.entries(value)) {
      if (key.startsWith('_')) noteKeys.push(`${path}.${key}`);
      findRealmHazards(child, `${path}.${key}`);
    }
  }
};
findRealmHazards(realm, 'realm');
for (const key of noteKeys) {
  errors.push(
    `infrastructure/keycloak/cinerion-realm.json has the field ${key}. Keycloak refuses fields it doesn't know, ` +
    'so the realm import fails and the identity provider never starts. Put notes in infrastructure/keycloak/README.md.');
}
for (const value of longValues) {
  errors.push(
    `infrastructure/keycloak/cinerion-realm.json has a value over 255 characters at ${value}. Keycloak stores it ` +
    'in a VARCHAR(255) column, so the import fails and the identity provider never starts.');
}

const realmRoles = new Set((realm.roles?.realm ?? []).map((role) => role.name));
const realmMappers = (realm.clients ?? []).flatMap((client) => client.protocolMappers ?? []);
const mappedClaims = new Set(realmMappers.map((mapper) => mapper.config?.['claim.name']).filter(Boolean));

// Authentication strength must describe how the current session was authenticated.
// A mapper sourcing it from a stored user attribute would grant a permanent step-up
// and defeat the release, credential and security-policy gates.
if (mappedClaims.has('ch1_auth_strength')) {
  errors.push('Realm must not map ch1_auth_strength: step-up would become a permanent stored attribute.');
}
for (const claim of ['ch1_project', 'ch1_cell', 'roles']) {
  if (!mappedClaims.has(claim)) errors.push(`Realm does not emit the required CH1 identity claim: ${claim}`);
}
if (!realmMappers.some((mapper) => mapper.config?.['included.client.audience'] === 'cinerion-control-core')) {
  errors.push('Realm does not add the cinerion-control-core audience; Control Core rejects every portal token.');
}

// Keycloak 24+ moved "sub" and "auth_time" into the built-in "basic" client scope.
// A client that lists defaultClientScopes explicitly and omits it issues tokens with
// no subject, so every request fails AUTH_IDENTITY_REQUIRED. auth_time is also the
// recency evidence step-up will depend on.
for (const client of realm.clients ?? []) {
  const scopes = client.defaultClientScopes;
  if (Array.isArray(scopes) && !client.bearerOnly && !scopes.includes('basic')) {
    errors.push(`Client "${client.clientId}" omits the "basic" client scope; its tokens carry no sub claim.`);
  }
}

// Device accounts authenticate with mTLS and workload identity, not through the realm.
const nonRealmRoles = new Set(['DeviceController']);
const actorContext = await readFile(
  resolve(root, 'services/control-core/src/Cinerion.Domain/Security/ActorContext.cs'), 'utf8');
const declaredRoles = [...actorContext.matchAll(/public const string \w+ = "([^"]+)";/g)].map((match) => match[1]);
for (const role of declaredRoles) {
  if (!nonRealmRoles.has(role) && !realmRoles.has(role)) {
    errors.push(`CinerionRoles."${role}" has no realm role and can never be granted.`);
  }
}
for (const role of realmRoles) {
  if (!declaredRoles.includes(role)) {
    errors.push(`Realm role "${role}" is assignable but no CinerionRoles constant enforces it.`);
  }
}

const baselineApi = JSON.parse(await readFile(resolve(root, 'docs/baseline/P03_IFV/data/api_endpoints.json'), 'utf8'));
const expectedApi = new Set(baselineApi.map(([method, path]) => `${method} ${path}`));

// -- Every authority the controlled documents name, mapped to a role or to a reason. ----
//
// access.json and api_endpoints.json write authorities as prose - "Engineer or Maintainer",
// "Self or Identity Administrator", "Quality or Project role", "IR plus Document Control
// review" - and the code enforces role constants. Nothing reconciled the two. The
// consequence was that a mapping decision could be made silently inside an endpoint and
// never recorded anywhere, which is exactly what conflicts 9 and 23 turned out to be: two
// authorities a controlled document names, with no role behind them and no record of what
// they had been mapped onto.
//
// traceability/controlled-authorities.json records one decision per phrase. This refuses
// a controlled document naming an authority the register does not account for, a register
// entry naming a phrase no controlled document contains, an entry that maps to nothing at
// all, and a mapped role CinerionRoles does not define. It does NOT check which endpoint
// enforces which role - the endpoint tests do that, and a second implementation of those
// checks would be a second place for them to differ.

const controlledAccess = JSON.parse(
  await readFile(resolve(root, 'docs/baseline/P03_IFV/data/access.json'), 'utf8'));
const authorityRegister = JSON.parse(
  await readFile(resolve(root, 'traceability/controlled-authorities.json'), 'utf8'));

const namedAuthorities = new Set([
  ...controlledAccess.map((row) => row[1]),
  ...baselineApi.map((row) => row[3]),
].filter(Boolean));

const mappedAuthorities = authorityRegister.authorities ?? {};

if (namedAuthorities.size === 0) {
  errors.push('No authorities were parsed from the controlled documents; this check would pass over nothing.');
}

for (const phrase of namedAuthorities) {
  const decision = mappedAuthorities[phrase];
  if (!decision) {
    errors.push(
      `The controlled documents name the authority "${phrase}" and ` +
      'traceability/controlled-authorities.json records no decision for it. An authority ' +
      'with no recorded mapping is a mapping made silently somewhere else.');
    continue;
  }
  const roles = decision.roles ?? [];
  if (roles.length === 0 && !decision.subject) {
    errors.push(
      `"${phrase}" is mapped to neither a role nor a stated reason for not being one.`);
  }
  for (const role of roles) {
    if (!declaredRoles.includes(role)) {
      errors.push(
        `"${phrase}" maps to the role "${role}", which CinerionRoles does not define.`);
    }
  }
}

for (const phrase of Object.keys(mappedAuthorities)) {
  if (!namedAuthorities.has(phrase)) {
    errors.push(
      `traceability/controlled-authorities.json maps "${phrase}", which no controlled document ` +
      'names. A register that can outlive its source stops being a reconciliation.');
  }
}

// Operations this deployment serves that the P03 catalogue does not contain, each one an
// owner decision recorded with the screen it serves and the reason it exists.
//
// THE TWO SETS NEVER MERGE. The catalogue stays exactly 54, frozen and SHA-256 verified by
// npm run baseline, and nothing here edits it. What this adds is a second, smaller set that
// a runtime route may belong to instead - so a route is either controlled, or approved and
// explained, and never merely unnoticed. The counts are reported separately for the same
// reason: an extension that could be read as a controlled operation would be the
// overstatement this whole repository is arranged to prevent.
//
// Every entry is a READ. That is what makes the register safe to have at all: a read cannot
// weaken an interlock, a credential proof, a local confirmation or a segregation rule, and
// the project scope and role checks apply to it exactly as they apply to a controlled read.
// The check below refuses a non-GET entry outright, so the constraint is enforced rather
// than merely stated in the file's own prose.
const approvedRegister = JSON.parse(
  await readFile(resolve(root, 'traceability/owner-approved-operations.json'), 'utf8'));
const approvedApi = new Map();
for (const operation of approvedRegister.operations) {
  const key = `${operation.method} ${operation.path}`;
  if (operation.method !== 'GET') {
    errors.push(
      `Owner-approved operation ${key} is not a read. This register may only carry reads: ` +
      'a write outside the controlled catalogue is a controlled operation that has not been ' +
      'controlled.');
  }
  if (expectedApi.has(key)) {
    errors.push(
      `Owner-approved operation ${key} is already in the P03 catalogue, so approving it ` +
      'separately would record a decision nobody needed to take.');
  }
  for (const field of ['summary', 'authority', 'controls', 'servesScreen', 'reason']) {
    if (!operation[field]) {
      errors.push(`Owner-approved operation ${key} does not state its ${field}.`);
    }
  }
  approvedApi.set(key, operation);
}
const exposed = new Map();
const endpointDirectory = resolve(root, 'services/control-core/src/Cinerion.Api/Endpoints');
for (const entry of await readdir(endpointDirectory)) {
  if (!entry.endsWith('Endpoints.cs')) continue;
  const text = await readFile(resolve(endpointDirectory, entry), 'utf8');
  const group = /MapGroup\("([^"]+)"\)/.exec(text)?.[1] ?? '';
  for (const match of text.matchAll(/group\.Map(Get|Post|Put|Patch|Delete)\("([^"]+)"/g)) {
    record(match[1].toUpperCase(), `${group}${match[2]}`, entry);
  }
  for (const match of text.matchAll(/endpoints\.Map(Get|Post|Put|Patch|Delete)\("([^"]+)"/g)) {
    record(match[1].toUpperCase(), match[2], entry);
  }
  if (entry === 'DeferredCatalogueEndpoints.cs') {
    for (const match of text.matchAll(/\("(GET|POST|PUT|PATCH|DELETE)",\s*"([^"]+)"/g)) {
      record(match[1], match[2], entry);
    }
  }
}

function record(method, rawPath, source) {
  const path = rawPath.replace(/:guid}/g, '}');
  const key = `${method} ${path}`;
  const sources = exposed.get(key) ?? [];
  sources.push(source);
  exposed.set(key, sources);
}

for (const key of expectedApi) {
  const sources = exposed.get(key) ?? [];
  if (sources.length === 0) errors.push(`Baseline API operation is absent from runtime catalogue: ${key}`);
  if (sources.length > 1) errors.push(`Baseline API operation is mapped more than once: ${key} (${sources.join(', ')})`);
}
for (const [key] of exposed) {
  if (expectedApi.has(key) || key === 'GET /api/v1/system/prototype-seed') continue;
  if (approvedApi.has(key)) continue;
  errors.push(
    `Runtime API operation is neither controlled by the P03 catalogue nor recorded in ` +
    `traceability/owner-approved-operations.json: ${key}`);
}

// An approved operation that nothing serves is a decision nobody acted on, and it would sit
// in the register looking like capability. Refused on the same terms as the reverse.
for (const [key, operation] of approvedApi) {
  if (!exposed.has(key)) {
    errors.push(
      `Owner-approved operation is recorded but not served: ${key} (for ${operation.servesScreen})`);
  }
}

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(`Repository policy valid: ${relativeFiles.length} files checked; ${expectedApi.size} controlled API operations represented exactly once.`);
  console.log(
    `${approvedApi.size} owner-approved read operations outside the controlled catalogue, ` +
    `each recorded with the screen it serves: ` +
    `${[...approvedApi.values()].map((operation) => operation.servesScreen).join(', ')}.`);
  console.log(
    'Safety boundary valid: no portal local-commit route, and no output energised anywhere in ' +
    `${firmwareSources.length} firmware sources — outputs are planned, and the pin map declares ` +
    `${(pinMap.signals ?? []).filter((signal) => signal.actuator).length} actuator signals, none energisable ` +
    `at hardware revision ${pinMap.hardwareRevision}.`);
  console.log(`Identity contract valid: ${realmRoles.size} realm roles reconciled with CinerionRoles; step-up is not a stored attribute.`);
  console.log(
    `Controlled authorities reconciled: ${namedAuthorities.size} authority phrases in access.json and ` +
    'api_endpoints.json, every one mapped to a role CinerionRoles defines or to a stated reason for ' +
    'not being a role.');

  // Controlled verification cases this gate is offered as evidence for. Printed only
  // after every check above has held, and read from an actual run by
  // scripts/check-verification.mjs, so the binding cannot outlive the check.
  //   0066 - no AI role exists to hold command, approval or release authority, and the
  //          realm/CinerionRoles reconciliation fails if one appears.
  //   0070 - no portal local-commit route and no actuator GPIO in the ESP32 entry point.
  //   0082 - no private key, cloud access key, credential literal or packaged secret path.
  //   0121 - the broker requires TLS 1.3, client certificates and no anonymous access.
  //   0134 - neither the portal nor the standard controller can be given safety credit,
  //          because neither carries a route or an output that could earn it.
  console.log('VERIFICATION-CASE CH1-VVT-TC-0066 CH1-VVT-TC-0070 CH1-VVT-TC-0082 CH1-VVT-TC-0121 CH1-VVT-TC-0134');
}
