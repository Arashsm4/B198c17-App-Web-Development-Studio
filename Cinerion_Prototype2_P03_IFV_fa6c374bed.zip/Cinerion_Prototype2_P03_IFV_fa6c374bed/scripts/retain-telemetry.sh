#!/usr/bin/env sh
# The controlled telemetry disposal procedure — CH1-DBA-DD-0001.
#
#   "Retention is based on evidence, legal and project needs; deletion is authorised,
#    logged and compatible with immutable-release obligations."
#
# This is an ADMINISTRATIVE act, not a service function, and deliberately has no API
# operation behind it. The P03 catalogue contains none, `scripts/check-repository-policy.mjs`
# would fail the build on one that was invented, and CH1-DBA-DD-0001 describes disposal as
# an authorised administrative process rather than something a running service does to
# itself. So it is run by a person, as a distinct database role, with a name and a reason.
#
# What it will not do, and why each is a refusal rather than a warning:
#
#   * run without a named authoriser and a stated reason — an authorisation with nobody's
#     name on it is not one;
#   * run with a retention window under 7 days — "delete everything" is a mistake, not a
#     policy, and the floor is in the database rather than in this script;
#   * delete anything other than raw telemetry — the role it connects as holds DELETE on
#     exactly one table, so alarms, measurements, release records and the audit chain are
#     out of reach whatever this script asks for;
#   * delete a sample that is evidence for a permanent record — samples inside an alarm's
#     window and samples a controlled measurement was taken from are retained regardless of
#     age, which is CH1-DBA-DD-0001's "critical events and acceptance measurements are never
#     lost through telemetry downsampling";
#   * delete a sample before an hourly summary standing in for it exists — the entity
#     register makes TelemetrySample "Configurable; summary permanent", so nothing
#     disappears without leaving an aggregate.
#
# Usage:
#   CINERION_RETENTION_CONNECTION='postgres://cinerion_retention@host/db' \
#   scripts/retain-telemetry.sh --project <uuid> --days <n> --by <name> --reason <text>
#
# Documented in docs/operations/TELEMETRY_RETENTION.md.
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

project=""
days=""
authorised_by=""
reason=""
dry_run=false

while [ $# -gt 0 ]; do
  case "$1" in
    --project) project=$2; shift 2 ;;
    --days) days=$2; shift 2 ;;
    --by) authorised_by=$2; shift 2 ;;
    --reason) reason=$2; shift 2 ;;
    --dry-run) dry_run=true; shift ;;
    *) echo "retain-telemetry.sh: unknown argument $1" >&2; exit 2 ;;
  esac
done

if [ -z "$project" ] || [ -z "$days" ] || [ -z "$authorised_by" ] || [ -z "$reason" ]; then
  echo "retain-telemetry.sh: --project, --days, --by and --reason are all required." >&2
  echo "CH1-DBA-DD-0001 makes disposal authorised and logged; an unattributed run is refused here" >&2
  echo "and again by the database." >&2
  exit 2
fi

if [ -z "${CINERION_RETENTION_CONNECTION:-}" ]; then
  echo "retain-telemetry.sh: CINERION_RETENTION_CONNECTION is not set." >&2
  echo "It must name the cinerion_retention role, which holds DELETE on ch1.telemetry_samples" >&2
  echo "and on nothing else. Connecting as the application role or the owner would defeat the" >&2
  echo "separation this procedure depends on." >&2
  exit 2
fi

# Refuse a connection that is not the retention role before anything is written. Running
# this as the owner would work and would silently remove every protection below.
identity=$(psql "$CINERION_RETENTION_CONNECTION" -tAc "SELECT current_user")
if [ "$identity" != "cinerion_retention" ]; then
  echo "retain-telemetry.sh: connected as '$identity', not cinerion_retention." >&2
  echo "The separation of authority is the control here, so this refuses rather than proceeding." >&2
  exit 3
fi

superuser=$(psql "$CINERION_RETENTION_CONNECTION" -tAc \
  "SELECT rolsuper OR rolbypassrls FROM pg_roles WHERE rolname = current_user")
if [ "$superuser" != "f" ]; then
  echo "retain-telemetry.sh: cinerion_retention is a superuser or bypasses row-level security." >&2
  echo "Project isolation would not apply to this disposal, so it refuses." >&2
  exit 3
fi

if [ "$dry_run" = true ]; then
  # Counts only. Nothing is summarised and nothing is deleted, so an operator can see the
  # shape of a disposal before authorising it.
  psql "$CINERION_RETENTION_CONNECTION" -v ON_ERROR_STOP=1 -v project="$project" -v days="$days" <<'SQL'
SET LOCAL ch1.project_id = :'project';
WITH cutoff AS (SELECT clock_timestamp() - make_interval(days => :days::int) AS at)
SELECT
    (SELECT count(*) FROM ch1.telemetry_samples s, cutoff c
      WHERE s.project_id = :'project'::uuid AND s.sampled_at < c.at) AS older_than_cutoff,
    (SELECT count(*) FROM ch1.telemetry_samples s, cutoff c
      WHERE s.project_id = :'project'::uuid AND s.sampled_at < c.at
        AND (EXISTS (SELECT 1 FROM ch1.alarms a
                     WHERE a.project_id = s.project_id AND a.cell_id = s.cell_id
                       AND a.source_id = s.device_id AND s.sampled_at >= a.activated_at
                       AND s.sampled_at <= coalesce(a.cleared_at, s.sampled_at))
          OR EXISTS (SELECT 1 FROM ch1.measurements m
                     WHERE m.project_id = s.project_id AND m.source_device_id = s.device_id
                       AND m.source_sample_time = s.sampled_at))) AS protected_as_evidence;
SQL
  echo
  echo "Dry run only. Nothing was summarised and nothing was deleted."
  exit 0
fi

# One transaction: the summary and the deletion it authorises either both happen or neither
# does. SET LOCAL scopes the project claim to it, so the disposal cannot outlive its scope.
psql "$CINERION_RETENTION_CONNECTION" -v ON_ERROR_STOP=1 \
  -v project="$project" -v days="$days" -v by="$authorised_by" -v reason="$reason" <<'SQL'
BEGIN;
SET LOCAL ch1.project_id = :'project';
SELECT authorised_by, reason, retention_days, cutoff,
       samples_summarised, samples_deleted, samples_retained_as_evidence, buckets_written
FROM ch1.dispose_telemetry(:'project'::uuid, :days::int, :'by', :'reason');
COMMIT;
SQL

echo
echo "Disposal recorded in ch1.telemetry_disposals, which is append-only."
echo "Raw samples that evidenced an alarm or a controlled measurement were retained regardless"
echo "of age, and every deleted sample is represented by a permanent hourly summary."
