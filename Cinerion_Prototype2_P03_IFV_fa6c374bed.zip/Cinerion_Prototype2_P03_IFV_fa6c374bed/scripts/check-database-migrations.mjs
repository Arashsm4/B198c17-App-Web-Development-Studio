// Reconciles the controlled migration set with the two places that must track it.
//
// A migration exists in exactly one directory, but two independent artefacts have to
// know about it: the data laboratory initialises a first-run database from the files
// infrastructure/compose.yaml mounts, and Control Core refuses to start against a
// database behind its own build by probing the columns CinerionDataSource declares.
// Neither is generated from the directory, so both drift silently.
//
// Both had drifted when this check was written. 0009_reports_and_scan_events.sql was
// mounted nowhere, so a fresh laboratory database had no ch1.reports and no
// ch1.scan_events; and the startup probe stopped at 0008, so it reported the schema
// current and Control Core started against it. The first report or part scan would then
// have failed in front of a user, which is the exact outcome the probe exists to
// prevent. This is the same defect class as the one that made the laboratory database
// unable to be correct at all, so it is closed with a gate rather than only a patch.

import { readdir, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const migrationDirectory = 'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations';
const errors = [];

const migrations = (await readdir(resolve(root, migrationDirectory)))
  .filter((name) => name.endsWith('.sql'))
  .sort();

if (migrations.length === 0) {
  errors.push(`No migrations found under ${migrationDirectory}.`);
}

// Migrations the column probe cannot represent, each for a stated reason. Anything
// else must be represented, so a new migration cannot be added without deciding how
// a database missing it will be detected.
const probeExempt = new Map([
  ['0001_ch1_foundation.sql', 'the foundation schema; absence is caught by the ch1 schema presence probe'],
  ['0002_application_role.sql', 'creates the non-superuser role only, which is not a schema column'],
  ['0011_retention_role.sql', 'creates the retention role and its grants only, which are cluster and schema objects rather than columns; re-asserted by scripts/restore.sh for exactly that reason'],
]);

// -- 1. Every migration is mounted into a first-run laboratory database, in order. ----

const compose = await readFile(resolve(root, 'infrastructure/compose.yaml'), 'utf8');
const mounts = [...compose.matchAll(
  /\.\.\/(services\/[^:\s]+\/Migrations\/([^:\s]+\.sql)):\/docker-entrypoint-initdb\.d\/([^:\s]+\.sql):ro/g)];

const mountedNames = mounts.map((match) => match[2]);
for (const [, source, name, target] of mounts) {
  if (name !== target) {
    errors.push(`Compose mounts ${name} as ${target}; PostgreSQL runs init scripts in lexical order of the target name.`);
  }
  if (!migrations.includes(name)) {
    errors.push(`Compose mounts a migration that does not exist: ${source}`);
  }
}
for (const name of migrations) {
  if (!mountedNames.includes(name)) {
    errors.push(
      `Migration ${name} is not mounted in infrastructure/compose.yaml: a first-run data-lab database would be behind this build.`);
  }
}
if (mountedNames.join(',') !== [...mountedNames].sort().join(',')) {
  errors.push(`Compose mounts migrations out of order: ${mountedNames.join(', ')}`);
}

// -- 2. Every migration is detectable by the startup probe. --------------------------

const dataSourcePath = 'services/control-core/src/Cinerion.Infrastructure/Persistence/CinerionDataSource.cs';
const dataSource = await readFile(resolve(root, dataSourcePath), 'utf8');
const declaration = /RequiredColumns\s*=\s*\[(.*?)\n\s*\];/s.exec(dataSource);
if (!declaration) {
  errors.push(`Could not read RequiredColumns from ${dataSourcePath}; this check would otherwise pass over nothing.`);
}

const required = [...(declaration?.[1] ?? '').matchAll(/\(\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\)/g)]
  .map(([, table, column, migration]) => ({ table, column, migration }));

if (declaration && required.length === 0) {
  errors.push(`RequiredColumns in ${dataSourcePath} parsed as empty; the startup probe would check nothing.`);
}

const sql = new Map();
for (const name of migrations) {
  sql.set(name, await readFile(resolve(root, migrationDirectory, name), 'utf8'));
}

for (const { table, column, migration } of required) {
  const text = sql.get(migration);
  if (text === undefined) {
    errors.push(`Startup probe names a migration that does not exist: ${migration}`);
    continue;
  }
  if (!new RegExp(`ch1\\.${table}\\b`).test(text)) {
    errors.push(`Startup probe expects ch1.${table} from ${migration}, which never mentions that table.`);
  }
  if (!new RegExp(`\\b${column}\\b`).test(text)) {
    errors.push(`Startup probe expects ${table}.${column} from ${migration}, which never mentions that column.`);
  }
}

const probed = new Set(required.map((entry) => entry.migration));
for (const name of migrations) {
  if (probeExempt.has(name)) {
    if (probed.has(name)) {
      errors.push(`${name} is listed as exempt from the startup probe (${probeExempt.get(name)}) but is also probed.`);
    }
    continue;
  }

  const text = sql.get(name);
  const created = [...text.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?ch1\.([a-z_]+)/g)].map((match) => match[1]);
  const addsColumns = /ADD COLUMN/.test(text);

  if (created.length === 0 && !addsColumns) {
    errors.push(
      `${name} creates no table and adds no column, so no exemption reason is recorded and the startup probe cannot detect it.`);
    continue;
  }

  // Every table a migration creates must be probed. A migration that creates two
  // tables and is probed for only one leaves the other undetectable, which is how
  // ch1.reports and ch1.scan_events both went missing from the laboratory database.
  for (const table of created) {
    if (!required.some((entry) => entry.migration === name && entry.table === table)) {
      errors.push(
        `${name} creates ch1.${table} but the startup probe does not check it: a database missing it would start and fail later.`);
    }
  }
  if (created.length === 0 && !probed.has(name)) {
    errors.push(`${name} adds columns but the startup probe does not check any of them.`);
  }
}

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(
    `Migration set valid: ${migrations.length} migrations, all mounted for a first-run database in order, ` +
    `${required.length} startup probes covering every migration that is not exempt.`);
}
