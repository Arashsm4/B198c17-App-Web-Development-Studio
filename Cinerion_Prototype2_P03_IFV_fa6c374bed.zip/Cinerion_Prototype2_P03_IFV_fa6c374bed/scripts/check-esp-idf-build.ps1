# Builds firmware/esp32 with the real ESP-IDF toolchain, on Windows.
#
# The Windows sibling of scripts/check-esp-idf-build.sh, and it exists because ESP-IDF
# cannot be driven from Git Bash on this platform at all. Two separate reasons, both
# observed rather than assumed:
#
#   * `export.ps1` exposes `idf.py` as a POWERSHELL FUNCTION, not as an executable on
#     PATH, so the sh script's `command -v idf.py` finds nothing however correctly the
#     toolchain is installed;
#   * invoking `tools/idf.py` directly from Git Bash picks the system interpreter rather
#     than the IDF virtual environment and dies with "No module named 'rich_click'", and
#     `idf_tools.py` refuses MSys outright ("MSys/Mingw is not supported").
#
# The sh script's preflight reported "IDF_PATH is unset or does not name a directory" for
# a toolchain that was fully installed, because IDF_PATH holds a Windows path that
# `[ -d ]` cannot resolve. That reads as a missing toolchain and is not one.
#
# *** DELIBERATELY NOT IN verify.sh, AND THAT IS THE POINT. ***
#
# Defect 51 was a harness that could not be run printing `SKIPPED locally` while the
# pipeline exited 0. An optional step inside the strict pipeline is exactly that shape, so
# this is not one. It is run on demand, on a workstation that has the toolchain, and its
# result belongs in the handover as a dated observation.
#
# What it establishes that nothing else can: firmware/esp32/main/time_sync.cpp is
# COMPILED. That file had never been built by anything — it is excluded from the host
# build for a stated reason, esp_netif_sntp.h being macro-heavy enough that a hand-written
# stub would be coverage that only looks like coverage — so the real toolchain is the only
# honest way to compile it. It also compiles the component's dependency declaration for
# the first time, and the first run of this found defect 79: three of the six components
# `REQUIRES` named were wrong for ESP-IDF v6.0, and the project could not even configure.
#
# This flashes nothing and drives nothing. There is no board attached and no actuator, and
# CH1-EMB-FDS-0001's P03 verification boundary defers independent review until before
# hazardous energisation.
#
# Usage, from a plain PowerShell prompt:
#   . C:\esp\esp-idf\export.ps1
#   .\scripts\check-esp-idf-build.ps1

# Deliberately NOT 'Stop'. Windows PowerShell 5.1 wraps every stderr line a native
# executable writes in an ErrorRecord, and idf.py writes its configuration report there —
# so 'Stop' turns ordinary build output into a terminating error and the gate fails on a
# build that succeeded. Exit codes are checked explicitly below instead, which is the only
# honest signal a native command gives.
$ErrorActionPreference = 'Continue'
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo

if (-not $env:IDF_PATH -or -not (Test-Path -PathType Container $env:IDF_PATH)) {
    Write-Output 'ESP-IDF BUILD: NOT RUN - IDF_PATH is unset or does not name a directory.'
    Write-Output '  This is a statement, not a pass. Nothing in this repository has compiled'
    Write-Output '  firmware/esp32/main/time_sync.cpp except this script.'
    Write-Output '  Install ESP-IDF, then run:  . <IDF_PATH>\export.ps1'
    exit 2
}

# idf.py is a function that export.ps1 defines; Get-Command finds it only in a session
# that has sourced it. Checking for the function rather than for an executable is the
# whole difference between this script and the sh one.
if (-not (Get-Command idf.py -ErrorAction SilentlyContinue)) {
    Write-Output 'ESP-IDF BUILD: NOT RUN - IDF_PATH is set but idf.py is not available.'
    Write-Output '  Dot-source the export script in THIS session: . $env:IDF_PATH\export.ps1'
    Write-Output '  Setting IDF_PATH alone does not configure the toolchain, and a build'
    Write-Output '  attempted without it fails for a reason that has nothing to do with'
    Write-Output '  this firmware.'
    exit 2
}

Write-Output "ESP-IDF at $env:IDF_PATH"
idf.py --version

# The target is the module the controlled pin map names. Stated here rather than left to
# whatever a stale sdkconfig holds: firmware/pinmap/esp32s3-r01.json is the
# hardware-revision-controlled derivative of the controlled I/O table, and a build for
# another target would be a build of different code.
Write-Output 'Target: esp32s3, from the controlled pin map''s module'
idf.py -C firmware/esp32 set-target esp32s3
if ($LASTEXITCODE -ne 0) { Write-Output "ESP-IDF BUILD: FAILED - set-target exited $LASTEXITCODE."; exit 1 }

idf.py -C firmware/esp32 build
if ($LASTEXITCODE -ne 0) { Write-Output "ESP-IDF BUILD: FAILED - build exited $LASTEXITCODE."; exit 1 }

# The build is only evidence about time_sync.cpp if time_sync.cpp was actually one of the
# translation units. A component whose SRCS list lost the file would still build, and
# would still print "Project build complete" — which is the shape of a gate that passes
# over nothing. The object file is the measurement.
$objects = @(
    'firmware/esp32/build/esp-idf/main/CMakeFiles/__idf_main.dir/app_main.cpp.obj',
    'firmware/esp32/build/esp-idf/main/CMakeFiles/__idf_main.dir/time_sync.cpp.obj'
)
$missing = $objects | Where-Object { -not (Test-Path $_) }
if ($missing) {
    Write-Output ''
    Write-Output 'ESP-IDF BUILD: FAILED - the build completed without compiling:'
    $missing | ForEach-Object { Write-Output "  $_" }
    Write-Output '  A build that does not compile the file this gate exists for is not evidence.'
    exit 1
}

Write-Output ''
Write-Output 'ESP-IDF BUILD: COMPLETED.'
Write-Output '  Compiled, and NOT flashed, NOT linked against a board, NOT run. No hardware is'
Write-Output '  attached. What this establishes is that the component builds with the real headers'
Write-Output '  - including time_sync.cpp, which nothing had ever compiled - and that its REQUIRES'
Write-Output '  set is sufficient for the headers its sources include.'
Write-Output '  It establishes nothing about behaviour on the board. CH1-VVT-HIL-0001''s cases still'
Write-Output '  need the rig, and CH1-EMB-FDS-0001 defers independent review until before hazardous'
Write-Output '  energisation.'
