// Compares the RUNNING identity realm against the file that declares it.
//
// This exists because of a month-long silent divergence. Keycloak imports a realm only
// when that realm does not already exist, and `cinerion_cinerion-identity-db` is a named
// volume that outlives every restart and survives `docker volume prune` - so a lab that
// has ever been started ignores every later edit to `cinerion-realm.json`. Nothing
// noticed, because `npm run policy` reconciles `CinerionRoles` against the FILE. The
// `ProjectOwner` role was declared in the file, absent from the running realm, and added
// by hand when somebody happened to look.
//
// The general shape is worth more than the instance: a gate that reads a declaration and
// a gate that reads a deployment are different gates, and this repository had only the
// first. What this refuses is the second kind of error - a realm that is not what the
// file says it is - and it can only be run against a live provider.
//
// It is therefore deliberately NOT in `verify.sh`. An optional step inside a strict
// pipeline is defect 51's exact shape: it would print a skip and the run would exit 0.
// It exits 2 with a statement when the provider is unreachable, exactly as
// `check-esp-idf-build.sh` does for a missing toolchain, and `npm run lab:up` runs it
// after raising the stack, which is where a live provider is guaranteed to exist.
//
// It reads and never writes. Realigning a drifted realm is `provision-portal-identities.sh`
// for identities, and a decision for a person for anything else: this says what differs
// and stops.
//
//   npm run realm:drift

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const authority = process.env.CINERION_KEYCLOAK_URL ?? 'http://localhost:8180';

const failures = [];
const notes = [];
let checks = 0;

function that(label, condition, detail) {
  checks += 1;
  if (condition === true) {
    console.log(`PASS  ${label}`);
    return true;
  }
  console.log(`FAIL  ${label}${detail === undefined ? '' : ` — ${detail}`}`);
  failures.push(label);
  return false;
}

function unreachable(message) {
  console.error(`\n${message}`);
  console.error(
    'This gate can only compare a running realm with the file, so it establishes nothing ' +
    'here and says so rather than passing. Raise the identity lab with "npm run lab:up".');
  process.exit(2);
}

/** Reads a value out of the secrets file without sourcing it. */
async function readSecret(name) {
  const text = await readFile(resolve(root, 'infrastructure/.env.local'), 'utf8').catch(() => undefined);
  if (text === undefined) return undefined;
  for (const line of text.split(/\r?\n/)) {
    if (line.startsWith(`${name}=`)) return line.slice(name.length + 1);
  }
  return undefined;
}

const admin = await readSecret('CINERION_KEYCLOAK_ADMIN');
const adminPassword = await readSecret('CINERION_KEYCLOAK_ADMIN_PASSWORD');
if (!admin || !adminPassword) {
  unreachable('infrastructure/.env.local carries no Keycloak administrator credentials.');
}

const declared = JSON.parse(
  await readFile(resolve(root, 'infrastructure/keycloak/cinerion-realm.json'), 'utf8'));

let token;
try {
  const response = await fetch(`${authority}/realms/master/protocol/openid-connect/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: 'admin-cli',
      username: admin,
      password: adminPassword,
      grant_type: 'password',
    }),
  });
  if (!response.ok) {
    unreachable(`The identity provider at ${authority} refused the administrator: ${response.status}.`);
  }
  token = (await response.json()).access_token;
} catch (cause) {
  unreachable(`The identity provider at ${authority} could not be reached: ${cause.message}`);
}

async function adminApi(path) {
  const response = await fetch(`${authority}/admin/realms/${declared.realm}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (response.status === 404) return undefined;
  if (!response.ok) {
    throw new Error(`GET ${path} answered ${response.status}`);
  }
  return response.json();
}

const running = await adminApi('');
if (running === undefined) {
  unreachable(`The realm "${declared.realm}" does not exist at ${authority}.`);
}

console.log(`Comparing the running realm at ${authority} with infrastructure/keycloak/cinerion-realm.json\n`);

// ---------------------------------------------------------------------------
// Realm-level settings.
//
// Every scalar the FILE states is compared. Deliberately derived from the file rather
// than from a list written here: a list would have to be extended whenever a setting was
// added to the realm, and the setting most likely to drift is the one somebody has just
// added. Keys beginning with an underscore are this repository's own annotations and are
// not Keycloak settings.
// ---------------------------------------------------------------------------
const scalarKeys = Object.keys(declared).filter(
  (key) => !key.startsWith('_') && (typeof declared[key] !== 'object' || declared[key] === null),
);
for (const key of scalarKeys) {
  that(
    `realm setting ${key} is ${JSON.stringify(declared[key])}`,
    running[key] === declared[key],
    `the running realm has ${JSON.stringify(running[key])}`,
  );
}

// ---------------------------------------------------------------------------
// Realm roles. This is the check that would have caught ProjectOwner.
// ---------------------------------------------------------------------------
const declaredRoles = (declared.roles?.realm ?? []).map((role) => role.name).sort();
const runningRoles = ((await adminApi('/roles')) ?? []).map((role) => role.name);
for (const role of declaredRoles) {
  that(`realm role ${role} exists in the running realm`, runningRoles.includes(role));
}
// A role present only in the running realm is not automatically wrong - Keycloak adds its
// own defaults - but one that is neither declared nor a Keycloak default is an authority
// nobody reviewed, and is reported.
const KEYCLOAK_BUILT_IN_ROLES = new Set(['default-roles-' + declared.realm, 'offline_access', 'uma_authorization']);
for (const role of runningRoles) {
  if (declaredRoles.includes(role) || KEYCLOAK_BUILT_IN_ROLES.has(role)) continue;
  that(
    `realm role ${role} is declared in the file`,
    false,
    'it exists in the running realm and nothing declares it, so no review covered it',
  );
}

// ---------------------------------------------------------------------------
// Clients. A redirect URI or a public-client flag that has drifted is an authentication
// boundary that has drifted.
// ---------------------------------------------------------------------------
const runningClients = (await adminApi('/clients')) ?? [];
const COMPARED_CLIENT_FIELDS = [
  'publicClient',
  'standardFlowEnabled',
  'directAccessGrantsEnabled',
  'serviceAccountsEnabled',
  'implicitFlowEnabled',
  'bearerOnly',
];
for (const client of declared.clients ?? []) {
  const live = runningClients.find((candidate) => candidate.clientId === client.clientId);
  if (!that(`client ${client.clientId} exists`, live !== undefined)) continue;
  for (const field of COMPARED_CLIENT_FIELDS) {
    if (client[field] === undefined) continue;
    that(
      `client ${client.clientId} has ${field} = ${client[field]}`,
      live[field] === client[field],
      `the running client has ${JSON.stringify(live[field])}`,
    );
  }
  for (const [collection, label] of [['redirectUris', 'redirect URI'], ['webOrigins', 'web origin']]) {
    for (const value of client[collection] ?? []) {
      that(
        `client ${client.clientId} permits ${label} ${value}`,
        (live[collection] ?? []).includes(value),
        `the running client permits ${JSON.stringify(live[collection] ?? [])}`,
      );
    }
    // The stronger direction: a redirect URI the running realm accepts and the file does
    // not declare is somewhere an authorisation code can be sent that nobody reviewed.
    for (const value of live[collection] ?? []) {
      that(
        `client ${client.clientId} permits no ${label} the file does not declare (${value})`,
        (client[collection] ?? []).includes(value),
      );
    }
  }
}

// ---------------------------------------------------------------------------
// Users and their role mappings.
// ---------------------------------------------------------------------------
for (const user of declared.users ?? []) {
  const matches = (await adminApi(`/users?username=${encodeURIComponent(user.username)}&exact=true`)) ?? [];
  const live = matches[0];
  if (!that(`identity ${user.username} exists`, live !== undefined)) continue;
  that(
    `identity ${user.username} is enabled as declared`,
    live.enabled === (user.enabled ?? true),
    `the running identity has enabled = ${live.enabled}`,
  );
  const mapped = ((await adminApi(`/users/${live.id}/role-mappings/realm`)) ?? []).map((role) => role.name);
  for (const role of user.realmRoles ?? []) {
    that(`identity ${user.username} holds ${role}`, mapped.includes(role));
  }
  // Roles the running identity holds that the file does not declare. Reported as a NOTE
  // rather than a failure: `provision-portal-identities.sh` deliberately grants more than
  // the file does, and says why, so a failure here would refuse the repository's own
  // documented practice. It is still printed, because an unreviewed role on a live
  // identity is exactly the thing nobody was looking at.
  const extra = mapped.filter(
    (role) => !(user.realmRoles ?? []).includes(role) && !KEYCLOAK_BUILT_IN_ROLES.has(role),
  );
  if (extra.length > 0) {
    notes.push(
      `${user.username} holds ${extra.join(', ')} in the running realm and the file does not ` +
      'declare them. scripts/provision-portal-identities.sh grants the full set; the file is ' +
      'what a FRESH lab gets.');
  }
}

console.log();
for (const note of notes) console.log(`NOTE  ${note}`);
if (notes.length > 0) console.log();

if (failures.length > 0) {
  console.error(
    `Realm drift: ${failures.length} of ${checks} comparisons failed. The running realm at ` +
    `${authority} is not what infrastructure/keycloak/cinerion-realm.json declares.`);
  console.error(
    'Keycloak imports a realm only when it does not already exist, so editing the file does ' +
    'not change a lab that has already been started. Either realign the running realm, or ' +
    'take the identity-db volume down and let the file be imported again.');
  process.exit(1);
}

console.log(
  `Realm reconciled against the running provider: ${checks} comparisons, 0 differences. ` +
  `${declaredRoles.length} declared realm roles, ${(declared.clients ?? []).length} clients, ` +
  `${(declared.users ?? []).length} declared identities.`);
