#!/usr/bin/env sh
# Checks the RUNNING lab, which is the only place several controls actually execute.
#
# This exists because `npm run commit:loop` passed while device authentication was
# completely broken against PostgreSQL. That gate runs on the in-memory store - it has to,
# because on PostgreSQL a cell's interlocks are not persisted and the controller reports
# OFFLINE, so no command can be prepared - and the in-memory store has no
# `CinerionDataSource` to dispose. The synchronous scope disposal that threw therefore never
# ran in any test, and every device request in the containerised lab answered 500 AFTER
# authenticating perfectly.
#
# So this checks the lab, and the check that matters is the shape of a refusal. Asking the
# stand-in controller to confirm a command that does not exist must produce a 404 from
# Control Core: a 404 proves the client certificate was accepted, the enrolled device record
# was resolved under row-level security, and the command register was read. A 500 proves the
# request never got that far, and is what the defect looked like.
#
# Read-only. It prepares nothing, confirms nothing and changes no record.
#
# Usage: npm run lab:check
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

api=${CINERION_LAB_API:-http://localhost:5080}
portal=${CINERION_LAB_PORTAL:-http://localhost:8081}
confirmer=${CINERION_LAB_CONFIRMER:-http://localhost:5085}

failures=0
checks=0
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); checks=$((checks + 1)); }
pass() { printf 'PASS  %s\n' "$*"; checks=$((checks + 1)); }

health=$(curl -fsS "$api/api/v1/system/health" 2>/dev/null) || {
  echo "check-lab.sh: Control Core is not answering at $api. Raise the lab with npm run lab:up." >&2
  exit 2
}
pass "Control Core answers its health endpoint"

case "$health" in
  *'"runtimeProfile":"Simulation"'*) pass "the lab runs the Simulation profile" ;;
  *) fail "the lab is not in the Simulation profile: $health" ;;
esac
case "$health" in
  *'"developmentIdentityEnabled":false'*) pass "development identity is OFF, so the portal signs in for real" ;;
  *) fail "development identity is enabled in the lab, so no OIDC token would ever be validated" ;;
esac
case "$health" in
  *'"deviceIdentityListenerEnabled":true'*) pass "the device listener is enabled, so a controller can reach this service" ;;
  *) fail "the device listener is not enabled, so no controller can answer a prepared command" ;;
esac

# The literal, which must be refused. AllowedHosts=localhost is the control.
literal=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${api##*:}/api/v1/system/health" 2>/dev/null) || true
[ -n "$literal" ] || literal=000
if [ "$literal" = "400" ]; then
  pass "the same service addressed as 127.0.0.1 answers 400, which is AllowedHosts working"
else
  fail "127.0.0.1 answered $literal rather than 400"
fi

portal_status=$(curl -s -o /dev/null -w '%{http_code}' "$portal/" 2>/dev/null) || true
[ -n "$portal_status" ] || portal_status=000
if [ "$portal_status" = "200" ]; then
  pass "the portal is served"
else
  fail "the portal answered $portal_status"
fi

# The portal's Content-Security-Policy must name every origin its bundle was built to
# reach. A policy that names fewer is a portal whose requests the browser will block, and
# the failure reads as "still loading" rather than as a policy refusal.
policy=$(curl -sI "$portal/" 2>/dev/null | tr -d '\r' | grep -i 'content-security-policy' || true)
for origin in "$api" "$confirmer"; do
  case "$policy" in
    *"$origin"*) pass "the portal is permitted to reach $origin" ;;
    *) fail "the portal's connect-src does not name $origin, so the browser would block it" ;;
  esac
done

confirmer_health=$(curl -fsS "$confirmer/health" 2>/dev/null) || {
  fail "the stand-in cell controller is not answering at $confirmer"
  printf '\nLab check: %s checks, %s failed.\n' "$checks" "$failures"
  exit 1
}
pass "the stand-in cell controller answers"
case "$confirmer_health" in
  *'"physicalEdge":false'*) pass "and states in its own health that no physical edge is observed" ;;
  *) fail "the stand-in does not disclaim a physical edge" ;;
esac

# THE CHECK THIS SCRIPT EXISTS FOR. A command that does not exist must be REFUSED by
# Control Core, not fail. Reaching a refusal means the client certificate was accepted, the
# enrolled device record was resolved under row-level security, and the command register was
# read - every step of device authentication against the real database.
answer=$(curl -s -X POST "$confirmer/confirm" \
  -H 'Content-Type: application/json' \
  -d '{"commandId":"00000000-0000-4000-8000-0000000000ff"}' 2>/dev/null) || true
case "$answer" in
  *'"controlCoreStatus":404'*)
    pass "a device identity reaches Control Core over mutual TLS and is answered 404 for a command that does not exist" ;;
  *'"controlCoreStatus":500'*)
    fail "Control Core answered 500 to an authenticated device read. It authenticated and then faulted: $answer" ;;
  *'"controlCoreStatus":401'*)
    fail "the stand-in's certificate was not accepted. Is CH1-DEV-CELL-0001 enrolled? Run scripts/enrol-cell-confirmer.sh" ;;
  *)
    fail "the stand-in answered something this gate does not recognise: $answer" ;;
esac

# Telemetry is ACCEPTED, not just produced. The simulated source publishes every 5 s, and
# Control Core throws away any sample on a channel the device didn't declare at enrolment.
# For two days this lab threw away every single reading - an old enrolment declared a channel
# nobody publishes - while all ten checks above stayed green. So look for a sample actually
# STORED in the last minute, giving the next tick up to 30 s to land. Still read-only.
telemetry_device=${CINERION_CONFIRMER_CONTROLLER_ID:-CH1-DEV-CELL-0001}
recent=0
if [ -f infrastructure/.env.local ]; then
  tries=0
  while :; do
    recent=$(docker compose --env-file infrastructure/.env.local \
        -f infrastructure/compose.yaml -f infrastructure/compose.lab.yaml \
        --profile data-lab --profile identity-lab \
        exec -T postgres psql -U cinerion_owner -d cinerion -tAc \
        "select count(*) from ch1.telemetry_samples where device_id = '$telemetry_device' and received_at > now() - interval '60 seconds'" \
        2>/dev/null | tr -d '[:space:]') || true
    case "$recent" in ''|*[!0-9]*) recent=0 ;; esac
    [ "$recent" -gt 0 ] && break
    tries=$((tries + 1))
    [ "$tries" -ge 10 ] && break
    sleep 3
  done
fi
if [ "$recent" -gt 0 ]; then
  pass "simulated telemetry is being accepted: $recent samples from $telemetry_device stored in the last minute"
else
  fail "nothing from $telemetry_device was stored in the last minute. Control Core's log says why; an enrolment with an out-of-date manifest is repaired by scripts/enrol-cell-confirmer.sh"
fi

printf '\nLab check: %s checks, %s failed.\n' "$checks" "$failures"
[ "$failures" -eq 0 ] || exit 1

echo
echo "The running lab is what it claims to be: Simulation profile, real sign-in, a device"
echo "listener a controller can reach, and a portal permitted to address everything its"
echo "bundle names. Nothing was prepared, confirmed or changed by this check."
