// Reconciles the register of executable obligations that have NO controlled verification
// case.
//
// docs/baseline/P03_IFV/data/tests.json holds 87 cases and none of them is about telemetry
// retention, record retention, the I/O register, demonstration data, the internal gateway
// interface or the cell state machine's shape. The gates for those announce no case, which
// is correct — binding real evidence to an unrelated case is the overstatement
// traceability/verification-map.json exists to prevent — and the consequence was that the
// evidence appeared in no traceability artefact at all. A reviewer reading traceability/
// could not have known those gates existed.
//
// traceability/executable-obligations.json records them. This gate exists to stop that
// register from ever becoming a second verification map, so it fails when
//
//   * an entry names a controlled verification case anywhere except in its
//     `doesNotEstablish` field — that field is where an entry says which cases its evidence
//     is NOT, and forbidding the name there would forbid the honest sentence, while
//     allowing it anywhere else would let a claim in through prose;
//   * an entry names a gate package.json does not define;
//   * an entry names a requirement, interface or document the controlled baseline does not
//     contain;
//   * an entry names no obligation at all;
//   * or an entry does not say what it fails to establish, because a record of evidence
//     that states only its own strength is an advertisement rather than a record.
//
// It is deliberately a SEPARATE gate rather than a block inside check-verification.mjs,
// where it started. That script raises every container lab and takes about twenty minutes,
// so a check with no runtime dependencies buried inside it is a check nobody runs while
// they are editing the thing it checks — and one that cannot be attacked at all, because an
// attack suite would have to run it three times.

import { readdir, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const load = async (path) => JSON.parse(await readFile(resolve(root, path), 'utf8'));

const CASE_PATTERN = /CH1-VVT-TC-\d{4}/g;

const obligations = await load('traceability/executable-obligations.json');
const requirements = await load('docs/baseline/P03_IFV/data/requirements.json');
const interfaces = await load('docs/baseline/P03_IFV/data/interfaces.json');
const packageScripts = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8')).scripts ?? {};

// requirements.json is a list of OBJECTS with an `id`; the other controlled data files in
// the same directory are lists of row arrays. Reading it as rows produces a set of
// `undefined` and every identifier below fails as unknown, which is exactly how this check
// refused its own register on its first run. The shapes are not uniform and each reader has
// to know which one it has.
const controlledIdentifiers = new Set([
  ...requirements.map((entry) => entry.id),
  ...interfaces.map((row) => row[0]),
  ...(await readdir(resolve(root, 'docs/baseline/P03_IFV/sources')))
    .map((name) => name.replace(/\.md$/, '')),
]);

const entries = obligations.obligations ?? [];
if (entries.length === 0) {
  errors.push('traceability/executable-obligations.json records nothing; this check would pass over nothing.');
}

for (const entry of entries) {
  const { doesNotEstablish, ...claimed } = entry;

  CASE_PATTERN.lastIndex = 0;
  if (CASE_PATTERN.test(JSON.stringify(claimed))) {
    errors.push(
      `"${entry.gate}" names a controlled verification case outside its \`doesNotEstablish\` ` +
      'field. This register records obligations that have NONE; an entry that claims one ' +
      'belongs in verification-map.json, where it would be reconciled against a real run.');
  }
  CASE_PATTERN.lastIndex = 0;

  const script = (entry.gate ?? '').replace(/^npm run /, '');
  if (!Object.hasOwn(packageScripts, script)) {
    errors.push(`"${entry.gate}" is not a gate package.json defines.`);
  }

  for (const identifier of entry.carriesEvidenceFor ?? []) {
    if (!controlledIdentifiers.has(identifier)) {
      errors.push(
        `"${entry.gate}" carries evidence for ${identifier}, which is not a controlled ` +
        'requirement, interface or document.');
    }
  }

  if ((entry.carriesEvidenceFor ?? []).length === 0) {
    errors.push(`"${entry.gate}" names no obligation at all.`);
  }
  if (!entry.refuses || entry.refuses.length < 40) {
    errors.push(`"${entry.gate}" does not say what it refuses.`);
  }
  if (!doesNotEstablish || doesNotEstablish.length < 40) {
    errors.push(
      `"${entry.gate}" does not state what it fails to establish. A record of evidence that ` +
      'states only its own strength is an advertisement.');
  }
}

// The other direction: a case that IS bound must not also appear here as an obligation
// with no case, which would be the two registers disagreeing about the same evidence.
const map = await load('traceability/verification-map.json');
const boundHarnesses = new Set(
  map.cases.flatMap((entry) => entry.bindings ?? []).map((binding) => String(binding)));
for (const entry of entries) {
  const script = (entry.gate ?? '').replace(/^npm run /, '');
  if ([...boundHarnesses].some((harness) => harness === script)) {
    errors.push(
      `"${entry.gate}" is recorded here as carrying no controlled case, and ` +
      'traceability/verification-map.json binds a case to it. One of the two is wrong.');
  }
}

if (errors.length > 0) {
  console.error('Executable obligations register check failed:');
  for (const error of errors) console.error(`  FAIL ${error}`);
  process.exit(1);
}

console.log(
  `Executable obligations reconciled: ${entries.length} gates carrying evidence for controlled ` +
  'requirements that have no verification case, each recorded with what it refuses AND what it ' +
  'does not establish. None of them is a case and none may become one here.');
for (const entry of entries) {
  // A conflict number is printed only when there is one. Most of these gates exist
  // because a recorded conflict blocks a controlled document from moving; one exists
  // because every verification case for its requirements is hardware-gated, which is a
  // classification rather than a disagreement, and `(conflict undefined)` would read as
  // a number somebody forgot rather than one that does not apply.
  const because = entry.conflict === undefined ? '' : ` (conflict ${entry.conflict})`;
  console.log(`  ${entry.gate} -> ${(entry.carriesEvidenceFor ?? []).join(', ')}${because}`);
}
