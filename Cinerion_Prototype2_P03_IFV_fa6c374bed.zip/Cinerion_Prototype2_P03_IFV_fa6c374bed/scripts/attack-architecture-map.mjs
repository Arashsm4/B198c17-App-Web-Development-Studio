// Attacks scripts/check-architecture-map.mjs by reverting, one at a time, each control it
// exists for. Every mutation is applied to the real files and undone afterwards, so the
// gate under attack is exactly the gate CI runs.
//
// The two that matter most are the last pair: a project reference added across the
// isolation boundary, in each direction. "Isolated credentials, no production route" is
// the Simulators component's own subtitle and the research band has no connector in the
// controlled diagram; a reference either way would be that route, and no other gate in
// this repository would see it.
//
// Every source mutation asserts that it CHANGED the file before the gate's answer is
// judged, for the reason recorded as defect 75.

import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);

const mapPath = 'traceability/system-architecture-r01.json';
const portalClientPath = 'apps/operator-portal/src/api/client.ts';
const policyPath = 'scripts/check-repository-policy.mjs';
const controlCoreProject = 'services/control-core/src/Cinerion.Application/Cinerion.Application.csproj';
const simulatorProject = 'simulators/plc-guard/src/Cinerion.PlcGuard/Cinerion.PlcGuard.csproj';
const diagramPath = 'docs/baseline/P03_IFV/assets/system-architecture.svg';

const paths = [mapPath, portalClientPath, policyPath, controlCoreProject, simulatorProject];
const originals = new Map(
  await Promise.all(paths.map(async (path) => [path, await readFile(path, 'utf8')])));

let holes = 0;

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-architecture-map.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

const component = (map, name) => map.components.find((item) => item.name === name);

const mapAttacks = [
  ['an edge invented from the experience layer straight to the local controllers', (map) => {
    map.layerEdges.push({
      from: 'Experience and operations',
      to: 'Local guarded execution',
      guarded: false,
      boundTo: [{ source: portalClientPath, symbol: 'fetch' }],
    });
  }, 'the controlled diagram does not draw it'],

  ['the guarded dispatch edge declared unguarded', (map) => {
    const edge = map.layerEdges.find((item) => item.to === 'Protocol and integration');
    edge.guarded = false;
    delete edge.notImplemented;
    edge.boundTo = [{ source: policyPath, symbol: 'gpio_set_level' }];
  }, 'the controlled diagram draws it in amber'],

  ['the actuator edge declared unguarded', (map) => {
    map.layerEdges.find((item) => item.to === 'Physical process and evidence sources').guarded = false;
  }, 'the controlled diagram draws it in amber'],

  ['a controlled layer edge deleted', (map) => {
    map.layerEdges = map.layerEdges.filter((item) => item.from !== 'Experience and operations');
  }, 'is declared nowhere'],

  ['CommandGuard moved into the protocol layer', (map) => {
    component(map, 'CommandGuard').layer = 'Protocol and integration';
  }, 'the controlled diagram draws it in "Domain and authority"'],

  ['a controlled component deleted from the map', (map) => {
    map.components = map.components.filter((item) => item.name !== 'ConfirmGate station');
  }, 'the controlled component "ConfirmGate station" is declared nowhere'],

  ['a component invented that the controlled diagram does not draw', (map) => {
    map.components.push({
      name: 'RemoteStart',
      layer: 'Domain and authority',
      paths: ['services/control-core/src/Cinerion.Api'],
    });
  }, 'the controlled diagram does not draw it'],

  ['the Local HMI quietly claimed as built', (map) => {
    const hmi = component(map, 'Local HMI');
    delete hmi.notImplemented;
    hmi.paths = ['firmware/esp32/main/local_hmi.cpp'];
  }, 'which does not exist'],

  ['the Local HMI declared absent with no stated reason', (map) => {
    component(map, 'Local HMI').notImplemented = { reason: 'later', recordedIn: 'docs/implementation/PROTOTYPE2_PROGRESS.md' };
  }, 'is declared not implemented without a stated reason'],

  ['the layers reordered, so the domain sits below the protocol layer', (map) => {
    const domain = map.layers.find((item) => item.name === 'Domain and authority');
    const protocol = map.layers.find((item) => item.name === 'Protocol and integration');
    [domain.order, protocol.order] = [protocol.order, domain.order];
  }, 'The order is the architecture'],

  ['the isolation boundary removed from the map', (map) => {
    delete map.isolation;
  }, 'declares no isolation boundary'],

  ['the isolation boundary pointed at a directory that does not exist', (map) => {
    map.isolation.rootPath = 'sandboxes';
  }, 'which does not exist'],

  ['the ResearchBench isolation edge declared an ordinary call', (map) => {
    map.componentEdges[0].kind = 'call';
  }, 'the controlled diagram draws it "isolated"'],
];

const sourceAttacks = [
  [portalClientPath, 'the portal stops naming the domain endpoint it is bound to', (text) =>
    text.replace(/EXPO_PUBLIC_CINERION_API_URL/g, 'CINERION_DIRECT_CONTROLLER_URL'),
  'is bound to "EXPO_PUBLIC_CINERION_API_URL"'],

  [policyPath, 'the firmware GPIO refusal removed — what makes the actuator edge guarded today', (text) =>
    text.replace(/gpio_set_level/g, 'gpio_write_level'),
  'is bound to "gpio_set_level"'],

  [controlCoreProject, 'a production project given a route into the simulators', (text) =>
    text.replace(
      '</Project>',
      '  <ItemGroup>\n    <ProjectReference Include="..\\..\\..\\..\\simulators\\plc-guard\\src\\Cinerion.PlcGuard\\Cinerion.PlcGuard.csproj" />\n  </ItemGroup>\n</Project>'),
  'crosses the controlled isolation boundary'],

  [simulatorProject, 'a simulator given a route out into the domain', (text) =>
    text.replace(
      '</Project>',
      '  <ItemGroup>\n    <ProjectReference Include="..\\..\\..\\..\\services\\control-core\\src\\Cinerion.Domain\\Cinerion.Domain.csproj" />\n  </ItemGroup>\n</Project>'),
  'crosses the controlled isolation boundary'],
];

const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
  console.log(output.split('\n').filter((line) => line.includes('FAILED') || line.includes('  - ')).slice(0, 3).join('\n'));
};

const restore = async () => {
  await Promise.all([...originals].map(([path, text]) => writeFile(path, text)));
};

console.log('Attacking the controlled architecture gate.\n');

try {
  for (const [name, mutate, expected] of mapAttacks) {
    const map = JSON.parse(originals.get(mapPath));
    mutate(map);
    await writeFile(mapPath, `${JSON.stringify(map, null, 2)}\n`);
    const { refused, output } = await gate();
    await writeFile(mapPath, originals.get(mapPath));
    judge(name, expected, refused, output);
  }

  for (const [path, name, mutate, expected] of sourceAttacks) {
    const mutated = mutate(originals.get(path));
    if (mutated === originals.get(path)) {
      holes += 1;
      console.log(`  *** HOLE ***     ${name} (the mutation changed nothing, so nothing was attacked)`);
      continue;
    }
    await writeFile(path, mutated);
    const { refused, output } = await gate();
    await writeFile(path, originals.get(path));
    judge(name, expected, refused, output);
  }
} finally {
  await restore();
}

// The controlled diagram is not mutated: it is SHA-256 verified inside the frozen
// baseline, and npm run baseline is the control over it. What is checked is that the gate
// parsed the diagram this suite was written against.
const parsed = await readFile(diagramPath, 'utf8');
const bands = [...parsed.matchAll(/<rect\b[^>]*\bwidth="1460"/g)].length;
const edges = [...parsed.matchAll(/<path\b[^>]*class="(?:line|guard|isolate)"/g)].length;
if (bands !== 6 || edges !== 5) {
  holes += 1;
  console.log(
    `  *** HOLE ***     the controlled diagram carries ${bands} bands and ${edges} edges, not 6 and 5; ` +
    'the gate parsed a different diagram from the one this suite attacks.');
} else {
  console.log('  NOT ATTACKED     the frozen diagram itself — it is SHA-256 verified, and ' +
    'npm run baseline is the control over it.');
}

const restored = await gate();
console.log(`\n${mapAttacks.length + sourceAttacks.length} attacks, ${holes} holes.`);
console.log(`Restored files pass the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
