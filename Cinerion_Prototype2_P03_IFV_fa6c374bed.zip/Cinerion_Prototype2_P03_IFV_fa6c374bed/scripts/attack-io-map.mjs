// Attacks scripts/check-io-map.mjs by reverting, one at a time, each control it exists for.
// Every mutation is applied to the real files and undone afterwards, so the gate under
// attack is exactly the gate CI runs. A mutation the gate does not refuse is reported here
// as a hole in the gate, which is the only useful outcome of an attack suite.

import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);
const mapPath = 'firmware/pinmap/esp32s3-r01.json';
const headerPath = 'firmware/shared/include/cinerion/conditioned_io.hpp';

const originalMap = await readFile(mapPath, 'utf8');
const originalHeader = await readFile(headerPath, 'utf8');

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-io-map.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

const attacks = [
  ['a signal deleted from the pin map', (map) => {
    map.signals = map.signals.filter((s) => s.signalId !== 'CH1-IO-DI-0004');
  }, 'contains CH1-IO-DI-0004 and'],

  ['a signal invented that the controlled table does not contain', (map) => {
    map.signals.push({ ...map.signals[0], signalId: 'CH1-IO-DI-0009', pins: [{ gpio: 14, role: 'input' }] });
  }, 'CH1-IO-DI-0009, which the controlled I/O table does not contain'],

  ['a fail state quietly changed', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DI-0005').normal = 'Off';
  }, 'CH1-IO-DI-0005.normal'],

  ['a diagnostic action quietly changed', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DI-0004').diagnostic = 'Required permissive';
  }, 'CH1-IO-DI-0004.diagnostic'],

  ['conditioning that does not implement the controlled diagnostic action', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-AI-0003').conditioning = 'range-rate';
  }, 'calls for "median"'],

  ['an actuator output made energisable while the wiring is unfrozen', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DO-0006').energisable = true;
  }, 'energisable while the wiring is not frozen'],

  ['the stepper made energisable', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-PWM-0001').energisable = true;
  }, 'energisable while the wiring is not frozen'],

  ['the wiring declared frozen with terminals still TBD', (map) => {
    map.wiringFrozen = true;
  }, 'declares the wiring frozen while'],

  ['a signal moved onto a flash pin', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DO-0002').pins = [{ gpio: 28, role: 'output' }];
  }, 'reserves for SPI flash / PSRAM'],

  ['a signal moved onto a strapping pin', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DO-0002').pins = [{ gpio: 46, role: 'output' }];
  }, 'reserves for strapping, sampled at reset'],

  ['the reserved list widened by deleting an entry from the map', (map) => {
    delete map.reservedPins['46'];
  }, 'does not record GPIO 46 as reserved'],

  ['two outputs electrically paralleled onto one pin', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DO-0003').pins = [{ gpio: 17, role: 'output' }];
  }, 'Only a shared bus role may be claimed twice'],

  ['an output left with no external pull to a de-energised level', (map) => {
    delete map.signals.find((s) => s.signalId === 'CH1-IO-DO-0006').externalPull;
  }, 'declares no external pull'],

  ['an external pull that would energise the output it is meant to hold off', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DO-0006').externalPull = 'up';
  }, 'pulled up at reset but calls its de-energised level'],

  ['an actuator no longer declared as one', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-DO-0006').actuator = false;
  }, 'not marked as an actuator'],

  ['a signal this controller owns given no pins and no reason', (map) => {
    const signal = map.signals.find((s) => s.signalId === 'CH1-IO-DI-0001');
    signal.pins = [];
  }, 'no recognised reason for having none'],

  ['another controller\'s signal claimed by this one', (map) => {
    map.signals.find((s) => s.signalId === 'CH1-IO-USB-0001').owner = 'ESP32-S3';
  }, 'CH1-IO-USB-0001.owner'],
];

const headerAttacks = [
  ['a signal the firmware stops naming', (text) =>
    text.replace('constexpr std::string_view buzzer = "CH1-IO-DO-0005";', 'constexpr std::string_view buzzer = "";'),
  'does not name CH1-IO-DO-0005'],

  ['the firmware conditioning another controller\'s signal', (text) =>
    text.replace('constexpr std::string_view local_display = "CH1-IO-HMI-0001";',
      'constexpr std::string_view local_display = "CH1-IO-HMI-0001";\nconstexpr std::string_view reader = "CH1-IO-USB-0001";'),
  'taken authority it was not given'],
];

let holes = 0;

const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
  console.log(output.split('\n').filter((line) => line.includes('FAIL')).slice(0, 3).join('\n'));
};

// Every mutation is undone in a `finally`, including on a throw. A suite that mutates
// tracked files and then dies leaves the repository holding a deliberately broken pin map,
// which is a worse outcome than the attack never having run.
try {
  for (const [name, mutate, expected] of attacks) {
    const map = JSON.parse(originalMap);
    mutate(map);
    await writeFile(mapPath, JSON.stringify(map, null, 2));
    const { refused, output } = await gate();
    await writeFile(mapPath, originalMap);
    judge(name, expected, refused, output);
  }

  for (const [name, mutate, expected] of headerAttacks) {
    await writeFile(headerPath, mutate(originalHeader));
    const { refused, output } = await gate();
    await writeFile(headerPath, originalHeader);
    judge(name, expected, refused, output);
  }
} finally {
  await writeFile(mapPath, originalMap);
  await writeFile(headerPath, originalHeader);
}

// The gate must pass again on the restored files, or the attack suite has left damage
// behind and every result above is worthless.
const restored = await gate();
console.log(`\n${attacks.length + headerAttacks.length} attacks, ${holes} holes.`);
console.log(`Restored files pass the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
