// Runs the production dependency audit and reconciles it against the recorded
// disposition, rather than passing or failing on the raw advisory count.
//
// The previous CI step piped `npm audit --omit=dev --audit-level=high --json` into an
// artefact. npm exits 1 when it finds anything at that level, GitHub Actions runs each
// bash step with -e, and this dependency graph has had unfixable transitive advisories
// for as long as it has depended on Metro - so that step failed the workflow every time
// and no evidence was ever produced. Raising --audit-level, or appending `|| true`,
// would have turned a security gate into a formality.
//
// CH1-VVT-FAT-0001 case CH1-VVT-TC-0126 asks a release to carry a SBOM *and a dependency
// disposition*. That is the shape used here: every advisory the audit reports must be
// dispositioned in traceability/dependency-disposition.json, every disposition must
// still correspond to a reported advisory, an accepted risk carries a review date and
// expires, and a runtime-reachable high or critical cannot be accepted at all.

import { exec } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const run = promisify(exec);
const errors = [];
const today = new Date().toISOString().slice(0, 10);

// npm audit exits non-zero whenever it reports anything, so the exit code carries no
// information this check does not derive itself. A missing or unparseable report is a
// different matter and is treated as a failure below.
let report;
try {
  // A fixed command line, so that the same call works against the npm.cmd shim on
  // Windows and the npm shell script elsewhere. Nothing here is interpolated: no part
  // of this command comes from the environment, a file, or a command line argument.
  const { stdout } = await run(
    'npm audit --omit=dev --json', { cwd: root, maxBuffer: 64 * 1024 * 1024 });
  report = stdout;
} catch (error) {
  report = error.stdout ?? '';
  if (!report.trim()) {
    console.error(`npm audit produced no report: ${error.stderr || error.message}`);
    console.error('The audit needs registry access. CI treats this step as mandatory; a skipped audit is not a passed audit.');
    process.exitCode = 1;
    // eslint-disable-next-line no-process-exit
    process.exit();
  }
}

let audit;
try {
  audit = JSON.parse(report);
} catch (error) {
  console.error(`npm audit did not return parseable JSON: ${error.message}`);
  process.exitCode = 1;
  // eslint-disable-next-line no-process-exit
  process.exit();
}

// Kept as release evidence whatever the outcome, which the previous step never managed.
await mkdir(resolve(root, 'artifacts'), { recursive: true });
await writeFile(resolve(root, 'artifacts/npm-audit.json'), report, 'utf8');

// An advisory appears once as an object inside the `via` list of the package that
// actually carries it, and by name in the `via` list of every package that merely
// depends on it. Only the objects are distinct advisories.
const advisories = new Map();
for (const [name, entry] of Object.entries(audit.vulnerabilities ?? {})) {
  for (const via of entry.via ?? []) {
    if (typeof via !== 'object') continue;
    const key = /GHSA-[0-9a-z-]+/.exec(via.url ?? '')?.[0] ?? `npm-${via.source}`;
    advisories.set(key, { key, package: via.name ?? name, severity: via.severity, title: via.title, range: via.range });
  }
}

const disposition = JSON.parse(await readFile(resolve(root, 'traceability/dependency-disposition.json'), 'utf8'));
const recorded = new Map((disposition.dispositions ?? []).map((item) => [item.advisory, item]));
const allowedDecisions = new Set(['accepted', 'fix_pending']);
const allowedReachability = new Set(['build_toolchain', 'runtime']);
const requiredFields = ['advisory', 'package', 'severity', 'reachability', 'decision', 'rationale', 'recordedOn', 'reviewBy'];

for (const [key, advisory] of advisories) {
  const item = recorded.get(key);
  if (!item) {
    errors.push(
      `Undispositioned advisory ${key} (${advisory.severity}) in ${advisory.package} ${advisory.range}: ${advisory.title}. ` +
      'Fix it, or record the disposition in traceability/dependency-disposition.json.');
    continue;
  }
  if (item.severity !== advisory.severity) {
    errors.push(`Disposition for ${key} records severity ${item.severity} but the audit now reports ${advisory.severity}.`);
  }
  if (item.package !== advisory.package) {
    errors.push(`Disposition for ${key} names package ${item.package} but the audit reports ${advisory.package}.`);
  }
}

for (const [key, item] of recorded) {
  if (!advisories.has(key)) {
    errors.push(
      `Stale disposition ${key} (${item.package}): the audit no longer reports it. Remove the entry so the record stays honest.`);
  }
  for (const field of requiredFields) {
    if (!item[field]) errors.push(`Disposition ${key} is missing required field "${field}".`);
  }
  if (item.decision && !allowedDecisions.has(item.decision)) {
    errors.push(`Disposition ${key} has decision "${item.decision}"; expected one of ${[...allowedDecisions].join(', ')}.`);
  }
  if (item.reachability && !allowedReachability.has(item.reachability)) {
    errors.push(`Disposition ${key} has reachability "${item.reachability}"; expected one of ${[...allowedReachability].join(', ')}.`);
  }
  if (!Array.isArray(item.evidence) || item.evidence.length === 0) {
    errors.push(`Disposition ${key} records no evidence for its reachability claim.`);
  }
  if (item.reviewBy && item.reviewBy < today) {
    errors.push(
      `Disposition ${key} was accepted until ${item.reviewBy} and that date has passed. ` +
      'Re-assess and re-date it, or fix the dependency. An accepted risk expires.');
  }
  // A high or critical advisory that reaches the deployed artefact is not something a
  // record can make acceptable; the dependency has to change.
  if (item.reachability === 'runtime' && ['high', 'critical'].includes(item.severity) && item.decision === 'accepted') {
    errors.push(`Disposition ${key} accepts a runtime-reachable ${item.severity} advisory. That must be fixed, not accepted.`);
  }
}

const counts = audit.metadata?.vulnerabilities ?? {};
if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(
    `Dependency audit reconciled: ${advisories.size} distinct advisories across ` +
    `${Object.keys(audit.vulnerabilities ?? {}).length} affected packages ` +
    `(critical ${counts.critical ?? 0}, high ${counts.high ?? 0}, moderate ${counts.moderate ?? 0}, low ${counts.low ?? 0}); ` +
    `every one dispositioned, none expired, none runtime-reachable at high or above.`);
  console.log('Report written to artifacts/npm-audit.json.');
}
