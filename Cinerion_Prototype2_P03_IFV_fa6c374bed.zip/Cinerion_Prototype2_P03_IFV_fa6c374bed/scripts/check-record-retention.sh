#!/usr/bin/env sh
# CH1-DBA-DD-0001 — retention for the two controlled registers with an ABSOLUTE period.
#
#   "Retention is based on evidence, legal and project needs; deletion is authorised,
#    logged and compatible with immutable-release obligations."
#
# entities.json gives ten entities a finite retention. Only three are computable from data
# CH1 holds: TelemetrySample is configurable and is implemented and gated by
# scripts/check-telemetry-retention.sh, and MessageAcknowledgement and RoleAssignment are
# both a flat "7 years". This is their disposal path, and this is what refuses it.
#
# Conflict 25 records why the other seven have none: their retention is relative to a
# lifecycle end the schema does not record and no controlled operation sets, so a disposal
# process would have no date to compute from. Nothing here changes that.
#
# The property under test is a DATABASE property, so this gate is SQL end to end. There is
# no API in it, deliberately: an application that happens not to issue a DELETE proves
# nothing, and CH1-DBA-DD-0001 asks for the difference between "no code does that" and "the
# database will not permit it" — the same distinction conflict 19 records.
#
# What it does:
#
#   1. raises a database and applies every controlled migration in order;
#   2. establishes the two registers with rows on both sides of their retention boundary —
#      an acknowledgement and a role assignment that expired a year ago, and one of each
#      that has six more years to run;
#   3. ATTACKS the immutability before proving the disposal: the application role may not
#      update or delete either register, the retention role may not update them either, and
#      the retention role may NOT delete a row whose period has not ended;
#   4. attacks the procedure: no authoriser, no reason, an unknown register, another
#      project, and the application role calling it at all;
#   5. runs the disposal as the retention role and reads the result back FROM THE DATABASE
#      rather than believing the row the procedure returned;
#   6. proves the evidence of the disposal is itself permanent, and that the retention role
#      holds no authority over anything else.
#
# It announces NO controlled verification case, for the same reason
# check-telemetry-retention.sh announces none: data/tests.json contains no case for
# retention or disposal. Recorded as conflict 18 rather than bound to a case about
# something else.
#
# Usage: scripts/check-record-retention.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

image=postgres:18.4-alpine3.24
container=cinerion-record-retention-verify
db_port=55443

owner_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
app_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
retention_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)

project_id=00000000-0000-4000-8000-000000000101
other_project_id=00000000-0000-4000-8000-000000000201
site_id=00000000-0000-4000-8000-000000000102
cell_id=00000000-0000-4000-8000-000000000103

failures=0
log() { printf '\n%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

cleanup() { docker rm -f "$container" >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM

if ! docker version >/dev/null 2>&1; then
  echo "check-record-retention.sh: the Docker daemon is unreachable. This gate disposes of" >&2
  echo "real records in a real database; there is no meaningful way to run it without one." >&2
  exit 1
fi

# As the owner: fixtures and observations only. Every act under test runs as one of the two
# non-superuser roles, because a superuser bypasses row-level security and would make an
# isolation check pass while doing nothing (defect 13).
sql() { docker exec "$container" psql -U cinerion_owner -d cinerion -tAc "$1" | tr -d ' \r'; }

# As the application role, over TCP so its grants and RLS actually apply.
app_sql() {
  docker exec -e PGPASSWORD="$app_password" "$container" \
    psql -h 127.0.0.1 -U cinerion_app -d cinerion -tAc "$1" 2>&1 | tr -d '\r'
}

# As the retention role, likewise.
retention_sql() {
  docker exec -e PGPASSWORD="$retention_password" "$container" \
    psql -h 127.0.0.1 -U cinerion_retention -d cinerion -tAc "$1" 2>&1 | tr -d '\r'
}

# A statement that MUST be refused, and refused for the stated reason. A check that only
# asserts "an error happened" passes when the error is a typo in the check.
refused() {
  what=$1; expected=$2; statement=$3; runner=$4
  output=$($runner "$statement" || true)
  if printf '%s' "$output" | grep -qi "$expected"; then
    pass "$what"
  else
    fail "$what — expected a refusal naming '$expected', got: $(printf '%s' "$output" | tr '\n' ' ' | cut -c1-160)"
  fi
}

# --------------------------------------------------------------------------------------

log "[1/6] Raising a database and applying every controlled migration"
docker rm -f "$container" >/dev/null 2>&1 || true
docker run -d --name "$container" \
  -e POSTGRES_DB=cinerion -e POSTGRES_USER=cinerion_owner -e POSTGRES_PASSWORD="$owner_password" \
  -p "127.0.0.1:$db_port:5432" "$image" >/dev/null

attempt=0
settled=0
while [ "$settled" -lt 3 ]; do
  if docker exec "$container" psql -U cinerion_owner -d cinerion -tAc "select 1" >/dev/null 2>&1; then
    settled=$((settled + 1))
  else
    settled=0
  fi
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "PostgreSQL never became ready"; exit 1; }
  sleep 1
done

applied=0
for file in services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/*.sql; do
  docker exec -i "$container" psql -U cinerion_owner -d cinerion -q -v ON_ERROR_STOP=1 < "$file" >/dev/null 2>&1 \
    || { fail "migration $(basename "$file") did not apply"; exit 1; }
  applied=$((applied + 1))
done
docker exec "$container" psql -U cinerion_owner -d cinerion -q \
  -c "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password';" \
  -c "ALTER ROLE cinerion_retention LOGIN PASSWORD '$retention_password';" >/dev/null
pass "$applied controlled migrations applied; both non-superuser roles given a login"

# The procedure and the retention-aware trigger both have to exist, or every refusal below
# would be a refusal for the wrong reason.
[ "$(sql "SELECT count(*) FROM pg_proc WHERE proname = 'dispose_expired_records';")" = "1" ] \
  && pass "ch1.dispose_expired_records exists" \
  || fail "ch1.dispose_expired_records is missing; nothing below would test what it claims"
[ "$(sql "SELECT count(*) FROM pg_trigger WHERE tgname IN ('role_assignments_retained','message_acknowledgements_retained');")" = "2" ] \
  && pass "both registers carry the retention-aware refusal" \
  || fail "a register is missing its retention trigger"

log "[2/6] Two registers, with rows on both sides of the retention boundary"
# A fixture that fails silently is worse than no fixture. On the first run of this gate the
# role-assignment insert violated a NOT NULL and was swallowed, and [3/6] then reported "the
# retention role cannot dispose of a role assignment whose seven years have not ended" as a
# PASS - against an empty register, where the DELETE matched nothing. Both registers are
# counted below before anything depends on them, and the counts are asserted separately.
# Only what the two registers actually need: two projects, and one thread and message for
# the receipts to belong to. ch1.role_assignments references nothing but the project.
sql "
INSERT INTO ch1.projects (project_id, project_code, name, baseline)
VALUES ('$project_id', 'CH1-RETENTION', 'Retention verification', 'P03/IFV'),
       ('$other_project_id', 'CH1-OTHER', 'Another project', 'P03/IFV')
ON CONFLICT DO NOTHING;
INSERT INTO ch1.context_threads (thread_id, project_id, object_type, object_id, access_scope, created_by, created_at)
VALUES ('00000000-0000-4000-8000-0000000009a1', '$project_id', 'Cell', '$cell_id',
        '[]'::jsonb, 'USR-RETENTION', now())
ON CONFLICT DO NOTHING;
INSERT INTO ch1.context_messages
  (message_id, project_id, thread_id, author_id, author_kind, priority, body, created_at, delivery_state)
VALUES ('00000000-0000-4000-8000-0000000009b1', '$project_id', '00000000-0000-4000-8000-0000000009a1',
        'USR-RETENTION', 'Human', 'Normal', 'retention fixture', now(), 'Delivered')
ON CONFLICT DO NOTHING;
" >/dev/null

# One receipt whose seven years ended a year ago and one with six still to run. retain_until
# is not chosen freely: the CHECK ties it to acknowledged_at, so the fixture moves the
# ACKNOWLEDGEMENT and the retention follows. That is the point of carrying the declared
# period on the row rather than in a policy document.
sql "
INSERT INTO ch1.message_acknowledgements
  (message_ack_id, project_id, message_id, recipient_id, recipient_kind, acknowledged_at, retain_until)
VALUES
  ('00000000-0000-4000-8000-0000000009c1', '$project_id', '00000000-0000-4000-8000-0000000009b1',
   'USR-EXPIRED', 'Human', now() - interval '8 years', now() - interval '8 years' + interval '7 years'),
  ('00000000-0000-4000-8000-0000000009c2', '$project_id', '00000000-0000-4000-8000-0000000009b1',
   'USR-CURRENT', 'Human', now() - interval '1 year', now() - interval '1 year' + interval '7 years')
ON CONFLICT DO NOTHING;
" >/dev/null

sql "
INSERT INTO ch1.role_assignments
  (assignment_id, project_id, subject_user_id, subject_username, previous_roles, current_roles,
   granted_roles, withdrawn_roles, assigned_by, assigned_at, provider, correlation_id, retain_until)
VALUES
  ('00000000-0000-4000-8000-0000000009d1', '$project_id', 'USR-EXPIRED', 'expired.subject',
   '[]'::jsonb, '[\"Viewer\"]'::jsonb, '[\"Viewer\"]'::jsonb, '[]'::jsonb,
   'USR-ADMIN', now() - interval '8 years', 'keycloak',
   '00000000-0000-4000-8000-0000000009e1', now() - interval '8 years' + interval '7 years'),
  ('00000000-0000-4000-8000-0000000009d2', '$project_id', 'USR-CURRENT', 'current.subject',
   '[]'::jsonb, '[\"Viewer\"]'::jsonb, '[\"Viewer\"]'::jsonb, '[]'::jsonb,
   'USR-ADMIN', now() - interval '1 year', 'keycloak',
   '00000000-0000-4000-8000-0000000009e2', now() - interval '1 year' + interval '7 years')
ON CONFLICT DO NOTHING;
" >/dev/null

acks=$(sql "SELECT count(*) FROM ch1.message_acknowledgements WHERE project_id = '$project_id';")
assignments=$(sql "SELECT count(*) FROM ch1.role_assignments WHERE project_id = '$project_id';")
[ "$acks" = "2" ] && [ "$assignments" = "2" ] \
  && pass "each register holds one expired row and one still within its seven years" \
  || fail "the fixture did not establish both registers: $acks acknowledgement(s), $assignments assignment(s)"

expired_acks=$(sql "SELECT count(*) FROM ch1.message_acknowledgements WHERE project_id = '$project_id' AND retain_until < now();")
[ "$expired_acks" = "1" ] \
  && pass "exactly one acknowledgement is past its declared retention" \
  || fail "$expired_acks acknowledgement(s) are past retention; the disposal below would prove nothing"

log "[3/6] The registers are immutable within their retention"

# The application role. 0002's ALTER DEFAULT PRIVILEGES grants it all four privileges on
# every table created in ch1 afterwards, so these REVOKEs are the control and a GRANT would
# have been a comment. Defect 53 was exactly that.
refused "the application role cannot rewrite a delivery receipt" "denied" \
  "UPDATE ch1.message_acknowledgements SET recipient_id = 'USR-EDITED' WHERE recipient_id = 'USR-CURRENT';" app_sql
refused "the application role cannot delete a delivery receipt" "denied" \
  "DELETE FROM ch1.message_acknowledgements WHERE recipient_id = 'USR-EXPIRED';" app_sql
refused "the application role cannot rewrite a role assignment" "denied" \
  "UPDATE ch1.role_assignments SET subject_user_id = 'USR-EDITED' WHERE subject_user_id = 'USR-CURRENT';" app_sql
refused "the application role cannot delete a role assignment" "denied" \
  "DELETE FROM ch1.role_assignments WHERE subject_user_id = 'USR-EXPIRED';" app_sql

# The retention role. It may delete, and it may not rewrite: a record that could be edited
# before being disposed of could be given any retention its holder liked.
refused "the retention role holds no UPDATE on a receipt at all" "denied" \
  "SET ch1.project_id = '$project_id'; UPDATE ch1.message_acknowledgements SET recipient_id = 'USR-EDITED' WHERE recipient_id = 'USR-CURRENT';" retention_sql
refused "the retention role holds no UPDATE on a role assignment at all" "denied" \
  "SET ch1.project_id = '$project_id'; UPDATE ch1.role_assignments SET subject_user_id = 'USR-EDITED' WHERE subject_user_id = 'USR-CURRENT';" retention_sql

# THE CENTRAL CONTROL. A retention period that could be ended early by the one role
# permitted to act on it is not a retention period.
refused "the retention role cannot dispose of a receipt whose seven years have not ended" "is retained until" \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.message_acknowledgements WHERE recipient_id = 'USR-CURRENT';" retention_sql
refused "the retention role cannot dispose of a role assignment whose seven years have not ended" "is retained until" \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.role_assignments WHERE subject_user_id = 'USR-CURRENT';" retention_sql

# THE TRIGGER'S OWN BRANCHES, reached directly.
#
# Both refusals above came from the PRIVILEGE layer, not from the trigger: the retention
# role holds no UPDATE, so PostgreSQL refuses before a row is ever examined. That is the
# stronger outcome and it is the right one — but it means the trigger's UPDATE branch and
# its role branch are claims nothing has exercised, and an unexercised control is a comment.
# So the privilege is granted for exactly as long as it takes to prove the trigger refuses
# anyway, and then taken back. The state is asserted afterwards, because a gate that widens
# a grant and fails to narrow it again has left the deployment worse than it found it.
sql "GRANT UPDATE ON ch1.role_assignments TO cinerion_retention;" >/dev/null
refused "with UPDATE granted, the trigger still refuses to let a role assignment be rewritten" "cannot be updated"   "SET ch1.project_id = '$project_id'; UPDATE ch1.role_assignments SET subject_user_id = 'USR-EDITED' WHERE subject_user_id = 'USR-CURRENT';" retention_sql
sql "REVOKE UPDATE ON ch1.role_assignments FROM cinerion_retention;" >/dev/null

sql "GRANT DELETE ON ch1.role_assignments TO cinerion_app;" >/dev/null
refused "with DELETE granted, the trigger still refuses a role other than the retention role" "only by the retention role"   "SET ch1.project_id = '$project_id'; DELETE FROM ch1.role_assignments WHERE subject_user_id = 'USR-EXPIRED';" app_sql
sql "REVOKE DELETE ON ch1.role_assignments FROM cinerion_app;" >/dev/null

# Narrowed again. If either REVOKE had failed, everything after this point would be running
# against a database with authority the deployment does not grant.
widened=$(sql "SELECT count(*) FROM information_schema.role_table_grants WHERE table_schema = 'ch1' AND table_name = 'role_assignments' AND ((grantee = 'cinerion_retention' AND privilege_type = 'UPDATE') OR (grantee = 'cinerion_app' AND privilege_type = 'DELETE'));")
[ "$widened" = "0" ]   && pass "both grants taken for those two checks were given back"   || fail "$widened grant(s) opened by this gate are still in place"

log "[4/6] The procedure refuses every act it should"
refused "a disposal with no named authoriser" "named authoriser and a reason" \
  "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$project_id', 'message_acknowledgements', '   ', 'a reason');" retention_sql
refused "a disposal with no reason" "named authoriser and a reason" \
  "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$project_id', 'message_acknowledgements', 'USR-ADMIN', '  ');" retention_sql
refused "a disposal pointed at a register this procedure may not act on" "is not one this procedure may act on" \
  "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$project_id', 'audit_events', 'USR-ADMIN', 'a reason');" retention_sql
refused "a disposal aimed at another project than the session's" "scoped to the session project" \
  "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$other_project_id', 'message_acknowledgements', 'USR-ADMIN', 'a reason');" retention_sql
refused "the application role cannot run the disposal at all" "denied" \
  "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$project_id', 'message_acknowledgements', 'USR-ADMIN', 'a reason');" app_sql

log "[5/6] The disposal runs, and the result is read back from the database"
retention_sql "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$project_id', 'message_acknowledgements', 'USR-ADMIN', 'declared seven-year period elapsed');" >/dev/null
retention_sql "SET ch1.project_id = '$project_id'; SELECT ch1.dispose_expired_records('$project_id', 'role_assignments', 'USR-ADMIN', 'declared seven-year period elapsed');" >/dev/null

# Read back, never believed. Three of this project's defects came from code deciding an
# outcome from a return value or an exit code instead of reading the resulting state.
remaining_acks=$(sql "SELECT count(*) FROM ch1.message_acknowledgements WHERE project_id = '$project_id';")
remaining_assignments=$(sql "SELECT count(*) FROM ch1.role_assignments WHERE project_id = '$project_id';")
[ "$remaining_acks" = "1" ] && [ "$remaining_assignments" = "1" ] \
  && pass "the expired row in each register is gone and the row still within its period is not" \
  || fail "after disposal: $remaining_acks acknowledgement(s), $remaining_assignments assignment(s); expected 1 and 1"

survivor=$(sql "SELECT recipient_id FROM ch1.message_acknowledgements WHERE project_id = '$project_id';")
[ "$survivor" = "USR-CURRENT" ] \
  && pass "the surviving receipt is the one whose retention has not ended" \
  || fail "the wrong receipt survived: '$survivor'"

disposals=$(sql "SELECT count(*) FROM ch1.record_disposals WHERE project_id = '$project_id';")
deleted=$(sql "SELECT sum(rows_deleted) FROM ch1.record_disposals WHERE project_id = '$project_id';")
[ "$disposals" = "2" ] && [ "$deleted" = "2" ] \
  && pass "two disposals are recorded, accounting for two deleted rows between them" \
  || fail "$disposals disposal record(s) accounting for $deleted deletion(s); expected 2 and 2"

named=$(sql "SELECT count(*) FROM ch1.record_disposals WHERE project_id = '$project_id' AND authorised_by = 'USR-ADMIN' AND length(btrim(reason)) > 0 AND declared_retention = '7 years';")
[ "$named" = "2" ] \
  && pass "each disposal names its authoriser, its reason and the retention the register declares" \
  || fail "a disposal record is missing its attribution"

log "[6/6] The evidence of the disposal is itself permanent"
refused "the role that writes a disposal record holds no UPDATE on it" "denied" \
  "SET ch1.project_id = '$project_id'; UPDATE ch1.record_disposals SET reason = 'something else' WHERE project_id = '$project_id';" retention_sql
refused "nor any DELETE on it" "denied" \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.record_disposals WHERE project_id = '$project_id';" retention_sql

# The retention role's destructive authority is exactly three tables and no more. A role
# that could also remove an alarm, a measurement or an audit event would make the whole
# chain deniable.
refused "the retention role cannot delete an audit event" "denied\|cannot be updated or deleted" \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.audit_events WHERE project_id = '$project_id';" retention_sql
refused "the retention role cannot delete a measurement" "denied\|cannot be updated or deleted" \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.measurements WHERE project_id = '$project_id';" retention_sql
refused "the retention role cannot delete a release record" "denied\|cannot be updated or deleted" \
  "SET ch1.project_id = '$project_id'; DELETE FROM ch1.release_records WHERE project_id = '$project_id';" retention_sql

# And it does not bypass row-level security, which is what makes the project scoping above
# a control rather than a convention (defect 13).
bypass=$(sql "SELECT rolbypassrls FROM pg_roles WHERE rolname = 'cinerion_retention';")
[ "$bypass" = "f" ] \
  && pass "the retention role does not bypass row-level security" \
  || fail "the retention role bypasses row-level security, so every scoping check above is decoration"

echo
if [ "$failures" -eq 0 ]; then
  echo "CH1-DBA-DD-0001 record retention verified against a real database."
  echo "  registers         : MessageAcknowledgement and RoleAssignment, the two entities whose"
  echo "                      declared retention is absolute and therefore computable"
  echo "  within retention  : neither register can be rewritten by anyone, or deleted by the"
  echo "                      application role, or deleted by the retention role before the"
  echo "                      period the register declares has ended"
  echo "  disposal          : refused without a named authoriser, without a reason, against"
  echo "                      another project, against a register outside the closed set, and"
  echo "                      to the application role entirely"
  echo "  after disposal    : the expired row is gone, the row still within its period is not,"
  echo "                      and the count was read back from the database rather than believed"
  echo "  evidence          : the disposal record names its authoriser, reason and declared"
  echo "                      retention, and can itself be neither rewritten nor removed"
  echo "  authority         : the retention role can delete from three tables and no others,"
  echo "                      and does not bypass row-level security"
  echo
  echo "No controlled verification case is announced: data/tests.json contains none for"
  echo "retention or disposal. Recorded as conflict 18."
  exit 0
fi

echo "$failures check(s) failed."
exit 1
