#!/usr/bin/env sh
# Sets the passwords for the portal demo identities in a running Keycloak.
#
# WHY THIS IS A SCRIPT AND NOT A REALM FIELD. infrastructure/keycloak/cinerion-realm.json
# declares both identities and their role mappings, and deliberately carries no credentials:
# a password in a committed file is a committed secret, and npm run policy exists to refuse
# one. An imported user with no credential simply cannot sign in until this has run, which
# is the fail-closed direction.
#
# WHY THERE ARE TWO IDENTITIES. RoleSegregation forbids CybersecurityAdministrator beside
# SystemAdministrator (a system administrator manages general configuration, not root
# cybersecurity policy) and beside Inspector (a cybersecurity administrator manages trust
# and cannot release parts). One person holding all fourteen roles would have defeated the
# separation CH1-CYB-ACP-0001 spends its length establishing. Two identities is not a
# workaround for the rule; it IS the rule.
#
#   ch1-portal-demo      13 roles - everything one human may hold
#   ch1-portal-security   3 roles - the cybersecurity authority, on its own identity
#
# Between them every one of the 22 declared screens is reachable, and neither breaks a
# segregation rule to get there.
#
# The realm enforces a real password policy - length(14), digits, upper, lower, special,
# and a history of 12 - so a value that ignores it is refused by Keycloak rather than
# quietly accepted.
#
# Usage: scripts/provision-portal-identities.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

secrets="infrastructure/.env.local"
authority="${CINERION_KEYCLOAK_URL:-http://localhost:8180}"
realm=cinerion

fail() { printf 'FAIL  %s\n' "$*" >&2; exit 1; }
pass() { printf 'PASS  %s\n' "$*"; }

[ -f "$secrets" ] || fail "$secrets is absent. Run scripts/bootstrap-local.ps1 first."

# Read without sourcing: a stray line in the secret file should not be able to execute.
read_secret() {
  grep "^$1=" "$secrets" | head -1 | cut -d= -f2-
}

admin=$(read_secret CINERION_KEYCLOAK_ADMIN)
admin_password=$(read_secret CINERION_KEYCLOAK_ADMIN_PASSWORD)
demo_password=$(read_secret CINERION_PORTAL_DEMO_PASSWORD)

[ -n "$admin" ] && [ -n "$admin_password" ] || fail "the Keycloak admin credentials are not in $secrets"
[ -n "$demo_password" ] || fail "CINERION_PORTAL_DEMO_PASSWORD is not in $secrets"

token=$(curl --silent --show-error --fail \
  --data "client_id=admin-cli" \
  --data "username=$admin" \
  --data-urlencode "password=$admin_password" \
  --data "grant_type=password" \
  "$authority/realms/master/protocol/openid-connect/token" \
  | sed -n 's/.*"access_token":"\([^"]*\)".*/\1/p')
[ -n "$token" ] || fail "could not obtain an admin token from $authority. Is the identity lab up?"
pass "authenticated to Keycloak at $authority"

# The roles each identity holds. RoleSegregation forbids CybersecurityAdministrator beside
# SystemAdministrator and beside Inspector, so it lives on its own identity and the other
# holds the remaining fourteen. ProjectOwner joined them when conflict 23 was
# resolved; it changes nothing for this identity, which authors the publication package
# and is therefore refused as its own reviewer whichever capacity it holds. DeviceController is on neither: it may never be human.
demo_roles="Viewer Auditor Engineer AutomationEngineer Inspector LocalConfirmer MaintenanceEngineer OperationsCoordinator ProjectManager ConfigurationManager RDEngineer DocumentController ProjectOwner SystemAdministrator"
security_roles="Viewer Auditor CybersecurityAdministrator"

project_id=00000000-0000-4000-8000-000000000101
cell_id=00000000-0000-4000-8000-000000000103

api() {
  method=$1
  path=$2
  body=${3:-}
  if [ -n "$body" ]; then
    curl --silent --show-error --fail-with-body \
      -X "$method" \
      -H "Authorization: Bearer $token" \
      -H "Content-Type: application/json" \
      --data "$body" \
      "$authority/admin/realms/$realm$path"
  else
    curl --silent --show-error --fail-with-body \
      -X "$method" \
      -H "Authorization: Bearer $token" \
      "$authority/admin/realms/$realm$path"
  fi
}

find_user() {
  api GET "/users?username=$1&exact=true" \
    | sed -n 's/.*"id":"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1
}

# THE REALM FILE IS NOT ENOUGH, and that is worth stating rather than discovering. Keycloak
# imports a realm only on a FIRST run, and the identity-db volume outlives every restart -
# so a lab that has ever been started ignores every later edit to cinerion-realm.json. The
# file is what a fresh lab gets; this is what an existing one gets, and the two are kept
# saying the same thing.
provision() {
  username=$1
  first=$2
  wanted=$3

  id=$(find_user "$username")
  if [ -z "$id" ]; then
    api POST "/users" "{
      \"username\": \"$username\",
      \"enabled\": true,
      \"emailVerified\": true,
      \"firstName\": \"CH1\",
      \"lastName\": \"$first\",
      \"attributes\": {
        \"ch1_project_id\": [\"$project_id\"],
        \"ch1_cell_ids\": [\"$cell_id\"]
      }
    }" > /dev/null || fail "could not create $username"
    id=$(find_user "$username")
    [ -n "$id" ] || fail "created $username but could not read it back"
    created="created"
  else
    created="already present"
  fi

  # Role mappings, reconciled rather than assumed. Only the missing ones are added, so
  # running this twice is not an error and a role removed deliberately is not silently
  # restored by something other than this list.
  held=$(api GET "/users/$id/role-mappings/realm" | grep -o '"name":"[^"]*"' | cut -d: -f2 | tr -d '"')
  added=0
  for role in $wanted; do
    if ! printf '%s\n' "$held" | grep -qx "$role"; then
      representation=$(api GET "/roles/$role")
      role_id=$(printf '%s' "$representation" | sed -n 's/.*"id":"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1)
      [ -n "$role_id" ] || fail "realm role $role does not exist; is cinerion-realm.json imported?"
      api POST "/users/$id/role-mappings/realm" "[{\"id\":\"$role_id\",\"name\":\"$role\"}]" > /dev/null \
        || fail "could not grant $role to $username"
      added=$((added + 1))
    fi
  done

  # THE OUTCOME IS MEASURED, NOT INFERRED FROM AN EXIT CODE. The attempt is made and then
  # the credentials are read back, because there are three ways to end up correctly
  # provisioned and only one of them is "the PUT returned success":
  #
  #   the password was set now;
  #   the password was already this value, and passwordHistory(12) refused a repeat -
  #     which is the policy working, not a failure;
  #   the PUT succeeded and curl reported otherwise, which was observed here.
  #
  # In all three the identity can sign in, and the only state that matters is whether a
  # password credential exists afterwards. Asking that question directly removes every
  # guess. The realm forbids a direct grant for the public browser client, so signing in as
  # them is not available as a check and this is the strongest one that is.
  before=$(api GET "/users/$id/credentials" | grep -o '"type":"password"' | wc -l | tr -d ' ')

  curl --silent --output /dev/null --fail \
    -X PUT \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    --data "{\"type\":\"password\",\"value\":\"$demo_password\",\"temporary\":false}" \
    "$authority/admin/realms/$realm/users/$id/reset-password" 2>/dev/null || true

  after=$(api GET "/users/$id/credentials" | grep -o '"type":"password"' | wc -l | tr -d ' ')
  [ "$after" != "0" ] \
    || fail "$username has no password credential after provisioning. The realm policy is length(14) with digits, upper, lower and special characters, and a history of 12."
  if [ "$before" = "0" ]; then
    set_result="password set"
  else
    set_result="password already set"
  fi

  # CH1 roles only. Keycloak gives every user its own default-roles-<realm> composite, and
  # counting it made a correctly provisioned identity look like it held one more role than
  # anyone had granted - which is how a segregation violation would be missed among the
  # noise rather than seen.
  granted=$(api GET "/users/$id/role-mappings/realm" \
    | grep -o '"name":"[^"]*"' | cut -d: -f2 | tr -d '"' | grep -v '^default-roles-' || true)
  total=$(printf '%s\n' "$granted" | grep -c . || true)

  for role in $wanted; do
    printf '%s\n' "$granted" | grep -qx "$role" \
      || fail "$username does not hold $role after provisioning"
  done

  # And the segregation rules themselves, asserted on the result rather than assumed from
  # the list above. A future edit that put CybersecurityAdministrator on the operations
  # identity would pass every check but this one.
  if printf '%s\n' "$granted" | grep -qx CybersecurityAdministrator; then
    printf '%s\n' "$granted" | grep -qx SystemAdministrator \
      && fail "$username holds CybersecurityAdministrator beside SystemAdministrator, which RoleSegregation forbids"
    printf '%s\n' "$granted" | grep -qx Inspector \
      && fail "$username holds CybersecurityAdministrator beside Inspector, which RoleSegregation forbids"
  fi
  printf '%s\n' "$granted" | grep -qx DeviceController \
    && fail "$username holds DeviceController, which may never belong to a human account"

  pass "$username: $created, $set_result, $added role(s) added, $total held"
}

provision ch1-portal-demo Operations "$demo_roles"
provision ch1-portal-security Cybersecurity "$security_roles"

echo
echo "Both portal identities are ready. The password is the one in $secrets"
echo "as CINERION_PORTAL_DEMO_PASSWORD; it is not printed here and must not be."
echo
echo "  ch1-portal-demo      every role one human may hold - 13 of the 14"
echo "  ch1-portal-security  CybersecurityAdministrator, which may not sit beside"
echo "                       SystemAdministrator or Inspector"
echo
echo "Portal: http://localhost:${CINERION_LOCAL_PORTAL_PORT:-19006}   Control Core: http://localhost:${CINERION_LOCAL_API_PORT:-15090}"
