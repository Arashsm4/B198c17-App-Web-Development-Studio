#!/usr/bin/env sh
# Sets up local secrets and config so the labs can start. Run once, then forget about it.
#
# Writes infrastructure/.env.local with every value the lab needs. If the file already
# exists it is TOPPED UP, never rewritten: a value that is already there stays exactly as it
# is, because the database and identity volumes were initialised with it and a new one would
# lock the lab out of its own data (handover items 64 and 74). Only missing keys are added.
#
# The first version of this script wrote five of the seven values lab-up.sh and the identity
# provisioning need; the other two had been added by hand on the one workstation that had
# ever run the lab. A fresh machine following the documented steps stopped at "FAIL
# CINERION_APP_PASSWORD is not in infrastructure/.env.local". Found by installing the
# release package from scratch.

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
target="$repo_dir/infrastructure/.env.local"

umask 077

random_secret() {
  if command -v openssl 1>&- 2>&-; then
    openssl rand -base64 36 | tr -d '\n'
  else
    node -e "process.stdout.write(require('node:crypto').randomBytes(36).toString('base64'))"
  fi
}

# The demo sign-in password has to pass the realm's policy: 14+ characters with a digit, an
# upper-case and a lower-case letter and a special character. Random base64 misses the
# special character about one time in five, so each class is guaranteed and the result is
# shuffled. No quote, backslash or dollar sign: the value travels inside JSON and through
# Compose's env-file reader.
demo_password() {
  node -e '
    const { randomInt } = require("node:crypto");
    const sets = ["ABCDEFGHJKLMNPQRSTUVWXYZ", "abcdefghijkmnopqrstuvwxyz", "23456789", "!@#%-_."];
    const all = sets.join("");
    const chars = sets.map((set) => set[randomInt(set.length)]);
    while (chars.length < 24) chars.push(all[randomInt(all.length)]);
    for (let i = chars.length - 1; i > 0; i -= 1) {
      const j = randomInt(i + 1);
      [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    process.stdout.write(chars.join(""));
  '
}

created=false
if [ ! -e "$target" ]; then
  echo "# Generated local-only secrets. Never commit, publish, or reuse these values." > "$target"
  created=true
fi

has_key() { grep -q "^$1=" "$target"; }
added=""
add_key() {
  if ! has_key "$1"; then
    printf '%s=%s\n' "$1" "$2" >> "$target"
    added="$added $1"
  fi
}

add_key CINERION_POSTGRES_PASSWORD "$(random_secret)"
add_key CINERION_KEYCLOAK_DB_PASSWORD "$(random_secret)"
add_key CINERION_KEYCLOAK_ADMIN "cinerion-local-admin"
add_key CINERION_KEYCLOAK_ADMIN_PASSWORD "$(random_secret)"
add_key CINERION_MQTT_SECRETS_DIR "./secrets/mqtt"
add_key CINERION_APP_PASSWORD "$(random_secret)"
add_key CINERION_PORTAL_DEMO_PASSWORD "$(demo_password)"

chmod 600 "$target"
if [ "$created" = true ]; then
  echo "Created infrastructure/.env.local with fresh local-only secrets."
elif [ -n "$added" ]; then
  echo "Topped up infrastructure/.env.local; added:$added. Existing values were left alone."
else
  echo "infrastructure/.env.local already has every value the lab needs; nothing changed."
fi
echo "The Keycloak bootstrap credential is local-only and must be removed after initial provisioning."
