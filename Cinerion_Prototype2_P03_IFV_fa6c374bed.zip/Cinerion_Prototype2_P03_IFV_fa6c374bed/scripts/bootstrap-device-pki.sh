#!/usr/bin/env sh
# Generates the laboratory PKI the device mutual-TLS listener needs.
#
# CH1-IAM-FR-0008 keeps device identities off the human realm entirely: a cell controller
# or a bound instrument adapter authenticates with mutual TLS and workload identity, never
# with a password or an OIDC token. Control Core's device listener is the HTTP surface that
# implements that, and it needs three things - its own server certificate, the authority to
# validate client certificates against, and a client certificate for each device.
#
# Four artefacts, and two of them exist only so the listener can be attacked:
#
#   control-core     serverAuth, with subjectAltName entries for every name a device might
#                    address the service by inside the control zone plus loopback for a
#                    host-side run.
#   cell-confirmer   clientAuth, CN = the controller identity. Unlike the gRPC edge, the
#                    common name is NOT the authorisation here: Control Core resolves the
#                    certificate's THUMBPRINT to an enrolled device record and takes the
#                    project, the cell and the role from that. A certificate whose name
#                    matches a device but whose thumbprint is not the enrolled one
#                    authenticates as nothing.
#   unenrolled       clientAuth, signed by this authority and never enrolled. It exists so
#                    the gate can prove that trusting the authority and being an enrolled
#                    device are two independent controls.
#   foreign          clientAuth, CN identical to the real controller, signed by a SECOND
#                    authority this deployment knows nothing about. It proves identity is
#                    what this authority attested rather than a name a client chose.
#
# This is a LABORATORY certificate authority. CH1-CYB-IAM-0001 keeps root credentials
# hardware-backed and issues device certificates through a controlled provisioning ceremony
# with the private key generated inside the device's own secure element; what is produced
# here exists to exercise the transport, and every artefact says so in its subject
# organisational unit.
#
# Output goes to infrastructure/secrets/device, which .gitignore excludes. No key is ever
# printed, committed, or written anywhere else.
#
# Usage: scripts/bootstrap-device-pki.sh [--force]
set -eu

# Git Bash rewrites any argument that looks like a POSIX path into a Windows one before the
# process sees it, so "/O=Cinerion/OU=…/CN=…" arrives at openssl as "C:/Program Files/Git/…"
# and the subject is rejected. Both variables are needed; harmless everywhere else.
MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out="$repo_dir/infrastructure/secrets/device"
force=false
reissue=false
[ "${1:-}" = "--force" ] && force=true
# --reissue-controller: a new certificate for the stand-in controller ONLY, from the existing
# authority. The CA, Control Core's server certificate and every other enrolment stay as they
# are. It's how a controller enrolled with a stale capability manifest gets re-enrolled: the
# enrolment operation refuses the same certificate twice, so re-declaring means rotating.
[ "${1:-}" = "--reissue-controller" ] && reissue=true

controller_cn=${CINERION_CONFIRMER_CONTROLLER_ID:-CH1-DEV-CELL-0001}
service_cn=${CINERION_DEVICE_MTLS_SERVICE_CN:-control-core}

issue() {
  name=$1
  common_name=$2
  authority=$3
  extension=$4
  echo "Issuing $name as CN=$common_name from $authority…"
  # 3072-bit RSA because DeviceCertificate.MinimumRsaKeySize refuses anything smaller: a
  # device certificate with a multi-year life carries too little margin at 2048.
  openssl req -newkey rsa:3072 -sha256 -nodes \
    -keyout "$name.key" -out "$name.csr" \
    -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=$common_name"
  printf '%s\n' "$extension" > "$name.ext"
  openssl x509 -req -in "$name.csr" -CA "$authority.crt" -CAkey "$authority.key" -CAcreateserial \
    -out "$name.crt" -days 365 -sha256 -extfile "$name.ext"
  rm -f "$name.csr" "$name.ext"
}

if [ "$reissue" = true ]; then
  [ -f "$out/ca.crt" ] && [ -f "$out/ca.key" ] || {
    echo "No laboratory authority in $out to reissue from. Run this script without options first." >&2
    exit 1
  }
  cd "$out"
  issue cell-confirmer "$controller_cn" ca "subjectAltName=DNS:$controller_cn
extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"
  openssl pkcs12 -export -inkey cell-confirmer.key -in cell-confirmer.crt -out cell-confirmer.p12 \
    -passout pass:cinerion-lab -name cell-confirmer >/dev/null 2>&1
  chmod 644 cell-confirmer.crt 2>/dev/null || true
  chmod 600 cell-confirmer.key cell-confirmer.p12 2>/dev/null || true
  rm -f ca.srl
  echo "Reissued the stand-in controller's certificate; the authority and the server certificate are unchanged."
  exit 0
fi

if [ -f "$out/ca.crt" ] && [ "$force" != true ]; then
  echo "Device laboratory PKI already present in $out. Pass --force to regenerate."
  exit 0
fi

mkdir -p "$out"
cd "$out"

echo "Generating the laboratory certificate authority for device identities…"
openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
  -keyout ca.key -out ca.crt \
  -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=Cinerion CH1 Device CA" \
  -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

echo "Generating a second authority this deployment does not trust…"
openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
  -keyout foreign-ca.key -out foreign-ca.crt \
  -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=Untrusted Device Authority" \
  -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

issue control-core "$service_cn" ca "subjectAltName=DNS:$service_cn,DNS:control-core,DNS:localhost,IP:127.0.0.1
extendedKeyUsage=serverAuth
keyUsage=critical,digitalSignature,keyEncipherment"

# The device's own certificate carries its identifier in the subject alternative name as
# well as the common name, because DeviceCertificate.Identifies looks in both and an
# enrolment whose certificate does not name its device is refused.
issue cell-confirmer "$controller_cn" ca "subjectAltName=DNS:$controller_cn
extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

issue unenrolled "CH1-DEV-CELL-9999" ca "subjectAltName=DNS:CH1-DEV-CELL-9999
extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

issue foreign "$controller_cn" foreign-ca "subjectAltName=DNS:$controller_cn
extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

# PKCS#12 bundles for the client certificates, because curl on Windows uses schannel and
# schannel cannot import a PEM client certificate at all: it answers
# "Failed to import cert file ... 0x80092002" and CLOSES THE CONNECTION before presenting
# anything. That matters more than it sounds. An attack suite checking that a bad
# certificate is refused would have seen the connection fail, recorded a pass, and
# exercised the server not at all - which is defect 75 in a new place. The gate that uses
# these asserts a POSITIVE control first for exactly that reason.
#
# The passphrase is a fixed laboratory constant and is not a secret: these keys are
# generated here, live only in a git-ignored directory, and exist to exercise a transport.
for client in cell-confirmer unenrolled foreign; do
  openssl pkcs12 -export -inkey "$client.key" -in "$client.crt" -out "$client.p12" -passout pass:cinerion-lab -name "$client" >/dev/null 2>&1
done
chmod 600 ./*.p12 2>/dev/null || true

chmod 644 ./*.crt 2>/dev/null || true
chmod 600 ./*.key 2>/dev/null || true
rm -f ca.srl foreign-ca.srl

echo
echo "Device laboratory PKI written to infrastructure/secrets/device (git-ignored):"
echo "  ca.crt                 the only trust anchor the device listener consults"
echo "  control-core.crt/key   CN=$service_cn, serverAuth"
echo "  cell-confirmer.crt/key CN=$controller_cn, clientAuth — enrol this one"
echo "  unenrolled.crt/key     trusted authority, never enrolled — for the attack suite"
echo "  foreign.crt/key        CN=$controller_cn from an untrusted authority — for the attack suite"
echo
echo "A certificate alone authenticates nothing here. Control Core resolves its thumbprint"
echo "to an ENROLLED device record and takes the project, cell and role from that; an"
echo "unenrolled certificate, or one whose device has had its trust withdrawn, is refused."
