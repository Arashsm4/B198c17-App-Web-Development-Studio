// Reconciles the portal's capability register against the controlled sources.
//
// `apps/operator-portal/src/api/capabilities.ts` decides which acts each screen offers
// and which roles plausibly own each one. That is an authority decision, and until it
// existed the same decision was made eight times over in eight screens as
// `roles.includes('Engineer')` written wherever a control happened to be. A decision
// written in eight places is a decision nobody can review, and one that can be widened in
// one of them without anything noticing.
//
// This refuses five things:
//
//   1. an act naming an operation the controlled catalogue does not contain;
//   2. an authority phrase that is not the one `api_endpoints.json` gives that operation,
//      character for character - a paraphrase is a second declaration to keep in step;
//   3. a role list that WIDENS what `traceability/controlled-authorities.json` maps that
//      phrase to. Narrowing is permitted and must carry `narrowedBecause`; widening is an
//      authority the controlled document does not grant;
//   4. a mapped-role authority declared here as if it had no roles, or the reverse -
//      because `ownsAct` offers a no-role act to every signed-in identity, so mislabelling
//      one is how an authority silently disappears;
//   5. a screen identifier the controlled screen register does not declare.
//
// And it reports, without failing, every controlled WRITE the register does not account
// for. That list is the honest measure of what the portal does not yet offer, and it is
// printed rather than asserted because several of its entries must never be here at all:
// the two controller-local operations belong to the cell controller and the repository
// policy gate refuses them in this tree outright.
//
//   npm run capabilities

import { readFile, readdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const endpoints = JSON.parse(
  await readFile(resolve(root, 'docs/baseline/P03_IFV/data/api_endpoints.json'), 'utf8'));
const authorities = JSON.parse(
  await readFile(resolve(root, 'traceability/controlled-authorities.json'), 'utf8')).authorities;
const screens = JSON.parse(
  await readFile(resolve(root, 'docs/baseline/P03_IFV/data/screens.json'), 'utf8'));
const declaredScreens = new Set(screens.map((row) => row[0]));

const source = await readFile(
  resolve(root, 'apps/operator-portal/src/api/capabilities.ts'), 'utf8');

/**
 * The register, read out of the TypeScript rather than imported.
 *
 * Importing it would need a TypeScript loader in a plain Node gate, and parsing what the
 * file literally says has a second virtue: a value assembled at runtime - spread in from
 * somewhere, computed from a helper - would not be readable here and would fail, which is
 * the right outcome for a register that is supposed to be a flat list a reviewer can read.
 *
 * Comments are stripped first. A gate that greps a source for a symbol will match it in a
 * comment, which is item 63, and this file's own prose quotes several authority phrases.
 */
const withoutComments = source
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/^[ \t]*\/\/.*$/gm, '');

const registerBody = withoutComments.match(
  /export const ControlledActs = \{([\s\S]*?)\n\} as const satisfies/);
if (registerBody === null) {
  console.error('capabilities.ts does not declare ControlledActs in the shape this gate reads.');
  process.exit(1);
}

const acts = [];
for (const entry of registerBody[1].matchAll(/^ {2}([A-Za-z][A-Za-z0-9]*): \{([\s\S]*?)^ {2}\},$/gm)) {
  const [, name, body] = entry;
  const scalar = (field) => {
    const found = body.match(new RegExp(`^ {4}${field}:\\s*\\n?\\s*'((?:[^'\\\\]|\\\\.)*)'`, 'm'));
    return found === null ? undefined : found[1].replace(/\\'/g, "'");
  };
  const rolesRaw = body.match(/^ {4}roles: \[([^\]]*)\]/m);
  acts.push({
    name,
    operation: scalar('operation'),
    act: scalar('act'),
    authority: scalar('authority'),
    subject: scalar('subject'),
    orRelationship: scalar('orRelationship'),
    narrowedBecause: scalar('narrowedBecause'),
    screen: scalar('screen'),
    roles:
      rolesRaw === null
        ? undefined
        : [...rolesRaw[1].matchAll(/'([^']+)'/g)].map((match) => match[1]),
  });
}

if (acts.length === 0) {
  console.error('No acts were read from the register, so this gate would establish nothing.');
  process.exit(1);
}

const catalogue = new Map(endpoints.map((row) => [`${row[0]} ${row[1]}`, row]));

for (const act of acts) {
  const where = `${act.name} (${act.operation ?? 'no operation'})`;

  if (act.operation === undefined || act.act === undefined || act.authority === undefined || act.screen === undefined) {
    errors.push(`${where} is missing one of operation, act, authority or screen.`);
    continue;
  }

  const row = catalogue.get(act.operation);
  if (row === undefined) {
    errors.push(
      `${where} names an operation the controlled catalogue does not contain. ` +
      'An act the portal offers must be one api_endpoints.json declares.');
    continue;
  }

  if (row[3] !== act.authority) {
    errors.push(
      `${where} states the authority as "${act.authority}" and api_endpoints.json says ` +
      `"${row[3]}". The phrase is quoted, not paraphrased.`);
    continue;
  }

  if (!declaredScreens.has(act.screen)) {
    errors.push(`${where} claims screen ${act.screen}, which screens.json does not declare.`);
  }

  const mapped = authorities[act.authority];
  if (mapped === undefined) {
    errors.push(
      `${where} names an authority the controlled-authority register does not account for. ` +
      'npm run policy would have refused that one level up.');
    continue;
  }

  if (mapped.roles === undefined) {
    // Not a role at all. Declaring roles for it would invent an authority; declaring it
    // without a subject would leave an act offered to everyone with no stated reason.
    if (act.roles !== undefined) {
      errors.push(
        `${where} declares roles for "${act.authority}", which the authority register ` +
        `records as not a role at all: ${mapped.subject}`);
    }
    if (act.subject === undefined) {
      errors.push(
        `${where} has a non-role authority and no subject. ownsAct offers such an act to ` +
        'every signed-in identity, so the reason has to be written down.');
    }
    continue;
  }

  if (act.roles === undefined) {
    errors.push(
      `${where} declares no roles, but the authority register maps "${act.authority}" to ` +
      `${mapped.roles.join(', ')}. An act with no roles is offered to every signed-in ` +
      'identity, so this would silently drop the authority.');
    continue;
  }

  // An authority phrase naming BOTH a relationship and a role - "Session owner or
  // Identity Administrator" - must record both. `ownsAct` offers such an act to every
  // signed-in identity, which is correct because no token states whose session an object
  // is; the roles half still has to be written down, and the relationship half still has
  // to be explained, or the widest possible offer would have no stated reason.
  const RELATIONSHIP_WORDS = new Set([
    'owner', 'self', 'requester', 'participant', 'recipient', 'holder',
  ]);
  const authorityNamesARelationship = act.authority
    .toLowerCase()
    .split(/[^a-z]+/)
    .some((word) => RELATIONSHIP_WORDS.has(word));
  if (act.orRelationship !== undefined && !authorityNamesARelationship) {
    errors.push(
      `${where} declares a relationship half for "${act.authority}", which names no ` +
      'relationship. That would offer a role-only act to every signed-in identity.');
  }

  const widened = act.roles.filter((role) => !mapped.roles.includes(role));
  if (widened.length > 0) {
    errors.push(
      `${where} offers ${widened.join(', ')} an act the controlled authority "${act.authority}" ` +
      `does not name. The register maps it to ${mapped.roles.join(', ')}. ` +
      'A mapping here narrows or restates a controlled authority; it never widens one.');
  }

  const narrowed = mapped.roles.filter((role) => !act.roles.includes(role));
  if (narrowed.length > 0 && act.narrowedBecause === undefined) {
    errors.push(
      `${where} withholds the act from ${narrowed.join(', ')}, which the authority register ` +
      'maps to it, and states no reason. Narrowing is permitted and must be explained.');
  }
}

// Duplicates would mean two screens disagreeing about the same act.
const seen = new Map();
for (const act of acts) {
  const held = seen.get(act.operation);
  if (held !== undefined) {
    errors.push(`${act.operation} is declared twice, as ${held} and as ${act.name}.`);
  }
  seen.set(act.operation, act.name);
}

/**
 * Every controlled API path the portal source actually names, normalised to a template.
 *
 * Parsed rather than matched. A template literal may contain `${...}` with nested braces -
 * `${encodeURIComponent(items?.[0]?.code ?? '')}` has several - and every regular
 * expression reached for here either stops at the first `}` and under-counts or spans to
 * the last and over-counts. Both have happened, and the resulting figure was carried into
 * the handover as fact. So the braces are walked.
 */
async function portalPaths(sourceRoot) {
  const files = [];
  async function walk(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const full = `${directory}/${entry.name}`;
      if (entry.isDirectory()) await walk(full);
      else if (/\.(ts|tsx)$/.test(entry.name)) files.push(full);
    }
  }
  await walk(sourceRoot);

  const paths = new Set();
  for (const file of files) {
    const source = await readFile(file, 'utf8');
    for (let index = 0; index < source.length; index += 1) {
      const quote = source[index];
      // Double quotes as well. A JSX attribute is written `endpoint="/api/v1/reports"`,
      // and reading only single quotes and backticks made an act the portal genuinely
      // issues invisible to this count - the same lesson the grep this parser replaced
      // taught, one layer down.
      if (quote !== "'" && quote !== '`' && quote !== '"') continue;
      // Read the literal, collapsing each interpolation to one path segment placeholder.
      let cursor = index + 1;
      let literal = '';
      let closed = false;
      while (cursor < source.length) {
        const character = source[cursor];
        if (character === '\\') { cursor += 2; continue; }
        if (character === quote) { closed = true; break; }
        // Only a template literal may span lines; an unterminated quoted string is a
        // syntax error rather than something to keep reading through.
        if (character === '\n' && quote !== '`') break;
        if (quote === '`' && character === '$' && source[cursor + 1] === '{') {
          // Walk to the matching brace, counting depth, so a nested one cannot end it early.
          let depth = 1;
          cursor += 2;
          while (cursor < source.length && depth > 0) {
            if (source[cursor] === '{') depth += 1;
            else if (source[cursor] === '}') depth -= 1;
            cursor += 1;
          }
          literal += '{x}';
          continue;
        }
        literal += character;
        cursor += 1;
      }
      if (!closed) continue;
      index = cursor;
      if (!literal.startsWith('/api/v1/')) continue;
      paths.add(literal.split('?')[0]);
    }
  }
  return paths;
}

const named = await portalPaths(resolve(root, 'apps/operator-portal/src'));
const asTemplate = (path) => path.replace(/\{[^}]+\}/g, '{x}');

// What the register does not account for. Reported, never asserted: two of these must
// never appear in this tree at all.
const accounted = new Set(acts.map((act) => act.operation));
const writes = endpoints.filter((row) => row[0] !== 'GET');
const unaccounted = writes
  .map((row) => `${row[0]} ${row[1]}`)
  .filter((operation) => !accounted.has(operation));

if (errors.length > 0) {
  console.error(`\n${errors.join('\n')}`);
  process.exitCode = 1;
} else {
  console.log(
    `Portal capability register reconciled: ${acts.length} acts, every one a controlled ` +
    `operation, quoting its authority verbatim and mapped to roles the controlled-authority ` +
    `register grants it. ${acts.filter((a) => a.roles !== undefined).length} are owned by a ` +
    `role; ${acts.filter((a) => a.roles === undefined).length} are authorised by a ` +
    'relationship or a device identity and are offered to any signed-in identity.');
  console.log(
    `Controlled write operations the register does not account for: ${unaccounted.length} of ` +
    `${writes.length}.`);
  for (const operation of unaccounted) console.log(`  ${operation}`);

  // Measured from the source, not from the register: an act may be declared here and the
  // screen that was supposed to offer it never built. Reported and never asserted, because
  // two of these must never be in the portal at all.
  const issued = writes.filter((row) => named.has(asTemplate(row[1])));
  console.log(
    `\nControlled write operations the portal ISSUES: ${issued.length} of ${writes.length}, ` +
    'measured from the source by walking its template literals rather than matching them.');
  for (const row of writes) {
    if (!named.has(asTemplate(row[1]))) console.log(`  not issued: ${row[0]} ${row[1]}`);
  }
}
