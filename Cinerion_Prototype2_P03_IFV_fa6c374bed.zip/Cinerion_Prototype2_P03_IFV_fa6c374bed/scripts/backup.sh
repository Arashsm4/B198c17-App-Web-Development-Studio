#!/usr/bin/env sh
# Takes a controlled backup of Cinerion operational state, with the integrity evidence
# needed to decide later whether it is still the artefact that was taken.
#
# CH1-OPS-FR-0002 requires documented backup, integrity verification, restore and
# rollback procedures. A dump on its own satisfies none of those: nothing about a bare
# .sql file says which schema it came from, whether it is complete, or whether it has
# been altered since. So every backup is written with a manifest carrying a SHA-256 of
# the dump, a fingerprint of the controlled schema it came from and the controlled table
# count, and scripts/restore.sh refuses a backup whose dump no longer matches it.
#
# There is deliberately no version number in the manifest. This schema has no migrations
# table, and inventing one here would be a second declaration of the schema level to keep
# in step with scripts/check-database-migrations.mjs and the startup probe. The manifest
# fingerprints the controlled tables the dump actually contains, and Control Core refuses
# at start to run against a database behind its own build, naming the migration -- which
# is the guard that matters after a restore.
#
# The dump is taken with --clean --if-exists so a restore is a replacement rather than a
# merge: restoring on top of existing rows would silently produce a database that is
# neither the backup nor what was there before.
#
# Usage:
#   scripts/backup.sh --dsn <libpq-url> [--out artifacts/backups] [--label <name>]
#   scripts/backup.sh --container <name> [--database cinerion] [--user cinerion_owner]
#
# The --container form runs pg_dump inside the database container, which is how the
# controlled data zone is reached: it is on an internal network with no published host
# port, deliberately.
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out_dir="$repo_dir/artifacts/backups"
label=$(date -u +%Y%m%dT%H%M%SZ)
dsn=""
container=""
database="cinerion"
user="cinerion_owner"

while [ $# -gt 0 ]; do
  case "$1" in
    --dsn) dsn=$2; shift 2 ;;
    --container) container=$2; shift 2 ;;
    --database) database=$2; shift 2 ;;
    --user) user=$2; shift 2 ;;
    --out) out_dir=$2; shift 2 ;;
    --label) label=$2; shift 2 ;;
    *) echo "backup.sh: unknown argument $1" >&2; exit 2 ;;
  esac
done

if [ -z "$dsn" ] && [ -z "$container" ]; then
  echo "backup.sh: one of --dsn or --container is required." >&2
  exit 2
fi

mkdir -p "$out_dir"
dump="$out_dir/cinerion-$label.sql"
manifest="$out_dir/cinerion-$label.manifest.json"

table_query="select table_name from information_schema.tables where table_schema='ch1' order by table_name"

# The controlled schema only. ch1 is where every controlled record lives; the rest of the
# cluster is infrastructure a restore re-creates rather than carries.
if [ -n "$container" ]; then
  docker exec "$container" pg_dump --username="$user" --dbname="$database" \
    --schema=ch1 --clean --if-exists --no-owner --no-privileges > "$dump"
  table_list=$(docker exec "$container" psql --username="$user" --dbname="$database" -tAc "$table_query")
else
  pg_dump "$dsn" --schema=ch1 --clean --if-exists --no-owner --no-privileges > "$dump"
  table_list=$(psql "$dsn" -tAc "$table_query")
fi

table_list=$(printf '%s' "$table_list" | tr -d '\r' | sed '/^[[:space:]]*$/d')
tables=$(printf '%s\n' "$table_list" | grep -c . || true)
schema_fingerprint=$(printf '%s' "$table_list" | sha256sum | cut -d' ' -f1)

# A dump that produced no controlled tables is an empty backup, and an empty backup that
# restores cleanly is the most dangerous artefact this script could write.
if [ "$tables" -lt 1 ]; then
  rm -f "$dump"
  echo "backup.sh: the source database has no ch1 tables; refusing to write an empty backup." >&2
  exit 1
fi

checksum=$(sha256sum "$dump" | cut -d' ' -f1)
bytes=$(wc -c < "$dump" | tr -d ' ')

cat > "$manifest" <<JSON
{
  "artefact": "$(basename "$dump")",
  "takenAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "schema": "ch1",
  "controlledTables": $tables,
  "schemaFingerprint": "$schema_fingerprint",
  "bytes": $bytes,
  "sha256": "$checksum",
  "restoreWith": "scripts/restore.sh",
  "note": "Controlled operational state only. Identity lives in FortressGate and is backed up with the realm; step-up grants are deliberately never persisted and are not in this artefact."
}
JSON

echo "Backup written: $dump"
echo "  controlled tables : $tables"
echo "  schema fingerprint: $schema_fingerprint"
echo "  sha256            : $checksum"
echo "  manifest          : $manifest"
