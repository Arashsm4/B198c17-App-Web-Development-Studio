// Attacks scripts/check-cell-state-map.mjs by reverting, one at a time, each control it
// exists for. Every mutation is applied to the real files and undone afterwards, so the
// gate under attack is exactly the gate CI runs. A mutation the gate does not refuse is
// reported here as a hole, which is the only useful outcome of an attack suite.
//
// The first two attacks are the important ones, because they are defect 66 restored: the
// transition out of Complete removed from the firmware, and then removed from the map as
// well. A gate that only noticed the first would be a gate a future session could satisfy
// by deleting the declaration.

import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);

const mapPath = 'firmware/statemap/cell-state-machine-r01.json';
const headerPath = 'firmware/shared/include/cinerion/cell_state_machine.hpp';
const sourcePath = 'firmware/shared/src/cell_state_machine.cpp';
const sclPath = 'plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl';
const diagramPath = 'docs/baseline/P03_IFV/assets/cell-state-machine.svg';

const paths = [mapPath, headerPath, sourcePath, sclPath];
const originals = new Map(
  await Promise.all(paths.map(async (path) => [path, await readFile(path, 'utf8')])));

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-cell-state-map.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

/**
 * A multi-line mutation, tolerant of the line endings the file happens to carry.
 *
 * The SCL mutations below were written as exact `String.replace` calls with `\n` in them,
 * and they silently stopped matching the moment a patch script wrote the file back with
 * Windows endings: `replace` found nothing, the file was written back unchanged, and the
 * gate passed because there was no longer anything wrong with it. Two attacks became
 * decoration in one edit.
 *
 * They were caught only because this suite asserts that a mutation CHANGED something
 * before judging the gate's answer — without that check the run would have reported 18
 * attacks and 0 holes while attacking sixteen things. That assertion is the load-bearing
 * part of an attack suite, more than any individual attack is.
 */
const replaceLines = (text, from, to) => {
  const pattern = new RegExp(
    from.map((line) => line.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\r?\\n'));
  return text.replace(pattern, to.join('\n'));
};

const mcu = (map) => map.implementations.find((item) => item.id === 'mcu');
const plc = (map) => map.implementations.find((item) => item.id === 'plc');

/// Mutations of the map itself.
const mapAttacks = [
  ['the transition out of Complete deleted from the map — defect 66, restored', (map) => {
    const implementation = mcu(map);
    implementation.transitions = implementation.transitions.filter(
      (transition) => transition.from !== 'Complete');
  }, 'does not implement the controlled transition Complete --acknowledge completion / new order--> Idle'],

  ['a transition invented that the controlled diagram does not contain', (map) => {
    mcu(map).transitions.push({
      from: 'Complete', label: 'operator override', to: 'Executing', routines: ['prepare'],
    });
  }, 'which the controlled diagram does not contain'],

  ['a transition whose routine does not exist', (map) => {
    mcu(map).transitions.find((transition) => transition.from === 'Recovery').routines = ['resume_execution'];
  }, 'which does not appear in'],

  ['a transition declared with no routine performing it', (map) => {
    mcu(map).transitions.find((transition) => transition.from === 'Complete').routines = [];
  }, 'with no routine performing it'],

  ['a controlled state mapped to a state the firmware does not define', (map) => {
    mcu(map).states.Recovery = 'Recovered';
  }, 'which firmware/shared/include/cinerion/cell_state_machine.hpp does not define'],

  ['a controlled state covered and mapped to nothing', (map) => {
    delete mcu(map).states.Complete;
  }, 'maps it to nothing'],

  ['a refinement declared with no stated reason', (map) => {
    mcu(map).states.Prepared = { subsumedBy: 'AwaitCredential', reason: 'transient' };
  }, 'a refinement with no stated reason'],

  ['an extra state declared with no stated reason', (map) => {
    mcu(map).extraStates.Committed.reason = 'it is useful';
  }, 'with no stated reason'],

  ['an extra state refining a transition the diagram does not contain', (map) => {
    mcu(map).extraStates.Committed.refines = 'Idle --operator wishes--> Executing';
  }, 'which is not a transition in the controlled diagram'],

  ['coverage claimed for a state the controlled diagram does not contain', (map) => {
    mcu(map).covers.push('Maintenance');
    mcu(map).states.Maintenance = 'Idle';
    mcu(map).reachability.Maintenance = 'state_ = State::Idle';
  }, 'which the controlled diagram does not contain'],

  ['a covered state with no declared assignment', (map) => {
    delete plc(map).reachability.Complete;
  }, 'declares no assignment for it'],

  ['a covered state the implementation never assigns', (map) => {
    plc(map).reachability.Complete = '#State := 41';
  }, 'never assigns it'],
];

/// Mutations of the implementations, which is how the drift would actually arrive.
const sourceAttacks = [
  [sourcePath, 'the Complete -> Idle transition removed from the firmware', (text) =>
    text.replace('Result StateMachine::acknowledge_completion(', 'Result StateMachine::unused_completion_path('),
  'is performed by "acknowledge_completion", which does not appear in'],

  [sourcePath, 'the recovery reconciliation removed from the firmware', (text) =>
    text.replace('Result StateMachine::accept_recovery(', 'Result StateMachine::unused_recovery_path('),
  'is performed by "accept_recovery", which does not appear in'],

  [headerPath, 'the Recovery state deleted from the firmware', (text) =>
    replaceLines(text, ['    FaultLatched,', '    Recovery,'], ['    FaultLatched,']),
  'maps the controlled state "Recovery" to "Recovery", which'],

  [headerPath, 'a state added to the firmware that the controlled diagram does not contain', (text) =>
    replaceLines(text, ['    FaultLatched,', '    Recovery,'],
      ['    FaultLatched,', '    Recovery,', '    Overridden,']),
  'defines the state "Overridden", which is neither a controlled state nor a declared extension'],

  [sclPath, 'the guard sent back to Idle rather than Complete — the PLC half of defect 66', (text) =>
    replaceLines(text, ['      #State := 40;', '      #ReasonCode := 140;'],
      ['      #State := 0;', '      #ReasonCode := 140;']),
  'covers "Complete" and plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl never assigns it'],

  [sclPath, 'the guard no longer latching a procedure fault', (text) =>
    replaceLines(text, ['      #State := 90;', '      #ReasonCode := 320;'],
      ['      #State := 0;', '      #ReasonCode := 320;']),
  'covers "FaultLatched" and plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl never assigns it'],
];

let holes = 0;

const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
  console.log(output.split('\n').filter((line) => line.includes('FAIL')).slice(0, 4).join('\n'));
};

const restore = async () => {
  await Promise.all([...originals].map(([path, text]) => writeFile(path, text)));
};

// Every mutation is undone in a `finally`, including on a throw. A suite that mutates
// tracked files and then dies leaves the repository holding a deliberately broken state
// machine, which is a worse outcome than the attack never having run.
try {
  for (const [name, mutate, expected] of mapAttacks) {
    const map = JSON.parse(originals.get(mapPath));
    mutate(map);
    await writeFile(mapPath, `${JSON.stringify(map, null, 2)}\n`);
    const { refused, output } = await gate();
    await writeFile(mapPath, originals.get(mapPath));
    judge(name, expected, refused, output);
  }

  for (const [path, name, mutate, expected] of sourceAttacks) {
    const mutated = mutate(originals.get(path));
    if (mutated === originals.get(path)) {
      holes += 1;
      console.log(`  *** HOLE ***     ${name} (the mutation changed nothing, so nothing was attacked)`);
      continue;
    }
    await writeFile(path, mutated);
    const { refused, output } = await gate();
    await writeFile(path, originals.get(path));
    judge(name, expected, refused, output);
  }
} finally {
  await restore();
}

// The controlled diagram is not mutated. It is inside the frozen baseline, and
// `npm run baseline` would refuse the change on the next run whether or not this suite
// restored it — but a suite that edits a SHA-256-verified source, even briefly, is one
// crash away from leaving the baseline broken. The gate's own refusal to guess at an
// endpoint is checked by reading the diagram rather than by rewriting it.
const parsed = await readFile(diagramPath, 'utf8');
const endpoints = [...parsed.matchAll(/<path\b[^>]*class="(?:arrow|fault)"/g)].length;
if (endpoints !== 10) {
  holes += 1;
  console.log(`  *** HOLE ***     the controlled diagram carries ${endpoints} transitions, not 10; ` +
    'the gate parsed a different diagram from the one this suite was written against.');
} else {
  console.log('  NOT ATTACKED     the frozen diagram itself — it is SHA-256 verified, and ' +
    'npm run baseline is the control over it.');
}

const restored = await gate();
console.log(`\n${mapAttacks.length + sourceAttacks.length} attacks, ${holes} holes.`);
console.log(`Restored files pass the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
