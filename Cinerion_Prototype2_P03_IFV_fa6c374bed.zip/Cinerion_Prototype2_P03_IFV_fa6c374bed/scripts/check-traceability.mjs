// Makes sure every requirement maps to code or to a stated reason. No orphans.

import { access, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const load = async (path) => JSON.parse(await readFile(resolve(root, path), 'utf8'));
const requirements = await load('docs/baseline/P03_IFV/data/requirements.json');
const tests = await load('docs/baseline/P03_IFV/data/tests.json');
const implementation = await load('traceability/implementation-map.json');

const expectedIds = new Set(requirements.map((item) => item.id));
const requirementsById = new Map(requirements.map((item) => [item.id, item]));
const testIds = new Set(tests.map((row) => row[0]));
const seen = new Set();
const allowedStatuses = new Set([
  'prototype_verified',
  'implemented_pending_dotnet_ci',
  'foundation_implemented',
  'hardware_or_conformance_gated',
  'future_controlled_phase',
]);
const errors = [];

if (implementation.project !== 'Cinerion' || implementation.namespace !== 'CH1') {
  errors.push('Implementation map project identity must be Cinerion / CH1.');
}
if (implementation.governingBaseline !== 'P03/IFV') {
  errors.push('Implementation map must remain governed by P03/IFV.');
}

for (const entry of implementation.entries ?? []) {
  if (seen.has(entry.requirementId)) errors.push(`Duplicate requirement mapping: ${entry.requirementId}`);
  seen.add(entry.requirementId);
  if (!expectedIds.has(entry.requirementId)) errors.push(`Unknown requirement mapping: ${entry.requirementId}`);
  const requirement = requirementsById.get(entry.requirementId);
  if (requirement && entry.testCaseId !== requirement.test_case) errors.push(`Test-case mapping drift for ${entry.requirementId}`);
  if (requirement && entry.statement !== requirement.statement) errors.push(`Requirement statement drift for ${entry.requirementId}`);
  if (requirement && entry.priority !== requirement.priority) errors.push(`Priority drift for ${entry.requirementId}`);
  if (requirement && entry.allocation !== requirement.allocation) errors.push(`Allocation drift for ${entry.requirementId}`);
  if (!testIds.has(entry.testCaseId)) errors.push(`Unknown test case ${entry.testCaseId} for ${entry.requirementId}`);
  if (!allowedStatuses.has(entry.implementationStatus)) errors.push(`Invalid status for ${entry.requirementId}`);
  if (!Array.isArray(entry.evidence) || entry.evidence.length === 0) errors.push(`No evidence path for ${entry.requirementId}`);
  for (const evidencePath of entry.evidence ?? []) {
    try {
      await access(resolve(root, evidencePath));
    } catch {
      errors.push(`Missing evidence path for ${entry.requirementId}: ${evidencePath}`);
    }
  }
}

for (const id of expectedIds) {
  if (!seen.has(id)) errors.push(`Requirement is not mapped: ${id}`);
}

if (requirements.length !== tests.length) {
  errors.push(`Baseline requirements/tests mismatch: ${requirements.length}/${tests.length}`);
}
if (implementation.requirementCount !== requirements.length || seen.size !== requirements.length) {
  errors.push(`Implementation map count mismatch: declared ${implementation.requirementCount}, mapped ${seen.size}, expected ${requirements.length}`);
}

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  const counts = Object.groupBy(implementation.entries, (entry) => entry.implementationStatus);
  const summary = Object.fromEntries(Object.entries(counts).map(([key, entries]) => [key, entries.length]));
  console.log(`Traceability valid: ${requirements.length} requirements, ${tests.length} tests, ${seen.size} implementation mappings.`);
  console.log(JSON.stringify(summary));
}
