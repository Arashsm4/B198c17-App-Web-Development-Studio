#!/usr/bin/env sh
# CH1-VVT-TC-0021 — "EdgeLink must support replaceable protocol adapters without changing
#                    domain or inspection logic."
# CH1-VVT-TC-0022 — "Data and command semantics remain consistent across adapters."
#
# CH1-VVT-TC-0022 names MQTT, OPC UA and Modbus. Until now one of the three was operational,
# so "consistent across adapters" rested on a single live protocol. This raises the OPC UA
# controller stand-in AND the MQTT broker from the controlled compose model and runs one
# gateway against both at once, so the same unchanged AdapterConformance suite is answered
# by three operational adapters — simulator, MQTT 5 and OPC UA — in one process, with the
# fourth still gated and still refusing.
#
# It also attacks the OPC UA transport controls, because a control nobody attacked is a
# claim: CH1-COM-IF-0007 says "SignAndEncrypt + certificates" and CH1-COM-IF-0022 says
# "OPC UA SignAndEncrypt or zoned allowlist; no raw UI writes".
#
# Order matters and is deliberate. The endpoint probe runs against a FRESH controller,
# before the gateway connects, and every refusal it provokes is one that neither advances
# the guard nor spends a sequence number — PROBE-12 asserts exactly that. The controller is
# a stateful peer: a spent sequence stays spent and a prepared command stays prepared, which
# is correct behaviour and the reason the controller and the gateway are recreated together.
#
# Usage: scripts/check-opcua-edge.sh
set -eu

# Git Bash rewrites POSIX-looking values in arguments and the environment into Windows paths
# before docker sees them, which turns /run/secrets/opcua/ca.crt into a path inside the Git
# installation. Harmless elsewhere.
MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

opcua_secrets="$repo_dir/infrastructure/secrets/opcua"
mqtt_secrets="$repo_dir/infrastructure/secrets/mqtt"
failures=0

log() { printf '%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

if ! docker version >/dev/null 2>&1; then
  echo "check-opcua-edge.sh: the Docker daemon is unreachable. This gate runs a real OPC UA" >&2
  echo "controller and a real gateway against it; there is no meaningful way to run it" >&2
  echo "without one." >&2
  exit 1
fi

log "[1/6] Laboratory PKI"
./scripts/bootstrap-opcua-pki.sh > /dev/null
./scripts/bootstrap-mqtt-pki.sh > /dev/null
for artefact in ca.crt plc.crt plc.key edgelink.crt edgelink.key; do
  [ -f "$opcua_secrets/$artefact" ] || { fail "the OPC UA PKI is incomplete: $artefact is missing"; exit 1; }
done
for artefact in ca.crt broker.crt broker.key edgelink.crt edgelink.key device.crt device.key; do
  [ -f "$mqtt_secrets/$artefact" ] || { fail "the MQTT PKI is incomplete: $artefact is missing"; exit 1; }
done
pass "certificate authority, controller and gateway certificates present for both edges"

log "[2/6] Raising the OPC UA controller and the broker from the controlled compose model"
cd "$repo_dir/infrastructure"
# shellcheck disable=SC1091
[ -f .env.local ] && { set -a; . ./.env.local; set +a; }

CINERION_MQTT_HOST=mqtt
CINERION_MQTT_CLIENT_ID=ch1-edgelink
CINERION_MQTT_DEVICE_ID=CH1-DEV-CELL-0001
CINERION_MQTT_CA_CERT=/run/secrets/mqtt/ca.crt
CINERION_MQTT_CLIENT_CERT=/run/secrets/mqtt/edgelink.crt
CINERION_MQTT_CLIENT_KEY=/run/secrets/mqtt/edgelink.key
CINERION_MQTT_DEVICE_CERT=/run/secrets/mqtt/device.crt
CINERION_MQTT_DEVICE_KEY=/run/secrets/mqtt/device.key
CINERION_MQTT_DEVICE_SIMULATOR=true
CINERION_MQTT_PROJECT_ID=00000000-0000-4000-8000-000000000101
CINERION_MQTT_CELL_ID=00000000-0000-4000-8000-000000000103
CINERION_MQTT_ASSET_ID=00000000-0000-4000-8000-000000000104
CINERION_OPCUA_ENDPOINT=opc.tcp://opcua-plc:4840/ch1
CINERION_OPCUA_APPLICATION_URI=urn:cinerion:ch1:edgelink
CINERION_OPCUA_DEVICE_ID=CH1-DEV-CELL-0001
CINERION_OPCUA_CA_CERT=/run/secrets/opcua/ca.crt
CINERION_OPCUA_CLIENT_CERT=/run/secrets/opcua/edgelink.crt
CINERION_OPCUA_CLIENT_KEY=/run/secrets/opcua/edgelink.key
CINERION_OPCUA_PROJECT_ID=00000000-0000-4000-8000-000000000101
CINERION_OPCUA_CELL_ID=00000000-0000-4000-8000-000000000103
CINERION_OPCUA_ASSET_ID=00000000-0000-4000-8000-000000000104
export CINERION_MQTT_HOST CINERION_MQTT_CLIENT_ID CINERION_MQTT_DEVICE_ID \
  CINERION_MQTT_CA_CERT CINERION_MQTT_CLIENT_CERT CINERION_MQTT_CLIENT_KEY \
  CINERION_MQTT_DEVICE_CERT CINERION_MQTT_DEVICE_KEY CINERION_MQTT_DEVICE_SIMULATOR \
  CINERION_MQTT_PROJECT_ID CINERION_MQTT_CELL_ID CINERION_MQTT_ASSET_ID \
  CINERION_OPCUA_ENDPOINT CINERION_OPCUA_APPLICATION_URI CINERION_OPCUA_DEVICE_ID \
  CINERION_OPCUA_CA_CERT CINERION_OPCUA_CLIENT_CERT CINERION_OPCUA_CLIENT_KEY \
  CINERION_OPCUA_PROJECT_ID CINERION_OPCUA_CELL_ID CINERION_OPCUA_ASSET_ID

# The gateway is removed first, and this is load-bearing rather than tidiness. A gateway
# left running from an earlier run reconnects to the recreated controller and completes its
# conformance suite against it — which spends a sequence number and leaves the guard
# Prepared, so the probe below then meets a controller that refuses everything with
# STATE_INVALID for a reason that has nothing to do with what is being tested. Observed
# exactly that way: PROBE-08 through PROBE-12 all failed reporting STATE_INVALID, and
# PROBE-12 named the cause — state 10, last sequence 2000, which is EdgeLink's own
# conformance envelope. The controller is a stateful peer and the gate has to own its state.
docker compose -f compose.yaml --profile protocol-lab rm -sf edge-link > /dev/null 2>&1 || true
docker compose -f compose.yaml --profile protocol-lab up -d --build --force-recreate \
  mqtt opcua-plc > /dev/null 2>&1

attempt=0
until docker logs cinerion-opcua-plc-1 2>&1 | grep -q "CH1 OPC UA stand-in online"; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 60 ] && { fail "the OPC UA controller never came online"; break; }
  sleep 2
done
controller_log=$(docker logs cinerion-opcua-plc-1 2>&1)

printf '%s' "$controller_log" | grep -q "SignAndEncrypt/Basic256Sha256, certificate user identity, anonymous refused" \
  && pass "the controller reports SignAndEncrypt with a certificate identity and no anonymous path" \
  || fail "the controller did not report the security profile CH1-COM-IF-0007 requires"

# The controller states, at boot, the two guard checks it cannot make. A stand-in that
# stopped saying so would be one whose answers could be mistaken for the CPU's.
deferred=$(printf '%s' "$controller_log" | grep -c "deferred check" || true)
[ "$deferred" -eq 2 ] \
  && pass "the controller names both prepare checks it defers to the real CPU" \
  || fail "expected 2 deferred-check statements at boot, observed $deferred"

log "[3/6] Attacking the OPC UA transport and the guard, against a fresh controller"
cd "$repo_dir"
probe_log=$(docker compose -f infrastructure/compose.yaml --profile protocol-lab run --rm --no-deps \
  opcua-plc --probe opc.tcp://opcua-plc:4840/ch1 2>&1 || true)
printf '%s\n' "$probe_log" | grep -E '^PROBE ' || true

for check in \
  PROBE-01-NO-UNSECURED-ENDPOINT \
  PROBE-02-NO-ANONYMOUS-POLICY \
  PROBE-03-ANONYMOUS-REFUSED \
  PROBE-04-FOREIGN-CERTIFICATE-REFUSED \
  PROBE-05-TRUSTED-SESSION \
  PROBE-06-NO-RAW-WRITE \
  PROBE-07-NO-COMMIT-METHOD \
  PROBE-08-REVISION-MISMATCH \
  PROBE-09-EXPIRED-REFUSED \
  PROBE-10-SCHEMA-UNSUPPORTED \
  PROBE-11-COMMAND-NOT-IN-CAPABILITY-MODEL \
  PROBE-12-REFUSAL-LEAVES-NOTHING-BEHIND
do
  printf '%s' "$probe_log" | grep -q "PROBE PASS $check" \
    || fail "$check did not pass: $(printf '%s' "$probe_log" | grep "$check" || echo 'not reported at all')"
done
[ "$failures" -eq 0 ] && pass "all twelve endpoint probes refused what they exist to refuse"

log "[4/6] The same suite, unchanged, against a third operational adapter"
cd "$repo_dir/infrastructure"
# CH1-NFR-PER-0003 is measured by this run, so the gateway is told to measure it. Off by
# default: twenty samples cost about five seconds per adapter, spent waiting for
# preparations to lapse, and a production edge that delayed coming online to produce a
# figure for a verification report would be serving a document instead of a cell.
CINERION_EDGE_MEASURE_ACK_LATENCY=true \
docker compose -f compose.yaml --profile protocol-lab up -d --build --force-recreate \
  edge-link > /dev/null 2>&1
cd "$repo_dir"

# The gateway runs its conformance suites at startup and stops the host if any check fails,
# so waiting for it to still be running is itself part of the assertion.
attempt=0
until docker logs cinerion-edge-link-1 2>&1 | grep -q "CH1-ADP-OPCUA-0001 ADP-09"; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 60 ] && { fail "the gateway never completed OPC UA conformance"; break; }
  sleep 2
done
gateway_log=$(docker logs cinerion-edge-link-1 2>&1)

simulator_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-SIM-0001 ADP-.*passed=True" || true)
mqtt_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-MQTT-0001 ADP-.*passed=True" || true)
opcua_passes=$(printf '%s' "$gateway_log" | grep -c "adapter CH1-ADP-OPCUA-0001 ADP-.*passed=True" || true)
any_failed=$(printf '%s' "$gateway_log" | grep -c "passed=False" || true)

[ "$simulator_passes" -eq 9 ] && [ "$mqtt_passes" -eq 9 ] && [ "$opcua_passes" -eq 9 ] \
  && pass "three operational adapters passed all nine checks each (simulator $simulator_passes, MQTT $mqtt_passes, OPC UA $opcua_passes)" \
  || fail "simulator $simulator_passes, MQTT $mqtt_passes, OPC UA $opcua_passes of nine"

[ "$any_failed" -eq 0 ] \
  && pass "no conformance check failed anywhere in the gateway" \
  || fail "$any_failed conformance checks failed"

# ------------------------------------------------- CH1-NFR-PER-0003 / CH1-VVT-TC-0092
#
# "Prepared-command acknowledgement shall be less than 750 milliseconds at the 95th
# percentile on the reference local network."
#
# Measured where the requirement is allocated - CommandGuard/EdgeLink - from the gateway
# issuing a preparation to the controller's answer being in hand: the session, the
# transport, the method call and the guard's own evaluation, all of them real.
#
# ACCEPTED preparations, not refused ones. A refusal is a cheaper path through the guard
# and measuring it would flatter the result, so the accepted count is asserted alongside
# the percentile: a run that was mostly refusals measured the wrong thing, and would say so.
required_ack_ms=750
attempt=0
until docker logs cinerion-edge-link-1 2>&1 | grep -q "AckLatency CH1-ADP-OPCUA-0001"; do
  attempt=$((attempt + 1))
  [ "$attempt" -gt 60 ] && { fail "the gateway never reported an acknowledgement latency"; break; }
  sleep 2
done

ack_line=$(docker logs cinerion-edge-link-1 2>&1 | grep "AckLatency CH1-ADP-OPCUA-0001" | head -1)
if [ -z "$ack_line" ]; then
  fail "no acknowledgement latency was reported for the OPC UA adapter"
else
  printf 'NOTE  %s\n' "$ack_line"
  ack_samples=$(printf '%s' "$ack_line" | sed -n 's/.*samples=\([0-9][0-9]*\).*/\1/p')
  ack_accepted=$(printf '%s' "$ack_line" | sed -n 's/.*accepted=\([0-9][0-9]*\).*/\1/p')
  ack_p95=$(printf '%s' "$ack_line" | sed -n 's/.*p95=\([0-9.]*\)ms.*/\1/p')

  [ -n "$ack_samples" ] && [ "$ack_samples" -ge 20 ] \
    && pass "the acknowledgement latency was taken over $ack_samples preparations" \
    || fail "only ${ack_samples:-0} preparations were measured; a 95th percentile cannot be taken from that"

  [ -n "$ack_accepted" ] && [ "$ack_accepted" = "$ack_samples" ] \
    && pass "every one of the $ack_accepted measured preparations was ACCEPTED by the guard, so this is the acknowledgement path and not the refusal path" \
    || fail "only ${ack_accepted:-0} of ${ack_samples:-0} preparations were accepted; the rest measured a refusal, which is a cheaper path through the guard"

  ack_ok=$(awk -v p="$ack_p95" -v r="$required_ack_ms" 'BEGIN { print (p + 0 > 0 && p + 0 < r) ? 1 : 0 }')
  [ "$ack_ok" = "1" ] \
    && pass "prepared-command acknowledgement: p95 ${ack_p95} ms against a required ${required_ack_ms} ms" \
    || fail "prepared-command acknowledgement: p95 ${ack_p95:-unknown} ms against a required ${required_ack_ms} ms"
fi

# Modbus alone remains gated. Four checks, not eight: OPC UA has left that list.
gated=$(printf '%s' "$gateway_log" | grep -c "gated adapter.*GATE-.*passed=True" || true)
[ "$gated" -eq 4 ] \
  && pass "Modbus alone is still registered and held to the gated contract (4 checks)" \
  || fail "expected 4 gated-adapter checks with OPC UA now live, observed $gated"

log "[5/6] What the OPC UA adapter read, and where it read it from"

# The manifest is the sharpest of the nine: every field of it was browsed out of the
# controller's own address space, and the security profile names the channel it arrived on.
printf '%s' "$gateway_log" | grep -q "CH1-ADP-OPCUA-0001 online as OPCUA.*OPCUA-SIGNANDENCRYPT-BASIC256SHA256-CERTIFICATE-TRUSTLIST" \
  && pass "the OPC UA capability model came from the controller's address space, not from the adapter" \
  || fail "the OPC UA adapter did not report a browsed capability model"

printf '%s' "$gateway_log" | grep -q "OPC UA adapter connected to opc.tcp://opcua-plc:4840/ch1 with SignAndEncrypt" \
  && pass "the session is SignAndEncrypt, checked by the gateway rather than merely preferred" \
  || fail "the gateway did not report a SignAndEncrypt session"

# Scope is agreed from what the controller declares about itself, before any subscription
# or command path opens. A gateway configured for another project or cell refuses.
printf '%s' "$gateway_log" | grep -q "OPC UA adapter scope agreed with the controller: project $CINERION_OPCUA_PROJECT_ID, cell $CINERION_OPCUA_CELL_ID, asset $CINERION_OPCUA_ASSET_ID" \
  && pass "project, cell and asset scope was agreed with the controller before any command path opened" \
  || fail "the gateway did not report agreeing scope with the controller"

# ADP-06 and ADP-07 together mean a command really crossed the wire, was evaluated by the
# guard, and came back as a preparation — never as an execution.
printf '%s' "$gateway_log" | grep -q "CH1-ADP-OPCUA-0001 ADP-07-NO-PHYSICAL-CLAIM passed=True: state AwaitingCredential, reason PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION" \
  && pass "a semantic command round trip completed and the controller claimed no physical effect" \
  || fail "no acknowledged command round trip is evidenced over OPC UA"

# Monitored items really delivered, with the unit read from the channel's own
# EngineeringUnits property and the quality word translated from the server's status code.
#
# COUNTED BY CHANNEL, not by line, and the difference is the whole correctness of the
# check. The adapter reconnects twice in a normal run - once when the worker reconciles it
# at the top of its loop, and once at ADP-09, which exists to prove that reconnection
# replays nothing - and each reconnection re-establishes the subscription and legitimately
# re-delivers a first sample per channel. An exact line count therefore asserted a race:
# whether the second set had arrived before the log was read. It observed 3 for as long as
# it happened to win that race and 6 the first time it did not.
#
# What the check is actually for is that every declared channel delivered a sample with its
# own engineering unit and a translated quality word. That is a property of the channels,
# so it is counted over the channels.
sample_lines=$(printf '%s' "$gateway_log" | grep -c "OPC UA telemetry .* first sample .* quality Simulated" || true)
sample_channels=$(printf '%s' "$gateway_log" \
  | sed -n 's/.*OPC UA telemetry \([a-z_]*\) first sample .* quality Simulated.*/\1/p' \
  | sort -u | wc -l | tr -d ' ')
[ "$sample_channels" -eq 3 ] && [ "$sample_lines" -ge 3 ] \
  && pass "all three telemetry channels delivered a monitored-item sample, each united and marked Simulated ($sample_lines line(s) across $sample_channels distinct channels, re-delivered on each reconnection)" \
  || fail "expected first samples from 3 distinct OPC UA channels, observed $sample_channels distinct across $sample_lines line(s)"

# The gateway repeats what the controller told it about the checks it could not make.
printf '%s' "$gateway_log" | grep -q "OPC UA controller deferred check: 207 PRELIMINARY_PERMISSIVE_INVALID" \
  && pass "the gateway carries the controller's deferred checks through to its own log" \
  || fail "the gateway did not report the controller's deferred checks"

log "[6/6] Result"
echo
if [ "$failures" -eq 0 ]; then
  echo "The OPC UA edge is operational and its controls refuse."
  echo "  adapters passing the same suite : simulator, MQTT 5 and OPC UA, nine checks each"
  echo "  transport                       : SignAndEncrypt / Basic256Sha256, certificate"
  echo "                                    user identity, controlled trust list"
  echo "  refused                         : an unsecured endpoint, an anonymous session, a"
  echo "                                    certificate this authority never signed, a raw"
  echo "                                    write, and every guard refusal the SCL defines"
  echo "  still gated                     : Modbus, held to the gated-adapter contract"
  echo "VERIFICATION-CASE CH1-VVT-TC-0021"
  echo "VERIFICATION-CASE CH1-VVT-TC-0022"
  # CH1-NFR-PER-0003, measured on the platform half only. The real S7-1200 G2 CPU's own
  # scan cycle is part of the number this requirement ultimately governs, and a stand-in
  # does not have one, so the case stays partially_automated.
  echo "VERIFICATION-CASE CH1-VVT-TC-0092"
  exit 0
fi

echo "$failures check(s) failed. Neither case is announced."
exit 1
