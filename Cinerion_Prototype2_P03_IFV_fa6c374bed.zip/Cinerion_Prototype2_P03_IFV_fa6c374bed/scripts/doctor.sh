#!/usr/bin/env sh
# Health check for the workstation: Node, .NET, Docker, compilers and friends. Run this first
# when things feel weird.

set -u

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
soft=false
if [ "${1:-}" = "--soft" ]; then
  soft=true
fi

passes=0
warnings=0
failures=0

pass() {
  passes=$((passes + 1))
  printf 'PASS  %s\n' "$1"
}

warn() {
  warnings=$((warnings + 1))
  printf 'WARN  %s\n' "$1"
}

fail() {
  failures=$((failures + 1))
  printf 'FAIL  %s\n' "$1"
}

printf '%s\n' 'Cinerion workstation doctor'
printf '%s\n' '============================'

kernel_release=$(uname -r 2>&1)
case "$kernel_release" in
  *[Mm]icrosoft*|*[Ww][Ss][Ll]*) pass "WSL2 kernel detected: $kernel_release" ;;
  *) warn "WSL2 was not detected. Native Linux is supported, but Windows Docker Desktop instructions will not apply." ;;
esac

if [ -r /etc/os-release ]; then
  # shellcheck disable=SC1091
  . /etc/os-release
  os_label=${PRETTY_NAME:-${NAME:-Linux}}
  os_codename=${VERSION_CODENAME:-unknown}
  pass "Operating system: $os_label (codename: $os_codename)"
else
  warn "Unable to read /etc/os-release."
fi

case "$repo_dir" in
  /mnt/*) warn "Repository is under /mnt. Move it to the native WSL filesystem (for example, ~/projects/cinerion) for reliable Node and Docker performance." ;;
  *) pass "Repository uses the native Linux filesystem: $repo_dir" ;;
esac

node_output=$(node --version 2>&1)
node_status=$?
if [ "$node_status" -ne 0 ]; then
  fail "Node.js is unavailable. Install the Cinerion baseline Node 24.14.x through nvm. Details: $node_output"
else
  node_number=${node_output#v}
  old_ifs=$IFS
  IFS=.
  set -- $node_number
  IFS=$old_ifs
  node_major=${1:-0}
  node_minor=${2:-0}
  if [ "$node_major" -eq 24 ] && [ "$node_minor" -ge 14 ]; then
    pass "Node.js baseline is usable: $node_output"
  elif [ "$node_major" -gt 24 ]; then
    warn "Node.js $node_output is newer than the verified 24.14.x baseline. Use nvm to select 24.14.x before release verification."
  elif [ "$node_major" -gt 22 ] || { [ "$node_major" -eq 22 ] && [ "$node_minor" -ge 13 ]; }; then
    warn "Node.js $node_output meets the package floor but differs from the verified 24.14.x baseline."
  else
    fail "Node.js $node_output is too old. Cinerion requires at least 22.13 and verifies releases on 24.14.x."
  fi
fi

npm_output=$(npm --version 2>&1)
if [ $? -eq 0 ]; then
  npm_version=$(printf '%s\n' "$npm_output" | sed -n '$p')
  pass "npm is available: $npm_version"
else
  fail "npm is unavailable. Details: $npm_output"
fi

dotnet_output=$(dotnet --version 2>&1)
dotnet_status=$?
if [ "$dotnet_status" -eq 0 ]; then
  case "$dotnet_output" in
    10.*) pass ".NET SDK baseline is usable: $dotnet_output" ;;
    *) fail ".NET SDK $dotnet_output is installed, but Cinerion requires .NET 10.x (global.json selects 10.0.100 with feature-band roll-forward)." ;;
  esac
else
  case "$dotnet_output" in
    *'/usr/lib/dotnet/host/fxr'*|*'host/fxr'*)
      fail ".NET has a broken partial installation: the launcher exists but host/fxr is missing. Follow docs/implementation/WSL_SETUP.md to repair the Ubuntu packages."
      ;;
    *) fail ".NET 10 SDK is unavailable. Details: $dotnet_output" ;;
  esac
fi

compiler_output=$(g++ --version 2>&1)
if [ $? -eq 0 ]; then
  compiler_first=$(printf '%s\n' "$compiler_output" | sed -n '1p')
  pass "C++ compiler is available: $compiler_first"
else
  fail "g++ is unavailable. Install build-essential. Details: $compiler_output"
fi

git_output=$(git --version 2>&1)
if [ $? -eq 0 ]; then
  pass "$git_output"
else
  fail "Git is unavailable. Details: $git_output"
fi

curl_output=$(curl --version 2>&1)
if [ $? -eq 0 ]; then
  curl_first=$(printf '%s\n' "$curl_output" | sed -n '1p')
  pass "$curl_first"
else
  fail "curl is unavailable. Details: $curl_output"
fi

unzip_output=$(unzip -v 2>&1)
if [ $? -eq 0 ]; then
  pass "unzip is available"
else
  fail "unzip is unavailable. Details: $unzip_output"
fi

# A Chromium browser, because the layout gate lays screens out in one. jsdom can't, and a
# squashed page title got through 630 green checks because of it. Same list the gate uses.
browser_found=""
for candidate in "${CINERION_CHROME:-}" \
  "/c/Program Files/Google/Chrome/Application/chrome.exe" \
  "/c/Program Files (x86)/Google/Chrome/Application/chrome.exe" \
  "/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe" \
  "/c/Program Files/Microsoft/Edge/Application/msedge.exe" \
  /usr/bin/google-chrome /usr/bin/google-chrome-stable /usr/bin/chromium /usr/bin/chromium-browser \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; do
  if [ -n "$candidate" ] && [ -f "$candidate" ]; then
    browser_found=$candidate
    break
  fi
done
if [ -n "$browser_found" ]; then
  pass "Chromium browser for the layout gate: $browser_found"
else
  fail "No Chrome or Edge found for npm run layout:portal. Install one, or set CINERION_CHROME to its executable."
fi

openssl_output=$(openssl version 2>&1)
if [ $? -eq 0 ]; then
  pass "$openssl_output"
else
  warn "OpenSSL CLI is unavailable. Local secret generation can fall back to Node.js, but OpenSSL is recommended."
fi

docker_output=$(docker --version 2>&1)
docker_status=$?
if [ "$docker_status" -ne 0 ]; then
  fail "Docker is not exposed to this WSL distribution. In Docker Desktop enable Settings > Resources > WSL Integration for this Ubuntu distribution, apply/restart, then run 'wsl --shutdown' from PowerShell."
else
  pass "$docker_output"

  compose_output=$(docker compose version 2>&1)
  if [ $? -eq 0 ]; then
    pass "Docker Compose v2 is available: $compose_output"
  else
    fail "Docker CLI exists but the Compose v2 plug-in is unavailable. Details: $compose_output"
  fi

  daemon_output=$(docker info --format '{{.ServerVersion}}' 2>&1)
  if [ $? -eq 0 ]; then
    pass "Docker daemon is reachable: server $daemon_output"
  else
    fail "Docker CLI is present but the daemon is unreachable. Start Docker Desktop and wait for Engine running. Details: $daemon_output"
  fi
fi

printf '\nSummary: %s passed, %s warning(s), %s failure(s).\n' "$passes" "$warnings" "$failures"

if [ "$failures" -gt 0 ]; then
  printf '%s\n' 'Open docs/implementation/WSL_SETUP.md and repair every FAIL item before strict verification.'
  if [ "$soft" = false ]; then
    exit 1
  fi
fi

if [ "$failures" -eq 0 ]; then
  printf '%s\n' 'Workstation prerequisites are ready for Cinerion strict verification.'
fi
