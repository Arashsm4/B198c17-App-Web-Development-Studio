#!/usr/bin/env node
// CH1-NFR-PER-0002 - "Dashboard data freshness shall be less than 1.5 seconds at the 95th
// percentile on the reference local network."
//
// Reads the raw poll log written by scripts/check-baseline-load.sh while the baseline load
// was being offered, and reports what a dashboard would have been looking at.
//
// Freshness is measured as the age of the newest reading AT THE MOMENT THE READ WAS
// SERVED, plus the time that read took to come back:
//
//     freshness = (asOf - newestSampleAt) + roundTrip
//
// Both timestamps in the first term come from Control Core's own clock, so the measurement
// carries no clock skew between containers; the second term is measured by curl inside the
// polling container, so the network and the read path are included rather than assumed
// away. Adding them is the honest total: it is how old the data on the screen is by the
// time the screen has it.
//
// Measured UNDER the baseline load rather than on an idle system, because a freshness
// figure taken with nothing happening answers a question nobody asked.
//
// THE WINDOW IS THE LOAD DRIVER'S OWN, not one inferred here. The driver prints the wall
// clock bounds of its measured window - LOAD WINDOW-OPENED and LOAD WINDOW-CLOSED - and
// only polls served inside them are measured. Two earlier attempts at inferring it were
// both wrong, in opposite directions: counting polls put the read path's cold start inside
// the window, because the poller starts before the driver's container does; anchoring on
// the first reading put the seconds AFTER the load stopped inside it, where nothing is
// writing and the newest reading simply ages - 0.9 s, then 1.9 s, then 3.0 s off one
// unchanging sample - which made the figure three times the truth.
//
// Taking the bounds from the driver also means a stall DURING the window still counts
// against freshness, which an inference that discarded stale-looking polls would have
// quietly excused.
//
// Every discarded observation is still printed. The cold start and the tail are facts
// about the system and belong in the output; what they must not do is enter a percentile
// that claims to describe sustained operation.
//
// Usage: node scripts/measure-dashboard-freshness.mjs <raw-log> <opened-iso> <closed-iso>

import { readFileSync } from 'node:fs';

const [, , rawPath, openedArgument, closedArgument] = process.argv;
if (!rawPath || !openedArgument || !closedArgument) {
  console.error(
    'usage: measure-dashboard-freshness.mjs <raw-log> <opened-iso> <closed-iso>');
  process.exit(2);
}

const windowOpensAt = Date.parse(openedArgument);
const windowClosesAt = Date.parse(closedArgument);
if (Number.isNaN(windowOpensAt) || Number.isNaN(windowClosesAt) || windowClosesAt <= windowOpensAt) {
  console.error(
    `the measured window is not a usable interval: '${openedArgument}' to '${closedArgument}'`);
  process.exit(2);
}
const raw = readFileSync(rawPath, 'utf8');

// One chunk per poll. The marker is printed by the poller after curl has written both the
// body and its own timing line, so a chunk is a complete observation or it is discarded.
const chunks = raw.split('LOADPOLL-END').slice(0, -1);

const observations = [];
const unusable = [];

chunks.forEach((chunk, index) => {
  const poll = index + 1;
  const rtt = /LOADRTT ([0-9.]+)/.exec(chunk);
  const start = chunk.indexOf('{');
  const end = chunk.lastIndexOf('}');
  if (!rtt || start < 0 || end <= start) {
    unusable.push(`poll ${poll}: no complete response`);
    return;
  }

  let body;
  try {
    body = JSON.parse(chunk.slice(start, end + 1));
  } catch {
    unusable.push(`poll ${poll}: the response was not JSON`);
    return;
  }

  if (!body.asOf || !body.newestSampleAt) {
    // Before the first reading exists there is nothing whose age could be measured. That
    // is not a freshness failure and it is not silently a pass either: it is counted.
    unusable.push(`poll ${poll}: the service held no reading yet`);
    return;
  }

  const servedAt = Date.parse(body.asOf);
  const ageMs = servedAt - Date.parse(body.newestSampleAt);
  const roundTripMs = Number.parseFloat(rtt[1]) * 1000;
  observations.push({ poll, servedAt, ageMs, roundTripMs, totalMs: ageMs + roundTripMs });
});

if (observations.length === 0) {
  console.log('FRESHNESS OBSERVATIONS 0');
  console.log(`FRESHNESS UNUSABLE-COUNT ${unusable.length}`);
  for (const reason of unusable.slice(0, 5)) {
    console.log(`FRESHNESS UNUSABLE ${reason}`);
  }
  process.exit(0);
}

const warmingUp = observations.filter((entry) => entry.servedAt < windowOpensAt);
const afterTheLoad = observations.filter((entry) => entry.servedAt >= windowClosesAt);
const measured = observations.filter(
  (entry) => entry.servedAt >= windowOpensAt && entry.servedAt < windowClosesAt);

const round = (value) => Math.round(value * 10) / 10;

console.log(`FRESHNESS OBSERVATIONS ${measured.length}`);
console.log(`FRESHNESS WINDOW-OPENED ${new Date(windowOpensAt).toISOString()}`);
console.log(`FRESHNESS WINDOW-CLOSED ${new Date(windowClosesAt).toISOString()}`);
console.log(`FRESHNESS WARMUP-DISCARDED ${warmingUp.length}`);
console.log(`FRESHNESS AFTER-LOAD-DISCARDED ${afterTheLoad.length}`);
console.log(`FRESHNESS UNUSABLE-COUNT ${unusable.length}`);

if (measured.length === 0) {
  console.log('FRESHNESS P95-MS 0');
  process.exit(0);
}

const sorted = [...measured].sort((left, right) => left.totalMs - right.totalMs);
const percentile = (fraction) =>
  sorted[Math.min(sorted.length - 1, Math.floor(fraction * sorted.length))].totalMs;

console.log(`FRESHNESS P50-MS ${round(percentile(0.5))}`);
console.log(`FRESHNESS P95-MS ${round(percentile(0.95))}`);
console.log(`FRESHNESS P99-MS ${round(percentile(0.99))}`);
console.log(`FRESHNESS WORST-MS ${round(sorted[sorted.length - 1].totalMs)}`);
console.log(
  `FRESHNESS WORST-AGE-MS ${round(Math.max(...measured.map((entry) => entry.ageMs)))}`);
console.log(
  `FRESHNESS WORST-ROUND-TRIP-MS ${round(Math.max(...measured.map((entry) => entry.roundTripMs)))}`);

// The discarded warm-up, printed rather than dropped. A reader can see exactly what was
// excluded and decide for themselves whether the exclusion was fair.
console.log(
  'FRESHNESS WARMUP-PROFILE ' +
  (warmingUp.length === 0
    ? 'none'
    : warmingUp.map((entry) => `${round(entry.totalMs)}`).join(',')));

// And the tail, for the same reason: these are the seconds after the load stopped, where
// the newest reading is simply getting older because nothing is writing one.
console.log(
  'FRESHNESS AFTER-LOAD-PROFILE ' +
  (afterTheLoad.length === 0
    ? 'none'
    : afterTheLoad.map((entry) => `${round(entry.totalMs)}`).join(',')));
for (const reason of unusable.slice(0, 5)) {
  console.log(`FRESHNESS UNUSABLE ${reason}`);
}
