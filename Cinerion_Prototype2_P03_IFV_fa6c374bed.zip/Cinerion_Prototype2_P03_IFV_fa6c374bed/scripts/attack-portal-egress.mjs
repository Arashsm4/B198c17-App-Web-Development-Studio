// Attacks the portal egress gate.
//
// `npm run portal:egress` exists to keep a public-internet dependency out of the half of
// this platform that runs in a browser - CH1-OPS-FR-0001, and CH1-AI-FR-0002 where the
// public host would be a model endpoint. Like every gate that searches for an ABSENCE, it
// prints the same thing whether the tree is clean or the search is broken, so each attack
// below puts back exactly what it is supposed to refuse and asserts it FAILED and said why.
//
// Every attack first asserts that its mutation CHANGED the file (defect 75), and every
// file is restored afterwards including on a crash, with a byte-identical check at the end.
//
// The exported bundle is one of the targets. It is git-ignored and rebuilt by
// `npm run build:portal`, so mutating it is safe - but it is restored anyway, because an
// attack suite that leaves the artefact it examined in a state nobody chose has made the
// next gate's result meaningless.
//
//   npm run portal:egress:attack

import { execFile } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { glob } from 'node:fs/promises';

const run = promisify(execFile);
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

// The exported entry bundle, found rather than named: its filename carries a content hash
// that changes with every build.
const bundleMatches = [];
for await (const entry of glob('apps/operator-portal/dist/_expo/static/js/web/*.js', { cwd: root })) {
  bundleMatches.push(entry.replaceAll('\\', '/'));
}
if (bundleMatches.length === 0) {
  console.error(
    'FAIL  No exported portal bundle found under apps/operator-portal/dist. Run npm run build:portal first.');
  process.exit(1);
}

const targets = {
  gate: 'scripts/check-portal-egress.mjs',
  nginx: 'infrastructure/nginx/operator-portal.conf',
  compose: 'infrastructure/compose.yaml',
  session: 'apps/operator-portal/src/auth/session.tsx',
  realm: 'infrastructure/keycloak/cinerion-realm.json',
  dockerfile: 'apps/operator-portal/Dockerfile',
  bundle: bundleMatches[0],
};

const originals = new Map();
for (const [key, path] of Object.entries(targets)) {
  originals.set(key, await readFile(resolve(root, path), 'utf8'));
}

let attacks = 0;
let holes = 0;

async function gate() {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-portal-egress.mjs'], { cwd: root, maxBuffer: 32 * 1024 * 1024 });
    return { refused: false, output: stdout };
  } catch (cause) {
    return { refused: true, output: `${cause.stdout ?? ''}${cause.stderr ?? ''}` };
  }
}

async function attack(name, key, mutate, expectation) {
  attacks += 1;
  const path = resolve(root, targets[key]);
  const original = originals.get(key);
  const mutated = mutate(original);
  if (mutated === original) {
    holes += 1;
    console.log(`HOLE  ${name} — the mutation changed nothing, so the gate was never exercised.`);
    return;
  }
  await writeFile(path, mutated, 'utf8');
  try {
    const result = await gate();
    if (!result.refused) {
      holes += 1;
      console.log(`HOLE  ${name} — the gate ACCEPTED it.`);
      return;
    }
    if (expectation !== undefined && !result.output.includes(expectation)) {
      holes += 1;
      console.log(`HOLE  ${name} — refused, but not for the stated reason. Expected: ${expectation}`);
      return;
    }
    console.log(`ok    ${name}`);
  } finally {
    await writeFile(path, original, 'utf8');
  }
}

console.log('Attacking the portal egress gate.\n');

// -- The browser's own enforcement. --

// 1. The widest possible hole: default-src open to anywhere.
await attack(
  'default-src widened past self',
  'nginx',
  (source) => source.replace("default-src 'self'", "default-src 'self' https:"),
  'rather than \'self\'',
);

// 2. A font service. The classic accidental egress, and it comes in through a stylesheet
//    rather than through anybody's code.
await attack(
  'a public font service permitted',
  'nginx',
  (source) => source.replace("font-src 'self' data:", "font-src 'self' data: https://fonts.gstatic.com"),
  'which is not a local origin',
);

// 3. A script CDN.
await attack(
  'a script CDN permitted',
  'nginx',
  (source) => source.replace("style-src 'self' 'unsafe-inline'", "style-src 'self' 'unsafe-inline'; script-src 'self' https://cdn.jsdelivr.net"),
  'which is not a local origin',
);

// 4. 'unsafe-eval', which makes a string into executable code and so makes every static
//    check in the gate advisory.
await attack(
  "'unsafe-eval' allowed",
  'nginx',
  (source) => source.replace("style-src 'self' 'unsafe-inline'", "style-src 'self' 'unsafe-inline' 'unsafe-eval'"),
  "allows 'unsafe-eval'",
);

// 5. Framing, which is a different exfiltration surface from fetching.
await attack(
  'frame-ancestors relaxed',
  'nginx',
  (source) => source.replace("frame-ancestors 'none'", "frame-ancestors 'self'"),
  'frame-ancestors',
);

// 6. No policy at all. The gate must not treat a missing header as nothing to check.
await attack(
  'the Content-Security-Policy removed entirely',
  'nginx',
  (source) => source.replace(/^\s*add_header\s+Content-Security-Policy.*$/m, ''),
  'declares no Content-Security-Policy',
);

// -- Where the portal is built to talk to. --

// 7. A build argument pointed at a public host. The Dockerfile derives connect-src from
//    these, so this widens the policy as well as the bundle.
await attack(
  'the controlled model pointing the portal at a public API',
  'compose',
  (source) => source.replace(
    'EXPO_PUBLIC_CINERION_API_URL: ${EXPO_PUBLIC_CINERION_API_URL:-http://localhost:5080}',
    'EXPO_PUBLIC_CINERION_API_URL: ${EXPO_PUBLIC_CINERION_API_URL:-https://api.cinerion.example.com}'),
  'whose host is not local',
);

// 7b. The same value moved out of the substitution's default, which is how an earlier
//     revision of the gate came to examine none of these four while printing a count of
//     them. Kept as its own attack so that hole cannot come back quietly.
await attack(
  'a public API origin written as a plain value rather than a substitution default',
  'compose',
  (source) => source.replace(
    'EXPO_PUBLIC_CINERION_API_URL: ${EXPO_PUBLIC_CINERION_API_URL:-http://localhost:5080}',
    'EXPO_PUBLIC_CINERION_API_URL: https://api.cinerion.example.com'),
  'whose host is not local',
);

// 7c. Every argument left to the environment, so the model decides nothing. The gate has
//     to say it established nothing rather than print a reassuring count of skips.
await attack(
  'the model deciding no build argument at all',
  'compose',
  (source) => source
    .replace('${EXPO_PUBLIC_CINERION_API_URL:-http://localhost:5080}', '${EXPO_PUBLIC_CINERION_API_URL}')
    .replace('${EXPO_PUBLIC_CINERION_OIDC_AUTHORITY:-http://localhost:8180/realms/cinerion}', '${EXPO_PUBLIC_CINERION_OIDC_AUTHORITY}')
    .replace('${EXPO_PUBLIC_CINERION_OIDC_CLIENT_ID:-cinerion-operator-portal}', '${EXPO_PUBLIC_CINERION_OIDC_CLIENT_ID}')
    .replace(/EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL: .*/, 'EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL: ${EXPO_PUBLIC_CINERION_CELL_SIMULATOR_URL}'),
  'established nothing',
);

// -- The artefact that ships. --

// 8. A public origin inside the exported bundle - how a dependency upgrade introduces an
//    egress nobody decided on.
await attack(
  'a public origin appearing in the exported bundle',
  'bundle',
  (source) => `var __beacon="https://telemetry.example.net/collect";\n${source}`,
  'names the public origin',
);

// 9. An AI service host in the bundle. The static tree gate reads first-party files; a
//    model endpoint arriving inside a dependency shows up only here.
await attack(
  'an AI service host inside the exported bundle',
  'bundle',
  (source) => `var __advisor="https://api.anthropic.com/v1/messages";\n${source}`,
  'names the AI service host',
);

// 10. A stale exemption. An allowlist that stops describing the artefact it governs is how
//     a permission outlives its reason.
await attack(
  'an allowlist entry for an origin the bundle does not contain',
  'gate',
  (source) => source.replace(
    "  ['http://hostname', ",
    "  ['https://cdn.example.org', 'no reason at all'],\n  ['http://hostname', "),
  'which the exported bundle no longer contains',
);

// -- The hosted auth proxy, and both of its controls. --

// 11. Asking for the proxy explicitly.
await attack(
  'the Expo hosted auth proxy switched on',
  'session',
  (source) => source.replace('AuthSession.makeRedirectUri()', 'AuthSession.makeRedirectUri({ useProxy: true })'),
  'mentions useProxy',
);

// 12. An option object with no useProxy in it. Still refused: the option object is where
//     the proxy would live, and a gate that only greps for the word would miss a variable.
await attack(
  'makeRedirectUri given an options object',
  'session',
  (source) => source.replace('AuthSession.makeRedirectUri()', "AuthSession.makeRedirectUri({ scheme: 'cinerion' })"),
  'It must be called with none',
);

// 13. The second, independent control: the realm refusing a non-local redirect. Removing
//     it would leave the proxy blocked by one thing instead of two.
await attack(
  'the controlled realm permitting a public redirect target',
  'realm',
  (source) => source.replace('"http://localhost:8081/*"', '"https://auth.expo.io/@cinerion/portal"'),
  'whose host is not local',
);

// -- The build's own reporting. --

// 14. Expo's CLI reports usage by default, and the build happens inside the image, so the
//     shell variable in verify.sh does not reach it.
await attack(
  'build telemetry re-enabled in the portal image',
  'dockerfile',
  (source) => source.replace('ENV EXPO_NO_TELEMETRY=1 CI=1', 'ENV CI=1'),
  'reports usage to a public host',
);

// -- Restoration. --

let unrestored = 0;
for (const [key, path] of Object.entries(targets)) {
  const now = await readFile(resolve(root, path), 'utf8');
  if (now !== originals.get(key)) {
    holes += 1;
    unrestored += 1;
    console.log(`HOLE  ${path} was NOT restored to its original content.`);
  }
}
if (unrestored === 0) {
  attacks += 1;
  console.log(`ok    all ${Object.keys(targets).length} mutated files are byte-identical to how the suite found them`);
}

// And the gate passes again on the restored tree. An attack suite that leaves a refusal
// behind has broken the thing it was checking.
attacks += 1;
const finalRun = await gate();
if (finalRun.refused) {
  holes += 1;
  console.log(`HOLE  the gate refuses the restored tree: ${finalRun.output}`);
} else {
  console.log('ok    the gate passes again on the restored tree');
}

console.log();
if (holes > 0) {
  console.error(`Portal egress gate: ${attacks} attacks, ${holes} HOLES.`);
  process.exitCode = 1;
} else {
  console.log(`Portal egress gate: ${attacks} attacks, 0 holes.`);
}
