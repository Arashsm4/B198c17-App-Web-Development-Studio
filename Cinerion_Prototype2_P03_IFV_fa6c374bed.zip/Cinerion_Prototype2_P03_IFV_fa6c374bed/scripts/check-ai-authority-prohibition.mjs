// CH1-VVT-TC-0066 - "AI authority prohibition. AI service has no command, approval or
//                    release permission."
// CH1-AI-FR-0002   - "AI shall not approve, release, authenticate, locally confirm or
//                     command physical equipment." Must, verified by Test.
// CH1-CYB-ACP-0001 - access.json carries the row
//                    ["Approve or command via AI", "None", "Not applicable",
//                     "Explicitly prohibited"]. Role NONE, strength NOT APPLICABLE.
// CH1-PMG-AIU-0005 - "Prohibited authority ... No authentication, command, confirmation,
//                     NCR closure or release ... Enforced by architecture and access
//                     controls." Status: "Baseline rule".
// CH1-SWA-ADR-0010 - "Keep AI outside authentication, approval and command paths."
//                    Accepted.
// CH1-CYB-THR-0018 - "AI prompt injection through evidence", allocated to the Engineering
//                    Assistant, mitigated by "Read-only isolation, provenance and human
//                    review".
//
// WHAT THIS GATE ADDS, AND WHY IT IS NOT THE ONE THAT ALREADY EXISTS.
//
// The verification map binds CH1-VVT-TC-0066 to `policy-gate` and records, honestly, what
// that binding is worth: "No AI role exists in CinerionRoles or in the realm ... That is
// the absence of authority, not a test of a service that does not exist." True, and thin.
// A role register can be complete while an HTTP client three layers down posts controlled
// evidence to a model endpoint and writes the answer into a record - no role required,
// because a service reaching out needs none.
//
// So the prohibition is enforced here over the whole deployable tree rather than over the
// role register: no AI client library may be depended on, no AI service host may be
// named, no model identifier, no AI credential, no actor kind or role, and no component
// in the controlled architecture. The absence is MEASURED rather than assumed, and it is
// measured against patterns this gate proves it can still find (see the positive control
// below).
//
// THE RULE IS READ FROM THE BASELINE, NOT HARDCODED. If access.json stops prohibiting
// "Approve or command via AI", or CH1-AI-FR-0002 changes, this gate refuses and says the
// rule has moved rather than continuing to enforce a rule the controlled documents no
// longer state. A gate that outlives its authority is a gate nobody can reason about.
//
// THIS IS ALSO A DEPLOYMENT PROPERTY. CH1-OPS-FR-0001 requires principal workflows to run
// on the local network with no public-internet dependency, and every AI service named
// below is a public-internet host. scripts/check-offline-workflow.sh proves the workflow
// completes on a genuinely internal network; this gate proves nothing in the tree is
// reaching for one of these hosts in the first place. The two are complementary: that one
// is behavioural and covers Control Core, this one is static and covers everything.
//
// Usage: node scripts/check-ai-authority-prohibition.mjs

import { readdir, readFile } from 'node:fs/promises';
import { basename, dirname, extname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const notes = [];

// ---------------------------------------------------------------------------------------
// 0. The prohibited surface.
//
// Each entry is a class of thing that would put an AI service inside this platform. They
// are separated because the refusal has to name which one was found: "an AI dependency"
// and "a model identifier in a string" are different mistakes with different fixes.
// ---------------------------------------------------------------------------------------

// Dependency identifiers. Matched against declared dependency NAMES, not against source
// text, so `ai` and `openai` can be exact without a word like "domain" tripping them.
const prohibitedNpmPackages = new Set([
  'ai', 'openai', 'openai-edge', 'ollama', 'replicate', 'groq-sdk', 'cohere-ai',
  'langchain', 'llamaindex', 'together-ai', 'tiktoken', 'js-tiktoken', 'gpt-3-encoder',
  'onnxruntime-node', 'onnxruntime-web', 'anthropic', 'claude-sdk', 'gpt4all',
]);
const prohibitedNpmScopes = [
  '@anthropic-ai/', '@openai/', '@google/generative-ai', '@google/genai', '@azure/openai',
  '@aws-sdk/client-bedrock', '@mistralai/', '@huggingface/', '@langchain/', '@ai-sdk/',
  '@xenova/transformers', '@tensorflow/tfjs',
];
const prohibitedNuGetPrefixes = [
  'Anthropic', 'OpenAI', 'Betalgo.OpenAI', 'Azure.AI.OpenAI', 'Azure.AI.Inference',
  'AWSSDK.BedrockRuntime', 'Microsoft.SemanticKernel', 'Microsoft.Extensions.AI',
  'Microsoft.ML', 'LLamaSharp', 'OllamaSharp', 'Google.Cloud.AIPlatform',
  'Mistral', 'Cohere', 'HuggingFace',
];

// Service hosts. Every one is a public-internet endpoint, which is why this list is also
// evidence for CH1-OPS-FR-0001.
const prohibitedHosts = [
  'api.anthropic.com', 'api.openai.com', 'oai.azure.com', 'openai.azure.com',
  'generativelanguage.googleapis.com', 'aiplatform.googleapis.com',
  'api.cohere.ai', 'api.cohere.com', 'api.mistral.ai', 'api-inference.huggingface.co',
  'api.groq.com', 'api.together.xyz', 'api.replicate.com', 'api.perplexity.ai',
  'api.deepseek.com', 'api.x.ai', 'api.voyageai.com', 'bedrock-runtime.',
];

// Model identifiers. Shaped to require the hyphen-and-character form a model id has, so
// the repository's own directory name (…/Cinerion/Claude/…) cannot match: a path carries a
// separator after the word, never a hyphen.
const prohibitedModelPatterns = [
  /claude-[a-z0-9]/i, /gpt-3\.5/i, /gpt-4/i, /gpt-5/i, /text-davinci/i,
  /gemini-[0-9]/i, /gemini-pro/i, /llama-[0-9]/i, /mixtral-/i, /mistral-large/i,
  /command-r\b/i, /deepseek-chat/i, /o[134]-mini\b/i, /text-embedding-(ada|3)/i,
];

// Credentials. An AI key in the tree would be a secret and a dependency at once.
const prohibitedCredentials = [
  'ANTHROPIC_API_KEY', 'CLAUDE_API_KEY', 'OPENAI_API_KEY', 'OPENAI_ORG_ID',
  'AZURE_OPENAI_API_KEY', 'AZURE_OPENAI_ENDPOINT', 'GEMINI_API_KEY', 'COHERE_API_KEY',
  'MISTRAL_API_KEY', 'GROQ_API_KEY', 'HUGGINGFACE_TOKEN', 'HUGGINGFACEHUB_API_TOKEN',
  'REPLICATE_API_TOKEN', 'TOGETHER_API_KEY', 'PERPLEXITY_API_KEY', 'DEEPSEEK_API_KEY',
  'XAI_API_KEY',
];

// Authority surfaces. An AI actor kind, role or authority constant would make the
// prohibition expressible as a permission, which access.json says it is not.
const prohibitedAuthorityPatterns = [
  /\bAiAssistant\b/, /\bEngineeringAssistant\b/, /ActorKind\.(Ai|Assistant|Model)\b/,
  /\bAiService\b/, /\bAiAgent\b/, /\bLlm[A-Z]/,
];

// ---------------------------------------------------------------------------------------
// 1. POSITIVE CONTROL: the matchers are exercised before anything is judged by them.
//
// Item 71 of the handover, three times in one session: a backslash written into a patch
// script arrives collapsed, and a regular expression with a collapsed `\b` silently stops
// matching. A gate whose matchers have quietly died reports a clean tree for a tree it
// never examined - which is defect 75's shape, and the reason every attack suite here
// asserts its mutation changed something. The same reasoning applies to a gate that
// searches for absence: absence is indistinguishable from a broken search.
//
// So each class is first run against a synthetic buffer that DOES contain it. If any
// matcher fails to fire here, the gate refuses and reports which one, and no conclusion is
// drawn about the repository at all.
// ---------------------------------------------------------------------------------------

const positiveControls = [
  { klass: 'host', probe: 'const endpoint = "https://api.anthropic.com/v1/messages";' },
  { klass: 'host', probe: 'BEDROCK = "bedrock-runtime.eu-central-1.amazonaws.com"' },
  { klass: 'model', probe: 'const model = "claude-opus-4-20250514";' },
  { klass: 'model', probe: 'model: "gpt-4o-mini"' },
  { klass: 'credential', probe: 'var key = Environment.GetEnvironmentVariable("OPENAI_API_KEY");' },
  { klass: 'authority', probe: 'if (actor.Kind == ActorKind.Ai) { return true; }' },
  { klass: 'authority', probe: 'public const string AiAssistant = "AiAssistant";' },
];

const matchHosts = (text) => prohibitedHosts.filter((host) => text.includes(host));
const matchModels = (text) => prohibitedModelPatterns.filter((pattern) => pattern.test(text));
const matchCredentials = (text) => prohibitedCredentials.filter((name) => text.includes(name));
const matchAuthority = (text) => prohibitedAuthorityPatterns.filter((pattern) => pattern.test(text));

const matchersByClass = {
  host: matchHosts,
  model: matchModels,
  credential: matchCredentials,
  authority: matchAuthority,
};

let controlsFired = 0;
for (const control of positiveControls) {
  const found = matchersByClass[control.klass](control.probe);
  if (found.length === 0) {
    errors.push(
      `POSITIVE CONTROL FAILED: the ${control.klass} matcher did not fire on a buffer that ` +
      `contains a ${control.klass} it is supposed to refuse: ${control.probe.trim()}. ` +
      'Nothing this gate says about the repository can be believed until that is fixed.');
  } else {
    controlsFired += 1;
  }
}

// A failed positive control makes every later result meaningless, so stop rather than
// print a reassuring count next to a broken search.
if (errors.length > 0) {
  for (const error of errors) console.error(`FAIL  ${error}`);
  process.exit(1);
}

// ---------------------------------------------------------------------------------------
// 2. The rule is still the baseline's rule.
// ---------------------------------------------------------------------------------------

const baselineData = (name) =>
  readFile(resolve(root, 'docs/baseline/P03_IFV/data', name), 'utf8').then(JSON.parse);

const access = await baselineData('access.json');
const requirements = await baselineData('requirements.json');
const aiUsage = await baselineData('ai_usage.json');
const adrs = await baselineData('adrs.json');

const prohibitionRow = access.find((row) => Array.isArray(row) && row[0] === 'Approve or command via AI');
if (!prohibitionRow) {
  errors.push(
    'access.json no longer contains the row "Approve or command via AI". This gate enforces a ' +
    'controlled prohibition and cannot enforce one the baseline has stopped stating.');
} else {
  const [, role, strength, control] = prohibitionRow;
  if (role !== 'None' || strength !== 'Not applicable' || control !== 'Explicitly prohibited') {
    errors.push(
      'access.json still names "Approve or command via AI" but no longer as ' +
      `[None | Not applicable | Explicitly prohibited]; it now reads [${role} | ${strength} | ` +
      `${control}]. A prohibition that has become a permission is an owner decision, not ` +
      'something this gate may keep refusing.');
  }
}

const aiFr0002 = requirements.find((entry) => entry.id === 'CH1-AI-FR-0002');
if (!aiFr0002) {
  errors.push('CH1-AI-FR-0002 is absent from requirements.json, so this gate has no requirement to verify.');
} else if (!/shall not approve, release, authenticate, locally confirm or command/i.test(aiFr0002.statement)) {
  errors.push(`CH1-AI-FR-0002's statement has changed: "${aiFr0002.statement}".`);
}

const prohibitedAuthorityUsage = aiUsage.find((row) => Array.isArray(row) && row[0] === 'CH1-PMG-AIU-0005');
if (!prohibitedAuthorityUsage || prohibitedAuthorityUsage[5] !== 'Baseline rule') {
  errors.push(
    'CH1-PMG-AIU-0005 is no longer a "Baseline rule" in ai_usage.json. That row is what makes the ' +
    'prohibition a rule rather than a preference.');
}

const adr0010 = adrs.find((row) => Array.isArray(row) && row[0] === 'CH1-SWA-ADR-0010');
if (!adr0010 || adr0010[2] !== 'Accepted') {
  errors.push('CH1-SWA-ADR-0010 ("Keep AI outside authentication, approval and command paths") is no longer Accepted.');
}

// ---------------------------------------------------------------------------------------
// 3. The tree this gate is responsible for.
//
// Scanned: every deployable and buildable directory. Not scanned, each for a stated
// reason:
//   docs/baseline/  frozen controlled sources, verified by SHA-256 elsewhere. They
//                   legitimately CONTAIN the prohibition and the AI usage register, which
//                   is the text this gate reads its authority from.
//   docs/           documentation describing a prohibition is not an implementation of
//                   the thing prohibited. The progress record names these hosts and model
//                   identifiers in order to report what is refused.
//   this gate and its attack suite, by name, for the same reason: the pattern list has to
//                   live somewhere.
// Generated and vendored trees are skipped exactly as scripts/check-repository-policy.mjs
// skips them, and for the same reason: a count that changes with whether somebody has
// built is a count nobody can reason about.
// ---------------------------------------------------------------------------------------

const scannedRoots = [
  'apps', 'firmware', 'infrastructure', 'packages', 'plc', 'scripts', 'services',
  'simulators', 'tests', 'tools', 'traceability',
];
const ignoredDirectories = new Set([
  '.git', '.expo', '.local', 'artifacts', 'bin', 'build', 'dist', 'node_modules', 'obj',
  'release', 'secrets',
]);
const textExtensions = new Set([
  '.conf', '.cpp', '.cs', '.csproj', '.css', '.h', '.hpp', '.html', '.js', '.json',
  '.cmd', '.mjs', '.props', '.ps1', '.scl', '.sh', '.slnx', '.sql', '.ts', '.tsx', '.yaml', '.yml',
]);
// A gate must NAME what it refuses, and an attack suite must be able to inject it. These
// four files are the ones whose subject IS this prohibition, and they are exempt by exact
// path rather than by pattern.
//
// Found by the gate itself, on the first strict run after `check-portal-egress.mjs` was
// written: that gate checks the exported bundle against the same AI host list, and this one
// refused it 17 times. The right outcome, and the reason the exemption is spelled out
// rather than loosened - `scripts/` as a whole is NOT exempt, because it holds the
// laboratory and packaging scripts a real egress could be added to.
const selfExempt = new Set([
  'scripts/check-ai-authority-prohibition.mjs',
  'scripts/attack-ai-authority-prohibition.mjs',
  'scripts/check-portal-egress.mjs',
  'scripts/attack-portal-egress.mjs',
]);

// And the exemption cannot quietly grow to cover product code. Every exempt path must be a
// gate script: under scripts/, a .mjs, and named for checking or attacking. A gate with an
// exemption nothing constrains is a gate that can be switched off by editing a list.
for (const path of selfExempt) {
  if (!/^scripts\/(check|attack)-[a-z0-9-]+\.mjs$/.test(path)) {
    errors.push(
      `selfExempt contains "${path}", which is not a gate script under scripts/. Only a gate whose own ` +
      'subject is this prohibition may name what it refuses; exempting anything else switches the gate ' +
      'off for that file.');
  }
}

async function walk(directory) {
  let entries;
  try {
    entries = await readdir(directory, { withFileTypes: true });
  } catch {
    return [];
  }
  const found = [];
  for (const entry of entries) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue;
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) found.push(...await walk(path));
    else found.push(path);
  }
  return found;
}

const allFiles = [];
for (const name of scannedRoots) allFiles.push(...await walk(resolve(root, name)));
// The installers at the top of the tree are deliverable code too, so they get scanned.
for (const name of ['package.json', 'Directory.Packages.props', 'Directory.Build.props', 'Cinerion.slnx', 'global.json', '.env.example', '.dockerignore', 'install.ps1', 'install.sh', 'install.cmd']) {
  allFiles.push(resolve(root, name));
}

const scanned = allFiles
  .map((path) => relative(root, path).replaceAll('\\', '/'))
  .filter((path) => textExtensions.has(extname(path)) || basename(path) === '.env.example' || basename(path) === '.dockerignore')
  .filter((path) => !selfExempt.has(path))
  .sort();

/**
 * Whether a match lands on a line that is not a comment.
 *
 * The same line-based crudeness as `inCode` in scripts/check-local-commit-sequence.mjs,
 * and it is here for item 63's reason running the other way. That gate found a control it
 * had deleted still "present" because a comment two lines up said the word; this one would
 * otherwise refuse a source file for explaining, in a comment, which hosts are refused.
 * A pattern appearing both in a comment and in code is code, which is the direction that
 * matters.
 */
const codeLines = (source) => source
  .split(/\r?\n/)
  .map((line, index) => ({ line, number: index + 1 }))
  .filter(({ line }) => {
    const trimmed = line.trim();
    return trimmed.length > 0
      && !trimmed.startsWith('//')
      && !trimmed.startsWith('*')
      && !trimmed.startsWith('/*')
      && !trimmed.startsWith('#')
      && !trimmed.startsWith('--');
  });

let linesExamined = 0;
const findings = [];

for (const path of scanned) {
  let source;
  try {
    source = await readFile(resolve(root, path), 'utf8');
  } catch {
    continue;
  }
  for (const { line, number } of codeLines(source)) {
    linesExamined += 1;
    for (const host of matchHosts(line)) {
      findings.push({ path, number, klass: 'AI service host', detail: host });
    }
    for (const pattern of matchModels(line)) {
      findings.push({ path, number, klass: 'AI model identifier', detail: String(pattern) });
    }
    for (const name of matchCredentials(line)) {
      findings.push({ path, number, klass: 'AI service credential', detail: name });
    }
    for (const pattern of matchAuthority(line)) {
      findings.push({ path, number, klass: 'AI authority surface', detail: String(pattern) });
    }
  }
}

for (const finding of findings) {
  errors.push(
    `${finding.klass} in the deployable tree: ${finding.path}:${finding.number} names ` +
    `${finding.detail}. CH1-AI-FR-0002 and access.json's "Approve or command via AI | None | ` +
    'Not applicable | Explicitly prohibited" put AI outside every authority path, and ' +
    'CH1-OPS-FR-0001 forbids a public-internet dependency in a principal workflow.');
}

// ---------------------------------------------------------------------------------------
// 4. Dependency manifests, by declared name.
// ---------------------------------------------------------------------------------------

const npmManifests = scanned.filter((path) => basename(path) === 'package.json');
let npmDependenciesExamined = 0;
for (const path of npmManifests) {
  const manifest = JSON.parse(await readFile(resolve(root, path), 'utf8'));
  const declared = [
    ...Object.keys(manifest.dependencies ?? {}),
    ...Object.keys(manifest.devDependencies ?? {}),
    ...Object.keys(manifest.peerDependencies ?? {}),
    ...Object.keys(manifest.optionalDependencies ?? {}),
  ];
  npmDependenciesExamined += declared.length;
  for (const name of declared) {
    if (prohibitedNpmPackages.has(name) || prohibitedNpmScopes.some((scope) => name.startsWith(scope))) {
      errors.push(
        `${path} declares the AI client dependency "${name}". CH1-SWA-ADR-0010 keeps AI outside ` +
        'authentication, approval and command paths, and this platform has no AI component in ' +
        'traceability/system-architecture-r01.json for one to belong to.');
    }
  }
}

const nuGetManifest = await readFile(resolve(root, 'Directory.Packages.props'), 'utf8');
const nuGetPackages = [...nuGetManifest.matchAll(/PackageVersion\s+Include="([^"]+)"/g)].map((match) => match[1]);
for (const name of nuGetPackages) {
  if (prohibitedNuGetPrefixes.some((prefix) => name === prefix || name.startsWith(`${prefix}.`))) {
    errors.push(
      `Directory.Packages.props declares the AI client dependency "${name}". Central package ` +
      'management means one line here reaches every project, so this is the one place it has to be refused.');
  }
}

// Central package management is only a control while it is on: a project that pins its own
// version could take an AI package without appearing above.
if (!/<ManagePackageVersionsCentrally>\s*true\s*<\/ManagePackageVersionsCentrally>/.test(nuGetManifest)) {
  errors.push(
    'Directory.Packages.props no longer manages package versions centrally, so the NuGet check ' +
    'above no longer sees every dependency this solution takes.');
}
const projectFiles = scanned.filter((path) => extname(path) === '.csproj');
for (const path of projectFiles) {
  const project = await readFile(resolve(root, path), 'utf8');
  for (const match of project.matchAll(/PackageReference\s+Include="([^"]+)"[^>]*Version="([^"]+)"/g)) {
    errors.push(
      `${path} pins its own version for "${match[1]}" (${match[2]}), which bypasses the central ` +
      'manifest the AI dependency check reads.');
  }
}

// ---------------------------------------------------------------------------------------
// 5. No AI actor kind, role or component - the absence measured rather than assumed.
// ---------------------------------------------------------------------------------------

/**
 * Whether a PascalCase identifier contains an AI word as a WORD.
 *
 * The first run of this gate refused `MaintenanceEngineer`, twice, because "MaintenAnce"
 * contains the letters a-i. A substring test over identifiers is the same mistake item 63
 * records in a different costume: the pattern matched something that was never the thing
 * being looked for. So the identifier is split on case boundaries and each word compared
 * whole. `AiAssistant` splits to [Ai, Assistant] and is refused; `MaintenanceEngineer`
 * splits to [Maintenance, Engineer] and is not.
 */
const aiWords = new Set(['ai', 'llm', 'assistant', 'copilot', 'agent', 'inference', 'gpt', 'claude', 'gemini', 'chatbot']);
const namesAnAiWord = (identifier) => String(identifier)
  .split(/(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|[^A-Za-z0-9]+/)
  .filter(Boolean)
  .some((word) => aiWords.has(word.toLowerCase()));

const actorContext = await readFile(
  resolve(root, 'services/control-core/src/Cinerion.Domain/Security/ActorContext.cs'), 'utf8');
const actorKinds = [...(actorContext.match(/enum ActorKind\s*\{([^}]*)\}/s)?.[1] ?? '')
  .split(',')
  .map((value) => value.trim())
  .filter(Boolean)];
if (actorKinds.length === 0) {
  errors.push('ActorKind could not be read from ActorContext.cs, so the actor-kind check established nothing.');
}
for (const kind of actorKinds) {
  if (namesAnAiWord(kind)) {
    errors.push(`ActorKind declares "${kind}". An AI actor kind makes the prohibition expressible as a permission.`);
  }
}

const declaredRoles = [...actorContext.matchAll(/public const string (\w+) = "([^"]+)";/g)].map((match) => match[2]);
if (declaredRoles.length === 0) {
  errors.push('No role constants could be read from ActorContext.cs, so the role check established nothing.');
}
for (const role of declaredRoles) {
  if (namesAnAiWord(role)) {
    errors.push(`CinerionRoles declares "${role}", which reads as an AI authority. access.json gives it role "None".`);
  }
}

const realm = JSON.parse(await readFile(resolve(root, 'infrastructure/keycloak/cinerion-realm.json'), 'utf8'));
const realmRoles = (realm.roles?.realm ?? []).map((role) => role.name);
for (const role of realmRoles) {
  if (namesAnAiWord(role)) {
    errors.push(`The controlled realm declares the role "${role}", which reads as an AI authority.`);
  }
}
const realmClients = (realm.clients ?? []).map((client) => client.clientId);
for (const clientId of realmClients) {
  if (/(^|[-_])(ai|llm|assistant|copilot|agent)([-_]|$)/i.test(clientId)) {
    errors.push(`The controlled realm declares the client "${clientId}", which reads as an AI service identity.`);
  }
}

// The controlled architecture diagram draws fourteen components and the Engineering
// Assistant is not one of them - which is the topology half of CH1-SWA-ADR-0010. Measured,
// because "the diagram has no AI box" is exactly the kind of claim item 45 says to re-test.
const architecture = JSON.parse(await readFile(resolve(root, 'traceability/system-architecture-r01.json'), 'utf8'));
const components = architecture.components ?? [];
if (components.length === 0) {
  errors.push('No components could be read from the architecture register, so the component check established nothing.');
}
for (const component of components) {
  const label = String(component.label ?? component.name ?? '');
  if (namesAnAiWord(label)) {
    errors.push(
      `The controlled architecture register declares the component "${label}". CH1-AI-FR-0001 and ` +
      'CH1-AI-FR-0002 are allocated to an "Engineering Assistant" that the controlled architecture ' +
      'diagram does not draw; a component appearing here is an architecture change.');
  }
}

// ---------------------------------------------------------------------------------------
// 6. Agent and editor tooling does not belong in a controlled deliverable.
//
// Not an AI API, and refused for a narrower reason: scripts/package-release.sh copies the
// tree into the release archive, and MANIFEST.sha256 recorded that
// apps/operator-portal/.claude/settings.json and apps/operator-portal/AGENTS.md were
// inside it. Editor plugin enablement and instructions addressed to a coding agent are
// development tooling; shipping them inside a confidential controlled release states
// something about how the deliverable was produced that the AI usage register
// (CH1-PMG-AIU-0001..0008) is the controlled place to state. The root AGENTS.md lives one
// directory ABOVE the working copy for exactly this reason.
// ---------------------------------------------------------------------------------------

const toolingArtefacts = allFiles
  .map((path) => relative(root, path).replaceAll('\\', '/'))
  .filter((path) => /(^|\/)\.claude\//.test(path)
    || /(^|\/)\.cursor\//.test(path)
    || /(^|\/)\.aider/.test(path)
    || /(^|\/)AGENTS\.md$/.test(path)
    || /(^|\/)CLAUDE\.md$/.test(path)
    || /(^|\/)\.mcp\.json$/.test(path));
for (const path of toolingArtefacts) {
  errors.push(
    `Agent or editor tooling inside the deployable tree: ${path}. scripts/package-release.sh ` +
    'copies this into the release archive. Keep it outside the working copy, as the root ' +
    'AGENTS.md is, or gitignore and exclude it from packaging.');
}

// And the exclusion has to be real, not just currently true.
const packaging = await readFile(resolve(root, 'scripts/package-release.sh'), 'utf8');
for (const pattern of ['.claude', 'AGENTS.md']) {
  if (!packaging.includes(pattern)) {
    errors.push(
      `scripts/package-release.sh does not exclude "${pattern}", so agent tooling would be packaged ` +
      'again the moment somebody added it back.');
  }
}

// ---------------------------------------------------------------------------------------
// Result.
// ---------------------------------------------------------------------------------------

if (errors.length > 0) {
  for (const error of errors) console.error(`FAIL  ${error}`);
  console.error(`\nAI authority prohibition: ${errors.length} refusal(s).`);
  process.exit(1);
}

console.log(
  `Positive control: ${controlsFired} of ${positiveControls.length} matcher classes fired on a buffer ` +
  'that contains what they refuse, so the absence reported below is a measurement rather than a silence.');
console.log(
  `AI authority prohibition held over ${scanned.length} files and ${linesExamined} non-comment lines: ` +
  `no AI service host (${prohibitedHosts.length} refused), no model identifier ` +
  `(${prohibitedModelPatterns.length} patterns), no service credential (${prohibitedCredentials.length} names), ` +
  `and no authority surface (${prohibitedAuthorityPatterns.length} patterns).`);
console.log(
  `Dependencies: ${npmDependenciesExamined} npm dependencies across ${npmManifests.length} manifests and ` +
  `${nuGetPackages.length} centrally managed NuGet packages, none of them an AI client. ` +
  `${projectFiles.length} project files take no version of their own, so the central manifest is the whole list.`);
console.log(
  `Authority: ${actorKinds.length} actor kinds (${actorKinds.join(', ')}), ${declaredRoles.length} role ` +
  `constants, ${realmRoles.length} realm roles and ${components.length} controlled architecture components, ` +
  'and none of them is an AI, an assistant or an inference service. access.json gives ' +
  '"Approve or command via AI" the role None at strength Not applicable, explicitly prohibited, and ' +
  'CH1-SWA-ADR-0010 is Accepted.');
console.log(
  'NOT ESTABLISHED by this gate: that no AI service is reachable at runtime from a deployed system. ' +
  'This is a static gate over the tree. The behavioural half is scripts/check-offline-workflow.sh, ' +
  'which runs the controlled demonstration on a network proven to have no route out.');
for (const note of notes) console.log(`NOTE  ${note}`);

// Controlled verification case this gate is offered as evidence for. Printed only after
// every check above has held, and read from an actual run by scripts/check-verification.mjs,
// so the binding cannot outlive the check.
//   0066 - AI has no command, approval or release permission: no client, no host, no model,
//          no credential, no actor kind, no role, no realm identity and no architecture
//          component, measured over the deployable tree with the matchers proven live.
console.log('VERIFICATION-CASE CH1-VVT-TC-0066');
