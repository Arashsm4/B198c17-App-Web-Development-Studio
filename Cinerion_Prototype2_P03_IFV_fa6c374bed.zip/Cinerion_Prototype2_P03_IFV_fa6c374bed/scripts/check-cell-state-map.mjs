// Reconciles every implementation of the cell state machine against the CONTROLLED
// state diagram.
//
// CH1-AUT-FDS-0001 names the states — "Off/Isolated, Initialising, Idle, Prepared,
// AwaitCredential, AwaitButton, Executing, Complete, FaultLatched, Maintenance and
// Recovery" — and then refers the transitions to `assets/cell-state-machine.png`. This
// repository was reading that as an image, and a previous session recorded the
// consequence as conflict 30: `Complete` had no transition back to `Idle`, so a
// controller accepted one procedure per boot, and the exit could not be "read from the
// controlled sources with confidence".
//
// It can. The frozen baseline carries `assets/cell-state-machine.svg` beside the PNG, and
// an SVG is a transition table with coordinates: six state boxes on one column, two more
// beside them, and ten paths whose endpoints land exactly on a box edge, each followed by
// its own label. This gate parses that geometry and refuses to guess — an endpoint that
// does not resolve to exactly one box is an error, not a nearest match — so the diagram
// becomes an authority the build checks rather than a picture a reader interprets.
//
// Two implementations realise parts of that machine: the MCU command state machine the
// ESP32-S3 runs, and the S7-1200 CommandGuard. Neither covers all of it and neither
// should; what matters is that what each one covers agrees with the controlled diagram.
// So this fails when
//
//   * the controlled diagram no longer parses into states and transitions, or an
//     endpoint resolves to no box or to more than one;
//   * a controlled state an implementation claims to cover is mapped to nothing, or to a
//     state name that implementation does not actually define;
//   * an implementation defines a state that is neither a controlled state nor declared
//     as a refinement with a stated reason;
//   * a controlled transition between two states an implementation covers is not
//     implemented, or is implemented by a routine that does not exist in its source;
//   * the map declares a transition the controlled diagram does not contain — which is
//     the direction that matters, because it is how an invented transition into a
//     safety-relevant state machine would arrive;
//   * or a declared refinement names a controlled transition that does not exist.
//
// What it does NOT do, stated because the omission matters. It cannot see an implementation
// transition the map does not declare: it reads the map's claims and the diagram's
// geometry, and it does not parse C++ or SCL control flow to discover what a routine
// actually assigns. So a transition added to the firmware and left undeclared is invisible
// here, and is caught — if at all — by the host tests and the cell simulation. What this
// gate does hold is the other three directions, which are the ones a drifting map takes:
// a controlled transition that stops being implemented, a declared one the diagram does not
// contain, and a covered state the body cannot reach.
//
// It announces no controlled verification case of its own. `data/tests.json` binds the
// cell state machine's BEHAVIOUR to CH1-VVT-TC-0011..0019 and those are announced by the
// host tests that exercise it; this gate checks a different thing — that the implemented
// machine is the controlled one — and binding it to a behavioural case would be the
// overstatement the verification map exists to prevent. Same shape as conflicts 18, 20,
// 26 and 28, and recorded as conflict 31.

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const diagramPath = 'docs/baseline/P03_IFV/assets/cell-state-machine.svg';
const mapPath = 'firmware/statemap/cell-state-machine-r01.json';

const svg = await readFile(resolve(root, diagramPath), 'utf8');
const map = JSON.parse(await readFile(resolve(root, mapPath), 'utf8'));

// -- 1. The controlled diagram, parsed. --------------------------------------------------
//
// Boxes first: every <rect> that carries a width and height, in document order. Then the
// state labels: a <text class="state"> whose anchor point falls inside exactly one box
// names that box. A label that falls in none, or in two, is an error — the alternative is
// a gate that silently names a state after the wrong rectangle.

const boxes = [...svg.matchAll(/<rect\b([^>]*)\/>/g)]
  .map((match) => match[1])
  .map((attributes) => ({
    x: number(attributes, 'x'),
    y: number(attributes, 'y'),
    width: number(attributes, 'width'),
    height: number(attributes, 'height'),
  }))
  .filter((box) => box.width !== null && box.height !== null && box.x !== null && box.y !== null)
  // The page background is a <rect> too, and it has no x or y. Anything the size of the
  // canvas is not a state.
  .filter((box) => box.width < 600);

function number(attributes, name) {
  const match = attributes.match(new RegExp(`\\b${name}="(-?[\\d.]+)"`));
  return match ? Number(match[1]) : null;
}

// A point is on a box when it is inside it or on its boundary. Every endpoint in the
// controlled diagram sits exactly on an edge, so no tolerance is needed and none is
// given: a diagram revision that moved a path off its box would refuse here rather than
// be rounded onto the nearest one.
const contains = (box, x, y) =>
  x >= box.x && x <= box.x + box.width && y >= box.y && y <= box.y + box.height;

const stateOfBox = new Map();
for (const [, attributes, name] of svg.matchAll(/<text\b([^>]*class="state"[^>]*)>([^<]+)<\/text>/g)) {
  const x = number(attributes, 'x');
  const y = number(attributes, 'y');
  const hits = boxes.filter((box) => contains(box, x, y));
  if (hits.length !== 1) {
    errors.push(
      `${diagramPath}: the state label "${name}" at (${x},${y}) falls inside ${hits.length} boxes. ` +
      'A label that names no box, or two, cannot be read as a state.');
    continue;
  }
  stateOfBox.set(hits[0], name.trim());
}

const controlledStates = new Set(stateOfBox.values());
if (controlledStates.size === 0) {
  errors.push(`${diagramPath}: no states were parsed; this check would pass over nothing.`);
}

// Transitions: each <path> carries its geometry in `d`, and its label is the next
// <text class="label"> in document order. Six of the ten are written on the same line as
// their path and four are not, so document order is the association rather than the line.

const elements = [...svg.matchAll(/<(path|text)\b([^>]*?)(?:\/>|>([^<]*)<\/text>)/g)].map((match) => ({
  tag: match[1],
  attributes: match[2],
  text: (match[3] ?? '').trim(),
}));

const transitions = [];
for (let index = 0; index < elements.length; index += 1) {
  const element = elements[index];
  if (element.tag !== 'path') continue;
  const d = element.attributes.match(/\bd="([^"]+)"/)?.[1];
  // The marker definitions are <path> too, and they carry no `d` beginning with M x y.
  if (!d || !element.attributes.includes('class=')) continue;

  const points = [...d.matchAll(/-?[\d.]+/g)].map((value) => Number(value[0]));
  if (points.length < 4 || points.length % 2 !== 0) {
    errors.push(`${diagramPath}: the path "${d}" does not carry an even list of coordinates.`);
    continue;
  }
  const start = { x: points[0], y: points[1] };
  const end = { x: points[points.length - 2], y: points[points.length - 1] };

  const resolvePoint = (point, which) => {
    const hits = boxes.filter((box) => contains(box, point.x, point.y));
    if (hits.length !== 1) {
      errors.push(
        `${diagramPath}: the ${which} of path "${d}" at (${point.x},${point.y}) touches ` +
        `${hits.length} state boxes. An endpoint that resolves to no state, or to two, is ` +
        'not a transition this gate will guess at.');
      return null;
    }
    return stateOfBox.get(hits[0]) ?? null;
  };

  const from = resolvePoint(start, 'start');
  const to = resolvePoint(end, 'end');

  const label = elements
    .slice(index + 1)
    .find((candidate) => candidate.tag === 'text' && candidate.attributes.includes('class="label"'));
  if (!label) {
    errors.push(`${diagramPath}: the path "${d}" has no label after it, so its event is unnamed.`);
    continue;
  }
  if (from && to) {
    transitions.push({ from, to, label: label.text });
  }
}

if (transitions.length === 0) {
  errors.push(`${diagramPath}: no transitions were parsed; this check would pass over nothing.`);
}

const transitionKey = (transition) => `${transition.from} --${transition.label}--> ${transition.to}`;
const controlledTransitions = new Map(transitions.map((transition) => [transitionKey(transition), transition]));

// -- 2. Each implementation, against it. -------------------------------------------------

const sources = new Map();
async function sourceOf(path) {
  if (!sources.has(path)) {
    sources.set(path, await readFile(resolve(root, path), 'utf8').catch(() => null));
  }
  return sources.get(path);
}

for (const implementation of map.implementations ?? []) {
  const label = `${mapPath}: ${implementation.id}`;
  const source = await sourceOf(implementation.source);
  const stateSource = await sourceOf(implementation.stateSource);
  if (source === null) {
    errors.push(`${label} names ${implementation.source}, which does not exist.`);
    continue;
  }
  if (stateSource === null) {
    errors.push(`${label} names ${implementation.stateSource}, which does not exist.`);
    continue;
  }

  // The states this implementation actually defines, read from its own source rather
  // than from the map — a map that could name its own states would be reconciling
  // against itself. The block is extracted first so that a second enumeration in the
  // same file cannot contribute names to this one.
  const block = stateSource.match(new RegExp(implementation.stateBlockPattern));
  if (!block) {
    errors.push(
      `${label}: ${implementation.stateSource} no longer contains the declared state block, so ` +
      'this implementation would be reconciled against nothing.');
    continue;
  }
  const defined = new Set(
    [...block[1].matchAll(new RegExp(implementation.stateNamePattern, 'g'))].map((match) => match[1].trim()));
  if (defined.size === 0) {
    errors.push(
      `${label}: no states were parsed from ${implementation.stateSource} with the declared pattern, ` +
      'so this implementation would be reconciled against nothing.');
    continue;
  }

  const covers = new Set(implementation.covers ?? []);
  for (const state of covers) {
    if (!controlledStates.has(state)) {
      errors.push(`${label} claims to cover "${state}", which the controlled diagram does not contain.`);
    }
  }

  // Every controlled state it covers must map to a state it defines, or be declared a
  // refinement of one with a reason.
  const mapped = new Map();
  for (const state of covers) {
    const entry = implementation.states?.[state];
    if (entry === undefined) {
      errors.push(
        `${label} covers the controlled state "${state}" and maps it to nothing. ` +
        'A covered state with no implementation state is a gap, not a mapping.');
      continue;
    }
    if (typeof entry === 'string') {
      if (!defined.has(entry)) {
        errors.push(
          `${label} maps the controlled state "${state}" to "${entry}", which ` +
          `${implementation.stateSource} does not define.`);
      }
      mapped.set(entry, state);
      continue;
    }
    // A refinement: the controlled state is subsumed by another, with a stated reason.
    if (!entry.subsumedBy || !defined.has(entry.subsumedBy)) {
      errors.push(
        `${label} declares "${state}" subsumed by "${entry.subsumedBy}", which ` +
        `${implementation.stateSource} does not define.`);
    }
    if (!entry.reason || entry.reason.length < 40) {
      errors.push(
        `${label} declares "${state}" a refinement with no stated reason. A controlled state an ` +
        'implementation does not realise needs an argument, not an omission.');
    }
  }

  // Every state it defines must be a controlled state it covers, or a declared extension
  // with a reason. This is the direction that catches a state somebody added.
  for (const state of defined) {
    if (mapped.has(state)) continue;
    const extension = implementation.extraStates?.[state];
    if (!extension) {
      errors.push(
        `${label}: ${implementation.stateSource} defines the state "${state}", which is neither a ` +
        'controlled state nor a declared extension. A state the controlled diagram does not ' +
        'contain needs a stated reason before it exists.');
      continue;
    }
    if (!extension.reason || extension.reason.length < 40) {
      errors.push(`${label} declares the extra state "${state}" with no stated reason.`);
    }
    if (extension.refines && !controlledTransitions.has(extension.refines)) {
      errors.push(
        `${label} says the extra state "${state}" refines "${extension.refines}", which is not a ` +
        'transition in the controlled diagram.');
    }
  }

  // A covered state has to be REACHABLE, not merely declared. FB_CH1_CommandGuard
  // enumerated Complete and FaultLatched on its State output for two revisions while the
  // body assigned neither, and check-plc-model.mjs carried an explicit exemption for both
  // — so the two states this gate exists to check were the two nothing checked. The map
  // names the assignment for each covered state and this looks for it.
  for (const state of covers) {
    const assignment = implementation.reachability?.[state];
    if (assignment === undefined) {
      errors.push(
        `${label} covers "${state}" and declares no assignment for it, so nothing establishes ` +
        'that the implementation can reach it.');
      continue;
    }
    if (!source.includes(assignment)) {
      errors.push(
        `${label} covers "${state}" and ${implementation.source} never assigns it ` +
        `("${assignment}" does not appear). A documented state the body cannot reach is a ` +
        'state machine that does not exist.');
    }
  }

  // Every controlled transition between two covered states must be implemented, and by
  // something that exists.
  const declared = new Map(
    (implementation.transitions ?? []).map((entry) => [`${entry.from} --${entry.label}--> ${entry.to}`, entry]));

  for (const [key, transition] of controlledTransitions) {
    if (!covers.has(transition.from) || !covers.has(transition.to)) continue;
    const entry = declared.get(key);
    if (!entry) {
      errors.push(
        `${label} does not implement the controlled transition ${key}. Both states are covered, so ` +
        'the diagram requires this transition to exist.');
      continue;
    }
    const routines = entry.routines ?? [];
    if (routines.length === 0) {
      errors.push(`${label} declares ${key} with no routine performing it.`);
    }
    for (const routine of routines) {
      if (!new RegExp(`\\b${routine.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(source)) {
        errors.push(
          `${label} says ${key} is performed by "${routine}", which does not appear in ` +
          `${implementation.source}.`);
      }
    }
  }

  // And nothing may be declared that the diagram does not contain.
  for (const key of declared.keys()) {
    if (!controlledTransitions.has(key)) {
      errors.push(
        `${label} declares the transition ${key}, which the controlled diagram does not contain. ` +
        'A transition added to a safety-relevant state machine has to come from the controlled ' +
        'source, not from this map.');
    }
  }
}

// ----------------------------------------------------------------------------------------

if (errors.length > 0) {
  console.error('Controlled cell state machine check failed:');
  for (const error of errors) console.error(`  FAIL ${error}`);
  process.exit(1);
}

const covered = (map.implementations ?? []).map(
  (implementation) =>
    `${implementation.id} covers ${implementation.covers.length} of ${controlledStates.size}`);
console.log(
  `Cell state machine reconciled against ${diagramPath}: ${controlledStates.size} controlled states, ` +
  `${controlledTransitions.size} controlled transitions, ${map.implementations.length} implementations ` +
  `(${covered.join('; ')}).`);
for (const key of controlledTransitions.keys()) {
  console.log(`  controlled transition: ${key}`);
}
