// Reconciles the operator portal's TypeScript contracts with what the service actually
// sends, using responses captured by a real request rather than written by hand.
//
// The contracts in apps/operator-portal/src/api/contracts.ts are the portal's statement
// of every response shape it reads, and nothing checked them against the service. A
// property named wrongly there typechecks perfectly and renders undefined at runtime.
// That is not hypothetical: it happened twice while the work-order and device screens
// were written, most recently an alarm field declared as "code" that the service sends
// as "alarmCode". Both were caught by comparing against a running service by hand, which
// is exactly the sort of check that should not depend on somebody remembering to do it.
//
// PortalContractFixtureTests writes artifacts/contracts/<Interface>.json by issuing a
// real request through the test host. This reads those and the declaration, and fails
// when a declared property is absent from the response the service actually sent.
//
// Nested shapes are compared too, and deliberately so: the defect that prompted this gate
// was inside an inline object type, so a check that only compared top-level properties
// would have passed over the very thing it exists to catch.
//
// The reverse direction is reported, not failed: CH1-SWA-API-0001 makes unknown optional
// fields safe to ignore, so a response key the portal has not declared is a field it
// chooses not to read, which is a decision rather than a defect.

import { readdir, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const contractsPath = 'apps/operator-portal/src/api/contracts.ts';
const fixtureDirectory = 'artifacts/contracts';
const errors = [];
const notes = [];
const strict = process.argv.includes('--strict') || process.env.CI === 'true';

// -- 1. The declaration. ------------------------------------------------------------

/** Consumes a balanced brace span starting at the opening brace. */
function spanFrom(text, openIndex) {
  let depth = 0;
  let index = openIndex;
  do {
    if (text[index] === '{') depth++;
    else if (text[index] === '}') depth--;
    index++;
  } while (depth > 0 && index < text.length);
  return { body: text.slice(openIndex + 1, index - 1), end: index };
}

/**
 * Properties declared directly in one interface body, each with the nested shape of an
 * inline object type where it has one.
 */
function parseProperties(body) {
  const properties = [];
  const pattern = /readonly\s+(\w+)(\?)?\s*:/g;
  let match;
  while ((match = pattern.exec(body)) !== null) {
    const [, name, optional] = match;
    let children = [];
    let references = [];

    // Look ahead to the end of this member. An inline object type opens a brace before
    // the member's terminating semicolon.
    const rest = body.slice(match.index + match[0].length);
    const brace = rest.indexOf('{');
    const semicolon = rest.indexOf(';');
    if (brace >= 0 && (semicolon < 0 || brace < semicolon)) {
      // An intersection such as `DeviceRecord & { … }` declares the named interface's
      // properties as well as the inline ones. Without resolving it the inline half
      // looks complete and every inherited property is reported as unread, which would
      // make this gate's output actively misleading.
      references = [...rest.slice(0, brace).matchAll(/[A-Z]\w+/g)].map((item) => item[0]);
      const nested = spanFrom(rest, brace);
      children = parseProperties(nested.body);
      // Skip the nested block so its members are not read as this interface's own.
      pattern.lastIndex = match.index + match[0].length + nested.end;
    }

    properties.push({ name, optional: optional === '?', children, references });
  }

  return properties;
}

const source = await readFile(resolve(root, contractsPath), 'utf8');
const interfaces = new Map();

for (const match of source.matchAll(/export interface (\w+)(?:\s+extends\s+([\w,\s]+?))?\s*\{/g)) {
  const [, name, extendsList] = match;
  const { body } = spanFrom(source, match.index + match[0].length - 1);
  interfaces.set(name, {
    properties: parseProperties(body),
    extends: (extendsList ?? '').split(',').map((item) => item.trim()).filter(Boolean),
  });
}

if (interfaces.size === 0) {
  errors.push(`No interfaces parsed from ${contractsPath}; this check would otherwise pass over nothing.`);
}

function declaredProperties(name, seen = new Set()) {
  if (seen.has(name)) return [];
  seen.add(name);
  const declaration = interfaces.get(name);
  if (!declaration) return [];
  return [
    ...declaration.extends.flatMap((parent) => declaredProperties(parent, seen)),
    ...declaration.properties,
  ];
}

// -- 2. What the service actually sent. ---------------------------------------------

/** Compares one declared shape against one captured value, at any depth. */
function compare(path, declared, value) {
  if (value === null || typeof value !== 'object') return;

  // An inline object type inside an array — `readonly allowCredentials: readonly { … }[]`
  // — describes the element, not the array. Comparing the array itself would pass over
  // every property the elements declare, which is the same blind spot nesting was added
  // to close one level up.
  if (Array.isArray(value)) {
    if (value.length > 0) compare(`${path}[0]`, declared, value[0]);
    return;
  }

  const keys = new Set(Object.keys(value));

  for (const property of declared) {
    if (!keys.has(property.name)) {
      if (!property.optional) {
        errors.push(
          `${path}.${property.name} is declared by the portal but absent from the response the ` +
          'service sent. A screen reading it renders undefined.');
      }

      continue;
    }

    const nested = [
      ...property.children,
      ...(property.references ?? []).flatMap((reference) => declaredProperties(reference)),
    ];
    if (nested.length > 0) {
      compare(`${path}.${property.name}`, nested, value[property.name]);
    }
  }

  const extras = [...keys].filter((key) => !declared.some((item) => item.name === key));
  if (extras.length > 0) notes.push(`  ${path} does not read: ${extras.join(', ')}`);
}

let fixtures = [];
try {
  fixtures = (await readdir(resolve(root, fixtureDirectory))).filter((name) => name.endsWith('.json'));
} catch {
  const message =
    `No captured responses in ${fixtureDirectory}. They are written by PortalContractFixtureTests, ` +
    'so run the .NET tests first.';
  if (strict) {
    errors.push(`${message} CI treats this step as mandatory; a skipped comparison is not a passed one.`);
  } else {
    console.log(`SKIPPED locally: ${message} CI treats this as mandatory.`);
  }
}

for (const file of fixtures) {
  const name = file.replace(/\.json$/, '');
  if (!interfaces.has(name)) {
    errors.push(`${fixtureDirectory}/${file} was captured for "${name}", which ${contractsPath} does not declare.`);
    continue;
  }

  const captured = JSON.parse(await readFile(resolve(root, fixtureDirectory, file), 'utf8'));
  if (captured === null || typeof captured !== 'object' || Array.isArray(captured)) {
    // A comparison can only read properties off an object, so a null or an array here
    // would be compared against nothing and reported as reconciled.
    errors.push(
      `${fixtureDirectory}/${file} is not a JSON object, so nothing about ${name} can be compared against it.`);
    continue;
  }

  compare(name, declaredProperties(name), captured);
}

// -- 3. Every declared shape must have one. ------------------------------------------
//
// A shape with no captured response is compared against nothing, which is indistinguish-
// able from a shape that matched. Once the fixtures exist at all, a declared interface
// without one is therefore a failure rather than a note — so a new portal contract
// arrives with evidence about the service, or it does not arrive.
//
// The single exemption is declared in the contract source itself, next to the interface
// it applies to, so this script and PortalContractFixtureTests read one statement rather
// than keeping two lists in step.

const exempt = new Set(
  [...source.matchAll(/@noCapturedResponse[\s\S]*?\*\/\s*export interface (\w+)/g)].map((item) => item[1]));

for (const name of exempt) {
  if (!interfaces.has(name)) {
    errors.push(`"${name}" is marked @noCapturedResponse but ${contractsPath} declares no such interface.`);
  }
}

const uncovered = [...interfaces.keys()]
  .filter((name) => !exempt.has(name) && !fixtures.includes(`${name}.json`))
  .sort();

if (fixtures.length > 0 && uncovered.length > 0) {
  errors.push(
    `Declared by the portal with no captured response: ${uncovered.join(', ')}. ` +
    'They are captured by PortalContractFixtureTests; a shape nothing captured is compared against nothing.');
}

// -- 4. Report. ----------------------------------------------------------------------

// -- Every response shape the portal reads must be declared HERE, not on a screen. ------
//
// Four were not, and nothing noticed: `AuditPage` and `ChainVerification` in audit.tsx,
// `DirectoryPage` and `DirectoryUser` in security.tsx. A shape declared inside a route
// file typechecks perfectly and renders `undefined` at runtime exactly as one declared
// here would — but this gate only reads contracts.ts, so those four were never compared
// against anything the service sent. That is the same failure this gate exists to remove,
// one level up: a declaration nobody reconciles wearing the same clothes as one that is.
//
// So the type argument of every `useObserved<T>` and `useControlledAction<T>` in the route
// sources has to name a shape contracts.ts exports.
const routeDirectory = 'apps/operator-portal/src/app';
const READ_TYPE = /use(?:Observed|ControlledAction)<\s*([^>]+?)\s*>/g;

for (const file of (await readdir(resolve(root, routeDirectory))).filter((n) => n.endsWith('.tsx'))) {
  const routeSource = await readFile(resolve(root, routeDirectory, file), 'utf8');
  for (const [, rawType] of routeSource.matchAll(READ_TYPE)) {
    // `readonly X[]`, `X | undefined` and `unknown` all reduce to the shape being read.
    const named = rawType.replace(/readonly\s+/g, '').replace(/\[\]/g, '').trim();
    if (named === 'unknown' || named === 'never') continue;
    for (const part of named.split('|').map((item) => item.trim()).filter(Boolean)) {
      if (part === 'undefined' || part === 'null' || /^[a-z]/.test(part)) continue;
      // Two ways to be wrong, and the second is the one that slipped through when this
      // check was first written: a name contracts.ts does not export at all, and a name it
      // does export that the route shadows with a local declaration of its own. The second
      // typechecks, renders identically, and is reconciled against nothing.
      if (!interfaces.has(part)) {
        errors.push(
          `${routeDirectory}/${file} reads a response as ${part}, which ${contractsPath} does not export. ` +
          'A shape declared on a screen is never compared against a captured response, so a property ' +
          'named wrongly there would typecheck and render undefined exactly as it did before this gate existed.');
      } else if (new RegExp(String.raw`\binterface\s+` + part + String.raw`\b`).test(routeSource)) {
        errors.push(
          `${routeDirectory}/${file} declares its own interface ${part} and reads a response as it, ` +
          `shadowing the one ${contractsPath} exports. The local declaration is what the screen ` +
          'actually reads and nothing reconciles it against a captured response.');
      }
    }
  }
}

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(
    `Portal contracts reconciled: ${fixtures.length} of ${interfaces.size - exempt.size} declared shapes compared ` +
    'against a response the service actually sent, nested shapes and array elements included.');
  for (const note of notes) console.log(note);
  console.log(
    exempt.size === 0
      ? 'No shape is exempt from capture.'
      : `Exempt, with the reason stated in ${contractsPath}: ${[...exempt].join(', ')}`);
}
