// Builds the implementation map from the requirements and what the code says it implements.

import { readFile, writeFile } from 'node:fs/promises';
import { dirname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const requirementsPath = resolve(root, 'docs/baseline/P03_IFV/data/requirements.json');
const outputPath = resolve(root, 'traceability/implementation-map.json');
const requirements = JSON.parse(await readFile(requirementsPath, 'utf8'));

const evidenceByDomain = {
  AI: ['SECURITY.md', 'docs/implementation/DEVELOPMENT_GATES.md'],
  CMD: [
    'simulators/state-model/src/model.ts',
    'simulators/state-model/test/command-machine.test.ts',
    'firmware/shared/src/cell_state_machine.cpp',
    'firmware/tests/cell_state_machine_test.cpp',
    'services/control-core/src/Cinerion.Domain/Commands/CommandTransaction.cs',
  ],
  // CH1-COL-FR-0003 is the separation of a communication acknowledgement from any
  // control action, and both sides of it now exist: the alarm that cannot be cleared by
  // an acknowledgement, and the message receipt that cannot reach an alarm. The schema
  // itself carries the guarantee - context_messages.control_authority and
  // message_acknowledgements.acknowledgement_kind are both CHECK-constrained.
  COL: [
    'packages/contracts/openapi/openapi.generated.yaml',
    // CH1-UXD-DSG-0001 requires the alarm/message distinction to hold in the interface
    // as well as the API. semantics.ts holds both vocabularies and carries a
    // compile-time guard that fails the portal gate if any verb, mark or shape
    // collides, so the separation cannot be lost by an inattentive edit.
    'apps/operator-portal/src/constants/semantics.ts',
    'apps/operator-portal/src/app/collaboration.tsx',
    'services/control-core/src/Cinerion.Domain/Collaboration/ContextRecords.cs',
    'services/control-core/src/Cinerion.Application/Collaboration/ContextBridgeService.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/ContextBridgeEndpoints.cs',
    'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0004_message_acknowledgements.sql',
    'services/control-core/src/Cinerion.Domain/Monitoring/AlarmRecords.cs',
    'services/control-core/src/Cinerion.Application/Monitoring/MonitoringService.cs',
    'services/control-core/tests/Cinerion.Domain.Tests/AlarmTests.cs',
    'services/control-core/tests/Cinerion.Api.Tests/MonitoringEndpointTests.cs',
    'services/control-core/tests/Cinerion.Api.Tests/ContextBridgeEndpointTests.cs',
  ],
  COM: [
    'packages/contracts/src/index.ts',
    'packages/contracts/schemas/ch1-message-envelope.schema.json',
    'services/edge-link/src/Cinerion.EdgeLink/Protocols/IProtocolAdapter.cs',
    'services/edge-link/src/Cinerion.EdgeLink/Protocols/SimulatorProtocolAdapter.cs',
  ],
  // Device PKI is where CH1-CYB-FR-0002 and CH1-CYB-FR-0003 stop being architecture
  // and become code: the platform derives the thumbprint itself, checks key strength,
  // and refuses submitted private key material outright.
  CYB: [
    'SECURITY.md',
    'infrastructure/compose.yaml',
    'infrastructure/keycloak/cinerion-realm.json',
    '.github/workflows/ci.yml',
    'services/control-core/src/Cinerion.Domain/Assets/DeviceEnrolment.cs',
    'services/control-core/src/Cinerion.Application/Assets/DevicePkiService.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/DevicePkiEndpoints.cs',
    'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0007_device_enrolment.sql',
    'services/control-core/tests/Cinerion.Domain.Tests/DeviceCertificateTests.cs',
    'services/control-core/tests/Cinerion.Api.Tests/DevicePkiEndpointTests.cs',
  ],
  DOC: ['docs/baseline/P03_IFV/SHA256SUMS.txt', 'SECURITY.md'],
  IAM: [
    'infrastructure/keycloak/cinerion-realm.json',
    'services/control-core/src/Cinerion.Api/Program.cs',
    'services/control-core/src/Cinerion.Api/Security/ActorContextFactory.cs',
    'services/control-core/src/Cinerion.Domain/Security/StepUp.cs',
    'services/control-core/src/Cinerion.Application/Security/StepUpService.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/AuthenticationEndpoints.cs',
    'services/control-core/tests/Cinerion.Domain.Tests/StepUpTests.cs',
    'services/control-core/tests/Cinerion.Api.Tests/StepUpEndpointTests.cs',
    // User administration and session revocation. The segregation rules are the
    // substantive evidence for CH1-IAM-FR-0008 and the "no security-policy authority"
    // control, and the Keycloak service account is granted no more than they assume.
    'services/control-core/src/Cinerion.Domain/Identity/IdentityRecords.cs',
    'services/control-core/src/Cinerion.Application/Identity/IdentityAdministrationService.cs',
    'services/control-core/src/Cinerion.Infrastructure/Identity/KeycloakIdentityDirectory.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/IdentityAdministrationEndpoints.cs',
    'services/control-core/tests/Cinerion.Domain.Tests/RoleSegregationTests.cs',
    'services/control-core/tests/Cinerion.Api.Tests/IdentityAdministrationEndpointTests.cs',
  ],
  MFG: ['services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0001_ch1_foundation.sql', 'services/control-core/src/Cinerion.Infrastructure/Seed/PrototypeSeed.cs', 'apps/operator-portal/src/app/quality.tsx'],
  // CH1-MGT-FR-0004 is capacity, reservation and conflict state. The ledger that
  // computes it is kept free of storage and transport so it can be reasoned about and
  // tested on its own.
  MGT: [
    'packages/contracts/openapi/openapi.generated.yaml',
    'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0001_ch1_foundation.sql',
    'apps/operator-portal/src/app/assets.tsx',
    // CH1-MGT-FR-0004 requires conflict state to be exposed, not merely prevented. The
    // board renders committed peak, free-at-peak and every over-committed interval.
    'apps/operator-portal/src/app/resources.tsx',
    'services/control-core/src/Cinerion.Domain/Resources/ResourceRecords.cs',
    'services/control-core/src/Cinerion.Application/Resources/ResourceOrchestratorService.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/ResourceEndpoints.cs',
    'services/control-core/tests/Cinerion.Domain.Tests/CapacityLedgerTests.cs',
    'services/control-core/tests/Cinerion.Api.Tests/ResourceEndpointTests.cs',
  ],
  // Freshness resolution and its presentation are the substantive evidence for
  // CH1-MON-FR-0003: client observation may only downgrade the server's declared
  // freshness, and each state carries its own word and glyph rather than a colour.
  MON: [
    'apps/operator-portal/src/app/index.tsx',
    // The operational view CH1-MON-FR-0001 and CH1-MON-FR-0002 describe: bounded
    // telemetry against its channel allowlist, and alarms whose acknowledgement state
    // and cause state are rendered as two separate facts.
    'apps/operator-portal/src/app/control-room.tsx',
    'apps/operator-portal/src/api/freshness.ts',
    'apps/operator-portal/src/api/use-observed.ts',
    'apps/operator-portal/src/api/use-controlled-action.ts',
    'apps/operator-portal/src/components/session-gate.tsx',
    'apps/operator-portal/src/components/capability.tsx',
    // Server side: the telemetry and alarm projections that carry source time,
    // freshness and quality, and the ingestion that establishes them.
    'services/control-core/src/Cinerion.Domain/Monitoring/TelemetryRecords.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/MonitoringEndpoints.cs',
    'services/control-core/src/Cinerion.Infrastructure/Monitoring/SimulatedCellTelemetrySource.cs',
    'services/control-core/tests/Cinerion.Api.Tests/MonitoringEndpointTests.cs',
  ],
  NFR: ['simulators/state-model/test/command-machine.test.ts', 'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0001_ch1_foundation.sql'],
  OPS: ['infrastructure/compose.yaml', 'infrastructure/README.md', '.gitignore', 'scripts/run-local.sh'],
  PLC: ['plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl', 'plc/s7-1200-g2/tests/PLCSIM_SCENARIOS.md'],
  QMS: ['simulators/state-model/src/quality.ts', 'simulators/state-model/test/audit-quality.test.ts', 'services/control-core/src/Cinerion.Domain/Quality/QualityRecords.cs'],
  // CH1-RND-FR-0001 and CH1-RND-FR-0003 are isolation properties, so the schema is
  // evidence too: ch1.experiments and ch1.experiment_revisions both carry
  // CHECK (production_authority = false), and a recorded run is append-only.
  RND: [
    'apps/operator-portal/src/app/explore.tsx',
    'docs/implementation/DEVELOPMENT_GATES.md',
    'services/control-core/src/Cinerion.Domain/Research/ExperimentRecords.cs',
    'services/control-core/src/Cinerion.Application/Research/ResearchBenchService.cs',
    'services/control-core/src/Cinerion.Api/Endpoints/ResearchBenchEndpoints.cs',
    'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0006_experiment_revisions.sql',
    'services/control-core/tests/Cinerion.Api.Tests/ResearchBenchEndpointTests.cs',
  ],
  RPT: ['docs/baseline/P03_IFV/sources/CH1-PMG-FRP-0001.md', 'docs/baseline/P03_IFV/sources/CH1-VVT-STR-0001.md'],
  SAF: ['firmware/esp32/main/app_main.cpp', 'firmware/shared/src/cell_state_machine.cpp', 'firmware/tests/cell_state_machine_test.cpp', 'docs/implementation/DEVELOPMENT_GATES.md'],
  TRC: ['simulators/state-model/src/audit.ts', 'simulators/state-model/test/audit-quality.test.ts', 'services/control-core/src/Cinerion.Domain/Audit/AuditChain.cs', 'apps/operator-portal/src/app/audit.tsx'],
};

const prototypeVerified = new Set([
  ...Array.from({ length: 10 }, (_, index) => `CH1-CMD-FR-${String(index + 1).padStart(4, '0')}`),
  'CH1-COM-FR-0001',
  'CH1-COM-FR-0002',
  'CH1-COM-FR-0005',
  'CH1-COM-FR-0006',
  'CH1-COM-FR-0008',
  'CH1-MON-FR-0003',
  'CH1-OPS-FR-0003',
  'CH1-QMS-FR-0002',
  'CH1-QMS-FR-0003',
  'CH1-QMS-FR-0004',
  'CH1-QMS-FR-0005',
  'CH1-QMS-FR-0006',
  'CH1-SAF-FR-0002',
  'CH1-SAF-FR-0003',
  'CH1-TRC-FR-0002',
]);

const implementedPendingCi = new Set([
  'CH1-IAM-FR-0001',
  'CH1-IAM-FR-0004',
  'CH1-IAM-FR-0008',
  'CH1-MFG-FR-0002',
  'CH1-MFG-FR-0004',
  'CH1-TRC-FR-0001',
  'CH1-TRC-FR-0003',
]);

const hardwareGated = new Set([
  'CH1-COM-FR-0003',
  'CH1-COM-FR-0004',
  'CH1-CYB-FR-0003',
  'CH1-CYB-FR-0004',
  'CH1-IAM-FR-0005',
  'CH1-IAM-FR-0006',
  'CH1-IAM-FR-0007',
  'CH1-PLC-FR-0001',
  'CH1-PLC-FR-0002',
  'CH1-PLC-FR-0003',
  'CH1-PLC-FR-0004',
  'CH1-SAF-FR-0001',
  'CH1-SAF-FR-0004',
]);

const futurePhase = new Set([
  'CH1-DOC-FR-0002',
  'CH1-DOC-FR-0003',
  'CH1-DOC-FR-0004',
  'CH1-RPT-FR-0001',
  'CH1-RPT-FR-0002',
]);

function domainOf(id) {
  const match = /^CH1-([A-Z]+)-/.exec(id);
  if (!match) throw new Error(`Unrecognised requirement ID: ${id}`);
  return match[1];
}

function statusOf(id) {
  if (prototypeVerified.has(id)) return 'prototype_verified';
  if (implementedPendingCi.has(id)) return 'implemented_pending_dotnet_ci';
  if (hardwareGated.has(id)) return 'hardware_or_conformance_gated';
  if (futurePhase.has(id)) return 'future_controlled_phase';
  return 'foundation_implemented';
}

function scopeNote(status) {
  switch (status) {
    case 'prototype_verified':
      return 'Verified at executable model, host-firmware, contract, or portal level; this is not system acceptance.';
    case 'implemented_pending_dotnet_ci':
      return 'Implemented in the C# vertical slice; mandatory .NET 10 build/tests run in CI because the authoring host lacks the SDK.';
    case 'hardware_or_conformance_gated':
      return 'Interface or fail-closed skeleton exists; live enablement requires the named procurement, conformance, HIL, and/or independent safety gate.';
    case 'future_controlled_phase':
      return 'Reserved by the baseline and intentionally outside the Prototype 1 executable scope.';
    default:
      return 'Architecture, schema, contract, UI, or controlled stub exists; requirement-level acceptance evidence is still required.';
  }
}

const entries = requirements
  .slice()
  .sort((a, b) => a.id.localeCompare(b.id))
  .map((requirement) => {
    const domain = domainOf(requirement.id);
    const status = statusOf(requirement.id);
    return {
      requirementId: requirement.id,
      testCaseId: requirement.test_case,
      priority: requirement.priority,
      allocation: requirement.allocation,
      statement: requirement.statement,
      implementationStatus: status,
      verificationScope: scopeNote(status),
      evidence: evidenceByDomain[domain] ?? [],
    };
  });

const output = {
  schemaVersion: '1.0.0',
  project: 'Cinerion',
  namespace: 'CH1',
  governingBaseline: 'P03/IFV',
  softwareVersion: '0.1.0-prototype.1',
  authority: 'Simulation and controlled extra-low-voltage Prototype 1 only',
  generatedFrom: relative(root, requirementsPath),
  requirementCount: entries.length,
  entries,
};

await writeFile(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
console.log(`Generated ${relative(root, outputPath)} with ${entries.length} requirements.`);
