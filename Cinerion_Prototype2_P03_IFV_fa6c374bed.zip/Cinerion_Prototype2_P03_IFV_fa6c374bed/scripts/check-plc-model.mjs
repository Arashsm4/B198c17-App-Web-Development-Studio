// Reconciles the executable PLC model with the controlled SCL and the scenario table.
//
// plc/s7-1200-g2/01_Blocks/*.scl is the controlled source and stays authoritative; it
// cannot be executed here, because PLCSIM needs TIA Portal, a CPU firmware version and an
// order code, all of which are procurement gates. plc/host-model is a faithful
// translation of it so the eleven scenarios in PLCSIM_SCENARIOS.md can actually run —
// they had never been executed in any form.
//
// A second implementation can drift from the first, and a model nobody reconciled with
// the controlled source would be worse than no model: it would look like evidence about
// the PLC while being evidence about itself. So this fails when
//
//   * a reason code exists in the SCL and not in the model, or the reverse;
//   * a state value exists in one and not the other;
//   * a scenario row in the table has no test exercising it;
//   * or the scenario test names a scenario the table does not contain.
//
// It deliberately does NOT try to prove the two implementations behave identically. That
// is what PLCSIM evidence against the real CPU is for, and it remains outstanding.

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const guardScl = await readFile(resolve(root, 'plc/s7-1200-g2/01_Blocks/FB_CH1_CommandGuard.scl'), 'utf8');
const procedureScl = await readFile(resolve(root, 'plc/s7-1200-g2/01_Blocks/FB_CH1_Procedure.scl'), 'utf8');
const modelHeader = await readFile(resolve(root, 'plc/host-model/include/cinerion/plc_command_guard.hpp'), 'utf8');
const modelSource = await readFile(resolve(root, 'plc/host-model/src/plc_command_guard.cpp'), 'utf8');
const scenarioTable = await readFile(resolve(root, 'plc/s7-1200-g2/tests/PLCSIM_SCENARIOS.md'), 'utf8');
const scenarioTest = await readFile(resolve(root, 'plc/tests/plc_scenario_test.cpp'), 'utf8');

// -- 1. Reason codes. -----------------------------------------------------------------
//
// In the SCL they are assignments with a naming comment; in the model they are enumerator
// values. Both sets must be identical: a code the model cannot emit is a refusal the
// scenarios can never observe, and a code only the model has is one the CPU will never
// produce.

const sclReasonCodes = new Set(
  [...`${guardScl}\n${procedureScl}`.matchAll(/(?:ReasonCode|FaultCode)\s*:=\s*(\d+)/g)]
    .map((match) => Number(match[1]))
    .filter((code) => code !== 0));

const modelReasonCodes = new Set(
  [...modelHeader.matchAll(/\bk[A-Za-z]+\s*=\s*(\d+)\s*,/g)]
    .map((match) => Number(match[1]))
    .filter((code) => code !== 0));

// State values are declared in the SCL only as a comment on the State output, which is
// the one place they are enumerated, so that comment is the contract.
const stateComment = guardScl.match(/State\s*:\s*USInt;\s*\/\/([^\n]*)/);
if (!stateComment) {
  errors.push('FB_CH1_CommandGuard no longer documents its State values on the State output.');
}

const sclStates = new Set(
  [...(stateComment?.[1] ?? '').matchAll(/(\d+)\s+[A-Z]/g)].map((match) => Number(match[1])));
const modelStates = new Set(
  [...modelHeader.matchAll(/\bk[A-Za-z]+\s*=\s*(\d+),\s*$/gm)].map((match) => Number(match[1])));

for (const code of sclReasonCodes) {
  if (!modelReasonCodes.has(code)) {
    errors.push(`The SCL emits reason code ${code}, which plc/host-model does not define.`);
  }
}

for (const code of modelReasonCodes) {
  // State values share the enum namespace in the model, so a model value that is a
  // declared state is not an unmatched reason code.
  if (!sclReasonCodes.has(code) && !sclStates.has(code)) {
    errors.push(`plc/host-model defines ${code}, which the controlled SCL never emits.`);
  }
}

for (const state of sclStates) {
  if (!modelStates.has(state)) {
    errors.push(`FB_CH1_CommandGuard documents state ${state}, which plc/host-model does not define.`);
  }
}

// -- 2. Every state the SCL documents must be reachable in the SCL itself. -------------
//
// The State output's comment enumerated Executing, Complete and FaultLatched while the
// body assigned none of them. Two of those three carried an exemption here for two
// revisions — "Complete belongs to FB_CH1_Procedure" — and the exemption was wrong: the
// guard's own state 40 was simply unreachable, and so was 90, which meant a procedure
// that latched a fault while the permissives were still valid left the guard holding
// ExecutePermit with nothing able to clear it. Both are assigned now and the exemption is
// gone, so every documented state has to appear as an assignment.

for (const state of sclStates) {
  if (!new RegExp(`#State\\s*:=\\s*${state}\\b`).test(guardScl)) {
    errors.push(
      `FB_CH1_CommandGuard documents state ${state} but never assigns it. A documented state ` +
      'the body cannot reach is a state machine that does not exist.');
  }
}

// -- 3. Scenario coverage. ------------------------------------------------------------

const tableScenarios = [...scenarioTable.matchAll(/^\| ([A-Z][^|]+?) \|/gm)]
  .map((match) => match[1].trim())
  .filter((name) => name !== 'Scenario');

const testFunctions = [...scenarioTest.matchAll(/^void (scenario_\w+)\(\)/gm)].map((match) => match[1]);
const normalise = (text) => text.toLowerCase().replace(/[^a-z]/g, '');
const normalisedTests = testFunctions.map(normalise);

for (const scenario of tableScenarios) {
  const words = scenario.toLowerCase().split(/[^a-z]+/).filter((word) => word.length > 3);
  const covered = normalisedTests.some((test) => words.filter((word) => test.includes(word)).length >= 1);
  if (!covered) {
    errors.push(`PLCSIM_SCENARIOS.md lists "${scenario}" and no scenario test exercises it.`);
  }
}

if (tableScenarios.length === 0) {
  errors.push('No scenarios parsed from PLCSIM_SCENARIOS.md; this check would pass over nothing.');
}

// Every test must be invoked. A scenario function nobody calls is a scenario nobody runs.
for (const test of testFunctions) {
  if (!new RegExp(`^\\s*${test}\\(\\);`, 'm').test(scenarioTest)) {
    errors.push(`${test} is defined but never called from main().`);
  }
}

// -- 4. The stand-in guard is a third expression of the same block. -------------------
//
// simulators/plc-guard is reached over CH1-COM-IF-0007 and CH1-COM-IF-0008, so it is a
// third place the SCL's numbering can drift from. It is deliberately a SUBSET: it holds no
// material state and no wired inputs, so two of the prepare checks cannot be decided there
// and it declares them instead of answering them. Both directions are checked.
//
//   * every state value and reason code it defines must be one the SCL actually uses;
//   * every reason code the SCL's PREPARE branch can emit must either be implemented by the
//     stand-in or be named in its DeferredChecks. A new check added to the SCL therefore
//     cannot be silently absent from the interface a gateway talks to.

const standIn = await readFile(
  resolve(root, 'simulators/plc-guard/src/Cinerion.PlcGuard/Ch1PlcRuntime.cs'), 'utf8');

const section = (name) => standIn.match(
  new RegExp(`public static class ${name}\\s*\\{([\\s\\S]*?)\\n    \\}`))?.[1] ?? '';

const standInStates = new Set(
  [...section('GuardState').matchAll(/public const ushort \w+ = (\d+);/g)].map((match) => Number(match[1])));
const standInReasons = new Set(
  [...section('Reason').matchAll(/public const ushort \w+ = (\d+);/g)]
    .map((match) => Number(match[1]))
    .filter((code) => code !== 0));

// Profile refusals belong to the protocol, not to the guard, and live above 1000 so that a
// number crossing a wire that carries nothing else cannot be mistaken for a controlled
// reason code. The separation is only worth anything if it is enforced.
const profileReasons = new Set(
  [...section('ProfileReason').matchAll(/public const ushort \w+ = (\d+);/g)]
    .map((match) => Number(match[1])));
for (const code of profileReasons) {
  if (code < 1000) {
    errors.push(
      `Profile reason ${code} is below 1000, where the controlled SCL's own codes live. ` +
      'A profile refusal that collides with a guard reason is indistinguishable from it on a ' +
      'transport that carries only the number.');
  }
  if (sclReasonCodes.has(code)) {
    errors.push(`Profile reason ${code} is also a controlled SCL reason code.`);
  }
}

// The gateway names those codes for an operator, from its own table, because Modbus carries
// the number alone. A code the stand-in can emit and the gateway cannot name would reach a
// reader as "UNSPECIFIED".
const gatewayNames = new Set(
  [...(await readFile(
    resolve(root, 'services/edge-link/src/Cinerion.EdgeLink/Protocols/ModbusProtocolAdapter.cs'), 'utf8'))
    .matchAll(/^\s*(\d+) => "/gm)].map((match) => Number(match[1])));
for (const code of [...standInReasons, ...profileReasons]) {
  if (!gatewayNames.has(code)) {
    errors.push(
      `The stand-in guard can emit reason ${code} and Ch1GuardReasons does not name it, so a ` +
      'Modbus operator would be shown UNSPECIFIED for a refusal the controller stated precisely.');
  }
}

if (standInStates.size === 0 || standInReasons.size === 0) {
  errors.push(
    'No states or reason codes were parsed from Ch1PlcRuntime; this check would pass over nothing.');
}

for (const state of standInStates) {
  if (!sclStates.has(state)) {
    errors.push(`The stand-in guard defines state ${state}, which the controlled SCL does not document.`);
  }
}

for (const code of standInReasons) {
  if (!sclReasonCodes.has(code)) {
    errors.push(`The stand-in guard defines reason code ${code}, which the controlled SCL never emits.`);
  }
}

// The prepare branch only: the commit and execution codes are reachable through local
// confirmation, which this interface deliberately offers no way to supply.
const prepareBranch = guardScl.slice(
  guardScl.indexOf('IF #PrepareEdge.Q THEN'),
  guardScl.indexOf('IF #CommitEdge.Q THEN'));
const prepareCodes = new Set(
  [...prepareBranch.matchAll(/ReasonCode\s*:=\s*(\d+)/g)]
    .map((match) => Number(match[1]))
    .filter((code) => code !== 0));

if (prepareCodes.size === 0) {
  errors.push('No prepare-branch reason codes were parsed from the SCL; this check would pass over nothing.');
}

const deferred = new Set(
  [...(standIn.match(/DeferredChecks\s*=\s*\[([\s\S]*?)\];/)?.[1] ?? '').matchAll(/"(\d+)\s+[A-Z_]+/g)]
    .map((match) => Number(match[1])));

for (const code of prepareCodes) {
  if (!standInReasons.has(code) && !deferred.has(code)) {
    errors.push(
      `FB_CH1_CommandGuard's prepare branch can emit ${code}, and the stand-in guard neither ` +
      'implements it nor names it in DeferredChecks. A check the interface silently skips is ' +
      'the one an operator would assume was made.');
  }
}

for (const code of deferred) {
  if (!prepareCodes.has(code)) {
    errors.push(`The stand-in guard defers ${code}, which the SCL's prepare branch never emits.`);
  }
  if (standInReasons.has(code)) {
    errors.push(`The stand-in guard both implements and defers ${code}; it cannot be doing both.`);
  }
}

// -- 5. Report. -----------------------------------------------------------------------

if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(
    `PLC model reconciled: ${sclReasonCodes.size} reason codes and ${sclStates.size} states ` +
    `shared with the controlled SCL, ${tableScenarios.length} scenarios in the table and ` +
    `${testFunctions.length} executed.`);
  console.log(
    `Stand-in guard reconciled: ${standInReasons.size} reason codes and ${standInStates.size} states ` +
    `from the same SCL, ${prepareCodes.size} prepare-branch codes accounted for, ` +
    `${deferred.size} declared as decided by the CPU rather than answered here.`);
  console.log(
    'The model is not a substitute for PLCSIM evidence against the real CPU, which remains outstanding.');
}
