#!/usr/bin/env sh
# Stops the local stack. The off switch.

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"
docker compose -f infrastructure/compose.yaml down
