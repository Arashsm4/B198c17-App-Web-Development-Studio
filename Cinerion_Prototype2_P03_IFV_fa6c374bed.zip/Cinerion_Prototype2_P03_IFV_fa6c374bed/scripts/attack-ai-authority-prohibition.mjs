// Attacks the AI authority prohibition gate.
//
// `npm run ai:prohibition` exists to keep an AI service out of every authority path and
// out of the deployable tree - CH1-AI-FR-0002, access.json's "Approve or command via AI |
// None | Not applicable | Explicitly prohibited", and CH1-SWA-ADR-0010. A gate that
// searches for ABSENCE is the easiest kind to fool, because a broken search and a clean
// tree print the same thing. So each attack below puts back exactly what the gate is
// supposed to refuse, runs it, and asserts it FAILED and said why.
//
// Every attack first asserts that its mutation CHANGED the file. That is defect 75: two
// attacks in another suite silently stopped matching, the file went back unchanged, and
// the gate passed because there was genuinely nothing wrong with it. An attack that
// exercises nothing reports a full score.
//
// Attack 16 is the one this suite exists for. It collapses a backslash inside the gate's
// own matcher - item 71's failure, which happened three times in one session - and asserts
// the gate's POSITIVE CONTROL catches it. A gate that can go blind without saying so is
// worse than no gate, because it is believed.
//
// Every file is restored after every attack, including on a crash, and the suite checks at
// the end that each one is byte-identical to what it started with. One of them is a FROZEN
// baseline source, so that check is not a formality: `npm run baseline` verifies it by
// SHA-256.
//
//   npm run ai:attack

import { execFile } from 'node:child_process';
import { mkdir, readFile, rm } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const run = promisify(execFile);
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

const targets = {
  gate: 'scripts/check-ai-authority-prohibition.mjs',
  actor: 'services/control-core/src/Cinerion.Domain/Security/ActorContext.cs',
  portalPackage: 'apps/operator-portal/package.json',
  nuget: 'Directory.Packages.props',
  realm: 'infrastructure/keycloak/cinerion-realm.json',
  architecture: 'traceability/system-architecture-r01.json',
  access: 'docs/baseline/P03_IFV/data/access.json',
  packaging: 'scripts/package-release.sh',
  session: 'apps/operator-portal/src/auth/session.tsx',
  domainProject: 'services/control-core/src/Cinerion.Domain/Cinerion.Domain.csproj',
};

const originals = new Map();
for (const [key, path] of Object.entries(targets)) {
  originals.set(key, await readFile(resolve(root, path), 'utf8'));
}

let attacks = 0;
let holes = 0;

async function gate() {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-ai-authority-prohibition.mjs'], { cwd: root });
    return { refused: false, output: stdout };
  } catch (cause) {
    return { refused: true, output: `${cause.stdout ?? ''}${cause.stderr ?? ''}` };
  }
}

/**
 * Runs one attack against one file. `mutate` returns the content it wants written; an
 * attack whose mutation leaves the content unchanged is itself a failure, because it
 * exercises nothing.
 */
async function attack(name, key, mutate, expectation) {
  attacks += 1;
  const path = resolve(root, targets[key]);
  const original = originals.get(key);
  const mutated = mutate(original);
  if (mutated === original) {
    holes += 1;
    console.log(`HOLE  ${name} — the mutation changed nothing, so the gate was never exercised.`);
    return;
  }
  await writeFile(path, mutated, 'utf8');
  try {
    const result = await gate();
    if (!result.refused) {
      holes += 1;
      console.log(`HOLE  ${name} — the gate ACCEPTED it.`);
      return;
    }
    if (expectation !== undefined && !result.output.includes(expectation)) {
      holes += 1;
      console.log(
        `HOLE  ${name} — the gate refused, but not for the stated reason. ` +
        `Expected to see: ${expectation}`);
      return;
    }
    console.log(`ok    ${name}`);
  } finally {
    await writeFile(path, original, 'utf8');
  }
}

/** An attack that adds a file rather than changing one. */
async function attackByAdding(name, relativePath, contents, expectation) {
  attacks += 1;
  const path = resolve(root, relativePath);
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, contents, 'utf8');
  try {
    const result = await gate();
    if (!result.refused) {
      holes += 1;
      console.log(`HOLE  ${name} — the gate ACCEPTED it.`);
      return;
    }
    if (!result.output.includes(expectation)) {
      holes += 1;
      console.log(`HOLE  ${name} — refused, but not for the stated reason. Expected: ${expectation}`);
      return;
    }
    console.log(`ok    ${name}`);
  } finally {
    await rm(path, { force: true });
    await rm(dirname(path), { force: true, recursive: false }).catch(() => {});
  }
}

console.log('Attacking the AI authority prohibition gate.\n');

// -- The four text classes, each put into a file that is genuinely part of the product. --

// 1. The plainest form: a controlled service calling a model endpoint.
await attack(
  'an AI service host in the portal session module',
  'session',
  (source) => source.replace(
    "import * as AuthSession from 'expo-auth-session';",
    "import * as AuthSession from 'expo-auth-session';\nconst advisor = 'https://api.anthropic.com/v1/messages';"),
  'AI service host in the deployable tree',
);

// 2. A host that only appears with a region prefix, which a naive exact-match list misses.
await attack(
  'a Bedrock runtime endpoint, which is regional and so never matches a fixed host',
  'actor',
  (source) => source.replace(
    'public enum ActorKind',
    'public static class Advisor { public const string Endpoint = "bedrock-runtime.eu-central-1.amazonaws.com"; }\n\npublic enum ActorKind'),
  'AI service host in the deployable tree',
);

// 3. A model identifier with no host beside it - the shape a configuration value takes.
await attack(
  'a model identifier in a configuration constant',
  'actor',
  (source) => source.replace(
    'public enum ActorKind',
    'public static class Advisor { public const string Model = "claude-opus-4-20250514"; }\n\npublic enum ActorKind'),
  'AI model identifier in the deployable tree',
);

// 4. A credential read. No host and no model, so only the credential class can catch it.
await attack(
  'an AI credential read from the environment',
  'actor',
  (source) => source.replace(
    'public enum ActorKind',
    'public static class Advisor { public static string? Key => Environment.GetEnvironmentVariable("OPENAI_API_KEY"); }\n\npublic enum ActorKind'),
  'AI service credential in the deployable tree',
);

// 5. The authority surface itself: a branch that lets a non-human act.
//
//    Every multi-line mutation in this suite is a `\r?\n` REGEX rather than a literal.
//    That is item 46 / defect 75: ActorContext.cs and cinerion-realm.json are CRLF while
//    every other file here is LF, and a literal '\n' mutation against a CRLF file matches
//    nothing, writes the file back unchanged, and the gate then passes because there is
//    genuinely nothing wrong with it. Measured, not assumed: 111 CRLF and 0 bare LF in
//    ActorContext.cs, 337 and 0 in the realm, 0 and 642 in session.tsx.
await attack(
  'an actor kind the authorisation path could branch on',
  'actor',
  (source) => source.replace(
    /( {4}Human,\r?\n {4}Service,)/,
    '$1\r\n    Ai,'),
  'An AI actor kind makes the prohibition expressible as a permission',
);

// 6. A role constant. access.json gives this authority the role "None".
await attack(
  'an AI role constant in CinerionRoles',
  'actor',
  (source) => source.replace(
    '    public const string Viewer = "Viewer";',
    '    public const string Viewer = "Viewer";\n    public const string EngineeringAssistant = "EngineeringAssistant";'),
  'reads as an AI authority',
);

// -- Dependencies. A client library is how an AI service arrives in practice. --

// 7. The npm client, scoped.
await attack(
  'an AI client dependency in the portal manifest',
  'portalPackage',
  (source) => source.replace('"expo": "~57.0.11",', '"@anthropic-ai/sdk": "^0.30.0",\n    "expo": "~57.0.11",'),
  'declares the AI client dependency',
);

// 8. The npm client under a bare name, which a scope-prefix check alone would miss.
await attack(
  'an unscoped AI client dependency',
  'portalPackage',
  (source) => source.replace('"expo": "~57.0.11",', '"expo": "~57.0.11",\n    "openai": "^4.68.0",'),
  'declares the AI client dependency',
);

// 9. The .NET client, through the central manifest.
await attack(
  'an AI client in the central NuGet manifest',
  'nuget',
  (source) => source.replace(
    '<PackageVersion Include="Npgsql"',
    '<PackageVersion Include="Azure.AI.OpenAI" Version="2.1.0" />\n    <PackageVersion Include="Npgsql"'),
  'declares the AI client dependency',
);

// 10. Turning off the control that makes check 9 complete. Central management is the only
//     reason one manifest is the whole dependency list.
await attack(
  'central package management turned off, so the dependency check stops seeing everything',
  'nuget',
  (source) => source.replace(
    '<ManagePackageVersionsCentrally>true</ManagePackageVersionsCentrally>',
    '<ManagePackageVersionsCentrally>false</ManagePackageVersionsCentrally>'),
  'no longer manages package versions centrally',
);

// 11. The way round check 9 that does not touch the central manifest at all.
await attack(
  'a project pinning its own package version, bypassing the manifest the gate reads',
  'domainProject',
  (source) => source.replace(
    '</Project>',
    '  <ItemGroup>\n    <PackageReference Include="Microsoft.SemanticKernel" Version="1.30.0" />\n  </ItemGroup>\n</Project>'),
  'bypasses the central manifest',
);

// -- Identity and architecture. --

// 12. A realm role. The identity provider is where authority actually comes from.
await attack(
  'an AI role in the controlled realm',
  'realm',
  (source) => source.replace(
    /("roles": \{\r?\n {4}"realm": \[)/,
    '$1\r\n      {\r\n        "name": "AiAdvisor"\r\n      },'),
  'reads as an AI authority',
);

// 13. A realm client - a service identity needs no role to hold a token.
await attack(
  'an AI service identity in the controlled realm',
  'realm',
  (source) => source.replace('"clientId": "cinerion-operator-portal"', '"clientId": "cinerion-ai-advisor"'),
  'reads as an AI service identity',
);

// 14. A component in the controlled architecture register. The Engineering Assistant is
//     allocated two requirements and a threat and is drawn in no band of the diagram.
await attack(
  'an Engineering Assistant added to the controlled architecture register',
  'architecture',
  (source) => source.replace('"name": "ResearchBench"', '"name": "Engineering Assistant"'),
  'is an architecture change',
);

// -- The gate's own authority, and its own sight. --

// 15. The prohibition turned into a permission in the FROZEN baseline. The gate must stop
//     and say the rule has moved rather than keep enforcing one the documents dropped.
await attack(
  'the controlled prohibition rewritten as a permission',
  'access',
  (source) => source.replace(
    /"Approve or command via AI",(\r?\n) {4}"None",\r?\n {4}"Not applicable",\r?\n {4}"Explicitly prohibited"/,
    '"Approve or command via AI",$1    "Engineer",$1    "MFA",$1    "Audit"'),
  'A prohibition that has become a permission is an owner decision',
);

// 16. THE ONE THIS SUITE EXISTS FOR. Item 71: a backslash arrives collapsed and a regular
//     expression silently stops matching. Here the word-boundary is removed from a model
//     pattern and the host list is emptied, which is what a half-broken matcher looks
//     like. The positive control has to catch it, because nothing else can.
await attack(
  'the host matcher blinded, exactly as a collapsed escape would blind it',
  'gate',
  (source) => source.replace(
    "  'api.deepseek.com', 'api.x.ai', 'api.voyageai.com', 'bedrock-runtime.',",
    '  // emptied'),
  'POSITIVE CONTROL FAILED',
);

// 17. The same blinding, on a different class, to prove the control is per-class and not
//     one lucky assertion.
await attack(
  'the credential matcher blinded',
  'gate',
  (source) => source.replace(
    "  'ANTHROPIC_API_KEY', 'CLAUDE_API_KEY', 'OPENAI_API_KEY', 'OPENAI_ORG_ID',",
    "  'ANTHROPIC_API_KEY', 'CLAUDE_API_KEY', 'OPENAI_ORG_ID',"),
  'POSITIVE CONTROL FAILED',
);

// 17b. The exemption list, widened to cover product code. Four gate scripts are exempt
//      because a gate must NAME what it refuses - and the first strict run after the
//      egress gate was written is what forced that exemption to exist, because this gate
//      refused that one 17 times. An exemption nothing constrains is a switch, so it is
//      constrained to gate scripts and the constraint is attacked.
await attack(
  'the self-exemption widened to cover a product source file',
  'gate',
  (source) => source.replace(
    "  'scripts/attack-portal-egress.mjs',",
    "  'scripts/attack-portal-egress.mjs',\n  'services/control-core/src/Cinerion.Api/Program.cs',"),
  'is not a gate script under scripts/',
);

// 17c. The same, as a directory rather than a file - the shape an exemption takes when
//      somebody is trying to make a refusal go away rather than to fix it.
await attack(
  'the self-exemption widened to a whole directory',
  'gate',
  (source) => source.replace(
    "  'scripts/attack-portal-egress.mjs',",
    "  'scripts/attack-portal-egress.mjs',\n  'apps/operator-portal/src/',"),
  'is not a gate script under scripts/',
);

// 18. A gate that can read no actor kinds must say it established nothing, not pass.
await attack(
  'the actor kind enum made unreadable',
  'actor',
  (source) => source.replace('public enum ActorKind', 'public enum ActorKindRenamed'),
  'established nothing',
);

// -- Packaging. The reason the tooling rule is here at all. --

// 19. Removing the packaging exclusion. Currently-true is not enforced.
await attack(
  'the packaging exclusion for agent tooling removed',
  'packaging',
  // The packaging script moved from tar --exclude to git archive pathspecs; this follows it.
  (source) => source.replace(/ {2}':\(exclude,glob\)\*\*\/\.claude\/\*\*' \\\r?\n/, ''),
  'does not exclude ".claude"',
);

// 20. Putting agent tooling back into the deployable tree, where packaging would take it.
await attackByAdding(
  'agent tooling put back inside the deployable tree',
  'apps/operator-portal/.claude/settings.json',
  '{ "enabledPlugins": {} }\n',
  'Agent or editor tooling inside the deployable tree',
);

// 21. The same, as an instruction file addressed to a coding agent.
await attackByAdding(
  'an agent instruction file inside the portal',
  'apps/operator-portal/src/AGENTS.md',
  '# Notes for an agent\n',
  'Agent or editor tooling inside the deployable tree',
);

// -- Restoration. One of these is a frozen controlled source. --

let unrestored = 0;
for (const [key, path] of Object.entries(targets)) {
  const now = await readFile(resolve(root, path), 'utf8');
  if (now !== originals.get(key)) {
    holes += 1;
    unrestored += 1;
    console.log(`HOLE  ${path} was NOT restored to its original content.`);
  }
}
if (unrestored === 0) {
  attacks += 1;
  console.log(`ok    all ${Object.keys(targets).length} mutated files are byte-identical to how the suite found them`);
}

// And the frozen one is checked the way the repository checks it, not the way this suite
// happens to have read it.
attacks += 1;
try {
  await run(process.execPath, ['scripts/check-baseline-integrity.mjs'], { cwd: root });
  console.log('ok    the frozen baseline still verifies by SHA-256 after attack 15');
} catch (cause) {
  holes += 1;
  console.log(`HOLE  the frozen baseline no longer verifies: ${cause.stdout ?? cause.message}`);
}

console.log();
if (holes > 0) {
  console.error(`AI authority prohibition gate: ${attacks} attacks, ${holes} HOLES.`);
  process.exitCode = 1;
} else {
  console.log(`AI authority prohibition gate: ${attacks} attacks, 0 holes.`);
}
