// Attacks the widened CH1-SAF-FR-0001 actuator-output boundary in
// scripts/check-repository-policy.mjs. Each attack is the move the boundary exists to stop.

import { readFile, unlink } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);

const entryPath = 'firmware/esp32/main/app_main.cpp';
const driverPath = 'firmware/shared/src/output_driver.cpp';
const conditionedPath = 'firmware/shared/src/conditioned_io.cpp';
const mapPath = 'firmware/pinmap/esp32s3-r01.json';

const originalEntry = await readFile(entryPath, 'utf8');
const originalConditioned = await readFile(conditionedPath, 'utf8');
const originalMap = await readFile(mapPath, 'utf8');

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-repository-policy.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

let holes = 0;
const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
  console.log(output.split('\n').filter((l) => /error|Error|FAIL/.test(l)).slice(0, 3).join('\n'));
};

try {
  // 1. The original boundary: an actuator GPIO in the entry point itself.
  await writeFile(entryPath, originalEntry.replace(
    'extern "C" void app_main() {',
    'extern "C" void app_main() {\n    gpio_set_level(11, 1);'));
  let result = await gate();
  await writeFile(entryPath, originalEntry);
  judge('an actuator GPIO driven from the entry point', 'entry point configures or energises', result.refused, result.output);

  // 2. The move the widening exists to stop: the same act, one file lower, where the
  //    entry-point check could never have seen it.
  await writeFile(driverPath, [
    '#include "cinerion/conditioned_io.hpp"',
    '// A board driver that energises the actuator enable. This is the file the old check',
    '// could not see, and the reason the boundary is now the whole tree.',
    'void apply(const cinerion::io::OutputPlan& plan) {',
    '    gpio_set_level(11, plan.actuator_enable ? 1 : 0);',
    '}',
  ].join('\n'));
  result = await gate();
  await unlink(driverPath);
  judge('an actuator driven from a NEW file below the entry point',
    'energises a physical output outside HIL review', result.refused, result.output);

  // 3. The same, hidden inside a file that already exists and is expected to be there.
  await writeFile(conditionedPath, `${originalConditioned}\nvoid energise() { ledc_set_duty(0, 0, 512); }\n`);
  result = await gate();
  await writeFile(conditionedPath, originalConditioned);
  judge('a PWM duty written from inside the conditioned I/O layer',
    'energises a physical output outside HIL review', result.refused, result.output);

  // 4. The stepper, by the other API a stepper is usually driven with.
  await writeFile(conditionedPath, `${originalConditioned}\nvoid step() { mcpwm_start(0, 0); }\n`);
  result = await gate();
  await writeFile(conditionedPath, originalConditioned);
  judge('the stepper driven through the motor-control peripheral',
    'energises a physical output outside HIL review', result.refused, result.output);

  // 5. The data half: energisation granted by editing a JSON field rather than by review.
  const map = JSON.parse(originalMap);
  map.signals.find((s) => s.signalId === 'CH1-IO-DO-0006').energisable = true;
  await writeFile(mapPath, JSON.stringify(map, null, 2));
  result = await gate();
  await writeFile(mapPath, originalMap);
  judge('the actuator declared energisable while the wiring is unfrozen',
    'energisable while the wiring is not frozen', result.refused, result.output);
} finally {
  await writeFile(entryPath, originalEntry);
  await writeFile(conditionedPath, originalConditioned);
  await writeFile(mapPath, originalMap);
  await unlink(driverPath).catch(() => {});
}

const restored = await gate();
console.log(`\n5 attacks, ${holes} holes.`);
console.log(`Restored files pass the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
