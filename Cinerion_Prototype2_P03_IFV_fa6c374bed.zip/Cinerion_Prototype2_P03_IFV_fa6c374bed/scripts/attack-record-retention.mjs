// Attacks scripts/check-record-retention.sh by reverting, one at a time, each control it
// exists for. A gate that passes with the control removed is not a gate, and the only way
// to know which kind it is is to take the control away and watch.
//
// Each attack mutates the controlled migration, runs the whole gate against a fresh
// database, and puts the migration back. Every mutation is undone in a `finally`, and the
// restored file is re-run at the end, because a suite that dies holding a deliberately
// broken migration is worse than one that never ran.

import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);
const migration = 'services/control-core/src/Cinerion.Infrastructure/Persistence/Migrations/0014_record_retention.sql';
const original = await readFile(migration, 'utf8');

const gate = async () => {
  try {
    const { stdout } = await run('sh', ['scripts/check-record-retention.sh'], {
      maxBuffer: 32 * 1024 * 1024,
      env: { ...process.env, MSYS_NO_PATHCONV: '1', MSYS2_ARG_CONV_EXCL: '*' },
    });
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

const attacks = [
  // The retention boundary itself. A disposal that ignores retain_until reaches for a
  // record whose declared seven years have six left to run.
  //
  // The expected failure here is NOT the one this attack was first written to predict, and
  // the difference is the interesting part: the disposal does not delete too much, it
  // deletes NOTHING. The trigger refuses the unexpired row, the whole transaction aborts,
  // and no disposal record is written at all. That is defence in depth doing its job — the
  // procedure's predicate is a convenience and the trigger is the control — and the gate
  // still refuses, so it is recorded rather than tidied away.
  ['the disposal stops honouring the declared retention period',
    (sql) => sql
      .replaceAll('WHERE project_id = p_project AND retain_until < v_cutoff;', 'WHERE project_id = p_project;'),
    'after disposal:'],

  // The same, with BOTH halves removed, so the procedure's predicate is tested on its own
  // rather than behind the trigger that was covering for it.
  ['both the procedure predicate and the trigger date check are removed',
    (sql) => sql
      .replaceAll('WHERE project_id = p_project AND retain_until < v_cutoff;', 'WHERE project_id = p_project;')
      .replace('IF OLD.retain_until IS NULL OR OLD.retain_until >= clock_timestamp() THEN', 'IF false THEN'),
    'the wrong receipt survived'],

  // The trigger's date branch. Without it the retention role may delete anything it can
  // see, and the period becomes advisory.
  ['the trigger stops checking whether the period has ended',
    (sql) => sql.replace(
      'IF OLD.retain_until IS NULL OR OLD.retain_until >= clock_timestamp() THEN',
      'IF false THEN'),
    'the retention role cannot dispose of a receipt whose seven years have not ended'],

  // The trigger's role branch. Without it any role holding DELETE may dispose of evidence,
  // and "one named role" stops being true.
  ['the trigger stops checking which role is disposing',
    (sql) => sql.replace(
      "IF NOT pg_has_role(current_user, 'cinerion_retention', 'MEMBER') THEN",
      'IF false THEN'),
    'with DELETE granted, the trigger still refuses a role other than the retention role'],

  // Attribution. CH1-DBA-DD-0001 makes deletion authorised, and an authorisation with
  // nobody's name on it is not one.
  ['the disposal stops requiring a named authoriser and a reason',
    (sql) => sql.replace(
      "IF p_authorised_by IS NULL OR length(btrim(p_authorised_by)) = 0\n       OR p_reason IS NULL OR length(btrim(p_reason)) = 0 THEN",
      'IF false THEN'),
    'a disposal with no named authoriser'],

  // The closed register set. Without it the procedure is a general-purpose delete with a
  // reason field attached.
  ['the procedure accepts a register outside the closed set',
    (sql) => sql.replace(
      "IF p_register IS NULL OR p_register NOT IN ('message_acknowledgements', 'role_assignments') THEN",
      'IF false THEN'),
    'a disposal pointed at a register this procedure may not act on'],

  // Project scope. Without it a disposal reaches into another project's records.
  ['the disposal stops being scoped to the session project',
    (sql) => sql.replace(
      'IF p_project IS DISTINCT FROM ch1.current_project_id() THEN',
      'IF false THEN'),
    "a disposal aimed at another project than the session's"],

  // The REVOKE, which is the load-bearing half: 0002's ALTER DEFAULT PRIVILEGES grants the
  // application role all four privileges on every table created afterwards, so removing
  // this puts an unattributable deletion back within reach (defect 53's exact shape).
  ['the application role keeps the UPDATE and DELETE it is granted by default',
    (sql) => sql.replace(
      'REVOKE UPDATE, DELETE ON ch1.message_acknowledgements FROM cinerion_app;',
      '-- REVOKE removed by the attack suite'),
    'the application role cannot rewrite a delivery receipt'],
];

let holes = 0;

try {
  for (const [name, mutate, expectedFailure] of attacks) {
    const mutated = mutate(original);
    if (mutated === original) {
      holes += 1;
      console.log(`  *** NOT APPLIED *** ${name} — the mutation changed nothing, so this attack tested nothing`);
      continue;
    }
    await writeFile(migration, mutated);
    const { refused, output } = await gate();
    await writeFile(migration, original);

    // Refused is not enough: it must fail on the CHECK that exists for this control, or the
    // suite is only proving that a broken migration breaks something.
    const named = output.includes(`FAIL  ${expectedFailure}`) || output.includes(expectedFailure);
    const failedOnRightCheck = refused && named;
    if (failedOnRightCheck) {
      console.log(`  REFUSED BY NAME  ${name}`);
    } else {
      holes += 1;
      console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
      console.log(output.split('\n').filter((line) => line.startsWith('FAIL')).slice(0, 3).join('\n'));
    }
  }
} finally {
  await writeFile(migration, original);
}

const restored = await gate();
console.log(`\n${attacks.length} attacks, ${holes} holes.`);
console.log(`Restored migration passes the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
