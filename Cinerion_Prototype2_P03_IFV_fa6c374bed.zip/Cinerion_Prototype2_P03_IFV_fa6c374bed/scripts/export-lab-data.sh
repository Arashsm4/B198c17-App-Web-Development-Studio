#!/usr/bin/env sh
# Photographs the running lab's data so a release package can carry it to another PC.
#
# Writes lab-snapshot/ (git-ignored):
#   cinerion-lab-data.sql.gz   every row in the ch1 schema, data only
#   counts.txt                 rows per table, counted from the dump itself
#   SNAPSHOT_INFO.txt          when, from which commit, and the totals
#
# `npm run package:release` puts these in the zip when they exist, and on the new machine
# lab-up.sh loads them into the EMPTY database before Control Core first starts - so the new
# lab opens with the same telemetry history, alarms, audit trail, test runs and everything
# else as this one. It's never loaded over a database that already has data.
#
# What's NOT in it, on purpose: no secrets (the ch1 schema holds none - passwords live in
# Keycloak and infrastructure/.env.local, private keys in infrastructure/secrets/), no roles
# or grants (the migrations create those), and no half-finished WebAuthn challenges.
#
# The counts come from the dump file, not from a second query: telemetry keeps arriving while
# the dump runs, and pg_dump reads one consistent snapshot, so only the file's own rows are
# the truth to check the restore against.
#
# Usage: npm run lab:export

set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

fail() { printf 'FAIL  %s\n' "$*" >&2; exit 1; }
pass() { printf 'PASS  %s\n' "$*"; }

secrets="infrastructure/.env.local"
[ -f "$secrets" ] || fail "$secrets is absent, so there is no lab to photograph."

compose() {
  docker compose --env-file "$secrets" \
    -f infrastructure/compose.yaml -f infrastructure/compose.lab.yaml \
    --profile data-lab --profile identity-lab "$@"
}

compose ps --status running --services 2>/dev/null | grep -qx postgres \
  || fail "the lab's database isn't running. Start the lab first (npm run lab:up)."

out=lab-snapshot
mkdir -p "$out"
dump="$out/cinerion-lab-data.sql.gz"
tmp="$dump.partial"

echo "Taking a snapshot of the lab's data..."
# --disable-triggers wraps each table's rows in DISABLE/ENABLE TRIGGER ALL, so the restore
# isn't tripped by the append-only and foreign-key triggers loading tables in dump order.
#
# A plain `pg_dump | gzip` would hide a failed dump: a pipeline reports only its last
# command. So pg_dump's own exit code is written aside and checked.
err="$out/.pg_dump.err"
status="$out/.pg_dump.status"
{
  compose exec -T postgres pg_dump -U cinerion_owner -d cinerion \
      --data-only --schema=ch1 --disable-triggers --no-owner --no-privileges \
      --exclude-table-data=ch1.webauthn_challenges 2>"$err"
  echo $? > "$status"
} | gzip -9 > "$tmp"
code=$(cat "$status" 2>/dev/null || echo missing)
rm -f "$status"
if [ "$code" != 0 ]; then
  cat "$err" >&2
  rm -f "$err" "$tmp"
  fail "pg_dump failed (exit $code), so no snapshot was written."
fi
# On success pg_dump says one thing: some tables' foreign keys point at each other. That is
# exactly what --disable-triggers is for, so that notice is dropped; anything else is shown.
grep -vE "^pg_dump: (warning: there are circular foreign-key constraints|detail:|hint:)" "$err" >&2 || true
rm -f "$err"
[ -s "$tmp" ] || fail "pg_dump produced nothing."

# Rows per table, straight from the COPY blocks in the file.
gunzip -c "$tmp" | awk '
  /^COPY ch1\./ { split($2, parts, "."); table = parts[2]; counting = 1; rows = 0; next }
  counting && /^\\\.$/ { print table "|" rows; counting = 0; next }
  counting { rows++ }
' | LC_ALL=C sort > "$out/counts.txt"
tables=$(grep -c . "$out/counts.txt" || true)
total=$(awk -F'|' '{ s += $2 } END { print s + 0 }' "$out/counts.txt")
[ "$tables" -gt 0 ] || fail "the snapshot has no tables in it, which means the dump didn't capture the ch1 schema."

mv -f "$tmp" "$dump"

{
  echo "Cinerion lab data snapshot"
  echo
  echo "Taken (UTC):   $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "From commit:   $(git rev-parse HEAD 2>/dev/null || echo unknown)"
  echo "Tables:        $tables"
  echo "Rows:          $total"
  echo
  echo "Loaded automatically by scripts/lab-up.sh into an EMPTY database on a new machine,"
  echo "before Control Core first starts. Never loaded over existing data."
  echo "Rows per table are in counts.txt; the restore is checked against them."
} > "$out/SNAPSHOT_INFO.txt"

size=$(du -h "$dump" | cut -f1)
pass "snapshot written: $total rows across $tables tables, $size compressed, in $out/"
awk -F'|' '$2 > 0 { printf "      %-34s %s\n", $1, $2 }' "$out/counts.txt" | head -12
