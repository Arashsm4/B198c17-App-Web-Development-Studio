// Attacks scripts/check-executable-obligations.mjs by reverting, one at a time, each
// control it exists for. Every mutation is applied to the real file and undone afterwards,
// so the gate under attack is exactly the gate CI runs.
//
// The first attack is the one that matters. traceability/executable-obligations.json exists
// because six gates carry real evidence for controlled requirements that have no
// verification case, and the single failure mode of such a register is that it quietly
// becomes a second verification map — an entry that CLAIMS a case, reconciled against
// nothing, counted alongside the 87 that are.

import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);
const registerPath = 'traceability/executable-obligations.json';
const original = await readFile(registerPath, 'utf8');

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-executable-obligations.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

const first = (register) => register.obligations[0];

const attacks = [
  ['a controlled verification case claimed as the obligation', (register) => {
    first(register).carriesEvidenceFor = ['CH1-VVT-TC-0090'];
  }, 'names a controlled verification case outside its `doesNotEstablish` field'],

  ['a case smuggled in through prose rather than through the binding field', (register) => {
    first(register).refuses = `${first(register).refuses} Evidence for CH1-VVT-TC-0090.`;
  }, 'names a controlled verification case outside its `doesNotEstablish` field'],

  ['an obligation naming a requirement the baseline does not contain', (register) => {
    first(register).carriesEvidenceFor = ['CH1-DBA-DD-9999'];
  }, 'is not a controlled requirement, interface or document'],

  ['an obligation naming a gate that does not exist', (register) => {
    first(register).gate = 'npm run retention:pretend';
  }, 'is not a gate package.json defines'],

  ['an obligation with no limits stated', (register) => {
    first(register).doesNotEstablish = 'nothing';
  }, 'does not state what it fails to establish'],

  ['an obligation that does not say what it refuses', (register) => {
    first(register).refuses = 'things';
  }, 'does not say what it refuses'],

  ['an obligation carrying evidence for nothing at all', (register) => {
    first(register).carriesEvidenceFor = [];
  }, 'names no obligation at all'],

  ['the register emptied, so the gate would pass over nothing', (register) => {
    register.obligations = [];
  }, 'this check would pass over nothing'],
];

let holes = 0;
const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
  console.log(output.split('\n').filter((line) => line.includes('FAIL')).slice(0, 3).join('\n'));
};

// The mutation is undone in a `finally`, including on a throw: a suite that edits a tracked
// register and then dies leaves the repository holding a deliberately broken one.
try {
  for (const [name, mutate, expected] of attacks) {
    const register = JSON.parse(original);
    mutate(register);
    await writeFile(registerPath, `${JSON.stringify(register, null, 2)}\n`);
    const { refused, output } = await gate();
    await writeFile(registerPath, original);
    judge(name, expected, refused, output);
  }
} finally {
  await writeFile(registerPath, original);
}

// And the honest sentence must still be legal, or the gate has been made to refuse the one
// thing the register exists to record.
const restored = await gate();
const mentionsACase = restored.output.length > 0 && !restored.refused;
console.log(
  `  ALLOWED          a case named inside \`doesNotEstablish\`, which is where an entry says ` +
  `which cases its evidence is NOT: ${mentionsACase ? 'yes' : 'NO — the gate now refuses the honest sentence'}`);
if (!mentionsACase) holes += 1;

console.log(`\n${attacks.length} attacks, ${holes} holes.`);
console.log(`Restored register passes the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
