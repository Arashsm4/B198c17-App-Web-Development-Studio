#!/usr/bin/env sh
# The demonstration dataset, over HTTP, against a real service on PostgreSQL.
#
# scripts/../DemonstrationSeedTests asserts the dataset at the STORE. That is the right place
# for it — deterministic, fast, and free of the shared environment the API test factory sets
# once for the whole assembly. It is also not the thing anyone actually complained about.
# What a reviewer sees is a SCREEN, and a screen reads an HTTP operation, and an operation
# that answers 200 with an empty array renders exactly like one that is broken.
#
# So this raises Control Core from the controlled compose model, on PostgreSQL, with the
# demonstration seed on, and asks every read the declared screens depend on whether it has
# anything to show. It refuses an empty answer.
#
# What it does NOT do is assert that the screens render — scripts/check-portal-render.mjs
# already mounts the real screen modules and drives them, and duplicating that here would be
# a second declaration to keep in step. This is about the data being there.
#
# It announces no controlled verification case. data/tests.json has none for demonstration
# data, and binding this to an unrelated one is the overstatement the verification map exists
# to prevent — the same position check-telemetry-retention.sh and check-io-map.mjs take.
#
# Usage: scripts/check-demonstration-data.sh
set -eu

MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_dir"

project=cinerion-demo-verify
client_image=curlimages/curl:8.11.1
project_id=00000000-0000-4000-8000-000000000101
cell_id=00000000-0000-4000-8000-000000000103
part_id=00000000-0000-4000-8000-000000000106

failures=0
log() { printf '\n%s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*" >&2; failures=$((failures + 1)); }
pass() { printf 'PASS  %s\n' "$*"; }

compose() {
  docker compose -p "$project" \
    -f infrastructure/compose.yaml \
    -f infrastructure/compose.grpc-verify.yaml \
    -f infrastructure/compose.demo-verify.yaml "$@"
}

cleanup() { compose --profile data-lab down -v --remove-orphans >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM

if ! docker version >/dev/null 2>&1; then
  echo "check-demonstration-data.sh: the Docker daemon is unreachable. This gate reads a real" >&2
  echo "service on a real database; there is no meaningful way to run it without one." >&2
  exit 1
fi

docker image inspect "$client_image" >/dev/null 2>&1 || docker pull -q "$client_image" >/dev/null
cleanup

app_password=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)

# The development identity, which is what makes this gate about the DATA rather than about
# the sign-in ceremony. Every role the declared screens need, so an empty answer is an empty
# answer and never an authority refusal — the two are deliberately indistinguishable to a
# caller (CH1-CYB-ACP-0001), which would make this gate unable to tell them apart too.
network="${project}_control"
# -HHost:localhost is not decoration. AllowedHosts=localhost answers a request addressed to
# the Compose service name with a bare 400, which reads as the service being broken rather
# than as a host-header refusal — the same trap defect 42 records for the gRPC listener.
headers="-HHost:localhost -HX-CH1-Actor:USR-DEMO-VERIFY -HX-CH1-Project:$project_id"
headers="$headers -HX-CH1-Roles:Viewer,Engineer,Inspector,Auditor,ProjectManager,MaintenanceEngineer,OperationsCoordinator,RnDEngineer,LocalConfirmer"
headers="$headers -HX-CH1-Cells:$cell_id -HX-CH1-Auth-Strength:StepUpPhishingResistant"
headers="$headers -HX-CH1-Session:session-demo-verify"

api() {
  method=$1
  path=$2
  # shellcheck disable=SC2086
  docker run --rm --network "$network" "$client_image" curl -sS --max-time 20 \
    -X "$method" $headers "http://control-core:8080$path" 2>/dev/null
}

# A read that must have something to show. `jq` is not available in the curl image, so the
# count is taken with node on the host from the body the service actually sent.
populated() {
  what=$1; path=$2; expression=$3
  body=$(api GET "$path" || true)
  # The expression travels in the environment, not spliced into the script. Splicing it
  # produced malformed JavaScript for every call, and the gate then reported twelve
  # populated endpoints as unreadable JSON — a check failing for a reason that had nothing
  # to do with its subject.
  count=$(printf '%s' "$body" | CH1_EXPR="$expression" node -e '
    let s = "";
    process.stdin.on("data", d => s += d).on("end", () => {
      try {
        const v = JSON.parse(s);
        const r = new Function("v", "return (" + process.env.CH1_EXPR + ");")(v);
        console.log(Array.isArray(r) ? r.length : (r === undefined || r === null ? 0 : 1));
      } catch { console.log("-1"); }
    });' 2>/dev/null || echo "-1")

  case "$count" in
    -1|'')
      fail "$what — the response could not be read: $(printf '%s' "$body" | tr '
' ' ' | cut -c1-140)" ;;
    0)
      fail "$what — the operation answered, and answered with nothing. A reviewer cannot tell this from a broken screen." ;;
    *)
      pass "$what ($count)" ;;
  esac
}

log "[1/4] Raising PostgreSQL and Control Core with the demonstration seed on"
CINERION_POSTGRES_PASSWORD=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
CINERION_DATABASE_MODE=Postgres
CINERION_POSTGRES_CONNECTION="Host=postgres;Port=5432;Database=cinerion;Username=cinerion_app;Password=$app_password"
CINERION_SIMULATED_TELEMETRY=false
CINERION_DEMONSTRATION_DATA=true
export CINERION_POSTGRES_PASSWORD CINERION_DATABASE_MODE CINERION_POSTGRES_CONNECTION \
  CINERION_SIMULATED_TELEMETRY CINERION_DEMONSTRATION_DATA

compose --profile data-lab up -d --build postgres >/dev/null 2>&1 || {
  fail "PostgreSQL could not be raised"; exit 1; }

attempt=0
settled=0
while [ "$settled" -lt 3 ]; do
  if compose --profile data-lab exec -T postgres psql -U cinerion_owner -d cinerion -tAc "select 1" >/dev/null 2>&1; then
    settled=$((settled + 1))
  else
    settled=0
  fi
  attempt=$((attempt + 1))
  [ "$attempt" -gt 90 ] && { fail "PostgreSQL never became ready"; exit 1; }
  sleep 2
done

compose --profile data-lab exec -T postgres psql -U cinerion_owner -d cinerion -qc \
  "ALTER ROLE cinerion_app LOGIN PASSWORD '$app_password';" >/dev/null

if ! control_core_out=$(compose up -d --build control-core 2>&1); then
  fail "Control Core could not be raised"
  printf '%s\n' "$control_core_out" | tail -25 | sed 's/^/      /' >&2
  exit 1
fi

attempt=0
until api GET /api/v1/system/health 2>/dev/null | grep -q "status"; do
  attempt=$((attempt + 1))
  if [ "$attempt" -gt 60 ]; then
    fail "Control Core never answered"
    compose logs --tail 30 control-core 2>&1 | sed 's/^/      /' >&2
    exit 1
  fi
  sleep 2
done
pass "Control Core is serving on PostgreSQL with the demonstration seed applied"

log "[2/4] Every screen's backing read has something to show"

# CH1-UX-SCR-0003 project portfolio, 0004 site and cell hierarchy
populated "CH1-UX-SCR-0003 project portfolio" "/api/v1/projects" "v.items ?? v"
populated "CH1-UX-SCR-0004 cell hierarchy" "/api/v1/sites/00000000-0000-4000-8000-000000000102/cells" "v.items ?? v"

# CH1-UX-SCR-0005 live control room, 0016 cross-layer overview
populated "CH1-UX-SCR-0005 alarms" "/api/v1/alarms" "v.items ?? v.alarms ?? v"
populated "CH1-UX-SCR-0005 telemetry" "/api/v1/telemetry?cellId=$cell_id" "v.items ?? v.samples ?? v"
populated "CH1-UX-SCR-0016 cell state" "/api/v1/cells/$cell_id/state" "v.cellId ?? v"

# CH1-UX-SCR-0006 work-order board, 0007 genealogy
populated "CH1-UX-SCR-0006 work orders" "/api/v1/work-orders" "v.items ?? v.workOrders ?? v"
populated "CH1-UX-SCR-0006 product revisions" "/api/v1/products" "v.items ?? v"
populated "CH1-UX-SCR-0007 part genealogy" "/api/v1/parts/$part_id/genealogy" "v.measurements ?? v"

# CH1-UX-SCR-0012 instrument and calibration register
populated "CH1-UX-SCR-0012 calibrations" "/api/v1/calibrations" "v.items ?? v.calibrations ?? v"

# CH1-UX-SCR-0014 audit-chain explorer
populated "CH1-UX-SCR-0014 audit events" "/api/v1/audit/events" "v.items ?? v"

# CH1-UX-SCR-0015 mobile scan and evidence mode
populated "CH1-UX-SCR-0015 scan events" "/api/v1/parts/scan-events" "v.items ?? v.scanEvents ?? v"

# CH1-UX-SCR-0017 resource and capacity board
populated "CH1-UX-SCR-0017 resources" "/api/v1/resources" "v.items ?? v"

# CH1-UX-SCR-0020 R&D workbench
populated "CH1-UX-SCR-0020 experiments" "/api/v1/experiments" "v.items ?? v"

log "[3/4] The dataset says what it is"

# Every seeded reading must be Simulated. A demonstration dataset whose telemetry claimed to
# be Live would be the single most misleading thing in the system, and it is exactly the
# mistake that is easy to make and impossible to see from a screen.
telemetry=$(api GET "/api/v1/telemetry?cellId=$cell_id" || true)
live=$(printf '%s' "$telemetry" | node -e '
  let s = ""; process.stdin.on("data", d => s += d).on("end", () => {
    try {
      const v = JSON.parse(s);
      const rows = v.items ?? v.samples ?? v ?? [];
      console.log(rows.filter(r => r.freshness === "Live").length);
    } catch { console.log("-1"); }
  });' 2>/dev/null || echo "-1")
[ "$live" = "0" ] \
  && pass "no seeded reading claims to be Live; every one is Simulated (CH1-MON-FR-0003)" \
  || fail "$live seeded reading(s) claim Freshness=Live"

# And no command may have executed. A seeded execution would be this service claiming a
# physical act that never happened, which CH1-AUT-FDS-0001 and AGENTS.md forbid outright.
executed=$(compose --profile data-lab exec -T postgres psql -U cinerion_owner -d cinerion -tAc \
  "SELECT count(*) FROM ch1.command_transactions WHERE state IN ('Executing','Completed','Committed');" 2>/dev/null | tr -d ' \r')
case "$executed" in
  0) pass "no seeded command has executed, committed or completed" ;;
  ''|*[!0-9]*) fail "the command register could not be read, so whether anything executed is UNKNOWN (got '$executed')" ;;
  *) fail "$executed seeded command(s) claim to have executed" ;;
esac

log "[4/4] The dataset is off unless it is asked for"
# The load-bearing negative. A demonstration dataset that seeded itself by default would
# eventually reach somewhere it should not, and nobody would notice until they read the
# database.
grep -q 'CINERION_DEMONSTRATION_DATA' infrastructure/compose.yaml \
  && fail "the controlled compose model names CINERION_DEMONSTRATION_DATA; it belongs to the lab overlay alone" \
  || pass "the controlled compose model does not enable demonstration data"

grep -q 'Demonstration data is forbidden in the Production runtime profile' \
  services/control-core/src/Cinerion.Api/Program.cs \
  && pass "the service refuses demonstration data in the Production profile" \
  || fail "nothing stops demonstration data in the Production profile"

echo
if [ "$failures" -eq 0 ]; then
  echo "Demonstration dataset verified against a real service on PostgreSQL."
  echo "  screens        : every declared screen's backing read answered with something to show"
  echo "  honesty        : every reading is Simulated, no command has executed"
  echo "  default        : off unless asked for, and refused in the Production profile"
  echo
  echo "No controlled verification case is announced: data/tests.json contains none for"
  echo "demonstration data. Recorded as conflict 29."
  exit 0
fi

echo "$failures check(s) failed."
exit 1
