# Starts the local stack on Windows.

$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Push-Location $Repo
try {
    docker compose -f infrastructure/compose.yaml up --detach --build --wait
    Write-Host 'Cinerion simulator-safe stack is healthy.'
    Write-Host 'Portal: http://localhost:8081'
    Write-Host 'API:    http://localhost:5080/api/v1/system/health'
} finally {
    Pop-Location
}
