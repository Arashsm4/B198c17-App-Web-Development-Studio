// Reconciles the implementation against the CONTROLLED PREPARE / LOCAL COMMIT sequence.
//
// CH1-AUT-FDS-0001 describes the secure physical action in prose and refers the exchange
// itself to `assets/prepare-local-commit.png`. This repository was reading that as an
// image, which is the same mistake item 45 records for the cell state diagram: the frozen
// baseline carries `assets/prepare-local-commit.svg` beside the PNG, and an SVG sequence
// diagram is not a picture of a protocol, it IS one, with coordinates.
//
// The geometry is exact and this gate depends on that rather than on tolerance:
//
//   * four lifelines at x = 200, 540, 890 and 1300, each starting inside exactly one
//     header rectangle whose <text class="head"> names the participant;
//   * seven <path> messages, each horizontal, whose two endpoints land EXACTLY on a
//     lifeline x - not near one;
//   * seven <text class="step"> elements numbered "1." to "7.";
//   * message labels at exactly pathY - 10, and step notes at exactly stepY + 30.
//
// Nothing here is a nearest match. An endpoint that does not equal a lifeline, or a
// <text class="small"> that sits at neither offset, is an error - because the alternative
// is a gate that rounds a moved arrow onto the wrong participant and then approves.
//
// Reading it found two defects that inspection had not, both in the last two steps:
//
//   * defect 76 - every audit event EdgeIngressService wrote carried `Guid.NewGuid()` as
//     its correlation identity, including `ControllerAcknowledgementRecorded`. The
//     controller's answer to a command was therefore correlated with nothing, and step 7
//     ("Correlate telemetry, result and audit evidence") had no evidence to correlate.
//     CH1-CYB-FR-0006 requires security events to carry correlation data; a per-event
//     random GUID is the shape of correlation data without being any.
//   * defect 77 - `GET /api/v1/commands/{commandId}` returned the lifecycle only.
//     api_endpoints.json controls it as "Read command lifecycle and controller
//     acknowledgements" with "immutable audit links", and it carried neither, so the
//     final message ("Visible execution outcome") delivered the domain's decision and
//     never the equipment's answer.
//
// What it refuses:
//
//   * the controlled diagram no longer parsing into four participants, seven steps and
//     seven messages, or any endpoint or label that does not resolve exactly;
//   * a controlled element the map does not declare, or a declared element the diagram
//     does not contain - the second is the direction that matters, because it is how an
//     invented step in a safety sequence would arrive;
//   * the map's order differing from the diagram's, which for a protocol is most of its
//     meaning: a credential proof accepted AFTER the button edge is a different and much
//     weaker system than the controlled one;
//   * a message whose direction or amber/blue guarding disagrees with the diagram;
//   * an element that is neither bound to symbols present in named sources nor declared
//     not-implemented with a reason;
//   * a bound symbol that is absent from the source that claims it.
//
// What it does NOT do, stated because the omission matters. It does not parse C#, C++ or
// control flow, so it cannot see that a named symbol is reached on the path the diagram
// describes - only that the source contains it. A guard moved behind an `if (false)` is
// invisible here and is caught by the domain tests and the API tests that exercise the
// refusals by code. What this gate holds is the direction those cannot: that the
// controlled exchange is still the exchange the code claims to implement, in order, with
// every controlled note still enforced by something.
//
// It announces no controlled verification case of its own, for the reason recorded as
// conflict 31: `data/tests.json` binds this sequence's BEHAVIOUR to CH1-VVT-TC-0011..0017
// and those are announced by the harnesses that exercise it. This gate checks a different
// thing - that the implemented exchange is the controlled one - and binding it to a
// behavioural case would be the overstatement the verification map exists to prevent.

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const diagramPath = 'docs/baseline/P03_IFV/assets/prepare-local-commit.svg';
const mapPath = 'traceability/local-commit-sequence-r01.json';

const svg = await readFile(resolve(root, diagramPath), 'utf8');
const map = JSON.parse(await readFile(resolve(root, mapPath), 'utf8'));

const attribute = (attributes, name) => {
  const match = attributes.match(new RegExp(`\\b${name}="([^"]*)"`));
  return match ? match[1] : null;
};
const number = (attributes, name) => {
  const value = attribute(attributes, name);
  return value === null ? null : Number(value);
};

// -- 1. The controlled diagram, parsed. --------------------------------------------------

// Participant headers. Every <rect> carrying x/y/width/height is one; the page background
// has no x, and there is nothing else rectangular in this diagram.
const headers = [...svg.matchAll(/<rect\b([^>]*)\/>/g)]
  .map((match) => ({
    x: number(match[1], 'x'),
    y: number(match[1], 'y'),
    width: number(match[1], 'width'),
    height: number(match[1], 'height'),
  }))
  .filter((box) => box.x !== null && box.y !== null && box.width !== null && box.height !== null);

const contains = (box, x, y) =>
  x >= box.x && x <= box.x + box.width && y >= box.y && y <= box.y + box.height;

const texts = [...svg.matchAll(/<text\b([^>]*)>([^<]*)<\/text>/g)].map((match) => ({
  x: number(match[1], 'x'),
  y: number(match[1], 'y'),
  cls: attribute(match[1], 'class'),
  text: match[2].trim(),
}));

// A participant is a header rectangle, the <text class="head"> inside it, and the dashed
// lifeline that starts inside it. All three must resolve one-to-one.
const participants = [];
for (const head of texts.filter((item) => item.cls === 'head')) {
  const hits = headers.filter((box) => contains(box, head.x, head.y));
  if (hits.length !== 1) {
    errors.push(
      `${diagramPath}: the participant label "${head.text}" at (${head.x},${head.y}) falls inside ` +
      `${hits.length} header boxes. A label naming no box, or two, is not a participant this gate will guess at.`);
    continue;
  }
  participants.push({ name: head.text, box: hits[0] });
}

const lifelines = [...svg.matchAll(/<line\b([^>]*)\/>/g)]
  .map((match) => ({
    x1: number(match[1], 'x1'),
    y1: number(match[1], 'y1'),
    x2: number(match[1], 'x2'),
    y2: number(match[1], 'y2'),
    cls: attribute(match[1], 'class'),
  }))
  .filter((line) => line.cls === 'life');

for (const lifeline of lifelines) {
  if (lifeline.x1 !== lifeline.x2) {
    errors.push(
      `${diagramPath}: the lifeline from (${lifeline.x1},${lifeline.y1}) to (${lifeline.x2},${lifeline.y2}) ` +
      'is not vertical, so no message endpoint on it can be resolved to one participant.');
    continue;
  }
  const hits = participants.filter((participant) =>
    lifeline.x1 >= participant.box.x && lifeline.x1 <= participant.box.x + participant.box.width);
  if (hits.length !== 1) {
    errors.push(
      `${diagramPath}: the lifeline at x=${lifeline.x1} belongs to ${hits.length} participants.`);
    continue;
  }
  if (hits[0].lifeline !== undefined) {
    errors.push(`${diagramPath}: "${hits[0].name}" has more than one lifeline.`);
    continue;
  }
  hits[0].lifeline = lifeline.x1;
}

for (const participant of participants) {
  if (participant.lifeline === undefined) {
    errors.push(`${diagramPath}: "${participant.name}" has no lifeline, so it sends and receives nothing.`);
  }
}

// Messages. Each is a horizontal <path> whose endpoints must EQUAL a lifeline x. The
// amber class is the diagram's own marking of a locally guarded exchange.
const byLifeline = new Map(participants.filter((p) => p.lifeline !== undefined).map((p) => [p.lifeline, p]));

const rawMessages = [];
for (const match of svg.matchAll(/<path\b([^>]*)\/>/g)) {
  const cls = attribute(match[1], 'class');
  if (cls !== 'arrow' && cls !== 'local') continue;
  const d = attribute(match[1], 'd');
  const points = [...(d ?? '').matchAll(/-?[\d.]+/g)].map((value) => Number(value[0]));
  if (points.length !== 4) {
    errors.push(`${diagramPath}: the message path "${d}" is not a single straight segment.`);
    continue;
  }
  const [x1, y1, x2, y2] = points;
  if (y1 !== y2) {
    errors.push(`${diagramPath}: the message path "${d}" is not horizontal, so its place in the order is ambiguous.`);
    continue;
  }
  const from = byLifeline.get(x1);
  const to = byLifeline.get(x2);
  if (!from || !to) {
    errors.push(
      `${diagramPath}: the message path "${d}" has an endpoint at x=${!from ? x1 : x2} that is not a lifeline. ` +
      'This gate resolves an endpoint exactly or not at all; a moved arrow is a changed protocol, not a rounding error.');
    continue;
  }
  rawMessages.push({ kind: 'message', y: y1, from: from.name, to: to.name, guarded: cls === 'local' });
}

// Steps, numbered and contiguous.
const rawSteps = [];
for (const step of texts.filter((item) => item.cls === 'step')) {
  const parsed = step.text.match(/^(\d+)\.\s+(.*)$/);
  if (!parsed) {
    errors.push(`${diagramPath}: the step "${step.text}" is not numbered, so its place in the sequence is unstated.`);
    continue;
  }
  rawSteps.push({ kind: 'step', y: step.y, number: Number(parsed[1]), text: parsed[2].trim() });
}
rawSteps.sort((a, b) => a.y - b.y);
rawSteps.forEach((step, index) => {
  if (step.number !== index + 1) {
    errors.push(
      `${diagramPath}: step ${step.number} is the ${index + 1}th step down the page. ` +
      'A numbering that disagrees with the order cannot be reconciled against an implementation.');
  }
});

// The two exact offsets. A <text class="small"> is a message label at pathY - 10 or a
// step note at stepY + 30, and nothing else. Anything satisfying neither, or both, is an
// error rather than a nearest guess.
const LABEL_OFFSET = 10;
const NOTE_OFFSET = 30;
const rawNotes = [];
for (const small of texts.filter((item) => item.cls === 'small')) {
  const labelled = rawMessages.filter((message) => message.y - small.y === LABEL_OFFSET);
  const noted = rawSteps.filter((step) => small.y - step.y === NOTE_OFFSET);
  if (labelled.length + noted.length !== 1) {
    errors.push(
      `${diagramPath}: the text "${small.text}" at (${small.x},${small.y}) is ${labelled.length} message ` +
      `label(s) and ${noted.length} step note(s). Every small text in this diagram sits exactly ` +
      `${LABEL_OFFSET} above a message or exactly ${NOTE_OFFSET} below a step; one that sits at neither ` +
      'offset has been moved, and this gate does not guess what it now qualifies.');
    continue;
  }
  if (labelled.length === 1) {
    if (labelled[0].label !== undefined) {
      errors.push(`${diagramPath}: the message at y=${labelled[0].y} carries more than one label.`);
      continue;
    }
    labelled[0].label = small.text;
  } else {
    rawNotes.push({ kind: 'note', y: small.y, step: noted[0].number, text: small.text });
  }
}
for (const message of rawMessages) {
  if (message.label === undefined) message.label = null;
}

if (participants.length === 0 || rawSteps.length === 0 || rawMessages.length === 0) {
  errors.push(`${diagramPath}: the diagram did not parse into participants, steps and messages; this check would pass over nothing.`);
}

// The controlled sequence: everything, in the order it happens down the page.
const controlled = [...rawSteps, ...rawMessages, ...rawNotes].sort((a, b) => a.y - b.y);

// -- 2. The map, against it. -------------------------------------------------------------

const nameOfId = new Map((map.participants ?? []).map((participant) => [participant.id, participant.name]));
for (const participant of map.participants ?? []) {
  if (!participants.some((item) => item.name === participant.name)) {
    errors.push(
      `${mapPath}: participant "${participant.id}" is declared as "${participant.name}", which the ` +
      'controlled diagram does not contain.');
  }
}
for (const participant of participants) {
  if (![...nameOfId.values()].includes(participant.name)) {
    errors.push(`${mapPath}: the controlled participant "${participant.name}" is declared nowhere.`);
  }
}

const sources = new Map();
async function sourceOf(path) {
  if (!sources.has(path)) {
    sources.set(path, await readFile(resolve(root, path), 'utf8').catch(() => null));
  }
  return sources.get(path);
}

// Every source a participant names must exist. A map pointing at a deleted file would
// otherwise fail only on the bindings that happen to use it.
for (const participant of map.participants ?? []) {
  for (const path of [...(participant.sources ?? []), ...(participant.surface ? [participant.surface] : [])]) {
    if ((await sourceOf(path)) === null) {
      errors.push(`${mapPath}: participant "${participant.id}" names ${path}, which does not exist.`);
    }
  }
}

/**
 * Whether a symbol appears on a line that is not a comment.
 *
 * Line-based and deliberately crude: it recognises the single-line and documentation
 * comment forms the C#, C++ and TypeScript in this repository actually use, and it does
 * not attempt to track block-comment state or string literals. A symbol that appears both
 * in a comment and in code is code, which is the direction that matters; the failure mode
 * left open is a symbol inside a multi-line `/* ... *\/` block being read as code, which
 * overstates nothing a reviewer would not see.
 */
const inCode = (source, symbol) => source
  .split(/\r?\n/)
  .filter((line) => {
    const trimmed = line.trim();
    return !trimmed.startsWith('//') && !trimmed.startsWith('*') && !trimmed.startsWith('/*') && !trimmed.startsWith('#');
  })
  .some((line) => line.includes(symbol));

const describe = (element) => {
  if (element.kind === 'step') return `step ${element.number} "${element.text}"`;
  if (element.kind === 'note') return `note on step ${element.step} "${element.text}"`;
  return `message ${element.from} -> ${element.to}` + (element.label ? ` "${element.label}"` : ' (unlabelled)');
};

const declared = map.sequence ?? [];
if (declared.length !== controlled.length) {
  errors.push(
    `${mapPath}: declares ${declared.length} sequence elements; the controlled diagram contains ` +
    `${controlled.length}. Every controlled element is declared exactly once, in order.`);
}

for (let index = 0; index < Math.max(declared.length, controlled.length); index += 1) {
  const expected = controlled[index];
  const actual = declared[index];
  if (!expected) {
    errors.push(`${mapPath}: element ${index + 1} (${describe(actual)}) is declared beyond the end of the controlled sequence.`);
    continue;
  }
  if (!actual) {
    errors.push(`${mapPath}: the controlled ${describe(expected)} is declared nowhere.`);
    continue;
  }

  const at = `${mapPath}: element ${index + 1}`;
  if (actual.kind !== expected.kind) {
    errors.push(`${at} is declared a ${actual.kind}; the controlled diagram has a ${expected.kind} there (${describe(expected)}).`);
    continue;
  }
  if (actual.text !== expected.text) {
    errors.push(`${at} is declared "${actual.text}"; the controlled diagram reads "${expected.text}".`);
  }
  if (expected.kind === 'step' && actual.number !== expected.number) {
    errors.push(`${at} is declared step ${actual.number}; the controlled diagram numbers it ${expected.number}.`);
  }
  if (expected.kind === 'note' && actual.step !== expected.step) {
    errors.push(`${at} is declared as qualifying step ${actual.step}; the controlled diagram places it under step ${expected.step}.`);
  }
  if (expected.kind === 'message') {
    const from = nameOfId.get(actual.from);
    const to = nameOfId.get(actual.to);
    if (from !== expected.from || to !== expected.to) {
      errors.push(
        `${at} is declared ${from ?? actual.from} -> ${to ?? actual.to}; the controlled diagram draws ` +
        `${expected.from} -> ${expected.to}. Direction is the message.`);
    }
    if ((actual.label ?? null) !== expected.label) {
      errors.push(`${at} is labelled "${actual.label ?? ''}"; the controlled diagram labels it "${expected.label ?? ''}".`);
    }
    if (Boolean(actual.guarded) !== expected.guarded) {
      errors.push(
        `${at} is declared ${actual.guarded ? '' : 'not '}locally guarded; the controlled diagram draws it in ` +
        `${expected.guarded ? 'amber, which is its marking for a locally guarded exchange' : 'blue'}. ` +
        'CH1-CMD-FR-0005 forbids a remote interface emulating, bridging or bypassing a guarded one.');
    }
  }

  // Bound, or declared absent. There is no third answer.
  const bindings = actual.boundTo ?? actual.enforcedBy ?? null;
  const absent = actual.notImplemented ?? null;
  if (bindings && absent) {
    errors.push(`${at} (${describe(expected)}) is both bound and declared not implemented.`);
    continue;
  }
  if (!bindings && !absent) {
    errors.push(
      `${at} (${describe(expected)}) is neither bound to an implementation nor declared not implemented ` +
      'with a reason. A controlled step that is silently unrealised is the failure this gate exists for.');
    continue;
  }
  if (absent) {
    if (!absent.reason || absent.reason.trim().length < 40) {
      errors.push(`${at} (${describe(expected)}) is declared not implemented without a stated reason.`);
    }
    if (!absent.recordedIn) {
      errors.push(
        `${at} (${describe(expected)}) is declared not implemented and records the decision nowhere. ` +
        'An unimplemented controlled step must be reported, not merely known here.');
    } else if ((await sourceOf(absent.recordedIn)) === null) {
      errors.push(`${at} records its decision in ${absent.recordedIn}, which does not exist.`);
    }
    continue;
  }

  if (!Array.isArray(bindings) || bindings.length === 0) {
    errors.push(`${at} (${describe(expected)}) declares an empty binding list.`);
    continue;
  }
  for (const binding of bindings) {
    const source = await sourceOf(binding.source);
    if (source === null) {
      errors.push(`${at} (${describe(expected)}) names ${binding.source}, which does not exist.`);
      continue;
    }
    if (!source.includes(binding.symbol)) {
      errors.push(
        `${at} (${describe(expected)}) is bound to "${binding.symbol}" in ${binding.source}, which does ` +
        'not contain it. Either the implementation moved and the map did not, or the controlled step is no longer realised.');
      continue;
    }
    // Present, but present in CODE. This suite's own first run found the reason: the
    // binding "acknowledgements" was deleted from the response projection and the gate
    // passed, because the XML documentation above it still said the word. A comment
    // describing a control is not the control, and a gate that accepts one is a gate
    // that approves the comment.
    if (!inCode(source, binding.symbol)) {
      errors.push(
        `${at} (${describe(expected)}) is bound to "${binding.symbol}", which appears in ` +
        `${binding.source} only inside comments. A comment describing a control is not the control.`);
    }
  }
}

// -- 3. Report. --------------------------------------------------------------------------

if (errors.length > 0) {
  console.error(`PREPARE / LOCAL COMMIT sequence check FAILED (${errors.length}).`);
  for (const error of errors) console.error(`  - ${error}`);
  process.exit(1);
}

const bound = declared.filter((element) => element.boundTo || element.enforcedBy).length;
const stated = declared.filter((element) => element.notImplemented).length;
console.log(
  `PREPARE / LOCAL COMMIT sequence reconciled against ${diagramPath}: ` +
  `${participants.length} participants, ${rawSteps.length} steps, ${rawMessages.length} messages ` +
  `(${rawMessages.filter((message) => message.guarded).length} locally guarded), ${rawNotes.length} controlled notes. ` +
  `${bound} elements bound to implementation, ${stated} declared not implemented with a recorded reason.`);
