#!/usr/bin/env sh
# Generates the laboratory PKI the MQTT edge needs, and nothing beyond it.
#
# CH1-COM-IF-0004 and CH1-COM-IF-0005 both put mutual TLS with per-identity certificates
# on the MQTT edge, and infrastructure/mosquitto/config/mosquitto.conf already requires
# them: require_certificate true, use_identity_as_username true, TLS 1.3 only. Nothing
# generated them, so the protocol lab could not start.
#
# This is a LABORATORY certificate authority. It is not the PKI CH1-CYB-IAM-0001
# describes: that one keeps root credentials hardware-backed and issues device
# certificates through a controlled provisioning ceremony, and this platform is a trust
# registry rather than a certificate authority — enrolment accepts a certificate the
# device generated in its own secure element and refuses a submitted private key. What is
# produced here exists to exercise the transport, and every artefact says so in its
# subject organisational unit.
#
# Output goes to infrastructure/secrets/mqtt, which .gitignore excludes. No key is ever
# printed, committed, or written anywhere else.
#
# Usage: scripts/bootstrap-mqtt-pki.sh [--force]
set -eu

# Git Bash rewrites any argument that looks like a POSIX path into a Windows one before
# the process sees it, so "/O=Cinerion/OU=…/CN=…" arrives at openssl as
# "C:/Program Files/Git/…" and the subject is rejected. Both variables are needed: the
# first governs MSYS2 builds, the second older MSYS. Harmless everywhere else.
MSYS_NO_PATHCONV=1
MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV MSYS2_ARG_CONV_EXCL

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
out="$repo_dir/infrastructure/secrets/mqtt"
force=false
[ "${1:-}" = "--force" ] && force=true

if [ -f "$out/ca.crt" ] && [ "$force" != true ]; then
  echo "MQTT laboratory PKI already present in $out. Pass --force to regenerate."
  exit 0
fi

mkdir -p "$out"
cd "$out"

# The identity in the subject common name is what mosquitto uses as the MQTT username,
# because use_identity_as_username is on. The topic ACL is written against exactly these
# names, so a certificate is not merely an authentication: it is the authorisation.
broker_cn=${CINERION_MQTT_BROKER_CN:-localhost}
edgelink_cn=${CINERION_MQTT_CLIENT_ID:-ch1-edgelink}
device_cn=${CINERION_MQTT_DEVICE_ID:-CH1-DEV-CELL-0001}

echo "Generating a laboratory certificate authority…"
openssl req -x509 -newkey rsa:4096 -sha256 -days 365 -nodes \
  -keyout ca.key -out ca.crt \
  -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=Cinerion CH1 Laboratory CA" \
  -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

issue() {
  name=$1
  common_name=$2
  extension=$3
  echo "Issuing $name as CN=$common_name…"
  openssl req -newkey rsa:3072 -sha256 -nodes \
    -keyout "$name.key" -out "$name.csr" \
    -subj "/O=Cinerion/OU=P03-IFV-LABORATORY-ONLY/CN=$common_name"
  printf '%s\n' "$extension" > "$name.ext"
  openssl x509 -req -in "$name.csr" -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out "$name.crt" -days 365 -sha256 -extfile "$name.ext"
  rm -f "$name.csr" "$name.ext"
}

# The broker proves it is the host the client asked for. A subject alternative name is
# not optional decoration: without it the client cannot check that it reached the broker
# it intended rather than one that merely holds a certificate this CA signed.
issue broker "$broker_cn" "subjectAltName=DNS:$broker_cn,DNS:mqtt,IP:127.0.0.1
extendedKeyUsage=serverAuth
keyUsage=critical,digitalSignature,keyEncipherment"

# Client certificates carry clientAuth only. A client certificate that also asserted
# serverAuth could be presented by something impersonating the broker.
issue edgelink "$edgelink_cn" "extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"
issue device "$device_cn" "extendedKeyUsage=clientAuth
keyUsage=critical,digitalSignature,keyEncipherment"

# Mosquitto runs unprivileged inside its container and reads these read-only.
chmod 644 ./*.crt 2>/dev/null || true
chmod 600 ./*.key 2>/dev/null || true
rm -f ca.srl

echo
echo "Laboratory PKI written to infrastructure/secrets/mqtt (git-ignored):"
echo "  ca.crt         the trust anchor both ends validate against"
echo "  broker.crt/key CN=$broker_cn, serverAuth"
echo "  edgelink.crt/key CN=$edgelink_cn, clientAuth — the gateway's MQTT username"
echo "  device.crt/key   CN=$device_cn, clientAuth — the device's MQTT username"
echo
echo "These are laboratory credentials for exercising the transport. CH1-CYB-IAM-0001"
echo "keeps real device keys non-exportable in a secure element, and this platform"
echo "refuses a submitted private key at enrolment for exactly that reason."
