// Lays every rendered portal screen out in a REAL browser and refuses the two shapes a
// broken flex row leaves behind.
//
// Why this exists: the render gate drives all 22 screens through jsdom, and jsdom never
// computes a single box. Every width it knows is zero. So when the Security screen's
// title got squeezed into one letter per line by a fifteen-role pill that refused to
// shrink, 630 checks stayed green and the owner found it with a screenshot. A test that
// cannot see layout cannot fail on layout. This one can.
//
// How it works, with nothing new installed and no network:
//   1. the render gate (run with CINERION_RENDER_SNAPSHOT_DIR) freezes each scenario's
//      final page, styles and all, into a plain HTML file;
//   2. this script starts the Chrome or Edge already on the machine, headless, with a
//      throwaway profile, and talks to it over the DevTools protocol using Node's own
//      WebSocket;
//   3. each snapshot is opened at 1180, 1440 and 1920 px - 1180 being the narrowest width
//      at which any screen still uses its desktop layout - and measured.
//
// It refuses:
//   * anything past the right edge of the window that isn't inside a scroller
//     ("past-window") - the pill that ran off the screen;
//   * text in a box under 30 px wide and over four lines tall ("squeezed-text") - the
//     title that became a vertical word search;
//   * a page that scrolls sideways.
//
// Positive control first, because a gate looking for ABSENCE prints the same thing for a
// clean screen and a broken search (handover item 79). A little page that HAS both bugs is
// audited before anything else, and if the audit doesn't catch both, nothing it says about
// the real screens counts.
//
//   npm run layout:portal              (reads artifacts/render-snapshots/pipeline)
//   npm run layout:portal -- <dir>     (any snapshot directory)

import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdtemp, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const snapshotDir = resolve(root, process.argv[2] ?? 'artifacts/render-snapshots/pipeline');
const WIDTHS = [1180, 1440, 1920];

// -- Find a browser. ----------------------------------------------------------------------

const candidates = [
  process.env.CINERION_CHROME,
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  '/usr/bin/google-chrome',
  '/usr/bin/google-chrome-stable',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
].filter(Boolean);
const browser = candidates.find((path) => existsSync(path));

if (!browser) {
  // A failure, not a skip. Defect 51 was a strict pipeline reporting "could not run" as fine.
  console.error(
    'FAIL  No Chromium browser found, so no screen was laid out and nothing about layout is known. ' +
    `Looked in: ${candidates.join(', ')}. Set CINERION_CHROME to a Chrome or Edge executable.`);
  process.exit(1);
}

if (!existsSync(snapshotDir)) {
  console.error(
    `FAIL  No render snapshots at ${snapshotDir}. Produce them with:\n` +
    '      CINERION_RENDER_SNAPSHOT_DIR=artifacts/render-snapshots/pipeline npm run render:portal');
  process.exit(1);
}
const pages = (await readdir(snapshotDir)).filter((name) => name.endsWith('.html')).sort();
if (pages.length === 0) {
  console.error(`FAIL  ${snapshotDir} holds no snapshots, so this gate would establish nothing.`);
  process.exit(1);
}

// -- The audit that runs inside the page. --------------------------------------------------
//
// Kept as a string because it executes in the browser, not here. Deepest-first for the
// overflow check, so one runaway pill is reported once and not once per ancestor.

const AUDIT = `(() => {
  const vw = document.documentElement.clientWidth;
  const findings = [];
  const scrollsX = (el) => {
    for (let a = el.parentElement; a && a !== document.body; a = a.parentElement) {
      const o = getComputedStyle(a).overflowX;
      if (o === 'auto' || o === 'scroll') return true;
    }
    return false;
  };
  const past = [];
  for (const el of document.body.querySelectorAll('*')) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    if (r.right > vw + 1 && !scrollsX(el)) past.push(el);
  }
  const deepest = past.filter((el) => !past.some((o) => o !== el && el.contains(o)));
  for (const el of deepest.slice(0, 3)) {
    findings.push({ kind: 'past-window', right: Math.round(el.getBoundingClientRect().right), vw,
      text: (el.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 60) });
  }
  for (const el of document.body.querySelectorAll('*')) {
    const own = [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join('').trim();
    if (own.length < 6) continue;
    const r = el.getBoundingClientRect();
    const size = parseFloat(getComputedStyle(el).fontSize) || 12;
    // Zero width counts. Measured on the real broken Security screen: the title's box was
    // exactly 0px wide and 836px tall, letters spilling out of an empty column. The first
    // version of this rule said "width > 0" and would have stepped right over it.
    if (r.width < 30 && r.height > 4 * size) {
      findings.push({ kind: 'squeezed-text', width: Math.round(r.width), height: Math.round(r.height), text: own.slice(0, 50) });
    }
  }
  const scrollWidth = document.scrollingElement.scrollWidth;
  if (scrollWidth > vw + 1) findings.push({ kind: 'page-scrolls-sideways', scrollWidth, vw });
  return findings;
})()`;

// -- A tiny DevTools client. ---------------------------------------------------------------

const profile = await mkdtemp(join(tmpdir(), 'cinerion-layout-'));
const chrome = spawn(browser, [
  '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  '--hide-scrollbars', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank',
], { stdio: 'ignore' });

let socket;
async function shutdown() {
  try { socket?.close(); } catch { /* already gone */ }
  chrome.kill();
  // Chrome holds its profile open for a beat after it's told to stop.
  for (let attempt = 0; attempt < 10; attempt += 1) {
    try { await rm(profile, { recursive: true, force: true }); return; } catch { await sleep(200); }
  }
}
const sleep = (ms) => new Promise((done) => setTimeout(done, ms));

// Chrome writes the port it picked into the profile once it's listening.
const portFile = join(profile, 'DevToolsActivePort');
let endpoint;
for (let waited = 0; waited < 20_000 && !endpoint; waited += 100) {
  if (existsSync(portFile)) {
    const [port, path] = (await readFile(portFile, 'utf8')).split(/\r?\n/);
    if (port && path) endpoint = `ws://127.0.0.1:${port}${path}`;
  }
  if (!endpoint) await sleep(100);
}
if (!endpoint) {
  await shutdown();
  console.error(`FAIL  ${browser} never opened its debugging port, so no screen was laid out.`);
  process.exit(1);
}

socket = new WebSocket(endpoint);
await new Promise((ready, broke) => { socket.onopen = ready; socket.onerror = broke; });
let nextId = 0;
const pending = new Map();
const listeners = new Set();
socket.onmessage = (event) => {
  const message = JSON.parse(event.data);
  if (message.id !== undefined && pending.has(message.id)) {
    const { resolve: done, reject } = pending.get(message.id);
    pending.delete(message.id);
    if (message.error) reject(new Error(message.error.message)); else done(message.result);
  } else {
    for (const listener of listeners) listener(message);
  }
};
const send = (method, params = {}, sessionId) => new Promise((done, reject) => {
  const id = ++nextId;
  pending.set(id, { resolve: done, reject });
  socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
});

const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
await send('Page.enable', {}, sessionId);

async function audit(url, width) {
  await send('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: false }, sessionId);
  const loaded = new Promise((done) => {
    const listener = (message) => {
      if (message.method === 'Page.loadEventFired' && message.sessionId === sessionId) {
        listeners.delete(listener);
        done();
      }
    };
    listeners.add(listener);
  });
  await send('Page.navigate', { url }, sessionId);
  await Promise.race([loaded, sleep(10_000)]);
  const { result } = await send('Runtime.evaluate', { expression: AUDIT, returnByValue: true }, sessionId);
  return result.value ?? [];
}

const errors = [];

try {
  // -- 1. POSITIVE CONTROL. -------------------------------------------------------------
  //
  // The exact bug from the owner's screenshot, rebuilt in twenty lines: a title column that
  // may shrink to nothing beside a pill that may not shrink at all.
  //
  // The text carries react-native-web's own Text styles (pre-wrap + break-word). The first
  // version of this control left them out, and plain CSS lets a word in a zero-width box
  // spill out whole instead of breaking into letters - so the control caught the runaway
  // pill and missed the squeezed title, and this gate refused itself. Which is the job.
  const text = 'white-space:pre-wrap;overflow-wrap:break-word';
  const controlPath = join(profile, 'positive-control.html');
  await writeFile(controlPath, `<!doctype html><html><body style="margin:0;font-family:sans-serif">
    <div style="display:flex;flex-direction:row;gap:24px;padding:24px">
      <div style="flex:1 1 0%;min-width:0">
        <div style="font-size:9px;${text}">CH1-UX-SCR-0013 / FORTRESSGATE</div>
        <div style="font-size:28px;font-weight:800;${text}">Security administration</div>
      </div>
      <div style="flex-shrink:0;white-space:nowrap;font-size:11px">${
        Array.from({ length: 15 }, (_, i) => `ROLENUMBER${i}`).join(' · ')}</div>
    </div></body></html>`, 'utf8');
  const control = await audit(pathToFileURL(controlPath).href, 1440);
  const caught = new Set(control.map((finding) => finding.kind));
  if (!caught.has('squeezed-text') || !caught.has('past-window')) {
    errors.push(
      'POSITIVE CONTROL FAILED: a page built to contain both a squeezed title and a runaway pill was ' +
      `audited and the audit reported [${[...caught].join(', ') || 'nothing'}]. Nothing this gate says ` +
      'about the real screens can be believed until it catches its own example.');
  }

  // -- 2. The real screens. -------------------------------------------------------------
  let measured = 0;
  if (errors.length === 0) {
    for (const page of pages) {
      const url = pathToFileURL(join(snapshotDir, page)).href;
      for (const width of WIDTHS) {
        const findings = await audit(url, width);
        measured += 1;
        for (const finding of findings) {
          const where = finding.kind === 'squeezed-text'
            ? `"${finding.text}" is ${finding.width}px wide and ${finding.height}px tall`
            : finding.kind === 'past-window'
              ? `an element reaches ${finding.right}px in a ${finding.vw}px window${finding.text ? ` ("${finding.text}")` : ''}`
              : `the page is ${finding.scrollWidth}px wide in a ${finding.vw}px window`;
          errors.push(`${page.replace(/\.html$/, '')} at ${width}px: ${finding.kind} - ${where}.`);
        }
      }
    }
  }

  if (errors.length > 0) {
    for (const error of errors) console.error(`FAIL  ${error}`);
    console.error(`\nPortal layout: ${errors.length} refusal(s).`);
    process.exitCode = 1;
  } else {
    console.log(
      `Positive control: a page carrying both bugs from the owner's screenshot was caught for both ` +
      `(${[...caught].join(', ')}), so the silence below is a measurement.`);
    console.log(
      `Portal layout held in a real browser: ${pages.length} rendered screens x ${WIDTHS.length} widths ` +
      `(${WIDTHS.join(', ')} px) = ${measured} layouts, with nothing past the window, no squeezed text ` +
      'and no page scrolling sideways.');
    console.log(`Browser: ${browser.split(/[\\/]/).pop()}, headless, throwaway profile.`);
    console.log(
      'NOT ESTABLISHED: the compact (under 980 px) branch - these snapshots were rendered for a ' +
      'desktop window, and a narrower window takes a different branch the snapshot does not contain.');
  }
} finally {
  await shutdown();
}
