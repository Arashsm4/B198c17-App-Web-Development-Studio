#!/usr/bin/env sh
# A quick poke at a running API to check it's alive and answering.

set -eu

api_url=${CINERION_API_URL:-http://localhost:5080}
project_id=00000000-0000-4000-8000-000000000101
cell_id=00000000-0000-4000-8000-000000000103

echo "Checking public health and explicit simulation marking..."
health=$(curl --fail --silent --show-error "$api_url/api/v1/system/health")
echo "$health" | grep '"simulation":true'

echo "Checking anonymous access is rejected..."
anonymous_status=$(curl --silent --output /tmp/cinerion-anonymous-response.json --write-out '%{http_code}' "$api_url/api/v1/projects")
if [ "$anonymous_status" != "401" ]; then
  echo "Expected 401, received $anonymous_status"
  exit 1
fi

echo "Checking authenticated project and cell scope..."
curl --fail --silent --show-error \
  -H "X-CH1-Actor: IR" \
  -H "X-CH1-Project: $project_id" \
  -H "X-CH1-Roles: Engineer,Auditor" \
  -H "X-CH1-Cells: $cell_id" \
  -H "X-CH1-Auth-Strength: StepUpPhishingResistant" \
  "$api_url/api/v1/cells/$cell_id/state"

echo "Checking audit-chain verification endpoint..."
curl --fail --silent --show-error --request POST \
  -H "X-CH1-Actor: IR" \
  -H "X-CH1-Project: $project_id" \
  -H "X-CH1-Roles: Engineer,Auditor" \
  -H "X-CH1-Cells: $cell_id" \
  -H "X-CH1-Auth-Strength: StepUpPhishingResistant" \
  "$api_url/api/v1/audit/chain-verifications"

echo "Cinerion API smoke checks passed."
