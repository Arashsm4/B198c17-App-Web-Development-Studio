# Sets up local secrets and config on Windows so the labs can start.
#
# Writes infrastructure/.env.local with every value the lab needs. If the file already exists
# it is TOPPED UP, never rewritten: a value that is already there stays exactly as it is,
# because the database and identity volumes were initialised with it and a new one would lock
# the lab out of its own data. Only missing keys are added. See bootstrap-local.sh for the
# story of the two values the first version forgot.

$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Target = Join-Path $Repo 'infrastructure/.env.local'

# RandomNumberGenerator.Fill is .NET Core only and is absent from the .NET Framework
# runtime behind Windows PowerShell 5.1. Create()/GetBytes is cryptographically
# equivalent and available on both, so the script works on either shell.
function Get-RandomBytes([int]$Count) {
    $bytes = [byte[]]::new($Count)
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return $bytes
}

function New-CinerionSecret {
    [Convert]::ToBase64String((Get-RandomBytes 36))
}

# Unbiased pick from a set, so no character is favoured over another.
function Get-RandomIndex([int]$Size) {
    $limit = [uint32]::MaxValue - ([uint32]::MaxValue % $Size)
    do { $value = [BitConverter]::ToUInt32((Get-RandomBytes 4), 0) } while ($value -ge $limit)
    return [int]($value % $Size)
}

# The realm wants 14+ characters with a digit, upper, lower and a special character. Each
# class is guaranteed, then the lot is shuffled. No quote, backslash or dollar sign: the value
# travels inside JSON and through Compose's env-file reader.
function New-DemoPassword {
    $sets = @('ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnopqrstuvwxyz', '23456789', '!@#%-_.')
    $all = -join $sets
    $chars = New-Object System.Collections.Generic.List[char]
    foreach ($set in $sets) { $chars.Add($set[(Get-RandomIndex $set.Length)]) }
    while ($chars.Count -lt 24) { $chars.Add($all[(Get-RandomIndex $all.Length)]) }
    for ($i = $chars.Count - 1; $i -gt 0; $i--) {
        $j = Get-RandomIndex ($i + 1)
        $swap = $chars[$i]; $chars[$i] = $chars[$j]; $chars[$j] = $swap
    }
    return -join $chars
}

$created = $false
$lines = New-Object System.Collections.Generic.List[string]
if (Test-Path $Target) {
    foreach ($line in [System.IO.File]::ReadAllLines($Target)) { $lines.Add($line) }
} else {
    $lines.Add('# Generated local-only secrets. Never commit, publish, or reuse these values.')
    $created = $true
}

$wanted = [ordered]@{
    CINERION_POSTGRES_PASSWORD       = { New-CinerionSecret }
    CINERION_KEYCLOAK_DB_PASSWORD    = { New-CinerionSecret }
    CINERION_KEYCLOAK_ADMIN          = { 'cinerion-local-admin' }
    CINERION_KEYCLOAK_ADMIN_PASSWORD = { New-CinerionSecret }
    CINERION_MQTT_SECRETS_DIR        = { './secrets/mqtt' }
    CINERION_APP_PASSWORD            = { New-CinerionSecret }
    CINERION_PORTAL_DEMO_PASSWORD    = { New-DemoPassword }
}

$added = @()
foreach ($key in $wanted.Keys) {
    if (-not ($lines | Where-Object { $_ -like "$key=*" })) {
        $lines.Add("$key=$(& $wanted[$key])")
        $added += $key
    }
}

# UTF-8 without a byte-order mark and with LF endings, because sh reads this file too.
[System.IO.File]::WriteAllText($Target, (($lines -join "`n") + "`n"), [System.Text.UTF8Encoding]::new($false))

if ($created) {
    Write-Host 'Created infrastructure/.env.local with fresh local-only secrets.'
} elseif ($added.Count -gt 0) {
    Write-Host "Topped up infrastructure/.env.local; added: $($added -join ', '). Existing values were left alone."
} else {
    Write-Host 'infrastructure/.env.local already has every value the lab needs; nothing changed.'
}
Write-Host 'Remove the Keycloak bootstrap credential after initial provisioning.'
