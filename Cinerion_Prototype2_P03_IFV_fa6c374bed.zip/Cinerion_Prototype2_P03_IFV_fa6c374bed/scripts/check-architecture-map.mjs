// Reconciles the repository against the CONTROLLED cross-layer architecture.
//
// The third and last of the frozen baseline's SVG twins. CH1-SYS-SAD-0001 describes the
// architecture in prose and refers the structure to `assets/system-architecture.png`;
// `assets/system-architecture.svg` sits beside it, and a layer diagram in SVG is a
// topology with coordinates rather than a picture of one.
//
// The geometry is exact:
//
//   * six layer bands, each a <rect> 1460 wide, at disjoint y ranges;
//   * fourteen component boxes, each wholly inside exactly one band, named by the
//     <text class="box"> inside it;
//   * four vertical connectors, each running from one band's bottom edge to the next
//     band's top edge - two blue, two amber, where amber is the diagram's own marking
//     for a guarded crossing;
//   * one horizontal dashed purple edge inside the research band: an isolation boundary,
//     not a call.
//
// Nothing here is a nearest match. A connector whose endpoints are not exactly a band
// edge, or a box that straddles two bands, is an error - a gate that rounded either would
// approve an authority boundary that had moved.
//
// What reading it establishes, which prose alone did not:
//
//   * the experience layer has exactly ONE edge, and it goes to the domain layer. There
//     is no connector from it to the protocol or local bands, which is the topology
//     stating what the portal's absent commit control states in code;
//   * the only connector leaving the domain band departs in CommandGuard's column, is
//     amber, and skips the research band entirely;
//   * the research band has no connector at all, in either direction. "Isolated
//     credentials, no production route" is not a caption - it is what the diagram draws,
//     and `isolation` below checks the project graph against it rather than trusting it;
//   * the Local HMI is a controlled component with five assigned GPIOs and no behaviour.
//     It is declared not implemented here, which is the point of making a component
//     register at all: a controlled box nobody built is otherwise visible to nothing.
//
// What it refuses:
//
//   * the diagram no longer parsing into six bands, fourteen components and five edges,
//     or any box or endpoint that does not resolve to exactly one band;
//   * a controlled layer, component or edge the map does not declare;
//   * a declared layer, component or edge the diagram does not draw - the direction that
//     matters, because an invented edge is how a layer would quietly gain an authority;
//   * a component declared in the wrong band;
//   * a component that is neither bound to repository paths that exist nor declared not
//     implemented with a reason, and an edge likewise;
//   * a project reference that crosses the isolation boundary in either direction.
//
// What it does NOT do. It does not verify that a bound path implements its component,
// only that the path exists and, for an edge, that the named symbol is present. Layer
// adherence in .NET is checked where it is mechanical - the isolation boundary, from
// every .csproj in the tree - and not inferred anywhere else. A component whose code
// grew a dependency the diagram does not draw is invisible here unless that dependency
// crosses into or out of simulators/.
//
// It announces no controlled verification case, for the reason recorded as conflict 31.

import { readFile, readdir, stat } from 'node:fs/promises';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const diagramPath = 'docs/baseline/P03_IFV/assets/system-architecture.svg';
const mapPath = 'traceability/system-architecture-r01.json';

const svg = await readFile(resolve(root, diagramPath), 'utf8');
const map = JSON.parse(await readFile(resolve(root, mapPath), 'utf8'));

const attribute = (attributes, name) => {
  const match = attributes.match(new RegExp('\\b' + name + '="([^"]*)"'));
  return match ? match[1] : null;
};
const number = (attributes, name) => {
  const value = attribute(attributes, name);
  return value === null ? null : Number(value);
};

// -- 1. The controlled diagram, parsed. --------------------------------------------------

const rectangles = [...svg.matchAll(/<rect\b([^>]*)\/>/g)]
  .map((match) => ({
    x: number(match[1], 'x'),
    y: number(match[1], 'y'),
    width: number(match[1], 'width'),
    height: number(match[1], 'height'),
    stroke: attribute(match[1], 'stroke'),
  }))
  // The page background carries no x. Everything else in this diagram is a band or a box.
  .filter((box) => box.x !== null && box.y !== null && box.width !== null && box.height !== null);

const texts = [...svg.matchAll(/<text\b([^>]*)>([^<]*)<\/text>/g)].map((match) => ({
  x: number(match[1], 'x'),
  y: number(match[1], 'y'),
  cls: attribute(match[1], 'class'),
  text: match[2].trim(),
}));

const inside = (box, x, y) =>
  x >= box.x && x <= box.x + box.width && y >= box.y && y <= box.y + box.height;

// A band is a full-width rectangle. The width is the diagram's own distinction and is
// used rather than a threshold: every band is 1460 wide and no component box is.
const BAND_WIDTH = 1460;
const bands = rectangles
  .filter((box) => box.width === BAND_WIDTH)
  .map((box) => {
    const labels = texts.filter(
      (item) => (item.cls === 'layer' || item.cls === 'white') && inside(box, item.x, item.y));
    if (labels.length !== 1) {
      errors.push(
        `${diagramPath}: the band at y=${box.y} carries ${labels.length} layer labels. ` +
        'A band naming no layer, or two, is not a layer this gate will guess at.');
      return null;
    }
    return { ...box, name: labels[0].text };
  })
  .filter(Boolean)
  .sort((a, b) => a.y - b.y);

for (let index = 1; index < bands.length; index += 1) {
  if (bands[index].y <= bands[index - 1].y + bands[index - 1].height) {
    errors.push(
      `${diagramPath}: the bands "${bands[index - 1].name}" and "${bands[index].name}" overlap. ` +
      'Overlapping bands make a component box ambiguous between two layers.');
  }
}

const components = [];
for (const box of rectangles.filter((item) => item.width !== BAND_WIDTH)) {
  const names = texts.filter((item) => item.cls === 'box' && inside(box, item.x, item.y));
  if (names.length !== 1) {
    errors.push(
      `${diagramPath}: the component box at (${box.x},${box.y}) carries ${names.length} names.`);
    continue;
  }
  const holders = bands.filter(
    (band) => box.y >= band.y && box.y + box.height <= band.y + band.height);
  if (holders.length !== 1) {
    errors.push(
      `${diagramPath}: the component "${names[0].text}" is wholly inside ${holders.length} bands. ` +
      'A component that straddles a layer boundary has no layer, and this gate does not pick one.');
    continue;
  }
  components.push({ name: names[0].text, layer: holders[0].name, box });
}

// Edges. A vertical connector runs between two band edges; a horizontal one runs between
// two component boxes inside one band.
const layerEdges = [];
const componentEdges = [];
for (const match of svg.matchAll(/<path\b([^>]*)\/>/g)) {
  const cls = attribute(match[1], 'class');
  if (cls !== 'line' && cls !== 'guard' && cls !== 'isolate') continue;
  const d = attribute(match[1], 'd');
  const points = [...(d ?? '').matchAll(/-?[\d.]+/g)].map((value) => Number(value[0]));
  if (points.length !== 4) {
    errors.push(`${diagramPath}: the edge "${d}" is not a single straight segment.`);
    continue;
  }
  const [x1, y1, x2, y2] = points;

  if (x1 === x2) {
    // Vertical: from the bottom edge of one band to the top edge of the next.
    const from = bands.find((band) => band.y + band.height === y1);
    const to = bands.find((band) => band.y === y2);
    if (!from || !to) {
      errors.push(
        `${diagramPath}: the vertical edge "${d}" does not run from one band's bottom edge to ` +
        "another band's top edge. An endpoint this gate cannot resolve exactly is a changed " +
        'topology, not a rounding error.');
      continue;
    }
    // The column an amber edge departs in is evidence about which component holds the
    // authority, and it is recorded rather than asserted: the endpoint is on the band
    // edge, not on the box, so naming a component from it would be a guess.
    const column = components.filter(
      (component) => component.layer === from.name &&
        x1 >= component.box.x && x1 <= component.box.x + component.box.width);
    layerEdges.push({
      from: from.name,
      to: to.name,
      guarded: cls === 'guard',
      column: column.length === 1 ? column[0].name : null,
    });
    continue;
  }

  if (y1 === y2) {
    const resolve1 = (x) => components.filter((component) => inside(component.box, x, y1));
    const from = resolve1(x1);
    const to = resolve1(x2);
    if (from.length !== 1 || to.length !== 1) {
      errors.push(
        `${diagramPath}: the horizontal edge "${d}" has an endpoint touching ` +
        `${from.length !== 1 ? from.length : to.length} component boxes.`);
      continue;
    }
    componentEdges.push({ from: from[0].name, to: to[0].name, kind: cls === 'isolate' ? 'isolated' : 'call' });
    continue;
  }

  errors.push(`${diagramPath}: the edge "${d}" is neither vertical nor horizontal.`);
}

if (bands.length === 0 || components.length === 0 || layerEdges.length === 0) {
  errors.push(`${diagramPath}: the diagram did not parse into bands, components and edges; this check would pass over nothing.`);
}

// -- 2. The map, against it. -------------------------------------------------------------

const exists = async (path) => {
  try {
    await stat(resolve(root, path));
    return true;
  } catch {
    return false;
  }
};

const sources = new Map();
async function sourceOf(path) {
  if (!sources.has(path)) {
    sources.set(path, await readFile(resolve(root, path), 'utf8').catch(() => null));
  }
  return sources.get(path);
}

// Layers, in the diagram's own top-to-bottom order.
const declaredLayers = [...(map.layers ?? [])].sort((a, b) => a.order - b.order);
if (declaredLayers.length !== bands.length) {
  errors.push(`${mapPath}: declares ${declaredLayers.length} layers; the controlled diagram draws ${bands.length}.`);
}
for (let index = 0; index < Math.max(declaredLayers.length, bands.length); index += 1) {
  const expected = bands[index];
  const actual = declaredLayers[index];
  if (!expected) {
    errors.push(`${mapPath}: layer "${actual.name}" is declared below the last band the diagram draws.`);
  } else if (!actual) {
    errors.push(`${mapPath}: the controlled layer "${expected.name}" is declared nowhere.`);
  } else if (actual.name !== expected.name) {
    errors.push(
      `${mapPath}: layer ${index + 1} is declared "${actual.name}"; the controlled diagram has ` +
      `"${expected.name}" there. The order is the architecture.`);
  }
}

// Components.
const declaredComponents = new Map((map.components ?? []).map((item) => [item.name, item]));
for (const component of components) {
  const declaration = declaredComponents.get(component.name);
  if (!declaration) {
    errors.push(`${mapPath}: the controlled component "${component.name}" is declared nowhere.`);
    continue;
  }
  if (declaration.layer !== component.layer) {
    errors.push(
      `${mapPath}: "${component.name}" is declared in "${declaration.layer}"; the controlled ` +
      `diagram draws it in "${component.layer}".`);
  }
  const paths = declaration.paths ?? null;
  const absent = declaration.notImplemented ?? null;
  if (paths && absent) {
    errors.push(`${mapPath}: "${component.name}" is both bound and declared not implemented.`);
    continue;
  }
  if (!paths && !absent) {
    errors.push(
      `${mapPath}: "${component.name}" is neither bound to repository paths nor declared not ` +
      'implemented with a reason. A controlled component nobody built is otherwise visible to nothing.');
    continue;
  }
  if (absent) {
    if (!absent.reason || absent.reason.trim().length < 40) {
      errors.push(`${mapPath}: "${component.name}" is declared not implemented without a stated reason.`);
    }
    if (!absent.recordedIn) {
      errors.push(`${mapPath}: "${component.name}" is declared not implemented and records the decision nowhere.`);
    } else if (!(await exists(absent.recordedIn))) {
      errors.push(`${mapPath}: "${component.name}" records its decision in ${absent.recordedIn}, which does not exist.`);
    }
    continue;
  }
  if (paths.length === 0) {
    errors.push(`${mapPath}: "${component.name}" declares an empty path list.`);
  }
  for (const path of paths) {
    if (!(await exists(path))) {
      errors.push(`${mapPath}: "${component.name}" names ${path}, which does not exist.`);
    }
  }
}
for (const name of declaredComponents.keys()) {
  if (!components.some((component) => component.name === name)) {
    errors.push(`${mapPath}: component "${name}" is declared, and the controlled diagram does not draw it.`);
  }
}

// Edges.
const edgeKey = (edge) => `${edge.from} -> ${edge.to}`;
const controlledLayerEdges = new Map(layerEdges.map((edge) => [edgeKey(edge), edge]));
const declaredLayerEdges = map.layerEdges ?? [];
if (declaredLayerEdges.length !== layerEdges.length) {
  errors.push(`${mapPath}: declares ${declaredLayerEdges.length} layer edges; the controlled diagram draws ${layerEdges.length}.`);
}
for (const declaration of declaredLayerEdges) {
  const controlled = controlledLayerEdges.get(edgeKey(declaration));
  if (!controlled) {
    errors.push(
      `${mapPath}: the layer edge ${edgeKey(declaration)} is declared, and the controlled diagram ` +
      'does not draw it. An edge between layers is an authority, and inventing one here is how a ' +
      'boundary would be crossed without anyone deciding to cross it.');
    continue;
  }
  if (Boolean(declaration.guarded) !== controlled.guarded) {
    errors.push(
      `${mapPath}: the layer edge ${edgeKey(declaration)} is declared ${declaration.guarded ? '' : 'not '}` +
      `guarded; the controlled diagram draws it in ${controlled.guarded ? 'amber' : 'blue'}.`);
  }
  await reconcileBinding(declaration, `layer edge ${edgeKey(declaration)}`);
}
for (const edge of layerEdges) {
  if (!declaredLayerEdges.some((declaration) => edgeKey(declaration) === edgeKey(edge))) {
    errors.push(`${mapPath}: the controlled layer edge ${edgeKey(edge)} is declared nowhere.`);
  }
}

const controlledComponentEdges = new Map(componentEdges.map((edge) => [edgeKey(edge), edge]));
const declaredComponentEdges = map.componentEdges ?? [];
if (declaredComponentEdges.length !== componentEdges.length) {
  errors.push(`${mapPath}: declares ${declaredComponentEdges.length} component edges; the controlled diagram draws ${componentEdges.length}.`);
}
for (const declaration of declaredComponentEdges) {
  const controlled = controlledComponentEdges.get(edgeKey(declaration));
  if (!controlled) {
    errors.push(`${mapPath}: the component edge ${edgeKey(declaration)} is declared, and the controlled diagram does not draw it.`);
    continue;
  }
  if (declaration.kind !== controlled.kind) {
    errors.push(
      `${mapPath}: the component edge ${edgeKey(declaration)} is declared "${declaration.kind}"; ` +
      `the controlled diagram draws it "${controlled.kind}".`);
  }
  await reconcileBinding(declaration, `component edge ${edgeKey(declaration)}`);
}
for (const edge of componentEdges) {
  if (!declaredComponentEdges.some((declaration) => edgeKey(declaration) === edgeKey(edge))) {
    errors.push(`${mapPath}: the controlled component edge ${edgeKey(edge)} is declared nowhere.`);
  }
}

async function reconcileBinding(declaration, label) {
  const bindings = declaration.boundTo ?? null;
  const absent = declaration.notImplemented ?? null;
  if (bindings && absent) {
    errors.push(`${mapPath}: ${label} is both bound and declared not implemented.`);
    return;
  }
  if (!bindings && !absent) {
    errors.push(`${mapPath}: ${label} is neither bound to an implementation nor declared not implemented with a reason.`);
    return;
  }
  if (absent) {
    if (!absent.reason || absent.reason.trim().length < 40) {
      errors.push(`${mapPath}: ${label} is declared not implemented without a stated reason.`);
    }
    if (!absent.recordedIn) {
      errors.push(`${mapPath}: ${label} is declared not implemented and records the decision nowhere.`);
    } else if (!(await exists(absent.recordedIn))) {
      errors.push(`${mapPath}: ${label} records its decision in ${absent.recordedIn}, which does not exist.`);
    }
    return;
  }
  for (const binding of bindings) {
    const source = await sourceOf(binding.source);
    if (source === null) {
      errors.push(`${mapPath}: ${label} names ${binding.source}, which does not exist.`);
      continue;
    }
    if (!source.includes(binding.symbol)) {
      errors.push(`${mapPath}: ${label} is bound to "${binding.symbol}" in ${binding.source}, which does not contain it.`);
    }
  }
}

// -- 3. The isolation boundary, checked rather than asserted. ----------------------------
//
// The research band has no connector to any other band, and the Simulators box says "no
// production route". In this repository that has a mechanical form: the .NET project
// graph. A reference either way would be the production route the diagram says does not
// exist, and it would be invisible to every other gate here.

const isolation = map.isolation ?? null;
if (!isolation) {
  errors.push(`${mapPath}: declares no isolation boundary, so the controlled "no production route" is checked by nothing.`);
} else {
  const isolatedRoot = isolation.rootPath;
  if (!(await exists(isolatedRoot))) {
    errors.push(`${mapPath}: the isolation boundary names ${isolatedRoot}, which does not exist.`);
  } else {
    const projects = await findProjects(root);
    if (projects.length === 0) {
      errors.push(`${mapPath}: no .csproj files were found, so the isolation boundary is checked over nothing.`);
    }
    const isIsolated = (path) => {
      const rel = relative(root, path).split('\\').join('/');
      return rel === isolatedRoot || rel.startsWith(`${isolatedRoot}/`);
    };
    for (const project of projects) {
      const content = await readFile(project, 'utf8');
      const references = [...content.matchAll(/ProjectReference\s+Include="([^"]+)"/g)]
        .map((match) => resolve(dirname(project), match[1].split('\\').join('/')));
      for (const reference of references) {
        const here = isIsolated(project);
        const there = isIsolated(reference);
        if (here === there) continue;
        const from = relative(root, project).split('\\').join('/');
        const to = relative(root, reference).split('\\').join('/');
        errors.push(
          `${from} references ${to}, which crosses the controlled isolation boundary at ` +
          `${isolatedRoot}/. The architecture diagram draws no connector into or out of the ` +
          '"Controlled research and development" band, and the Simulators component states "no ' +
          'production route". A project reference is exactly that route.');
      }
    }
  }
}

async function findProjects(directory) {
  const found = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === 'obj' || entry.name === 'bin' || entry.name === '.git') continue;
    const path = join(directory, entry.name);
    if (entry.isDirectory()) {
      found.push(...(await findProjects(path)));
    } else if (entry.name.endsWith('.csproj')) {
      found.push(path);
    }
  }
  return found;
}

// -- 4. Report. --------------------------------------------------------------------------

if (errors.length > 0) {
  console.error(`Controlled architecture check FAILED (${errors.length}).`);
  for (const error of errors) console.error(`  - ${error}`);
  process.exit(1);
}

const built = (map.components ?? []).filter((item) => item.paths).length;
const stated = (map.components ?? []).filter((item) => item.notImplemented).length;
const guardedEdges = layerEdges.filter((edge) => edge.guarded);
console.log(
  `Controlled architecture reconciled against ${diagramPath}: ${bands.length} layers, ` +
  `${components.length} components (${built} bound, ${stated} declared not implemented), ` +
  `${layerEdges.length} layer edges (${guardedEdges.length} guarded: ` +
  `${guardedEdges.map((edge) => `${edge.from} -> ${edge.to}${edge.column ? ` via ${edge.column}` : ''}`).join('; ')}), ` +
  `${componentEdges.length} component edge. Isolation boundary at ${isolation?.rootPath}/ holds in both directions.`);
