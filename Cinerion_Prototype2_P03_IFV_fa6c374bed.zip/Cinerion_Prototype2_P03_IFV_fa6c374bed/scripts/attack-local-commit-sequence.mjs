// Attacks scripts/check-local-commit-sequence.mjs by reverting, one at a time, each
// control it exists for. Every mutation is applied to the real files and undone
// afterwards, so the gate under attack is exactly the gate CI runs. A mutation the gate
// does not refuse is reported here as a hole, which is the only useful outcome of an
// attack suite.
//
// The first four are defects 76 and 77 restored, each in both of the two ways it could
// come back: the implementation removed, and then the map's claim about it removed as
// well. A gate that only noticed the first would be a gate a future session could satisfy
// by deleting a declaration.
//
// Every source mutation asserts that it CHANGED the file before the gate's answer is
// judged. Defect 75 is why: two attacks in the cell-state suite silently stopped
// attacking when a patch script rewrote a file's line endings, and the run would have
// reported its full count while exercising nothing.

import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);

const mapPath = 'traceability/local-commit-sequence-r01.json';
const commandServicePath = 'services/control-core/src/Cinerion.Application/Commands/CommandService.cs';
const transactionPath = 'services/control-core/src/Cinerion.Domain/Commands/CommandTransaction.cs';
const endpointsPath = 'services/control-core/src/Cinerion.Api/Endpoints/CommandEndpoints.cs';
const ingressPath = 'services/control-core/src/Cinerion.Application/Edge/EdgeIngressService.cs';
const firmwarePath = 'firmware/shared/src/cell_state_machine.cpp';
const diagramPath = 'docs/baseline/P03_IFV/assets/prepare-local-commit.svg';

const paths = [mapPath, commandServicePath, transactionPath, endpointsPath, ingressPath, firmwarePath];
const originals = new Map(
  await Promise.all(paths.map(async (path) => [path, await readFile(path, 'utf8')])));

let holes = 0;

const gate = async () => {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-local-commit-sequence.mjs']);
    return { refused: false, output: stdout };
  } catch (error) {
    return { refused: true, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
};

const element = (map, index) => map.sequence[index];

/// Mutations of the map: a declaration that drifts from the controlled diagram.
const mapAttacks = [
  ['step 7 declared not implemented with no reason — the escape hatch, closed', (map) => {
    const step = map.sequence.find((item) => item.kind === 'step' && item.number === 7);
    delete step.boundTo;
    step.notImplemented = { reason: 'later' };
  }, 'is declared not implemented without a stated reason'],

  ['step 7 declared not implemented and recorded nowhere', (map) => {
    const step = map.sequence.find((item) => item.kind === 'step' && item.number === 7);
    delete step.boundTo;
    step.notImplemented = {
      reason: 'The correlation of telemetry, result and audit evidence has not been implemented in this prototype.',
    };
  }, 'records the decision nowhere'],

  ['the last message left unbound and unexplained', (map) => {
    delete map.sequence[map.sequence.length - 1].boundTo;
  }, 'is neither bound to an implementation nor declared not implemented'],

  ['the credential proof and the button edge swapped — the whole point of the sequence', (map) => {
    const order = map.sequence;
    const credential = order.findIndex((item) => item.label === 'Credential proof accepted');
    const button = order.findIndex((item) => item.label === 'New physical button edge');
    [order[credential], order[button]] = [order[button], order[credential]];
  }, 'the controlled diagram labels it'],

  ['a guarded message declared unguarded — CH1-CMD-FR-0005 removed from the map', (map) => {
    map.sequence.find((item) => item.label === 'New physical button edge').guarded = false;
  }, 'CH1-CMD-FR-0005 forbids a remote interface'],

  ['a message reversed, so the controller asks the domain for a credential', (map) => {
    const message = map.sequence.find((item) => item.label === 'Credential requested');
    [message.from, message.to] = [message.to, message.from];
  }, 'Direction is the message'],

  ['a controlled step deleted from the map', (map) => {
    map.sequence = map.sequence.filter(
      (item) => !(item.kind === 'step' && item.number === 6));
  }, 'declares 18 sequence elements; the controlled diagram contains 19'],

  ['a step invented that the controlled diagram does not contain', (map) => {
    map.sequence.splice(1, 0, {
      kind: 'step',
      number: 2,
      text: 'Portal confirms on the operator’s behalf',
      boundTo: [{ source: endpointsPath, symbol: 'MapPost' }],
    });
  }, 'the controlled diagram has a message there'],

  ['the resample note bound to a refusal that does not exist', (map) => {
    map.sequence.find((item) => item.text === 'A held/stuck input cannot satisfy this step')
      .enforcedBy[0].symbol = 'CONFIRM_EDGE_PREFERRED';
  }, 'which does not contain it'],

  ['a participant renamed to one the diagram does not draw', (map) => {
    map.participants.find((item) => item.id === 'local-confirmgate').name = 'Remote confirmer';
  }, 'which the controlled diagram does not contain'],

  ['a note reattached to another step', (map) => {
    map.sequence.find((item) => item.text === 'Commit locally or reject').step = 2;
  }, 'the controlled diagram places it under step 6'],

  ['the not-implemented dispatch quietly claimed as built', (map) => {
    const message = map.sequence.find((item) => item.label === 'Signed PREPARE');
    delete message.notImplemented;
    message.boundTo = [{ source: ingressPath, symbol: 'DispatchPreparedCommandAsync' }];
  }, 'which does not contain it'],
];

/// Mutations of the implementation, which is how the drift would actually arrive.
const sourceAttacks = [
  [commandServicePath, 'defect 77 restored: the correlated read deleted', (text) =>
    text.replace('public async ValueTask<CommandOutcome?> FindOutcomeAsync(', 'private async ValueTask<CommandOutcome?> UnusedOutcomePath('),
  'is bound to "FindOutcomeAsync" in'],

  [commandServicePath, 'the correlated read stops correlating and scans the project instead', (text) =>
    text.replace('await store.QueryAuditAsync(', 'await store.FindCommandAsync('),
  'is bound to "QueryAuditAsync" in'],

  [ingressPath, 'defect 76 restored: the acknowledgement filed under a fresh correlation', (text) =>
    // Line-ending tolerant on purpose. Written as an exact `\n` match this stopped
    // matching the moment the file carried Windows endings, and reported a pass while
    // attacking nothing — which is defect 75, and the reason the assertion below exists.
    text.replace(/\n(\s*)command\.CorrelationId,\r?\n/, '\n$1Guid.NewGuid(),\n'),
  'is bound to "command.CorrelationId" in'],

  [endpointsPath, 'the acknowledgements dropped from the visible outcome', (text) =>
    text.replace('acknowledgements = outcome.Acknowledgements,', 'ackCount = outcome.Acknowledgements.Count,'),
  'bound to "acknowledgements"'],

  [endpointsPath, 'the immutable audit links dropped from the visible outcome', (text) =>
    text.replace('auditLinks = outcome.AuditLinks,', 'evidence = outcome.AuditLinks,'),
  'bound to "auditLinks"'],

  [transactionPath, 'CH1-CMD-FR-0007 removed: a held input may satisfy the confirmation', (text) =>
    text.replace('"CONFIRM_EDGE_REQUIRED"', '"CONFIRM_EDGE_OPTIONAL"'),
  'is bound to "CONFIRM_EDGE_REQUIRED" in'],

  [transactionPath, 'the gate armed while the confirmation input is already held', (text) =>
    text.replace('"CONFIRM_BUTTON_HELD"', '"CONFIRM_BUTTON_NOTED"'),
  'is bound to "CONFIRM_BUTTON_HELD" in'],

  [transactionPath, 'the credential proof no longer bound to the cell', (text) =>
    text.replace('"PROOF_CELL_MISMATCH"', '"PROOF_CELL_ADVISORY"'),
  'is bound to "PROOF_CELL_MISMATCH" in'],

  [transactionPath, 'the short expiry removed from preparation', (text) =>
    text.replace('"CMD_TTL_INVALID"', '"CMD_TTL_ADVISORY"'),
  'is bound to "CMD_TTL_INVALID" in'],

  [transactionPath, 'a remote interface permitted to commit', (text) =>
    text.replace('"REMOTE_CONFIRMATION_FORBIDDEN"', '"REMOTE_CONFIRMATION_NOTED"'),
  'is bound to "REMOTE_CONFIRMATION_FORBIDDEN" in'],

  [firmwarePath, 'the controller stops resampling its permissives', (text) =>
    text.replace('bool StateMachine::permissives_valid(', 'bool StateMachine::unused_permissive_path('),
  'is bound to "StateMachine::permissives_valid" in'],

  [firmwarePath, 'the controller stops sampling the physical confirmation', (text) =>
    text.replace('Result StateMachine::sample_physical_confirmation(', 'Result StateMachine::unused_confirmation_path('),
  'is bound to "StateMachine::sample_physical_confirmation" in'],
];

const judge = (name, expected, refused, output) => {
  const named = output.includes(expected);
  if (refused && named) {
    console.log(`  REFUSED BY NAME  ${name}`);
    return;
  }
  holes += 1;
  console.log(`  *** HOLE ***     ${name} (refused=${refused}, named=${named})`);
  console.log(output.split('\n').filter((line) => line.includes('FAILED') || line.includes('  - ')).slice(0, 3).join('\n'));
};

const restore = async () => {
  await Promise.all([...originals].map(([path, text]) => writeFile(path, text)));
};

console.log('Attacking the controlled PREPARE / LOCAL COMMIT sequence gate.\n');

try {
  for (const [name, mutate, expected] of mapAttacks) {
    const map = JSON.parse(originals.get(mapPath));
    mutate(map);
    await writeFile(mapPath, `${JSON.stringify(map, null, 2)}\n`);
    const { refused, output } = await gate();
    await writeFile(mapPath, originals.get(mapPath));
    judge(name, expected, refused, output);
  }

  for (const [path, name, mutate, expected] of sourceAttacks) {
    const mutated = mutate(originals.get(path));
    // The load-bearing assertion. An attack whose replacement no longer matches is not a
    // passing attack, it is no attack at all, and without this the count below would be a
    // lie in exactly the way defect 75 was.
    if (mutated === originals.get(path)) {
      holes += 1;
      console.log(`  *** HOLE ***     ${name} (the mutation changed nothing, so nothing was attacked)`);
      continue;
    }
    await writeFile(path, mutated);
    const { refused, output } = await gate();
    await writeFile(path, originals.get(path));
    judge(name, expected, refused, output);
  }
} finally {
  await restore();
}

// The controlled diagram is not mutated. It is inside the frozen baseline and
// `npm run baseline` is the control over it; a suite that edits a SHA-256-verified source,
// even briefly, is one crash away from leaving the baseline broken. What is checked
// instead is that the gate parsed the diagram this suite was written against.
const parsed = await readFile(diagramPath, 'utf8');
const messages = [...parsed.matchAll(/<path\b[^>]*class="(?:arrow|local)"/g)].length;
const steps = [...parsed.matchAll(/class="step"/g)].length;
if (messages !== 7 || steps !== 7) {
  holes += 1;
  console.log(
    `  *** HOLE ***     the controlled diagram carries ${messages} messages and ${steps} steps, ` +
    'not 7 and 7; the gate parsed a different diagram from the one this suite attacks.');
} else {
  console.log('  NOT ATTACKED     the frozen diagram itself — it is SHA-256 verified, and ' +
    'npm run baseline is the control over it.');
}

const restored = await gate();
console.log(`\n${mapAttacks.length + sourceAttacks.length} attacks, ${holes} holes.`);
console.log(`Restored files pass the gate: ${restored.refused ? 'NO' : 'yes'}`);
process.exit(holes === 0 && !restored.refused ? 0 : 1);
