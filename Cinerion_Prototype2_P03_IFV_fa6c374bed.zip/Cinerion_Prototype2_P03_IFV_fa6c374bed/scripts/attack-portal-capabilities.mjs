// Attacks the portal capability gate.
//
// `npm run capabilities` exists to stop the portal offering a controlled act to a role the
// controlled documents do not name. A gate like that is worth exactly what it refuses, so
// each attack below mutates `capabilities.ts` in a way that ought to be caught, runs the
// gate, and asserts it FAILED.
//
// Every attack first asserts that its mutation CHANGED the file. That is defect 75: two
// attacks in another suite silently stopped matching, the file went back unchanged, and
// the gate passed because there was genuinely nothing wrong with it. An attack that
// exercises nothing reports a full score.
//
// The register is restored after every attack, including on a crash, and the suite checks
// at the end that the file on disk is byte-identical to what it started with.
//
//   npm run capabilities:attack

import { execFile } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { writeFile } from './lib/write-settled.mjs'; // retries through Windows file locks, then reads back
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const run = promisify(execFile);
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const registerPath = resolve(root, 'apps/operator-portal/src/api/capabilities.ts');
const original = await readFile(registerPath, 'utf8');

let attacks = 0;
let holes = 0;

async function gate() {
  try {
    const { stdout } = await run(process.execPath, ['scripts/check-portal-capabilities.mjs'], { cwd: root });
    return { refused: false, output: stdout };
  } catch (cause) {
    return { refused: true, output: `${cause.stdout ?? ''}${cause.stderr ?? ''}` };
  }
}

/**
 * Runs one attack. `mutate` returns the file content it wants written; an attack whose
 * mutation leaves the content unchanged is itself a failure, because it exercises nothing.
 */
async function attack(name, mutate, expectation) {
  attacks += 1;
  const mutated = mutate(original);
  if (mutated === original) {
    holes += 1;
    console.log(`HOLE  ${name} — the mutation changed nothing, so the gate was never exercised.`);
    return;
  }
  await writeFile(registerPath, mutated, 'utf8');
  try {
    const result = await gate();
    if (!result.refused) {
      holes += 1;
      console.log(`HOLE  ${name} — the gate ACCEPTED it.`);
      return;
    }
    if (expectation !== undefined && !result.output.includes(expectation)) {
      holes += 1;
      console.log(
        `HOLE  ${name} — the gate refused, but not for the stated reason. ` +
        `Expected to see: ${expectation}`);
      return;
    }
    console.log(`ok    ${name}`);
  } finally {
    await writeFile(registerPath, original, 'utf8');
  }
}

console.log('Attacking the portal capability register gate.\n');

// 1. Widening an authority. The whole reason the register exists.
await attack(
  'an act offered to a role the controlled authority does not name',
  (source) =>
    source.replace(
      "    authority: 'Inspector',\n    roles: ['Inspector'],\n    screen: 'CH1-UX-SCR-0011',\n  },\n  releasePart:",
      "    authority: 'Inspector',\n    roles: ['Inspector', 'Viewer'],\n    screen: 'CH1-UX-SCR-0011',\n  },\n  releasePart:"),
  'does not name',
);

// 2. Widening to a role that exists but belongs to a different authority entirely.
await attack(
  'part release offered to an Engineer',
  (source) =>
    source.replace(
      "    act: 'Release an accepted physical part',\n    authority: 'Inspector',\n    roles: ['Inspector'],",
      "    act: 'Release an accepted physical part',\n    authority: 'Inspector',\n    roles: ['Inspector', 'Engineer'],"),
  'never widens one',
);

// 3. Paraphrasing the controlled authority phrase. A second declaration to keep in step
//    is exactly what this register exists to avoid.
await attack(
  'an authority phrase reworded rather than quoted',
  (source) => source.replace("authority: 'Inspector or Engineer',", "authority: 'Inspector or an Engineer',"),
  'quoted, not paraphrased',
);

// 4. Naming an operation the catalogue does not contain.
await attack(
  'an act naming an operation nobody controls',
  (source) => source.replace("operation: 'POST /api/v1/ncrs',", "operation: 'POST /api/v1/ncrs/bulk-close',"),
  'controlled catalogue does not contain',
);

// 5. Silently dropping an authority by declaring no roles. `ownsAct` offers such an act
//    to every signed-in identity, so this is the quietest possible widening.
await attack(
  'an authority dropped by declaring no roles at all',
  (source) =>
    source.replace(
      "    authority: 'System Administrator',\n    roles: ['SystemAdministrator'],\n    screen: 'CH1-UX-SCR-0013',",
      "    authority: 'System Administrator',\n    subject: 'anyone, apparently',\n    screen: 'CH1-UX-SCR-0013',"),
  'silently drop the authority',
);

// 6. Narrowing without saying why. Permitted, but not silently.
await attack(
  'an act withheld from a role the register grants it, with no reason',
  (source) =>
    source.replace(
      "    authority: 'Inspector or Engineer',\n    roles: ['Inspector', 'Engineer', 'AutomationEngineer'],",
      "    authority: 'Inspector or Engineer',\n    roles: ['Inspector'],"),
  'must be explained',
);

// 7. A screen the controlled register does not declare.
await attack(
  'an act placed on a screen nobody declared',
  (source) => source.replace("screen: 'CH1-UX-SCR-0011',", "screen: 'CH1-UX-SCR-0099',"),
  'screens.json does not declare',
);

// 8. Claiming a relationship half for an authority that names none, which would offer a
//    role-only act to every signed-in identity.
await attack(
  'a relationship half invented for a role-only authority',
  (source) =>
    source.replace(
      "    authority: 'Cybersecurity Administrator',\n    roles: ['CybersecurityAdministrator'],\n    screen: 'CH1-UX-SCR-0013',\n  },\n  revokeCredential:",
      "    authority: 'Cybersecurity Administrator',\n    roles: ['CybersecurityAdministrator'],\n    orRelationship: 'anyone who feels responsible',\n    screen: 'CH1-UX-SCR-0013',\n  },\n  revokeCredential:"),
  'which names no relationship',
);

// 9. Two acts for the same operation, which would let two screens disagree about it.
await attack(
  'the same controlled operation declared twice',
  (source) =>
    source.replace(
      "  // --- Audit --------------------------------------------------------------------",
      "  releasePartAgain: {\n" +
      "    operation: 'POST /api/v1/release-records',\n" +
      "    act: 'Release an accepted physical part, again',\n" +
      "    authority: 'Inspector',\n" +
      "    roles: ['Inspector'],\n" +
      "    screen: 'CH1-UX-SCR-0011',\n" +
      "  },\n\n" +
      "  // --- Audit --------------------------------------------------------------------"),
  'is declared twice',
);

// 10. The gate reading its own subject out of a comment. Item 63: a gate that greps a
//     source for a symbol will match it in a comment, so the gate strips comments first
//     and this proves it. A widened role written ONLY in a comment must not fail the gate,
//     and the same widening written in code must.
attacks += 1;
{
  const commented = original.replace(
    "  // --- Audit --------------------------------------------------------------------",
    "  // roles: ['Inspector', 'Viewer'] would widen part release, but this is a comment\n" +
    "  // --- Audit --------------------------------------------------------------------");
  if (commented === original) {
    holes += 1;
    console.log('HOLE  a widening written only in a comment — the mutation changed nothing.');
  } else {
    await writeFile(registerPath, commented, 'utf8');
    try {
      const result = await gate();
      if (result.refused) {
        holes += 1;
        console.log(
          'HOLE  a widening written only in a comment — the gate refused a COMMENT, which ' +
          'means it is reading prose rather than the register.');
      } else {
        console.log('ok    a widening written only in a comment is correctly ignored');
      }
    } finally {
      await writeFile(registerPath, original, 'utf8');
    }
  }
}

// 11. The register emptied entirely. A gate that passes an empty register establishes
//     nothing, and would do so on the day somebody refactors the file's shape.
await attack(
  'the register emptied',
  (source) =>
    source.replace(
      /export const ControlledActs = \{[\s\S]*?\n\} as const satisfies/,
      'export const ControlledActs = {\n} as const satisfies'),
  'would establish nothing',
);

const restored = await readFile(registerPath, 'utf8');
if (restored !== original) {
  holes += 1;
  console.log('HOLE  the register was NOT restored to its original content.');
} else {
  console.log('ok    the register is byte-identical to how the suite found it');
  attacks += 1;
}

console.log();
if (holes > 0) {
  console.error(`Portal capability gate: ${attacks} attacks, ${holes} HOLES.`);
  process.exitCode = 1;
} else {
  console.log(`Portal capability gate: ${attacks} attacks, 0 holes.`);
}
