// Reconciles the ESP32-S3 pin map against the controlled I/O table.
//
// CH1-HWE-IOL-0001 makes the I/O table the authoritative logical signal register and the
// microcontroller pin map a hardware-revision-controlled derivative of it: "Names describe
// physical meaning rather than implementation", "Exactly one component owns each output",
// and a change to controller allocation, electrical type, fail state or diagnostic action
// requires impact assessment. None of that is checkable by reading either file alone.
//
// A pin map that drifted would not fail loudly. The firmware would condition a signal the
// register does not contain, or leave one it does contain unconditioned, and every test
// written against the pin map would agree with the pin map. So this fails when
//
//   * the controlled table names a signal the pin map does not, or the reverse;
//   * a signal's name, owner, direction, range, normal state, diagnostic action or terminal
//     disagrees with the controlled table;
//   * a signal this controller owns has no pins and no declared reason for having none;
//   * two signals claim one GPIO in a way that is not a shared bus;
//   * any signal sits on a pin the module reserves for flash, PSRAM, USB, the console or
//     boot strapping — the gate holds its own copy of that set, so the map cannot widen it;
//   * an output does not declare the external pull that establishes its de-energised state
//     while the controller's pins are still high-impedance at reset;
//   * the conditioning declared for a signal is not the one its controlled diagnostic
//     action calls for;
//   * an actuator output is declared energisable while the wiring is not frozen;
//   * the wiring is declared frozen while any terminal is still TBD;
//   * or the firmware's own signal table and this map name different signals.
//
// It announces no controlled verification case. `data/tests.json` contains none for the
// I/O register — searching it for I/O, wiring, signal, terminal, pin or loop check returns
// nothing — and binding this evidence to an unrelated case is the overstatement the
// verification map exists to prevent. Recorded as a conflict instead.

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];

const mapPath = 'firmware/pinmap/esp32s3-r01.json';
const tablePath = 'docs/baseline/P03_IFV/data/io.json';
const firmwarePath = 'firmware/shared/include/cinerion/conditioned_io.hpp';

const table = JSON.parse(await readFile(resolve(root, tablePath), 'utf8'));
const map = JSON.parse(await readFile(resolve(root, mapPath), 'utf8'));

// -- The controlled table, by identifier. ------------------------------------------------
// io.json is a table of rows, not objects: id, name, owner, type, range, normal,
// diagnostic, terminal. Naming the columns here rather than indexing them at each use is
// the difference between a check that reads and one that silently compares the wrong pair.

const controlled = new Map(table.map((row) => [row[0], {
  signalId: row[0],
  name: row[1],
  owner: row[2],
  direction: row[3],
  range: row[4],
  normal: row[5],
  diagnostic: row[6],
  terminal: row[7],
}]));

if (controlled.size === 0) {
  errors.push('No signals were read from the controlled I/O table; this check would pass over nothing.');
}

const declared = new Map();
for (const signal of map.signals ?? []) {
  if (declared.has(signal.signalId)) {
    errors.push(`${mapPath} declares ${signal.signalId} twice. One signal, one entry.`);
  }
  declared.set(signal.signalId, signal);
}

if (declared.size === 0) {
  errors.push(`No signals were read from ${mapPath}; this check would pass over nothing.`);
}

// -- Completeness, both ways. ------------------------------------------------------------

for (const signalId of controlled.keys()) {
  if (!declared.has(signalId)) {
    errors.push(
      `The controlled I/O table contains ${signalId} and ${mapPath} does not. ` +
      'A signal with no pin-map entry is a signal no firmware conditions.');
  }
}

for (const signalId of declared.keys()) {
  if (!controlled.has(signalId)) {
    errors.push(
      `${mapPath} declares ${signalId}, which the controlled I/O table does not contain. ` +
      'Inventing a signal is the same class of error as inventing a telemetry channel.');
  }
}

// -- Every column the controlled table owns is carried verbatim. -------------------------
// CH1-HWE-IOL-0001: a change to controller allocation, electrical type, scaling, fail state
// or diagnostic action requires impact assessment. Copying the columns and checking them is
// how that change becomes visible instead of being made in passing.

const carried = ['name', 'owner', 'direction', 'range', 'normal', 'diagnostic', 'terminal'];
for (const [signalId, signal] of declared) {
  const source = controlled.get(signalId);
  if (!source) continue;
  for (const column of carried) {
    if (signal[column] !== source[column]) {
      errors.push(
        `${signalId}.${column} is "${signal[column]}" in ${mapPath} and "${source[column]}" in the ` +
        'controlled I/O table.');
    }
  }
}

// -- Conditioning follows the controlled diagnostic action. ------------------------------
// The diagnostic column is the requirement; `conditioning` is the implementation's name for
// it. Deriving one from the other here means a diagnostic action cannot be changed in the
// baseline without the firmware being told.

const conditioningFor = new Map([
  ['Required permissive', 'isolated-di'],
  ['Controlled stop', 'isolated-di'],
  ['Rising-edge only', 'isolated-di'],
  ['Debounce + stuck detection', 'isolated-di'],
  ['Drops permissive', 'isolated-di'],
  ['Travel plausibility', 'isolated-di'],
  ['Only AwaitButton state', 'isolated-do'],
  ['Ready/complete indication', 'isolated-do'],
  ['Prepared/warning indication', 'isolated-do'],
  ['Fault-latched indication', 'isolated-do'],
  ['Pattern controlled', 'isolated-do'],
  ['Drops on watchdog/fault', 'isolated-do'],
  ['Rate and travel limited', 'step-dir'],
  ['Range/rate validation', 'range-rate'],
  ['Median filter', 'median'],
  ['Windowed RMS', 'windowed-rms'],
  ['CRC/sequence/timeout', 'framed-serial'],
  ['mTLS/heartbeat', 'none'],
  ['Certificate trust', 'none'],
  ['Allowlisted map', 'none'],
  ['Identification only', 'none'],
  ['Challenge-response', 'none'],
  ['No remote-start control', 'none'],
]);

for (const [signalId, signal] of declared) {
  const source = controlled.get(signalId);
  if (!source) continue;
  const expected = conditioningFor.get(source.diagnostic);
  if (expected === undefined) {
    errors.push(
      `The controlled diagnostic action "${source.diagnostic}" on ${signalId} has no conditioning ` +
      'in this gate. A new diagnostic action must be given one rather than passing unchecked.');
  } else if (signal.conditioning !== expected) {
    errors.push(
      `${signalId} declares conditioning "${signal.conditioning}" but its controlled diagnostic ` +
      `action "${source.diagnostic}" calls for "${expected}".`);
  }
}

// -- Signals this controller owns have pins; the rest say why they do not. ----------------

const absenceReasons = new Set(['ESP32_INTERNAL', 'OTHER_CONTROLLER', 'ARDUINO_NODE']);

for (const [signalId, signal] of declared) {
  const pins = signal.pins ?? [];
  if (pins.length === 0) {
    if (!absenceReasons.has(signal.absence)) {
      errors.push(
        `${signalId} has no pins and no recognised reason for having none. ` +
        `Declare one of ${[...absenceReasons].join(', ')}.`);
    }
  } else if (signal.absence !== undefined) {
    errors.push(`${signalId} declares both pins and an absence reason.`);
  }
}

// -- Pins are exclusive unless they are a bus, and never reserved. -----------------------
// The gate holds its own copy of the reserved set. Reading it from the map being checked
// would let a map excuse its own violation by deleting the entry that forbids it.

const reserved = new Map([
  [0, 'strapping (boot mode)'],
  [3, 'strapping (JTAG source select)'],
  [19, 'USB D-'],
  [20, 'USB D+'],
  [26, 'SPI flash / PSRAM'],
  [27, 'SPI flash / PSRAM'],
  [28, 'SPI flash / PSRAM'],
  [29, 'SPI flash / PSRAM'],
  [30, 'SPI flash / PSRAM'],
  [31, 'SPI flash / PSRAM'],
  [32, 'SPI flash / PSRAM'],
  [33, 'octal PSRAM on the N16R8 module'],
  [34, 'octal PSRAM on the N16R8 module'],
  [35, 'octal PSRAM on the N16R8 module'],
  [36, 'octal PSRAM on the N16R8 module'],
  [37, 'octal PSRAM on the N16R8 module'],
  [43, 'U0TXD, the console'],
  [44, 'U0RXD, the console'],
  [45, 'strapping (VDD_SPI voltage select)'],
  [46, 'strapping, sampled at reset'],
]);

// A bus is shared by construction; a signal line is not. Sharing SDA between four sensors
// is the design. Sharing an output between two signals is CH1-HWE-IOL-0001's "exactly one
// component owns each output" being broken, and multi-source status resolved electrically
// rather than in domain logic.
const busRoles = new Set(['i2c-sda', 'i2c-scl']);

const claims = new Map();
for (const [signalId, signal] of declared) {
  for (const pin of signal.pins ?? []) {
    if (!Number.isInteger(pin.gpio) || pin.gpio < 0 || pin.gpio > 48) {
      errors.push(`${signalId} claims GPIO ${pin.gpio}, which is not an ESP32-S3 pin.`);
      continue;
    }
    if (reserved.has(pin.gpio)) {
      errors.push(
        `${signalId} claims GPIO ${pin.gpio}, which the module reserves for ${reserved.get(pin.gpio)}.`);
    }
    const existing = claims.get(pin.gpio);
    if (existing === undefined) {
      claims.set(pin.gpio, { signalId, role: pin.role });
    } else if (!busRoles.has(pin.role) || existing.role !== pin.role) {
      errors.push(
        `GPIO ${pin.gpio} is claimed by ${existing.signalId} as ${existing.role} and by ` +
        `${signalId} as ${pin.role}. Only a shared bus role may be claimed twice.`);
    }
  }
}

// The map must also account for every pin it says it reserves, or a reader would trust a
// list that had quietly lost an entry.
for (const gpio of reserved.keys()) {
  if (map.reservedPins?.[String(gpio)] === undefined) {
    errors.push(`${mapPath} does not record GPIO ${gpio} as reserved, and it is.`);
  }
}

// -- Outputs are de-energised at reset by the wiring, not by software having run. ---------
// Every ESP32-S3 GPIO is high-impedance until firmware configures it, and high impedance is
// not a level. CH1-VVT-TC-0072 requires the non-energising startup state to hold before any
// firmware decision, which only an external pull can deliver.

for (const [signalId, signal] of declared) {
  const drivesSomething = (signal.pins ?? []).some(
    (pin) => pin.role === 'output' || pin.role === 'step' || pin.role === 'direction');
  if (!drivesSomething) continue;
  if (signal.externalPull !== 'down' && signal.externalPull !== 'up') {
    errors.push(
      `${signalId} drives an output and declares no external pull. Without one its state at ` +
      'reset is high impedance, which is not a de-energised level.');
  }
  if (signal.deEnergisedLevel !== 'low' && signal.deEnergisedLevel !== 'high') {
    errors.push(`${signalId} drives an output and declares no de-energised level.`);
  }
  if (signal.externalPull === 'down' && signal.deEnergisedLevel !== 'low') {
    errors.push(
      `${signalId} is pulled down at reset but calls its de-energised level ` +
      `"${signal.deEnergisedLevel}". The pull would then energise it.`);
  }
  if (signal.externalPull === 'up' && signal.deEnergisedLevel !== 'high') {
    errors.push(
      `${signalId} is pulled up at reset but calls its de-energised level ` +
      `"${signal.deEnergisedLevel}". The pull would then energise it.`);
  }
}

// -- The energisation boundary, in data. --------------------------------------------------
// CH1-SAF-FR-0001 keeps the machine safety function local and independent, and
// CH1-EMB-FDS-0001's P03 verification boundary defers independent review until before
// hazardous energisation. scripts/check-repository-policy.mjs holds the code half of that
// boundary; this holds the data half. An actuator that became energisable by editing a JSON
// field would be exactly the quiet move both halves exist to stop.

const actuators = new Set(['CH1-IO-DO-0006', 'CH1-IO-PWM-0001']);
for (const [signalId, signal] of declared) {
  const isActuator = signal.actuator === true;
  if (isActuator !== actuators.has(signalId)) {
    errors.push(
      `${signalId} is ${isActuator ? '' : 'not '}marked as an actuator, and the controlled table ` +
      `says it is ${actuators.has(signalId) ? '' : 'not '}one.`);
  }
  if (isActuator && signal.energisable !== false && map.wiringFrozen !== true) {
    errors.push(
      `${signalId} is an actuator output declared energisable while the wiring is not frozen. ` +
      'Hazardous energisation follows independent review, not a JSON edit.');
  }
}

// -- A frozen wiring schedule has no TBD terminals. ---------------------------------------
// CH1-HWE-IOL-0001: "Terminal TBD is acceptable at P03 design stage but blocks wiring
// freeze." Stated in the document and refused here, so the two cannot disagree.

if (map.wiringFrozen === true) {
  for (const [signalId, signal] of declared) {
    if (signal.terminal === 'TBD') {
      errors.push(`${mapPath} declares the wiring frozen while ${signalId} has terminal TBD.`);
    }
  }
} else if (!Array.isArray(map.wiringFreezeBlockedBy) || map.wiringFreezeBlockedBy.length === 0) {
  errors.push(`${mapPath} leaves the wiring unfrozen and states no reason.`);
}

// -- The firmware's own signal table names the same signals. ------------------------------
// Two copies again, and for the same reason as the Modbus map: the firmware must not read
// the JSON at build time, so it carries its own list, and a list that agrees only because
// nobody checked is not a contract.

const firmware = await readFile(resolve(root, firmwarePath), 'utf8').catch(() => null);
if (firmware === null) {
  errors.push(`${firmwarePath} is missing; the firmware half of the pin map cannot be reconciled.`);
} else {
  const named = new Set([...firmware.matchAll(/"(CH1-IO-[A-Z]+-\d{4})"/g)].map((match) => match[1]));
  if (named.size === 0) {
    errors.push(`No signal identifiers were parsed from ${firmwarePath}; this check would pass over nothing.`);
  }
  // The firmware conditions what this controller OWNS, which is not the same as what
  // consumes a GPIO: CH1-IO-NET-0001 is the ESP32's MQTT uplink and its radio is inside the
  // module. Ownership is the controlled table's own column, so the rule keys off that.
  // Signals belonging to EdgeLink, ConfirmGate or the Arduino node are in the register for
  // completeness and are not this controller's to sample.
  const controller = 'ESP32-S3';
  for (const [signalId, signal] of declared) {
    const ours = signal.owner === controller;
    if (ours && !named.has(signalId)) {
      errors.push(
        `${firmwarePath} does not name ${signalId}, which the controlled table gives to ${controller}. ` +
        'A signal the firmware cannot name is a signal it does not condition.');
    }
    if (!ours && named.has(signalId)) {
      errors.push(
        `${firmwarePath} names ${signalId}, which the controlled table gives to "${signal.owner}". ` +
        'A controller that conditions another controller\'s signal has taken authority it was not given.');
    }
  }
  for (const signalId of named) {
    if (!declared.has(signalId)) {
      errors.push(`${firmwarePath} names ${signalId}, which ${mapPath} does not declare.`);
    }
  }
}

// ----------------------------------------------------------------------------------------

if (errors.length > 0) {
  console.error('Controlled I/O pin map check failed:');
  for (const error of errors) console.error(`  FAIL ${error}`);
  process.exit(1);
}

const owned = [...declared.values()].filter((signal) => signal.owner === 'ESP32-S3');
const elsewhere = declared.size - owned.length;
const pins = new Set([...claims.keys()]);
console.log(
  `Pin map reconciled: ${declared.size} controlled signals, ${owned.length} owned by ${map.module} ` +
  `and conditioned by the firmware on ${pins.size} GPIOs, ${elsewhere} owned by another controller ` +
  'with a stated reason.');
console.log(
  `Wiring frozen: ${map.wiringFrozen === true ? 'yes' : 'no'}; ` +
  `actuator outputs energisable: ${[...declared.values()].filter((s) => s.actuator && s.energisable).length}.`);
