# Windows health check for the workstation. Tells you what's missing before a build does.

$ErrorActionPreference = 'Continue'
$Failures = 0
$Warnings = 0
$Passes = 0

function Pass([string]$Message) {
    $script:Passes++
    Write-Host "PASS  $Message" -ForegroundColor Green
}

function Warn([string]$Message) {
    $script:Warnings++
    Write-Host "WARN  $Message" -ForegroundColor Yellow
}

function Fail([string]$Message) {
    $script:Failures++
    Write-Host "FAIL  $Message" -ForegroundColor Red
}

Write-Host 'Cinerion Windows/WSL doctor'
Write-Host '============================'

try {
    $WslVersion = (wsl --version 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -eq 0) { Pass "WSL is available. $($WslVersion.Split([Environment]::NewLine)[0])" }
    else { Fail "WSL is unavailable: $WslVersion" }

    $WslList = (wsl --list --verbose 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -eq 0) {
        Write-Host $WslList
        if ($WslList -match '\s2\s*$' -or $WslList -match '\s2\s') { Pass 'At least one WSL2 distribution is listed.' }
        else { Fail 'No WSL2 distribution was detected. Convert Ubuntu with: wsl --set-version <DistributionName> 2' }
    }
} catch {
    Fail "Unable to query WSL: $($_.Exception.Message)"
}

try {
    $DockerVersion = (docker --version 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -eq 0) { Pass $DockerVersion }
    else { Fail "Docker Desktop CLI is unavailable: $DockerVersion" }

    $ComposeVersion = (docker compose version 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -eq 0) { Pass $ComposeVersion }
    else { Fail "Docker Compose v2 is unavailable: $ComposeVersion" }

    $ServerVersion = (docker info --format '{{.ServerVersion}}' 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -eq 0) { Pass "Docker Engine is running: server $ServerVersion" }
    else { Fail "Docker Engine is not reachable: $ServerVersion" }
} catch {
    Fail "Unable to query Docker Desktop: $($_.Exception.Message)"
}

Write-Host "`nSummary: $Passes passed, $Warnings warning(s), $Failures failure(s)."
if ($Failures -gt 0) {
    Write-Host 'Enable Docker Desktop > Settings > Resources > WSL Integration for Ubuntu, apply/restart, then run wsl --shutdown.' -ForegroundColor Cyan
    exit 1
}

