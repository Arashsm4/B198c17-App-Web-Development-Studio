// The attribute that tags a test with the verification case it proves.

namespace Cinerion.Verification;

/// <summary>
/// Binds an executable test to a controlled verification case from
/// <c>docs/baseline/P03_IFV/data/tests.json</c>.
/// </summary>
/// <remarks>
/// <para>
/// CH1-VVT-VMP-0001 requires every baseline requirement to have a primary case in the
/// RTM and every case to have identified evidence. The requirement side of that has been
/// machine-checked since <c>traceability/implementation-map.json</c> existed; the case
/// side has not, so nothing could state how many of the 87 controlled cases had an
/// executable form, and nothing failed when a case had none.
/// </para>
/// <para>
/// The identifier is carried as an attribute rather than folded into the test name.
/// A test name states which requirement the author had in mind; this states which
/// controlled case the test is offered as evidence for, one test may carry several, and
/// <see cref="VerificationBinding"/> reconciles the whole set against the map in both
/// directions — an unknown identifier fails, and a case the map claims this assembly
/// covers fails if no test here carries it.
/// </para>
/// </remarks>
[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true, Inherited = false)]
public sealed class VerificationCaseAttribute : Attribute
{
    /// <param name="testCaseId">A controlled identifier of the form <c>CH1-VVT-TC-0000</c>.</param>
    public VerificationCaseAttribute(string testCaseId) => TestCaseId = testCaseId;

    /// <summary>The controlled verification case this test is evidence for.</summary>
    public string TestCaseId { get; }
}
