// Matches test tags to the controlled verification cases. Keeps everyone honest about what's
// actually tested.

using System.Globalization;
using System.Reflection;
using System.Text.Json;

namespace Cinerion.Verification;

/// <summary>
/// Reconciles the <see cref="VerificationCaseAttribute"/> bindings a test assembly
/// actually carries with the bindings <c>traceability/verification-map.json</c> claims
/// for it, and both with the frozen baseline case list.
/// </summary>
/// <remarks>
/// The reconciliation runs inside the test assembly rather than as a source scan,
/// because a scan proves a string is present in a file whereas this proves a test exists,
/// is discoverable, and belongs to the assembly the map names. Each test assembly checks
/// its own slice, so the three together cover every dotnet binding in the map.
/// </remarks>
public static class VerificationBinding
{
    /// <summary>Locates the repository root from the test output directory.</summary>
    public static string RepositoryRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !Directory.Exists(Path.Combine(directory.FullName, "docs", "baseline")))
        {
            directory = directory.Parent;
        }

        return directory?.FullName
            ?? throw new InvalidOperationException(
                "Could not locate the repository root from " + AppContext.BaseDirectory);
    }

    /// <summary>Every controlled verification case identifier, from the frozen baseline.</summary>
    public static IReadOnlySet<string> BaselineCaseIds()
    {
        var path = Path.Combine(RepositoryRoot(), "docs/baseline/P03_IFV/data/tests.json");
        using var document = JsonDocument.Parse(File.ReadAllText(path));
        return document.RootElement.EnumerateArray()
            .Select(row => row[0].GetString()!)
            .ToHashSet(StringComparer.Ordinal);
    }

    /// <summary>The case identifiers the map assigns to one harness.</summary>
    public static IReadOnlySet<string> DeclaredFor(string harness)
    {
        var path = Path.Combine(RepositoryRoot(), "traceability/verification-map.json");
        using var document = JsonDocument.Parse(File.ReadAllText(path));
        var declared = new HashSet<string>(StringComparer.Ordinal);
        foreach (var entry in document.RootElement.GetProperty("cases").EnumerateArray())
        {
            if (!entry.TryGetProperty("bindings", out var bindings))
            {
                continue;
            }

            foreach (var binding in bindings.EnumerateArray())
            {
                if (string.Equals(binding.GetString(), harness, StringComparison.Ordinal))
                {
                    declared.Add(entry.GetProperty("testCaseId").GetString()!);
                }
            }
        }

        return declared;
    }

    /// <summary>
    /// The case identifiers this assembly carries, with the tests that carry each. A
    /// class-level binding is attributed to every test method the class declares.
    /// </summary>
    public static IReadOnlyDictionary<string, IReadOnlyList<string>> ObservedIn(Assembly assembly)
    {
        var observed = new SortedDictionary<string, List<string>>(StringComparer.Ordinal);
        foreach (var type in assembly.GetTypes())
        {
            var testMethods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly)
                .Where(IsTestMethod)
                .ToArray();

            foreach (var attribute in type.GetCustomAttributes<VerificationCaseAttribute>(inherit: false))
            {
                foreach (var method in testMethods)
                {
                    Record(observed, attribute.TestCaseId, $"{type.Name}.{method.Name}");
                }

                if (testMethods.Length == 0)
                {
                    Record(observed, attribute.TestCaseId, $"{type.Name} (no test method)");
                }
            }

            foreach (var method in type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly))
            {
                foreach (var attribute in method.GetCustomAttributes<VerificationCaseAttribute>(inherit: false))
                {
                    Record(
                        observed,
                        attribute.TestCaseId,
                        IsTestMethod(method) ? $"{type.Name}.{method.Name}" : $"{type.Name}.{method.Name} (not a test)");
                }
            }
        }

        return observed.ToDictionary(
            pair => pair.Key,
            pair => (IReadOnlyList<string>)pair.Value,
            StringComparer.Ordinal);
    }

    /// <summary>
    /// Every disagreement between the assembly and the map. An empty result is the only
    /// passing outcome; the caller asserts on it so the failure text names each one.
    /// </summary>
    public static IReadOnlyList<string> Reconcile(Assembly assembly, string harness)
    {
        var baseline = BaselineCaseIds();
        var declared = DeclaredFor(harness);
        var observed = ObservedIn(assembly);
        var failures = new List<string>();

        foreach (var (caseId, tests) in observed)
        {
            if (!baseline.Contains(caseId))
            {
                failures.Add(
                    $"{harness}: [VerificationCase(\"{caseId}\")] on {string.Join(", ", tests)} is not a controlled case in tests.json.");
            }
            else if (!declared.Contains(caseId))
            {
                failures.Add(
                    $"{harness}: {string.Join(", ", tests)} claims {caseId}, but traceability/verification-map.json does not bind that case to this harness.");
            }

            foreach (var test in tests.Where(item => item.EndsWith("(not a test)", StringComparison.Ordinal)
                                                 || item.EndsWith("(no test method)", StringComparison.Ordinal)))
            {
                failures.Add($"{harness}: {test} carries a {caseId} binding but is not executable evidence.");
            }
        }

        foreach (var caseId in declared.Except(observed.Keys, StringComparer.Ordinal).Order(StringComparer.Ordinal))
        {
            failures.Add(
                $"{harness}: traceability/verification-map.json binds {caseId} to this harness, but no test here carries [VerificationCase(\"{caseId}\")].");
        }

        return failures;
    }

    /// <summary>
    /// Writes what this assembly carries, so a verification report can cite the tests
    /// that were run for a case rather than the map's claim about them.
    /// </summary>
    public static string WriteObservedBindings(Assembly assembly, string harness)
    {
        var directory = Path.Combine(RepositoryRoot(), "artifacts", "verification");
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, $"bindings-{harness}.json");
        var payload = new
        {
            harness,
            assembly = assembly.GetName().Name,
            observedAtUtc = DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture),
            cases = ObservedIn(assembly),
        };
        File.WriteAllText(path, JsonSerializer.Serialize(payload, SerializerOptions));
        return path;
    }

    private static readonly JsonSerializerOptions SerializerOptions = new() { WriteIndented = true };

    private static void Record(SortedDictionary<string, List<string>> observed, string caseId, string test)
    {
        if (!observed.TryGetValue(caseId, out var tests))
        {
            tests = [];
            observed[caseId] = tests;
        }

        if (!tests.Contains(test, StringComparer.Ordinal))
        {
            tests.Add(test);
        }
    }

    /// <summary>
    /// Recognises an xUnit test without referencing xUnit, so this library stays free of
    /// a test framework and cannot drag a second test host into any assembly.
    /// </summary>
    private static bool IsTestMethod(MethodInfo method) =>
        method.GetCustomAttributes(inherit: true).Any(attribute =>
        {
            for (var type = attribute.GetType(); type is not null; type = type.BaseType)
            {
                if (type.Name is "FactAttribute" or "TheoryAttribute")
                {
                    return true;
                }
            }

            return false;
        });
}
