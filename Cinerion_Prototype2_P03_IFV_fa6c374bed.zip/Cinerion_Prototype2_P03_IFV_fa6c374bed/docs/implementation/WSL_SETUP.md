# Cinerion workstation setup and repair

This runbook is for Windows 10/11 with Ubuntu 26.04 under WSL2 and Docker
Desktop. It repairs the two failure modes captured during the first Cinerion
setup: a partial .NET installation and Docker Desktop not exposed to Ubuntu.

## 1. Record the current state

Run these commands in Ubuntu before changing packages:

```bash
. /etc/os-release
printf 'Ubuntu: %s (%s)\n' "$PRETTY_NAME" "$VERSION_CODENAME"
type -a dotnet || true
readlink -f "$(command -v dotnet)" || true
dpkg -l | awk '/dotnet|aspnetcore|netstandard/ {print $1, $2, $3}'
apt-cache policy dotnet-sdk-10.0 dotnet-hostfxr-10.0 dotnet-host
printf 'DOTNET_ROOT=%s\n' "${DOTNET_ROOT:-<unset>}"
```

The error `[/usr/lib/dotnet/host/fxr] does not exist` means that the `dotnet`
launcher is present but its host framework resolver is missing. It is not a
Cinerion code failure.

## 2. Repair .NET 10 on Ubuntu 26.04

Ubuntu 26.04 provides .NET 10 from its built-in Ubuntu feed. The backports PPA
is not required for .NET 10. Complete any interrupted package transaction,
remove the unnecessary PPA, and reinstall the exact SDK and host chain:

```bash
sudo dpkg --configure -a
sudo apt-get --fix-broken install -y
sudo add-apt-repository --remove -y ppa:dotnet/backports || true
sudo apt-get update
sudo apt-get install --reinstall -y \
  dotnet-host \
  dotnet-hostfxr-10.0 \
  dotnet-runtime-10.0 \
  aspnetcore-runtime-10.0 \
  dotnet-sdk-10.0

unset DOTNET_ROOT
hash -r
dotnet --info
dotnet --list-sdks
dotnet --list-runtimes
```

The SDK result must start with `10.`. Cinerion's `global.json` requests
`10.0.100` and allows roll-forward to the latest installed .NET 10 feature
band.

If the Ubuntu package transaction still cannot be repaired, use Microsoft's
official non-admin installer as a fallback rather than mixing more package
feeds:

```bash
mkdir -p "$HOME/.local/share/dotnet"
curl -fsSL https://dot.net/v1/dotnet-install.sh -o /tmp/dotnet-install.sh
chmod 700 /tmp/dotnet-install.sh
/tmp/dotnet-install.sh \
  --channel 10.0 \
  --quality GA \
  --install-dir "$HOME/.local/share/dotnet"

printf '\nexport DOTNET_ROOT="$HOME/.local/share/dotnet"\n' >> "$HOME/.bashrc"
printf 'export PATH="$DOTNET_ROOT:$DOTNET_ROOT/tools:$PATH"\n' >> "$HOME/.bashrc"
source "$HOME/.bashrc"
dotnet --info
```

Do not keep both a broken system installation and a hidden PATH override without
recording which one is authoritative. `type -a dotnet` must make the selected
installation obvious.

Official references:

- https://learn.microsoft.com/dotnet/core/install/linux-ubuntu-install
- https://learn.microsoft.com/dotnet/core/tools/dotnet-install-script

## 3. Expose Docker Desktop to Ubuntu WSL2

Do not install a second Docker Engine inside Ubuntu. Use Docker Desktop on
Windows as the single engine.

In an Administrator PowerShell window:

```powershell
wsl --update
wsl --set-default-version 2
wsl --list --verbose
```

Confirm that the Ubuntu distribution used for Cinerion shows version `2`.
Then open Docker Desktop and set:

1. **Settings > General > Use the WSL 2 based engine**: enabled.
2. **Settings > Resources > WSL Integration**: enable the exact Ubuntu
   distribution shown by `wsl --list --verbose`.
3. Select **Apply & restart**.
4. If WSL Integration is not visible, switch Docker Desktop to Linux
   containers.

After Docker Desktop reports that the engine is running, return to PowerShell:

```powershell
wsl --shutdown
```

Reopen Ubuntu and test:

```bash
docker version
docker compose version
docker info --format '{{.ServerVersion}}'
docker run --rm hello-world
```

Official reference:

- https://docs.docker.com/desktop/features/wsl/

## 4. Verify all prerequisites

From the extracted Cinerion repository root:

```bash
chmod +x scripts/*.sh
./scripts/doctor.sh
```

The doctor validates WSL, the native Linux repository location, Node.js, npm,
.NET 10, g++, Git, curl, unzip, OpenSSL, Docker Compose v2, and Docker Engine.
Resolve every `FAIL` before continuing. A `WARN` is advisory and is explained
in the output.

## 5. Install dependencies and execute the strict release gate

Keep the repository under `~/projects`, not under `/mnt/c`, OneDrive, Desktop,
or Downloads.

```bash
cd ~/projects/Cinerion_Prototype1_0.1.0_P03_IFV
npm ci
./scripts/verify.sh --strict
```

The final line must be:

```text
Cinerion Prototype 1 verification completed.
```

## 6. Start and prove the simulator-safe stack

```bash
./scripts/run-local.sh
./scripts/smoke-api.sh
docker compose -f infrastructure/compose.yaml ps
```

Open:

- Portal: http://localhost:8081
- API health: http://localhost:5080/api/v1/system/health
- API catalogue: http://localhost:5080/swagger

The health response and portal must explicitly identify `Simulation`. Stop the
stack without deleting named volumes:

```bash
./scripts/stop-local.sh
```

No PLC, RFID reader, actuator, machine I/O, or hazardous supply is connected at
this stage.

