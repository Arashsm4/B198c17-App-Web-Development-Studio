# Implementation status

Baseline: `CH1 / Cinerion / P03 / IFV`  
Software checkpoint: `0.1.0-prototype.1`  
Authority: simulation and controlled extra-low-voltage Prototype 1 only

> **This document describes the Prototype 1 checkpoint and is partly superseded.**
> Prototype 2 work is recorded in [`PROTOTYPE2_PROGRESS.md`](PROTOTYPE2_PROGRESS.md).
> In particular, the statement below that .NET, Compose and PostgreSQL are unavailable
> on the authoring host is no longer true: all three are installed and every gate runs
> locally. The .NET solution did not compile at this checkpoint and its tests had never
> executed; both are fixed.

## Implemented in this checkpoint

- Monorepo and bounded-domain structure
- Versioned API and message contracts
- Guarded semantic-command aggregate
- PREPARE, cryptographic-presence proof, button-edge, final-permissive and
  LOCAL COMMIT executable state model
- Rejection of expiry, duplicate/replay, wrong target, stale revision, held
  button, remote button emulation, changed interlock, and restart continuation
- Fault latch and local-only recovery model
- Hash-linked append-only audit model and verifier
- Physical-part, work-order, measurement, hold, NCR, retest, and segregated
  release domain foundations
- PostgreSQL schema baseline and row/object-scope foundations
- Expo universal operator portal shell with explicit freshness, quality, and
  authority language
- EdgeLink protocol-provider boundary and simulator adapter
- Portable embedded state-machine core with host tests
- Siemens S7-1200 G2 Structured Text source skeleton and PLCSIM scenarios
- Local Compose topology, health checks, secret boundaries, and simulation-only
  defaults
- CI, repository policy, traceability, secret-pattern, and contract checks

## Verified quantities

| Control | Result |
|---|---:|
| Frozen baseline files with matching SHA-256 | 74 |
| Controlled requirements | 87 |
| Linked verification cases | 87 |
| Implementation-map entries | 87 |
| Controlled API operations | 54 |
| Executable TypeScript state-model tests | 12 |
| Portable firmware host suites | 2 |
| Statically exported portal routes | 8 |

The local authoring host verified the TypeScript, portal, traceability, policy,
contract, and portable C++ gates. .NET, Compose, and PostgreSQL execution remain
mandatory CI gates because those runtimes are not installed on this host.

## Intentionally incomplete or gated

- Real FIDO2/card reader integration and production key ceremony
- Exact Siemens PLC order code, OPC UA licence, and hardware communication module
- Machine-specific safety functions and electrical design freeze
- Production firmware fuse/secure-boot provisioning
- Hardware-in-the-loop execution evidence
- Independent technical review, scheduled after Prototype 1
- Production deployment, certification, customer delivery, and final release

An unimplemented or unexecuted gate is reported as such and must not be inferred
from the existence of source code.
