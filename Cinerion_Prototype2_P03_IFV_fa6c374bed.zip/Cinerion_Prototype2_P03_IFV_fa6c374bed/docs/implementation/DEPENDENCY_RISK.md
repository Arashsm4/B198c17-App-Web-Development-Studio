# Dependency risk record

Record date: 2026-08-06  
Last updated: 2026-08-12  
Owner: IR  
Scope: `0.1.0-prototype.1`

## .NET disposition — `Microsoft.OpenApi` (CVE-2026-49451)

Recorded 2026-08-07 on first execution of the .NET gate.

`Swashbuckle.AspNetCore` 10.0.1 resolves `Microsoft.OpenApi` 2.3.0, which carries
GHSA-v5pm-xwqc-g5wc / CVE-2026-49451 (High, CVSS 7.5): a circular schema reference
in a parsed OpenAPI document terminates the process by stack overflow. NuGet audit
raises NU1903, and `TreatWarningsAsErrors` correctly turns it into a failed restore.

**Decision: remediated, not accepted.** `Microsoft.OpenApi` is pinned to 2.7.5 — the
first patched release on the 2.x line — in `Directory.Packages.props`, taking effect
through `CentralPackageTransitivePinningEnabled`. The minimum patched version was
chosen over the newest 2.x to limit unintended behavioural drift from the version
Swashbuckle was built against.

`NU1903` was **not** suppressed. Suppression would have left a reachable
high-severity defect in the component that parses externally supplied documents.

Reassess when Swashbuckle publishes a release that resolves a patched
`Microsoft.OpenApi` directly, at which point the pin can be removed.

## .NET disposition — `SQLitePCLRaw.lib.e_sqlite3` (CVE-2025-6965)

Recorded 2026-08-16, on the first build after CH1-NFR-REL-0001's gateway buffer was added.

`Microsoft.Data.Sqlite` 10.0.10 resolves the SQLitePCLRaw 2.1.11 family, whose native
package carries GHSA-2m69-gcr7-jv3q / CVE-2025-6965 (High): in SQLite before 3.50.2 the
number of aggregate terms can exceed the number of columns available, which is a
memory-corruption defect. NuGet audit raises NU1903 and `TreatWarningsAsErrors` correctly
turned it into a failed restore — the buffer's first build never compiled.

**Decision: remediated, not accepted.** `SQLitePCLRaw.bundle_e_sqlite3`, `.core`,
`.lib.e_sqlite3` and `.provider.e_sqlite3` are pinned to 2.1.12 — the first release outside
the advisory's stated range — in `Directory.Packages.props`, taking effect through
`CentralPackageTransitivePinningEnabled`. The minimum patched version was chosen over 2.1.13
or the 3.x line for the same reason `Microsoft.OpenApi` was pinned to 2.7.5: to limit
behavioural drift from the version `Microsoft.Data.Sqlite` was built against.

`NU1903` was **not** suppressed.

**The pin is not trusted on its own.** A version pin is a claim about what NuGet resolved;
`EdgeBufferTests.TheLoadedSqliteIsPastTheControlledAdvisory` opens a real buffer and asks
the loaded native library what it is — `SELECT sqlite_version()` — and fails below 3.50.2.
A future resolution that quietly reintroduced the defective engine therefore fails a test
rather than passing a version comparison.

Reassess when `Microsoft.Data.Sqlite` ships resolving a patched SQLitePCLRaw directly, at
which point the four pins can be removed.

## Current audit disposition

The locked JavaScript graph has no known high or critical advisory at release
time. The audit reports a moderate advisory for `uuid@7.0.3`, reached through
Expo's bundled native project-generation path:

`expo → @expo/cli → @expo/config-plugins → xcode → uuid`

The reported defect concerns caller-supplied buffers in UUID v3/v5/v6. Cinerion
does not invoke this package in the application runtime, does not generate those
UUID variants from untrusted input, and does not ship the Expo CLI in the final
static web container. The exposure is therefore restricted to a trusted build
workstation/CI context.

## Decision

Risk is temporarily accepted for Prototype 1 because the upstream `xcode`
package constrains `uuid` to major version 7. Forcing `uuid` 11 clears the
scanner finding but produces an invalid, vendor-unsupported dependency graph.
That override is prohibited.

Controls:

- lock-file installation with `npm ci`;
- no untrusted native project input in CI;
- no **runtime-reachable** high or critical audit finding permitted, and no accepted
  finding without a recorded reachability claim, its evidence and an expiry date
  (amended 2026-08-12; see "Enforcement" below for why the earlier absolute wording no
  longer described what the graph does or what CI could check);
- full audit JSON retained with CI evidence;
- SBOM generated for every CI run;
- Dependabot monitors npm and GitHub Actions weekly;
- reassess when Expo or `xcode` publishes a compatible patched graph, and before
  any production release.

This is an engineering risk acceptance, not a claim that the dependency is
vulnerability-free.

## `image-size` — GHSA-w3rx-r6r6-pgpr and GHSA-5p2g-fcmc-qvqq (High)

Recorded 2026-08-12, on first execution of the dependency-audit gate.

Metro resolves `image-size@1.2.1`. Two advisories describe infinite loops in the ICNS,
JXL and HEIF parsers, both with the range `<=2.0.2`. **There is no fixed release**:
2.0.2 is the latest published version and is itself in range, so neither an upgrade nor
an `overrides` entry can clear it. npm reports a fix as a downgrade of `expo` to
53.0.27, which is a major regression of the portal toolchain and still leaves Metro
depending on `image-size`.

`npm ls image-size --all` resolves exactly one instance, reached only through the
bundler. The parser runs at export time, on the build host, against files already in
this repository. `apps/operator-portal/dist` was searched and contains no `image-size`
code. An attacker would need commit access to place a malicious image, which is a
strictly greater capability than stalling a build.

**Decision: accepted until 2026-11-12** as a build-toolchain risk, recorded in
`traceability/dependency-disposition.json`.

## Enforcement

The disposition above is no longer prose alone. `scripts/check-dependency-audit.mjs`
(`npm run audit:deps`, and a CI step) runs `npm audit --omit=dev --json` and reconciles
every advisory it reports against `traceability/dependency-disposition.json`. It fails
on an advisory with no disposition, on a disposition the audit no longer reports, on a
missing reachability claim or evidence, on an accepted risk whose review date has
passed, and on any attempt to accept a runtime-reachable high or critical.

An accepted risk therefore expires rather than persisting silently, which is the
difference between a disposition and a suppression. The earlier control "no
high/critical audit finding permitted" was already untrue of the installed graph and
was not checked by anything; it is amended above to the rule that is now enforced.
