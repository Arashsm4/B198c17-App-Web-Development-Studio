# Implementation architecture

## Authority model

The portal requests domain intent. Control Core decides whether the requester
may prepare it. EdgeLink translates only an accepted semantic contract. The
cell controller independently validates preparation and owns the local state
machine. A credential verifier proves local presence but cannot start motion.
The physical button produces a local edge but has no authority unless armed for
the same command. Local permissives are authoritative and sampled immediately
before commit.

No layer is allowed to collapse these decisions into one “start” call.

## Bounded modules

| Module | Responsibility | Explicit non-authority |
|---|---|---|
| FortressGate | Human, service, and device identity context | Does not approve or command equipment |
| CommandGuard | Semantic intent, policy, idempotency, expected state, expiry | Cannot emulate local presence or permissives |
| ConfirmGate | Credential proof and button-event binding | Not a safety function; cannot prepare commands |
| ProtocolFabric / EdgeLink | Versioned adapter translation | Cannot invent domain intent or queue expired commands |
| ForgeFlow | Product, revision, route, and work-order control | Does not execute controller writes |
| TraceCore | Permanent part identity and genealogy | Does not release a failed/held part |
| OpenInspect | Procedures, instruments, measurements, limits, NCR/retest | Operator cannot independently release own work |
| AssetVault | Asset, device, capability, calibration, and configuration | Does not grant implicit network trust |
| ContextBridge | Object-linked messages and notifications | Message acknowledgement has no alarm/control effect |
| ResourceOrchestrator | Capacity, reservation, assignment, conflict | Physical-effect changes still use CommandGuard |
| ResearchBench | Isolated experiments and evidence | Default identity cannot reach production routes |
| ReportForge | Deterministic controlled reports | Cannot invent evidence or approval |
| AuditChain | Attributable append-only security/quality events | Hash chaining detects change; it is not confidentiality encryption |

## Runtime profiles

- `Simulation`: no physical outputs; deterministic test credentials and cell
  model are permitted and visibly marked.
- `PrototypeElv`: controlled extra-low-voltage bench only; real local inputs may
  be observed, but machine-specific hazardous outputs remain prohibited.
- `Production`: reserved. Configuration fails closed until hardware-backed
  identity, production credential verification, independent review, safety
  acceptance, signed artifacts, and recovery evidence are present.

