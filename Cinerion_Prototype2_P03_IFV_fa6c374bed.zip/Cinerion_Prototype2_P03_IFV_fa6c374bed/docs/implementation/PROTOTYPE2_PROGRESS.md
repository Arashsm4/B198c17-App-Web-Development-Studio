# Prototype 2 progress and handover

Working copy: `C:\Users\Arash_Sorati\Desktop\Projects\Cinerion\Claude`
Baseline authority: `docs/baseline/P03_IFV/` (frozen, 74 files, SHA-256 verified)
Governing rules: root `AGENTS.md`

This records the conversion of Prototype 1 into Prototype 2. It supplements
`STATUS.md` and `HANDOVER.md`, which describe the `0.1.0-prototype.1` checkpoint and
are **stale in one respect**: they state that .NET and Docker are unavailable on the
authoring host. Both are now installed and every gate runs locally.

**Start here.** Read this file, then the governing rules in `AGENTS.md` — which sits one
directory *above* the working copy, at `..\AGENTS.md` — then the baseline documents for
whichever subsystem you are about to touch. "Resuming work in a new session" below lists
the operational details that cost time to rediscover.

---

## Current state

| Measure | Value |
|---|---|
| Controlled API operations | 54 |
| Implemented | **52** — the two publication-package operations left the gated list, where they should never have been: CH1-DOC-FR-0004 is "Baseline P03", not a design target |
| Still gated (controlled `501`) | **2** — the secure document vault only. CH1-DOC-FR-0002 wants a per-document data-encryption key behind a separate key-encryption boundary and CH1-DOC-FR-0003 a hardware-backed credential to decrypt; a vault without those is not a vault |
| .NET tests | **513 pass, 0 skipped** — 124 domain, 287 API, 102 EdgeLink, counted from a strict run. The API assembly gained 8, all of them about a bound instrument adapter and five of them refusals. *The earlier figure follows.* **500 pass, 0 skipped** with `CINERION_POSTGRES_CONNECTION` set — 124 domain, 274 API, 102 EdgeLink. Counted from a run, not carried forward |
| EdgeLink operational protocol adapters | **4** — simulator, MQTT 5, OPC UA and Modbus TCP. **None gated**: every protocol CH1-COM-FR-0003 names has a live counterpart. **Three now source controller state** (simulator, Modbus, OPC UA), and a cell with two claimants publishes none rather than picking a winner. For the two stand-ins that front the guard, sourcing it is what makes an unanswered permissive observable rather than merely absent |
| EdgeLink → Control Core | **CH1-COM-IF-0003 is operational**: internal gRPC, Protobuf, mutual TLS. What the adapters observe now reaches the domain |
| Controlled verification cases | 87 |
| …bound to executable evidence | **76** — was 75. CH1-VVT-TC-0066 gained a second binding, `ai-prohibition`, and CH1-VVT-TC-0080 gained `portal-egress`. Counted from a run of `npm run verification`, which reports 18 of 18 announcing harnesses reconciled. The earlier note follows: **75** — was 72. CH1-VVT-TC-0090, 0091 and 0092 joined them |
| …fully exercised (`automated`) | **34** — was 33. CH1-VVT-TC-0066 joined them, and it is the one worth reading, because the case did not move by being tested harder. It was `partially_automated` bound to one harness whose own note said what that was worth: "no AI role exists … That is the absence of authority, not a test of a service that does not exist." A role register can be complete while a client library three layers down posts controlled evidence to a model endpoint, because a service reaching out needs no role. `ai-prohibition` is the second binding and measures the absence over the deployable tree. The earlier note follows: **33** — was 31. CH1-VVT-TC-0090 and 0091 joined them: each is measured end to end rather than argued |
| …`partially_automated` | **44** — was **45**, and this row is worth reading twice. CH1-VVT-TC-0066 left for `automated`, which takes 45 to 44. The row previously SAID 44 while the map held 45: it had drifted by one at some earlier point and nothing compared the two, so the correction above was itself briefly wrong (43) before the statuses were counted from `verification-map.json` with a script. Third instance of the rule this document already states about the portal’s operation count — **a figure a gate derives from the source cannot drift away from the source, and a figure typed into a table can and did.** `npm run verification` prints the distribution on every run; that print is the authority, not this cell. The earlier note follows: **44** — was 43. CH1-VVT-TC-0092 joined them, and stops there deliberately: the platform half is measured and the CPU’s own scan cycle is not |
| …`not_executed` | **2** — 0065 needs an AI service and 0071 is an analysis activity. **0065 is now understood to be permanently not executable here, not merely pending**: `CH1-AI-FR-0001` requires AI output to identify the records it used and remain subject to human verification, which presupposes AI output, and the owner’s instruction of 2026-09-17 is that there be no AI service in the product at all. That instruction agrees with `access.json`, `CH1-AI-FR-0002` and `CH1-SWA-ADR-0010`; the consequence is that satisfying 0065 would require building the thing 0066 exists to forbid. It stays `not_executed` with that reason recorded rather than being closed or quietly dropped. Was 5; the three that left were the performance cases |
| …`hardware_gated` | **4** — was 5. CH1-VVT-TC-0073 left: the watchdog DECISION is now executed on a host, and only its real timing is hardware. The remaining four are the real S7-1200 G2 CPU: order code, TIA version, block hashes and a witnessed PLCSIM run |
| …`future_controlled_phase` | **3** — CH1-VVT-TC-0128 and 0129 are the secure document vault. 0130 is the clean-room redaction this session implemented, and is left classified as it was for the owner to re-classify rather than re-classified here |
| …with no binding at all | **12** — the 5 hardware-gated, the 3 future phase, the 2 not executed, and 2 that are gate-only |
| Controlled operations with an HTTP-level test | **52 of 54** — every implemented operation. The 2 remaining are the gated document vault, which has a test that it *stays* gated **and** a test that the two operations which left that list have genuinely stopped answering 501 |
| TypeScript state-model tests | 12 pass |
| Portal screens laid out in a real browser | **61 rendered scenarios × 3 widths = 183 layouts**, clean - `npm run layout:portal`, headless local Chrome, no new dependency. Before this nothing in the pipeline had ever laid a page out; jsdom’s widths are all zero, which is how a title squeezed to 0 × 836 px passed 630 checks (defect 84). Its positive control caught the gate’s own first draft twice |
| Portal screens on live data | **22 of 22** declared in `screens.json`, **measured by a gate** rather than hand-counted — the render gate names every one it exercised. The four that once had no controlled operation behind their subject are served by the owner-approved reads, each recorded with the screen it serves |
| Portal consequential mutations | **5** (alarm acknowledgement, message receipt, reserve/release, establish project, end session) |
| Portal capability register | **32 controlled acts in one place**, `apps/operator-portal/src/api/capabilities.ts`, each quoting its authority phrase from `api_endpoints.json` verbatim and mapped only to roles `controlled-authorities.json` grants it. It replaces `roles.includes(…)` decided ad hoc in eight screens. `npm run capabilities` refuses a widening, a paraphrase, an uncatalogued operation, an unexplained narrowing, an authority dropped by declaring no roles, an undeclared screen and a duplicate; 12 attacks, 0 holes. The same gate MEASURES how many controlled writes the portal issues — **32 of 39** — by walking the source's string and template literals rather than matching them, because that figure has been produced by a grep and been wrong more than once |
| AI services in the deployable tree | **0, and that is now measured rather than assumed** — `npm run ai:prohibition` over 455 files and 75,725 non-comment lines: no AI client dependency among 25 npm dependencies in 4 manifests and 24 centrally managed NuGet packages, no AI service host (18 refused, `bedrock-runtime.` as a prefix because that host is regional), no model identifier (14 patterns), no service credential (17 names), no AI actor kind among the 4, no AI role among the 16 constants or 15 realm roles, no AI realm client, and no AI component among the 14 in the controlled architecture register. It reads the prohibition FROM `access.json` ("Approve or command via AI — role **None**, strength **Not applicable**, **Explicitly prohibited**"), `CH1-AI-FR-0002`, `CH1-PMG-AIU-0005` and `CH1-SWA-ADR-0010`, so it refuses rather than continues if the baseline stops stating the rule. Because a gate searching for ABSENCE cannot tell a clean tree from a broken search, all 7 matcher classes fire against buffers that DO contain what they refuse before any conclusion is drawn. 23 attacks, 0 holes, two of which blind those matchers |
| Public-internet origins in the shipped portal | **0 that are reachable, and 9 inert ones allowlisted by name with a reason** — `npm run portal:egress`. 27 exported files, 12 distinct absolute origins, 3 local; of the rest, eight are namespace identifiers, OIDC claim identifiers, library error text or `.example` placeholders, and one — `https://auth.expo.io`, Expo’s hosted auth proxy — is a REAL public service whose two INDEPENDENT reasons for being unreachable are asserted instead of waved at: `makeRedirectUri()` takes no options (which is where `useProxy` would live) and the controlled realm permits only loopback redirect URIs. Beside it the CSP’s 8 directives and 13 sources are each a keyword, a `data:` URI or a local origin, with `default-src 'self'` and no `'unsafe-eval'`. 18 attacks, 0 holes. **This is the portal half of CH1-OPS-FR-0001, which `check-offline-workflow.sh` never covered** — that gate proves the SERVICE completes on a network with no route out, and a browser is a general-purpose fetching machine |
| Device identities over HTTP | **implemented**. Control Core answers device identities on its own mutually authenticated listener; a client certificate is resolved to an ENROLLED device record and the project, cell and role come from that record and never from a header. All five settings or none, so an unconfigured deployment has no device listener rather than one without client certificates, and `GET /api/v1/system/health` reports which |
| The controlled local-commit sequence | **executed end to end**, `npm run commit:loop`, 18 checks 0 failed: prepare → credential proof → button edge → interlock re-sample → LOCAL COMMIT → Committed. The controller's half is performed by `simulators/cell-confirmer`, a separate service with its own device certificate — the portal has no route to either controller operation and the policy gate still refuses both strings in its tree. **Nothing physical happens**: the edge is marked `SimulatorInjection` and the presence `SimulatedPresence`, both refused outside the Simulation profile and both audited as marked |
| Controlled authorities reconciled | **49 of 49** authority phrases in `access.json` and `api_endpoints.json`, each mapped to a role `CinerionRoles` defines or to a stated reason for not being one — `traceability/controlled-authorities.json`, enforced by `npm run policy`, 5 attacks 0 holes. This is what conflicts 9 and 23 turned out to be |
| Controlled roles | **15** — `ProjectOwner` joined them, because `stakeholders.json` declares it ("IR - Project Owner") and nothing implemented it. Conflict 23 |
| Owner-approved reads outside the catalogue | **6** — `GET /api/v1/parts?serialNumber=` joined them for conflict 15. Every one is still a READ, refused outright by the policy gate if it is not |
| Executable obligations with no controlled case | **6**, recorded in `traceability/executable-obligations.json` with what each gate refuses AND what it does not establish. `npm run verification` refuses an entry that names a CH1-VVT-TC identifier at all |
| Portal response shapes compared against a real response | **53 of 53**, `PartIdentity` the newest. The earlier note stands: **43 of 43** at the time, four more than before — `AuditPage`, `ChainVerification`, `DirectoryPage` and `DirectoryUser` were declared on their screens rather than in the contract source, so nothing reconciled them. See defect 48 |
| Defects found and fixed | **80 numbered**, of which 76-80 are the session of 2026-09-16's. Four of the five are pre-existing; **80 was latent until this session made it reachable** — the safety-boundary scan swept the ESP-IDF build tree the moment one existed, and would eventually have accused a vendored file of energising an output. 76 and 77 came from reading `assets/prepare-local-commit.svg` — item 45 happening a second time, on the sequence diagram this time: the controller's answer to a command was filed under a fresh random correlation identity so it could be joined to nothing, and the command read carried the domain's decision and never the equipment's answer. 78 is the one a reviewer SEES: the controlled compose model built a portal with no OIDC authority at all, because `EXPO_PUBLIC_*` values are inlined at build time and the service passed no build arguments — the portal's "identity provider not configured" screen was honest and the model was what left it that way. 79 came from the first ESP-IDF build this repository has ever run, and is defect 33's precedent holding exactly: three of the six components `REQUIRES` named do not exist in ESP-IDF v6.0, including the one `time_sync.cpp` needs, so the project could not even configure. The earlier count follows: **75 numbered**, of which 69-75 were that session's. **74 and 75 were introduced by this session's own work** and are the third and fourth in that run — 67 and 68 were the same in the session before. 74 is the one to read: the fix for defect 69 could be pre-empted by the branch above it, so defect 69's exact shape re-entered through the fix for it, and eleven scenarios agreed it was sound because every one set a single input at a time. Of the pre-existing five, Six are pre-existing and four of those were found by reading the controlled state diagram as a transition table rather than as a picture — including a guard that held an execute permit no event could clear. Two of the five (72 and 73) are in the credential enrolment path, and 72 is the one worth reading: a control that was absent AND recorded as performed. The earlier count follows: **59 numbered**, of which **53 have their own entry** in the list below. Six numbers — 37, 38, 43, 44, 45, 46 — have no entry anywhere in this document and never did; 37 is mentioned in passing and the other five are not. Counted rather than carried forward, and the gap is recorded rather than filled in with invention. This session added 56–68, of which **59 and 66 are reported and not fixed**. Ten of the twelve were invisible to inspection: two were found by a compiler that had never been pointed at the file, three by RUNNING the firmware rather than testing it, one by asking the database what it would permit rather than asking the code what it does, one by asking whether a field the struct declared was ever read, and **two — 67 and 68 — were introduced by this session's own fixes**. 67 survived 478 passing tests, a 31-check gate, an 8-attack suite and a green strict pipeline because nothing exercised that write path against a real database; 68 was a timing bug inside the fix for 56 |
| Defects introduced this session and caught by a gate | **2** (both portal contract errors) |
| Migrations | **15** — `0015_source_time_quality.sql`, with 18 startup probes. It is NULLABLE on purpose: "the source declared nothing" is a fact, and a retention window of history cannot be given a quality nobody observed |
| Declared retentions that are executable | **3 of 10** — was 1. `MessageAcknowledgement` and `RoleAssignment` joined `TelemetrySample`; they are the only other two whose declared period is absolute rather than relative to a lifecycle end the schema does not record (conflict 25) |
| Controlled I/O signals | **24**, and the firmware names them for the first time. `firmware/pinmap/esp32s3-r01.json` is the hardware-revision-controlled pin map CH1-HWE-IOL-0001 requires, 20 signals owned by the ESP32-S3 on 24 GPIOs and 4 owned by another controller with a stated reason; `npm run io:map` reconciles it against the controlled table and against the firmware's own copy |
| Demonstration dataset | **off by default**, `CINERION_DEMONSTRATION_DATA`, refused in the Production profile. Populates every declared screen's backing read so an empty screen and a broken screen stop being indistinguishable. Every reading `Simulated`, no command executable, no credential able to authenticate — asserted by 14 tests at the store and by `npm run demo:data` over HTTP against PostgreSQL |
| Hardware, as a simulation | `simulators/cell-controller` runs the cell from the SAME translation units the board would compile; only the pin reads are synthetic. Ten assertions, run inside `verify.sh`. **It found defects 64, 65 and 66**, none of which any test had caught |
| Firmware host binaries | **6**, plus the cell simulation, plus — for the first time — a REAL ESP-IDF build of `firmware/esp32` (`npm run esp:build:windows`, ESP-IDF v6.0.3, target esp32s3). That is the only thing that has ever compiled `time_sync.cpp`, and its first run found defect 79. The earlier count follows: **6**, plus the cell simulation — was 3. The conditioned I/O layer joined them, and **the ESP32 entry point is now compiled** against stubs. It never had been, and it did not build |
| Actuator outputs energisable | **0 of 2**, and that is enforced in two places: the policy gate now covers every firmware source rather than the entry point alone, and the pin map's `energisable` field is refused by the same gate. Attacked, 5 attacks 0 holes |
| Defects introduced and caught by running the screens | **2** (24 and 25 below) |
| Defects introduced and caught by running the gRPC edge | **3** (40, 41 and 42 below — the REST API vanished, then redirected onto the gateway's port, then refused its own healthcheck) |
| Overall Prototype 2 progress | **~99%**, and on 2026-09-16 the two things that had never been done were done: `npm run demo:data` passes (18 checks, 0 failures, against a real service on PostgreSQL) and `npm run retention:verify` passes (26 checks, 0 failures, after migration `0015` touched `ch1.telemetry_samples`). **The ESP32-S3 firmware is compiled with the real toolchain for the first time** — 1070 targets, `time_sync.cpp` among them, 0x3fa50 bytes with 75% of the app partition free, nothing flashed. The earlier assessment follows. What is left is not effort in this repository: 2 gated operations needing a key-encryption boundary, 4 hardware-gated cases needing the real S7-1200 G2 CPU, the 5 HIL cases needing a rig, 2 cases needing an AI service or an analysis activity, and the conflicts below that require a controlled DOCUMENT to move rather than code. Six conflicts were resolved this session — 9, 13, 15, 23, 27 and 30 — and conflicts 18, 20, 26 and 28 have their second branch taken and recorded |
| EdgeLink store-and-forward | **CH1-NFR-REL-0001 implemented and verified**: 24 h on disk, derived capacity, critical events never evicted for telemetry, records surviving the gateway that wrote them |
| Executable gate scripts | `commit:map`/`commit:attack` and `arch:map`/`arch:attack` joined them on 2026-09-16, both wired into `verify.sh`, and `esp:build:windows` joined the on-demand list. The earlier note follows: `cell:map`/`cell:attack` and `authorities:attack` joined them, both wired into BOTH entry points. The earlier count follows: **16** announcing harnesses inside `npm run verification` — `firmware-io` joined them — plus `retention:verify`, `retention:records` and `io:map`, which announce no case by design, and three attack suites (`io:attack`, `safety:attack`, `retention:attack`) whose only output is whether a gate refuses the thing it exists to refuse. `load:verify` moved from the second list to the first: it announced nothing for two sessions because the requirement was not met, and it announces CH1-VVT-TC-0090 and 0091 now because it is |
| Portal screens **rendered and checked in CI** | **all 22**, by `npm run render:portal`: **60 scenarios, 630 checks**, and for the first time those scenarios render the DESKTOP shell — jsdom answers 0 for the document element's client box, so every previous scenario measured a zero-width window and took `AppShell`'s compact branch. *The earlier figure follows.* **45 scenarios, 464 checks**, no Docker and no database. A built screen with no scenario driving it **fails the gate**, so the coverage cannot silently regress. Before this existed, no screen's rendered behaviour was checked by anything |

Build is clean: `dotnet build -c Release` → 0 warnings, 0 errors.

`./scripts/verify.sh --strict` is the authoritative gate, and this session changed what it
covers in three ways worth knowing before reading any claim it makes.

- **It no longer downgrades a failed harness to a skip.** Step `[11/14]` decides that from
  its own arguments, and a strict pipeline was invoking it plainly — so a harness that
  genuinely failed printed `SKIPPED locally` and the run still exited 0. Observed, not
  theorised: that is exactly what the first run of this session did with the backup
  harness. Defect 51.
- **`baseline-load` now runs inside it.** For two sessions the load harness announced
  nothing, which was the honest answer while the rate was 21 msg/s. It is in the pipeline
  now because the requirement is carried, and it belongs there precisely so that it goes
  back to announcing nothing the moment it stops being.
- **Two harnesses were bound to ports Windows had taken.** Hyper-V reserves large blocks of
  the 5000–5700 range at boot, and both the backup and retention gates hard-coded a port
  inside it. Defect 52.

Fifteen announcing harnesses are reconciled against real runs. The pipeline needs Docker
Desktop started, because step `[0/14]` fails the workstation preflight when the daemon is
unreachable, and it needs `CINERION_POSTGRES_CONNECTION` set for the PostgreSQL-gated tests
to run rather than skip.

**Run end to end on `908264f` and green.** All fifteen steps `[0/14]`…`[14/14]`,
"Cinerion Prototype 1 verification completed", nothing skipped and nothing reported as
passed that did not run: **478** .NET tests with 0 skipped, and
`Verification map valid: 87 controlled cases, 76 with executable evidence, 17 of 17
announcing harnesses reconciled against a real run`, and
`Portal render gate: 44 scenarios, 458 checks, 0 scenarios failed` across all 22 screens.
The only lines in the log matching "skip" or "fail" are the counts that report zero of them.
Execution statuses: 45 partially_automated, 33 automated, 2 not_executed, **4 hardware_gated**
and 3 future_controlled_phase.

**It took seven attempts across this session, and the six refusals are again the most useful
part.** Two of them were defects this session had introduced into its own fixes — 67, a NOT
NULL column with no writer, and 68, a backlog measured after the drain had removed it — which
is the strongest argument in this document for running the pipeline again after every change
rather than after the last one.
The first refused at the gateway buffer for holding ONE record, which turned out to be the
gate asking whether the buffer was empty rather than whether the outage had drained (defect
56). The second and third refused at the load harness's 80 % collapse floor, and the fourth
added a gRPC "safety violation" that had not happened — the check reading an unreadable
answer as a count (defect 62) — plus a verification database the daemon dropped mid-run. The
load refusals were defect 63: the harness runs last, after fourteen gates have filled
Docker's disk, so it was measuring the pipeline rather than the service. **Neither the 80 %
floor nor any other control was relaxed to reach this green run.**

*The previous session's run, for the record:* **it took four attempts, and the three failures are the most useful thing in this section.**
The first refused at `[11/14]` with no reason at all — defect 54, a diagnostic that printed
the first line of a harness's output when a shell gate's output begins with a blank one. The
second, with the diagnostic fixed, named the workstation's disk. The third named a load
measurement taken beside a protocol lab that a previous gate had left running, and then an
OPC UA check that had been counting log lines and racing a reconnect. Every one of those was
found because defect 51 made a strict run refuse where it used to print a skip and exit 0.

### This session, packaged: what a brand-new machine found that the working lab never could

The owner asked for the whole project as a zip with a README, an installation guide and an
automatic installer. The deliverable is `Cinerion_Prototype2_P03_IFV_<commit>.zip`, built by
`npm run package:release` from the committed tree, with `install.cmd` / `install.ps1` (Windows)
and `install.sh` (Linux, macOS, WSL), `INSTALL.md` and a rewritten `README.md`.

**The part worth reading is how it was tested.** Not on this workstation's lab, which has run on
the same Docker volumes since 2026-08-07, but by extracting the zip with Windows' own
`Expand-Archive` into an ordinary folder and running the installer unattended against a
separate Compose project (`COMPOSE_PROJECT_NAME=cinerion-installtest`), so every volume was
empty: fresh secrets, a fresh device CA, fifteen migrations on an empty database, a realm
imported into an empty Keycloak. That is the first time anything in this repository had been
installed from nothing since August, and it failed four times before it passed. Every failure
was a real defect, and **three of the four were invisible to the only lab that existed**:

1. `bootstrap-local` wrote five of the seven secrets the lab needs. The other two had been
   added by hand on this workstation. A new machine stopped at "CINERION_APP_PASSWORD is not
   in infrastructure/.env.local". Defect 88.
2. `npm run package:release` called `zip`, which this workstation has never had; and npm runs
   scripts through cmd.exe on Windows, where `./scripts/x.sh` isn't a command - so
   `package:release`, `doctor`, `verify` and `simulate:cell` had never run from npm here.
   Defect 89.
3. **Keycloak refused the controlled realm**: `Unrecognized field "_sessionLifetimeNote"`. A
   note had been put inside the JSON as a fake field on 2026-09-17. Keycloak never started, so
   nobody could sign in. It hid because an existing realm is never re-imported - and the one
   lab's Keycloak container had been running since before the field existed. **This session's
   own `npm run lab:down` removed that container, so the owner's lab was one restart from the
   same failure.** Defect 90.
4. With the field gone, Keycloak parsed the realm and then died writing it: `value too long for
   type character varying(255)`. The identity-admin client's description had been 505
   characters since 2026-08-09 - two days after the only identity database was created. Every
   fresh install for six weeks would have failed here. Defect 91.

`npm run policy` now refuses both realm hazards (any `_` key; any string over 255 characters
outside `components.*.config`), and both checks were attacked. A misspelled real field would
still get past a static check, which is why **the realm must be imported into an empty identity
database before anyone believes it** - resuming item 88.

Then the installer itself, tested the same way. Its log captured 64 lines and none of the lab's
own output, because Windows PowerShell 5.1 keeps native output out of the transcript (defect
93). Unzipping a newer version into a new folder would have generated fresh secrets over old
volumes and locked the lab out of its data; both installers now stop before changing anything
when data exists and secrets don't, and that stop was exercised, as was the documented upgrade
(copy `.env.local` across, re-run: 115 s, 11 of 11). And every re-run reported "FAIL the
stand-in controller could not be enrolled" for a controller that was enrolled and working,
because busybox wget never shows the body that says so (defect 92).

One apparent failure was **not** a defect and is recorded so nobody chases it: the first test
extraction lived in this session's own scratch folder under `AppData\Local\Temp\claude`, and
PostgreSQL's `postgres` user got `I/O error` reading every migration from there while root read
them fine. The same zip unpacked with `Expand-Archive` into an ordinary folder - or into plain
`%TEMP%` - reads fine as `postgres`. It was the test location, not the package.

**What the package does not do:** a password sign-in cannot perform a step-up (conflict-level
finding, below), and the build still reports `0.1.0-prototype.1` as its version string because
that is spread across fifteen files and changing it is a release decision nobody asked for.
`BUILD_INFO.txt` pins the exact commit instead.

**Why no step-up can work in a browser - found while writing the install guide.** Every step-up
grant requires the session to be at least multi-factor (`StepUpGrant.Issue`,
`AUTH_STRONGER_AUTHENTICATOR_REQUIRED`). Control Core derives that strength from the token's
`amr` claim, and the controlled realm neither asks for a second factor nor has an AMR mapper,
so every password sign-in is single-factor. Registering a passkey is itself a step-up act (MFA,
`CredentialAdministration`), so there is no way in. That is precisely why the CommandGuard
"join the two halves" item could never have succeeded, and it is now explained rather than
merely failed. Turning on OTP at sign-in plus Keycloak's AMR mapper would open the chain; it is
a sign-in design change and is left for the owner, stated in `README.md` and `INSTALL.md`.

### This session, continued: a page title that became a vertical word search

The owner signed in at `http://localhost:8081` for the first time with the full lab identity
and sent a screenshot of the Security screen. The screen identifier ran down the page one
character at a time, the 28 px title did the same, and a pill listing every role ran off the
right edge of the window. They asked for it fixed, for plain human comments across the code,
and for everything else to be finished.

**The bug, measured rather than described.** `PageIntro` is a row: the title column on the
left is `flex: 1`, and the `aside` on the right was a `StatusPill` holding every role joined
with ` · ` and upper-cased. The lab identity holds fourteen roles and Keycloak adds its own
`default-roles-cinerion`, so that pill was about 2,000 px of text. React Native's default
`flexShrink` is **0**, so the pill refused to give up a pixel, and the title column - allowed
to shrink with nothing to stop it - was squeezed to exactly **0 px wide and 836 px tall**, the
letters spilling out of an empty box. react-native-web's Text breaks words anywhere
(`overflow-wrap: break-word`), which is why it came out one letter per line rather than as
overlapping words.

**Why 630 green render checks never saw it.** The render gate drives every screen through
jsdom, and **jsdom performs no layout at all**: every width it knows is zero. Item 66
recorded half of this (it answers 0 for the document's client width); the other half is that
nothing in the pipeline had ever laid a page out. A test that cannot see layout cannot fail on
layout. And every security scenario signed in with two roles, so nothing was ever wide enough
to lose.

**The fix is at the root, not on one screen:**

* `PageIntro` wraps, gives the title a 260 px floor it cannot be pushed through, and wraps the
  aside in a box that may shrink - if the two cannot share a row, the aside moves below.
* `SectionHeading` got the same treatment; it had the same shape.
* `StatusPill` may never be wider than its container, and a long label wraps inside it. Short
  pills keep their size - the first attempt let every pill shrink, and "1 LISTED" split onto
  two lines, which the real-browser photographs showed within minutes.
* Security shows roles as chips (`components/role-chips.tsx`) with a count, and Keycloak's own
  `default-roles-cinerion` is **disclosed as granting nothing** rather than counted as an
  authority or hidden. `ControlledRoleNames` is now a runtime list in `capabilities.ts` with
  the type derived from it, so there is one list instead of two. The Session screen and the
  "another role owns this act" notice stopped counting the provider's role too.
* The authority notice sizes like the panel it stands in for. It had no flex rules, so beside
  the Directory panel it kept its whole paragraph on one line and walked off the screen - a
  second overflow on the same page that only a real layout engine showed.

**The gate that can see it: `npm run layout:portal`.** The render run now photographs every
scenario (`CINERION_RENDER_SNAPSHOT_DIR`, reading react-native-web's rules back out of the CSS
object model, because `insertRule` never appears in a `<style>` tag's text). The gate opens
each photograph in the Chrome already on the workstation - headless, throwaway profile, driven
over the DevTools protocol with Node's own WebSocket, **no new dependency and no network** - at
1180, 1440 and 1920 px, and refuses anything past the window, squeezed text, or a page that
scrolls sideways. 61 screens × 3 widths = **183 layouts**, clean.

Its positive control is a small page carrying both of the screenshot's bugs, audited before
anything else, and **it caught the gate's own first draft twice**. The control page left out
react-native-web's `break-word`, and plain CSS spills a word out whole rather than breaking it,
so the "squeezed" check never fired; then the rule itself said `width > 0`, and the real bug
is **zero** wide. Either version would have printed "183 layouts clean" over a broken screen.
On the real pre-fix snapshot the finished gate refuses **18 times**, naming every symptom in
the screenshot.

**And it found one nobody had asked about.** The Resources capacity bar is a row inside a track
with `overflow: hidden`: an amber fill capped at 100 % and then a red over-commitment segment.
For a resource at 200 of 150 m, that is 100 % + 33 % inside a clipped track - **the red part,
the entire point of the bar, had never once been on screen**. It now scales to what was
committed, 75 % amber and 25 % red, and both fit.

`npm run layout:attack` puts each of those bugs back in the real source, re-renders the real
screen and requires a refusal for the stated reason: 7 attacks, 0 holes. One of its first
drafts was itself wrong - it expected a long pill inside a COLUMN to overflow, where CSS
already sizes it to fit and the page was fine - so the suite now also carries the control
proving the pill's width cap is what decides the ROW case.

**An attack suite that could damage the tree.** Re-running every attack suite after the
comments pass, `io:attack` crashed inside its own final restore - `UNKNOWN: unknown error,
open …esp32s3-r01.json`, errno -4094, a transient Windows lock on a file it had just
written - and left the pin map re-serialised with an attack's mutation still in it. It was
restored from `HEAD`; nothing was lost. It had never been noticed because **`io:attack` was
never in either pipeline**. All twelve attack suites now write through
`scripts/lib/write-settled.mjs`, which retries the transient errors and then reads the file back,
and `io:attack` runs after `io:map` in both entry points.

**Plain comments.** 267 source files - C#, TypeScript, C++, SCL, shell, PowerShell,
Dockerfiles - opened straight into a `using` or an `import` with nothing saying what they were
for. Each now starts with one or two plain lines written by hand from what the file does, a
little fun where that costs no accuracy. Files that already had a header were left alone, and
the frozen baseline, JSON and applied migrations were not touched. 267 files, 590 lines added
and 0 removed (265 of them in the comments commit, and `verify.sh` / `verify.ps1` in the commit
that wired `io:attack` - the comments commit message says 265, which is why this says both),
and the traps a comment can trip here were checked before writing - the portal policy's
refused route strings, the firmware GPIO names, `/*` and trailing backslashes under
`-Werror -pedantic` - and afterwards by building everything and running every gate that reads
source.

### This session: the prohibition that was a baseline rule with almost no evidence

The owner asked for two things in one sentence: that there be no Claude or AI API anywhere
in the code, and that the platform work completely offline.

Neither turned out to be a new requirement. Both are already controlled rules, and the
useful part of this session was finding that out and then discovering how little was
enforcing them.

**What the controlled documents actually say.** `docs/baseline/P03_IFV/data/access.json`
carries a row that is unlike every other row in that register:

| Capability | Role | Strength | Control |
|---|---|---|---|
| Approve or command via AI | **None** | **Not applicable** | **Explicitly prohibited** |

Every other row in that file grants something to somebody. This one grants nothing to
nobody. Beside it, `CH1-AI-FR-0002` is a **Must** verified by **Test** — "AI shall not
approve, release, authenticate, locally confirm or command physical equipment" — and
`CH1-SWA-ADR-0010` is **Accepted**: "Keep AI outside authentication, approval and command
paths." `CH1-PMG-AIU-0005` states the same thing with the status "**Baseline rule**", and
`CH1-CYB-THR-0018` allocates "AI prompt injection through evidence" to an Engineering
Assistant with "read-only isolation, provenance and human review" as its mitigation.

`ai_usage.json` is worth reading carefully, because it is the reason the question comes up
at all. All eight of its rows are about **document drafting** — structuring a baseline,
locating public standards pages, reviewing requirement wording, drafting a narrative from
controlled result records. AI produced documentation, under human review, and was recorded
doing so. None of those rows is about the product containing an AI service.

And the product does not contain one. `api_endpoints.json`'s 54 operations include no AI
operation. `screens.json`'s 22 screens include no AI screen. The controlled architecture
diagram draws fourteen components and the **Engineering Assistant is not one of them** —
so the component that two requirements and a threat are allocated to is drawn in no band
of the diagram at all. Measured, not assumed, because item 45 is specifically about
re-testing "the controlled source does not say".

So the owner's instruction and the baseline agree, and the strongest possible way to
satisfy `CH1-AI-FR-0002` is for there to be no AI service to prohibit. That was already
true. What was missing was any way to know it would stay true.

**What was enforcing it, and why that was thin.** `CH1-VVT-TC-0066` — "AI service has no
command, approval or release permission" — was `partially_automated`, bound to one
harness, and the verification map said in its own note exactly what that binding was
worth:

> "No AI role exists in CinerionRoles or in the realm ... That is the absence of authority,
> not a test of a service that does not exist."

That note was honest and it was also the finding. A role register can be complete while an
HTTP client three layers down posts controlled evidence to a model endpoint and writes the
answer into a record. **No role is required, because a service reaching out needs none.**
Nothing in the repository would have refused an AI SDK in a dependency manifest, an API
host in a configuration constant, or a model identifier in a settings file.

`npm run ai:prohibition` is now the second binding, and the case is `automated`. It
measures the absence over 455 files and 75,725 non-comment lines of the deployable tree:

* **no AI client dependency** — 25 npm dependencies across 4 manifests and 24 centrally
  managed NuGet packages, checked by declared NAME rather than by searching source text,
  so `ai` and `openai` can be exact without a word like "domain" tripping them. It also
  refuses a `.csproj` that pins its own version, because central package management is the
  only reason one manifest is the whole list — 13 project files, none of them pinning;
* **no AI service host** — 18 of them, including `bedrock-runtime.` as a prefix because
  that host is regional and an exact-match list would never see it;
* **no model identifier** — 14 patterns, shaped to require the hyphen-and-character form a
  model id has, so this repository's own directory name cannot match: a path carries a
  separator after the word, never a hyphen;
* **no service credential** — 17 environment-variable names;
* **no authority surface** — no AI actor kind among the 4 (`Human`, `Service`, `Device`,
  `System`), no AI role among the 16 constants or the 15 realm roles, no AI realm client,
  and no AI component among the 14 in the controlled architecture register.

**It reads the rule from the baseline rather than hardcoding it.** If `access.json` stops
prohibiting "Approve or command via AI", or stops prohibiting it as
`None`/`Not applicable`/`Explicitly prohibited`, or `CH1-AI-FR-0002`'s statement changes,
or `CH1-PMG-AIU-0005` stops being a "Baseline rule", or `CH1-SWA-ADR-0010` stops being
Accepted — the gate refuses and says the rule has moved. A gate that outlives its
authority is a gate nobody can reason about, and this repository has the opposite problem
often enough (conflicts 9, 15, 23 and 30 were all resolved by finding what a controlled
document already said) that it is worth being explicit about the direction.

**The positive control, which is the part worth copying.** A gate that searches for
ABSENCE prints the same thing whether the tree is clean or the search is broken. That is
item 71's failure — a backslash written into a patch script arrives collapsed, and a
regular expression with a dead `\b` silently stops matching — and it happened three times
in one session. So before the gate draws any conclusion about the repository, it runs all
seven of its matcher classes against synthetic buffers that DO contain what they refuse,
and refuses outright if any of them fails to fire. Two of the 23 attacks blind those
matchers deliberately, and both are caught by the positive control rather than by anything
else. It is the same reasoning as defect 75's "assert the mutation changed something",
pointed at a gate instead of at an attack.

**Two things were found and one of them had shipped.**

`MANIFEST.sha256` — the checksum list of the packaged release — contained
`./apps/operator-portal/.claude/settings.json` and `./apps/operator-portal/AGENTS.md`.
Editor plugin enablement and a two-line instruction addressed to a coding agent were
**inside a controlled, confidential release archive**. A third file,
`.claude/settings.local.json`, was tracked at the repository root and carried an absolute
path into a developer's home directory. None of the three is an AI API and none is product
material; the reason they are refused is narrower and is stated in the gate: how a
controlled deliverable was produced is something `ai_usage.json` is the controlled place to
state, and `scripts/package-release.sh` was copying an uncontrolled answer to that question
into the archive. All three are removed, gitignored, excluded from packaging, and the
exclusion itself is now checked — because currently-true is not enforced.

The gate refused `MaintenanceEngineer` on its first run, twice, because "MaintenAnce"
contains the letters a-i. Identifiers are now split on case boundaries and compared as
whole words. Worth recording as a class: a substring test over identifiers is item 63's
mistake in a different costume, where a pattern matched something that was never the thing
being looked for.

### The offline half, and the coverage gap the existing gate had

`CH1-OPS-FR-0001` is a **Must** verified by **Test**: "Principal workflows shall operate
on the local network without a public-internet dependency."

`scripts/check-offline-workflow.sh` already proves this behaviourally, and proves it well.
It creates a Docker network with `--internal`, **proves before anything else runs** that a
container on that network cannot reach a public host — without which the gate could pass
for two independent reasons, one of them an illusion — raises PostgreSQL and Control Core
on that network alone from the controlled images with every migration applied, and drives
the controlled quality path across it.

It covers the **service**. It does not cover the **portal**, and the portal is the half an
operator loads. A browser is a general-purpose fetching machine: a font declaration, an
analytics beacon, a source-map reference or a redirect through a hosted auth proxy is a
public-internet dependency that no server-side test would ever see — and one that arrives
through a dependency upgrade rather than through anybody's decision.

`npm run portal:egress` reads the artefact that actually ships:

* **The Content-Security-Policy**, whose non-`connect-src` directives are the browser's own
  enforcement: 8 directives and 13 sources, every one a keyword, a `data:` URI or a local
  origin, with `default-src 'self'`, `base-uri 'self'`, `form-action 'self'`,
  `frame-ancestors 'none'` and no `'unsafe-eval'` anywhere. A page under that policy cannot
  load a CDN asset even if a bundle asked it to.
* **The controlled compose model's four `EXPO_PUBLIC_*` arguments**, because the Dockerfile
  derives `connect-src` from exactly those — one place decides where the portal talks to,
  so that is the place to check that everywhere it talks to is local.
* **Every absolute origin in the exported bundle**: 27 files, 12 distinct origins, 3 local
  and 9 allowlisted BY NAME with a reason. An exemption for an origin the bundle no longer
  contains is refused too, so the list cannot outlive the artefact it governs.

**The one origin that is a real service, and why it needed different treatment.** Eight of
the nine allowlisted origins are inert: `http://www.w3.org` is an XML namespace identifier,
`https://openid.net` an OIDC claim identifier, and the rest are library error-message text
or placeholders from the `.example` reserved TLD. `https://auth.expo.io` is not — it is
Expo's hosted auth proxy, a live public service, and if the sign-in redirected through it
the sign-in would have a public-internet dependency. It is therefore not merely allowed.
The gate asserts the **two independent reasons it can never be reached**:

1. `makeRedirectUri()` is called with no arguments, which is where `useProxy` would live —
   and any argument at all is refused, not just the word, because the option could be a
   variable;
2. the controlled realm permits the portal exactly two redirect URIs and two web origins,
   all loopback, so Keycloak would refuse a proxy redirect even if one were built.

Either alone would be a single point of failure for a public host in the authentication
path. Both are asserted, and 3 of the 18 attacks remove one or the other.

**A hole the attack suite found in the gate, before the gate had ever been believed.** The
first revision skipped any compose value beginning with `${`, on the reasoning that a
substitution is an environment matter. Every one of the four arguments in the controlled
model is written `${NAME:-default}`, so the gate examined **none** of them and printed a
count of four. Writing attack 7 changed a value the gate was not reading and the gate
passed. It now parses the substitution's default, which is the value the model actually
decides, and counts separately the arguments left to the environment — because a count of
what a check skipped reads exactly like a count of what it approved. Two further attacks
(7b and 7c) exist only so that hole cannot come back quietly.

**What neither gate establishes, stated plainly.** The AI gate is static: it proves nothing
is in the tree, not that nothing is reachable at runtime. The egress gate reads the shipped
artefact and the policy governing it, not a running browser. There is **no harness driving
a real browser on a network proven to have no route out**, and there cannot easily be one
here, because a browser run needs a person at the keyboard (item 11). Both gates print that
sentence themselves rather than leaving a reader to infer the boundary.

### Offline, stated precisely — what needs a network, and what does not

The owner's instruction was that the platform "work completely offline". It does, and the
sentence is worth breaking into the three things it can mean, because they have different
answers and only one of them is enforced by a gate.

**Running it: no public network, and this is proven behaviourally.**
`npm run offline:verify` creates a Docker network with `--internal`, proves a container on
it cannot reach a public host, raises PostgreSQL and Control Core on that network alone, and
drives the controlled quality path across it. `npm run portal:egress` now covers the browser
half over the shipped bundle. Measured alongside them, and worth recording because it is the
shortest answer to the question: **the only outbound HTTP client in the whole of the
non-test service code is `KeycloakIdentityDirectory`**, and it addresses the identity
provider inside the deployment. `grep -rn "new HttpClient\|AddHttpClient" services/`
returns one production registration and one production request builder; every other match is
a test using an in-process test server. `CINERION_OIDC_AUTHORITY` and
`CINERION_OIDC_METADATA_ADDRESS` default to **empty** in the controlled compose model, so no
public identity host is baked into the deployment either.

**Building it: needs a registry and a package mirror, and that is not a defect.**
`infrastructure/compose.yaml` builds from `postgres:18.4-alpine3.24`,
`nginx:1.29.4-alpine3.23`, the Keycloak image and
`mcr.microsoft.com/dotnet/sdk:10.0.400-noble`, and the portal build resolves npm packages.
A first build on an air-gapped machine needs those mirrored locally — an ordinary deployment
requirement, and what `CH1-VVT-TC-0126`'s SBOM and dependency disposition exist to make
possible. CH1-OPS-FR-0001 is about **principal workflows**, not about compilation, and the
offline gate is deliberately written to raise the services **from the controlled images**
rather than to build them. Item 56 records that this network truncates large registry pulls
on some days, which is a practical reason to mirror rather than a requirement to.

**Time: the controller is honestly unsynchronised, and that is not an internet dependency.**
Every prepared command is refused as `CONTROLLER_TIME_NOT_TRUSTED` until a control-zone
time server's address is written into the node's NVS under `ch1_cfg/sntp_server`. That
server belongs **inside** the control zone. Nothing reaches for a public NTP pool.

**What is not established, and cannot be from this workstation.** No harness drives a real
browser on a network proven to have no route out. Both new gates print that sentence
themselves. Closing it needs either browser automation inside the internal network, or a
person at the keyboard on an air-gapped machine — and a browser run needs a person at the
keyboard regardless (item 11).

### The previous session: the controlled sequence completed, and the rail nobody had ever rendered

Four things the owner asked for, and the thread running through all of them is that an act
is something a ROLE performs on an OBJECT. The portal could express none of those three
clearly, and each was wrong in its own way.

**The workspace rail clipped its own navigation, and nothing in CI had ever rendered it.**
The rail was one unbounded column — twenty-two destinations, a workspace block, a safety
card and an identity block — inside a row whose cross-size is the viewport, so React
Native's default `overflow: hidden` cut it off at the bottom edge with no scrollbar.
"Calibration register" was unreachable. It is now three regions and which of them scrolls
is a decision: the workspace block is pinned at the top because a rail that no longer names
its project is how an operator acts on the wrong cell, the AUTHORITY BOUNDARY card is pinned
at the bottom because a safety statement that can be scrolled out of reach is not a
statement, and only the list between them scrolls.

**Why nothing caught it is the more useful half.** `react-native-web`'s `Dimensions` reads
the document element's client box; jsdom performs no layout and answers 0, so every one of
the 45 render scenarios measured a zero-width window and took `AppShell`'s COMPACT branch.
The rail an operator at a workstation actually uses had never been rendered by anything in
CI. `declareViewport` fixes that in three lines, scenarios may now declare their own
viewport, and the default is a workstation window.

**The session said AUTHENTICATED beside HTTP_401, then ended for no stated reason.** The
realm declared no `accessTokenLifespan`, so Keycloak's five-minute default applied; the
portal held no refresh token, had no reaction to a 401, and derived its whole session state
from a token string being non-empty. The token is now renewed forty-five seconds before it
expires so nothing in flight is refused; a refusal from Control Core triggers ONE renewal as
a backstop, because a 401 is the trigger to try and never a verdict; and renewal is
single-flight, because every screen polls at 1 Hz and Keycloak rotates the refresh token on
use, so a second concurrent attempt would present a spent token and end a healthy session.
A renewal that genuinely fails produces a new state — `ended` — which is said differently
from signed-out: "Your session ended", the provider's own reason verbatim, and the statement
that nothing in progress reached Control Core.

**The fix introduced a defect and the harness caught it.** The code exchange was guarded by
"there is no access token yet", which was true exactly once until a session could END — so
the first failed renewal re-presented an authorisation code the provider had already spent.
The code is redeemed once per page load now, and the harness stub refuses a second
redemption as a real provider does. Without that stub change the scenario passed while the
portal silently resurrected a dead session.

**The first attack on the renewal refused NOTHING**, and that is defect 75 again.
`assignedOperator()`'s default `exp` is a fixed instant in the past, so every scenario
renewed from the SCHEDULED path and the 401 backstop could be deleted with all five checks
still green. The scenarios now carry a token the portal believes is healthy, which makes the
refusal the only possible trigger. Five attacks, each refused by name.

**A realm nobody had compared with its file.** Keycloak imports a realm only when it does
not already exist, so a lab that has ever been started ignores every later edit to
`cinerion-realm.json` — and `npm run policy` reconciles against the FILE. `ProjectOwner` was
declared, absent from the running realm, and added by hand when somebody happened to look.
`npm run realm:drift` compares the two: 103 comparisons over settings, roles, clients,
redirect URIs, web origins, identities and role mappings, **in both directions**, because a
redirect URI the running realm accepts and the file does not declare is somewhere an
authorisation code can be sent that nobody reviewed. It needs a live provider, so it is not
in `verify.sh` — defect 51's shape — and runs as a step of `npm run lab:up`.

`accessTokenLifespan`, `ssoSessionIdleTimeout` and `ssoSessionMaxLifespan` are now declared
at EXACTLY Keycloak's defaults, confirmed against the running realm by that same gate, which
is how the values were established rather than assumed. Behaviour is unchanged; the decision
is now reviewable. No controlled document states a session lifetime.

**Authority was decided eight times over, in eight screens.** `roles.includes('Engineer')`
written wherever a control happened to be, so the same authority was spelled differently in
different places, one could widen quietly, and an identity holding none of a screen's roles
was shown a blank panel — the worst answer available, because the operator cannot tell
whether the act exists, whether the screen is broken, or whose job it is.
`apps/operator-portal/src/api/capabilities.ts` is the single register: 31 controlled acts,
each quoting its authority phrase from `api_endpoints.json` VERBATIM and mapped only to
roles `controlled-authorities.json` grants it. `npm run capabilities` refuses a widening, a
paraphrase, an uncatalogued operation, an unexplained narrowing, an authority silently
dropped by declaring no roles, an undeclared screen and a duplicate. 12 attacks, 0 holes —
one of them proving the gate ignores a widening written in a COMMENT, which is item 63 one
level out.

**The gate refused the register's own first draft, correctly.** Three authority phrases name
BOTH a relationship and a role — "Session owner or Identity Administrator" — and modelling
them as pure relationships would have offered the act to every signed-in identity and
dropped the role half in silence.

**The act the owner asked for by name.** `PUT /api/v1/users/{userId}/roles` was implemented,
tested and audited in Control Core and reachable only with a command-line HTTP client,
because the portal's API client had no PUT at all. It is on CH1-UX-SCR-0013 now: the whole
role set replaced at once, the segregation rules shown as the SERVER states them rather than
restated, no chip greyed out to pre-judge a rule the domain evaluates against both
identities, and the step-up phishing-resistant because conflict 10 takes the stronger of two
controlled requirements. Device enrolment joined it on CH1-UX-SCR-0018 — revocation was
offered and enrolment was not, so the one role that may withdraw a device's trust could not
grant it.

**The controlled sequence now completes end to end, and nothing physical happens.**
`ValidateController` requires an mTLS-authenticated device identity holding DeviceController,
and the only way to present one was the development identity handler, which is mutually
exclusive with OIDC. So in any lab serving the portal over OIDC a prepared command sat at
`AwaitingCredential` for ever and the sequence could not be watched. Control Core gains a
device listener on its own port: a client certificate is resolved to an ENROLLED device
record and the project, cell and role come from that record, never from a header.
`simulators/cell-confirmer` is the stand-in controller — a separate service with a separate
identity, because the portal has no route to `/credential-proofs` or `/local-commits` and
`check-repository-policy.mjs` still refuses either string anywhere in its tree.

**A real asymmetry surfaced on the way.** The button edge has always been markable as
`SimulatorInjection`, refused outside Simulation and audited as MARKED_SIMULATOR_EDGE. The
credential proof had no such member, so a stand-in had to name a real authenticator class
and the audit recorded CRYPTOGRAPHIC_LOCAL_PRESENCE_VERIFIED — asserting that a person had
presented a credential at a cell when nobody had. `AuthenticatorClass.SimulatedPresence` is
refused outside Simulation by the same guard in the same place and audits as
MARKED_SIMULATED_PRESENCE_NO_PERSON_AND_NO_CREDENTIAL_PRESENT.

`npm run commit:loop`: **18 checks, 0 failed.** Prepare → credential proof → button edge →
interlock re-sample → LOCAL COMMIT → Committed, with the audit chain read back and asserted
to mark BOTH halves and never to claim a cryptographic presence.

**Its attack section was worthless in its first form and looked fine**, which is the
dangerous combination. curl here is built against schannel, schannel cannot import a PEM
client certificate, and it closes the connection before presenting anything — so "a
certificate from an untrusted authority is refused" passed while the server had never seen
a certificate. The certificates are PKCS#12 now and a POSITIVE CONTROL runs first: the
enrolled certificate must reach an authorised operation, or the gate says every refusal
below establishes nothing.

**Two defects the gate found in this session's own work.** The device listener was
configured inside the gRPC edge's own `if`, so a deployment with device identities and no
gRPC edge bound no device port while health cheerfully reported it enabled. And the portal
Dockerfile gained a build argument the CONTROLLED compose model did not pass, which
`npm run policy` refused — correctly, because Metro inlines `EXPO_PUBLIC_*` at build time
and an unpassed argument produces an image carrying the Dockerfile default for its whole
life. Defect 78's exact shape. The model passes it EMPTY now: no simulator is raised, no
control renders, and the decision is stated in the model rather than hidden in a default.

**Every identifier the data already carried was inert text.** An alarm named its cell, a
cell its order and part, a part its nonconformities, every object its thread — and following
one meant copying a UUID into another screen's search box. `ObjectLink` makes them navigable
while still SHOWING the identifier, because that is what appears in the audit record, in the
controller's log and in a refusal's correlation id. Following one asserts nothing: the
destination performs its own controlled read, and 404 is still the same answer for "does not
exist" and "may not see". `GET /parts/{partId}/genealogy` now carries its derived
`contextThreadId`, so a part's discussion is reachable from the part.

**The code was NARROWER than a controlled authority, and a machine could not report a
result.** `api_endpoints.json` gives the measurement operation to "Bound instrument adapter
or Test Engineer"; every measurement went through an authorisation whose first line refuses
any actor that is not Human. Conflict 35, resolved in favour of the controlled document with
one control the document implies and the code had never needed: an adapter may append only
readings its OWN instrument produced, because a device naming another instrument would
attribute a result to equipment that did not make it. Exactly one thing was widened and each
of the rest has its own test.

**Two more defects, and only a RUNNING lab could have found either.** The pipeline was
green, 513 tests passed, `npm run commit:loop` passed with 18 checks, and device
authentication against PostgreSQL was completely broken.

`DeviceCertificateAuthenticationHandler` resolved the enrolled device in a synchronous DI
scope. `CinerionDataSource` implements `IAsyncDisposable` and NOT `IDisposable`, so
disposing that scope threw `InvalidOperationException` — **after** the authentication
decision had been made. Every device request in the containerised lab answered 500 having
authenticated perfectly. Nothing caught it because nothing could: the commit-loop gate runs
on the in-memory store, which has no data source to dispose, and it runs there for a
reason — on PostgreSQL a cell's interlocks are not persisted, the controller reports
OFFLINE, and no command can be prepared at all. `await using var scope =
services.CreateAsyncScope()`.

And `simulators/cell-confirmer/Dockerfile` named `mcr.microsoft.com/dotnet/aspnet:10.0.4-alpine3.22`,
which does not exist. Defect 34's class exactly: an image tag that cannot work, invisible
to every gate until something actually built it, and found by `npm run lab:up` refusing with
"not found".

**`npm run lab:check` is the gate that would have caught the first**, and the check that
matters is the SHAPE OF A REFUSAL. It asks the stand-in controller to confirm a command
that does not exist and requires Control Core to answer 404 — because a 404 proves the
client certificate was accepted, the enrolled record was resolved under row-level security
and the command register was read, while a 500 proves the request never got that far. It is
read-only: it prepares nothing and confirms nothing. Attacked by restoring the synchronous
scope, and it refused by name.

**`npm run lab:up` now builds.** It did not, and that is item 42 with teeth: every
`EXPO_PUBLIC_*` value is inlined by Metro at BUILD time and derived into the
Content-Security-Policy in the same build, so a lab that reuses an existing image can never
pick up a configuration change. Observed exactly that way — the lab came up healthy, the
stand-in was enrolled and answering, and the portal's `connect-src` named two origins out of
three because the image predated the change.

**And one request could not be met, which is reported rather than worked around.** There is
no controlled operation that creates a physical part (conflict 36). In this platform a part
is created by releasing a work order against a released revision, which is CH1-MFG-FR-0002's
shape and which the portal already offers. A screen offering an operator a serial-number
form would be inventing an operation the catalogue does not contain.


### This session: the controlled diagram was a transition table all along

The single most useful thing that happened this session was reading a file that had been
sitting in the frozen baseline the whole time.

Conflict 30 and defect 66 said that `Complete` had no transition back to `Idle`, that a
controller therefore accepted one procedure per boot, and that the exit "cannot be read
from the controlled sources with confidence" because CH1-AUT-FDS-0001 refers the
transitions to `assets/cell-state-machine.png` — an image. The baseline carries
`assets/cell-state-machine.svg` **beside** that PNG, and an SVG is a transition table with
coordinates: eight state boxes, ten paths whose endpoints land exactly on a box edge, and a
label after each one. The exit is labelled **"acknowledge completion / new order"**. It had
been readable since the baseline was frozen.

`scripts/check-cell-state-map.mjs` (`npm run cell:map`) parses that geometry and reconciles
it against `firmware/statemap/cell-state-machine-r01.json`, which binds each implementation
to the diagram. It refuses an endpoint that resolves to no box or to two — a nearest match
would be a guess — a controlled transition an implementation does not perform between two
states it covers, a routine the map names that the source does not contain, a covered state
the body never assigns, a state added to an implementation with no stated reason, and a
transition the map declares that the diagram does not contain. That last direction is the
one that matters: it is how an invented transition into a safety-relevant state machine
would arrive. **18 attacks, 0 holes**, including defect 66 restored from both ends — deleted
from the firmware, and deleted from the map.

Reading the diagram closed four gaps, and only one of them had been reported:

- MCU `Complete --acknowledge completion / new order--> Idle`, which is defect 66. The
  acknowledgement is bound to the command it acknowledges and does **not** reset the
  sequence high-water mark, so the procedure that has just run cannot be offered again.
- MCU `Recovery`, which CH1-AUT-FDS-0001 names in prose and the diagram places between
  `FaultLatched` and `Idle`. Defect 71.
- PLC `Executing --procedure passes--> Complete`. State 40 was documented on the guard's
  `State` output and assigned nowhere. Defect 70.
- PLC `Executing --critical fault--> FaultLatched`, which was hiding defect 69 — a latched
  procedure fault leaving `ExecutePermit` standing with no event able to clear it.

`simulators/cell-controller` now runs a **second procedure on one boot** and the whole
controlled recovery path, and asserts both, in place of the paragraph it used to print
explaining that it could not.

**The lesson is not about SVG.** It is that "the controlled source does not say" is a claim
worth re-testing before it becomes a conflict, because a conflict is where work stops. Four
defects sat behind one unexamined sentence for two sessions.

### Conflict 13 needed a field, not an operation

Conflict 13 was recorded as the largest functional blocker: "the catalogue has no passkey
REGISTRATION-challenge operation, so phishing-resistant step-up is unreachable for any
browser-enrolled identity". The catalogue needs no such operation, and the state the
enrolment path was actually in is worse than the conflict described.

CH1-CYB-IAM-0001 makes enrolment a controlled **ceremony** — "Enrolment verifies the person,
assigns roles separately, records credential serial/public key and issues recovery material
through a controlled ceremony" — and `POST /api/v1/credentials` is that ceremony, with
"**Proof of possession**, unique identity and lifecycle record" as its declared control. It
implemented the last two: the public key arrived as a request field and was stored. A
Cybersecurity Administrator could enrol any key at all, against any subject, and the audit
event recorded `PROOF_OF_POSSESSION_RECORDED` about it. Defect 72.

What was missing was the nonce to prove possession against — and that is the "**Purpose-bound
challenge**, short TTL and audit" that `POST /api/v1/auth/step-up` was already declared to
issue and did not. The grant was an identifier and nothing an authenticator could sign over.
It now carries 32 bytes from the cryptographic generator (not derived from the grant
identifier, which is a value the platform hands out), and the operation returns it with the
relying party and the two algorithms the verifier accepts.

`WebAuthnVerifier.VerifyRegistration` implements the Level 2 registration procedure and the
key comes out of the attestation rather than out of the request. A small CBOR cursor walks
the attestation object rather than adding a package — the same reasoning as the COSE reader
it sits beside — and refuses indefinite lengths, deep nesting and any length claiming more
bytes than the buffer carries. **Smart-card enrolment now refuses**: there is no reader here
and no challenge-response exchange, the credential class exists for local presence at a cell,
and serving it was the fake success rather than refusing it.

### Authorities are prose in the documents and constants in the code, and nothing reconciled them

access.json and api_endpoints.json name authorities as prose — "Engineer or Maintainer",
"Self or Identity Administrator", "Quality or Project role", "IR plus Document Control
review" — and the code enforces role constants. Nothing compared the two, so a mapping
decision could be made silently inside an endpoint and never recorded. Conflicts 9 and 23
are exactly that: two authorities a controlled document names, with no role behind them.

`traceability/controlled-authorities.json` records one decision for each of the **49**
distinct authority phrases the two documents contain, and `npm run policy` refuses a
document naming an authority the register does not account for, a register entry naming a
phrase no document contains, an entry mapping to nothing, and a mapped role `CinerionRoles`
does not define. 5 attacks, 0 holes.

- **Conflict 23 is resolved by implementing what a controlled document already declares.**
  `stakeholders.json` contains "IR - Project Owner … P03 scope, owner authorisation,
  confidential/publication boundary and resources … A: P03 owner decisions and
  authorisation". `ProjectOwner` now exists in `CinerionRoles` and the realm, and the
  publication pipeline exercises the owner's capacity through it. The Project Manager is
  **not** retained as a second route: an authority still reachable through the mapping it
  replaced is an authority the resolution did not move.
- **Conflict 9 is resolved in favour of the two documents that agree.** "Identity
  Administrator" appears only in api_endpoints.json's authority column; stakeholders.json
  does not contain it and access.json gives "Manage users" to the System Administrator. The
  existing mapping was already right; what was missing was the record of it.

### Time quality, and two clocks that were being reported as one

Defect 59 is fixed. `ControlCoreIngressClient.NewEnvelope` set `TimeQuality.Qualified` on
every message unconditionally, and the MQTT adapter decoded a device's own `timeQuality` and
dropped it. Underneath that was a second half nobody had recorded:
`ch1.telemetry_samples.time_quality` was written from **Control Core's own clock**, so it
described `received_at` and stood beside `sampled_at` as though it described that. A
controller honestly reporting `Unsynchronised` was stored indistinguishably from a
disciplined one, and no reader could have told.

CH1-COM-ICD-0001 says why that matters — "Clock offset and time quality are observable so
audit and TOTP decisions are not silently made on invalid time" — and prescribes the remedy
in the same document: "Contracts use additive evolution within a supported major version."
So the publication gained a field rather than the gateway taking the worse of two figures,
which would have lost both. The gateway declares its own clock from
`CINERION_EDGE_GATEWAY_TIME_QUALITY` and defaults to `Unknown`; nothing here disciplines it
against a traceable source, and nothing maps to `Trusted` at all.

**Measured on a running system rather than argued.** `scripts/check-grpc-edge.sh` refuses a
stored sample claiming a `Qualified` source clock and refuses a run where nothing carries a
declaration; green at 17 samples carrying one and 0 claiming Qualified, then attacked by
restoring the defect, which failed by name at *"16 stored sample(s) claim a Qualified source
clock that nothing in this deployment established"*.

### A printed serial number now reaches the part it names

Conflict 15: screens.json declares CH1-UX-SCR-0007 as "QR/RFID identity and complete
history", and the only operation turning a scanned code into a part needs a signed session
from an enrolled Field Companion device — correctly, since CH1-IAM-FR-0008 separates human,
service and device accounts. An Engineer holding a printed serial number had no controlled
route to the genealogy at all.

`GET /api/v1/parts?serialNumber=` resolves the identity and mints nothing. It is recorded in
`traceability/owner-approved-operations.json`, whose stated constraint it meets: every entry
is a READ. Four properties are asserted rather than described — it discloses nothing the
genealogy would not (same three roles, so a Local Confirmer gets the identical 404 from
both, preserving conflict 17's position rather than quietly widening it); the serial space
cannot be enumerated (exact match, and a prefix of a real serial answers 404); it is not
evidence and says so on the response and on the screen; and it carries no history at all,
checked over the raw body.

**Conflict 16 is reported, not resolved.** Its second branch — "the revoke response should
carry enough of the record for the act to be reviewable afterwards" — turns out to be
already satisfied: the response carries the thumbprint, trust state, last-seen time and
capability manifest. The first branch would widen a read authority that both controlled
documents agree on, which is the owner's to move.

### The obligations with no controlled case, recorded rather than left in the margin

`data/tests.json` holds 87 cases and none of them is about telemetry retention, record
retention, the I/O register, demonstration data, the internal gateway interface or the cell
state machine's shape. Their gates announce no case, which is right — binding real evidence
to an unrelated case is the overstatement the verification map exists to prevent — and the
consequence was that the evidence appeared in no traceability artefact at all.

`traceability/executable-obligations.json` records six of them with the controlled
requirement each carries evidence for, what the gate refuses, and **what it does not
establish**. `npm run verification` refuses an entry that names a CH1-VVT-TC identifier at
all, which is the one mutation that would merge the two registers; an entry naming a gate
`package.json` does not define; an entry naming a requirement or document that does not
exist; and an entry that states only its own strength, because a record of evidence with no
limits written on it is an advertisement.

That is the owner decision conflicts 18, 20, 26 and 28 each offered as a second branch,
taken and recorded: the case list is frozen in this working copy and cannot gain a case
here, so the obligation is carried as a design constraint with its evidence named. Adopting
any of them later is a move from that file to the verification map rather than a
rediscovery.

### The demonstration dataset, and the cell RUN rather than tested

Two requests that turned out to be the same request. You cannot tell a screen that works and
has nothing to show from a screen that is broken, and you cannot tell firmware that works
from firmware nobody has ever run. Both were true here, and closing them found five defects.

#### Every declared screen has something behind it

`PrototypeSeed` establishes one project, one site, one cell, one part — the minimum for a
coherent service, and it left most of the 22 declared screens showing their empty state.
`DemonstrationSeed` populates the rest, and `npm run demo:data` proves it against a real
service on PostgreSQL rather than at the store:

| Screen | Behind it |
|---|---|
| CH1-UX-SCR-0005 control room | 3 alarms in three distinguishable states, 121 telemetry samples on all four controlled channels, one past its limit |
| CH1-UX-SCR-0007 genealogy | a failure, an authorised rework and a passing retest, with the superseded failure still readable |
| CH1-UX-SCR-0011 NCR workflow | one open nonconformity and one closed with its full disposition |
| CH1-UX-SCR-0014 audit chain | 10 events, appended through the real chain so the explorer's verification holds |
| CH1-UX-SCR-0015 scan mode | a resolved scan from an enrolled Field Companion |
| CH1-UX-SCR-0017 capacity | a live reservation against the coating station |
| CH1-UX-SCR-0020 R&D | an experiment, a run with provenance, and a promotion request |

It is **off unless asked for**, refused outright in the Production profile, and every record
says what it is: every reading `Simulated` and never `Live`, **no command in an executing or
committed state**, credentials with a public key and nothing that could authenticate. The
negative assertions are the ones that matter — a demonstration dataset is the easiest place
in a controlled system to accidentally manufacture evidence.

#### The cell, run

`simulators/cell-controller` runs the cell from the SAME translation units the board would
compile. Only the pin reads are synthetic, because a simulator that reimplements the logic is
testing itself. It **asserts** rather than prints — ten checks, inside `verify.sh` — and
twelve seconds of it found three things no test had:

**Defect 64: the firmware could not send anything at all.** Buffers of 320 and 384 bytes
against messages that encode to 355, 365 and 438. Every message refused; the encoder fails
safe rather than truncating, so the device would simply have gone **silent**. Nothing caught
it because every host test encodes into a buffer of its own choosing — which proves the
encoder works and says nothing about whether the caller gave it room. Fixed with a declared
`maximum_envelope_bytes` and a test asserting it against the widest message of every type.
The simulator made the same 320-byte mistake in its own code, which is the argument for a
declared bound over a careful author.

**Defect 65: a controller that booted with any permissive absent was stuck forever.**
`Initialising` has no exit but `initialise()`, called once at boot. The ordinary state of a
cell before an operator arrives is the key off and the guard open.

**Defect 66, reported not fixed: `Complete` has no exit either**, so the controller accepts
one procedure per boot. Conflict 30 — adding a transition to a safety-relevant state machine
is the owner's decision.

#### Defect 67, which was mine

The demonstration seed's first honest run against PostgreSQL died on
`23502: null value in column "retain_until"`. Migration `0014` — written earlier in this same
session — had added that column `NOT NULL`, and the PostgreSQL writer for the table never set
it. Every message-acknowledgement write had been failing since, and **478 tests, a 31-check
gate, an 8-attack suite and a green strict pipeline all passed over it**, because nothing
exercises that one method against a real database.

Three attempts to see it clearly failed first, each for its own reason, and all three are now
operational items 40–44: the seed's idempotency guard made a crash loop look like a completed
run; two diagnoses were made against a stale image because `compose up` without `--build`
reuses whatever exists; and Compose passes only the variables a service declares, so the gate
needed its own overlay. The change that finally made it a one-line answer was refusing to let
optional data stop a controlled service from starting — the host came up, printed
`scan_events_device_id_fkey`, and the last empty screen had a cause.

---

### The Arduino I/O node, and a report-only link that was report-only by convention

`firmware/arduino-io/` held a frame codec and **nothing that used it**. The Arduino node is
the second controller in the controlled architecture — CH1-EMB-FDS-0001 restricts it to a
"secondary, replaceable I/O node with no independent authority to start a procedure" and
`io.json` gives it CH1-IO-SPI-0001, the part RFID reader — and it had no code at all.

#### Defect 61: the node bus accepted any frame type, including one nobody had defined yet

`validate_frame` checked the preamble, the version, the declared length, the sequence and the
CRC. It **never read the type byte.** `FrameHeader::type` existed in the struct and nothing
looked at it, so all 256 types were accepted — while the ESP32 entry point's own comment said
*"a valid frame reports local input state and can never be a command"* and the codec's header
said the same. The property was true only because nobody had defined a command yet.

That claim carries real weight: CH1-EMB-FDS-0001 gives the node no authority to start a
procedure, CH1-SYS-CON-0001 keeps commands out of anything that stores or forwards, and
CH1-VVT-TC-0014 is the case for remote bypass being refused. All three rested on a convention.

The type is now a **closed set of three report kinds** — `InputState`, `PartIdentity`,
`NodeStatus` — refused on both sides of the wire. The receiver rejects any other type; the
producer will not build one, so a node cannot compose a command even by mistake. Adding a
fourth is a reviewed change to a controlled interface, which is the point of a closed set
rather than a convention.

The host test sweeps **all 253 undefined types**, each carrying a valid preamble, length,
sequence and CRC, and requires every one to be refused — and separately requires all three
declared kinds to round-trip, so the refusal is a closed set and not a closed door.
**Attacked** by removing the type check: the suite fails by name on exactly that sweep.

`on_serial_frame` now dispatches on the type, and every branch consumes a report. There is no
branch that could start, arm, confirm or advance anything.

CH1-VVT-TC-0014 gains a `firmware-frame` binding: the physical-zone half of "no remote
local-button bypass" is a link inside the cell that carries no path capable of starting a
procedure, and that is now executed rather than asserted.

#### The node itself

`NodeApplication` composes the reports and has no method that composes anything else. Two
properties are worth stating:

- **A part identifier is never truncated.** A shortened UID is a *valid identifier for a
  different part*, so a node that trimmed one would attribute work, measurements and genealogy
  to the wrong component — and every record downstream would be internally consistent and
  wrong. CH1-MFG-FR-0002 makes the part identity permanent, and there is no recovering from
  having recorded the wrong one. An identifier the link cannot carry is refused, counted, and
  reported in the status frame, so a misbehaving reader is visible rather than quiet.
- **A refused frame consumes no sequence.** A number spent on a frame that never went out
  would leave a hole the receiver reads as a report lost in transit, which is a different
  fault from the one that actually happened.

19 host checks. The Arduino sketch that reads the pins is not written: it is board-specific,
belongs with the frozen pin map, and there is no Arduino toolchain here to compile it.

---

### Retention beyond telemetry, and SNTP

**Two of the ten finite retentions in `entities.json` are now executable.** Only three are
computable from data CH1 holds at all: `TelemetrySample` was implemented in `0010`/`0011`,
and `MessageAcknowledgement` and `RoleAssignment` are both a flat "7 years". Migration `0014`
is their disposal path. Conflict 25 is unchanged for the other seven — their retention is
relative to a lifecycle end the schema does not record and no controlled operation sets, so a
disposal process would have no date to compute from, and inventing one would be worse than
leaving it to the owner.

#### Immutable *within* the retention, which is one rule rather than two

`0012` put a `BEFORE UPDATE OR DELETE` trigger on `ch1.role_assignments` refusing **every**
deletion. Correct for immutability — and it also meant the declared seven years could never
end. A retention period that cannot be executed is a policy statement, not an obligation.

The trigger is now retention-aware rather than removed. `UPDATE` is refused for everyone,
always. `DELETE` is refused for everyone, always, **except** the retention role acting on a
row whose own `retain_until` has passed. Both halves are checked in the database, so neither
the application nor a mistake in a procedure can widen them.

`ch1.message_acknowledgements` had **no immutability trigger at all** and `0004` granted the
application role all four privileges, so a delivery receipt — a Controlled record whose whole
purpose is to evidence that a named recipient saw a message — could be silently rewritten or
deleted. Same shape as conflict 19: an authority nobody had asked for, doing nothing except
making an unattributable change possible. It now carries `retain_until` with the same `CHECK`
tying it to the register, and the application role's `UPDATE` and `DELETE` are revoked.

#### The gate found its own blind spot

`npm run retention:records` is SQL end to end — an application that happens not to issue a
`DELETE` proves nothing, and CH1-DBA-DD-0001 asks for the difference between "no code does
that" and "the database will not permit it". 31 checks.

Its first run failed **eight** of them, and only one was a defect in the product side:

- a fixture insert violated a `NOT NULL` and was swallowed, so `[3/6]` reported *"the
  retention role cannot dispose of a role assignment whose seven years have not ended"* as a
  **PASS against an empty register**, where the `DELETE` had matched nothing. Both registers
  are now counted before anything depends on them. A fixture that fails silently is worse
  than no fixture;
- three checks expected the trigger's refusal and met a **privilege** refusal instead,
  because the retention role holds no `UPDATE`. That is the stronger outcome and the
  expectation was wrong — but it also means the trigger's `UPDATE` branch and its role branch
  were claims nothing exercised. The gate now widens the grant for exactly one check each,
  shows the trigger refuses anyway, takes the grant back, and **asserts it was taken back**:
  a gate that widens a grant and fails to narrow it again has left the deployment worse than
  it found it.

**Attacked** — `npm run retention:attack`, 8 attacks, 0 holes, each mutating the controlled
migration and requiring a refusal by name. The first is the interesting one: removing the
procedure's `retain_until` predicate deletes **nothing** rather than too much, because the
trigger refuses the unexpired row and aborts the transaction. The procedure's predicate is a
convenience; the trigger is the control. Recorded rather than tidied away, and a second
attack removes both halves so the predicate is tested on its own.

Documented in [docs/operations/RECORD_RETENTION.md](../operations/RECORD_RETENTION.md).

#### SNTP, written and honestly unverified

`firmware/esp32/main/time_sync.cpp` disciplines the clock from a server provisioned with the
device identity, and `app_main` re-attempts every 15 minutes — well inside the hour that
separates Synchronised from holdover, so an ordinary run never drifts out of the command path
and a controller that loses its time server degrades through holdover rather than falling off
a cliff. A server answering an implausible epoch is refused rather than believed.

**There is deliberately no default server and no public one.** CH1-VVT-TC-0080 requires the
core demonstration to complete with no public internet, and a cell whose clock depends on the
public internet is a cell whose command path closes when the site's uplink does. With none
provisioned the controller stays Unsynchronised, refuses every prepared command as
`CONTROLLER_TIME_NOT_TRUSTED`, and says so on every message. That is correct behaviour, not
degraded behaviour.

**It is UNVERIFIED and is not in the host build.** `esp_netif_sntp.h` is macro-heavy, and a
hand-written stub of it would let that file compile against something the real header does
not agree with — coverage that looks like coverage. It is in the ESP-IDF component and
nowhere else, so it has never been compiled and never been run here. What *is* tested is
everything it feeds: the whole Unsynchronised/Synchronised/holdover/stale decision and the
two clocks of different strictness live in `cinerion::io::TimeSource`, exercised by advancing
a clock that never runs.

---

### This session: the conditioned I/O layer, and three defects that only a compiler could find

`data/io.json` defines 24 controlled signals. Before this session the firmware named none
of them. There was no pin map, no conditioning, and nothing holding the controlled table and
the code in step — so every signal's fail state, electrical type and diagnostic action lived
in a document that no build had ever read.

#### The safety boundary was widened, not worked around

`scripts/check-repository-policy.mjs` refused `gpio_set_level`, `gpio_config` or
`ledc_set_duty` in `firmware/esp32/main/app_main.cpp`. That is bound to CH1-SAF-FR-0001 and
CH1-VVT-TC-0070 and it is not an oversight.

It was also **checking one file**, which was right while one file was all there was and
became wrong the moment a conditioned I/O layer existed: a driver added in a second file
under `firmware/` would have satisfied a check named after the entry point while breaking the
position the check exists to hold. The boundary now covers **every firmware source**, plus
the pin map's `energisable` field, so neither a new file nor a JSON edit can grant
energisation that independent review has not.

**Attacked** — `npm run safety:attack`, 5 attacks, 0 holes, each refused by name:

| Attack | Refused as |
|---|---|
| an actuator GPIO driven from the entry point | *entry point configures or energises physical outputs* |
| the same act in a **new file below it** | *energises a physical output outside HIL review* |
| a PWM duty written from inside the conditioned I/O layer | *energises a physical output outside HIL review* |
| the stepper driven through the motor-control peripheral | *energises a physical output outside HIL review* |
| energisation granted by editing the pin map's JSON | *energisable while the wiring is not frozen* |

The second row is the one that matters: it is the move the widening exists to stop, and the
old check could not have seen it.

Outputs are **planned, not driven**. `OutputPlanner` computes what the six controlled outputs
should be from the cell condition and the diagnostics; nothing in the tree applies a plan to
a pin. `firmware/pinmap/esp32s3-r01.json` records that neither actuator signal is energisable
at hardware revision R01, and states why: CH1-EMB-FDS-0001's P03 verification boundary defers
independent review until before hazardous energisation.

#### Defect 57: `firmware/esp32` could never have linked

Nothing in the pipeline had ever built the entry point — ESP-IDF is not installed on this
workstation — so it was checked only by a grep. Four stubs in `firmware/tests/host-stubs`
now supply the ESP-IDF headers it includes, and `verify.sh` step `[9/14]` compiles it under
the same `-Wall -Wextra -Werror -pedantic` as every other host binary. It is compiled and
never linked or run: the loop does not terminate and the transport is not here.

The first compile found three things at once:

- **`publish` was declared in an anonymous namespace and never defined**, while the heartbeat
  and acknowledgement paths odr-used it. A definition is required, so the real target build
  would fail to link. It now has one, and that definition counts the message as undelivered
  and says so — it does not report a delivery it did not perform;
- **`on_command` was defined and never called.** The entire command receive path was
  unreachable;
- **`on_serial_frame` was defined and never called.** So was the entire RS-485 receive path.

Both are reachable now, through a poll that reads nothing because the transport is not
provisioned. A receive path nothing calls is a receive path nobody will notice has broken.

This is the session's clearest instance of the method: *anything that had never actually been
executed was broken*, extended one step to *anything that had never actually been compiled*.

#### Defect 58: the envelope claimed a clock the controller did not have

`ch1_envelope.cpp` wrote the literal `"Synchronised"` into the `timeQuality` field of every
message — directly under a comment saying that a controller whose clock has not been
disciplined must say so rather than claim otherwise. Meanwhile `wall_clock_milliseconds()`
returned `-1`, so the same firmware refused every prepared command as
`CONTROLLER_TIME_NOT_TRUSTED` and simultaneously told the gateway its clock was disciplined.
Both statements cannot be true and the one on the wire was the false one.

CH1-COM-ICD-0001 requires time quality to be visible precisely so audit decisions are not
silently made on invalid time, and CH1-COM-FR-0009 requires the heartbeat to report it. A
constant is not a report. Every encoder now takes the value, and `TimeSource` produces it.

The byte-for-byte vector `Cinerion.EdgeLink.Tests` pins is **unchanged** — the reference
message is the disciplined form — and a new test proves the two forms differ in exactly one
field, so the parameter cannot be decorative.

#### Defect 59, reported and not fixed: the gateway discards what the device said about its clock

`ControlCoreIngressClient.NewEnvelope` sets `TimeQuality.Qualified` unconditionally. The
gateway decodes the device's declared `timeQuality` and then throws it away, so a device
reporting an untrusted clock reaches Control Core as qualified — the same silent upgrade the
`Freshness` enum's own comment forbids for readings ("Control Core never upgrades what it was
told"). The proto carries no per-device time-quality field to put it in, so this is a
contract question rather than a one-line fix. Recorded as **conflict 27**.

#### The conditioned I/O layer

`firmware/shared/include/cinerion/conditioned_io.hpp`, host-tested with no board present,
because every type takes a sample and a clock reading and returns a decision:

- **debounce as a TIME bound**, not a sample count, so a task that ran late does not shorten
  the debounce it was supposed to apply;
- **stuck detection** — CH1-IO-DI-0004's controlled diagnostic action. A signal asserted past
  its bound asserts *nothing* until it is **seen to release**; time passing never clears it,
  because an input that is still asserted has proved nothing. A welded contact, and a
  controller that booted with a shorted button, therefore cannot present the confirmation
  edge CH1-CMD-FR-0003 requires a person to make;
- **normally closed circuits that fail to the demand rather than to silence**, and a
  `circuit_healthy()` that distinguishes a cut conductor from an operator opening a guard;
- **the analogue conditioning each channel declares**: range and rate for temperature and
  humidity, a 5-sample median for position, a 16-sample windowed RMS for vibration. Each
  reading carries unit, source sample time, quality and freshness; an implausible sample is
  substituted and **Bad**, never Good with a plausible number in it; a window that has not
  filled publishes nothing rather than a partial average; and a sample the controller could
  not time is refused outright, because a reading whose age is unknown cannot carry freshness;
- **the indicator conditions one for one from the controlled table** — the confirmation lamp
  lit in `AwaitButton` and nowhere else, green for ready or complete, amber for prepared or
  warning, red for a latched fault — and a buzzer with **no continuous setting to select**,
  because a buzzer that sounds continuously is silenced on the first day and then means
  nothing;
- **`OutputWatchdog`**, whose failure withholds the actuator enable and names the reason;
- **`TimeSource`**, with two clocks of deliberately different strictness: a report clock that
  accepts holdover, because a sample carrying a slightly drifted time and *saying so* is more
  useful than no sample, and a command clock that does not, because a command judged on a
  drifted clock is an intent with no bound on how long it was in flight.

#### CH1-VVT-TC-0073 left `hardware_gated`

It had **no binding at all**, with the note "No watchdog is implemented in a form that can be
exercised on a host". The timing is hardware; the **decision** is not, and it is executed now.
A supervised task that stops checking in is reported overdue by name, the planner withholds
the actuator enable and the stepper with it and states `WATCHDOG_UNHEALTHY`, and a watchdog
table that could not hold every task it was asked to supervise is **never healthy again** —
supervising fewer tasks than the controller believes is supervised is worse than refusing to
start. `partially_automated`, not `automated`: the host advances a clock that never runs.

#### The pin map, and the gate that came before it

`firmware/pinmap/esp32s3-r01.json` is a contract between the controlled I/O table, the wiring
and the firmware, and **each holds its own copy** — the same shape as the Modbus register map
and for the same reason: every test written against a pin map agrees with the pin map.

`npm run io:map` refuses a signal in one and not the other; a name, owner, direction, range,
fail state, diagnostic action or terminal that disagrees; conditioning that does not implement
the declared diagnostic action; a signal this controller owns with no pins and no stated
reason; two signals on one pin that is not a shared bus; a pin the module reserves for flash,
PSRAM, USB, the console or boot strapping; an output with no external pull to establish a
de-energised level while the controller's pins are high-impedance at reset; an actuator
declared energisable while the wiring is unfrozen; a wiring freeze declared with terminals
still TBD (CH1-HWE-IOL-0001 states that plainly and this refuses it); and a firmware header
naming different signals from the map.

The gate holds its **own** copy of the module's reserved-pin set, because a map that could
excuse its own violation by deleting the entry that forbids it is not a check.

**It found a real disagreement on its first run** and the disagreement was the gate's: the
rule keyed off whether a signal consumed a GPIO, and `CH1-IO-NET-0001` is the ESP32's MQTT
uplink whose radio is inside the module. Ownership is a column the controlled table already
has, so the rule keys off that instead.

**Attacked** — `npm run io:attack`, 19 attacks, 0 holes, each refused by name. Every mutation
is undone in a `finally` and the restored files are re-checked, so a suite that dies cannot
leave a deliberately broken pin map behind.

It **announces no controlled verification case**. `data/tests.json` contains none for the I/O
register — searching it for I/O, wiring, signal, terminal, pin or loop check returns nothing —
and binding this evidence to an unrelated case is the overstatement the verification map
exists to prevent. Recorded as **conflict 26**, the same shape as conflict 18 for retention.

#### Defect 56: the buffer gate asked whether the buffer was empty

The session opened by re-running `./scripts/verify.sh --strict` at `0099074`, as the handover
instructed. **It was not green.** It refused at `[11/14]`:

    gateway-buffer: could not be run (FAIL  1 record(s) are still held after the link returned)

Every other check in that harness passed, including all of section `[7/8]` — in order, none
lost, none counted twice. Run standalone it passed. Nothing in the four commits since the last
green run touches `services/edge-link` or that gate.

The gate was asking the wrong question. The buffer is **write-through**: `IngressPublisher`
enqueues every observation and a separate drain loop wakes once a second to deliver it, so a
*healthy* gateway holds a freshly written record part of the time and the instantaneous count
is legitimately nonzero. "Is the buffer empty at the moment I looked" is not the statement
CH1-NFR-REL-0001 makes.

**Measured, not assumed.** The harness now prints the residue profile every run, and the first
amended run read **empty on 16 of 20 observations, peak residue 1** — exactly the one record
the strict run had refused on.

The drain check now names the **outage backlog** by its high-water sequence at the moment the
link returned and requires every record at or below it to arrive. Relaxing that alone would
let a genuinely stalled drain pass, so the strictness moved rather than disappearing: a
healthy buffer is empty most of the time and a stalled one is never empty, so the buffer must
be **observed empty at least once** across twenty samples. On failure the gate now names what
is still held and prints the gateway's last log lines.

A contributing measurement: `buffer_sql` ran `apk add sqlite` over the network on **every**
call and took a measured 3.6–4.1 s, putting the poll period at about 5.8 s against a gateway
enqueueing every 5.0 s — a check sampling at almost the rate of the thing it watches, whose
verdict depended on package-mirror latency. One prebuilt image: 1.3 s, no network.

---

### This session: the three performance cases, and the defect under all of them

**CH1-VVT-TC-0090, 0091 and 0092 were all `not_executed` at the start of this session and
all three are measured now.** The load requirement went from 36.95 msg/s to 100.02. What
follows is what was actually wrong, because none of it was the thing the previous session
had reasoned its way to.

#### Defect 50: the connection pool ended with the request that opened it

`CinerionDataSource` was registered **per request** — correctly, because the project scope
it applies is per request — and it also constructed its own `NpgsqlDataSource` in its
constructor and disposed it at the end of the scope. `NpgsqlDataSource` **is** the pool. So
nothing was ever pooled: every request built a private pool, opened fresh physical
connections into it, and closed them again. Each one paid the full TCP, startup and
authentication cost — 13.3 ms measured on this workstation — and made PostgreSQL fork a
backend process for it. A telemetry publication takes three connections and the rig runs
256 requests in flight.

It also made defect 49's connection budget unenforceable. Capping a pool that belongs to
one request bounds nothing `max_connections` cares about: a hundred concurrent requests
were each entitled to the whole server.

The pool is now a `CinerionConnectionPool` singleton and the per-request wrapper borrows it,
disposing it only when it created it. Nothing else moved: the scope is still per request,
`set_config` is still applied on every open so a recycled connection cannot inherit a
previous request's project, and no store method changed. The lifetimes moved out of
`Program.cs` into `AddCinerionPostgresStorage` so they could be **executed** rather than
read — `PostgresStorageRegistrationTests` resolves the real graph and asks PostgreSQL which
backend served each scope, because every reuse test would still pass if the host stopped
sharing the pool.

Attacked by restoring the defect inside the registration: both gates fail by name, *"two
request scopes were served by backends 529 and 531"*.

#### The rig could not offer the load it announced

Each publisher computed its next due time as *now plus the period*, so every `Task.Delay`
overshoot — up to the 15.6 ms Windows timer tick — was lost for good. Over a 66-second run
that cost 0.4 %: **the driver offered 99.6 msg/s while announcing itself configured for
100, and the service was then failed for not carrying a load nobody had given it.** The
cadence is now absolute, and the rig reports what it OFFERED as well as what completed,
because a shortfall that cannot be attributed is not a diagnosis.

#### The measurement began on a cold process

The per-second profile of a cold run is `0, 33, 262, 99, 101, 99, 100, …`. The first full
second of a process's life carries a third of the rate while the ingestion path is compiled
and the pool opens its first backends; the next second carries the backlog; every second
after that carries the requirement — with nothing refused and nothing lost. The number being
measured there is start-up, and CH1-NFR-PER-0001 asks for a **sustained** rate. A declared
warm-up now precedes the measured window. The requirement is not lowered by a millisecond:
the warm-up's seconds are still printed, its refusals and transport failures are still
counted, and every publication it made must still be found in the database.

#### The sustained criterion changed, deliberately, and is stricter

It was the smallest number of completions inside any fixed one-second bucket, which measures
**bucket alignment**: a publication issued at 56.99 s and answered at 57.02 s counts in the
next second, so a 100 ms pause shows as one low bucket immediately followed by one high one —
`93,107` and `89,94,115` in the profiles, each dip repaid in full. It is now four checks:

1. the rig must have **offered** the required rate, or the harness has failed and says so;
2. the service must have **completed** it over the window;
3. outstanding work must never have exceeded **half a second's worth** — the real test,
   since a service that cannot carry the rate accumulates backlog without bound, and it is
   immune to where a one-second boundary falls;
4. no single second may fall below 80 %, so a gross stall still fails.

Persistence is bracketed rather than "at least": every answered publication in the database,
and nothing beyond what was still in flight when the clock stopped.

**Measured** — this workstation, other labs stopped, 60 s window on a warmed service:

| | |
|---|---|
| offered | 99.98 msg/s |
| carried | 100.02 msg/s |
| worst measured second | 99 |
| worst backlog | 2 publications |
| refused / transport failures | 0 / 0 |
| devices / live channels | 63 / 252 |
| ingress latency | p50 14.7 ms, p95 19.8 ms, p99 28.1 ms |
| persisted | 26 404 samples, none stored twice |

**Attacked** by restoring defect 50 and re-running: 47.00 msg/s, 459 transport failures, a
backlog of 715, a worst second of 11, p95 8 842 ms, and Npgsql's *"Failed to connect"* named
in the output. Five checks failed by name.

#### CH1-VVT-TC-0091: dashboard freshness, measured under the load

CH1-NFR-PER-0002 wants dashboard freshness below 1.5 s at p95. It had no harness at all.
It is measured now, and measured **under** the baseline load, because a freshness figure
taken on an idle system answers a question nobody asked. While 63 devices publish 100 msg/s,
the operational read is polled once a second — the cadence the portal's own `useObserved`
uses — from inside the control zone, in ONE container rather than one per poll, because
sixty container starts during a load measurement would be sixty perturbations of the thing
being measured.

Each observation is the age of the newest reading at the moment the read was served, from
Control Core's own `asOf` and `newestSampleAt` so no clock skew between containers enters
it, **plus** the round trip curl measured. That sum is the honest total: how old the data on
the screen is by the time the screen has it.

**p95 77.7 ms against a required 1500 ms**, over 58 observations, worst 107 ms, p50 38 ms.

**The window is the driver's own**, published as `LOAD WINDOW-OPENED`/`LOAD WINDOW-CLOSED`,
and getting there took two wrong answers that are both worth remembering:

- Counting polls put the **read** path's cold start inside the window. It has the same shape
  as the write path's — a first dashboard read of 7.9 s falling to 22 ms by the tenth — and
  the poller starts before the driver's container does, so poll numbers align to nothing.
- Anchoring on the first reading then put the seconds **after** the load stopped inside it,
  where nothing is writing and the newest sample simply ages — 0.9 s, 1.9 s, 3.0 s off one
  unchanging row — which made the figure three times the truth.

Both excluded profiles are printed with the result, so the exclusion can be judged rather
than taken on trust. Attacked by pointing the measurement at the post-load tail: p95
3 664 ms, refused.

#### CH1-VVT-TC-0092: the platform half, and only the platform half

CH1-NFR-PER-0003 allocates prepared-command acknowledgement to CommandGuard/EdgeLink. The
map said it "needs the hardware". Half of that was true: a real S7-1200 G2's scan cycle is
part of the number and a stand-in has none. The platform half needs no hardware, and is the
half CH1 owns.

**p95 47.6 ms against a required 750**, p50 2.2 ms, over 20 preparations against the live
OPC UA controller stand-in over a real SignAndEncrypt session. 47.6 of 750 leaves the CPU
702.

**Accepted preparations, not refused ones**, and the accepted count travels with the
percentile *because of what that caught*. The first version ran after the conformance suite,
whose ADP-05 leaves the guard `Prepared` for five minutes; all twenty samples were refused
as `STATE_INVALID` and it reported **p95 3.09 ms with accepted=0** — a fast number about the
refusal path, which is a cheaper path through the guard. The gate refused it by name. It now
runs before the suite, with sequence numbers below the suite's, and drains itself.

Repeating an acceptance at all is possible because the guard housekeeps a lapsed preparation
back to Idle; without that there is one acceptance per controller lifetime, which is a sample
of one.

---

### Defect 51: a strict pipeline that reported a failed harness as a skip

`./scripts/verify.sh --strict` did not pass `--strict` to step `[11/14]`.
`check-verification.mjs` reads its **own** arguments to decide whether a harness that could
not be run is an error or a stated local skip, so a strict pipeline invoking it plainly
downgraded a genuine harness failure to `SKIPPED locally` and still exited 0.

Observed, not theorised: this session's first strict run printed
`SKIPPED locally: backup-restore: could not be run` and then reported the pipeline complete.
A gate that approves rather than refuses is the failure mode the whole method exists to
prevent, and the same line was missing from `verify.ps1`.

### Defect 52: two gates bound to ports Windows had taken

`check-backup-restore.sh` and `check-telemetry-retention.sh` bound Control Core to fixed
ports 5091 and 5092. **Windows had reserved 5041–5657 for Hyper-V at boot**, so Kestrel
failed with `SocketException 10013` and the harness read as the service being broken. The
excluded ranges are dynamic and move between reboots, so no fixed number is safe: both now
bind port 0 and read the port back from the service's own startup log.

Two further things had to be true at once, and each cost a run: Kestrel refuses a dynamic
port on the `localhost` name outright — *"You must either bind to 127.0.0.1:0 or [::1]:0"* —
while `AllowedHosts=localhost` answers a request addressed to the literal with 400. The
service therefore **binds** `127.0.0.1:0` and is **addressed** as `http://localhost:<port>`.

### Defect 53: a migration whose GRANT was a comment

Migration `0012` said "SELECT and INSERT only". `0002` sets
`ALTER DEFAULT PRIVILEGES IN SCHEMA ch1 GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES`, so
`cinerion_app` held all four from the moment the table existed and granting two of them again
changed nothing. The attack test found the `UPDATE` being refused by the immutability
**trigger** rather than by an absent privilege — the trigger holding a line the grant was
supposed to have held first.

Worth remembering as a class: **every controlled table created since 0002 inherits UPDATE and
DELETE for the application role unless it revokes them**, and only `0010` ever did. `0012` and
`0013` now revoke explicitly.

---

### RoleAssignment: a declared entity whose history was verifiable and not readable

`entities.json` declares it with its own identifier, a Security Sensitive classification and
a seven-year retention, and `0001` created no table. A role change was evidenced only by
`ch1.audit_events`, which stores a payload **hash** — so an auditor could prove an event had
not been altered while being unable to say what it recorded. Same class as conflicts 3 and 7.

Migration `0012` records each change **in full** — previous, current, granted and withdrawn —
rather than only the difference, because a history of deltas cannot answer *"what did this
person hold on that date"* without replaying every row and trusting that none is missing. It
names the provider the change was applied to, so a row cannot be read as evidence about a
directory it never reached, and carries the declared retention on the row with a `CHECK`, so
a disposal process can act on data rather than on a reading of a page.

Keycloak remains the authority on who holds which role. This is CH1's own record of the
changes **it** made. Written after the directory accepts the change, so a row can never
assert a grant the provider refused; a no-op request records nothing, and a refused change
records nothing while the audit chain still carries the attempt.

### CH1-DOC-FR-0004: the publication pipeline, which was never the vault

Four operations answered 501 as "the secure document vault, a declared future phase". Two of
them were not that. CH1-DOC-FR-0002 and 0003 genuinely are a later phase. **CH1-DOC-FR-0004
is "Baseline P03"** and needs no key boundary at all: it is a review pipeline.

| Control it names | What happens |
|---|---|
| approved redaction profile | two profiles held with pinned revisions; an unknown one is refused rather than treated as permissive |
| allowlist inputs | every source must be a controlled document in this project AND its classification must be on the profile's allowlist — an allowlist, so a classification nobody anticipated is excluded by default |
| metadata scrub | every key not on the profile's list is removed **and named**; a package that claims to have been scrubbed and can name nothing it removed is one nobody can check |
| secret scan | a finding is a **refusal**, not a note. The retained metadata is scanned on the same terms. Only pattern names are reported, never the matched text |
| owner approval | two capacities, two identities, neither the author, each with a phishing-resistant step-up grant and the checksum of what they looked at. One rejection decides the package |
| checksum generation | computed here, never accepted from the caller |
| content diff | **NOT performed**, and every package and response says so |

The diff against the source documents' own text needs bytes this platform does not hold. What
*is* checked is the half that needs none: a "redacted derivative" whose checksum equals a
source's has redacted nothing, and is refused. `contentDiffPerformed: false` travels with its
reason, on the same terms as a device revocation reporting `brokerTopicAclRevoked: false`.

**Nothing here publishes, and no operation in this platform does.** Every response says so.

`ch1.controlled_documents` had existed since `0001` with nothing in it and nothing reading
it; CH1-DOC-FR-0001 is the part of the document requirement that needs no vault, so the
register is now read and seeded with three classifications — the allowlist is the control,
and a refusal cannot be told from an empty database unless something is there to refuse.

### The OPC UA adapter sources controller state

The handover named this "the natural next increment on this edge". The value is not that a
cell becomes permissive: it is that it becomes observably **not** permissive. Until now a
gateway in front of an OPC UA controller reported nothing about the controller at all, so
`CellStateResolver`'s *"no controller has answered"* path was reached by **absence** rather
than by an answer. Defect 47 was two screens rendering a cell as fully permissive because a
protobuf default read as a fact; a refusal that exists only as silence is the same mistake one
layer up.

`ControllerPermissives.NotReported` is returned unconditionally — there is no branch that
could produce a reported permissive whatever the address space contains. The deferred codes
are parsed from the guard's own published lines rather than from a list held in the gateway,
and 207 is added whether or not a read carried it.

---

### The ingest ceiling, diagnosed and partly lifted — CH1-VVT-TC-0090

> **SUPERSEDED.** This is the previous session's record, kept because its diagnosis is
> what made the fix findable. The requirement is now MET at 100.02 msg/s — see "This
> session: the three performance cases" above. Every figure below is historical, and the
> statement that the gate announces nothing is no longer true of it.

The previous session left this as *"the undiagnosed `TRANSPORT_Unknown` failures under
pipelining"* and asked whether `AppendTelemetryAsync` round-trips per sample. Both questions
are now answered, and the second answer was yes.

**The failures name themselves now, which is the change that made the rest possible.** gRPC
reports every server-side throw as the same opaque `Unknown`, and the harness tears its stack
down on exit — so across two sessions nobody could see what was actually being thrown.
`scripts/check-baseline-load.sh` now prints the exceptions from Control Core's own log,
deduplicated, whenever a call failed. What came back:

```
19 System.TimeoutException: Timeout du…
19 NpgsqlException (0x80004005): Failed to co…
```

That is PostgreSQL **connection acquisition** timing out, not the writes themselves. The
p95 latency of 15 096 ms in the first run is the Npgsql pool timeout of 15 seconds, almost
to the millisecond.

**Why the pool was the constraint.** One publication carries four readings — every channel of
one device — and cost **nine pooled connections and roughly nineteen round trips**:

| Per publication | Before | After |
|---|---|---|
| device lookup | 4 connections (one per reading, same device) | **1** |
| telemetry append | 1 connection, 7 round trips (`set_config`, `BEGIN`, 4 × `INSERT`, `COMMIT`) | 1 connection, **3** round trips |
| outstanding-alarm read | 4 connections (one per reading) | **1** |
| **total** | **9 connections** | **3** |

At the required 100 msg/s that was 900 connection acquisitions a second against a pool of
100, each spending a round trip on `set_config` before its own statement.

Three changes, none of which alters a decision:

1. **`AppendTelemetryAsync` sends the burst as one `NpgsqlBatch`.** Same statement, same
   `ON CONFLICT`, same transaction; Npgsql simply writes every `INSERT` before waiting for
   any of them to be acknowledged.
2. **The device is looked up once per device per batch.** It was read once per *reading*, so
   a four-reading batch asked for the same record four times. Trust is still read from the
   store rather than believed from the message, still per call rather than cached across
   calls, and every guard still runs for every reading.
3. **Outstanding alarms are read once per source per batch.** A source holds at most one
   outstanding alarm per code, so the newest per code is exactly the row the per-reading
   query returned. A transition inside a batch updates the batch's view, so two readings on
   one channel cannot both raise.

**Measured, on this workstation, with the other labs stopped so they were not competing:**

| Run | Sustained | Worst complete second | p50 latency | Transport failures |
|---|---|---|---|---|
| Batched inserts only | 21.29 msg/s | 0 | 7 561 ms | 869 |
| **All three** | **36.95 msg/s** | **10** | **4 854 ms** | **578** |

A 74 % improvement, the worst second off zero for the first time, and latency halved. Two
earlier runs on a contended machine — the identity, protocol and data labs all up — gave
17.20 and 14.25 msg/s, which is why they were repeated on an idle one.

**The requirement is still not met, and the case stays `not_executed` with no bindings.**
36.95 against a required 100 is a refusal, and the gate announces nothing. Recording it any
other way would be the overstatement the verification map exists to prevent.

**Then the measurements were taken further, and found something better than a speed-up.**
Asking *why* the pool saturated at 37 msg/s produced defect 49: the pool was entitled to
open 100 connections against a server that grants 97, so under load it was failing to
obtain connections rather than waiting for them. That is a robustness defect independent of
throughput, and it is fixed.

**What the workstation can and cannot say.** Measured directly on the lab volume: **244
commits per second** (≈4.1 ms each, so disk durability is not the binding constraint at the
required 100/s) and **13.3 ms to open a fresh connection**. Docker Desktop sees 8 CPUs and
8 GB. So the remaining gap is not disk and not the wire; it is concurrency against a
connection budget, which is exactly what a rig on representative hardware exists to settle.

**What the next step is, and why it is not taken here.** Three connections per publication
remain, and each still spends a round trip setting the project scope before its own
statement. Collapsing them to one means a per-request unit of work — one connection held
across the whole ingestion call and threaded through `ICinerionStore` — which is an
architectural change to the store boundary rather than a local fix, and `AGENTS.md` is
explicit that broad rewrites are reported rather than made unilaterally. **Owner's decision.**
The cheaper half of it is worth stating too: `set_config` could ride in the same round trip
as the statement it scopes, which would halve the reads again without touching the boundary.

Verified after the change: `dotnet build` 0 warnings, 400 .NET tests pass, `npm run
grpc:verify` green end to end on PostgreSQL with the in-process source off, and
`npm run buffer:verify` green — the harness that proves nothing is lost, nothing is stored
twice and nothing arrives out of order through this exact write path.

### The portal interface harness exists, and CH1-VVT-TC-0102 is executed rather than argued

The largest remaining hole in verification was never screen coverage. It was that **no
screen's rendered behaviour could be checked by anything**: `npm run screens` counts which
declared screens exist, `npm run contracts:portal` proves each field the portal reads is one
the service really sends, and `dotnet test` proves the service sends the right values. None
of the three says anything about what an operator ends up looking at — and CH1-MON-FR-0003,
CH1-COL-FR-0002 and CH1-UXD-DSG-0001 are statements about exactly that. Every claim in the
"driven in a browser" tables above rests on somebody having looked, which cannot run in CI
and needs a person to type a password.

`npm run render:portal` now runs the interface. **39 scenarios, 426 checks** across **every one
of the 18 screens that exist**, no Docker and no database, in about a minute. It found a
safety-relevant defect on its first day (defect 47) and a hole in a neighbouring gate on its
second (defect 48).

| Piece | What it is |
|---|---|
| `apps/operator-portal/harness/loader.mjs` | Does what Metro does at build time: strips types, compiles JSX, resolves `@/` into `src/`, and points `react-native` at `react-native-web`. **No new dependency** — `@babel/core`, the JSX transform and the TypeScript preset are already in the tree because Expo builds the portal with them |
| `harness/environment.mjs` | A DOM, and a Control Core that answers **only** what was captured |
| `harness/render.mjs` | Mounts a screen with `react-dom/client` and lets its effects run |
| `harness/screens/*.mjs` | The scenarios, one file per subject |
| `scripts/check-portal-render.mjs` | The gate |

**Server rendering was the obvious approach and does not work.** Every screen reads through
`useObserved`, whose fetch happens in a `useEffect`, and server rendering never runs effects
— so `renderToStaticMarkup` produces the loading state of every screen in the portal and
nothing else. A DOM and a client render are what make the screen's own data path execute.
`jsdom` is the **one** dependency added (29.1.1, a portal devDependency); `npm run
audit:deps` was re-run after installing it and is still green.

**Nothing is mocked at the hook boundary, because that would test the mock.**
`globalThis.fetch` is stubbed and the screen's own `apiFetch`, `useObserved`, components and
rendering all run unmodified. The fixtures are the 39 responses in `artifacts/contracts/`,
captured from a *real* service by `PortalContractFixtureTests` and already gate-checked — so
a screen is rendered against what Control Core actually sends.

**A request the scenario has not declared is refused, not answered.** That is the
load-bearing property: a 404 or an invented body would let a screen asking for the wrong
thing keep passing. Proven by removing `/api/v1/projects` from a scenario's route table —
`the screen asked Control Core for nothing the harness had not captured` fails, naming it.
A **missing** capture fails the scenario outright rather than rendering an empty screen,
proven by moving `AlarmPage.json` aside.

**Every expectation is derived from the captured response rather than written out**, and the
harness computes its own expected timestamp formatting rather than calling the portal's —
an expected value computed by the code under test agrees with it by construction. The
scenarios were re-run after `dotnet test` recaptured the fixtures and still pass, which is
what that buys.

**What is stood in for, and what that costs.** Three modules are replaced, each a *host*
rather than a subject, each with the reason beside it in `loader.mjs` and printed nowhere
else in the tree: `expo-router` (navigation — a recorder, so a screen that navigates can be
asserted on), `expo-auth-session` (the OIDC browser redirect) and
`react-native-safe-area-context` (device insets, which a workstation has none of).
`SessionProvider` itself is **the shipped one**: it reads the authorisation response out of
the address bar, compares its state against the request the tab stored, consumes both so
neither can be redeemed twice, exchanges the code and decodes the claims with the portal's
own `readTokenClaims`. The stub refuses an authorisation code it did not issue, so a
harness that failed the state comparison would report a signed-out screen rather than a
signed-in one. **What is therefore not tested at all: authentication.** The token is
unsigned and the harness never establishes that anybody may see anything — Control Core
does that, on every request, and the scenarios assert only what is rendered.

**CH1-VVT-TC-0102 moves from `partially_automated` to `automated`.** Its controlled expected
result is that the six operational states "remain distinguishable without colour alone". The
shipped `FreshnessTag` is now mounted in all six and **only the DOM text is compared**, so a
pass cannot come from colour: every one of the fifteen pairs is asserted distinguishable, by
word and by glyph. Two of the six are additionally reached on the live control room through
the real data path — Simulated from the captured response, Disconnected by taking the
service away mid-run. What is still not exercised anywhere is a colour-vision or contrast
measurement, which is an inspection activity rather than a test, and the note says so.

**The gate was attacked eight ways, and refuses each.** Six against the screen, each
reverted afterwards:

| Attack | Result |
|---|---|
| The `Outstanding` fact deleted from the alarm row | 2 checks fail, naming `OutstandingYES` |
| An acknowledgement made to present the cause as clear | fails at `the cause is a fact of its own`, and again at the combined three-fact check |
| The screen made to consider itself always current | 3 checks fail — the not-current banner, the reason it gives, and the reconcile control |
| Telemetry requested with no cell scope | `no telemetry was requested for an identity with no cell scope — /api/v1/telemetry?cellId=undefined` |
| The thread link made to carry the alarm identifier as the thread identifier | fails, printing both identifiers |
| Two freshness states made to render identically | 3 checks fail, including `Stale and Maintenance are distinguishable from text alone — both render "▲STALE"` |

**One attack separated two independent controls, which is the useful part.** With the screen
made always-current, `the alarm feed reports DISCONNECTED` still **passed** — the freshness
indicator and the withholding of the acknowledgement are genuinely two controls, and the
attack showed which check measures which. Same lesson as the CH1-COM-IF-0003 probes.

And two against the binding, both caught:

| Attack | Result |
|---|---|
| The harness stops announcing the case the map binds to it | `The verification map binds CH1-VVT-TC-0102 to portal-render, but the run announced no such case.` |
| The harness announces a case the map does not bind to it | `portal-render announced CH1-VVT-TC-0101, but the verification map does not bind that case to it.` |

**An ordering constraint the work exposed, and it would have broken CI rather than this
workstation.** `artifacts/` is git-ignored, so the captured responses exist only once
`dotnet test` has written them — and `npm run verification` ran at step `[10/13]`, *before*
the .NET step at `[11/13]`. Adding the render harness there would have failed on a clean
checkout for a reason that had nothing to do with the portal. The two steps are now
swapped in both `verify.sh` and `verify.ps1`, which is the more correct order anyway: the
map's .NET half is reconciled inside each test assembly, so reconciling the bindings before
the .NET step always depended on evidence that did not exist yet. The gate also refuses up
front, by name, when `artifacts/contracts` is absent.

**And the render gate is its own step, not only an observation inside the verification one.**
`check-verification.mjs` reports a harness that exits non-zero as *could not be run*, which
locally prints as a skip — so a genuinely failing screen would have read as a harness that
was unavailable. The cheap gates already handle this by being both: `npm run baseline` and
`npm run policy` are standalone steps *and* observations. `npm run render:portal` now is
too, as `[13/14]`. `verify.sh` is therefore 15 steps, `[0/14]`…`[14/14]`, and `verify.ps1`
carries the same gate.

**Reconciled by `npm run verification`, with nothing skipped.** The gate ran end to end and
passed: *87 controlled cases, 72 with executable evidence, **14 of 14** announcing harnesses
reconciled against a real run*, `portal-render` among them — a harness the map binds but that
never ran would have failed the binding check, which is exactly what attack A produced.

An earlier run of the same gate reported **12 of 14**, with `offline-workflow` and `grpc-edge`
skipped: Docker Desktop had stopped and been restarted mid-session, and the gateway-buffer
harness was holding the daemon at the time. Each was then re-run directly and passed on its
own, and the next full run had all fourteen. Recorded because "SKIPPED locally" is how
`check-verification.mjs` reports a harness that exits non-zero for *any* reason — which is
also why `npm run render:portal` is its own `verify.sh` step rather than only an observation
inside this one.

**The capture was extended so the two remaining branches stopped being unreachable.**
`PortalContractFixtureTests` captured a telemetry page taken *before* the breach it then
raised, and an alarm page holding one already-acknowledged alarm — so the acknowledgement
form was correctly never offered and no reading was ever outside its limits. It now raises a
second breach on a second channel and leaves it outstanding, and captures the telemetry page
after both, so the captured responses carry an acknowledged alarm whose cause is still
present, an alarm nobody has answered, a reading inside its limits and two outside them.
Nothing was invented: every one comes through `MonitoringService.IngestAsync`, the path a
gateway uses. `AlarmRecord` is now captured **by identifier rather than by position**,
because a page holding two alarms would otherwise start describing whichever the service
happened to sort first.

That unlocked the two most valuable checks in the harness: **an empty acknowledgement
comment is refused in the interface and sends no request at all**, and a reading past its
limit says `Control Core raises the alarm, not this screen`. Reverting the empty-comment
guard fails three checks including `expected 0, observed 1` requests; softening the notice
to `alarm raised` fails two.

**And the harness cannot pass on impoverished fixtures**, which is the vacuous-check failure
mode this repository has been caught by twice. Reducing the captured alarm page to only
already-acknowledged alarms fails with *every captured alarm is already acknowledged, so the
acknowledgement control is never offered*; reducing the telemetry page to readings inside
their limits fails with *every captured reading is inside its limits*. A scenario that can
no longer exercise its subject says so rather than passing quietly.

**One thing the extension found, and it is the fixture rather than the service.** A telemetry
query's window ends at *now* — `TelemetryQuery.Create` resolves an absent `to` that way — so
readings the fixture stamped a second into the future raised their alarms and were then
absent from every query. The capture would have held an alarm whose reading could not be
found anywhere. The fixture now stamps in the past. This is a property of the in-process
ingestion path the capture uses: the controlled gRPC ingress checks clock lead before it
looks at a payload, so a real gateway running ahead is refused at the edge rather than made
invisible.

### CH1-UX-SCR-0007, the second screen: the failure that has to stay readable

Part genealogy was the natural second, because its load-bearing property is one no other
gate touches. CH1-QMS-FR-0004 requires a failing measurement **and** the retest that
supersedes it to both remain readable; a screen showing only the accepted result would
render a part with a clean history, and would be wrong in the one direction that matters —
an inspector reading it would not know a failure had ever happened. The captured
`PartGenealogy` already carried exactly that shape, a failing 8.2 µm against a 9.5–10.5
limit superseded by a passing 10.1 µm, so this needed no change to the capture at all.

Three scenarios, 42 checks. Two of the three are security properties rather than
presentation ones:

| Behaviour | Observation |
|---|---|
| The failing result survives the retest | 8.2 µm still on the page beside the 10.1 µm retest, marked `SUPERSEDED` and `OUTSIDE LIMITS`, with the retest naming what it supersedes and citing CH1-QMS-FR-0004 |
| Every measurement resolves to its run | the controlled `testRunId` rendered for each, which is what CH1-MFG-FR-0002's "resolve to its tests" asks for |
| Provenance is the server's word | rendered verbatim, so the screen can never misdescribe the durability of controlled evidence |
| **A part outside scope reads exactly like one that never existed** | the page says both are answered identically *on purpose*, and never says "not authorised" or "Forbidden" — telling them apart would be the leak |
| A serial number is not an identifier | typing the part's own serial number into the identifier field is refused inline, and **no request is sent for it** |

Two more attacks, both refused. Filtering superseded measurements out of the list — the
plausible "show only the current result" change — fails four checks including *a superseded
failure must not be removed from the history*. Replacing the empty state with *You are not
authorised to view this part* fails three, including the one written for exactly that: *the
screen does not say the caller lacks authority, which would be the leak itself*.

### The permissive distinction, reached at last — and the defect it exposed

The previous handover recorded this as blocked, and said why: *"No screen reads
`permissivesReported` or `deferredCheckCodes` yet … Left here rather than added blind,
because a screen change is verified by driving it in a browser and that needs a person at
the keyboard."* That constraint is what the harness removes, so this was the first thing
done with it.

**The gate was written before the code, and it failed — which is the finding.** Rendering
the captured cell state, whose controller has never answered, `CH1-UX-SCR-0016` produced
`6 / 6` in green and `CH1-UX-SCR-0008` produced `6 / 6 valid`. Recorded as **defect 47**.
Both screens held their own copy of the counting logic, which is how they came to be wrong
in the same way; the rule now lives once in `src/api/permissives.ts`.

| Behaviour | Observation |
|---|---|
| A cell nobody answered for is not counted | the count is withheld and replaced by `NOT ANSWERED`, on both screens |
| And is never green | `permissiveTone` returns `warning`, never `good`, before freshness is even consulted |
| The reason is given, not just the flag | *"An unanswered permissive is treated as not satisfied, never as satisfied, because a report that was never made and one that came back healthy are indistinguishable in the wire format."* |
| The deferred checks are named | 206 and 207 rendered, because the reason is what an operator needs |
| **A cell whose controller did answer still reads as it always did** | `6 / 6`, not marked unanswered — without this, a screen could satisfy the check above by never showing a healthy cell as healthy, which is a different defect rather than a fix |

Attacked twice, each reverted afterwards. Removing the withholding from
`permissiveSummary` fails two checks **on each screen** — which is also the evidence that
both really do depend on the one shared rule. Making `permissivesAnswered` infer an answer
from the cell merely existing fails **six on each**, and leaves the positive scenario
passing, so the attack cannot be mistaken for a screen that simply stopped rendering.

### CH1-UX-SCR-0018: a receipt that reports the half that did not happen

The fifth screen, and its subject is the one AGENTS.md names outright — the portal must
never falsely claim physical execution. CH1-COM-IF-0004 puts the MQTT topic ACL in the
broker, which is not enabled, so revoking a device withdraws platform trust and nothing
else. A receipt implying both halves took effect would be the more dangerous kind of wrong:
an administrator would believe a device had been cut off at the transport when it had not.

Four scenarios, 29 checks:

| Behaviour | Observation |
|---|---|
| The record is stated, not interpreted | identity, type, firmware, configuration revision, trust state, and **when it was last heard from** — never "online", which is not a fact the record carries; the service's own `lastSeenQuality` qualifies it |
| **The receipt reports what did not happen** | `DONE · Platform trust withdrawn` beside `NOT DONE · Broker topic ACL revoked`, with the server's note rendered verbatim |
| The captured response really carries an un-done half | asserted explicitly, so the honesty check is not passing against a happy path |
| A control the identity may not use is not offered | no reason field at all, and the screen says why rather than leaving it unexplained |
| **The role that may revoke but not read is told so** | conflict 16, stated on the screen: what it costs, and what to do instead |

Two more attacks, both refused. Hard-coding the broker effect to `done` fails *what did NOT
take effect is marked NOT DONE rather than omitted*. Removing the notice about the role
split fails three, including *what to do instead*.

`RevocationReceipt` is now exported so the harness can render it directly. Reaching it
through the screen needs a phishing-resistant step-up grant, and issuing one inside a test
harness would be the harness manufacturing an elevation — the one thing a step-up exists
not to be. **What is therefore not exercised is the step-up flow that precedes the receipt**,
and that is stated rather than glossed.

### CH1-UX-SCR-0006 and CH1-UX-SCR-0009: two screens whose subject is a refusal to look complete

Both of these are gated for what they **decline** to show, which is unusual and is exactly
why they need a gate: nothing else would notice the statement going away, and each would
look *more* useful without it.

**The work-order board** states conflict 14 on itself. The catalogue has no operation that
lists or fetches a work order, so an order raised in another session is not missing — it is
unreadable, and rendering an empty board as a complete one would be the more misleading of
the two. Four scenarios: the revisions and lifecycle states as the record carries them; the
board's own statement of the gap; a **draft** revision offering no way to start work and
naming CH1-MFG-FR-0005; and a released one that does offer the form, where an order with no
controlled number is refused in the interface and **sends no request at all**.

**The procedure screen** is gated on an absence. No controlled operation reports a
controller's position in a sequence, so a highlighted "current step" would be a guess
rendered as fact on the screen a Local Confirmer uses to decide whether a hold has been
reached. Two scenarios: the controlled sequence with its hold points marked, and seven
phrases the screen must never contain — `CURRENT STEP`, `IN PROGRESS`, `EXECUTING` and the
rest — alongside its own statement of why it cannot draw one.

**Attacking the gate found a hole in the gate, which is the point of doing it.** Adding a
`CURRENT STEP` pill to the first route step fails immediately, and deleting the board's
boundary paragraph fails two checks. But neutering `canRaise` — offering the Project
Manager's control to an identity that does not hold the role — **changed nothing any
scenario asserted**, because the two scenarios that could have caught it both ran as a
Project Manager. The role gate could have been removed without a single check noticing.
`work-orders-raise-not-offered-without-the-role` now covers it, and with it in place the
same attack fails three checks by name. That is the second time in this repository that
attacking a gate showed the *test* was weak rather than the code.

### Three more screens, each gated on a guarantee rather than on a layout

**CH1-UX-SCR-0019, collaboration.** The interface half of CH1-VVT-TC-0109: a message
carries no control authority, and reading one acknowledges no alarm. The vocabularies are
already held apart at compile time and the database refuses the confusion with CHECK
constraints — neither says anything about what a reader is shown. The receipt's verb, its
`controlAuthority` flag and its side-effect sentence are all asserted to be the server's
own words, and the scenario additionally asserts the captured receipt really does carry
`controlAuthority: false`, so the check cannot pass against a happy path. **The first
version of this scenario was wrong and is worth recording**: it asserted the alarm verb
never appears, and the screen shows both verbs side by side on purpose under *"Different
records. Different verbs."* — which is a stronger statement of the separation than silence.
The check now asserts that contrast, and separately that the thread asserts nothing about
an alarm's cause or acknowledgement state.

**CH1-UX-SCR-0017, resources.** A reservation holds capacity and starts nothing, and every
holding carries the server's own sentence saying so. The captured page carries a genuinely
over-committed resource — 200 m against a capacity of 150, withdrawn out of band beneath a
live holding — so the conflict branch is exercised rather than argued, including that the
negative availability is shown rather than clamped to zero.

**CH1-UX-SCR-0001, session.** An OIDC session reaches `Mfa` at most and the realm emits no
`amr` or `acr`, so which authenticators were presented is **not known**. The screen says so
rather than drawing a padlock, and four strength claims it must never make are asserted
absent. It also keeps the two controls apart: clearing the tab's token and ending the
session at FortressGate are different acts, and ending one everywhere asks for confirmation
before anything is sent.

Three more attacks, each reverted, each refused: relabelling a read receipt `ACKNOWLEDGED`,
replacing a holding's physical-effect sentence with `Reserved`, and asserting `MFA verified`
where the token attests nothing.

**A harness weakness fixed on the way.** Opening a per-row disclosure by first identifying
the row needs a predicate about the row, and the first one was subtly wrong — `ACCEPTS
RESERVATIONS` matched the same pattern as the reservation disclosure, so the harness pressed
nothing and the check failed for a reason that had nothing to do with the screen.
`pressAll(label)` now matches the control's own label and de-duplicates by the element
actually pressed, and returns how many it opened so a scenario can assert it opened what it
expected to.

### Defect 48: four response shapes nobody was reconciling

Found while working out which screens the harness could still cover, and it is the same
failure `npm run contracts:portal` was built to remove — one level up, exactly like the
`opcua-edge` hole in the verification gate.

`AuditPage` and `ChainVerification` were declared inside `audit.tsx`; `DirectoryPage` and
`DirectoryUser` inside `security.tsx`. The contract gate reads **only**
`apps/operator-portal/src/api/contracts.ts`, so all four were compared against nothing and
counted in no total. A property named wrongly in any of them would typecheck perfectly and
render `undefined` at runtime — which is the precise defect that gate exists to catch, and
which it had already caught twice elsewhere.

**The gate was extended before the shapes were moved.** It now reads the type argument of
every `useObserved<T>` and `useControlledAction<T>` in the route sources and refuses one the
contract source does not export.

**Attacking it found the extension was weak, and that is the more useful half.** Putting
`interface AuditPage` back on the screen **still passed**: the name was still exported from
`contracts.ts`, so the check was satisfied by a declaration the screen was no longer using.
A local declaration shadows the import, typechecks identically, and is reconciled against
nothing — the original defect wearing the fix as a disguise. The gate now refuses a route
that declares its own interface of a name it reads a response as, and the same attack fails
by name: *declares its own interface AuditPage and reads a response as it, shadowing the one
contracts.ts exports*.

All four shapes are now declared in the contract source and captured from real responses —
the audit page from a chain carrying an alarm acknowledgement raised through the ordinary
path, and the directory listing through the stub directory registered for that one host, the
same way session revocation already was. **43 of 43 shapes compared, up from 39.** The
capture also asserts the directory projection carries no `password`, `secret`, `credential`,
`seed` or `privateKey` field, which matters more than any property the portal reads.

### Three more screens: CH1-UX-SCR-0010, CH1-UX-SCR-0003 and CH1-UX-SCR-0004

Each gated on the same shape of property — a refusal to let an absence read as a pass.

| Screen | What is gated |
|---|---|
| **0010** inspection | an empty acceptance record is not a pass, and a superseded failure stays visible with its failing value — CH1-QMS-FR-0004 on a second screen |
| **0003** portfolio | the controlled gates G0–G9 are named as absent rather than drawn; eighteen checks assert no `G0 SATISFIED`/`G0 PENDING`-shaped row appears for any of them |
| **0004** topology | the device register is *called* and the server's refusal reported, rather than described in prose; the controller identity shown is the one the cell published |

Three more attacks, each reverted, each refused: dropping the superseded marker, drawing
`G0 SATISFIED · G1 SATISFIED · G4 PENDING` where no operation reports one, and replacing the
register's `REGISTER UNAVAILABLE` with `ALL CLEAR`.

### Every built screen is now driven, and the coverage is itself gated

The last five went in together — CH1-UX-SCR-0014 (audit), 0013 (security), 0022 (comms),
0002 (credentials) and 0011 (the disposition half of the quality route, which declares two
screens). Each is gated on a statement about what the platform does **not** hold or does
**not** prove, which is the class of claim a typechecker cannot see and a tidy-up can delete
without anyone noticing:

| Screen | What is gated |
|---|---|
| **0014** audit | events and the verification are the server's answers; the screen states that a *payload hash* is what is recorded, not the payload, and that external anchoring is a later gate. Pressing VERIFY CHAIN is asserted to issue the controlled request rather than compute an answer here |
| **0013** security | identifiers, scope and lifecycle and **never a credential field**; and separately, the fail-closed direction — a directory the platform cannot see reads as *unavailable, never as empty*, which is the reading most likely to be taken for "nobody holds a role" |
| **0022** comms | a deferred check is explained as the controller being honest about what it cannot read, with 206 and 207 named — an operator cannot act on "207" |
| **0002** credentials | nothing on the page ever shows a private key, four secret-shaped strings are asserted absent, and a browser with no authenticator is told so rather than offered a control that cannot work |
| **0011** quality | absence of an NCR is **not** acceptance; the disposition workflow says it is not yet retrieved rather than showing an empty one; and independent release is asserted against the record — the inspector who released is not the operator who made the part |

**And the coverage is now a requirement rather than a number.** The gate reads the `@screen`
markers out of the route sources and fails when a built screen has no scenario driving it.
Counted-but-not-required coverage is coverage that regresses quietly: a new route could be
added and the gate would go on reporting a healthy figure for the screens it happened to
know about. Proven by pointing one scenario at a different screen —
*CH1-UX-SCR-0022 is implemented by a portal route but no render scenario drives it*.

**Two escaping mistakes cost real time and are worth writing down as a class.** Twice a
regular expression written into a `.mjs` file through a script came out with `\b` collapsed
to a literal backspace character, so `/…\d{4}\b/` silently matched nothing and the check it
belonged to passed over everything. Both times the check *looked* right in the file and both
times the first attack on it passed. The tell is a check that finds zero of something that
obviously exists — and the fix is `String.raw` or no `\b` at all. It is recorded here
because the failure mode is invisible: a broken regex in a gate does not error, it simply
approves.

**What this does not cover, stated plainly.** The four screens with no controlled operation
behind their subject (0012, 0015, 0020, 0021) are not built and cannot be. There is no
browser engine, no layout and no measured size. Authentication is not exercised. A
colour-vision or contrast measurement remains an inspection activity. There is no browser
engine, no layout and no measured size: jsdom implements no layout, so nothing here asserts
a pixel. Authentication is not exercised. A colour-vision or contrast measurement is an
inspection activity and remains outstanding.

### CH1-COM-IF-0003, live: EdgeLink publishes into Control Core, and the command path runs on PostgreSQL for the first time

The interface register states this edge in one line — *CommandGuard to EdgeLink | Internal
gRPC | Bidirectional | Protobuf | mTLS* — and **none of it existed**. Four operational
adapters produced real telemetry, real capability models and real acknowledgements; the
gateway proved its conformance at startup and then sat idle, because there was nowhere for
any of it to go. Everything the domain knew about a cell came from a seeded row.

| Piece | What it is |
|---|---|
| `packages/contracts/proto/ch1_edge_link.proto` | The controlled contract, and deliberately **one file rather than two**. The Modbus map is held twice on purpose — there the two ends speak a protocol with no schema, so agreement between independently written maps is itself the evidence. Here the schema crosses the wire, and a second copy would be another thing to keep in step rather than a check on the first |
| `EdgeIngressService` | The receiving half. Schema version, source identity, destination, message identifier, sequence, scope, clock lead and expiry are all checked **before a payload is looked at**; then the device must be enrolled in that project, still trusted, and assigned to the cell it reports for — the same checks telemetry has always had, because a controller reporting its own permissives is at least as security-relevant as one reporting a temperature |
| `CellRuntimeProjection` | The volatile half of cell state, in memory and **never written anywhere**. Duplicate suppression by message identifier and ordering by observation time both live here, which is CH1-COM-FR-0010 stated as behaviour |
| `CellStateResolver` | The one place a cell is assembled, so the command path and the screen cannot disagree about it |
| `EdgeLinkIngressGrpcService` | The transport end, on its **own mutually authenticated listener**. It identifies the peer and translates; every decision about whether a message may be believed belongs to the service above |
| `IngressPublisher` | The gateway's side: controller state every 2 s, telemetry in batches, each refusal reported rather than retried |
| `Ch1IngressProbe` (`--probe`) | An attack client that is deliberately not a well-behaved gateway |
| `scripts/check-grpc-edge.sh` | `npm run grpc:verify` |

**The permissives are the whole design, and the honest answer is often "not answered".**
The controlled OPC UA and Modbus profiles both declare `207 PRELIMINARY_PERMISSIVE_INVALID`
as a deferred check: the S7-1200 G2 reads `UDT_CH1_Permissives` from wired inputs, and a
stand-in has none. So `Permissives` carries a `reported` flag, and when it is false the cell
resolves as **not permissive whatever the individual fields say**. That is not a formality —
proto3 leaves an unset boolean false, so a gateway that populates the interlocks and forgets
the flag sends exactly the dangerous message, and the probe sends precisely that.

**Nothing about a live permissive is persisted, and `ch1.cells` still has no column for
one.** Restoring an interlock from a database would present a stale permissive as a current
one; CH1-SAF-FR-0003 requires a restart to default to a non-energising safe state. The
report therefore stands for ten seconds — far tighter than the 30 s that governs a telemetry
projection, because a stale temperature is a reading an operator can judge and a stale
permissive is the state a physical command is authorised against.

**Verified on two services raised from the controlled compose model, on PostgreSQL, with the
in-process simulated telemetry source turned OFF.** That last part is load-bearing: Control
Core can feed itself in the Simulation profile, and with that running, telemetry in the
database would be evidence of nothing. Twenty-eight checks, all passing:

| Observation |
|---|
| before any controller reports, the cell is **not permissive** and says its permissives were never answered |
| the gateway opened the edge as `ch1-edgelink` over mutual TLS against the controlled authority, and Control Core answered `CONTROLLER_REPORT_ACCEPTED` |
| the cell then reports live permissives, an operating state and a configuration revision **read from the controller**, and freshness `Simulated` — never upgraded to `Live` |
| **17 telemetry samples in PostgreSQL**, every one marked `Simulated`, with nothing else writing to the store |
| **4 audit events for controller state, not 40** — a heartbeat every two seconds must not become an audit event, so only a material change is recorded |
| the audit chain still verifies with the gateway writing into it |
| `ch1.cells` carries **0** interlock, boot-identity or button columns |

**Then the thing that had never been possible.** `SaveCommandAsync` was fixed as defect 21
and stayed unexercised, because `PREPARE` needs a cell reporting live permissives and no
such cell could exist on PostgreSQL. With one:

| Observation |
|---|
| a command **PREPARED on PostgreSQL** against a live cell, state `AwaitingCredential` |
| the response states its own limits: local confirmation required, no remote start |
| the same command **CANCELLED at version 2** — the `UPDATE` branch of `SaveCommandAsync`, executed for the first time |
| the database agrees: the stored row is `Cancelled:2`, so **both branches wrote what they claimed** |
| the command, the cell and the asset resolve to one cell without contradiction |

**And communication loss, which is what CH1-COM-FR-0006 is actually about:**

| Observation |
|---|
| with the gateway stopped, the cell reads as **not permissive and `Stale`** within one window |
| a preparation attempted then is refused `INTERLOCK_CONTROLLER_OFFLINE` |
| the controller returns with a **new boot identity**, so the state hash changes and nothing prepared before the loss could be committed after it |
| **no command reached an executing or committed state** anywhere across the sequence |

**Sixteen probes attack the edge, each run before the gateway connects:**

| Attack | Result |
|---|---|
| No client certificate | refused **at the transport** |
| A certificate the controlled authority never signed, carrying the right common name | refused at the handshake — identity is what this authority attested, not a name a client chose |
| **A certificate this authority signed for another gateway** | `The client certificate is trusted but names another gateway` |
| Plaintext HTTP/2 at the ingress port | refused |
| The correct gateway, correct report | **accepted** — so every refusal above is about scope rather than a dead endpoint |
| The same message identifier twice | `INGRESS_DUPLICATE_MESSAGE` |
| A report older than the one already held | `INGRESS_REPORT_SUPERSEDED` |
| An envelope naming another source | `INGRESS_SOURCE_IDENTITY_MISMATCH` |
| Schema `2.0.0` | `INGRESS_SCHEMA_UNSUPPORTED` |
| A message that expired before it arrived | `INGRESS_MESSAGE_EXPIRED` |
| A device that is not enrolled | `INGRESS_DEVICE_NOT_ENROLLED` |
| A device reporting for another cell | `INGRESS_DEVICE_CELL_MISMATCH` |
| **Permissives not answered, interlocks all true** | accepted as `PERMISSIVES_NOT_REPORTED_CELL_NOT_PERMISSIVE`, and the cell then reads **not permissive**, naming deferred checks 206/207 |
| `rotor_speed` | `TELEMETRY_CHANNEL_NOT_ALLOWED` |
| A temperature in millimetres | `TELEMETRY_UNIT_MISMATCH` |
| An acknowledgement for a command nobody prepared | `INGRESS_COMMAND_NOT_FOUND` |

**Attacking the gate changed two of those probes, and that is the most useful thing that
happened here.** Reverting `ClientCertificateMode` to `AllowCertificate` and deleting the
gateway-identity check left the gate **green**: the first attempt was still refused, but by
the service's own null-certificate check rather than by the handshake, and the second was
still refused, but as `INGRESS_SOURCE_IDENTITY_MISMATCH` rather than as the wrong gateway.
Two independent controls in each case — which is good news about the design and bad news
about the probes, because a probe satisfied by either would have gone on passing after one
was removed. **PROBE-01 now requires refusal at the transport specifically, and PROBE-03
requires the identity refusal by name.** With that, the same attack fails the gate and names
what was lost. The other two attacks — dropping the `reported` guard, and widening the
ten-second window to an hour — each failed the gate immediately, at
`unanswered permissives produced startEnable=true` and `the cell still reports
startEnable=true freshness=Simulated after the gateway stopped`.

**A pre-existing defect the work uncovered, and three it introduced.** `GET /cells/{id}/state`
answered `freshness: "Simulated"`, `quality: "Good"` and `sourceTimestamp: <now>` as literals
in the projection, and `SaveCellAsync` wrote the same three as literals in its SQL — so a
cell nothing had reported for since a restart weeks earlier was indistinguishable from one
reporting right now, which is exactly what CH1-MON-FR-0003 exists to prevent. Freshness is
now computed from when the cell was last heard from. The three introduced faults are 40, 41
and 42 below; each would have been invisible on inspection and each was caught by the gate
within one run of raising the two services.

**What is not built, and why it is not hidden.** The register calls the edge bidirectional
and this implements request/response: every publication is answered with the domain's
decision and a stable reason code. What does **not** exist is a server-initiated command
dispatch down to the controller, and the reason is not effort — CH1-AUT-FDS-0001 puts the
commit behind a cryptographic credential proof and a physical button edge observed at the
cell, so a dispatch path would end at a controller that still cannot execute. The
acknowledgement operation exists and refuses a command Control Core never issued, which is
the half that can be honest today. It is recorded under remaining work rather than claimed.

### The Modbus adapter now sources controller state — and what that surfaced

`ModbusProtocolAdapter` implements `IControllerStateSource`. It reports the controller's
identity, firmware, configuration revision, guard operating state and security profile from
the controlled map, and reports the permissives as **never answered**, always naming
deferred check 207. That is the honest answer and the only available one: the controlled map
carries no interlock register, because the real S7-1200 G2 reads `UDT_CH1_Permissives` from
wired inputs and a zone stand-in has none.

Until now the unanswered-permissive path could only be produced by the attack probe. A safe
behaviour proven against a synthetic message is not proven against a controller that
genuinely cannot answer; it is now proven against both.

The boot identity is **derived** from the controller's own boot register rather than
generated. CH1-CMD-FR-0009 needs an identity that changes when the controller restarts; a
random Guid would change on every read and void every prepared command on a healthy
controller.

**A latent defect this surfaces, reasoned rather than measured.** `SimulatorProtocolAdapter`
is registered unconditionally in `Program.cs`, and until this change it was the only
`IControllerStateSource`. So a gateway fronting a real Modbus zone *with the gRPC ingress
also configured* would have published the **simulator's fabricated healthy permissives** for
the cell the Modbus zone actually fronts — a cell reading permissive on the strength of a
simulator while the controller behind it declares its permissive check deferred. That
combination has never been exercised: `check-modbus-edge.sh` configures no ingress and
`check-grpc-edge.sh` configures no Modbus, which is why it was never seen. It is now
unreachable — two sources are ambiguous and the gateway publishes no controller state until
`CINERION_EDGE_CONTROLLER_ADAPTER` names one — but the combination still has no gate, and
building one is the honest next piece of work on this edge.

Verified: `npm run grpc:verify` green (28 checks, including the controller-source guard's
first live run — the debt the previous commit carried), `npm run modbus:verify` green (four
operational adapters, nine checks each, none gated), `npm run modbus:map` reconciles 65
constants across both copies, 398 .NET tests pass.

### One cell, one controller: the guard written before the second source exists

The defect recorded below — that a second `IControllerStateSource` would make a cell flap
between permissive and not permissive — is now closed, and closed in the order the method
asks for: **the gate first, then the code it protects.**

`IngressPublisher.SelectControllerStateSource` chooses the single adapter that speaks for
the cell's controller. One source is selected with no configuration, which is exactly
today's behaviour. **Two sources with no explicit choice select nothing at all**, so the
cell reads as not permissive — the same safe state a gateway with no source produces —
and the refusal names both claimants and the setting that resolves them.
`CINERION_EDGE_CONTROLLER_ADAPTER` makes the choice explicit; a name matching no
registered adapter also selects nothing, because falling back to "the only other one"
would publish a different controller's permissives than the deployment asked for.

There is deliberately **no default preference between adapters**. A silent winner is how
one of two disagreeing controllers ends up authorising physical work.

Six tests, and the attack that matters: making ambiguity pick a winner instead of refusing
fails `Ch1SafFr0003_TwoSourcesWithNoExplicitChoiceProduceNoControllerStateAtAll` by name.
The Modbus and OPC UA adapters can now implement `IControllerStateSource` without
introducing the defect, which is the increment this unblocks.

**Since verified.** `npm run grpc:verify` was run against this change and is green end to
end: the gateway still opens the edge, publishes controller state, and the cell reports live
permissives read from the controller. The UNVERIFIED note this section previously carried is
discharged.

### Controller state from the OPC UA and Modbus adapters: written, working, and NOT committed

Implemented for the Modbus adapter and reverted before commit, because completing it
surfaced a defect the change itself would have introduced. The code built with 0 warnings
and six new tests passed (75 in the assembly, up from 69); none of it is in the tree.

**What was built.** `ModbusProtocolAdapter` implementing `IControllerStateSource`, decoding
the controller's identity, firmware, configuration revision, guard operating state and
security profile from the controlled map, with `ControllerPermissives.NotReported` and
deferred check 207 always named. The boot identity was widened deterministically from
`ConfigControllerBootIdLow` rather than generated, because CH1-CMD-FR-0009 needs an identity
that changes when the controller restarts — a random one changes on every read and would
void every prepared command on a healthy controller.

**The defect that stopped it.** `IngressPublisher` iterates **every** registered
`IControllerStateSource` and each publishes into the **same** cell, because
`ControlCoreIngressClient.NewEnvelope` stamps one `CellId` from configuration. Today that is
harmless: only the simulator implements the interface, so there is exactly one source. Add a
second and a deployment holding both would publish alternating reports for one cell every two
seconds — the simulator saying the permissives are answered and healthy, Modbus saying they
were never answered. `CellRuntimeProjection` accepts both, because each is newer than the
last, so **the cell would flap between permissive and not permissive**. That is a
safety-relevant regression, and the rules here are explicit that a safety property gets a
real gate and a real attack rather than a flag-and-skip. There was no budget left to design
the resolution and prove it, so nothing was committed.

**What the resolution has to decide**, and it is a design question rather than a bug fix:
what does a cell mean when two adapters can both speak for it? The fail-safe reading is that
disagreement resolves to *not permissive*, which argues for one source per cell chosen
explicitly, or for the publisher refusing to publish any controller state when more than one
source is registered. Either way it needs a gate that raises a gateway with two sources and
asserts the cell never reads permissive — which is exactly the attack that would have caught
this had it been written first.

### The portal interface harness: how it was de-risked, and the blocker that is gone

**Superseded — it is built; see "The portal interface harness exists" above.** Kept because
this reasoning is what made the build cheap, and because the blocker's resolution matters.
What was established before any of it existed:

**Rendering portal components in Node works, with no new dependency.** `react-native-web`
and `react-dom` are already in the tree, and `renderToStaticMarkup` over a
`react-native-web` element produces real DOM markup under plain `node`. That was the main
risk in the whole idea and it is gone.

**`artifacts/contracts/*.json` is the right fixture source.** Thirty-nine captured
*real* service responses already exist, written by `PortalContractFixtureTests` and checked
by `npm run contracts:portal`. A harness that renders against those is verifying screens
against what the service actually sends, not against fixtures someone invented — and the
existing gate already refuses a shape that drifts.

**The blocker is effects, and the tool is `jsdom`.** Screens fetch through
`useObserved`, so their data arrives in a `useEffect`. Server rendering never runs effects,
so without a DOM a screen renders only its loading state. The intended design — stub
`globalThis.fetch` to serve the captured responses and let the screen's own `apiFetch`,
hooks and rendering run unmodified — needs a DOM, and `jsdom` is the dependency-light way
to get one. It installs cleanly as a portal devDependency (29.1.1 verified).

**But installing anything re-resolves the lock file, and that is currently blocked.**
Adding `jsdom` re-resolved `package-lock.json` and turned `npm run audit:deps` red. The
advisory is **not** jsdom's and **not** new to this work:

> **RESOLVED — `npm run audit:deps` is green, and `jsdom` was installed with it still green.**
> The original entry follows.
>
> **`npm run audit:deps` failed on `main` at the time of writing.** GHSA-2v37-7h3g-55p8 (High) in
> `nanoid <3.3.18`, reached through **`expo-router`** — a portal runtime dependency, so it
> is not a dev-only exposure — and again through `expo → @expo/metro-config → postcss`.
> Confirmed against the **committed** lock file after `git checkout` and a clean `npm ci`,
> so nothing in this session caused it; the advisory was published after the last audit run.
> An `overrides` entry pinning `^3.3.18` was tried and npm did not apply it, even with the
> lock file rebuilt from scratch — `expo-router` appears to hold `nanoid` in a way the
> override does not reach. **This needs resolving before any portal dependency can be added**,
> and it is the first thing the harness work will hit. Either find the override form npm
> honours, wait for an `expo-router` release resolving 3.3.18, or record a disposition with
> a reachability claim — noting that the repository's own rule forbids accepting a
> runtime-reachable high.

All dependency changes were reverted at the time. `jsdom` 29.1.1 is now installed as a portal
devDependency and the audit gate was re-run after it and is green.

### CH1-VVT-TC-0090 measured for the first time — and the baseline load is NOT met

> **SUPERSEDED.** Historical: the first measurement, at 20.9 msg/s. The requirement is
> now met at 100.02 msg/s.

CH1-NFR-PER-0001 — *"25 active devices, 250 live channels and 100 sustained telemetry
messages per second"* — had never been measured, because until CH1-COM-IF-0003 existed
there was no path over which the load could be offered: telemetry entered the domain only
from an in-process simulated source inside Control Core, so a load run would have measured
Control Core feeding itself.

A harness now exists. `edge-link --load` offers the baseline using **the gateway's own
client** — the same channel, mutual TLS, envelope and sequence numbering the running
gateway uses, because a load driver with its own client measures the load driver.
`scripts/check-baseline-load.sh` (`npm run load:verify`) raises Control Core on PostgreSQL
with the simulated source **off** and judges the result.

**The result is a refusal, and it is a real one.** Measured on the authoring workstation:

| Measure | Required | Observed |
|---|---|---|
| Active devices | 25 | **25**, all publishing concurrently |
| Live channels | 250 | **100** — and 250 is unreachable, see conflict 22 |
| Sustained rate | 100 msg/s | **44.3 msg/s**, worst complete second 27 |
| Publications refused | — | **0** |
| Samples persisted | — | **10 696** across all 100 device/channel pairs, no duplicates |
| Ingress latency p50 / p95 | — | **538 ms / 850 ms** |

The first driver blocked per device, which conflates latency with throughput: 25 publishers
at ~0.54 s a call can only ever report ~46/s however much the service could carry. It was
rewritten to pace independently of completion, with a bounded 256 in-flight cap. **Offering
the load harder made throughput fall** — 33.6 msg/s, p50 latency 4.5 s, 1421 transport
failures — which is the signature of a saturation ceiling around 35–45 msg/s rather than a
pacing artefact.

**So the case stays `not_executed`, with `bindings: []`, and the gate announces nothing.**
The harness is real and the measurement is real; what it measured is that the requirement is
not met. Recording it any other way would be the overstatement the verification map exists
to prevent. What is needed next is a performance investigation of the ingest path — the
`TRANSPORT_Unknown` failures under pipelining are not yet diagnosed — and a rig on
representative hardware, **not more test code**.

**A defect the load found on the way.** `CellRuntimeProjection`'s duplicate-suppression
window is documented as five minutes and was bounded at 8192 identifiers. At the controlled
baseline rate of 100 msg/s that is **82 seconds**, after which the window empties itself and
duplicate suppression silently degrades to a fraction of what it documents — precisely when
the system is busiest. Five minutes at the baseline rate needs 30 000; the bound is now
32 768, still bounded, which is what CH1-COM-PRO-0001's "flow control caps memory" asks for.

### CH1-VVT-TC-0093 closed: the 24-hour gateway buffer, and four defects in the code that implemented it

CH1-NFR-REL-0001 — *"The gateway shall buffer at least 24 hours of configured telemetry
without overwriting newer critical events"* — was the last `not_executed` case needing only
work. The previous session left ~1000 lines for it in the working tree that had **never been
compiled**. It compiles now, and the honest headline is that **the design was sound and four
things in it were wrong**, each invisible on inspection.

**The restore failed before any code did.** `Microsoft.Data.Sqlite` 10.0.10 resolves the
SQLitePCLRaw 2.1.11 family, whose native package carries GHSA-2m69-gcr7-jv3q /
CVE-2025-6965 (High) — SQLite before 3.50.2 lets aggregate terms exceed the available
columns, which is memory corruption. `TreatWarningsAsErrors` turned NU1903 into a failed
restore, exactly as it did for `Microsoft.OpenApi` in the first week. Remediated the same
way and not accepted: the four packages are pinned to 2.1.12, the first release outside the
advisory's range, and `NU1903` is **not** suppressed. The pin is not trusted on its own —
a test opens a real buffer and asks the loaded native library what it is
(`SELECT sqlite_version()`), failing below 3.50.2, so a resolution that quietly reintroduced
the defective engine fails a test rather than passing a version comparison.

| Defect | What it was | How it was found |
|---|---|---|
| **43** | **Telemetry had no duplicate suppression at all.** `CellRuntimeProjection` refused a repeated message identifier for controller *state* reports and for nothing else; `PublishTelemetryAsync` went straight to the store. The buffer's whole replay design rests on a record being removed only once Control Core has answered, so a gateway dying in between **replays** — and would have stored the reading twice. The WIP explicitly claimed such a replay "is refused as `INGRESS_DUPLICATE_MESSAGE`". It was not. | Reading the receiving side to check the claim |
| **44** | **With no buffer configured the gateway published nothing.** `EnqueueAsync` returned early when `buffer is null`, dropping the record. Its own comment said "or sends it directly when no buffer exists". Every adapter would still read, every log line would still appear, and the domain would simply never hear anything — a silent total regression against the committed behaviour | Comparing the rewritten publisher against `HEAD` |
| **45** | **The derived capacity was one record short of the span it claimed.** `ceil(seconds × rate)` records span `n-1` intervals, so a buffer sized for 24 h retained **23:59:40**. "At least 24 hours" is the requirement and the measured span is what the statistics report, so the count gave way | A test that filled a buffer and measured it, rather than reading the expression |
| **46** | **A full-backlog drain held live controller state off the wire.** The drain ran on the state loop, so a gateway returning from a long outage would stop publishing permissives until the backlog cleared — the cell would read as not permissive because the buffer was busy rather than because the controller said so. The drain is now its own loop | Reading the loop with the 345 601-record case in mind |

Also fixed from the WIP's own list: the byte bound was validated at startup and **not
enforced at run time**, so a deployment whose readings exceeded the nominal 256-byte
allowance would pass validation and then grow past its disk allowance during the outage the
buffer exists for. It is now enforced on admission, telemetry giving way first and critical
events never evicted for space.

**Verified on two live services**, raised from the controlled compose model on PostgreSQL
with the in-process simulated telemetry source **off**. `npm run buffer:verify`, twenty
checks:

| Observation |
|---|
| the gateway states a capacity **derived** from the floor and the feed rate — `345601 telemetry records = 24 h at 4/s` — so no second number can disagree with the requirement |
| 11 samples reached PostgreSQL over the edge before the outage, with nothing else writing |
| with Control Core stopped, the gateway **held 8 records on disk** and backed off |
| the back-off **bound was observed to grow** across six distinct values, not merely to exist |
| **the gateway container was replaced mid-outage** and the new one resumed 9 records it had not written |
| the buffer kept growing across the restart, to 17 records |
| the buffer holds **only** `Telemetry` and `ControllerEvent`, and **0** commands |
| once the link returned the buffer **drained completely** |
| 133 samples arrived, covering the 17 records held at the buffer's fullest |
| **0 inversions**: every sample stored in the order it was taken |
| **0 duplicated readings** |
| 2 controller transitions reached the audit chain, stamped when observed rather than when delivered |
| the audit chain still verifies with a whole outage replayed into it |
| **0** commands executing or committed anywhere across the sequence |

**Attacking the gate found a weakness in the gate, which is the point of doing it.** Five
attacks, each reverted afterwards:

| Attack | Result |
|---|---|
| Eviction stops respecting the record class | Two .NET tests fail; critical events are taken by telemetry pressure |
| The controlled retention floor lowered to 6 h | The startup refusal and the derived capacity both fail, by name |
| The jitter removed from the reconnect policy | The full-range jitter test fails on 1 distinct delay in 400 draws |
| **The drain removes records before Control Core answers** | The gate fails — but **not** on the no-loss check, which went vacuous: the attack emptied the buffer during the outage, so the "held at its fullest" bound became zero and `arrived >= 0` passed on nothing. The check now takes the largest count seen during the outage and **fails outright on a zero bound**. What caught the attack is the direct detector — the buffer holding fewer records than the restarted container resumed |
| **Duplicate suppression removed from the ingress** | **The whole suite stayed green.** The first test exercised `CellRuntimeProjection.RegisterMessage` directly, so it proved the mechanism and not the call site — the same failure mode the CH1-COM-IF-0003 probes had. A second test now drives `EdgeIngressService.PublishTelemetryAsync` twice and asserts **one row in the store**; with the call removed it fails |

**What is not verified, stated plainly.** The gate does **not** run a 24-hour outage in real
time, and does **not** fill a buffer at the full 4 records/s (345 601 records with a
per-commit `fsync` is roughly thirteen minutes on this workstation). The 24-hour retained
span is measured in `Cinerion.EdgeLink.Tests`, through the same admission path, at one
record per twenty seconds — which is close to what this gateway really produces, since
telemetry is enqueued as one batched publication per device every five seconds rather than
one record per reading. **`Microsoft.Data.Sqlite` on the musl runtime image is now verified**
rather than assumed: the gate's gateway is the Alpine runtime image and it opened its buffer.

**A design decision worth keeping.** A controller **state report** is never buffered, and
that is load-bearing: it is a statement about *now*, and replaying an hour-old one would
present a stale permissive as current, which CH1-SAF-FR-0003 forbids. A new
`PublishControllerEvent` RPC carries the critical half — a transition, with both sides of it
— which is buffered, is never evicted for telemetry, changes no cell state and is safe to
accept late. Without it, a guard that opened and closed during an outage would leave no
trace anywhere.

### Controlled verification cases are now bound, counted and enforced

Implementation had run well ahead of its evidence, and nothing measured the gap.
`traceability/implementation-map.json` had machine-checked the *requirement* half of
CH1-VVT-VMP-0001 since Prototype 1, but the *case* half was unchecked: no artefact said
how many of the 87 controlled cases in `data/tests.json` had an executable form, and
nothing failed when a case had none.

`traceability/verification-map.json` now binds each of the 87 to the tests offered as
evidence for it, with an honest status and a note saying what is exercised and what is
not. The binding is reconciled against reality in two ways, neither of which trusts the
map:

| Half | Mechanism |
|---|---|
| .NET | `[VerificationCase("CH1-VVT-TC-nnnn")]` on the test method, read back **by reflection over the loaded types** in `VerificationBindingTests`, one per assembly. A case cannot be claimed for a test that was renamed, deleted or never written; and a case the map assigns to an assembly fails if no test there carries it |
| state model, firmware, policy and baseline gates | each prints the cases it covers **only after its own checks have held**, and `scripts/check-verification.mjs` reads those lines from an actual run |

Measured state, from the gate rather than from an estimate:

| Status | Cases | Meaning |
|---|---|---|
| `automated` | **22** | every result the case states is exercised here |
| `partially_automated` | **46** | part is exercised; the note says which part is not, and why |
| `hardware_gated` | 6 | 0022, 0073, 0123, 0131–0133 |
| `not_executed` | 7 | 0065, 0071, 0080, 0090–0093 — **0093 has since been closed; see its section above** |
| `future_controlled_phase` | 3 | 0128–0130, the document vault |

**66 of 87 cases now have executable evidence.** Every attack on the gate was tried and
caught: a map binding a case no harness announces, a harness announcing a case the map
does not bind, a paraphrased expected result, a quietly dropped case, `automated` with
nothing behind it, and — on the .NET side — a test claiming a case the map does not
assign to its assembly and a map assigning a case no test carries.

Two new firmware assertions were written to make bindings real rather than dropped:
that nothing but the wired button can supply the confirmation edge (CH1-VVT-TC-0014),
and that a credential proof naming another command, or one that was not
cryptographically verified, is refused (CH1-VVT-TC-0005).

### Every implemented controlled operation now has an HTTP-level test

The gate above measured the endpoint layer as the largest hole: 9 implemented operations
had no HTTP test at all. All nine are now exercised, and the four gated document-vault
operations have a test that they *stay* gated — a stub that quietly began answering 200
would otherwise have passed every other gate in the repository.

| Operation | What is now exercised |
|---|---|
| `POST /auth/totp/enrolments` | the seed disclosed once with its RFC 6238 parameters, a second enrolment refused while the first is live, enrolment for another identity refused without an administrator, and no step-up meaning no enrolment |
| `POST /auth/passkey/options` | a challenge bound to the configured relying party and origin, `userVerification: required`, the enrolled handle offered, an identity with no passkey told so, and a caller naming its own relying party or origin refused |
| `POST /auth/passkey/verify` | **a genuine assertion** — a real P-256 signature over real authenticator data — yielding a phishing-resistant grant; an assertion produced for a look-alike origin refused; the challenge single use |
| `POST /credentials` | role checked before the step-up is spent, the grant surviving a refusal, and a projection carrying no key, seed or secret |
| `DELETE /credentials/{id}` | revocation naming who, when and why, and stating plainly that the reader denylist was not reached |
| `POST /commands/{id}/cancel` | idempotent cancel keeping the reason it recorded first, a reason required, and refusal to anyone but the requester or an Engineer |
| `GET /parts/{id}/genealogy` | the assembled evidence graph — order, revision, operator, every measurement with its run — naming the store it came from, and indistinguishable from absent outside the project |
| `POST /release-records` | independent release end to end against a part that reached Accepted through the controlled path, with every refusal on the way |
| `POST /audit/chain-verifications` | the tamper-detection answer: reachable, deterministic for an unchanged chain, and only by the two roles the catalogue names |

Five controlled cases moved to `automated` as a result — independent part release
(CH1-VVT-TC-0044), audit tamper detection (CH1-VVT-TC-0051), part genealogy
(CH1-VVT-TC-0031), traceability to the physical part (CH1-VVT-TC-0050) and confirmation
arming (CH1-VVT-TC-0013). **26 of the 87 controlled cases are now fully exercised, up
from 22.**

Writing them found three more pre-existing defects, 30 to 32 below. That is the pattern
this repository has followed without exception: **anything that had never actually been
executed was broken.**

### Portal contracts checked against what the service actually sends

The portal declares every response shape it reads in
`apps/operator-portal/src/api/contracts.ts`, and **nothing reconciled that declaration
with the service**. A property named wrongly there typechecks perfectly and renders
`undefined` at runtime. That is not hypothetical: it happened twice while the work-order
and device screens were written, most recently an alarm field declared as `code` that the
service sends as `alarmCode`. Both were caught by comparing against a running service by
hand — which is exactly the kind of check that should not depend on remembering to do it.

Two pieces, in the pattern this repository already uses for verification bindings:

| Piece | What it does |
|---|---|
| `PortalContractFixtureTests` | issues a **real request** through the test host for each shape and writes the response to `artifacts/contracts/<Interface>.json`. A fixture somebody typed would be a second declaration to keep in step, not evidence about the first |
| `scripts/check-portal-contracts.mjs` | parses the declaration and fails when a declared property is absent from the response the service actually sent |

**Nested shapes are compared, deliberately.** The defect that prompted the gate was inside
an inline object type, so a check comparing only top-level properties would have passed
over the very thing it exists to catch. Proven by putting the original defect back:
`DeviceRevocation.alarm.code is declared by the portal but absent from the response the
service sent.`

**It then found a second error immediately** — in contract code written in this same
session. `DeviceRevocation.device` was declared as `DeviceRecord & { … }`, but the two
operations project the same entity differently: the read adds `lastSeenQuality`, the
revocation adds the author, reason and capability manifest instead. The intersection
therefore declared `lastSeenQuality` on a response that does not carry it. Now
`RevokedDeviceRecord` describes what the revocation actually returns.

The reverse direction is reported rather than failed, because CH1-SWA-API-0001 makes
unknown optional fields safe to ignore: a response key the portal has not declared is a
field it chooses not to read. The gate prints those.

### All 38 remaining shapes captured, and the gate made complete

The first pass compared 13 of 39 declared shapes; the other 26 were **compared against
nothing and reported as reconciled**, which is the same failure the gate was built to
remove, one level up. All of them are now captured from a real request, and the gate
fails when one is not.

The 26 were not a matter of adding more `GET`s. Most of the shapes exist only after
something has happened, so each is now produced through the ordinary path:

| Shape | What had to happen first |
|---|---|
| `QualityMeasurement`, `PartRecord`, `PartGenealogy` | the part driven through the whole controlled path — failing mandatory result, nonconformity, passing retest, closing disposition, independent release against a redeemed `PartRelease` grant — so the measurement array and the release are populated rather than empty and null |
| `TelemetrySample`, `TelemetryChannel` | a reading stated through `MonitoringService.IngestAsync`, the path a gateway uses |
| `AlarmRecord`, `AlarmAcknowledgement` | **a real breach**: 96 °C through the same ingestion path, then the acknowledgement that does not clear it |
| `ContextThreadSummary`, `ContextMessage`, `PostedContextMessage`, `ContextThreadPage` | a message posted on that alarm's own thread, at the identifier the alarm itself reports |
| `MessageReadReceipt`, `ContextMessageReceipt` | a receipt from **a second actor** — an author cannot receipt their own message, so one identity could not produce this shape at all |
| `ReservationReceipt`, `ResourceAllocation`, `ResourceAvailability`, `ResourcePage` | 200 m of film stock held against a work order, behind a step-up grant and an `If-Match` |
| `CapacityConflict` | capacity withdrawn to 150 m **under that live holding**, because a reservation refuses to over-commit and an interval can only become conflicted after the fact |
| `CredentialSummary`, `PasskeyOptions`, `PasskeyGrant`, `TotpEnrolment` | a credential enrolled, a challenge issued, and **a genuine P-256 assertion** signed over it |
| `RevokedDeviceRecord`, `CellInterlocks`, `ProductRevisionSummary`, `BomLine`, `RouteStep`, and the rest | captured from within the response that carries them, by path, rather than by a second request that might project differently |

Four things changed in the gate itself, each proven by attacking it:

| Change | Attack that proved it |
|---|---|
| **An uncaptured shape now fails** rather than printing a note | deleted `CapacityConflict.json` → `Declared by the portal with no captured response: CapacityConflict` |
| **A property inside an array of inline objects is compared.** `readonly allowCredentials: readonly { … }[]` describes the element, and comparing the array itself passed over every member | renamed `PasskeyOptions.allowCredentials[].label` → `PasskeyOptions.allowCredentials[0].labelText is declared by the portal but absent` |
| **A fixture that is not a JSON object is refused**, because a `null` would be compared against nothing and reported as matching | wrote `null` into `AlarmRecord.json` → `is not a JSON object, so nothing about AlarmRecord can be compared against it` |
| The original defect still fails | `DeviceRevocation.alarm.alarmCode` → `code` → caught, as before |

**The one exemption is declared in the contract source, not in the gate.**
`PortalTokenClaims` is issued by FortressGate, not Control Core, so there is no response
to capture. It carries a `@noCapturedResponse` marker with the reason beside the
interface, and both the script and `PortalContractFixtureTests` read that one statement —
two exemption lists would drift. Removing the marker fails both:
`Declared by the portal with no captured response: PortalTokenClaims`.

**The .NET side enforces completeness too**, by reading the portal's own declaration
rather than a count: `Ch1NfrMnt0001_EveryDeclaredPortalShapeIsCapturedFromARealResponse`
parses `contracts.ts`, and a new interface added to the portal without a capture fails
`dotnet test`. The previous guard asserted `written.Length >= 13`, which a new
undocumented shape would have passed.

**It found one thing immediately**, which is the argument for capturing all of them:
`QualityMeasurement` did not declare `testRunId`, though the service has always sent it.
CH1-MFG-FR-0002 requires a part to resolve to its *tests*, and the genealogy screen —
whose whole subject is that evidence graph — showed the characteristic, value, limits,
device and calibration record of each measurement but not the controlled run it belonged
to. Now declared and rendered. A second report is left as a report: `GET /cells/{id}/state`
also carries the cell's registered `name`, which only `SiteCell` declares; the portal
chooses not to read it on the single-cell page, which CH1-SWA-API-0001 permits.

### Three more screens: CH1-UX-SCR-0003, CH1-UX-SCR-0001 and CH1-UX-SCR-0009

Screen coverage moves from 14 to **17 of 22**, measured by `npm run screens`.

**CH1-UX-SCR-0003, project portfolio.** The stored governance record from
`GET /api/v1/projects` — code, name, baseline, revision, when it was established — and
`POST /api/v1/projects`, which had **no portal surface at all** and is the only
controlled operation that establishes a workspace. The identifier is not a field: Control
Core takes it from the caller's own `ch1_project` scope, so a Project Manager cannot
establish a workspace under an identifier they were not issued, and the form has nowhere
to put one.

The "gate summary" the register asks for is where this screen had to be careful. The
controlled gates G0–G9 are a programme artefact and **the catalogue has no operation that
reports one**, so a green row would be a claim with nothing behind it on the very screen
a reader would use to judge whether a project may proceed. Four things controlled reads
actually support are shown instead — workspace established, baseline agreement between
the project record and the running service, execution authority from the runtime profile,
and whether requests are being authorised by a verified token or by development headers —
and the gates are named as absent rather than drawn as pending.

Verified against a running Control Core:

| Behaviour | Observation |
|---|---|
| The record is read, not projected | `GET /projects` as a Viewer → `200` with `CH1` / `P03/IFV`, from `ch1.projects` |
| Establishing without the role | Engineer → `403 AUTH_PROJECT_MANAGER_REQUIRED` |
| Establishing twice | Project Manager → `400 PROJECT_ALREADY_ESTABLISHED`, "configuration changes are revisioned, not recreated" |
| A scope with no record | stated as an authorisation the provider issued against a controlled act nobody performed — every read succeeds and returns nothing until it is |

**CH1-UX-SCR-0001, session and authentication.** What the browser is holding, what it
proves, and what it does not: subject, session, project and cell scope, roles, when the
identity authenticated and when the token expires — all decoded for display and scoping
only, never verified here.

It closes a real gap. **`signOut` dropped the in-memory token and nothing else**, so the
session at FortressGate stayed live and a fresh sign-in resumed it without anybody
re-authenticating — which on a shared workstation is the whole difference between leaving
and being logged out. `DELETE /api/v1/auth/sessions/{sessionId}` is now offered beside it,
the two controls are labelled for what they each do, and the token in the tab is dropped
**only after** the server confirms the session is gone: dropping it first would leave a
live session nobody could see any more.

The screen also states what the token cannot prove. An OIDC session reaches `Mfa` at most,
the realm emits no `amr` or `acr`, so *which* authenticators were presented is reported as
not known rather than shown as a padlock — a hardcoded claim there would be a stored
permanent assertion of strength, which the policy gate refuses outright. Recovery is
named as FortressGate's: the portal never handles a password, and a lost authenticator is
a controlled ceremony, not a self-service reset.

Verified against a running Control Core:

| Behaviour | Observation |
|---|---|
| Ending somebody else's session as a Viewer | `403 AUTH_SESSION_REVOCATION` |
| Ending one's own with no provider configured | `400 IDENTITY_PROVIDER_NOT_CONFIGURED` — surfaced as a refusal, never as a success |
| Ending one's own with a provider present | `200`, `ownSession: true`, `revokedBy` the caller, audited as `SessionRevoked` / `SELF_REVOCATION` |

That last row needed a test host with a directory in it. The ordinary one deliberately has
none — an unconfigured directory must refuse rather than answer a security question with
invented data — with the consequence that **the success path of this operation had never
been executed by any test at all**; the live-Keycloak evidence for it was produced by hand.
A stub directory is now registered for one host only, replacing the provider and nothing
else: authority, self-versus-administrator ownership, the project-bounded lookup and the
audit event are all the real ones.

**CH1-UX-SCR-0009, automatic procedure progress.** The controlled sequence the part on the
cell is being made to, with hold points marked — a route step requiring mandatory
inspection is the hold point CH1-AUT-FDS-0001 describes. Read-only in the strict sense:
the screen has no control of any kind.

**There is deliberately no step pointer.** No controlled operation reports which step a
controller is executing; the cell reports its own state and the part reports its evidence,
and neither is a position in a sequence. A highlighted "current step" would be a guess
rendered as fact on the screen a Local Confirmer would use to decide whether a hold has
been reached, so the gap is stated instead — along with the fact that a measurement records
a characteristic and is not associated with a route step by the controlled record, which is
why acceptance evidence sits beside the sequence rather than inside it.

The resolution chain the screen depends on was checked against captured real responses
rather than assumed: cell `…106` → genealogy part `…106` → revision `…109` → the revision
in `GET /products` with 2 route steps, 1 hold point, and 2 mandatory measurements on the
part. **Building it found the seventeenth conflict**, recorded below: the Local Confirmer,
one of the two roles the screen is declared for, is refused the genealogy.

### The PLC command handshake, executed — and two defects it had been hiding

`plc/s7-1200-g2/` held detailed Structured Text for the command guard and the procedure,
and a table of eleven PLCSIM scenarios whose own header said results "remain **not
executed** until a controlled TIA Portal/PLCSIM environment records them". That
environment is a procurement gate — CPU order code, TIA version, OPC UA licence — so the
handshake CH1-AUT-FDS-0001 specifies **had never been run in any form**.

`plc/host-model/` is now a faithful translation of that SCL: the same state numbers, the
same reason codes, the same order of evaluation, scan by scan. `plc/tests/` executes every
scenario against it, and `scripts/check-plc-model.mjs` (`npm run plc`) holds the model, the
SCL and the scenario table in step. It does **not** replace PLCSIM, and says so: the
eventual evidence still needs the CPU, the TIA version and the block hashes.

**Running the scenarios found two defects that inspection had not**, both in the
controlled source, both of the same shape — a state machine with no way out of a state:

37. **The execute permit, once granted, never cleared.** `FB_CH1_CommandGuard` declared
    states `30 Executing`, `40 Complete` and `90 FaultLatched` on its `State` output and
    **assigned none of them**. After a local commit the block sat at `20` for as long as
    the CPU ran: nothing returned it to Idle, so `ExecutePermit := (State = 20) OR
    (State = 30)` stayed TRUE permanently. A permit that never clears is a standing
    authorisation to move, which is the one thing the whole handshake exists to prevent —
    a second procedure could start with no prepare, no commit and no button edge. The
    guard now takes `ProcedureRunning`/`ProcedureComplete` from `FB_CH1_Procedure`,
    advances 20 → 30 → Idle, reports `140 EXECUTION_FINISHED`, and **withdraws the permit
    immediately as `310 EXECUTION_PERMISSIVE_LOST` if a permissive drops mid-execution** —
    which the original could not do at all.
38. **A latched fault could never be cleared.** `FB_CH1_Procedure` set `FaultLatched` on a
    watchdog drop, stop request or lost permissive, and had **no reset input and no path
    that cleared it**. One watchdog dip left the block permanently dead, and
    CH1-AUT-FDS-0001's recovery — "cause removed, local authority, reset edge and
    reconciled state" — could not be performed. A `LocalResetRequest` edge now clears the
    latch, and only with all four conditions met; the reset returns the block to step 0
    with the actuator off, so **a reset never commands motion** and an execute permit
    would still have to arrive through the whole handshake again.

Both fixes were made in the controlled SCL and in the model together, and both are held by
scenarios that fail without them.

**All eleven controlled scenarios now execute**, plus the two the table did not contain
because the source could not have satisfied them:

| Scenario | Observation |
|---|---|
| Valid semantic prepare | state 10, prepared acknowledgement, and **no execution output** — preparation is not authorisation |
| Direct register or start attempt | no transition to execution; the commit is refused `301 NOT_PREPARED` |
| Duplicate sequence | `203`, no output |
| Expired prepare | `204` |
| Revision mismatch | `205` |
| Controller reboot while prepared | cancelled to Idle as `110`, no restart, no surviving permit |
| Wrong commit binding | `302`, no permit |
| Permissive dropped between prepare and commit | `305`, cancelled, outputs off |
| Communication loss | no queued start, and **no automatic continuation** when the session returns |
| Watchdog failure | actuator off, fault latched `901`; the cause returning is **not enough** — a local reset edge is required, and it commands no motion |
| Acknowledge-only traffic | twenty scans of broker acknowledgement with no local commit produce no permit |
| **Execute permit is not permanent** | 20 → 30 → Idle, permit clears, reported `140` |
| **Permissive lost during execution** | permit withdrawn immediately, reported `310` |

The gate was attacked three ways and refuses each: a reason code in the SCL the model does
not define, a state the guard documents but never assigns (which is defect 37 exactly), and
a scenario function defined but never called.

CH1-VVT-TC-0011, 0016 and 0017 now have their PLC half exercised alongside the domain,
state-model and firmware halves. All three stay `partially_automated`: PLCSIM evidence
against the real CPU is required and outstanding.

### The ESP32-S3 firmware, and a wire format two implementations agree on

CH1-COM-IF-0005 carries the CH1 envelope in CBOR to an ESP32-S3, and CH1-COM-IF-0006
carries framed binary over RS-485 from there to the Arduino I/O node. The firmware was a
skeleton: a cell state machine, a frame codec, and an `app_main` that ticked the machine
and did nothing else. It spoke neither controlled interface.

It now speaks both, and the interesting part is how that is checked without hardware.

| Piece | What it is |
|---|---|
| `firmware/shared/src/cbor.cpp` | canonical CBOR for the device — definite lengths only, shortest heads, shortest exact float form. No allocation anywhere: a controller that could fail to allocate while encoding a heartbeat would fail exactly when its state most needs reporting |
| `firmware/shared/src/ch1_envelope.cpp` | the controlled envelope, written against CH1-COM-ICD-0001 rather than against the gateway's code. Encodes telemetry, acknowledgements and heartbeats; decodes and validates a command |
| `firmware/tests/ch1_envelope_test.cpp` | the host test, built and run by `verify.sh` step `[9/14]` |
| `firmware/esp32/main/app_main.cpp` | the controller: heartbeat, command handling, the RS-485 edge, and the safety position unchanged |

**The two implementations are pinned to one literal.** The .NET test asserts the canonical
encoding of a stated reference message; the firmware's host test asserts the same literal
from the other side. Either drifting fails one of the two, and the bytes are the only
honest form of that statement.

**It found two encoding faults before any hardware existed**, both of which would have had
the gateway reject every message the firmware sent, and neither visible by reading it:

1. **Canonical map keys sort by length first, then bytewise** — so `type` precedes
   `cellId`. The encoder emitted them alphabetically, which is legal CBOR and refused by a
   canonical reader.
2. **Canonical floats take the shortest exact form** — 22.5 °C is a *half*, not a double.
   The encoder always emitted 64-bit doubles.

Both would have surfaced for the first time with a real controller in front of a real
broker, which is precisely the moment they are most expensive.

What the firmware refuses is the rest of it, and every refusal is exercised by the host
test:

| Behaviour | Observation |
|---|---|
| A command naming another cell | `COMMAND_OUT_OF_SCOPE` — the topic ACL and this check are independent boundaries, and neither assumes the other |
| **A controller with no disciplined clock** | `CONTROLLER_TIME_NOT_TRUSTED`. Commands expire and are never replayed, so accepting one whose expiry cannot be judged would remove the only bound on how long an intent lives. SNTP is not provisioned at this checkpoint, so the command path is closed — and says so once at boot rather than refusing silently |
| A command past its expiry | `COMMAND_EXPIRED`, from the same envelope that was accepted before it |
| `write:40001` as a command type | `SEMANTIC_COMMAND_INVALID` — a register address is not a semantic name |
| Any truncation of a valid envelope | none decodes as a valid command |
| A message that does not fit its buffer | refused, never truncated |

The safety position is unchanged and still enforced by the policy gate: no GPIO is
configured as an actuator output, the controller acknowledges a prepared intent as
`AwaitingCredential` and never reports an execution, and a valid RS-485 frame reports
local input state and can never be a command. Telemetry is **not** published, because
there is nothing to sample until the conditioned I/O driver exists — an invented number
would be indistinguishable from a measurement.

CH1-VVT-TC-0023 now has its MQTT/CBOR half exercised alongside its serial half, announced
by the host binary only after every assertion above holds.

### CH1-VVT-TC-0080 closed on the service side: the demonstration executed with no public internet

CH1-OPS-FR-0001 is a **Must** verified by *Test* — "Principal workflows shall operate on the
local network without a public-internet dependency" — and the verification map recorded the
position honestly and uncomfortably: *"The whole stack runs on an internal Compose network
with no public egress ... Nothing executable asserts the absence of a public-internet
dependency, so the case has no evidence."* Believing a deployment is offline because its
networks are declared `internal: true` is exactly the kind of claim this repository refuses
everywhere else.

`scripts/check-offline-workflow.sh` (`npm run offline:verify`) executes it instead:

| Step | Observation |
|---|---|
| A network created with `--internal` | **proven** unable to reach a public host before anything else runs: `curl: (6) Could not resolve host: example.com` |
| PostgreSQL and Control Core raised on that network **alone** | no published port, no default bridge, every controlled migration applied, PostgreSQL as the store |
| The controlled quality path, driven from a third container on the same network | test run, failing mandatory 8.2 µm against a 9.5–10.5 limit, nonconformity raised, passing 10.1 µm retest recorded beside the failure it supersedes |
| The evidence graph | genealogy assembled with 2 measurements including the superseded failure, and the provenance the service states rather than one the client composed |
| Live state | the cell reports its state hash and interlocks; bounded telemetry queryable, fed by the in-process simulated source |
| Integrity | the audit chain verifies offline: 5 events, hash-linked and valid |
| Still isolated | the egress probe is run **again after** the demonstration and still cannot resolve a public host |
| Configuration | every controlled `CINERION_*`/`EXPO_PUBLIC_*` endpoint setting names a loopback address, a private range or a Compose service |

**The egress probe runs twice, and that is the load-bearing part.** Without it the gate could
pass for two independent reasons — the workflow genuinely needing no internet, or the network
never having been isolated — and only one of those is evidence. Running it before and after
means a pass cannot come from the second.

**The case moves from `not_executed` to `partially_automated`, not to `automated`**, and the
note says why: the browser interface is not driven here, because there is no automated
interface harness in this repository at all. The portal's offline behaviour still rests on
the argument it always did — a static bundle served locally whose only outbound dependencies
are the local API and the local identity provider. Claiming the case outright would overstate
what was run.

Six controlled cases now remain `not_executed`, down from seven.

### Telemetry retention, downsampling and authorised disposal — CH1-DBA-DD-0001

CH1-DBA-DD-0001 states this subsystem in four sentences, and **none of it was implemented**:
raw samples accumulated forever, the entity register's `TelemetrySample` retention of
"Configurable; summary permanent" had no summary behind it, and migration `0001` carried the
intent in a comment beside the immutability triggers — *"Retention is a separate controlled
administrative process with independent evidence"* — that nothing acted on.

Migration `0010` adds four things, and the order of the argument matters more than the order
of the code.

| Piece | What it is |
|---|---|
| `ch1.telemetry_summaries` | The permanent half of "configurable; summary permanent": an immutable hourly aggregate per project, cell, device and channel — count, minimum, maximum, average, first and last sample time, and the **worst** quality and freshness in the bucket |
| `ch1.telemetry_disposals` | The "authorised, logged" half. Who, why, what window, what cutoff, and what it did — counted, not estimated. Append-only |
| `cinerion_retention` | A separate role that may `DELETE` from exactly one table and read the rest. `NOSUPERUSER`, `NOBYPASSRLS`, project-scoped like everything else |
| `ch1.dispose_telemetry(...)` | `SECURITY INVOKER`, stated rather than defaulted, so "this procedure cannot delete an alarm" is a fact about the grants rather than a promise about the SQL |

**Disposal is an administrative act and deliberately has no API operation.** The P03
catalogue contains none, the policy gate would fail the build on one invented for it, and
CH1-DBA-DD-0001 makes deletion authorised rather than something a service does to itself.
`scripts/retain-telemetry.sh` is the entry point; it refuses before connecting if the
authoriser or reason is missing, and refuses after connecting if the session is not
`cinerion_retention` or if that role turns out to be a superuser.

**A finding on the way: the application role could delete telemetry, and nothing would have
recorded it.** `0002` granted `cinerion_app` `DELETE` on every table. No code path in Control
Core issues one against `ch1.telemetry_samples`, so it was authority nobody had asked for and
nothing would have logged the use of. `0010` revokes it, which is what turns "deletion is
authorised and logged" from a description of current behaviour into a property of the
database.

**Verified on a real database, against real telemetry**, by `npm run retention:verify`: a
throwaway PostgreSQL, every controlled migration, Control Core with the simulated cell
feeding the **ordinary** ingestion path, and a controlled measurement produced through the
API. Twenty-six checks, all passing:

| Observation |
|---|
| 24 real samples and 1 measurement in the database, written by the service rather than inserted |
| disposal removed **7**, retained **17 as evidence**, and wrote **4 permanent summaries** — and the database agreed with the record: 24 − 7 = 17 |
| **every sample inside the alarm's window survived**, 16 of 16, and so did the sample the acceptance measurement names as its source |
| disposal touched nothing else: the alarm, the measurement and the audit chain all unchanged |
| every summary reports the **worst** freshness in its bucket — `Simulated`, never upgraded to `Live` |
| a summary and a disposal record are both refused an `UPDATE`: `CH1 immutable evidence cannot be updated or deleted` |
| a second run deleted 0 further samples and wrote no duplicate summary |

**Refused, each for its own reason:** a window under the seven-day floor, an unnamed
authoriser, a missing reason, another project, the application role executing the procedure
at all, and the application role deleting telemetry directly. The retention role was then
attacked directly and could delete from none of `ch1.alarms`, `ch1.measurements`,
`ch1.audit_events` or `ch1.release_records`.

**The gate was attacked, and the attack found a weak fixture — which is the point of doing
it.** Removing both evidence protections from the procedure made disposal take 23 samples
instead of 7, and the alarm check failed naming exactly what was lost. But the *measurement*
check still passed: its sample had survived on **age**, not on protection, because a
measurement's `source_sample_time` is "now" and the sample aligned to it was newer than any
cutoff. That check would have passed for the wrong reason indefinitely. The measurement is
now aged with the samples — the clock is moved, not the data, and the immutability trigger is
put back and asserted — and a new assertion requires every protected sample to be older than
the cutoff before disposal runs. With that in place, removing the measurement protection
alone fails the gate: `the acceptance measurement's raw sample was disposed of`.

**One thing this gate deliberately does not do is announce a controlled verification case.**
`data/tests.json` contains none for retention or disposal. Binding this evidence to a case
about something else would be exactly the overstatement the verification map exists to
prevent, so it announces nothing and the gap is recorded as the eighteenth conflict.

**And a restore would have undone it, which is defect 13's shape again.** A role is a
cluster object and its grants are schema objects, so a schema dump carries neither — a
restored database would have had the retention tables and the disposal procedure with no role
permitted to run them, and `cinerion_app`'s blanket `DELETE` on telemetry silently back in
force, because a `REVOKE` is a grant decision the dump does not hold either. The role, its
grants and the revoke are therefore in their own migration `0011`, exactly as `cinerion_app`
is separate from the foundation schema in `0002`, and `scripts/restore.sh` re-asserts both
after every restore. It now also refuses to report success if either role comes back able to
bypass row-level security, or if `cinerion_app` comes back holding `DELETE` on
`ch1.telemetry_samples`. Re-verified: `npm run backup:verify` restores into a database that
held 0 controlled tables and now holds 35, and still closes CH1-VVT-TC-0081.

Partition management is left as it was, and the reason is worth stating: disposal is
row-precise because it has to be. A dropped partition would take an alarm's evidence with it,
so per-period partitions remain a performance measure rather than the disposal mechanism. The
CH1-NFR-REL-0001 24-hour gateway buffer is a property of EdgeLink, not of this database, and
is untouched.

### The Modbus edge, live — CH1-VVT-TC-0022 closed on all three protocols it names

CH1-COM-IF-0008 puts Modbus TCP/RTU between EdgeLink and a controlled register map, and
CH1-COM-FR-0003 makes MQTT 5, OPC UA **and Modbus TCP/RTU** first-class interfaces, all
three as a **Must**. Modbus was the last one refusing.

It is a different kind of problem from the other two, and the controlled documents say so
precisely. **Modbus authenticates nothing and encrypts nothing** — there is no certificate,
no identity, no session. CH1-COM-ICD-0001 therefore terminates it "at EdgeLink or a
controlled PLC zone with allowlisted mappings and no general routing", CH1-COM-PRO-0001
requires the map to separate "read-only telemetry, configuration and command handshake" with
"arbitrary function codes and address ranges denied", and CH1-CYB-TMD-0001 names **"direct
Modbus write bypassing CommandGuard"** as a priority threat case. So the security of this
edge *is* the map, and the map is what was built and attacked.

| Piece | What it is |
|---|---|
| `Ch1ModbusMap` | The controlled map, in **two copies** — the gateway's and the controller's. Four bands: read-only telemetry, the guard's answer, read-only configuration, and one writable handshake window |
| `Ch1ModbusAllowlist` | Deny by default, on every request, before any register is touched. Three function codes and four address ranges; everything else is `ILLEGAL_FUNCTION` or `ILLEGAL_DATA_ADDRESS` |
| `ModbusTcpClient` | The gateway's master, **written by hand**: MBAP framing, three function codes, no arbitrary-function path, and not reachable by the domain |
| `simulators/modbus-plc/` | The controlled zone stand-in, on an **independent third-party Modbus implementation**, so the two ends share no code and agreement between them is evidence about the wire format |
| `Ch1ModbusProbe` (`--probe`) | A byte-level attack client that sends requests no well-behaved library would construct |
| `scripts/check-modbus-map.mjs` / `check-modbus-edge.sh` | `npm run modbus:map` and `npm run modbus:verify` |

**The answer to the named threat is structural, not procedural.** The guard's state, its
reason code and above all its **execute permit are input registers** — and Modbus has no
function code that writes an input register. A client cannot be refused the attempt; there
is no request that could carry it. `PROBE-07` tries every write function the protocol
defines at the permit's address and reports what each was refused with.

**One guard, two profiles.** `Ch1PlcRuntime` moved into `simulators/plc-guard/` and is now
reached by both the OPC UA controller and the Modbus zone, so a refusal reported over one is
the same refusal reported over the other — which is what CH1-VVT-TC-0022 means by consistent
semantics. `npm run plc` still reconciles it against the controlled SCL, and one thing had
to be fixed to keep that honest: the "unknown command type" refusal was borrowing the SCL's
`201 STATE_INVALID`. The SCL has no code for it and should not — in `UDT_CH1_Command` the
command type is an enumerated field that cannot hold an invalid value, so the case exists
only at a text boundary the CPU does not have. Over Modbus **only the number crosses the
wire**, so a profile refusal wearing a controlled reason code would be the whole message.
Profile codes are now ≥ 1000, a range the SCL never uses, and the gate holds them there.

**Verified on a running gateway against all three controller peers at once:**

| Observation |
|---|
| **four operational adapters passed the same nine checks each** — simulator 9, MQTT 5 9, OPC UA 9, Modbus 9 — in one gateway process, and **no adapter is gated any more** |
| the capability model was **read out of the controller's configuration band**: device, type, firmware, configuration revision, supported commands, and each channel's name and unit |
| the **map version was checked before a single field was decoded**, because CH1-COM-ICD-0001 versions Modbus maps like software APIs and a gateway reading the right addresses of the wrong map reports plausible numbers about the wrong things |
| a **semantic command round trip** evaluated by the guard: `AwaitingCredential` / `PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION`, never `Complete` |
| all three telemetry channels delivered a reading, united and marked `Simulated`, never `Good` |
| the same two deferred checks the OPC UA profile reports, carried as codes 206 and 207 |

**The map was attacked, and refuses.** Eleven probes against a fresh zone:

| Attack | Result |
|---|---|
| Reading an address one past the configuration band | `ILLEGAL_DATA_ADDRESS` |
| **A read starting inside a band and running off its end** | `ILLEGAL_DATA_ADDRESS` — a range check applied only to the first address is the usual way an allowlist leaks |
| Read coils (function 1) | `ILLEGAL_FUNCTION` |
| Read file record (function 20) | `ILLEGAL_FUNCTION` |
| **Every write function aimed at the execute permit** | write single register, write multiple registers, write single coil and mask write — all refused, and the permit still reads 0 |
| Writing the map version the gateway trusts | `ILLEGAL_DATA_ADDRESS`, and it still reads 1 |
| Writing the device identity the gateway reports | `ILLEGAL_DATA_ADDRESS` |
| A foreign unit identifier | not answered at all |
| The one declared writable window | accepted, so the refusals above are about scope rather than a dead device |

**Attacking the gate separated the two controls, which is the useful part.** With the
allowlist neutered to `return ModbusExceptionCode.OK`, six probes failed — the arbitrary
function code, both address-range probes, and all three write refusals. But `PROBE-07` still
reported **"the permit still reads 0"**: with every write accepted, the writes landed in
*holding* register 19, because the permit is input register 19 and the two are different
address spaces. The allowlist and the register-file placement are genuinely independent
defences, and the attack is what showed which of them each probe measures.

Moving a guard output into the writable file is caught separately: `npm run modbus:map`
fails with `AnswerExecutePermit is outside the input-register answer band, so a write
function could reach it`, proven by doing it.

**Two things cost real time here too.** A register written as a host-order `short` published
a map version of **256** for a value of 1 — the library copies its buffer straight to the
wire, so the buffers are now addressed as bytes and written big-endian. And Modbus caps a
single read at **125 registers** while the configuration band is 140 long, so the master
splits it; a master that assumed one request would have read a short band and decoded the
rest as zeros.

**CH1-VVT-TC-0022 is closed.** All three protocols it names are exercised simultaneously on
one gateway. What remains outstanding on this subject is hardware — the real S7-1200 G2 CPU,
its order code, TIA version, block hashes and a witnessed PLCSIM run — not protocol coverage.

### The OPC UA edge, live: EdgeLink's third operational adapter — and the PLC handshake reachable over the interface that carries it

CH1-COM-IF-0007 puts OPC UA with "SignAndEncrypt + certificates" between EdgeLink and the
PLC, and CH1-COM-IF-0022 puts "OPC UA SignAndEncrypt or zoned allowlist; no raw UI writes"
between EdgeLink and the Siemens S7-1200 G2 CPU, carrying "a versioned PLC semantic
handshake and capability model". **Neither had any implementation at all**: the adapter
refused, and nothing had ever spoken OPC UA in this repository.

Two things now exist, and the second is the interesting one.

| Piece | What it is |
|---|---|
| `simulators/opcua-plc/` | The S7-1200 G2 runtime stand-in: a real OPC UA server built on the OPC Foundation reference stack, publishing the CH1 information model — capability, handshake, telemetry — over one `SignAndEncrypt`/`Basic256Sha256` endpoint with a certificate trust list and no anonymous path |
| `OpcUaProtocolAdapter` | The live adapter. Browses the model, calls the handshake, subscribes to telemetry with monitored items, and is held to the same unchanged `AdapterConformance` suite as the simulator and MQTT |
| `scripts/bootstrap-opcua-pki.sh` | The laboratory CA and the two application instance certificates, each carrying the application URI in a `subjectAltName` because OPC UA checks it |
| `Ch1EndpointProbe` (`--probe`) | A verification client that attacks the endpoint and reports what it could not do |
| `scripts/check-opcua-edge.sh` | The executable verification, `npm run opcua:verify` |

**The stand-in is a third expression of the controlled SCL, not a new invention.**
`plc/s7-1200-g2/01_Blocks/` stays authoritative, `plc/host-model/` is the C++ translation
the eleven PLCSIM scenarios execute against, and `Ch1PlcRuntime` is the prepare branch of
the same `FB_CH1_CommandGuard` — the same state numbers and the same reason codes, in the
SCL's own order of evaluation. `npm run plc` now reconciles **all three**, and both
directions were proven by breaking them: a reason code the stand-in invents
(`defines reason code 250, which the controlled SCL never emits`) and a prepare check it
quietly drops (`can emit 207, and the OPC UA stand-in neither implements it nor names it in
DeferredChecks`).

**Two of the guard's seven prepare checks are declared rather than answered**, and that is
the whole reason the third expression is honest. `EXPECTED_STATE_MISMATCH` (206) compares
the command's expected state hash against `CurrentStateHash32`, which the CPU computes from
its own material state; `PRELIMINARY_PERMISSIVE_INVALID` (207) reads `UDT_CH1_Permissives`
from wired inputs. A stand-in with neither would have to invent both answers — and they are
precisely the two that decide whether equipment may move. So the method returns a
`DeferredChecks` output naming them, on every reply, accepted or refused; the controller
prints them at boot; the gateway repeats them into its own log; and the gate asserts all
three.

**There is no commit and no execute on this interface at all.** The address space exposes
exactly one method, it advances the guard to `Prepared` at most, and nothing an OPC UA
client can say produces an execute permit — CH1-AUT-FDS-0001 puts the commit behind a
cryptographic credential proof and a physical button edge observed at the cell. The probe
asserts the method inventory rather than trusting it: `the handshake exposes Prepare`.

**Verified on a running gateway against a running controller**, both raised from the
controlled compose model:

| Observation |
|---|
| **three operational adapters passed the same nine checks each** — simulator 9, MQTT 5 9, OPC UA 9 — in one gateway process, run by the same code, with no domain or inspection logic differing between them |
| Modbus alone remains gated, and is held to the stricter gated contract on the same gateway: 4 checks |
| the capability model was **browsed out of the controller's address space**, every node reached by *browse path* from the Objects folder rather than by a node identifier the adapter invented — so the same adapter resolves a real CPU, which numbers its nodes differently |
| **read-only is derived, not asserted**: a channel is reported writable or not from the `AccessLevel` attribute the server publishes, so `ADP-03` is evidence about the controller's model |
| **scope is agreed before anything opens**: project, cell and asset are read from what the controller declares about itself, and a gateway configured for another cell refuses and stops rather than opening a command path. Proven by configuring cell `…999` against a controller serving `…103` — the gateway named both and would not serve it |
| a **semantic command round trip**: called over the secure channel, evaluated by the guard, answered `AwaitingCredential` / `PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION` — never `Complete` |
| all three telemetry channels delivered a **monitored-item** sample, each carrying the unit from its own `EngineeringUnits` property and the quality word translated from the server's status code — `Simulated`, never `Good` |

**The transport and the guard were attacked, and refuse.** Twelve probes, each run against a
*fresh* controller before the gateway connects:

| Attack | Result |
|---|---|
| Is an unsecured endpoint offered at all? | `1 endpoint(s), all SignAndEncrypt` |
| Is an anonymous token policy published? | `certificate identities only` |
| An anonymous session | `Endpoint does not support the user identity type provided` |
| **A certificate this authority never signed, carrying the right application URI** | `BadSecurityChecksFailed` — identity is not a URI a client picks |
| The certificate it did sign | accepted, so the refusals above are about trust rather than a broken link |
| **A raw write to a telemetry value** | `BadNotWritable` |
| Any method other than `Prepare` | none exists |
| A wrong configuration revision | `REVISION_MISMATCH` (205) |
| An expired intent | `EXPIRED` (204) |
| An unsupported schema | `SCHEMA_UNSUPPORTED` (202) |
| `write:40001` as a command type | `COMMAND_TYPE_NOT_IN_CAPABILITY_MODEL` |
| **After four refused preparations** | guard still state 0, last sequence still 0 — a refusal leaves nothing behind |

**Every one of those controls was then reverted, and the gate failed on each.** An added
`None` endpoint, an added anonymous token policy, `AutoAcceptUntrustedCertificates = true`
and a telemetry node made `CurrentReadOrWrite` produced exactly four failures —
PROBE-01, -02, -04 and -06 — and the controlled files were restored. The interesting row is
the one that *still passed*: with an anonymous policy published, PROBE-03 reported
`anonymous was refused: BadIdentityTokenRejected`, because `Ch1PlcServer` refuses the token
independently of what the endpoint advertises. Two controls, not one, and the attack showed
which of them each probe is measuring.

**The gate had to be taught to own the controller's state, and the way it failed is the
argument for it.** The controller is a stateful peer: a spent sequence stays spent and a
prepared command stays prepared. A gateway left running from an earlier run reconnected to
the recreated controller, completed its conformance suite against it, and left the guard
`Prepared` at sequence 2000 — so the probe then met a controller refusing everything with
`STATE_INVALID`, for a reason that had nothing to do with what was being tested. Five probes
failed at once and `PROBE-12` named the cause exactly: *state 10, last sequence 2000*. The
gate now removes the gateway before it raises the controller. The controller's behaviour was
never wrong; the gate's assumption about who else was talking to it was.

**Two more things cost real time and are worth writing down.**

1. **`RelativePathElement.IsInverse` initialises to `true`.** A browse path that leaves it
   alone walks the hierarchy *backwards* and answers `BadNoMatch` for a node that is plainly
   there — which reads as "the server does not expose this" rather than "the client asked
   the wrong question". Measured side by side against one running server: the same path with
   `IsInverse = false` resolved, and without it did not.
2. **`DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1` and the OPC UA reference server are
   incompatible.** The server builds its diagnostic resource manager with
   `new CultureInfo("en-US")` before it opens a single endpoint, so under invariant mode it
   throws and the stack reports the useless `BadInternalError 'Unexpected error starting
   application'`. The container restarted forever with no usable diagnosis. Fixed by adding
   ICU and turning invariant mode off in that image only, and by catching the startup
   failure and printing the inner cause — a controller that cannot start should say why.

**A hole in the verification gate itself was found while wiring this in, and closed.**
`opcua-edge` was added to `traceability/verification-map.json` and bound to both cases
*before* it was added to the observation list in `scripts/check-verification.mjs` — and the
gate reported green. A harness declared in the map but never run was unverified evidence
wearing the same clothes as verified evidence, which is the exact failure that gate exists
to remove, one level up. It now fails on any non-`.Tests` harness the map names and the
script does not execute, proven by removing the observation again:
`The verification map declares harness "opcua-edge", which check-verification.mjs never
runs.` The count in its own summary line is what would have given it away — eight of eight,
when the map had just gained a ninth.

**CH1-VVT-TC-0021 stays closed and is now stronger**: three operational adapters answering
one unchanged suite rather than two. **CH1-VVT-TC-0022 remains `partially_automated`, and
deliberately so** — it names MQTT, OPC UA *and* Modbus; two of the three are now exercised
simultaneously on one gateway, and claiming the case while Modbus has no live counterpart
would be exactly the overstatement the verification map exists to prevent.

What is still hardware-gated here is the CPU itself: order code, TIA version, block hashes,
the real OPC UA server the S7 runtime provides, and a witnessed PLCSIM run. The stand-in
says so in its device type (`S7-1200-G2-CPU1212C-STANDIN`), in its firmware string, in the
quality word on every reading, and in the two prepare checks it refuses to answer.

### The MQTT edge, live: EdgeLink's second operational adapter

CH1-COM-IF-0004 and CH1-COM-IF-0005 put MQTT 5 over TLS with per-device certificates and a
topic ACL between EdgeLink, the broker and the ESP32-S3. The broker and its configuration
existed in the controlled compose model; **the adapter refused, and nothing had ever
connected to the broker at all.** The protocol boundary therefore had one operational
implementation behind it, which shows only that the interface was shaped around the one
thing implementing it.

Five pieces now exist:

| Piece | What it is |
|---|---|
| `Ch1MessageEnvelope` | the controlled envelope in **CBOR** - every field CH1-COM-ICD-0001 names, encoded canonically so the same message always produces the same bytes. Unknown optional fields are ignored; a missing mandatory one is refused with a stable code. CBOR because CH1-COM-IF-0005 names it, and the same bytes cross IF-0004 unchanged: a broker is a transport, not a translator |
| `MqttProtocolAdapter` | the live adapter. TLS 1.3, the broker validated against the controlled CA, a client certificate whose subject is the identity the ACL is written against. No anonymous path and no "encryption optional" switch |
| `MqttDeviceSimulator` | the device end - **a separate MQTT client with its own certificate**, so the broker authenticates it as the device and applies the device half of the ACL to it. A shortcut inside the adapter would have tested the gateway against itself |
| `scripts/bootstrap-mqtt-pki.sh` | the laboratory CA, broker, gateway and device certificates. Written to a git-ignored directory, never printed, and every subject carries `OU=P03-IFV-LABORATORY-ONLY` |
| `scripts/check-mqtt-edge.sh` | the executable verification, `npm run mqtt:verify` |

Three things the adapter deliberately does not do. It does not invent a capability
manifest - the manifest arrives on the device's own retained `capability` topic, and an
adapter that has never heard from its device refuses rather than describing one. It does
not treat a published command as an accepted one: it waits for the controller's
acknowledgement and reports a timeout as a refusal, because "the broker took the message"
is not "the controller accepted the intent". And it never replays - expiry and spent
sequences are refused locally, before anything reaches the wire.

**Verified on a running gateway against a live broker**, not asserted from the source.
`docker compose --profile protocol-lab` raised both, and EdgeLink emitted **38 conformance
checks, all passing**:

| Observation |
|---|
| the MQTT adapter passed **the same nine checks as the simulator**, run by the same code, with no domain or inspection logic differing between them |
| the manifest reported `MTLS-DEVICE-CERTIFICATE-TOPIC-ACL` with 3 channels - it came over the wire from the device, not from the adapter |
| **a real command round trip**: published to the broker, received by a separately authenticated client, acknowledged as `PREPARE_ACCEPTED_AWAITING_LOCAL_CONFIRMATION`, correlated back - and `AwaitingCredential`, never `Complete` |
| heartbeats carrying firmware `0.1.0-prototype.2` and configuration `CFG-REFAB-P01-R01`, as CH1-COM-ICD-0001 requires |
| both identities authenticated from their certificate common names over `TLSv1.3 TLS_AES_256_GCM_SHA384` |
| **OPC UA and Modbus are now registered on the running gateway** and held to the gated contract there - 8 checks - rather than only inside a test assembly. They refuse a command, refuse a manifest, name what is not commissioned, and produce no telemetry |

**The transport controls were attacked, and refuse:**

| Attack | Result |
|---|---|
| A client with no certificate | connection lost at the handshake |
| **A certificate this authority never signed, carrying the right common name** | refused. Identity is not a name a client picks; it is a name this CA attested |
| A device publishing into another device's telemetry path | `135 Not authorized` |
| A device publishing a command to itself | `135 Not authorized` - only the gateway may |
| Its own telemetry path | permitted, so the refusals are about scope rather than a broken link |

**Four pre-existing defects were found doing it**, 33 to 36 below - including one that made
CH1-COM-IF-0004 unimplementable and two container images that had never been built.

**One inference was wrong and is worth recording as such.** The broker's
`per_listener_settings true` looked like it was disabling the ACL, because probes showed
unauthorised publishes succeeding. It was not: the probes had defaulted to **MQTT 3.1.1,
where a denied publish is silently acknowledged as success**, and only MQTT 5 answers
`135`. Both configurations enforce identically - measured side by side on two brokers -
so the controlled file was restored unchanged. The protocol fact is the useful part, and
it is a concrete reason the ICD's choice of MQTT 5 matters: on 3.1.1 a device publishing
where it may not would have no way of knowing, and neither would anyone else.

**CH1-VVT-TC-0021 is closed** - "replaceable protocol adapters without changing domain or
inspection logic" is exactly what two operational adapters passing one unchanged suite
establishes. **CH1-VVT-TC-0022 moves from `hardware_gated` to `partially_automated`**: one
of its three protocols is exercised end to end, and its note no longer says that no MQTT
adapter exists.

### Backup, integrity verification, restore and rollback — CH1-VVT-TC-0081 closed

CH1-OPS-FR-0002 is a **Must** with a verification method of *Test*, and **nothing was
implemented at all**: no backup procedure, no restore, no rollback. The durability
observations recorded throughout this document are service restarts, which prove that
state was written — not that it can be recovered from an artefact. That distinction is the
whole requirement.

Three scripts and a procedure now exist, and the procedure is executed rather than
described:

| Piece | What it does |
|---|---|
| `scripts/backup.sh` | dumps the controlled `ch1` schema with `--clean --if-exists`, and writes a **manifest**: SHA-256 of the dump, a fingerprint of the controlled tables it came from, the table count and the time. A dump that produced no controlled tables is refused rather than written — an empty backup that restores cleanly is the most dangerous artefact this could produce |
| `scripts/restore.sh` | verifies the manifest **before writing anything**, refuses a mismatch, refuses a dump with no manifest, refuses to merge into a populated database without `--replace`, re-asserts the controlled application role from migration `0002`, and **refuses to report success** if the restored `cinerion_app` is not `NOSUPERUSER`/`NOBYPASSRLS` |
| `scripts/check-backup-restore.sh` | the executable verification, `npm run backup:verify` |
| `docs/operations/BACKUP_AND_RESTORE.md` | the documented procedure CH1-OPS-FR-0002 asks for, including what is deliberately **not** in the artefact |

**The verification does the real thing**, against two real PostgreSQL databases and two
service starts:

| Step | Observation |
|---|---|
| Source | controlled records produced **through the ordinary API** on PostgreSQL; chain verifies, 3 events |
| Source content | asserted to be in the database, not only in the service |
| Attack | a backup with one byte appended → `INTEGRITY CHECK FAILED`, and the target was **still empty** afterwards |
| Restore | into a database that held **0** controlled tables, now 33 |
| Isolation | the restored `cinerion_app` exists, `NOSUPERUSER` and `NOBYPASSRLS` |
| **Integrity** | the restored audit chain **verifies** — the hash linkage survived a dump and reload, including every `timestamptz` re-parse |
| Completeness | 3 audit events and 1 measurement before and after; the part's permanent identity `CH1-PART-000017-04` readable through the API |
| **Functional** | a new controlled record accepted after the restore, chaining onto the restored chain (3 → 4), which still verifies |
| **Attack** | `CONTROLLED_PROCEDURE_REVISION_PINNED` altered to `…-TAMPERED` in the restored database → verification **fails at position 1** |

Writing it found three things, each of which would have made the procedure wrong:

1. **A schema dump is not a restorable system.** `cinerion_app` is a *cluster* object and
   its grants are *schema* objects, so neither is in a `--no-privileges` schema dump. A
   restore that stopped at the data would produce controlled tables whose row-level
   security policies name a role that does not exist — which is **defect 13 reappearing
   through the restore path**: isolation inert while appearing to be in force. The role and
   its grants are now re-asserted from migration `0002`, their single definition, after the
   restore, and a restore that does not end with a role RLS can govern is reported as a
   failure.
2. **The gate passed while proving nothing.** The first run used
   `CINERION_STORAGE_MODE`, which is not the setting — it is `CINERION_DATABASE_MODE` — so
   the service fell back to in-memory storage, which is *permitted in Development*, and the
   backup was of an empty database that restored perfectly. Every check passed. The harness
   now asserts the source database actually holds the records before backing it up.
3. **The tamper attack was a no-op.** It set `decision = 'Allowed'` on an event whose
   decision was already `Allowed`, so nothing changed and the chain quite correctly still
   verified. It now alters `reason_code` and **asserts the stored value changed** before
   drawing any conclusion from the result.

Both directions of the binding were attacked: removing the announcement fails the
reconciliation (`The verification map binds CH1-VVT-TC-0081 to backup-restore, but the run
announced no such case`), and neutering the tamper attack fails the harness so it never
announces. **28 of 87 controlled cases are now fully exercised, 69 have executable
evidence, and 7 remain not executed** — every one of those needing an AI service, a load
rig, a hardware controller, or an analysis activity no test can perform.

### The five screens that cannot be built

With 0001, 0003 and 0009 built, **every declared screen that has a controlled operation
behind it now exists.** The five that remain are not remaining work in the ordinary sense:
each names a subject the P03 catalogue contains no operation for, and
`scripts/check-repository-policy.mjs` correctly fails the build on any runtime operation
the catalogue does not contain. Inventing one is precisely what that gate exists to stop,
so these are reported rather than worked around.

| Screen | What it needs | What the catalogue has |
|---|---|---|
| **0012** Instrument and calibration register — "validity and certificates" | a read over calibration records and their validity | **nothing.** `ch1.calibration_records` exists and every measurement references one, but no operation reads one. Calibration validity is decided server-side at measurement time (defect 14) and is visible only as `calibrationValid` on a measurement already taken — which is the opposite of a register you consult *before* measuring |
| **0015** Mobile scan and evidence mode — "camera/NFC, photos, notes and acknowledgements" | a browser-originated scan, and a way to attach a photograph | **neither.** `POST /api/v1/parts/scan-events` requires a signed session from an enrolled Field Companion device, and a browser cannot originate one — correctly, since CH1-IAM-FR-0008 keeps human, service and device accounts separate (conflict 15). No operation accepts a binary at all: measurements carry evidence *references*, and the vault that would hold the artefact is a declared future phase. The two remaining quarters, notes and acknowledgements, are already served by CH1-UX-SCR-0019 and CH1-UX-SCR-0005 — **claiming 0015 for those alone would report a capability that is not there**, which is exactly what the screen gate was built to prevent |
| **0020** R&D workbench — "isolated experiments, simulation, versions, evidence and comparison" | a read over experiments and their runs | **no read operation exists.** `POST /experiments`, `POST /experiments/{id}/runs` and `POST /experiments/{id}/promotion-requests` are all writes; the records are durable and audited but reachable only through the response to the write that created them. A workbench could create and never list, revisit or compare |
| **0021** Experiment promotion review — "impact, change, verification and controlled-baseline promotion" | a read over promotion requests, and an approval | **neither.** Promotion is outbound only by design (CH1-COM-IF-0021): the approval workflow lives in configuration control, a separate system. There is nothing to review here and nothing to approve with |
| **0022** Control-board communication health — "controller topology, protocol state, latency, quality and diagnostics" | per-controller protocol state, latency and diagnostics | **nothing for its subject.** `GET /system/health` reports service, dependency and time-quality health, not a controller's protocol state; there is no operation that lists devices, only `GET /devices/{deviceId}` by identifier. The reads that do exist — cell freshness and one device's identity, configuration revision and last-seen time — are already on CH1-UX-SCR-0004 and CH1-UX-SCR-0018 |

**Owner's decision in each case:** either the catalogue gains the read the screen needs, or
the screen register is corrected. Nothing here should be closed by adding an operation to
the code.

### Screen coverage measured, and CH1-UX-SCR-0018

"13 of 22 declared screens exist" had been a hand-count in this document that nothing
checked, and it could be wrong in both directions: several routes implemented a declared
screen without naming it, and nothing would have caught a screen claimed twice or claimed
under an identifier `screens.json` does not contain. CH1-UXD-DSG-0001 makes the screen
register the controlled statement of what the interface must offer, so what has been
built against it should be measured — the same argument that put the verification map
behind a gate.

Every route now declares what it implements with a marker the gate reads:

```
// @screen CH1-UX-SCR-0004 — Site and cell hierarchy: assets, devices and readiness
// @screen none — reason this route implements no declared screen
```

`scripts/check-screens.mjs` (`npm run screens`, step `[7/12]`) fails on a route that
declares nothing, an identifier the register does not contain, a screen claimed by two
routes, or a declaration with no explanation after it. It reports coverage and names what
is absent. The first run confirmed the hand-count of 13 — and then made it a number
rather than a claim.

**CH1-UX-SCR-0018, device and configuration management** is the fourteenth: one device's
identity, the configuration revision it is running, the certificate thumbprint it
enrolled under, its trust state, when it was last heard from, and the withdrawal of trust
behind a purpose-bound phishing-resistant step-up.

Verified against a running Control Core:

| Behaviour | Observation |
|---|---|
| **Every field the screen reads exists** | all twelve keys of `GET /devices/{deviceId}` compared name by name against the contract — no mismatch |
| Authority is exactly what the catalogue names | Engineer `200`, Maintenance Engineer `200`; Inspector, Viewer and **Cybersecurity Administrator** all `404`, identical to a device that never existed |
| **A contract error was found and fixed** | the alarm field is `alarmCode`, not `code`. The screen would have rendered `undefined` for the alarm a revocation raises; caught by comparing against the real response rather than the shape assumed while writing |
| Revoke without a step-up | `400 STEP_UP_REQUIRED` |
| Revoke with a `DeviceTrust` grant | `200`, trust `Revoked`, reason and author recorded, version 2, and `CH1-ALM-DEVICE-REVOKED` raised at priority 2 with the server's own guidance |
| Honest about what it did not do | the receipt renders `brokerTopicAclRevoked: false` and the note that the MQTT broker is unchanged, rather than implying both halves of the revocation took effect |
| Revoking twice | `400 DEVICE_ALREADY_REVOKED` |
| An Engineer revoking | `403 AUTH_DEVICE_TRUST` — the screen hides the control, the server refuses regardless |

Configuration rollback is **not offered**: the catalogue has no operation that sets a
device configuration, so a control for it would be a button with nothing behind it. The
screen says that instead.

### CH1-UX-SCR-0007, part genealogy — and defect 31, found by asking

The thirteenth declared screen, and the read side of CH1-MFG-FR-0002: one physical part,
its permanent identity, the order and revision that governed it, who made it, every
measurement taken against it, and whether it was released.

**Building it found an authority gap.** `api_endpoints.json` gives
`GET /api/v1/parts/{partId}/genealogy` to "Engineer, Inspector or Auditor". The endpoint
checked project scope and **nothing else**, so a Viewer received `200` and the complete
evidence graph for a part: every measurement with its value and limits, the instrument
and its calibration record, the operator who performed the work, open nonconformities and
the release. Recorded as defect 31. It was found by asking a running service what a
Viewer gets — not by reading the code, which is how every authority gap in this
repository has been found.

Verified on a running Control Core after the fix:

| Role | Genealogy |
|---|---|
| Inspector, Engineer, Auditor | `200` — the three the catalogue names |
| Viewer, Project Manager, Operations Coordinator | `404` |
| A part that never existed, to an Inspector | `404` |

A caller without the role is answered exactly as one asking about a part that does not
exist, so probing cannot distinguish "not allowed" from "not there". The test that now
holds this was run against the pre-fix code and fails there, naming `NotFound` expected
and `OK` observed.

**The screen itself, verified against a running service** by driving the whole controlled
quality path and reading back what the page renders:

| Behaviour | Observation |
|---|---|
| **Every field the screen reads exists** | `GET /parts/{id}/genealogy` compared key by key against the `PartGenealogy` contract — no mismatch |
| Permanent identity | `CH1-PART-000017-04` with `urn:cinerion:ch1:part:CH1-PART-000017-04`, issued once and never recomputed |
| Origin | the work order and revision that governed it, and `USR-OPERATOR-01` who made it |
| **The failure is retained beside the retest** | a failing 8.2 µm against 9.5–10.5 stays readable next to the 10.1 µm retest that supersedes it, which is what CH1-QMS-FR-0004 requires |
| Hold and release move together | `Hold` with one open NCR → `Released` with the release record, inspector and time after the closing disposition |
| Evidence completeness follows | `Open` → `Released`, reported by Control Core rather than computed by the screen |
| Provenance is the server's word | rendered verbatim, so it can never misdescribe the durability of controlled evidence |
| A part outside the project | `404`, identical to one that never existed — rendered as an empty state, not a fault |

**A second boundary is stated on the screen.** The genealogy operation takes a part
*identifier*, not the serial number on the label. The only operation that resolves a
scanned QR or RFID code to a part is `POST /api/v1/parts/scan-events`, which requires a
signed session from an enrolled Field Companion device — a browser cannot originate one
and should not be able to. So the page starts from the part the assigned cell reports and
otherwise takes an identifier obtained elsewhere, and says so rather than offering a
lookup that cannot work. Recorded as the fifteenth conflict.

### CH1-UX-SCR-0006, the work-order board — and the fourteenth conflict

The twelfth declared screen. Products and their controlled revisions, the order the cell
reports as loaded, and the two ForgeFlow mutations the portal can legitimately issue:
raising a work order against a released revision, and releasing it behind a
phishing-resistant step-up.

Building it exposed a gap in the catalogue rather than in the code. **There is no
controlled operation that reads a work order** — `POST /work-orders` and
`POST /work-orders/{id}/release` both answer with the record they wrote, and nothing
lists or fetches one. Adding `GET /api/v1/work-orders` was rejected: the repository
policy gate fails the build on any runtime operation the P03 catalogue does not contain,
which is correct, and quietly inventing it is precisely what that gate exists to stop.
So the board says so on itself, and shows only what it can actually see. Recorded as the
fourteenth conflict.

**Verified against a running Control Core**, not asserted from the source:

| Behaviour | Observation |
|---|---|
| **Every field the board reads exists** | `GET /products` compared key by key against the TypeScript contract — `productCode`, `revisionId`, `revisionCode`, `lifecycleState`, `bom{componentCode,quantity,unit}`, `route{stepNumber,operationCode,description,mandatoryInspection}`, `sourceChecksum`, `releasedAt`, `supersededAt`, `version`. No mismatch. Same for the eight cell-state fields |
| Raising, exactly as the screen sends it | `201`, status `Draft`, version 1, against revision R01 |
| **Release without a step-up** | `400 STEP_UP_REQUIRED` — the code the screen surfaces rather than a generic failure |
| Release with a `WorkOrderRelease` grant | `201`, status `Released`, `releasedBy`, `releasedAt`, version 2 |
| **The grant is single use** | the same grant a second time → `400 STEP_UP_ALREADY_USED` |
| Authority is the server's, not the screen's | an Engineer raising an order → `403 AUTH_PROJECT_MANAGER_REQUIRED`. The board hides the control for an identity without the role; the server refuses regardless |
| **A draft revision cannot start work** | `400 REVISION_NOT_SELECTABLE`, which is the wording the screen's blocked state mirrors |
| A draft is still shown | R02 appears on the board as `DRAFT` with 0 BOM lines and 0 route steps, marked as unable to start an order |

The portal was exported with the verification endpoints inlined and served at
`http://localhost:19006`; the route renders, the new navigation entry appears, and the
session gate offers the real Keycloak sign-in. **The authenticated render was not
verified**: completing it requires typing the lab identity's password, which is outside
what this agent may do. The board's authenticated behaviour therefore rests on the API
evidence above and on inspection, not on a browser run — see "Resuming work" below.

### The protocol boundary, demonstrated rather than declared

"EdgeLink supports replaceable protocol adapters" (CH1-COM-FR-0002) and "a transport
overlay connects through a stable provider boundary without changing domain messages"
(CH1-COM-FR-0005) both rested on an interface with **one implementation behind it** —
which shows only that the interface was shaped around the one thing implementing it.

Four things now exist:

| Piece | What it is |
|---|---|
| `FrameCodec` | the CH1 serial frame — preamble, version, type, length, sequence, payload, CRC — as a **second implementation** of the format `firmware/arduino-io/src/frame_codec.cpp` already speaks. Cross-checked against the published CRC-16/CCITT-FALSE vector (`123456789` → `0x29B1`) and against the firmware's field offsets byte by byte |
| `FramedSerialTransportProvider` | a reference alternate provider that segments, checksums and sequences every message, reassembles it, and refuses malformed, replayed and oversized input rather than repairing or truncating it |
| `TransportConformance` | six checks from the CH1-COM-ICD-0001 acceptance list: identity, round trip, segmented message, order, declared bound, cancellation |
| `AdapterConformance` | nine checks for an operational adapter, and **four separate ones for a gated adapter** — because refusing correctly is a gated adapter's contract, and one that quietly acknowledged a command would be the exact fake-success failure the gating exists to prevent |

Both suites live in **the service, not the test project**. The MQTT, OPC UA and Modbus
adapters are gated on conformance evidence, and evidence that only exists inside a unit-
test assembly says nothing about the adapter a running gateway was configured with.

**Verified on a running gateway**, not asserted from the source: `dotnet run` on EdgeLink
emitted **21 conformance checks** before reporting the adapter online, all passing —

| Observation |
|---|
| the 591-byte reference command envelope returned **identical** through both providers |
| a 401-byte message crossed the framed provider as **four frames and one message** |
| eight messages arrived in the order sent, through both |
| the framed provider refused a 16 385-byte message: *"refused rather than truncated"*; the loopback declares no bound and says so |
| the simulator adapter refused an expired command, a replayed sequence, and `write:40001` as a command type |
| a spent sequence stayed refused **after** reconciliation — reconnection replays nothing |

And it fails closed, which is the half that matters. A provider that flips one bit of the
message it carries, and an adapter that acknowledges an expired command, each **stop the
gateway** rather than being logged and served: `TRN-02-ROUND-TRIP … ALTERED` and
`ADP-05-EXPIRED-REFUSED` both throw out of `EdgeLinkWorker`, and
`BackgroundServiceExceptionBehavior.StopHost` is now set explicitly rather than inherited,
because a default is not a decision and this one is load-bearing.

**CH1-VVT-TC-0024 is closed** — "reference alternate provider passes conformance tests" is
exactly what two providers passing one suite establishes. CH1-VVT-TC-0023 moved from
`not_executed` to `partially_automated`: the serial half of it now exists and is
exercised, while CAN/CANopen and fabrication-machine adapters still do not.
CH1-VVT-TC-0021 stays `partially_automated` on purpose — the boundary is demonstrated
across four adapters and two providers, but only **one adapter is operational**, and a
second live protocol is what would close it.

### Telemetry and alarms, verified on a running system

Observed against Control Core on PostgreSQL with the simulated cell feeding the
ordinary ingestion path, not asserted from the source:

| Behaviour | Observation |
|---|---|
| Alarm raised by a real breach | Temperature crossed the 45 °C limit; `CH1-ALM-TEMP-HIGH` appeared at priority 3, state `Active` |
| **Acknowledgement does not clear the cause** | Acknowledged while the condition was present → state `Acknowledged`, `causeClear` still `false`, `clearedAt` still null |
| **Acknowledgement has no control side effect** | Cell `stateHash` and all six interlocks byte-identical before and after |
| Latching | Cause cleared before anyone acknowledged → `ReturnedUnacknowledged`, still outstanding, not silently removed |
| Clear time is the equipment's | `clearedAt` 00:50:13 stayed put while `acknowledgedAt` was 00:50:55 |
| Channel allowlist | `channel=rotor_speed` → `400 TELEMETRY_CHANNEL_NOT_ALLOWED`, not an empty page |
| Time bound | 30-day window → `400 TELEMETRY_WINDOW_TOO_WIDE` |
| Authority | Auditor with no cell assignment → `403`; assigned operator and Engineer → `201` |
| Project isolation | Alarm in another project → `404`, identical to one that never existed; cross-project telemetry → 0 rows |
| Cursor pagination | `limit=1` walked two alarms with no repeat and no skip; third page empty |
| Freshness | `Simulated` while the feed ran; `Stale` 57 s after it stopped; `Unknown` for a project with no samples |
| Audit | Both acknowledgements in the chain with reason `ACKNOWLEDGEMENT_DOES_NOT_CLEAR_CAUSE`; chain verified valid |
| Durability | 244 samples and both alarms with their comments survived a service restart |

### CH1-VVT-TC-0109 closed: communication and control separation

The verification case needed both halves present — an alarm that can be acknowledged,
and a message on that same alarm that can be read. Both now exist, so it was exercised
end to end rather than argued:

| Behaviour | Observation |
|---|---|
| A message on the alarm's own thread | posted at `Urgent` priority against `objectType: Alarm`, `controlAuthority: false` |
| **Reading it acknowledges nothing about the alarm** | alarm stayed `Active`, `acknowledgedBy` null, `causeClear` false, `clearedAt` null, still outstanding |
| **No interlock moved** | cell `stateHash` and all six interlocks byte-identical before and after |
| The verbs differ | receipt reports `kind: "Read"`; the alarm's own operation reports `Acknowledged` |
| The database refuses the confusion | as `cinerion_app`, direct SQL inserting `control_authority = true` and `acknowledgement_kind = 'AlarmAcknowledged'` were both rejected by CHECK constraints |
| Thread identity is derived, not chosen | client-side and server-side derivation agreed exactly; a chosen identifier was refused and told the canonical one |
| Scope | a MaintenanceEngineer outside the access scope got the same 404 as for a thread that never existed; another project the same |
| Provenance | author, author kind, priority, delivery state, access scope and read receipts all retained and returned |
| Retention | every page states the declared retention and that a message is not a controlled engineering decision |
| Receipts | author cannot receipt their own message (400); a second receipt from one recipient is a 409 conflict, not an overwrite |
| Audit | `ContextThreadOpened`, `ContextMessagePosted`, `ContextMessageRead` chained and verified; the read event's decision word is `Read` |
| Durability | thread, message and receipt survived a service restart |

### Resource capacity, reservation and conflict, verified on a running system

| Behaviour | Observation |
|---|---|
| Seeded capacity | one indivisible station (1 station) and one measured stock (250 m), read from PostgreSQL with `freshness: Live` |
| **Double-booking refused** | a second overlapping reservation on the station → `409 ALLOCATION_CAPACITY_CONFLICT`, "would commit 2 station at 2027-03-01 10:00:00Z" |
| Adjacent booking accepted | a reservation starting exactly as the first ends → `201`, so the refusal was about the interval, not the resource |
| **Quantities summed, not counted** | 200 m accepted, a further 60 m refused at 260 m, a further 50 m accepted at exactly 250 m |
| Peak found inside the interval | the check evaluates every boundary in the candidate window, not only its start |
| Optimistic concurrency | reusing a spent `If-Match` → `409 CONCURRENCY_CONFLICT` naming the current version; omitting it → `RESOURCE_VERSION_REQUIRED` naming it too |
| Step-up | no `X-CH1-Step-Up` → `STEP_UP_REQUIRED`; wrong role with a valid grant → `403 AUTH_RESOURCE_ALLOCATION` |
| Link required | no work order → `ALLOCATION_LINK_REQUIRED`; unknown work order → `404`; experiment → `ALLOCATION_EXPERIMENT_MODULE_NOT_ENABLED` |
| Cancellation authority | an Engineer who is neither owner nor coordinator → `403`; no reason → `400`; no version → `400`; owner → `200` |
| Cancellation evidence | reason, author, time and version 2 stored; quantity, interval and work-order link all retained |
| Capacity released | the station's committed peak returned to 0 and the window was reservable again |
| Database enforces it too | direct SQL as `cinerion_app` setting `status='Cancelled'` with no reason → rejected by `ck_allocations_cancellation_complete` |
| **Conflict state exposed** | capacity reduced 250 → 200 administratively; the view reported one conflict, 10:00–18:00, committed 250 against capacity 200, over by 50 |
| Audit | reservations, refusals and the cancellation all chained, including `CAPACITY_CONFLICT` refusals; 42 events verified valid |
| Durability | every reservation, the cancellation and the resource versions survived a service restart |

### R&D isolation, verified on a running system

CH1-VVT-TC-0110 and CH1-VVT-TC-0112 are security tests, so the interesting evidence is
what an R&D identity could **not** do:

| Behaviour | Observation |
|---|---|
| **Simulator only** | an experiment asking for `ControlledBench` → `400 EXPERIMENT_BENCH_TRANSITION_NOT_AUTHORISED`; the only reachable environment is `Simulator` |
| **No production route** | as `RDEngineer`: prepare a command → `400`, reserve a resource → `400`, read cell state → `404`, read alarms → `404` |
| **Database refuses production authority** | direct SQL as `cinerion_app` setting `production_authority = true` → rejected by `experiments_production_authority_check` |
| **Database refuses an invented environment** | `environment = 'Production'` → rejected by `experiments_environment_check` |
| **A recorded run is append-only** | direct SQL UPDATE and DELETE on `ch1.experiment_revisions` → both rejected by `ch1.reject_immutable_mutation()` |
| Reproducibility | run 1 retained configuration, model, input and result references each with a SHA-256, plus operator, environment and both timestamps |
| Isolated executor | `executedBy` is `bench:<experimentId>`, derived from the experiment, never the caller and never a production account |
| No fake success | the response states `Recorded. ResearchBench captures run provenance; the simulation itself runs elsewhere.` |
| Quota | the run response states `recorded 1 of 500` |
| **Promotion grants nothing** | `outcome: PromotionRequested`, `approved: false`, environment still `Simulator`, `productionAuthority` still false; approval authority named as configuration control |
| Promotion completeness | missing impact analysis → `PROMOTION_IMPACT_ANALYSIS_REQUIRED`; no step-up → `STEP_UP_REQUIRED`; nothing run yet → `EXPERIMENT_NO_RESULT_TO_PROMOTE` |
| Promotion is terminal here | a second request → `EXPERIMENT_PROMOTION_ALREADY_REQUESTED`; further runs → `EXPERIMENT_CLOSED_TO_RUNS` |
| Audit | `ExperimentDefined`, `ExperimentRunRecorded` and `ExperimentPromotionRequested` chained; the promotion decision word is `Requested`, never `Allowed`; 14 events verified |
| Unblocked links | a conversation attached to the experiment and capacity held for it — both previously refused as "module not enabled", both now carrying `controlAuthority: false` and `physicalEffect: None` |
| Durability | the experiment, its run and its promotion state survived a service restart |

### Identity administration, verified against the live Keycloak lab

The first subsystem whose system of record is **not** PostgreSQL. FortressGate owns
identity, so there is no `ch1.users` table and Control Core never becomes a second
system of record for it.

| Behaviour | Observation |
|---|---|
| **The service account's own token is least privilege** | decoded: `manage-users, view-users, query-groups, query-users`. No `realm-admin`, `manage-realm`, `manage-clients` or `manage-authorization` |
| **It cannot weaken realm security policy** | `PUT /admin/realms/cinerion {bruteForceProtected:false}` as that account → `403 Forbidden` |
| **It cannot create a client** | `POST /admin/realms/cinerion/clients` as that account → `403 Forbidden` |
| Live user list | `GET /api/v1/users` returned `ch1-portal-demo` from Keycloak with project, cell, actor kind and lifecycle — and no credential field of any kind |
| Scope filter works | the service account's own user, which carries no `ch1_project`, is absent from the list |
| **No security-policy authority** | granting `CybersecurityAdministrator` → `ROLE_SECURITY_POLICY_AUTHORITY`; withdrawing it is refused for the same reason |
| **No device role for a person** | `DeviceController` → `ROLE_NOT_ASSIGNABLE_TO_HUMAN` |
| Unknown role, empty set | `ROLE_UNKNOWN`; `ROLE_SET_EMPTY` — removing every role is not how an account is disabled |
| Real role changes | granting `MaintenanceEngineer` and withdrawing it again both applied in Keycloak, with previous and current sets reported |
| Project isolation | a user in another project → `404`, identical to one that never existed |
| Step-up | none → `STEP_UP_REQUIRED`; MFA-only → `AUTH_STRONGER_AUTHENTICATOR_REQUIRED`; a `PartRelease` grant → `STEP_UP_PURPOSE_MISMATCH` |
| **Revocation ends a real session** | a genuine portal session refreshed successfully before, and after revocation Keycloak answered `invalid_grant: Session not active` |
| Revocation authority | a Viewer revoking another identity's session → `403`; another project's administrator → `404`; a session that never existed → `404` |
| Fail closed | with no provider configured every operation returns `IDENTITY_PROVIDER_NOT_CONFIGURED` — never an empty user list |
| Authority before configuration | a caller without the role is told so whatever state the deployment is in, and learns nothing about whether a provider exists |
| Secret hygiene | the generated client secret appeared in neither service stdout/stderr nor anywhere in the working tree |
| Audit | `SessionRevoked` chained with reason `ADMINISTRATIVE_REVOCATION`; refused role changes are audited as `RoleAssignmentRejected` |

### Device PKI, verified on a running system

The platform is a **trust registry, not a certificate authority**: the device generates
its key pair in its own secure element and presents only the certificate.

| Behaviour | Observation |
|---|---|
| **The thumbprint is derived, not accepted** | the platform's computed SHA-256 matched the certificate byte for byte; there is no field a caller could put one in |
| **A submitted private key is refused and named** | `ENROLMENT_PRIVATE_KEY_SUBMITTED`, with "treat the submitted key as compromised" |
| **One certificate, one device** | the same certificate on a second device → `DEVICE_CERTIFICATE_ALREADY_ENROLLED`, naming the device that holds it |
| Subject binding | a certificate naming another device → `ENROLMENT_SUBJECT_MISMATCH` |
| Key strength | RSA-2048 → `ENROLMENT_KEY_TOO_WEAK`; RSA-3072 and P-256 accepted |
| Validity | expired, not-yet-valid and a 10-year lifetime each refused with their own code |
| Trust-list change alarm | enrolment raised `CH1-ALM-DEVICE-TRUST-CHANGED` at priority 3, as CH1-CYB-CSRS-0001 requires |
| Revocation alarm | revocation raised `CH1-ALM-DEVICE-REVOKED` at priority 2, which is the alarm the API control column names |
| **Revocation actually stops the device** | the simulated source, publishing as the revoked controller, was refused on every cycle and **zero samples were stored** |
| **Revoked use raises a priority-1 alarm** | `CH1-ALM-DEVICE-REVOKED-USE` raised once, not once per attempt, across five refused cycles |
| Evidence retained | thumbprint kept after revocation, with reason, author and time |
| Lifecycle | a second revocation → `DEVICE_ALREADY_REVOKED`; re-enrolling a revoked device → `DEVICE_REVOKED`; the same certificate again → `DEVICE_CERTIFICATE_UNCHANGED` |
| Authority | an Engineer → `403 AUTH_DEVICE_TRUST` **without spending a step-up grant**; MFA-only step-up → `AUTH_STRONGER_AUTHENTICATOR_REQUIRED` |
| **The database enforces the invariants** | as `cinerion_app`: a revoked device marked `Trusted` → `ck_devices_revoked_not_trusted`; an invented trust state → `ck_devices_trust_state`; one certificate on two devices → `ux_devices_certificate_thumbprint` |
| Manifest narrows the allowlist | an enrolled device may publish only what it declared; `humidity` is in the baseline catalogue but was refused as `TELEMETRY_CHANNEL_NOT_DECLARED` |
| Honest about what did not happen | the response states `brokerTopicAclRevoked: false` — CH1-COM-IF-0004 puts the topic ACL in the MQTT broker, which is not enabled |
| Audit | `DeviceEnrolled`, `DeviceCertificateRotated`, `DeviceRevoked` and `DeviceEnrolmentRejected` chained; 29 events verified valid |

### Portal screens for telemetry, alarms, collaboration and resources

Three declared screens built against operations that were already served but reachable
only over HTTP: CH1-UX-SCR-0005 (live control room), CH1-UX-SCR-0019 (contextual
collaboration) and CH1-UX-SCR-0017 (resource and capacity board). Eighteen operations
were already implemented behind them; none of the API changed.

Verified against Control Core on PostgreSQL with the simulated cell feeding the
ordinary ingestion path:

| Behaviour | Observation |
|---|---|
| **Every field the screens read exists** | all six endpoints' JSON keys compared name by name against the TypeScript contracts: `cells/{id}/state`, `telemetry`, `alarms`, `resources`, `context-threads/{id}/messages`, and both acknowledgement operations. No mismatch |
| A real alarm, not a fixture | `CH1-ALM-TEMP-HIGH` raised at priority 3 by the temperature channel crossing 45 °C, carrying its own `contextThreadId` |
| **A message receipt reports `Read`** | posting a message on that alarm's thread and receipting it returned `kind: "Read"` verbatim; the screen renders the server's field, not a label of its own |
| **Reading the message moved nothing on the alarm** | `state`, `acknowledgedBy`, `acknowledgedAt`, `causeClear`, `clearedAt` and `outstanding` identical before and after the receipt |
| Acknowledgement carries the cause through | the acknowledgement response returns `causeClear` and `clearedAt` as equipment observed them; the alarm had genuinely returned to clear between reads, so the response reported `Cleared` — by observation, not by the acknowledgement |
| An empty comment is refused | `400 ALARM_ACKNOWLEDGEMENT_COMMENT_REQUIRED`, which is the inline validation the form mirrors |
| Author cannot receipt their own message | exercised with a second actor, as the API requires |
| Static export renders every route | all 11 routes exported, including the three new ones |

The alarm/message separation CH1-UXD-DSG-0001 requires is held in one place,
`apps/operator-portal/src/constants/semantics.ts`, and is enforced rather than
intended: a `Distinct<A, B>` conditional type makes the portal gate fail if the alarm
and message mark, action verb, recorded verb or shape ever collide. Proven by making
them collide — `tsc` answered `TS2322` naming the colliding value — and then restoring.

### The same screens, driven in a browser as `ch1-portal-demo`

Signed in through the real Keycloak flow against Control Core on PostgreSQL with
`CINERION_ALLOW_DEVELOPMENT_IDENTITY=false`, so every request below carried a genuine
OIDC bearer token and was authorised on its merits.

| Behaviour | Observation |
|---|---|
| Telemetry, live | four allowlisted channels, each `SIMULATED`/`QUALITY GOOD` from `CH1-DEV-CELL-0001`, sampled 3 s earlier |
| A reading past its limit says who decides | `46.56 degC` against a 15–45 limit, marked `OUTSIDE ALARM LIMIT` with "Control Core raises the alarm, not this screen" |
| Bounds are visible | 200 rows returned, `Complete answer: NO — page is full`, ceiling 1000, 1 h window, 7-day maximum |
| **Cause, acknowledgement and outstanding shown as three separate facts** | every row, always all three, including when one is absent |
| Latching visible | one alarm `ACTIVE` with "Cause STILL PRESENT"; the rest `RETURNEDUNACKNOWLEDGED` with their own clear times |
| Inline validation | acknowledging with an empty comment produced a `role="alert"` refusal and **sent no request** |
| **Entered work survives a lost link** | comment typed, Control Core stopped: `▲ SCREEN NOT CURRENT — ACKNOWLEDGEMENT DISABLED`, `aria-disabled=true`, `RECONCILE NOW` offered, **comment intact**; service restarted, banner cleared, control re-enabled, comment still intact |
| **The acknowledgement does not clear the cause, visibly** | recorded at 20:10:26 while the receipt read "Cause clear at 20:07:22 — unchanged by this acknowledgement", the clear time being *earlier* and the equipment's |
| Server's words, verbatim | "None: no fault cleared, no interlock satisfied, no command confirmed." |
| Acknowledged once | the form is replaced by "Already acknowledged by …; a second acknowledgement is refused rather than overwriting the first" |
| **CH1-VVT-TC-0109, through the interface** | a receipt recorded by `ch1-portal-demo` at 20:22:08 left the alarm acknowledged by `verify-engineer` at 19:17:21 with cause clear at 19:16:58 — every field unmoved |
| The receipt's verb is the server's | rendered `RECEIPT KIND: READ` and `READ · verify-operator · …`, taken from the response field, never a label of the portal's own |
| An author cannot receipt themselves | the control is replaced by "You wrote this. An author cannot receipt their own message." |
| Message provenance | author, `Human`, `Elevated`, time, `Published`, and retention `Project life + 7 years` / `7 years` |
| Resources | both seeded resources at `LIVE` freshness with capacity, committed, available, peak and free-at-peak |
| **Conflict state exposed** | capacity reduced 250 → 200 → 150 out of band against a 200 m holding: `OVER-COMMITTED`, `Available now −50 m`, `200 / 150 m at peak — OVER BY 50`, and the interval named to the second |
| A reservation starts nothing | the allocation row carries the server's "None: a reservation holds capacity and starts no equipment." |
| Accessible naming | every alarm control announces as "Alarm CH1-ALM-TEMP-HIGH, P3 MEDIUM, state ReturnedUnacknowledged" — noun, priority in words, state, no reliance on colour |

---

## Environment

| Component | State |
|---|---|
| .NET SDK | 10.0.302 (`global.json` requires 10.0.100, rolls forward) |
| Node | 24.7.0, `npm ci` already run |
| Docker Desktop | required for the identity and data labs |
| Keycloak | `--profile identity-lab`, `http://localhost:8180`, realm `cinerion` |
| PostgreSQL | `--profile data-lab`, **no published host port by design** — use `docker compose exec postgres psql` |
| Local secrets | `infrastructure/.env.local`, git-ignored, generated by `scripts/bootstrap-local.ps1` |

Verification commands:

```bash
dotnet build Cinerion.slnx -c Release
dotnet test Cinerion.slnx -c Release
npm run baseline && npm run contracts && npm run test:model && npm run traceability && npm run policy
npm run check:portal && npm run build:portal
docker compose -f infrastructure/compose.yaml --profile data-lab --profile identity-lab --profile protocol-lab config --quiet
```

### CI steps reproduced locally

GitHub Actions cannot be exercised from here — the working copy has **no git remote**, so
the workflow has never been dispatched and the action versions pinned in
`.github/workflows/ci.yml` cannot be resolved offline. Every step the workflow runs
*outside* `./scripts/verify.sh --strict` was therefore reproduced by hand:

| CI step | Reproduced as | Result |
|---|---|---|
| Run strict verification | `./scripts/verify.sh --strict` | **10/10, exit 0** |
| Execute PostgreSQL foundation migration | `docker compose -p … --profile data-lab up --wait postgres` on a throwaway project name, then the two `psql` queries | 33 controlled tables; row security reported per table |
| Audit npm production dependencies | `npm run audit:deps` | 3 root advisories, all dispositioned; **the previous step could never have passed** — see defect 29 |
| Report vulnerable .NET dependencies | `dotnet list Cinerion.slnx package --vulnerable --include-transitive` | no vulnerable packages in any of the 8 projects |
| Generate SBOM / upload evidence | not reproducible locally | needs the runner |

Running the API on PostgreSQL requires a host-reachable database. The controlled
`data` zone is internal, so for host-side testing start a throwaway instance, apply
every migration in `Persistence/Migrations` in order, grant `cinerion_app` a login,
and point `CINERION_POSTGRES_CONNECTION` at it. Connect as `cinerion_app`, never as
the bootstrap owner: the owner is a superuser and bypasses every row-level security
policy, so isolation would appear to work while doing nothing.

Startup refuses a database whose schema is behind the build and names the missing
migration, so a partly-migrated database fails at start rather than in front of an
operator.

### Resuming work in a new session

Things that cost time to rediscover. **Items 57-65 are new.** Two older ones still earn
their place at the front: 45, because it is why four defects and a conflict had been
carried unexamined, and 51, because it is what "the project will not boot and the ports do
not work" actually turned out to be. Of the new ones, 57 is the sequel to 45 - the other
two controlled SVGs are now mined, and reading them produced defects 76 and 77 and a
controlled component nobody had built - and 62 is a way to waste an hour that cost one.

1. **`AGENTS.md` is one directory above the repository**, at
   `C:\Users\Arash_Sorati\Desktop\Projects\Cinerion\AGENTS.md`, not in the working copy.
2. **Something unrelated listens on `localhost:5080` — and on `localhost:8081`.** Both
   are Docker `wslrelay` processes with no matching container (`docker ps -a` shows
   none). The 8081 one still serves a stale `operator-portal` nginx build, complete with
   a `Content-Security-Policy` whose `connect-src` names only port 5080, so a portal
   served there silently cannot reach a Control Core on any other port. Verification
   instances here use `http://localhost:5090` for the API and **`http://localhost:19006`
   for the portal** — the realm's other permitted redirect origin, and also allowed by
   the `DevelopmentPortal` CORS policy. Address the service as `localhost`, never
   `127.0.0.1`: `AllowedHosts=localhost` answers the latter with 400.
3. **The throwaway verification database.** The `data-lab` PostgreSQL is on an internal
   network with no host port, so host-side testing needs its own instance:

   ```bash
   docker run -d --name cinerion-verify-db -e POSTGRES_DB=cinerion \
     -e POSTGRES_USER=cinerion_owner -e POSTGRES_PASSWORD=<generated> \
     -p 127.0.0.1:55432:5432 postgres:18.4-alpine3.24
   ```

   Copy every file in `Persistence/Migrations` in and apply them in order as
   `cinerion_owner`, then `ALTER ROLE cinerion_app LOGIN PASSWORD '<generated>'`, and
   connect the service as `cinerion_app`. Remove the container afterwards.
4. **The identity-admin Keycloak secret is not stored anywhere.** The
   `cinerion-identity-admin` client exists in the running realm, but its secret was
   generated locally and deleted. To exercise `GET /users`,
   `PUT /users/{userId}/roles` or `DELETE /auth/sessions/{sessionId}` again, reset the
   client secret through the Keycloak admin API using the credentials in
   `infrastructure/.env.local`, and pass it as
   `CINERION_KEYCLOAK_IDENTITY_ADMIN_SECRET`. Without it those three operations refuse
   with `IDENTITY_PROVIDER_NOT_CONFIGURED`, which is the intended fail-closed behaviour.
   The service account must hold `view-users`, `query-users` and `manage-users` from
   `realm-management` and nothing more.
5. **Tests run on the in-memory store**, so a PostgreSQL-only defect is invisible to
   them — that is how the `SaveCommandAsync` parameter defect survived. Set
   `CINERION_POSTGRES_CONNECTION` to run the four integration tests, and exercise new
   write paths over HTTP against PostgreSQL before believing them.
6. **The simulated telemetry source** publishes as `CH1-DEV-CELL-0001` every 5 s in the
   Simulation profile. `CINERION_SIMULATED_TELEMETRY=false` turns it off; the API test
   harness sets that so alarm assertions stay deterministic.
7. **Serving the portal for verification.** `EXPO_PUBLIC_*` variables passed on the
   command line are **not** reliably inlined, because Metro reuses cached transforms:
   the build succeeds and silently keeps the previous values, which reads as "the portal
   ignores its configuration". Put them in `apps/operator-portal/.env.local` (git-ignored
   by the root `.env.*` rule) and export with `--clear`. Confirm by grepping the emitted
   bundle for the endpoint. Serve `dist/` with a plain static server that maps a clean
   URL to `<route>.html`; `npx serve` redirects `/control-room.html` to `/control-room`
   and then 404s it, and its child process outlives the shell that started it, keeping a
   lock on `dist` that makes the next `expo export` fail with `EBUSY`.
8. **The lab identity is `ch1-portal-demo`**, holding `Viewer`, `Auditor`, `Engineer` and
   `Inspector`, scoped to project `…101` and cell `…103`. The realm enforces a real
   password policy — `length(14) and digits(1) and upperCase(1) and lowerCase(1) and
   specialChars(1) and passwordHistory(12)` — and `bruteForceProtected` is on, so a reset
   that ignores it is refused with `invalidPasswordMinDigitsMessage` or similar.
9. **Development identity and OIDC are mutually exclusive.** `Program.cs` registers one
   authentication scheme or the other, so with `CINERION_ALLOW_DEVELOPMENT_IDENTITY=true`
   a real Keycloak bearer token is not merely unauthorised — it is never validated, and
   every portal request answers `401` while the log repeats "Explicit X-CH1-Actor is
   required in development mode". Set it to `false` to exercise the portal. The
   separation is deliberate and correct; it is only worth writing down because the
   symptom points at the token rather than at the switch.
10. **Give Npgsql `Host=127.0.0.1`, not `Host=localhost`.** Under the portal's
    one-second polling, concurrent name resolution on Windows produced
    `SocketException (10111): A call to WSALookupServiceEnd was made while this call was
    still processing`, surfacing as intermittent `500`s and screens that showed no data
    for no visible reason. The loopback literal skips resolution. This is the connection
    string only — `AllowedHosts=localhost` still governs the HTTP host header, so the
    service itself is still addressed as `localhost`.

11. **A browser run needs you to sign in.** Everything up to the Keycloak login page can
    be set up unattended — Control Core with `CINERION_ALLOW_DEVELOPMENT_IDENTITY=false`
    on `http://localhost:5090`, `apps/operator-portal/.env.local` pointing at it, an
    `expo export --clear`, and the exported `dist/` served on `http://localhost:19006`.
    Typing the identity's password is not something this agent may do, so the
    authenticated render is the one class of evidence that needs a person at the keyboard.
    Serve `dist/` with a plain static file server that maps a clean URL to `<route>.html`;
    `npx serve` redirects and then 404s those routes, and its child process outlives the
    shell and locks `dist` so the next export fails with `EBUSY`.
12. **`dotnet run` ignores `ASPNETCORE_URLS`** because `Properties/launchSettings.json`
    wins, and puts the service on 5080 where the `wslrelay` ghost lives. Pass
    `--no-launch-profile --urls http://localhost:5090`.
13. **The storage-mode setting is `CINERION_DATABASE_MODE`, not `CINERION_STORAGE_MODE`.**
    Getting it wrong is silent: in Development the service falls back to in-memory storage,
    which is permitted, so every request succeeds and PostgreSQL stays empty. That cost a
    whole run of the backup gate, which backed up an empty database and restored it
    perfectly. Outside Development the setting is mandatory and the service refuses to
    start without it.
14. **The lab identity's password was rotated on 2026-08-15**, because the previous value
    appeared in a session prompt. The new value is in `infrastructure/.env.local` as
    `CINERION_PORTAL_DEMO_PASSWORD` (git-ignored) and was never printed. Confirmed against
    the running realm: the password credential's `createdDate` is the rotation and the
    previous one moved into `password-history`. The realm forbids direct grants for the
    public browser client, so the only way to exercise it is the browser sign-in.
15. **`RelativePathElement.IsInverse` initialises to `true` in the OPC Foundation stack.**
    An OPC UA browse path that does not set it walks the hierarchy *backwards* and answers
    `BadNoMatch` for a node that is plainly there, which reads as "the server does not
    expose this". Both `OpcUaProtocolAdapter.ResolveAsync` and `Ch1EndpointProbe` set it
    explicitly and say why.
16. **`DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1` breaks the OPC UA reference server.** It
    builds its diagnostic resource manager with `new CultureInfo("en-US")` before opening an
    endpoint, so under invariant mode it throws and the stack reports only
    `BadInternalError 'Unexpected error starting application'`. `simulators/opcua-plc/`
    therefore installs ICU and turns invariant mode off in that image alone; the other .NET
    images keep it. The startup failure is now caught and its inner cause printed.
17. **The OPC UA controller is a stateful peer, so the lab recreates it with the gateway.**
    A spent sequence stays spent and a prepared command stays prepared across a gateway
    restart — which is correct, and is why `scripts/check-opcua-edge.sh` force-recreates the
    controller and the gateway together. The endpoint probe runs *before* the gateway
    connects and provokes only refusals that leave the guard untouched; `PROBE-12` asserts
    exactly that, so the two halves of the gate cannot interfere.
18. **The protocol lab now has three controller peers**, all raised by
    `docker compose --profile protocol-lab`: the MQTT broker, the OPC UA controller
    (`opcua-plc`) and the Modbus zone (`modbus-plc`). None publishes a host port, by design
    — the control network is `internal: true`, and for Modbus that network boundary *is* the
    access control, because the protocol has none. Anything speaking to them joins
    `cinerion_control`, as `edge-link` does. `scripts/check-modbus-edge.sh` raises all three
    at once and runs one gateway against every one of them.
19. **`scripts/verify.ps1` had silently drifted behind `verify.sh`.** It was missing the CH1
    envelope host test, the PLC scenario host test, `npm run plc` and — once it existed —
    the Modbus map reconciliation, while `DEVELOPMENT_GATES.md` said the two entry points
    differed only in the workstation preflight and the Compose model. All four are now
    there. Worth remembering as a class rather than an incident: a second entry point to the
    same gates is a second place for a gate to go missing.
20. **A restore needs its own throwaway cluster.** `scripts/check-backup-restore.sh`
    creates and removes both databases itself (`cinerion-backup-source`,
    `cinerion-backup-target`, ports 55440/55441, API on 5091) and cleans up on any exit,
    so it does not disturb `cinerion-verify-db` or the labs.
21. **`Grpc.Tools` cannot run on Alpine.** It ships a prebuilt `protoc` and
    `grpc_csharp_plugin` linked against glibc, and on a musl image they fail with
    `MSB6003 … No such file or directory` — which names the dynamic loader, not the binary,
    and reads as a missing file. Both service Dockerfiles now build on
    `mcr.microsoft.com/dotnet/sdk:10.0.400-noble` and still run on the Alpine runtime: a
    framework-dependent publish is portable IL, so only the code generator needed the other
    libc. Same class as defect 34 — an image tag that cannot work, invisible until something
    actually built it.
22. **Adding a second Kestrel listener changes three things about the first, and none of
    them announces itself.** All three cost a run of the gate and are now defects 40–42:
    declaring any endpoint stops the host honouring `ASPNETCORE_URLS`/`ASPNETCORE_HTTP_PORTS`
    (so the REST API silently vanishes); a TLS endpoint gives `UseHttpsRedirection` a port to
    redirect to, and it will happily send the whole API to the gateway's mutual-TLS port; and
    `AllowedHosts=localhost` rejects a gRPC call whose `:authority` is the Compose service
    name with a bare `400` that the client reports as `Bad gRPC response`. Worth remembering
    as a class: a second listener is a second consumer of settings the first one owns.
23. **The gRPC gate runs under its own Compose project name.**
    `scripts/check-grpc-edge.sh` uses `-p cinerion-grpc-verify` with
    `infrastructure/compose.grpc-verify.yaml`, an overlay whose only effect is to remove
    Control Core's published host port — the workstation already has something on
    `127.0.0.1:5080`, and every request in that gate is made from inside the control zone
    anyway. The gate asserts that the overlay changes nothing else, by comparing the merged
    model against the base one service by service, so it cannot grow into a second
    deployment model. It tears its own project down on any exit and does not touch the
    labs.
24. **`compose run` uses whatever image already exists.** The ingress probe is built
    immediately before it is run for exactly this reason: on the first green run of the gate
    the probe was still the previous revision, which showed up only because a message it
    printed had changed. A probe suite that silently stops testing the code it was changed
    to test is the failure mode an attack suite is most likely to hide behind.
25. **Windows reserves large TCP port ranges at boot, and they move.**
    `netsh int ipv4 show excludedportrange protocol=tcp` showed 5041–5657 excluded this
    session, which covers 5090, 5091 and 5092 — the API port this handover previously told
    you to use and the two the backup and retention gates hardcoded. A bind into one fails
    with `SocketException 10013`, which reads as the service being broken. Both gates now
    take a free port; if you run Control Core by hand, **check the excluded ranges before
    picking a port** rather than trusting a number written down here.
26. **Kestrel will not take a dynamic port on the `localhost` name.** It requires
    `127.0.0.1:0` or `[::1]:0` and says so. `AllowedHosts=localhost` then answers a request
    addressed to the literal with 400. So: bind the literal, address the name.
27. **`ALTER DEFAULT PRIVILEGES` in `0002` grants the application role SELECT, INSERT,
    UPDATE and DELETE on every table created in `ch1` afterwards.** A new migration's
    `GRANT SELECT, INSERT` is therefore a comment, not a control. Write the `REVOKE`.
28. **Backslashes do not survive a heredoc into a scripting language here.** A regex or a
    `\1` backreference written through `python - <<'EOF'` arrives collapsed — `\1` became a
    literal 0x01 in a `sed` expression and the replacement silently became empty. Same class
    as the `.mjs` `\b` collapse the previous session recorded. **Write the script to a file
    and run the file**, or use a raw string; and grep the result with `cat -A` before
    trusting it.
29. **The load rig's window is published, not inferred.** `LOAD WINDOW-OPENED` and
    `LOAD WINDOW-CLOSED` are wall-clock bounds the driver prints. Anything measuring
    alongside it should select by those rather than by poll number or by when data first
    appeared — both were tried, and both were wrong in opposite directions.
31. **Docker fills the disk, and the pipeline fails without saying why.** A strict run
    reached `[11/14]` and reported `gateway-buffer: could not be run` and
    `baseline-load: could not be run` with **no reason at all**. Both harnesses pass on
    their own. What had happened is that the container gates leave anonymous volumes and
    build cache behind — 165 volumes, 7.9 GB, and 7.4 GB of build cache — and the
    workstation was at 97 % of its disk. `docker volume prune -f` and
    `docker builder prune -f` reclaimed 14 GB and the run went through.

    Two things to remember. `docker volume prune` **without `--all` removes only anonymous
    volumes**, so the four named lab volumes — `cinerion_cinerion-postgres`,
    `cinerion_cinerion-identity-db`, `cinerion_cinerion-edge-buffer`,
    `cinerion_cinerion-mqtt-data` — survive it, and with them the seeded realm and the lab
    database. `--all` would take them, and the `ch1-portal-demo` password would have to be
    reset afterwards. And **the VHDX does not shrink**: `df` on the host still reports the
    same free space afterwards, because the space is reclaimed inside Docker's own disk,
    which is where the gates need it.

    `check-verification.mjs` reported nothing because it printed only the FIRST line of a
    failed harness's output, and a shell gate's output begins with a blank line — the
    reason was in the buffer and thrown away one character before it. It now carries the
    harness's `FAIL` lines and its last lines, which is what turns "could not be run" into
    something a reader can act on.

32. **The portal render harness: four things that cost time.** (a) Node's async module
    hooks (`module.register`) intercept `import` but **not** CommonJS `require`, and
    `react-native-safe-area-context` reaches for `react-native` with a bare `require`,
    which then loads the real React Native package and dies on Flow syntax. Switching to
    the synchronous `module.registerHooks` fixes that and breaks jsdom instead, with
    `ERR_VM_MODULE_LINK_FAILURE` from its own CommonJS graph. What works is both routes at
    once: async hooks for ESM, and a seeded `require.cache` entry pointing
    `react-native` at `react-native-web` — the same substitution Metro makes, by the other
    door. (b) **jsdom's `atob` is a method of its window and refuses any other receiver.**
    In a browser `globalThis === window`, so `readTokenClaims`' `globalThis.atob(...)`
    works there and throws here for a reason that has nothing to do with the portal; the
    harness keeps Node's `atob`/`btoa`, which are the same algorithm with no receiver to
    lose. The symptom is a signed-in session whose claims are silently `undefined`, and
    the screen then correctly reporting no cell assignment. (c) **Draining microtasks is
    not the same as letting time pass.** `useObserved` refetches on a one-second
    `setInterval`, so any scenario about the link going away has to wait real time —
    `advance(1400)` — and a harness that reached in and called `refresh()` would be
    testing its own call rather than the screen's cadence. (d) **`artifacts/` is
    git-ignored**, so the captured responses exist only after `dotnet test`; that is the
    whole reason `npm run verification` now runs after the .NET step rather than before
    it.

33. **The ESP32 entry point is compiled now, and it was not before.** Nothing in the
    pipeline built `firmware/esp32/main/app_main.cpp` — ESP-IDF is not installed here — so it
    was checked only by a grep in the policy gate, and **it did not build**: `publish` was
    declared in an anonymous namespace and never defined, and two receive paths were
    unreachable. `firmware/tests/host-stubs` supplies the four ESP-IDF headers it includes and
    `verify.sh` step `[9/14]` compiles it with `-c` under the same warnings-as-errors as
    everything else. It is compiled and **never linked or run**: the loop does not terminate
    and the transport is not here. If you add an ESP-IDF include to that file you must add a
    stub, and if the API is macro-heavy you should put the code in its own translation unit
    outside the host build instead — a stub that disagrees with the real header is coverage
    that looks like coverage. `time_sync.cpp` is exactly that case.
34. **A gate helper that fetches a package on every call measures the package mirror.**
    `buffer_sql` ran `apk add --no-cache sqlite` per query: a measured 3.6–4.1 s, which put a
    drain poll's period at ~5.8 s against a gateway enqueueing every 5.0 s. A check sampling
    at almost the rate of the thing it watches can sit in the wrong phase for its whole
    window. One prebuilt image took it to 1.3 s with no network. Build the query image once.
35. **`check-portal-render.mjs` can take five minutes under container contention.** It
    normally takes about fifteen seconds. Measured at 0.7 s of CPU over five minutes, it is
    **blocked on I/O, not hung**, and it does finish. Do not kill it. Sampling the process's
    CPU time is how to tell the two apart, and it is worth doing before concluding anything.
36. **`check-verification.mjs` does not stop at the first failed harness.** It `continue`s and
    reports every error at the end, so a run that refuses still exercises everything after the
    refusal — which is why the first strict run of this session reached the load harness
    despite failing at the gateway buffer. Read the whole error list, not the first line.
37. **A privilege refusal pre-empts a trigger, and that hides the trigger.** Three checks in
    the record-retention gate expected `CH1 controlled evidence cannot be updated` and met
    `permission denied` instead, because the role holds no `UPDATE`. That is the stronger
    outcome — and it means the trigger's branch is a claim nothing exercised. To test the
    trigger, grant the privilege for exactly that one check, prove the trigger refuses anyway,
    take the grant back, **and assert that you took it back**. A gate that widens a grant and
    fails to narrow it again has left the deployment worse than it found it.
40. **A NOT NULL column is a change to every writer of that table, and the writers are in a
    different project from the migration.** `0014` added `retain_until NOT NULL` to
    `ch1.message_acknowledgements`; `PostgresCinerionStore.Collaboration.cs` never set it, and
    every acknowledgement write against a real database died on `23502` from that commit
    onward. 478 tests, a 31-check gate, an 8-attack suite and a green strict pipeline all
    passed over it, because **no test exercises that method against PostgreSQL**. Before
    adding a NOT NULL column, grep the store for every INSERT into that table. Defect 67.
41. **A seed's idempotency guard decides what a crash loop looks like.** Guarding on the
    FIRST record written means an interrupted run looks complete on the next start, and the
    service comes up healthy with a third of its data — which reads like several broken
    endpoints rather than one broken write. Guarding on the LAST means the retry re-runs
    sections that already succeeded and dies on a duplicate key. Neither is a seed: each
    section has to ask whether its own work is done, and the sentinel has to be written last.
42. **`docker compose up` without `--build` reuses whatever image exists, and it will lie to
    you for an hour.** Two separate diagnoses this session were made against a stale image —
    once chasing an exception that had already been fixed, once reading old line numbers in a
    stack trace. If the answer does not match the source you are reading, check the image
    before you check the logic. Same class as item 24, and it is worth its own number because
    the symptom is "the fix did not work" rather than "the probe is old".
43. **Compose passes only the variables a service DECLARES.** Exporting
    `CINERION_DEMONSTRATION_DATA` in the shell reached nothing: `infrastructure/compose.yaml`
    does not name it, deliberately, so the gate needs its own overlay
    (`compose.demo-verify.yaml`) exactly as the gRPC gate needs one for its ports. The
    symptom was five endpoints answering empty and a seed that had never been asked to run.
44. **Optional data must never be able to stop a controlled service from starting.** The
    demonstration seed threw twice while being written and each time took the host down,
    turning a cosmetic problem into an unavailable service and hiding the cause behind a
    restart loop. It is now caught, reported loudly on the console, and the service starts
    without it — so `npm run demo:data` can say precisely which screens have nothing behind
    them. That is the change that turned a two-hour guess into a one-line answer:
    `scan_events_device_id_fkey`.
39. **The load harness is the workstation's disk canary, and the TAIL LATENCIES are the
    tell.** A strict run refused with *"a measured second carried only 76 messages, below the
    80 collapse floor"*, and a standalone re-run on a quiet machine refused the same way at
    64. Nothing in the ingestion path had changed. Docker had accumulated 32 volumes and
    369 MB of build cache since the session started; `docker volume prune -f` and
    `docker builder prune -f` reclaimed 1.5 GB **inside Docker's own disk**, and the next run
    passed. Every figure moved, and the tails moved most:

    | | Before prune | After |
    |---|---|---|
    | carried | 100.00 msg/s | 100.02 |
    | worst measured second | **64** | **96** |
    | worst backlog | 38 | 5 |
    | ingress p50 / p95 / p99 | 22.6 / 127.1 / 215.8 ms | 15.8 / 24.8 / 40.1 ms |
    | dashboard freshness p95 | 198.9 ms | 54.7 ms |

    Two things worth carrying forward. The **p95 is the diagnostic**: a fivefold tail with an
    unchanged mean is disk pressure, not a code path, and it is visible in the harness's own
    output before anyone reasons about it. And the failing profile said so too —
    `...107,64,136,101` — a dip repaid *exactly* by the second after it, which is a hiccup
    rather than a collapse. The 80 % floor cannot tell those apart, and it was **not** relaxed
    to make a run pass: the machine was fixed instead. Prune before a strict run, not after
    one refuses.
45. **The frozen baseline carries SVG twins of the PNGs the documents embed, and an SVG is
    data.** `docs/baseline/P03_IFV/assets/` holds `cell-state-machine.svg`,
    `prepare-local-commit.svg` and `system-architecture.svg` beside the PNGs. The first of
    those is a transition table with coordinates — eight state boxes, ten paths whose
    endpoints land exactly on a box edge, each followed by its label — and reading it closed
    conflict 30 and defects 66, 69, 70 and 71, all of which had been carried for two sessions
    behind the sentence "CH1-AUT-FDS-0001 references a state diagram this repo carries only
    as an image".

    **The general form is worth more than the instance: "the controlled source does not say"
    is a claim to re-test before it becomes a conflict, because a conflict is where work
    stops.** The other two SVGs have not been mined and may hold as much.

46. **Python's `open(path, 'w')` writes CRLF on Windows, and that silently disarms an exact-match
    string mutation.** Two of `cell:attack`'s eighteen attacks stopped matching the moment a
    patch script rewrote the SCL: `String.replace` found nothing, the file went back
    unchanged, and the gate passed because there was genuinely nothing wrong with it.
    Defect 75. Use `open(path, 'w', newline='')`, or normalise afterwards, and write every
    multi-line mutation in an attack suite as a `\r?\n` regex rather than a literal.

    And the reason it was caught at all: the suite asserts that a mutation CHANGED something
    before judging the gate's answer. **Any attack suite written here needs that assertion**,
    or it will one day report a full score while exercising a subset.

47. **`requirements.json` is a list of OBJECTS with an `id`; its neighbours in the same
    directory are lists of row arrays.** `access.json`, `api_endpoints.json`, `io.json`,
    `tests.json` and `interfaces.json` are rows; `requirements.json` is not. Reading it as
    rows produces a set of `undefined` and every lookup fails as unknown, which is how
    `npm run obligations` refused its own register on its first run. Check the shape before
    writing the reader.

48. **A full ESP-IDF toolchain is already installed on this workstation.**
    `~/.espressif/tools` holds xtensa-esp-elf 15.2.0, riscv32-esp-elf, cmake, ninja, ccache,
    openocd and idf-exe, and `~/.espressif/python_env` holds `idf6.0_py3.11_env` — the whole
    expensive half. What was missing is the framework checkout itself. The previous handover's
    "ESP-IDF is not installed here" was true of `IDF_PATH` and not of the toolchain, and the
    distinction is worth about two gigabytes of download.

    `npm run esp:build` builds the component when `IDF_PATH` is set and `idf.py` is on PATH,
    and **exits 2 with a statement when they are not**. It is deliberately NOT in
    `verify.sh`: an optional step inside a strict pipeline is defect 51's exact shape.

49. **`ProjectOwner` is a role now, and the lab identity holds it.**
    `scripts/provision-portal-identities.sh` grants the demo identity fourteen roles rather
    than thirteen. It changes nothing for that identity in practice — it authors the
    publication package and is therefore refused as its own reviewer whichever capacity it
    holds — but a browser demonstration of the two-person review needs a second identity, and
    always did.

50. **Remove `cinerion-verify-db` when you are done with it.** The throwaway PostgreSQL from
    item 3 survives a `docker volume prune -f` because it is a named container with its own
    anonymous volume in use, and it will sit there holding a port until it is removed. It is
    also the reason `CINERION_POSTGRES_CONNECTION` works between sessions on this machine and
    then suddenly does not.

51. **"The project will not boot and the ports do not work" had TWO causes, and the second
    only appears after you fix the first.** Both were found in this order and the order
    matters, because fixing the first is what made the second visible.

    **(a) Docker Desktop was not running.** Every one of the project's twelve ports read as
    free — 5080, 5090-5092, 8080, 8081, 19006, 55432, 5432, 1883, 4840, 502 — which is the
    tell that distinguishes this from a port conflict: a conflict means something IS bound,
    and nothing was. `./scripts/doctor.sh` names it directly (`Docker daemon is reachable`)
    and is the fastest single check.

    **(b) A stale `wslrelay` holding 5080 AND 8081, reinstated the moment Docker Desktop
    started.** This is item 2's ghost, and it is not gone — it returns with the daemon. The
    signature is exact and worth memorising:

    ```
    Error response from daemon: ports are not available: exposing port TCP
    127.0.0.1:5080 -> 127.0.0.1:0: listen tcp4 127.0.0.1:5080: bind: Only one usage of
    each socket address ... is normally permitted.
    ```

    while `docker ps -a --format '{{.Names}}\t{{.Ports}}' | grep -E "5080|8081"` returns
    **nothing**. One `wslrelay.exe` process held both of the two ports the controlled compose
    model publishes, with no container behind either. `Stop-Process -Id <pid> -Force` released
    them immediately and `docker compose --profile data-lab up -d` then went through
    unchanged. WSL respawns the relay for genuine forwards; killing it drops only the stale
    ones.

    Find it with PowerShell, because `netstat` will not give you the owning image:

    ```powershell
    Get-NetTCPConnection -LocalPort 5080 -State Listen |
      ForEach-Object { Get-Process -Id $_.OwningProcess }
    ```

52. **Windows's reserved TCP ranges moved again, and this time they moved OFF the ports this
    project uses.** Item 25 recorded 5041-5657 excluded, which covered 5090, 5091 and 5092.
    After a reboot the exclusions are 1085-1584, 1712-1811, 5357, 6385-6484, 6638-6737,
    6741-6840, 6875-6974, 8031, 9031 and 50000-50059, and **nothing the project uses is
    excluded**. Re-read the list rather than trusting either number: it is a property of the
    boot, not of the machine, and it has now been observed to move twice.

53. **The four named lab volumes and `cinerion-verify-db` all survive a reboot.**
    `cinerion_cinerion-postgres`, `cinerion_cinerion-identity-db`,
    `cinerion_cinerion-edge-buffer` and `cinerion_cinerion-mqtt-data` were intact, and so was
    the throwaway verification database from item 3 — it was merely `Exited`, and
    `docker start cinerion-verify-db` brought it back on `127.0.0.1:55432` with its fifteen
    migrations and its `cinerion_app` role. **Start it before concluding the connection
    string is wrong**; recreating it costs fifteen migrations and a password rotation for
    nothing.

54. **The boot, verified end to end, and the two URLs that actually answer.** With the daemon
    up and the relay cleared:

    | | | |
    |---|---|---|
    | Control Core | `http://localhost:5080/api/v1/system/health` | `200`, `"status":"Healthy"`, `runtimeProfile: Simulation` |
    | Operator portal | `http://localhost:8081/` | `200` |
    | Same API as `127.0.0.1` | `http://127.0.0.1:5080/api/v1/system/health` | **`400`** |

    That last row is item 2's rule, observed rather than remembered: `AllowedHosts=localhost`
    rejects the literal. **`/health` is not the path** — it answers `404`. The health endpoint
    is `/api/v1/system/health`, and the compose healthcheck is where to read it from rather
    than guess.

55. **ESP-IDF refuses to run under MSys/Git Bash** — `ERROR: MSys/Mingw is not supported`
    from `idf_tools.py` before it does anything at all. Every ESP-IDF command needs
    PowerShell.

56. **The RISC-V toolchain download truncates at ~500 MB on this network, consistently.**
    Three attempts died at 508358689, 508358689 and 499482624 bytes out of 963974138, twice
    followed by `getaddrinfo failed`. It is a cap, not a transient. It blocks `export.ps1`,
    which refuses to activate while ANY declared tool is missing — even though an esp32s3
    build never invokes the RISC-V compiler, which belongs to the ULP coprocessor and this
    firmware has no ULP code.

    Two ways through, neither tried yet: the offline installer at
    `https://dl.espressif.com/dl/esp-idf`, which Espressif's own error message suggests; or
    resume the file with a client that does HTTP range requests
    (`curl -C - -o riscv32-esp-elf-15.2.0_20251204-x86_64-w64-mingw32.zip.tmp <url>`) and
    leave it in `~/.espressif/dist/` under exactly that name, where `idf_tools.py` finds and
    verifies it instead of downloading again.

    **The same network truncates Docker registry pulls.** `docker compose up -d --build`
    hung with no output and `npm run demo:data` failed at
    `mcr.microsoft.com/dotnet/sdk:10.0.400-noble: TLS handshake timeout`. Booting without
    `--build` works from the cached images — but item 42 still stands, so a run that matters
    needs the build to have succeeded.

38. **A fixture that fails silently turns a gate into decoration.** A `NOT NULL` violation in
    the record-retention fixture was swallowed, and the gate then reported *"the retention
    role cannot dispose of a role assignment whose seven years have not ended"* as a **PASS**
    — against an empty register, where the `DELETE` matched nothing. Count what a fixture
    established, by name, before anything depends on it.

---


57. **The other two controlled SVGs are mined, and item 45 happened again — twice.**
    `assets/prepare-local-commit.svg` and `assets/system-architecture.svg` were the two
    files item 45 said had never been read. Both are authorities, not pictures, and reading
    them produced defects 76 and 77 and a component nobody had built.

    The sequence diagram's geometry is exact and the gate depends on that rather than on
    tolerance: four lifelines at x = 200, 540, 890, 1300; every message endpoint lands
    **exactly** on one of them; message labels sit at exactly `pathY - 10` and step notes at
    exactly `stepY + 30`. Nothing is a nearest match. `npm run commit:map` parses it into
    seven steps, seven messages (three amber, which is the diagram's marking for a locally
    guarded exchange) and five controlled notes, and reconciles
    `traceability/local-commit-sequence-r01.json` against it. `npm run commit:attack` is 24
    attacks, 0 holes.

    The architecture diagram is six layer bands at disjoint y ranges, fourteen component
    boxes each wholly inside one band, four vertical connectors between adjacent band edges
    and one dashed purple isolation edge. `npm run arch:map` reconciles
    `traceability/system-architecture-r01.json` against it; `npm run arch:attack` is 17
    attacks, 0 holes.

    **What the architecture diagram turns out to say, which prose did not.** There are
    exactly four inter-layer connectors and no others. The experience layer has ONE, and it
    goes to the domain layer — there is no connector from it to the protocol or local bands
    at all. The only connector leaving the domain band departs in CommandGuard's column, is
    amber, and skips the research band entirely. The research band has no connector in
    either direction, so *"isolated credentials · no production route"* is the topology
    rather than a caption — and the gate checks it over the real `.csproj` graph, refusing
    a project reference either way across `simulators/`.

58. **A controlled component nobody had built: the Local HMI.** The architecture diagram
    draws `Local HMI — identity · state · diagnostics` in the local guarded execution band.
    `docs/baseline/P03_IFV/data/io.json` declares `CH1-IO-HMI-0001` (local display, SPI/UART,
    "Status/prompt", diagnostic behaviour "No remote-start control") and
    `firmware/pinmap/esp32s3-r01.json` assigns it five GPIOs. `conditioned_io.hpp` defines
    the signal constant. **Nothing references it.** The component is wired and silent.

    It is declared `notImplemented` with a reason in the architecture map rather than
    stubbed, and the gate refuses that declaration without a reason and a `recordedIn`. A
    display showing a plausible idle screen it was not driven to show would be a
    fake-success surface at the one place a person stands next to moving equipment.

59. **The ESP-IDF toolchain is now complete, and the network cap in item 56 is gone.**
    `riscv32-esp-elf esp-15.2.0_20251204` downloaded in full on the second way item 56
    suggested: `curl -C -` resuming `~/.espressif/dist/…zip.tmp`, then renamed to the final
    `.zip` name so `idf_tools.py install riscv32-esp-elf` found it already downloaded.
    963974138 bytes, SHA-256 `c61488aa…23c3d`, matching `tools.json` exactly. The same
    session pulled four .NET base images from `mcr.microsoft.com` without trouble, so the
    ~500 MB truncation was a property of that day rather than of this network.

60. **ESP-IDF v6.0.3's component manager is broken by pydantic 2.12, and the failure names
    neither.** `idf.py set-target` dies inside `prepare_components` with
    `AttributeError: 'NoneType' object has no attribute 'validation_alias'`, preceded by
    `WARNING: Cannot load idf.py extension "component_manager_ext"`. `idf-component-manager
    2.4.0` against `pydantic 2.12.0`. Fixed in the IDF virtual environment, not in this
    repository:

    ```powershell
    & C:\Users\<user>\.espressif\python_env\idf6.0_py3.11_env\Scripts\python.exe -m pip install "pydantic<2.12"
    ```

    `IDF_COMPONENT_MANAGER=0` also gets past it and is safe here — this project has no
    `idf_component.yml` — but it is a workaround and the pin is the fix.

61. **`npm run esp:build` cannot work on Windows, and now says so instead of blaming the
    toolchain.** Three separate reasons, all observed against a correctly installed
    ESP-IDF: `export.ps1` defines `idf.py` as a **PowerShell function**, not an executable,
    so `command -v idf.py` finds nothing; `IDF_PATH` holds `C:\esp\esp-idf`, which `[ -d ]`
    cannot resolve, so the preflight reported "IDF_PATH is unset or does not name a
    directory" for a toolchain that was fully present; and invoking `tools/idf.py` from Git
    Bash picks the system interpreter and dies with `No module named 'rich_click'`.

    `scripts/check-esp-idf-build.ps1` is the Windows sibling and is the one that runs.
    `npm run esp:build:windows`, or directly:

    ```powershell
    . C:\esp\esp-idf\export.ps1
    .\scripts\check-esp-idf-build.ps1
    ```

    Do **not** set `$ErrorActionPreference = 'Stop'` around `idf.py`: Windows PowerShell 5.1
    wraps every stderr line a native executable writes in an ErrorRecord, and `idf.py`
    writes its configuration report there, so 'Stop' fails the gate on a build that
    succeeded. Exit codes are checked explicitly instead.

    `firmware/esp32/sdkconfig` and `sdkconfig.old` are generated by `set-target` and are now
    gitignored; the controlled inputs are `main/CMakeLists.txt` and the pin map.

62. **DO NOT EDIT A SHELL SCRIPT WHILE IT IS RUNNING.** `sh` reads a script incrementally by
    byte offset. `scripts/verify.sh` was edited to wire in two new gates while a strict run
    was in `[13/14]`; inserting ~1,100 bytes shifted every later offset and the shell resumed
    mid-token, printing `./scripts/verify.sh: line 179: g: command not found`, skipping
    `[14/14]` entirely, and **still exiting 0**. The file on disk was fine — `sh -n` passed —
    so nothing about the repository looked wrong afterwards. The run was void from that point
    and had to be repeated on a quiescent tree. The same hazard applies to any long harness
    under `scripts/`.

63. **A gate that greps a source for a symbol will match that symbol in a COMMENT.** The
    first run of `attack-local-commit-sequence.mjs` found it: the binding `acknowledgements`
    was deleted from the response projection and `npm run commit:map` passed, because the
    XML documentation two lines above still said the word. A comment describing a control is
    not the control. `check-local-commit-sequence.mjs` now requires every bound symbol to
    appear on a line that is not a comment, and the attack exercises exactly that.

    It is the second time an attack suite has paid for itself immediately — defect 75 was
    the first — and both holes were in the gate the same session had just written.

64. **The identity lab needs `--env-file`, and the identity-db volume can outlive the
    secrets file.** `docker compose` reads `.env` beside the compose file, never
    `.env.local` — so `docker compose -f infrastructure/compose.yaml --profile identity-lab
    up` gives Keycloak the literal default `local-bootstrap-required` and it dies with
    `FATAL: password authentication failed for user "keycloak"`, which reads like a broken
    realm and is nothing of the kind. `infrastructure/README.md` and QUICKSTART both
    already give the right command; this is written down because the failure names the
    database rather than the invocation:

    ```bash
    docker compose --env-file infrastructure/.env.local -f infrastructure/compose.yaml       --profile data-lab --profile identity-lab up -d --wait
    ```

    There is a second, slower trap behind it. `cinerion_cinerion-identity-db` was created on
    2026-08-07 and `infrastructure/.env.local` was regenerated on 2026-08-18, so the
    persisted `keycloak` role can hold a password the current secrets file has never seen —
    and a volume that survives `docker volume prune` survives that divergence too. Realigning
    it is one statement as the role's owner, and is not destructive:
    `ALTER ROLE keycloak WITH PASSWORD '<the value in .env.local>'`.

    **Honest caveat:** both were done in that order on 2026-09-16 and the stack then came up
    healthy. Which of the two was load-bearing was not established, because the realignment
    happened before the invocation was corrected. If this recurs, correct the invocation
    FIRST and see whether that alone is enough.

65. **The full lab, verified end to end on 2026-09-16 after the portal build was fixed.**
    All six containers healthy with the command above. `http://localhost:8081` answers 200
    and the served bundle contains `localhost:8180/realms/cinerion`; the response carries
    `connect-src 'self' http://localhost:5080 http://localhost:8180`; the realm's discovery
    document reports that same string as its `issuer`; and the authorization endpoint
    answers **302** to the portal's own client id and redirect URI rather than an error.
    So the portal can now begin a real sign-in. **Typing the password is still the one class
    of evidence that needs a person at the keyboard** — item 11 is unchanged.


66. **jsdom answers 0 for `document.documentElement.clientWidth`, and that silently chose
    a branch for every render scenario.** `react-native-web`'s `Dimensions` reads the
    document element's client box and nothing else; jsdom performs no layout, so every
    screen in the render harness measured a zero-width window and `AppShell` took its
    `compact` branch — for 45 scenarios across three sessions. The desktop rail an operator
    actually uses had never been rendered by anything in CI, which is how a rail that
    clipped its own navigation list survived. `installBrowserEnvironment` now defines both
    properties and a scenario may declare its own viewport. **Setting `window.innerWidth` is
    NOT enough and looks like it should be**: `Dimensions` never reads it.

67. **A step-up grant is bound to the SESSION that obtained it.** `X-CH1-Session` must be
    the same value on the request that obtains the grant and on the request that spends it,
    or the answer is `STEP_UP_SESSION_MISMATCH`. Obvious once read; it cost a run of the
    commit-loop gate because the two halves used different session identifiers.

68. **A prepared command lives between 5 and 120 seconds.** `CMD_TTL_INVALID` refuses
    anything outside that, so a gate asking for a comfortable ten-minute window is refused
    by the control rather than accommodated by it.

69. **curl on Windows is built against schannel, and schannel cannot import a PEM client
    certificate.** It answers `Failed to import cert file … 0x80092002` and CLOSES THE
    CONNECTION before presenting anything. This matters far more than it sounds: an attack
    suite checking that a bad certificate is refused sees the connection fail, records a
    pass, and exercises the server not at all. Use PKCS#12 — `--cert-type P12 --cert
    file.p12:password` — and add `--ssl-revoke-best-effort`, because schannel also refuses a
    certificate whose revocation status it cannot determine and a laboratory authority
    publishes no CRL. **And assert a POSITIVE control first**: `check-local-commit-loop.sh`
    proves the ENROLLED certificate reaches an authorised operation before judging any
    refusal, and says the refusals establish nothing when it cannot.

70. **curl here is a Windows binary and does not resolve the POSIX absolute path Git Bash
    hands it.** A repository-relative path is both portable and unambiguous, and it avoids
    the second trap: a Windows absolute path already contains a colon, and
    `--cert path:password` splits on one. The same conversion problem goes the other way for
    .NET processes, which need `cygpath -w` — `MSYS_NO_PATHCONV=1` is right for openssl
    subjects and wrong for certificate paths, so convert explicitly where it is wanted.

71. **Item 28, three times in one session.** A backslash written into a heredoc arrives
    collapsed: `\b` in a regex became a literal backspace (0x08) INSIDE a regular
    expression in an emitted `.mjs` gate, and a shell line continuation became a literal
    `\n` in two shell scripts. Each looked correct in the diff. **Write every patch script
    with a file-writing tool rather than `cat > file <<'EOF'`**, and `grep` the result with
    `cat -A` before trusting it. The cheapest tell is that the emitted line is suspiciously
    long: a continuation that did not survive joins two lines into one.

72. **`npm run policy` requires the CONTROLLED compose model to pass every `EXPO_PUBLIC_*`
    the portal Dockerfile declares.** Adding a build argument to the lab overlay alone is
    refused, and correctly: Metro inlines these at build time, so an argument the model does
    not pass produces an image carrying the Dockerfile default for its whole life. Pass it
    with an empty default rather than omitting it — the decision then lives in the model
    where a reader will see it.

73. **Enrolment is idempotent-refusing, not idempotent.** `POST /devices/{id}/enrolment` with
    a certificate already enrolled answers `DEVICE_CERTIFICATE_UNCHANGED`, which makes
    re-enrolment a decision rather than a repeat. A gate that runs twice against the same
    database must treat that as success; a gate that treats it as failure is testing its own
    fixture.

74. **The lab database and `cinerion-verify-db` drift apart on `cinerion_app`'s password.**
    24 API tests failed with `28P01: password authentication failed` against the throwaway
    database while the lab was perfectly healthy. Realigning is one statement as the owner
    and is not destructive, exactly as item 64 records for Keycloak:
    `docker exec cinerion-verify-db psql -U cinerion_owner -d cinerion -c "ALTER ROLE
    cinerion_app LOGIN PASSWORD '<the value in .env.local>';"`

75. **Do not put `Maximum Pool Size` in `CINERION_POSTGRES_CONNECTION` when running the
    tests.** `PostgresConnectionBudgetTests` asserts what the UNSTATED default is, so stating
    one fails a test that is measuring the absence. The startup warning about the default
    overcommitting the server is informational and is not a reason to set it.

76. **The load harness is still the disk canary, and it is also a CONTENTION canary.** Two
    runs refused during this session — "57 publications behind" and "the load driver produced
    no measurement at all" — and both were caused by running it concurrently with something
    else this session had started. Run alone on a quiet machine it carried 99.98 msg/s with a
    worst second of 93 and p95 40.8 ms. Item 39's advice stands and gains a clause: prune
    before a strict run, and do not run anything beside it.


77. **`npm run lab:check` is the cheapest evidence in this repository and takes two
    seconds.** Eleven read-only checks against the RUNNING lab: the Simulation profile,
    development identity off, the device listener enabled, `127.0.0.1` answered 400, the
    portal served, its `connect-src` naming every origin its bundle addresses, the stand-in
    controller answering and disclaiming a physical edge, and — the one it exists for — a
    device identity reaching Control Core over mutual TLS and being answered **404** for a
    command that does not exist. A 404 there proves the certificate was accepted, the
    enrolled record was resolved under row-level security and the command register was read.
    A 500 proves the request never got that far, which is what a completely broken device
    authentication path looked like while every other gate was green.

    **Run it after `npm run lab:up` and before believing anything about the lab.**



78. **The controlled position on AI is written down in five places and nowhere obvious.**
    It cost an hour to assemble and is worth never assembling again:

    | Where | What it says |
    |---|---|
    | `data/access.json` | `Approve or command via AI` — role **None**, strength **Not applicable**, **Explicitly prohibited**. The only row in that register that grants nothing to nobody |
    | `data/requirements.json` | `CH1-AI-FR-0001` (Must, Inspection) and `CH1-AI-FR-0002` (Must, **Test**) — "AI shall not approve, release, authenticate, locally confirm or command physical equipment" |
    | `data/ai_usage.json` | Eight rows, **all about document drafting**, each with a reviewer and a verification. `CH1-PMG-AIU-0005` is "Prohibited authority", status "**Baseline rule**" |
    | `data/adrs.json` | `CH1-SWA-ADR-0010`, **Accepted**: "Keep AI outside authentication, approval and command paths" |
    | `data/threats.json` | `CH1-CYB-THR-0018`, "AI prompt injection through evidence", mitigated by "read-only isolation, provenance and human review" |

    Three things follow that are not obvious from any one of them. **The product contains no
    AI service and never did** — no AI operation among `api_endpoints.json`'s 54, no AI
    screen among `screens.json`'s 22, no AI entity, and no AI component among the fourteen
    the controlled architecture diagram draws. **`ai_usage.json` is about how the DOCUMENTS
    were produced**, not about what the platform is, which is the distinction that makes the
    whole question answerable. And `CH1-VVT-TC-0065` is therefore **not executable while the
    prohibition holds**, because it presupposes AI output — recorded as conflict 37 rather
    than closed.

    `npm run ai:prohibition` enforces all of it and reads the rule FROM those files, so if
    any of them changes the gate refuses and says the rule has moved.

79. **A gate that searches for ABSENCE needs a positive control, and this is the general
    form of item 71.** A gate looking for a forbidden string prints the same output whether
    the tree is clean or the matcher is dead — and item 71 records a backslash arriving
    collapsed *three times in one session*, which is exactly how a matcher dies quietly.
    Defect 75's rule ("assert the mutation CHANGED something") is the same idea pointed at
    an attack suite; this is it pointed at the gate.

    `check-ai-authority-prohibition.mjs` runs all seven of its matcher classes against
    synthetic buffers that DO contain what they refuse, **before** it examines the
    repository, and exits without drawing any conclusion if one fails to fire. Two of its 23
    attacks blind those matchers deliberately and are caught by nothing else. Any future gate
    here whose finding is "nothing was found" should do the same.

80. **A substring test over identifiers matches inside words, and `MaintenanceEngineer`
    contains a-i.** The first run of the AI gate refused it twice — once as a role constant,
    once as a realm role — because `/ai/i` matched inside "MaintenAnce". Identifiers are now
    split on case and punctuation boundaries and compared as whole words, so `AiAssistant`
    splits to `[Ai, Assistant]` and is refused while `MaintenanceEngineer` splits to
    `[Maintenance, Engineer]` and is not. Item 63's mistake in a different costume: a pattern
    matching something that was never the thing being looked for.

81. **The verification-case counters in this document's own state table had drifted, and the
    map is the authority.** The table said `partially_automated` = 44 while
    `verification-map.json` held 45, at `HEAD`, before this session changed anything — so
    the first correction written here was itself wrong. Count them:

    ```bash
    node -e "const m=require('./traceability/verification-map.json');const c={};for(const x of m.cases)c[x.executionStatus]=(c[x.executionStatus]||0)+1;console.log(c)"
    ```

    `npm run verification` prints the same distribution on every run and that print is the
    authority, not any cell in this file. Third instance of the rule the portal's operation
    count already established: **a figure a gate derives from the source cannot drift away
    from the source, and a figure typed into a table can and did.**

---

82. **A CRLF working copy on this workstation is NOT a finding, and chasing it wastes an
    hour.** Editing tools here rewrite a pure-LF file to CRLF wholesale: `scripts/verify.sh`
    went from 0 CRLF / 209 LF to 228 CRLF / 0 LF from a nineteen-line insertion. That looks
    alarming, because a shebang ending in CR fails on Linux with "bad interpreter: no such
    file or directory" and CI is where the authoritative gate runs.

    **It is already controlled, and the control was verified rather than assumed.**
    `.gitattributes` declares `* text=auto eol=lf`, so Git normalises on staging. Measured
    by staging the file and reading the blob back:

    ```bash
    git add scripts/verify.sh
    git show :scripts/verify.sh | node -e "let s='';process.stdin.on('data',d=>s+=d).on('end',()=>console.log((s.match(/\r\n/g)||[]).length))"
    git reset -q scripts/verify.sh
    ```

    — which prints `0`. The committed blob is LF, `git diff` compares normalised content so
    the change stays reviewable (19 lines, not 228), and `git diff --stat`'s warning
    *"CRLF will be replaced by LF the next time Git touches it"* is that control announcing
    itself rather than a problem.

    Two things follow. **Do not normalise the working copy to "fix" this** — it is churn, and
    doing it to a shell script that is currently running is item 62's exact hazard. And
    **item 46 still stands for CONTENT**: a patch script matching `\n` against a CRLF file
    still matches nothing, which is why every multi-line mutation in an attack suite here is
    a `\r?\n` regex. The distinction is that line endings in the working copy are Git's
    problem and already solved; line endings inside a string a script is matching are yours.

---

83. **A GREEN STRICT RUN LEAVES THE LAB STOPPED, and the next thing you run says Control
    Core is not answering.** Observed immediately after a clean `./scripts/verify.sh
    --strict` (exit 0, all 15 step markers): `npm run lab:check` refused with
    *"Control Core is not answering at http://localhost:5080"*, and `docker ps` showed only
    `identity`, `postgres`, `identity-db` and the throwaway database still up. Nothing had
    broken. The pipeline had stopped them.

    **The mechanism, measured rather than guessed.** Exactly three services in
    `infrastructure/compose.yaml` have **no profile**:

    | Profile | Services |
    |---|---|
    | *(none)* | `control-core`, `edge-link`, `operator-portal` |
    | `data-lab` | `postgres` |
    | `identity-lab` | `identity-db`, `identity` |
    | `protocol-lab` | `mqtt`, `opcua-plc`, `modbus-plc` |

    `scripts/check-baseline-load.sh` step `[2/8]` runs, on the DEFAULT project name and
    deliberately so:

    ```sh
    docker compose -f infrastructure/compose.yaml --profile protocol-lab down --remove-orphans
    ```

    `docker compose down` with a profile selected brings down the services in that profile
    **and every service that has no profile at all** — which is precisely Control Core,
    EdgeLink and the portal. `--remove-orphans` then takes `cell-confirmer`, which is
    defined in `compose.lab.yaml` and so is not in the model this invocation was given. The
    profiled labs survive, which is why the wreckage looks selective and puzzling: the
    databases and Keycloak are still healthy while everything in front of them is gone.

    **The gate's intent is right and its comment is not.** It wants the shared protocol lab
    and any stray gateway stopped so the measurement is of the service, and it raises its own
    isolated project (`cinerion-load-verify`) for the thing it measures — so none of this
    affects the figures. But the comment above that line reads *"Anything it stops was left
    running by a gate that had already finished with it"*, and that is the part that is
    untrue: it stopped a lab a person had raised and was using.

    **What to do.** Re-raise it — `npm run lab:up && npm run lab:check` — and do not go
    looking for a fault. Reported and NOT fixed here, deliberately: the narrower teardown is
    to `docker rm -f` the three named protocol containers instead of relying on
    `down --profile`, and changing a step inside the measurement gate obliges a fresh run of
    the load canary alone on a quiet machine (items 39 and 76) to be able to claim anything
    about it. Doing that at the end of a session that has just gone green, for a
    developer-convenience fix, would trade real evidence for tidiness.

---

84. **jsdom cannot see layout, so look at the snapshots in a real browser.** To photograph
    every screen:

    ```bash
    CINERION_RENDER_SNAPSHOT_DIR=artifacts/render-snapshots/pipeline npm run render:portal
    npm run layout:portal
    ```

    Each snapshot is plain HTML you can open directly. The in-app browser pane on this
    workstation is only ~293 px wide and scales a desktop viewport down to ~18 %, so for a
    readable picture use headless Chrome instead, with a throwaway profile:
    `chrome --headless=new --user-data-dir=<temp> --window-size=1600,1000 --screenshot=out.png <url>`.
    A file opened from disk in the pane is a static snapshot and ignores viewport emulation;
    serve it over `http://localhost` if you want the pane to lay it out at a desktop width.

85. **On Windows, a file an attack suite has just written may be briefly locked by something
    else.** Seen as `UNKNOWN: unknown error, open` with errno -4094. `scripts/lib/write-settled.mjs`
    is the fix; any NEW attack suite should import `writeFile` from it rather than from
    `node:fs/promises`. If a suite ever does crash, check `git status` before believing the next
    gate: a crashed restore leaves a controlled file changed, and the next gate then reports the
    attack's mutation as though it were the repository.

86. **Comments here have traps, and the header pass checked for all of them.** In the portal,
    `check-repository-policy.mjs` refuses the two controller-only route strings **even inside
    comments**; in firmware it refuses the GPIO driver function names the same way; and the C++
    host builds run with `-Werror -pedantic`, which fails on `/*` inside a comment and on a
    trailing backslash (which silently comments out the next line). The scratch script that
    applied the headers refused all of these before writing a file.

87. **Test the release package on EMPTY volumes, isolated from the lab.** `npm run lab:down`
    (removes containers, keeps the four named volumes), unzip with `Expand-Archive` into an
    ordinary folder - **not** this session's scratch folder, where PostgreSQL's `postgres` user
    cannot read bind-mounted files - then run the installer with
    `COMPOSE_PROJECT_NAME=cinerion-installtest`. The environment variable overrides the compose
    file's `name: cinerion`, so every volume is `cinerion-installtest_*` and the real lab's data
    is untouched (check `docker volume inspect ... CreatedAt` before and after). Tear down with the
    same project name and `down -v --rmi local`, then `npm run lab:up` from the repository.

88. **A realm change is not verified until Keycloak has imported it into an empty database.**
    Keycloak imports with `IGNORE_EXISTING`, so an existing lab never re-reads the file: two
    import-breaking defects (90, 91) sat in the realm for two days and six weeks while every gate
    and the only lab stayed green. The policy gate catches the two known shapes; the proof is
    item 87.

89. **This workstation's Git lives in `C:\Program Files\Git\Gitd`, and the only `bash` on PATH
    is WSL's (`C:\Windows\System32\bash.exe`).** Anything that needs Git's `sh` on Windows should
    find it by walking up from `git.exe`, as `install.ps1` does, and must never use System32's
    bash - it runs in a different Linux with different paths.

90. **A release package can carry the lab's data.** `npm run lab:export` writes `lab-snapshot/`
    (git-ignored: a data-only `pg_dump` of `ch1` with `--disable-triggers`, rows per table
    counted from the dump itself, and when/which commit). `npm run package:release` adds it to
    the zip beside the commit and into the manifest; `lab-up.sh` loads it with
    `import-lab-data.sh` after PostgreSQL is up and before Control Core first starts, in one
    transaction, **only into a database with no row in `ch1`**, then checks every table's
    count. Before packaging, grep the unzipped dump for every `.env.local` value of 8+
    characters, and prove the grep works by planting one value in a copy first - `ch1` holds
    no secrets today, and that should stay checked, not assumed.

91. **`lab:check` has twelve checks now; the twelfth is that telemetry is being STORED.** It
    reads through `compose exec postgres` (still read-only) and gives the next 5-second tick
    up to 30 s. Its negative control is
    `CINERION_CONFIRMER_CONTROLLER_ID=CH1-DEV-FIELD-0001 sh scripts/check-lab.sh`, which must
    FAIL on that check.

## Commits

| Commit | Subject |
|---|---|
| `b36c03c` | Baseline: Prototype 1 hardened working copy |
| `101f19c` | Keycloak authority port; unimplemented persistence settings marked |
| `fa98498` | Make the .NET solution restore, compile and execute its tests |
| `79ec1f2` | OIDC identity path produces a valid authorisation context |
| `55ca25c` | Complete the OIDC contract against a live Keycloak import |
| `4de1018` | Purpose-bound step-up authentication |
| `12920f2` | Portal connected to Control Core over OIDC |
| `1300955` | Audit and quality screens driven from Control Core |
| `67472ab` | Portal migration finished, sample-data module deleted |
| `587686f` | Projects, sites and cells as persistent domain records |
| `cf9c19c` | PREPARE bound to step-up; guarded chain exercised over HTTP |
| `1723dbd` | Test runs and nonconformities as real records with disposition |
| `16d1d7c` | ForgeFlow: revisions, BOM, routes, work orders, assets |
| `c730b18` | Audit chain linked per project to match the schema |
| `80fd881` | Row-level security made effective; database made reachable |
| `086408c` | Storage mode as an explicit fail-closed decision |
| `20a4aa6` | Devices and calibration certificates; client-asserted calibration rejected |
| `e86a355` | Physical part given the permanent identity CH1-MFG-FR-0002 requires |
| `a9991ae` | PostgreSQL repository implemented |
| `1b6965b` | Prototype 2 progress, decisions and remaining work recorded |
| `b0e9cb8` | Telemetry, alarms and acknowledgement that cannot clear a cause |
| `9169387` | ContextBridge; CH1-VVT-TC-0109 closed with both sides present |
| `15ae124` | ResourceOrchestrator; two broken PostgreSQL update statements fixed |
| `de6a6de` | ResearchBench; R&D isolation enforced by the schema |
| `f834eba` | Identity administration against live Keycloak, least privilege proven |
| `a363cfc` | Device PKI: enrolment, revocation, and a revoked device that is actually stopped |
| `848abcb` | Control room, collaboration and resource screens; alarm/message separation enforced at compile time; portal sign-in fixed |
| `bab53b7` | Handover for a new session — resume steps, corrected scope, twelfth conflict |
| `3683f72` | TOTP, passkeys and physical credentials; phishing-resistant step-up reachable |
| `fe17fb2` | Report and scan-event foundations; schema, domain and services |
| `0e11cd5` | ReportForge and Field Companion scan endpoints |
| `9b5fafe` | Portal step-up flow; reserve/release as the first consequential mutations |
| `c0d5f28` | Credential screen, and re-authentication offered where the refusal asks |
| `e3ffb2b` | Security administration screen; passkey registration gap reported |
| `889cdcc` | Corrected the implemented-operation count from 51 to 50 |
| `b4c405a` | Verification gates that actually gate: migration set, PowerShell entry point, dependency disposition; `verify.sh --strict` green |
| `11502fd` | Controlled verification cases bound to executable tests, counted and enforced in both directions |
| `4915ca8` | Endpoint tests for the nine untested operations; part release bound to a redeemed step-up; tamper detection actually exercised |
| `0f849e5` | Protocol and transport conformance suites; a reference alternate provider; the boundary demonstrated rather than declared |
| `538c12e` | CH1-UX-SCR-0006 work-order board; the fourteenth conflict — no controlled operation reads a work order |
| `570d2c7` | CH1-UX-SCR-0007 part genealogy, and an authority gap it exposed on the way |
| `c7e4fd1` | Screen coverage measured by a gate; CH1-UX-SCR-0018 device and configuration management |
| `284654b` | Portal contracts checked against responses the service actually sent |
| `0a8d45c` | Every declared portal shape captured from a real response; the gate made complete |
| `767720f` | CH1-UX-SCR-0003, 0001 and 0009; the seventeenth conflict; five screens named as unbuildable |
| `c9d4c7c` | Backup, integrity verification, restore and rollback; CH1-VVT-TC-0081 closed on a real restore |
| `cf5f9c3` | The MQTT edge made live: EdgeLink's second operational adapter, verified against a real broker |
| `d5c73f5` | ESP32-S3 firmware speaking the CH1 envelope; two implementations pinned to one literal |
| `2f9c45c` | The PLC command handshake executed; two state machines that could not leave a state |
| `26ec187` | The OPC UA edge made live: EdgeLink's third operational adapter, an S7 runtime stand-in, and twelve endpoint probes that each refuse |
| `cfdd4de` | Handover: the commit hash for the OPC UA edge |
| `c889e0b` | The Modbus edge made live; CH1-VVT-TC-0022 closed on all three protocols, and the named threat refused structurally |
| `c2591f0` | Handover: the commit hash for the Modbus edge |
| `6c0577c` | Telemetry retention, downsampling and authorised disposal; the application role's unlogged delete authority revoked |
| `1b4e3fc` | Handover: the commit hash for telemetry retention |
| `65449e5` | CH1-VVT-TC-0080 executed: the core demonstration completed on a network proven to have no public egress |
| `52d27fa` | CH1-COM-IF-0003 made live: EdgeLink publishes into Control Core over internal gRPC with mutual TLS, and the command path runs on PostgreSQL for the first time |
| `50d0f4e` | CH1-VVT-TC-0093 closed: the 24-hour gateway buffer, on disk, surviving the gateway that wrote it |
| `42ad840` | CH1-NFR-PER-0001 measured for the first time; the baseline load harness exists and the requirement is NOT met |
| `6fb4922` | fix(persistence): defect 50 — the connection pool ended with the request that opened it |
| `c435e80` | fix(gates): defects 51 and 52 — a strict run that skipped, and two gates bound to ports Windows had taken |
| `1dea019` | fix(gates): dynamic binding needs the loopback literal, and the host header needs the name |
| `f1ac43f` | feat(performance): CH1-VVT-TC-0090 is met and executed — 100.00 msg/s carried, 63 devices, 252 live channels |
| `2c9024d` | feat(performance): CH1-VVT-TC-0091 met and executed — dashboard freshness p95 77.7 ms under the baseline load |
| `8151164` | feat(identity): RoleAssignment was a declared entity with no table, so role history was verifiable and not readable |
| `244c7e4` | feat(documents): CH1-DOC-FR-0004's publication pipeline is implemented — 52 of 54 controlled operations |
| `1e1bfad` | feat(edge): the OPC UA adapter sources controller state, so an unanswered permissive is observable end to end |
| `1356d1b` | feat(performance): CH1-VVT-TC-0092 measured on the platform half — prepared-command acknowledgement p95 47.6 ms |
| `bb32e81` | fix(gates): defect 55 — the OPC UA sample check counted log lines and was racing a reconnect |
| `10447a2` | docs(handover): the strict pipeline is green end to end, and the three runs it took are the record |
| `6b0f196` | feat(api): five owner-approved reads, so the four unbuildable screens can be built |
| `d13c910` | feat(portal): all 22 declared screens are built, and all 22 are rendered in CI |
| `7fc4c9b` | feat(identity): both portal identities are provisioned, and between them every screen is reachable |
| `0099074` | feat(operations): the lab stack comes up end to end, and an existing schema can be brought forward |
| `4b42c64` | fix(gates): defect 56 — the buffer gate asked whether the buffer was empty, not whether the outage drained |
| `2e7b3ad` | feat(firmware): the conditioned I/O layer, a pin map reconciled against the controlled table, and an entry point that builds |
| `61ce100` | feat(retention): the two registers whose declared retention is absolute can now actually reach the end of it |
| `1b73b4c` | docs(handover): the conditioned I/O layer, the node bus, retention, and the load harness as a disk canary |
| `b74c320` | feat(firmware): the Arduino I/O node exists, and its link stops being report-only by convention |
| `818051d` | fix(gates): defect 62 — a gate reported a safety violation it could not actually see |
| `2139a81` | fix(gates): defect 63 — the load gate was measuring the pipeline, not the service |
| `612a7d6` | docs(handover): the strict pipeline is green at 2139a81, and the four refusals it took |
| `bb143e9` | feat(demonstration): a dataset so no screen is empty, and the cell RUN as a simulation |
| `a8121b1` | fix(demonstration): defect 67 — a NOT NULL column I added had no writer |
| `e38accd` | docs(handover): the demonstration dataset, the cell run as a simulation, and defects 64-67 |
| `908264f` | fix(gates): defect 68 — the buffer gate measured the backlog after the thing being measured had gone |

---
| `7f30301` | fix(portal): the workspace rail clipped its own navigation, and nothing in CI had ever rendered it |
| `18b0a88` | fix(portal): the session that said AUTHENTICATED beside HTTP_401, and a realm nobody had compared with its file |
| `67749ee` | feat(operations): the controlled sequence completes, every role sees the acts it owns, and identifiers became navigable |
| `7f7fe4b` | feat(quality): a bound instrument adapter can append its own readings, which the controlled authority always said it could |


## Defects found and fixed

Every one was pre-existing. The pattern held without exception: **anything that had
never actually been executed was broken.**

1. **Restore failed** — `Microsoft.OpenApi` 2.3.0 carried CVE-2026-49451 (High). Pinned to 2.7.5. `NU1903` not suppressed.
2. **44 × CS0246** — no test file declared `using Xunit`.
3. **CS0108** — `Scheme` const hid `AuthenticationHandler<T>.Scheme` and silently rebound in-class uses.
4. **16 analyzer errors** — fixed on merit; the one suppression (`CA1707`) is path-scoped to tests because test names carry requirement IDs.
5. **`dotnet test` discovered zero tests and exited 0** — a gate reporting success while running nothing.
6. **`bootstrap-local.ps1`** used a .NET Core-only API, so secrets could not be generated on Windows PowerShell.
7. **Keycloak 26 user profile** — unmanaged attributes disabled by default silently discarded `ch1_project`, `ch1_cell`, `ch1_actor_kind`.
8. **Portal client omitted the `basic` scope** — tokens carried no `sub`, so every request failed `AUTH_IDENTITY_REQUIRED`.
9. **Compose healthcheck could never pass** — requested `127.0.0.1` while `AllowedHosts=localhost`; `operator-portal` waits on that condition, so the stack could not start.
10. **Malformed request body returned 500** — misattributed a client fault to the server, with no stable code. Now `400 CH1_REQUEST_BODY_INVALID`.
11. **Control Core shared no network with PostgreSQL** — could never reach the database.
12. **PostgreSQL declared an inert host port** — attached only to an internal network.
13. **Row-level security was completely inert** — the bootstrap role is a superuser and superusers bypass RLS, including `FORCE`. All 26 project-isolation policies had no effect. Migration `0002` adds the non-superuser `cinerion_app` role.
14. **Client-asserted calibration** — `CH1-QMS-FR-0006` requires expired instruments to be blocked, but validity came from a boolean in the request body.
15. **Audit hash broke on database round-trip** — the hash covered a timestamp at .NET tick resolution while `timestamptz` keeps microseconds; a valid chain failed after storage, indistinguishable from tampering.
16. **Seed overwrote persisted state** — every restart reset a part from `Hold` to `InProcess`, discarding a quality decision.
17. **Genealogy provenance lied** — reported an in-memory store while running on PostgreSQL.
18. **The data-lab database could never be correct** — `compose.yaml` mounted only migration `0001` as an init script, so a fresh lab database had no `cinerion_app` role and therefore inert row-level security, which is defect 13 reappearing on every new volume. All migrations are now mounted, and Control Core refuses to start against a database behind its own schema, naming the migration.
19. **`.env.example` said persistence was not implemented** — untrue since `a9991ae`, and it told a reader to disregard the two settings that actually select the store.
20. **Uniqueness conflicts reported `400`** — only `CONCURRENCY_CONFLICT` and `IDEMPOTENCY_CONFLICT` mapped to `409`, so `PROJECT_CODE_CONFLICT`, `REVISION_CODE_CONFLICT` and `WORK_ORDER_NUMBER_CONFLICT` all came back as bad requests. A client could not distinguish "you sent something malformed" from "someone else already holds that identifier and retrying will not help". Any code containing `CONFLICT` is now `409`. A refusal that comes from a record's own state machine rather than a collision between two records stays `400` — `ALARM_ALREADY_ACKNOWLEDGED` is not a conflict with another row. The portal branches only on 401/403/404/501 and surfaces the stable `code` otherwise, so nothing downstream depended on the old status.
21. **Every command state transition on PostgreSQL failed with a 500.** `SaveCommandAsync` used one parameter list for both its branches: the `INSERT` declared 24 parameters and the `UPDATE` referenced 6 of them. PostgreSQL infers a parameter's type from where it is used, so one that is never used has no type to infer and the statement is rejected at parse time with `42P18 could not determine data type of parameter $2`. Credential proof, local commit and cancel were all affected. It was invisible twice over: the command tests run on the in-memory store, and on PostgreSQL the path is unreachable over HTTP because a restored cell correctly reports no permissive, so `PREPARE` is refused before an update is ever attempted. Confirmed by issuing the exact statement shape through `psql` as `cinerion_app`, then fixed by giving each branch its own parameters. The same mistake had just been made in the new reservation code and was caught the same way.
22. **No gate would have caught 21.** `PostgresStatementShapeTests` now extracts every SQL statement the store issues and (a) checks that the declared parameters form a contiguous run from `$1`, and (b) asks PostgreSQL to `PREPARE` each one. Both checks fail on the old shape. The second is skipped without `CINERION_POSTGRES_CONNECTION`; the first always runs.

23. **Portal sign-in failed silently wherever the popup was blocked — fixed.** `SessionProvider` uses `AuthSession.useAuthRequest`, whose web implementation opens the authorisation endpoint in a **popup**. When the popup is refused, `expo-auth-session` falls back to a same-tab redirect — and nothing survives that page load. Observed directly: after Keycloak redirected back to `http://localhost:19006/?code=…&state=…`, `sessionStorage` and `localStorage` were **both empty** and `window.opener` was null, so neither the PKCE `code_verifier` nor the request `state` existed to match the response against. The authorisation code is stranded, `exchangeCodeAsync` is never reached, and the user is returned to "Authentication required" with **`session.error` left undefined** — so the interface reports nothing at all. Reproduced three times, including once with the request fully settled before the click, so it is not a user-gesture timing artifact; the console reports `ERR_WEB_BROWSER_BLOCKED` every time. The memory-only *token* decision is sound and is not the cause: a code verifier and a state are single-use flow artifacts that PKCE expects to survive the redirect, and they are a different thing from a token. Two defects really: the flow cannot complete without a popup, and when it fails it says nothing.

    **Fixed.** On the web the browser is now sent to the provider in this tab, which is the ordinary OIDC web flow and cannot be blocked; native keeps `promptAsync` and its system-browser session, where there is no popup to block. The `state` and PKCE `code_verifier` are stored in `sessionStorage` for the duration of the redirect and consumed on return, so the tab can match and complete the exchange. This is **not** a relaxation of the memory-only token decision: a verifier is not a credential — it is worthless without the matching code, both are single-use, and RFC 7636 requires the client to still hold it when the redirect lands. The access token is still never persisted. Every outcome is now reported instead of discarded — a provider refusal, a response with no matching request, and a **state mismatch, which is the CSRF check and is refused rather than exchanged**. Verified end to end: signed in as `ch1-portal-demo` through the real Keycloak login page in a pane that blocks popups, reaching `SESSION: AUTHENTICATED` with the project, cell and roles the token carries. The spent code is then taken out of the address bar through the router — `history.replaceState` alone is undone, because the router rewrites the URL from its own state while it mounts.

Two further defects were **introduced by the new screens and caught by running them**, which
is the whole argument for the method: both typechecked, linted and looked right.

24. **A read receipt could never be recorded.** `MARK AS READ` was gated on
    `isCurrentObservation`, which demands `Live` or `Simulated`. The thread endpoint
    declares no freshness — there is nothing about a stored conversation to be stale in
    the way a sampled reading is — so the value was always `Unknown` and the control was
    disabled permanently. Clicking it sent no request at all, which is exactly how it
    escaped notice: nothing failed, nothing was logged, the button simply did nothing.
    `isLinkCurrent` now asks the question that response can actually answer — has the last
    poll reached the server — while alarms and telemetry, which do declare freshness, keep
    the stricter gate.
25. **An object nobody had written about yet reported a failure.** A thread exists only
    once its first message is posted, so the read returns `404`, and the screen rendered
    that as `UNEXPECTED CLIENT FAILURE` with a `DISCONNECTED` marker — telling an operator
    the link was broken when the honest answer was that the conversation had not started.
    Two causes: `useObserved` flattened every refusal to a string, so `explainFailure`
    could not classify it and fell through to its catch-all; and the screen treated a
    `404` here as an error rather than as the empty state. `Observed` now carries the
    refusal itself alongside the message, and the screen reports `NOT STARTED` with an
    explanation that posting opens the thread. The same flattening still affects the two
    pre-existing screens that predate this change; left alone to keep this diff to one
    subsystem, but it is the same defect and worth closing.

Three further pre-existing defects were found while making the verification gates run,
and all three are the same shape: **a check that was not checking what it claimed to.**

26. **A fresh laboratory database was one migration behind, and nothing said so.**
    `infrastructure/compose.yaml` mounted `0001`…`0008` as init scripts but not
    `0009_reports_and_scan_events.sql`. Proven rather than inferred: an isolated stack
    raised from that same file under a different Compose project name produced 31
    controlled tables with neither `ch1.reports` nor `ch1.scan_events`. This is defect 18
    returning by the same route — the mount list is hand-maintained while the migration
    directory is not, so the two drift apart silently.
27. **The startup probe that exists to catch exactly that had stopped at 0008.**
    `CinerionDataSource.RequiredColumns` names one column per migration so that a database
    behind the build fails at start and is told which migration to apply. It carried no
    entry for `0009`, so all eight probes passed against that 31-table database and
    Control Core would have started against it — then failed on the first
    `POST /api/v1/reports` or `POST /api/v1/parts/scan-events`, in front of an operator,
    which is precisely the outcome the probe exists to prevent. Both fixed and re-verified
    on a running system: the fresh database now raises 33 controlled tables and satisfies
    all ten probes. **A gate now holds them together** —
    `scripts/check-database-migrations.mjs` (`npm run migrations`, step `[6/10]`) requires
    every migration to be mounted in lexical order and every table a migration creates to
    be named by the startup probe, with `0001` and `0002` exempt for stated reasons.
    Proven by running it against the pre-fix tree, where it reports all three findings.
28. **`scripts/verify.ps1` reported success whatever its gates did.**
    `$ErrorActionPreference = 'Stop'` does not govern native commands in Windows
    PowerShell 5.1: a gate exiting non-zero sets `$LASTEXITCODE` and the script carries
    straight on to the next line, ending with "verification completed". Confirmed
    directly — `& cmd /c "exit 3"` under `Stop` continued and left `$LASTEXITCODE=3`.
    Every gate now runs through an `Invoke-Gate` helper that throws on a non-zero exit,
    proven by making one fail. This is the same class as defect 5, on the entry point the
    authoring workstation actually uses.
29. **The CI dependency-audit step could never have passed.**
    `npm audit --omit=dev --audit-level=high --json > artifacts/npm-audit.json` exits
    non-zero whenever npm reports anything at that level, GitHub Actions runs each bash
    step with `-e`, and this dependency graph has carried unfixable transitive advisories
    throughout — so the step failed the workflow on every run and never produced the
    artefact it existed to produce. Reproduced locally: exit 1, 14 high and 7 moderate
    across 21 affected packages. Raising `--audit-level`, or appending `|| true`, would
    have converted a security gate into a formality. Replaced by
    `scripts/check-dependency-audit.mjs` (`npm run audit:deps`), which reconciles the
    audit against `traceability/dependency-disposition.json` and still fails on anything
    undispositioned, expired, or runtime-reachable at high or above — the *dependency
    disposition* CH1-VVT-TC-0126 asks a release to carry alongside its SBOM. Each of
    those four rules was proven by breaking it.

    The 21 affected packages reduce to **three root advisories**, and neither package can
    be fixed today: `image-size` is reached only through Metro and **has no patched
    release in existence** — the advisory range is `<=2.0.2` and 2.0.2 is the latest
    published version — and `uuid@7.0.3` is reached only through `xcode`, which
    `expo prebuild` uses and this repository never invokes. Both were searched for in
    `apps/operator-portal/dist` and neither reaches the exported artefact. They are
    recorded as accepted build-toolchain risks expiring **2026-11-12**. *That acceptance
    is an owner decision to confirm; the gate makes it expire rather than persist.*

Building the part-genealogy screen found one more, also pre-existing:

31. **A Viewer could read a part's entire evidence graph.** `api_endpoints.json` gives
    `GET /api/v1/parts/{partId}/genealogy` to "Engineer, Inspector or Auditor", and
    `QualityService.FindPartAsync` checked project scope and no role at all. Every other
    read surface in this service checks one — telemetry, alarms and resources all refuse
    an identity without a dashboard role — so this was an omission rather than a
    decision. What it disclosed is the whole quality history of a part in one request:
    measured values against their limits, the instrument and its calibration record, the
    operator who performed the work, open nonconformities and the release. Now
    `CanReadGenealogy` requires one of the three roles, and a caller without one is
    answered exactly as for a part that does not exist. Proven by running the new test
    against the pre-fix code, where it reports `NotFound` expected and `OK` observed.

Writing the missing endpoint tests found three more, all pre-existing:

30. **Part release read a session claim instead of redeeming a step-up.**
    `api_endpoints.json` makes "step-up MFA" the control on `POST /release-records` and
    access.json says the same, but the endpoint redeemed nothing: `PartRecord.ReleaseBy`
    simply required `AuthenticationStrength >= StepUpPhishingResistant` on the actor.
    That is a standing session property — precisely the thing this platform already
    refuses to trust, because `scripts/check-repository-policy.mjs` fails the build if
    the realm ever maps `ch1_auth_strength`, a stored strength attribute being a
    permanent step-up. Release was reading the same property from the other end.
    Three real consequences: the phishing-resistant route the previous commit made
    reachable **could not actually be used to release a part**, because
    `StepUpPurpose.PartRelease` existed and no endpoint redeemed it; the release was
    neither single-use nor purpose-bound, unlike every other consequential operation; and
    the audit chain recorded no link between a release and the re-authentication that
    authorised it. `POST /release-records` now redeems a `PartRelease` grant at
    phishing-resistant strength in the same shape as NCR disposition and work-order
    release; `ReleaseBy` takes the grant and refuses one that was never redeemed, was
    granted for another purpose, or belongs to another identity; and the audit event
    names it. **Independent part release is reachable over the passkey route for the
    first time, and it is exercised end to end.**
31. **Cancelling a prepared command was not idempotent.** `api_endpoints.json` makes
    "idempotent cancel" the control on `POST /commands/{commandId}/cancel`; the second
    call returned `400 CMD_STATE_INVALID`. This matters more than it reads: a client
    whose first cancel timed out and retried would receive an error it could reasonably
    read as *the command is still armed*, which is the one conclusion that must never be
    reached by accident. A repeat now returns the same terminal state at the same
    version, carrying the reason first recorded — one effect, one audit event, and a
    caller supplying a different reason on the retry is shown the original rather than
    overwriting it.
32. **The core of CH1-VVT-TC-0051 had never been exercised.** The case states that an
    altered or deleted event *breaks verification and is reported*. Both the .NET and
    TypeScript suites verified only that a chain nobody had touched verified — which
    shows that hashing is self-consistent and nothing whatever about tamper evidence.
    Neither implementation could even be asked the question, because verification was an
    instance method over the chain's own private list. `AuditChain.Verify(events)` and
    `verifyEvents(events)` now verify a sequence a reader holds, which is the situation
    the requirement is actually about, and the new tests alter an event, delete an event,
    and reseal an altered event with a recomputed hash — each breaks verification at the
    position reported.

Three fake-success or unreachable defects from the original audit are closed:
`POST /test-runs` (returned an ID it never stored), measurements ignoring their run,
and `POST /ncrs/{id}/dispositions` being a 501 that left `CloseNcrAfterPassingRetest`
unreachable.

Building the live MQTT edge found four more, all pre-existing:

33. **The broker's topic ACL implemented one of the two edges it governs.** `infrastructure/mosquitto/config/acl` carried the device patterns of CH1-COM-IF-0005 and **nothing for EdgeLink**, so only the `pattern` block matched the gateway - granting it its own non-existent device paths. CH1-COM-IF-0004 was therefore unimplementable, and the way it failed is the dangerous part. Measured on a running broker with the rules absent: the gateway publishing a command was refused outright, and its telemetry subscription was **accepted and granted QoS 1 while delivering zero readings**. An adapter would look connected and subscribed while receiving nothing, which reads as a broken device rather than a missing grant. With the gateway block present the same publish is authorised and the same reading arrives; both halves were run before and after.
34. **Neither .NET service image could be built.** `services/control-core/Dockerfile` and `services/edge-link/Dockerfile` both named `mcr.microsoft.com/dotnet/sdk:10.0.10-alpine3.24`, which does not exist: SDK images are tagged with the **SDK** version (10.0.4xx), not the runtime version. The runtime and aspnet tags at 10.0.10 are correct, so only the build stage was wrong - and since GitHub Actions has never run and nothing built these locally, nothing had ever discovered it. `docker compose config` validates the model, not the images. Fixed to `10.0.400-alpine3.24`, and `npm run mqtt:verify` now builds the EdgeLink image every time it runs, so a broken base image cannot go unnoticed again.
35. **The MQTT broker declared a host port it cannot have.** `ports: - "127.0.0.1:8883:8883"` on a container attached only to the `control` network, which is `internal: true`. Docker silently ignores the mapping: `docker port` reports nothing and `docker inspect` shows an empty binding. This is **defect 12 repeating on a second service** - the same inert declaration PostgreSQL carried. Removed, with the reason stated: the control zone is internal by design and anything speaking to the broker joins that network, as `edge-link` does.
36. **The policy gate's private-key rule had no laboratory exemption.** `infrastructure/secrets/` was already exempt from the *secret-path* rule for the stated reason that it is git-ignored and excluded from packaging, but the *private-key extension* rule was absolute - so the moment anything actually generated a `.key` there, the documented bootstrap workflow and `./scripts/verify.sh` became mutually exclusive. That is the position the `.env.local` exemption had already resolved once. The same exemption now applies to both rules, and it is exactly as narrow: a key in `services/edge-link/` and a key in `infrastructure/` outside `secrets/` were both still refused when tried.

Building the CH1-COM-IF-0003 edge found one more pre-existing defect:

39. **A cell reported its freshness as a literal.** `GET /api/v1/cells/{cellId}/state`
    rendered `freshness: "Simulated"`, `quality: "Good"` and `sourceTimestamp:
    DateTimeOffset.UtcNow` as constants in the projection, and `SaveCellAsync` wrote the
    same three as literals inside its SQL statement — `'Simulated'`, `'Good'`, `now()`.
    `FindCellAsync` did not read the columns back at all. The consequence is the one
    CH1-MON-FR-0003 exists to prevent: a cell whose controller had said nothing since a
    restart weeks earlier was byte-for-byte indistinguishable from one reporting at that
    moment, and the page whose job is to keep live, stale, disconnected, simulated,
    maintenance and unknown apart could not tell any of them apart. It was invisible
    because the answer was always plausible. Freshness is now computed from when the cell
    was last heard from — `Unknown` when no controller has ever reported, `Stale` once a
    report has aged out, and otherwise whatever the report declared, never upgraded. The
    three values are parameters of `SaveCellAsync` rather than text in its statement,
    because a value written into SQL is a claim no reader can check.

Three further defects were **introduced by this change and caught by running the gate**,
which is the whole argument for raising both services rather than reasoning about them.
Each is the same shape: adding a second listener silently altered something about the first.

40. **The REST API disappeared.** Declaring any Kestrel endpoint in `ConfigureKestrel` makes
    the host stop honouring `ASPNETCORE_URLS` and `ASPNETCORE_HTTP_PORTS`, and it says so
    only in a warning — `Overriding address(es) 'http://*:8080'`. Control Core came up
    listening on the mutual-TLS port alone; every HTTP request failed and the container
    healthcheck could never pass. The controlled REST ports are now restated alongside the
    ingress, read from the same settings the host would otherwise have used.
41. **The API then redirected onto the gateway's port.** With the first fix in place the
    service listened on both, and `UseHttpsRedirection` — which had been a harmless no-op
    for as long as there was no TLS endpoint — found one and began answering every request
    with `307 → https://…:8443`. That is the mutually authenticated gateway interface,
    which requires a client certificate no browser holds: the portal would have been
    redirected off the API entirely. The redirect target is now taken from configuration
    and the middleware is applied only when a deployment states one, so it can never again
    infer a port belonging to a different interface.
42. **Then the service refused its own healthcheck.** `AllowedHosts=localhost` is a
    deliberate setting and host filtering is one global middleware, so a gRPC call carrying
    the Compose service name as its `:authority` was answered `400` before reaching any
    handler — reported by the client as `Bad gRPC response. HTTP status code: 400`, which
    reads like a protocol fault and is nothing of the kind. **The first fix for it was
    wrong**, and worth recording: appending the extra host to `options.AllowedHosts`
    suppressed the framework's own *post*-configure step, which fills the list only while it
    is still empty, leaving `control-core` as the sole permitted host and `localhost`
    rejected — `400 Bad Request - Invalid Hostname` for the healthcheck and every portal
    request. The whole list is now stated explicitly, and the one extra name is taken from
    the common name of the service's own certificate rather than from a free-text setting.

The portal render harness found the next one on its first day, and it is the reason that
harness exists:

47. **Two screens read a cell as fully permissive on the strength of a default value.**
    `CH1-UX-SCR-0016` and `CH1-UX-SCR-0008` each counted the six interlock booleans and
    rendered `6 / 6` — the overview additionally in **green**, through a `permissiveTone`
    that returned `good` when every entry was valid. Neither read `permissivesReported`.
    The captured cell state is exactly the dangerous case CH1-COM-IF-0003 was built to keep
    apart: every interlock `true` and **no controller has ever answered**, because proto3
    leaves an unset boolean false and a gateway that populates the interlocks and forgets
    the flag sends precisely that message. The domain already resolves such a cell as not
    permissive whatever the fields say, and `GET /cells/{id}/state` already carried both
    `permissivesReported` and `deferredCheckCodes`; the interface simply ignored them, so
    the one reading an operator must never be given — a fully ready cell, in green, on the
    strength of a default — was what both screens produced. **Found by rendering rather
    than by reading**: the scenarios were written first, and the failure printed the
    rendered `6 / 6`. The rule now lives in one place, `src/api/permissives.ts`, so the two
    screens cannot disagree about it, and each states what an unanswered permissive means
    and names the deferred check codes behind it. Both screens held their own copy of the
    counting logic before this, which is how they came to be wrong in the same way.

48. **Four response shapes the contract gate was not reading.** `AuditPage` and
    `ChainVerification` were declared inside `audit.tsx`, and `DirectoryPage` and
    `DirectoryUser` inside `security.tsx`. `scripts/check-portal-contracts.mjs` reads only
    `apps/operator-portal/src/api/contracts.ts`, so all four were compared against nothing
    and appeared in no total — a property named wrongly in any of them would typecheck
    perfectly and render `undefined` at runtime, which is the precise defect that gate
    exists to catch and had already caught twice elsewhere. The same shape as the
    `opcua-edge` hole in the verification gate: a declaration nobody reconciles wearing the
    same clothes as one that is. The gate now reads the type argument of every
    `useObserved<T>` and `useControlledAction<T>` in the route sources; all four shapes are
    declared in the contract source and captured from real responses, taking the reconciled
    count from 39 to **43 of 43**. **Attacking the extension found it weak**, which is the
    more useful half: putting `interface AuditPage` back on the screen still passed, because
    the name was still exported from `contracts.ts` and the check was satisfied by a
    declaration the screen no longer used. A local declaration shadows the import,
    typechecks identically and is reconciled against nothing — the original defect wearing
    the fix as a disguise. The gate refuses that too now, and the same attack fails by name.

49. **The connection pool was entitled to ask for more than the database would ever
    grant.** Npgsql's pool defaults to 100 and PostgreSQL to `max_connections = 100` with
    three held back for superusers, so **an unconfigured deployment was already over by
    three** — and nothing stated a pool size anywhere: not `infrastructure/compose.yaml`,
    not any of the six harness scripts. The consequence is not a slow service but a broken
    one: the pool opens connections until the server refuses, and that refusal reaches the
    caller as a failed request rather than as a wait for one of the ninety-seven it could
    have had. **Invisible until something offers enough load to reach it**, which is why it
    survived every gate — the CH1-NFR-PER-0001 rig had been producing it for two sessions
    as the opaque `TRANSPORT_Unknown`, and it only became readable once the harness was
    taught to print what the service was throwing: `NpgsqlException: Failed to connect`
    mixed in with genuine pool timeouts. **The response is proportionate to who chose the
    number**, which is the part worth keeping: a deployment that *states* a pool larger
    than the server grants has asked for something impossible and is refused at startup by
    name; one that states nothing inherited a default it never picked and is given a pool
    that fits, with the cap printed so nobody has to guess it happened. Refusing outright
    would have punished every correct-enough deployment — and broken all six harnesses —
    for a number nobody chose. All three paths were driven against a real database: the
    unstated pool caps at 97 and starts, a stated 500 refuses by name, and a stated 40
    starts silently.

---



50. **The connection pool ended with the request that opened it.**
    `CinerionDataSource` was registered per request — correctly, because the project scope
    it applies is per request — and it also constructed its own `NpgsqlDataSource` in its
    constructor and disposed it at the end of the scope. `NpgsqlDataSource` **is** the pool,
    so nothing was ever pooled: every request built a private pool, opened fresh physical
    connections into it at the full 13.3 ms of TCP, startup and authentication, and made
    PostgreSQL fork a backend process for each. A telemetry publication takes three
    connections and the load rig runs 256 requests in flight. It also made defect 49's
    connection budget unenforceable, because a cap on a private per-request pool bounds
    nothing `max_connections` cares about — a hundred concurrent requests were each entitled
    to the whole server. **Invisible to every existing test**: a pool that works is
    indistinguishable from one that does not until something offers enough load. The fix is
    a `CinerionConnectionPool` singleton that the per-request wrapper borrows; the scope
    stays per request and no store method changed. Gates written first and then attacked:
    `PostgresConnectionReuseTests` measures backends with `pg_backend_pid()` rather than
    reasoning about lifetimes, and keeps the defect itself as a test so the measurement is
    known to be capable of failing; `PostgresStorageRegistrationTests` resolves the real
    service graph, because every reuse test would still pass if the host stopped sharing the
    pool. Restoring the defect fails both by name: *"two request scopes were served by
    backends 529 and 531"*. **This was the ingest ceiling.** 36.95 msg/s became 99.63 on the
    strength of this change alone.

51. **`./scripts/verify.sh --strict` reported a failed harness as a skip.** Strictness did
    not travel into step `[11/14]`: `check-verification.mjs` reads its OWN arguments to
    decide whether a harness that could not be run is an error or a stated local skip, so a
    strict pipeline invoking it plainly downgraded a genuine failure to `SKIPPED locally` and
    still exited 0. Observed, not theorised — this session's first strict run printed
    `SKIPPED locally: backup-restore: could not be run` and then reported the pipeline
    complete. The same line was missing from `verify.ps1`. **A gate that approves rather than
    refuses is the failure mode the whole method exists to prevent.**

52. **Two gates were bound to ports Windows had taken.** `check-backup-restore.sh` and
    `check-telemetry-retention.sh` bound Control Core to fixed ports 5091 and 5092, and
    Windows had reserved **5041–5657** for Hyper-V at boot. Kestrel failed with
    `SocketException 10013` and it read as the service being broken rather than as the port
    being unavailable. The excluded ranges are dynamic and move between reboots, so no fixed
    number is safe: both now bind port 0 and read the port back from the service's own
    startup log. Two further facts had to hold at once, and each cost a run — Kestrel refuses
    a dynamic port on the `localhost` name outright (*"You must either bind to 127.0.0.1:0 or
    [::1]:0"*), while `AllowedHosts=localhost` answers a request addressed to the literal
    with 400. So the service **binds** `127.0.0.1:0` and is **addressed** as
    `http://localhost:<port>`.

53. **A migration whose `GRANT` was a comment.** `0012` said "SELECT and INSERT only", and
    `0002` sets `ALTER DEFAULT PRIVILEGES IN SCHEMA ch1 GRANT SELECT, INSERT, UPDATE, DELETE
    ON TABLES` — so `cinerion_app` held all four from the moment the table existed and
    granting two of them again changed nothing. Found by the attack test, which saw the
    `UPDATE` refused by the immutability **trigger** rather than by an absent privilege: the
    trigger holding a line the grant was supposed to have held first. **The class matters
    more than the instance: every controlled table created since `0002` inherits UPDATE and
    DELETE for the application role unless it revokes them, and only `0010` ever did.**
    `0012` and `0013` now revoke explicitly, and the test reads the catalogue rather than
    inferring the grant from a refusal.

### Two measurement defects in the rig, which are not defects in the product

Recorded because both made the product look worse than it was, and because the same shape
will recur.

- **The rig could not offer the rate it announced.** Each publisher computed its next due
  time as *now plus the period*, so every `Task.Delay` overshoot — up to the 15.6 ms Windows
  timer tick — was lost for good. Over 66 seconds that cost 0.4 %: the driver offered
  99.6 msg/s while announcing itself configured for 100, and the service was failed for not
  carrying a load nobody had given it.
- **The first acknowledgement-latency measurement measured refusals.** Placed after the
  conformance suite, it met a guard that suite's ADP-05 had left `Prepared` for five minutes,
  and reported a fast p95 of 3.09 ms with `accepted=0`.

Both were caught for the same reason: **the harness reports what it OFFERED and what was
ACCEPTED beside what it measured.** A measurement that reports only its result cannot be
told from one that measured the wrong thing.


54. **A failed harness reported no reason.** `check-verification.mjs` printed only the
    first line of a failing harness's output, and a shell gate's output begins with a
    blank line — so a strict run refused with `gateway-buffer: could not be run ()` and
    `baseline-load: could not be run ()`, the reason present in the buffer and discarded
    one character before it. The actual cause was the workstation's disk: the container
    gates had left 165 anonymous volumes and 7.4 GB of build cache behind, and Docker had
    no room to raise another stack. Nothing was wrong with either harness — both pass on
    their own — and the pipeline that refused them could not say so. The message now
    carries the harness's `FAIL` lines and its last lines. Found by the strictness fix in
    defect 51, which is what made the run refuse at all instead of printing a skip.

55. **A gate that counted log lines was racing a reconnect.** `check-opcua-edge.sh`
    asserted exactly three "first sample" lines from the OPC UA monitored items, and a
    strict run reported six. Nothing about the adapter had changed. The adapter reconnects
    twice in a normal run and both are meant to happen — the worker reconciles it at the top
    of its loop, and ADP-09 reconciles it again precisely to prove that reconnection replays
    nothing — and each reconnection re-establishes the subscription and legitimately
    re-delivers a first sample per channel. Six is correct; the check was asserting whether
    the second set had arrived before the log was read, and had been passing on winning that
    race. It now counts the three distinct CHANNELS, which is the property it was for, and
    reports both figures so a reader sees the re-delivery rather than wondering why the
    number moved.
56. **The gateway buffer gate asked whether the buffer was empty, not whether the outage
    drained.** A strict run at `0099074` refused with *"1 record(s) are still held after the
    link returned"*, while every other check in that harness passed and the same harness
    passed standalone. The buffer is write-through — `IngressPublisher` enqueues every
    observation and a drain loop wakes once a second to deliver it — so a HEALTHY gateway
    holds a freshly written record part of the time. Measured rather than argued: **empty on
    16 of 20 observations, peak residue 1**, which is exactly the record the run refused on.
    The check now names the outage backlog by its high-water sequence at the moment the link
    returned and requires every record at or below it to arrive; and because relaxing that
    alone would let a stalled drain pass, the buffer must separately be **observed empty at
    least once**, since a healthy buffer is empty most of the time and a stalled one never
    is. `buffer_sql` also ran `apk add sqlite` over the network on every call, a measured
    3.6–4.1 s, putting the poll period at ~5.8 s against a 5.0 s enqueue cadence; one
    prebuilt image took it to 1.3 s with no network.
57. **`firmware/esp32` could never have linked, and nothing had ever tried.** `publish` was
    declared in an anonymous namespace and odr-used by the heartbeat and acknowledgement
    paths, and never defined. `on_command` and `on_serial_frame` were both defined and never
    called, so the command receive path and the RS-485 receive path were each entirely
    unreachable. No gate had ever compiled the file — ESP-IDF is not installed here — so it
    was checked only by a grep in the policy gate. All three surfaced on the first host
    compile, against four stubs in `firmware/tests/host-stubs`. The entry point is now built
    by `verify.sh` step `[9/14]` under the same warnings-as-errors as every other host
    binary. `publish` has a definition that counts the message as undelivered and says so; it
    does not report a delivery it did not perform.
58. **The CH1 envelope claimed a clock the controller did not have.** `ch1_envelope.cpp`
    wrote the literal `"Synchronised"` into `timeQuality` on every message, directly beneath
    a comment saying a controller whose clock has not been disciplined must say so rather
    than claim otherwise — while `wall_clock_milliseconds()` returned `-1` and the same
    firmware refused every prepared command as `CONTROLLER_TIME_NOT_TRUSTED`. CH1-COM-ICD-0001
    requires time quality to be visible so audit decisions are not silently made on invalid
    time, and CH1-COM-FR-0009 requires the heartbeat to report it; a constant is not a report.
    Every encoder now takes it, `TimeSource` produces it, the byte-for-byte vector the .NET
    twin pins is unchanged because the reference message is the disciplined form, and a new
    test proves the two forms differ in exactly one field.
95. **Keycloak gave the realm's users a new random ID on every fresh install.** That ID is the
    `sub` Control Core records as the actor, so records moved to another PC would have pointed
    at users who don't exist there. The three users now carry fixed IDs (the ones the working
    lab already had, so it is unchanged: `npm run realm:drift` reports 0 differences). Nothing
    in today's data references them yet; the point is that nothing written later can be
    orphaned by a move.

94. **The simulated telemetry had been thrown away since 2026-09-17 15:14 - every sample - and
    every check stayed green.** `enrol-cell-confirmer.sh` declared one channel,
    `CH1-CH-TEMP-01`, which is not in the channel catalogue; Control Core refuses a sample on
    any channel the device didn't declare, and logged
    `did not declare channel 'temperature' in degC` every 5 seconds for two days. Found while
    making the package carry the data: the newest telemetry row was two days old. The
    enrolment now declares the catalogue's four channels (temperature, humidity, position,
    vibration_rms). A lab enrolled the old way is repaired automatically: the script reads the
    stored manifest (read-only, from the database - the device endpoint's view leaves the
    manifest out) and, if it's stale, issues the controller a new certificate from the existing
    authority (`bootstrap-device-pki.sh --reissue-controller`), re-enrols it through the same
    controlled operation, and restarts the stand-in. The first version of that check looked
    for the channel in the device endpoint's view, never found it, and rotated the certificate
    on **every** run - caught by running the script twice and comparing the certificate's
    hash. On the working lab: telemetry stored again (75,317 rows → growing, current
    timestamps), 0 refusals, a second run keeps the certificate. `lab:check` now checks for it
    (resuming item 91). The dump for the package was scanned for all seven `.env.local` values
    with a positive control (a planted value is found): none present, and no key or
    certificate block.

93. **The Windows installer's log missed everything the lab printed, and an upgrade could lock
    the lab out of its own data.** Windows PowerShell 5.1 keeps a native program's output out of
    `Start-Transcript`; the lab scripts now run through `Invoke-Sh`, which pipes their output
    in (547 lines instead of 64, still no secret in it). A newer version in a new folder has no
    `.env.local` while the old volumes were built with the old one; both installers now stop
    before changing anything in that case.

92. **Every re-run reported a false FAIL for the stand-in controller's enrolment.** The script
    looked for `DEVICE_CERTIFICATE_UNCHANGED` in busybox wget's error output, which holds only
    "400 Bad Request" and never the body. It now reads the device record first and skips
    enrolment when the thumbprint already matches (`openssl x509 -fingerprint -sha256`, the
    same lowercase SHA-256 the server computes).

91. **The realm's identity-admin client description was 505 characters; Keycloak's column holds
    255.** Present since 2026-08-09, two days after the only identity database was created, so no
    import had ever tried to store it. Shortened to 252; the full text is in
    `infrastructure/keycloak/README.md`; `npm run policy` refuses any realm string over 255.

90. **Keycloak refused the controlled realm on every fresh install.** A note written into the
    JSON as `"_sessionLifetimeNote"` on 2026-09-17; Keycloak's import rejects unknown fields and
    the identity provider never starts. Invisible to the existing lab until its identity container
    was recreated - which `lab:down` does. Moved to `infrastructure/keycloak/README.md`;
    `npm run policy` refuses any `_` key in the realm.

89. **`npm run package:release` could not work on this workstation, twice over.** It needed `zip`
    (absent), and npm on Windows runs scripts through cmd.exe, where `./scripts/x.sh` is not a
    command - so `package:release`, `doctor`, `verify` and `simulate:cell` had never run from
    npm here. Packaging now uses `git archive` (exactly the committed tree, refuses a dirty tree,
    re-verifies every checksum after unpacking) and the four scripts say `sh scripts/...`.

88. **`bootstrap-local` wrote five of the seven secrets the lab needs.** `CINERION_APP_PASSWORD`
    and `CINERION_PORTAL_DEMO_PASSWORD` had been added by hand on the one workstation that had run
    the lab. Both bootstraps now write all seven, top up an older file without changing an existing
    value, and guarantee the demo password passes the realm policy (0 of 200 failed each).

87. **The gateway-buffer gate looked once, after a fixed 40 s, and a busy machine was slower
    than that.** The final strict run of 2026-09-18 refused at `[11/14]` with "no bounded
    back-off is evidenced in the gateway's log". The same commit, run alone minutes later,
    passed all 22 checks with 6 back-off waits and 6 distinct bounds. Only header comments had
    touched EdgeLink since the previous green run, so this was timing: the back-off line is
    written only after a publish has actually failed, and under the pipeline's load the
    gateway had not yet tried and failed when the single look happened. The gate now polls for
    the evidence for up to 90 s more, **with the assertion unchanged** - a line must appear AND
    its bound must grow - and prints how long it waited. Item 39's rule held: the floor was
    not relaxed to make a run pass. Only the looking became patient.

86. **`io:attack` could crash inside its own restore and leave the pin map mutated, and was
    in no pipeline.** A transient Windows lock (errno -4094) on a file the suite had just
    written turned into an unhandled error in the `finally` that was meant to restore it. All
    twelve attack suites now write through `scripts/lib/write-settled.mjs`; `io:attack` runs in
    both pipelines. See resuming item 85.

85. **The Resources capacity bar had never shown its red over-commitment segment.** A 100 %
    amber fill plus a red slice inside a track with `overflow: hidden` adds up to more than the
    track, so the red was always clipped off. Found by the real-browser layout audit rather
    than by any report, because nothing was visibly broken - it was visibly *incomplete*.

84. **A page title squeezed to one letter per line on the Security screen, found by the owner.**
    A fifteen-role pill with React Native's default `flexShrink: 0` beside a title column with
    no minimum width; measured at 0 px × 836 px. It survived 630 render checks because jsdom
    lays nothing out. Fixed in `PageIntro`, `SectionHeading` and `StatusPill`, and gated by
    `npm run layout:portal`.

83. **The AI prohibition gate refused the egress gate, 17 times, on the first strict run
    after that gate existed — and it was right to.** `check-portal-egress.mjs` checks the
    exported bundle against a list of AI service hosts, because a model endpoint arriving
    inside a dependency would appear in the artefact and in no first-party source. To do
    that it has to NAME those hosts. `check-ai-authority-prohibition.mjs` refuses AI service
    hosts anywhere in the deployable tree, and `scripts/` is part of the deployable tree.

    The interesting part is what the fix must not be. Exempting `scripts/` wholesale would
    have switched the prohibition off for the directory that holds the laboratory bootstrap,
    the packaging script and every gate — which is precisely where a real egress would be
    easiest to hide and hardest to notice. So four files are exempt **by exact path**, on the
    stated ground that a gate must name what it refuses and an attack suite must be able to
    inject it, and **the exemption list is itself constrained**: every entry must match
    `scripts/(check|attack)-<name>.mjs`, so a product source file or a directory cannot be
    added to it. Two attacks (17b and 17c) try exactly that and are refused by name.

    Worth recording as a class rather than an incident. **An exemption that nothing
    constrains is a switch**, and this repository has been here before: defect 36 was the
    policy gate's private-key rule having no laboratory exemption, and the fix there was
    also to make the exemption exactly as narrow as its reason. The difference is that this
    one was found by a gate refusing the same session's own work, which is the third time
    that has happened here and the cheapest way it can happen.

82. **The egress gate examined none of the four values it printed a count of, and its own
    attack suite is what found that.** `check-portal-egress.mjs` reads the portal's
    `EXPO_PUBLIC_*` build arguments out of the CONTROLLED compose model, because the
    Dockerfile derives the Content-Security-Policy's `connect-src` from exactly those — one
    place decides where the portal talks to. The first revision skipped any value beginning
    with `${`, reasoning that a substitution belongs to the environment rather than to the
    model. **Every one of the four is written `${NAME:-default}`**, so the gate examined
    none of them, and then printed "4 EXPO_PUBLIC_* values … each either empty or a local
    origin". Writing attack 7 changed a value the gate was not reading, and the gate passed.

    It now parses the substitution's default — which is the value the model actually decides
    — and counts separately any argument left to the environment, because **a count of what a
    check skipped reads exactly like a count of what it approved**. Two further attacks exist
    only so the hole cannot come back quietly: one writes the public host as a plain value
    rather than as a default, and one turns all four into bare substitutions and requires the
    gate to say it established nothing.

    Same family as defect 75 and item 63, and the third time in this repository that an
    attack suite has paid for itself against the gate written in the same session.

81. **Coding-agent tooling was inside the packaged controlled release, and `MANIFEST.sha256`
    is where it was recorded.** Two entries in the release checksum manifest were
    `./apps/operator-portal/.claude/settings.json` — an editor plugin enablement file — and
    `./apps/operator-portal/AGENTS.md`, a two-line instruction addressed to a coding agent.
    A third file, `.claude/settings.local.json`, was tracked at the repository root and
    carried an absolute path into a developer's home directory into a repository `AGENTS.md`
    requires to be treated as confidential.

    None of the three is an AI API and none is product material, which is exactly why it went
    unnoticed: `scripts/package-release.sh` excludes secrets, keys, build output and PDFs, and
    had no reason to think about editor configuration. The reason it is a defect is narrower
    than "AI in the codebase" and is stated in the gate that now refuses it: **how a
    controlled deliverable was produced is something `ai_usage.json` is the controlled place
    to state**, and packaging an uncontrolled answer to that question into the archive states
    it somewhere else. The governing `AGENTS.md` lives one directory ABOVE the working copy
    for this reason; the portal's copy sat inside it.

    All three are removed, git-ignored, excluded from packaging — and the exclusion is itself
    checked by `npm run ai:prohibition`, because currently-true is not enforced. Two of the 23
    attacks put the files back and remove the exclusion.

80. **The safety-boundary scan swept the ESP-IDF build tree, and only a build could reveal
    it.** `check-repository-policy.mjs` enforces the actuator-output boundary over EVERY
    firmware source, which is the widening defect 62's family made necessary. Its directory
    walk ignored `bin`, `obj`, `dist`, `artifacts` and `node_modules` — and not `build`,
    because until this session nothing had ever run ESP-IDF and `firmware/esp32/build/` did
    not exist. After one build the firmware-source count moved from **19 to 21**, and the
    two extra files were CMake's own compiler-probe sources.

    Nothing failed, which is why it is worth writing down. A count that changes with whether
    somebody has built is a count nobody can reason about, and the next step is worse: the
    tree under `build/` holds vendored and generated component sources, so a `gpio_set_level`
    in any of them would have been reported as *this repository's firmware energising an
    output outside HIL review*. A gate that can accuse the wrong file is a gate that gets
    disbelieved.

    `build` joins the ignored set. 19 sources again, stable either way, and `npm run
    safety:attack` still refuses all five — including an actuator driven from a NEW file
    below the entry point, which is the attack that proves the exclusion narrowed the walk
    and not the boundary.


79. **`firmware/esp32` could not even CONFIGURE against the ESP-IDF it targets, and three
    of the six components it required did not exist.** The first ESP-IDF build this
    repository has ever run got nowhere near a compiler: `main/CMakeLists.txt` declared
    `REQUIRES driver esp_timer esp_task_wdt mqtt esp-tls nvs_flash`, and against ESP-IDF
    v6.0.3 `esp_task_wdt` is not a component (the task watchdog API moved into
    `esp_system`), `mqtt` is not a component either (it became the managed component
    `espressif/mqtt`, which a `REQUIRES` entry cannot name), and **`esp_netif` was
    missing** — while `time_sync.cpp` includes `esp_netif_sntp.h`.

    That last one is the sharp end. `time_sync.cpp` is excluded from the host build
    *precisely because* `esp_netif_sntp.h` is macro-heavy enough that a stub would be
    coverage that only looks like coverage — so the one translation unit the real
    toolchain exists to compile was the one whose dependency was never declared. Nothing
    could see it: `npm run policy` greps the file, the host build skips it, and a
    `REQUIRES` list is not checked by anything that does not run cmake.

    Defect 33's precedent held exactly. The last never-compiled file in this repository did
    not build, and neither did this one. **Fixed and verified**: `REQUIRES driver esp_timer
    esp_netif esp_system log esp-tls nvs_flash`, `idf.py set-target esp32s3` configures,
    `idf.py build` completes 1070 targets, and `time_sync.cpp.obj` exists — the gate now
    asserts that object file rather than trusting "Project build complete", because a
    component that lost the file from its `SRCS` would print the same line.
    `cinerion_cell_controller.bin` is 0x3fa50 bytes, 75% of the app partition free.
    Nothing was flashed and no board is attached.

78. **The controlled compose model built a portal that could not reach the identity
    provider the same model raises.** This is the screen a reviewer actually sees:
    `http://localhost:8081` renders *"FORTRESSGATE / OIDC — Identity provider not
    configured. This build has no OIDC issuer."* The portal was being honest. The model was
    what left it that way.

    `infrastructure/compose.yaml` declared `build: {context, dockerfile}` for
    `operator-portal` and **passed no `args` at all**, so the image always took the
    Dockerfile's defaults — and the Dockerfile's default for
    `EXPO_PUBLIC_CINERION_OIDC_AUTHORITY` is deliberately empty. `EXPO_PUBLIC_*` values are
    inlined by Metro at BUILD time, so an image built without them can never be configured
    afterwards: setting the variable in `.env.local` and restarting changes nothing. The
    Dockerfile also derives the `Content-Security-Policy` `connect-src` from those same two
    arguments, so the browser was additionally forbidden to reach an identity provider it
    had no address for. Meanwhile `cinerion-realm.json` already defines a
    `cinerion-operator-portal` client whose redirect URIs name `http://localhost:8081/*` —
    the exact port this service publishes.

    **Fixed and verified.** The build now passes all three arguments, defaulting to this
    model's own published endpoints (`http://localhost:5080`,
    `http://localhost:8180/realms/cinerion`). Rebuilt and measured rather than assumed: the
    emitted bundle contains `localhost:8180/realms/cinerion`, and the image's CSP reads
    `connect-src 'self' http://localhost:5080 http://localhost:8180`.

    `npm run policy` now reconciles the two: every `ARG EXPO_PUBLIC_*` the Dockerfile
    declares must be passed by the compose service that builds it, the authority passed
    must name the realm this model imports, and the client id must be one that realm
    defines. Attacked by deleting the `args` block — refused, by name, three times.

77. **The command read carried the domain's decision and never the equipment's answer.**
    `api_endpoints.json` controls `GET /api/v1/commands/{commandId}` as *"Read command
    lifecycle **and controller acknowledgements**"*, with *"object-level authorisation and
    immutable audit links"*. It returned the lifecycle alone. The controller's
    acknowledgement — accepted or refused, when, by which gateway — existed only as an
    audit row that no read surfaced, and there were no audit links either.

    That is step 7 of the controlled PREPARE / LOCAL COMMIT sequence, *"correlate telemetry,
    result and audit evidence"*, and its final message, *"visible execution outcome"*. An
    engineer asking what happened got the state the domain last wrote.

    **Fixed.** `CommandService.FindOutcomeAsync` reads the command and the audit events
    carrying its own correlation identity, and the endpoint returns `acknowledgements` and
    `auditLinks` as fields distinct from `state`. Deliberately distinct: merging them would
    invite a reader to treat an acknowledgement as execution, so the response also states
    `acknowledgementIsNotExecution: true` beside the existing `remoteStartAvailable: false`.
    Only hashes cross the boundary — `payloadHash` and `eventHash`, never payloads — because
    duplicating audit content onto a command read would widen a read authority both
    controlled documents agree on. Object-level authorisation still decides first, and a
    reader in another project gets `404` including the evidence.

76. **Every audit row the edge wrote was stamped with a fresh random correlation identity,
    so nothing a gateway published could be joined to anything.** `EdgeIngressService.
    AuditAsync` passed `Guid.NewGuid()` as the correlation id on every event it wrote —
    including `ControllerAcknowledgementRecorded`, the controller's answer to a command
    Control Core had itself prepared and which carries its own `CorrelationId`. The
    acknowledgement was therefore reachable from nothing: not from the command, not from
    the gateway's own message, not from `GET /api/v1/audit?correlationId=…`. It was also
    filed with `objectType: "Cell"` rather than the transaction it answered, so even an
    object-typed lookup would have found it behind every heartbeat the same controller ever
    sent.

    CH1-CYB-FR-0006 requires a security event to carry *"correlation data"*. A per-row
    random GUID has the shape of a join key and joins nothing. The envelope's own
    `CorrelationId` — which CH1-COM-ICD-0001 lists among the fields every controlled message
    carries — was decoded into `IngressEnvelope` and then dropped; `ValidateEnvelope` did not
    even require it.

    **Fixed.** `INGRESS_CORRELATION_REQUIRED` refuses an envelope with no usable correlation
    identifier, every caller now passes one explicitly (there is deliberately no overload
    that mints one), and the acknowledgement is filed under `command.CorrelationId` with
    `objectType: nameof(CommandTransaction)` — the gateway's own correlation id is carried
    in the payload rather than discarded. The test asserts the **join**, not the row: a test
    that an event was written would have passed before the fix.

    Both 76 and 77 were found by reading `assets/prepare-local-commit.svg`, which is item 45
    happening a second time. Two sessions had carried the PREPARE / LOCAL COMMIT exchange as
    "an image the documents embed".
75. **Two attacks became decoration when a patch script changed a file's line endings.**
    `attack-cell-state-map.mjs` mutates the controlled SCL with exact `String.replace`
    calls containing `\n`. A Python patch script wrote that file back with Windows endings,
    `replace` matched nothing, the file was written back unchanged, and the gate passed —
    correctly, because there was nothing wrong with it. Two of eighteen attacks were
    attacking nothing.

    **The suite caught it, and only because it asserts a mutation CHANGED something before
    judging the gate's answer.** Without that check the run would have printed *18 attacks,
    0 holes* while exercising sixteen. That assertion is the load-bearing part of an attack
    suite — more than any individual attack in it — because a mutation that silently stops
    mutating is indistinguishable from a gate that holds.

    Every multi-line mutation is now line-ending agnostic, and the four PLC files are back
    to LF. Same family as item 28: a Windows text-handling detail quietly changing a file so
    that an exact match stops matching, with no error anywhere.

74. **The fix for defect 69 could be pre-empted by the branch above it, and I wrote it that
    way.** `FB_CH1_Procedure` latches its own fault when a permissive is lost while
    `Step > 0`. So in the real system a permissive lost mid-execution makes BOTH of the
    guard's branches true in the same scan — and the permissive branch, which ran first,
    sent the guard to state 0. The fault branch could then never fire, because it fired only
    from 20 or 30.

    The guard therefore sat at Idle with the procedure latched. From Idle a fresh PREPARE is
    accepted the moment the permissives return, commits to state 20, and grants an
    `ExecutePermit` that no `ProcedureRunning` will ever follow. **That is defect 69's exact
    shape re-entering through the fix for it**, and the fix's own commit message had just
    finished describing why that shape is dangerous.

    Every scenario written for defect 69 set exactly one of the two inputs, which is why
    eleven PLCSIM scenarios, a reconciliation gate and a green strict pipeline all agreed
    the fix was sound. It was found by re-reading the change against
    `FB_CH1_Procedure` — asking not "does this branch do the right thing" but "what else is
    true at the same instant".

    The guard now latches from ANY state while the procedure reports a fault, evaluated
    BEFORE the permissive branch. A scenario drives both conditions in one scan and asserts
    the dangerous consequence directly: with the permissives back and the procedure still
    latched, a new preparation is refused. Reverting the fix fails four of its checks by
    name.

    Third in a run of the same class — 67 and 68 were also defects introduced into this
    session's own fixes. **The rule that keeps holding: a fix to a state machine has to be
    re-read against every OTHER input that can be true at the same moment, because a
    scenario that sets one input at a time will never disagree with it.**

73. **A body the operation no longer accepts answered 500 rather than a controlled 400.**
    `RegisterCredentialDto`'s attestation fields were non-nullable strings, so a request in
    the old shape — a public key and a handle as request fields — arrived with nulls and
    died inside `FromBase64Url` with an unhandled `NullReferenceException`. Found by the
    portal contract fixture, which posts the old shape and expects a captured response.
    An operation whose contract has moved has to say so with a code; a trace identifier
    tells a caller nothing about what to send instead. Both fields are nullable now and
    `RequireRegistration()` refuses by name.

72. **`POST /api/v1/credentials` audited a proof of possession nobody had made.**
    api_endpoints.json makes the control "**Proof of possession**, unique identity and
    lifecycle record", and the operation implemented the last two. The public key arrived
    as a request field and was stored, so a Cybersecurity Administrator could enrol any key
    at all — including one they held themselves — against any subject, and the audit event
    recorded `PROOF_OF_POSSESSION_RECORDED` about it.

    **The audit line is the part worth reading twice.** A control that is absent is a gap;
    a control that is absent and *recorded as performed* is a gap with evidence pointing
    away from it. Every other refusal in this codebase carries the check it actually made,
    and this one carried the check it did not. Found by asking what conflict 13 would
    actually take to close, which turned out to be a field on the step-up grant rather than
    an operation the catalogue lacks — the enrolment ceremony was there and the nonce was
    missing.

71. **A local reset returned the cell to Idle without the reconciliation the document
    requires.** CH1-AUT-FDS-0001: "Recovery verifies cause removed, local authority, reset
    edge **and reconciled work-order state**; interrupted execution never resumes
    automatically." `sample_physical_reset` checked the first three and went straight to
    `Idle`, where the next PREPARE is accepted — so after a fault the cell would take a new
    command for a part whose state nobody had re-established. The controlled diagram places
    `Recovery` between `FaultLatched` and `Idle` for exactly this, and the state existed in
    neither the firmware nor the enum. The fix is strictly *stricter* than what it replaced,
    which is the direction a safety-relevant state machine may be changed in.

70. **Two states the guard documented, assigned nowhere — and the gate exempted precisely
    those two.** `FB_CH1_CommandGuard`'s `State` output enumerated `40 Complete` and
    `90 FaultLatched`, and the body assigned neither. `check-plc-model.mjs` had a rule that
    every documented state must be reachable and an exemption reading
    `if (state === 0 || state === 40 || state === 90) continue;` with a comment explaining
    that Complete belongs to `FB_CH1_Procedure`. It does not: `FB_CH1_Procedure` has its own
    `Step`, and the guard simply never entered either state.

    So the check that existed to catch an unreachable documented state was exempting the only
    two unreachable documented states. **An exemption written from an explanation rather than
    from a measurement is a hole shaped exactly like the thing it excuses**, and it survived
    two revisions because the explanation sounded right. Both states are assigned now and the
    exemption is gone.

69. **A latched procedure fault left the execute permit standing, with no event able to clear
    it.** `FB_CH1_CommandGuard` withdrew `ExecutePermit` when the *permissives* went invalid,
    and learned nothing about the procedure's own fault. A step timeout or a plausibility
    fault with every permissive still healthy therefore left the guard in state 20 or 30
    holding the permit, and no input it reads could move it: `ProcedureRunning` had gone,
    `ProcedureComplete` would never arrive, and the permissives were fine.

    The block's own comment says what that is — *"A permit that never clears is a standing
    authorisation to move, which is precisely what this handshake exists to prevent"* —
    written when the same shape was fixed for state 20 and missed one scan-cycle input away.
    The guard now takes `ProcedureFaultLatched`, latches to state 90 on it, refuses a new
    preparation while it stands, and leaves only when the procedure's own controlled recovery
    clears it.

    **Found by reading the controlled state diagram as a transition table rather than as a
    picture**, which is the whole argument for `npm run cell:map`: the missing
    `Executing --critical fault--> FaultLatched` edge was the symptom, and this was under it.
    Eleven revisions of the SCL, a host model, eleven PLCSIM scenarios and a reconciliation
    gate had all agreed with each other about a machine the controlled source did not draw.

68. **The buffer gate measured the backlog after the thing being measured had gone.** The
    defect-56 fix introduced its own timing bug: the outage backlog's high-water sequence was
    read AFTER waiting for Control Core to answer, which races the drain. The gateway can
    empty the buffer between the service becoming healthy and the query landing, the backlog
    then reads 0, and the check refuses a run in which every record arrived exactly as it
    should. A strict run failed on precisely that — *"no outage backlog was held when the link
    returned"* — against a gateway that had held 16 records and delivered all of them. The
    mark is now read while the link is still down, which is the only moment it exists.

    Same lesson as defect 63 from the other direction. That one measured the pipeline's own
    wake; this one measured the recovery rather than the outage. **A measurement has to be
    taken while its subject is still there**, and both times the gate looked correct on the
    page and was sampling at the wrong instant.

67. **Every message acknowledgement write against PostgreSQL failed, and I caused it.**
    Migration `0014` added `retain_until` to `ch1.message_acknowledgements` as `NOT NULL`
    with a `CHECK` tying it to `acknowledged_at + 7 years`.
    `PostgresCinerionStore.SaveMessageAcknowledgementAsync` was written before `0014` existed
    and never set the column, so from the moment that migration landed every acknowledgement
    write died on a bare `23502`. CH1-COL-FR-0002 requires acknowledgement state to be
    retained, and recording any had become impossible.

    **Nothing caught it.** 478 tests passed, `retention:records` passed with 31 checks, the
    attack suite passed with 8 attacks and no holes, and the strict pipeline was green — over
    a write path that could not succeed, because no test exercises that method against a real
    database. It was found by a demonstration seed calling it on PostgreSQL, which is the
    handover's own rule arriving on schedule: *verify claims against a running system, not by
    reading code*. Adding a NOT NULL column is not a schema change, it is a change to every
    writer of that table, and the writers here are in a different project from the migration.

    `retain_until` is now computed in the SQL from `acknowledged_at`, so the value the CHECK
    tests and the value the row carries come from one expression on one clock. A caller
    passing its own would be a second place to state the register's declared period, which is
    what the CHECK exists to prevent.

66. **Reported, not fixed — `Complete` has no transition back to `Idle`**, so a controller
    accepts exactly one procedure per boot. Found by the simulator trying to run a second
    command. CH1-AUT-FDS-0001 describes a cell that runs successive procedures and references
    a state diagram this repository does not carry, and adding a transition to a
    safety-relevant state machine is the owner's decision, not a convenience. The simulator
    states the gap in its own summary rather than quietly scripting around it. Recorded as
    conflict 30.

65. **A controller that booted with any permissive absent was stuck forever.**
    `Initialising` has no exit but `initialise()`, and `app_main` called it once at boot. The
    ordinary state of a cell before an operator arrives is the start-enable key off and the
    guard open, so essentially every controller would have needed a power cycle at exactly
    the right moment to ever reach `Idle`. CH1-EMB-FDS-0001 says startup "enters Idle only
    when permissives are valid" — a condition to keep testing, not an instant to test once.
    The state machine is unchanged and still right to refuse; it is now asked again on every
    pass of the loop. Found by running the firmware for twelve seconds.

64. **The firmware could not send anything at all.** `app_main` sized its telemetry and
    heartbeat buffers at 320 bytes and its acknowledgement buffer at 384; the three messages
    encode to 355, 365 and 438. Every message the controller could send would have been
    refused. The encoder returns 0 rather than truncating, so the device fails safe and goes
    **silent** — which, for the heartbeat CH1-COM-FR-0009 requires, is a fault in itself: a
    device that never heartbeats reads as disconnected.

    Nothing caught it because every host test encodes into a buffer of its own choosing. That
    proves the encoder works and says exactly nothing about whether the CALLER gave it room,
    and `app_main` was never compiled — let alone run — until this session.

    Fixed structurally rather than by correcting three numbers: `ch1_envelope.hpp` declares
    `maximum_envelope_bytes` with its derivation, the callers use it, and a host test asserts
    the bound against the widest message of every type, so a longer reason code fails a gate
    instead of a deployment. **Attacked** by lowering the bound to 400: it fails by name on
    the acknowledgement. The simulator made the same 320-byte mistake in its own code and
    encoded exactly zero envelopes until it used the declared bound — the same instinct
    twice, which is the argument for a declared bound rather than a careful author.

63. **The load gate measured the pipeline rather than the service.** `check-baseline-load.sh`
    runs LAST in `./scripts/verify.sh --strict`, after fourteen gates have each created and
    destroyed containers, and it refused three strict runs at the 80 % collapse floor — 76,
    64 and 77 — while passing standalone at 96. Docker went from 6 volumes to 11 during a
    single pipeline. The harness already declared at step `[2/8]` that it stops the shared
    protocol lab "so the measurement is of the service rather than of the machine"; it now
    applies the same principle one layer down and reclaims Docker's accumulated anonymous
    volumes and build cache before the measured window. Measured on a dirty daemon versus a
    pruned one: worst second 64 → 96, backlog 38 → 5, ingress p95 127.1 → 24.8 ms, with an
    unchanged mean — a fivefold tail with a flat mean is disk pressure, not a code path.
    **The 80 % floor was not touched.** `--all` is deliberately not passed to the volume
    prune, and the gate now proves it: the four named lab volumes holding the seeded realm
    and database survive, which was checked rather than assumed.
62. **A gate reported a safety violation that had not happened, because it could not tell
    "no" from "I could not ask".** A strict run refused with

        FAIL   command(s) reached an executing or committed state across a communication loss

    — note the empty count where the number should be — beside a psql *"the database system
    is starting up"*. Nothing had executed. `check-grpc-edge.sh`'s `sql()` piped psql
    straight into `tr`, discarding both the exit code and stderr, so a database that was
    briefly unreachable returned an EMPTY STRING, and the check compared that against `"0"`
    and took the mismatch for a violation of CH1-VVT-TC-0025.

    This is the worst shape a gate defect can take. A check that misses a violation is a gap;
    a check that INVENTS one teaches its readers to disbelieve it, and the next real refusal
    gets waved through as "probably the database again". Some call sites already guarded with
    `[ -n "$x" ]` and this one did not, which is what an inconsistent guard on a
    silently-empty helper always produces eventually.

    Two fixes. `sql()` now retries the transients PostgreSQL legitimately shows while starting
    or recovering, and when a query truly cannot be answered it says so loudly and returns a
    value no numeric comparison can mistake for a count. And the check itself has **three**
    outcomes rather than two — nothing executed, something executed, and *the register could
    not be read* — because collapsing the third into the second is the whole defect.
    Attacked with five inputs (`0`, `3`, empty, the sentinel, a psql error line): each lands
    in the right branch, where the old code put the last three in the violation branch.

    `check-gateway-buffer.sh` had the same disease in a milder form: `compose up --build`
    sent both streams to `/dev/null` and then reported *"Control Core could not be raised"*,
    a gate saying something went wrong and refusing to say what — defect 54's shape again. It
    now prints the last 25 lines of what actually failed.
61. **The RS-485 node bus accepted any frame type, including one nobody had defined.**
    `validate_frame` checked the preamble, the version, the declared length, the sequence and
    the CRC and **never read the type byte** — `FrameHeader::type` existed in the struct and
    nothing looked at it — so all 256 types were accepted, while the ESP32 entry point and the
    codec's own header both stated that a frame on this link "reports local input state and
    can never be a command". CH1-EMB-FDS-0001 gives the node no authority to start a
    procedure, CH1-SYS-CON-0001 keeps commands out of anything that stores or forwards, and
    CH1-VVT-TC-0014 is the case for a refused bypass; all three rested on nobody having
    defined a command yet. The type is now a closed set of three report kinds refused on both
    sides of the wire, the host test sweeps all 253 undefined types with a valid preamble,
    length, sequence and CRC and requires each to be refused, and the attack that removes the
    check fails by name on exactly that sweep.
60. **A delivery receipt could be silently rewritten or deleted.**
    `ch1.message_acknowledgements` carries a Controlled classification and a 7-year retention
    and its entire purpose is to evidence that a named recipient saw a message. `0004` gave
    it no immutability trigger, and `0002`'s `ALTER DEFAULT PRIVILEGES` gave `cinerion_app`
    `SELECT, INSERT, UPDATE, DELETE` on it — so the application could change who had
    acknowledged what, or remove the evidence entirely, with nothing to stop it and nothing
    to show it had happened. Nothing in Control Core issues either statement, which is
    precisely the difference conflict 19 records: "no code does that" is not "the database
    will not permit it". `0014` adds the retention-aware trigger and revokes both privileges.
59. **Reported, not fixed — the gateway discards what the device said about its clock.**
    `ControlCoreIngressClient.NewEnvelope` sets `TimeQuality.Qualified` unconditionally, so a
    device declaring an untrusted clock reaches Control Core as qualified. The gateway decodes
    the device's `timeQuality` and throws it away, which is the same silent upgrade the
    `Freshness` enum's own comment forbids for readings. The proto carries no per-device
    time-quality field to put it in, so this is a contract question rather than a one-line
    fix. Recorded as **conflict 27** and left for the owner.

## Decisions taken, and why

These are settled. Do not silently reverse them.

- **Audit chain is linked per project.** `ch1.audit_events` carries RLS keyed on project, so a cross-project chain would reference rows a reader cannot see and therefore cannot verify. `ix_audit_project_sequence` reflects the same intent. Sequence numbers stay globally monotonic.
- **Step-up grants are never persisted.** Five-minute, single-use session artefacts with no controlled entity and no table. Issue and redemption are already permanent in the audit chain. A restart forces re-authentication, which is the safe direction. Held in a singleton cache because the store is per request.
- **OIDC-derived authentication strength is capped at `Mfa`.** `CH1-CYB-IAM-0001` requires step-up to be phishing-resistant *and recent*, and `amr` alone cannot establish recency. The route to phishing-resistant strength is therefore a verified passkey assertion, never a token claim — and since defect 30, **independent part release actually takes that route**: `POST /release-records` redeems a `PartRelease` grant, which only `IssueFromVerifiedPasskey` can raise to the required strength. Command preparation still needs the same treatment at the portal, which has no prepare control.
- **Conformance suites live in the service, not in the test project.** The MQTT, OPC UA and Modbus adapters are gated on conformance evidence, and evidence that exists only inside a unit-test assembly says nothing about the adapter a running gateway was actually configured with. `TransportConformance` and `AdapterConformance` therefore ship with EdgeLink, run at startup against whatever this deployment registered, and stop the gateway when a check fails. The same code will run against real hardware.
- **A gated adapter is held to a contract, not skipped.** `RunGatedAsync` requires it to refuse a command, refuse to publish a manifest, name what is not commissioned, and produce no telemetry. An uncommissioned adapter that acknowledged a command would have the domain believe a controller had accepted it, which is worse than one that is simply absent.
- **A consequential operation redeems a purpose-bound grant; it never reads the session's strength.** The two are not interchangeable. A session claim says how an identity authenticated at some earlier moment; a redeemed grant says that *this person* re-authenticated *for this act*, once, within five minutes, and it is in the audit chain either way. Part release was the last operation reading the former, and defect 30 records why that was the wrong half of the pair.
- **A controller's permissives are either answered or they are not, and "not answered" is a value.** `Permissives.reported` decides whether the rest of the message means anything, and when it is false the cell resolves as not permissive whatever the individual fields say. This is not defensive coding: the controlled OPC UA and Modbus profiles both declare `207 PRELIMINARY_PERMISSIVE_INVALID` as a deferred check, because a stand-in has no wired inputs, so a gateway in front of one has no honest alternative. Proto3 leaves an unset boolean false, which makes "interlocks populated, flag forgotten" the realistic mistake rather than an exotic one, and it is the message the probe sends.
- **The live half of cell state lives in memory for ten seconds and nowhere else.** `CellRuntimeProjection` holds what each controller last reported; `ch1.cells` still has no interlock, boot-identity or button column, and the gate asserts that it has none. The window is deliberately far tighter than the 30 s that governs a telemetry projection: a stale temperature is a reading an operator can judge for themselves, and a stale permissive is the state a physical command is authorised against. Expiry therefore means the link is gone, not that a report was late.
- **One resolver assembles a cell, for the command path and the screen alike.** `CommandTransaction.Prepare` refuses an intent whose expected-state hash does not equal the cell's own, and the client obtains that hash from `GET /api/v1/cells/{cellId}/state`. Two assemblies of the same cell would refuse every preparation as stale for a reason nobody could see.
- **A controller answers transactions; it does not introduce them.** An acknowledgement naming a command Control Core never issued is refused, and an acknowledgement that *is* recognised changes no command state — CH1-AUT-FDS-0001 advances the state machine on a cryptographic credential proof and a physical button edge, and CH1-COM-PRO-0001 already says the equivalent for the broker case: "a QoS acknowledgement is never treated as physical execution".
- **The gRPC ingress is a separate listener, and freshness is never inferred from what the server happens to be listening on.** The two surfaces have different callers, different credentials and different zones. Defects 40–42 are all consequences of forgetting that one listener's settings are not the other's.
- **Interlocks, controller boot identity and button state are never persisted.** They are sampled from the controller each cycle; restoring them would present a stale permissive as current. `CH1-SAF-FR-0003` requires restart to default to a non-energising safe state, so after a restart a cell reads as not permissive and a prepared command is refused.
- **In-memory storage is a development and test mode only**, enforced fail-closed outside Development.
- **`AllowedHosts=localhost`** is deliberate; address the service as `localhost`, not `127.0.0.1`.
- **Alarm acknowledgement and alarm cause are separate state.** `Active`, `Acknowledged`, `ReturnedUnacknowledged` and `Cleared` track the two independently, because CH1-AUT-FDS-0001 makes them independent. `Alarm.Acknowledge` carries `CauseClear`, `ClearedAt`, `Priority` and `ActivatedAt` through untouched; only equipment observation calls `ObserveCauseClear`. Collapsing the two into one flag is precisely what would let an acknowledgement read as a clearance.
- **The telemetry channel allowlist refuses, rather than filtering.** An out-of-catalogue channel returns `400 TELEMETRY_CHANNEL_NOT_ALLOWED`. Returning an empty page would be indistinguishable from an allowed channel with no data, and the allowlist would not be observable.
- **Freshness is computed from the newest stored sample, not asserted.** With no reading inside the widest servable window the answer is `Unknown`; older than 30 s it is `Stale`; otherwise it is whatever the reading itself declared, which is never silently upgraded to `Live`.
- **The simulated telemetry source is a Simulation-profile adapter, not a fixture.** It writes through the same ingestion path a gateway uses — device trust, cell assignment, channel and unit checks all apply — and every sample carries `Simulated` freshness. `CINERION_SIMULATED_TELEMETRY=false` turns it off.
- **A context thread identifier is derived from its object, never allocated.** `ch1.context_threads` carries `UNIQUE (project_id, object_type, object_id)` — one thread per object — and the P03 catalogue has no operation that creates a thread or hands out its identifier. Deriving it (RFC 9562 version 8, SHA-256 over a fixed CH1 namespace and the canonical object key) is what makes the two message operations reachable without inventing an operation the catalogue does not contain. Object pages return it as an additive optional field, which is the compatibility rule CH1-SWA-API-0001 states. Posting to a chosen identifier is refused and told the canonical one.
- **A message receipt is `Read`, and the word is load-bearing.** CH1-UXD-DSG-0001 requires messages and alarms to use different verbs so nobody mistakes one for the other, so the receipt never says "Acknowledged" — not in the response, not in the audit decision field. `MessageAcknowledgement` is a separate controlled entity from the message, as entities.json declares, because it has its own retention and one message needs one receipt per recipient.
- **The separation is enforced by the database, not only by the code.** `ch1.context_messages.control_authority` is `CHECK (control_authority = false)` in the foundation schema, and `ch1.message_acknowledgements.acknowledgement_kind` is `CHECK (acknowledgement_kind = 'Read')` in `0004`. Both were tested by direct SQL as the application role and both refused. No future code path can widen either without a reviewed migration.
- **Message bodies are never written to the audit chain.** `ch1.audit_events` is append-only and immutable, so recording message text there would make every contextual message permanently undeletable — exactly the uncontrolled permanent engineering record CH1-DBA-DD-0001 warns against. The audit carries provenance and a SHA-256 of the body, which still binds the event to that text if it is ever produced.
- **A thread must name a controlled object that exists in the caller's project.** ResearchBench experiments are refused with a controlled error while that module is a 501: accepting the link would record a reference this service cannot verify now or later.
- **A reservation holds capacity and starts nothing.** CH1-MGT-FR-0002 keeps every physical-effect path inside CommandGuard, local permissives and local confirmation. `ResourceOrchestratorService` therefore holds no reference to a cell, a command or an interlock, and both the API response and the audit payload say so in as many words.
- **Reserving bumps the resource version, and `If-Match` is mandatory.** The conflict check reads allocations, decides, then writes; without a version comparison inside the same transaction two callers who both saw room would both commit. The version is a concurrency token over the resource *and its commitments*, which is the only way to make check-then-write atomic against the schema as given. A caller that omits `If-Match` is told the current version rather than guessing.
- **`ResourceAvailabilityState` has no `Reserved` value.** Whether a resource is reserved depends on the interval being asked about and is computed from its allocations; storing it would go stale the moment a reservation started or ended. The stored states are `Available`, `Maintenance` and `Withdrawn`.
- **Conflicts are reported, not merely prevented.** Reservations refuse to over-commit, but capacity reduced administratively after the fact can still leave an interval over-committed, and CH1-MGT-FR-0004 requires that state to be exposed. `CapacityLedger` sweeps allocation boundaries to find both the peak and every over-committed interval exactly.
- **A cancelled reservation is kept, never deleted.** CH1-MGT-FR-0003 requires assignment changes to be attributable, revisioned and reversible to a known controlled version; a deleted row evidences neither who released the capacity nor why.
- **`ControlledBench` is declared and unreachable.** The schema and CH1-RND-FR-0003 both name it, and reaching it requires an explicit authorised bench transition for which the P03 catalogue contains no operation. Every experiment is therefore a simulator experiment, and an experiment asking for bench mode is refused rather than quietly downgraded — which is what makes "an experiment shall not command real equipment" true rather than merely intended.
- **ResearchBench records runs; it does not perform them.** CH1-RND-FR-0002 asks for configuration, model, inputs, environment, operator, timestamps, results and provenance sufficient for reproduction — a recording obligation. The computation happens in the R&D engineer's own simulator, each artefact reference is paired with a SHA-256, and the response says so plainly rather than implying the platform executed anything.
- **A run's executor is derived, never supplied.** `bench:<experimentId>` is computed from the experiment, so a caller cannot name a production service account and have it recorded as the executor. CH1-COM-IF-0020 requires isolated credentials on the ResearchBench-to-simulator path.
- **Promotion is an outbound request and nothing else.** CH1-COM-IF-0021 makes it outbound only, with the approval workflow in configuration control. The audit decision word is `Requested`, never `Allowed`; the experiment's environment and production authority are carried through untouched; and the response names the approving authority rather than implying one was exercised.
- **There is no `ch1.users` table and there should not be one.** FortressGate owns identity; duplicating it into the operational schema would create a second system of record that could disagree with the first. `IdentityUser` is a projection of what the provider reports, not a stored record, and it carries no credential, secret, token, TOTP seed or public key.
- **Least privilege is enforced at the identity provider, not only in code.** The `cinerion-identity-admin` service account is granted `view-users`, `query-users` and `manage-users`; `realm-admin`, `manage-realm`, `manage-clients` and `manage-authorization` are withheld. A defect in Control Core could therefore not reach realm policy, because the token would not carry the permission. This was proven by trying: the account's own attempts to change realm policy and create a client both returned 403.
- **The adapter asks the narrowest question that answers the need.** Listing every realm role needs `view-realm`, so role resolution uses the per-user "available roles" endpoint instead; enumerating a client's sessions needs `view-clients`, so session lookup walks the caller's own project users instead. Both choices came from the grant refusing the broader call, which is least privilege working as intended.
- **Session lookup is bounded to the caller's project by construction.** A session belonging to another project's user is not found rather than found and then filtered, so an administrator cannot end a session outside their scope even by guessing an identifier.
- **Authority is checked before configuration.** A caller without the role is told they lack it whatever state the deployment is in, and a refusal never discloses whether an identity provider is configured.
- **An unconfigured directory refuses; it never reports an empty list.** An empty user list would read as a project with no people rather than a service that cannot see any, and that is a fake-success answer to a security question.
- **The platform is a device trust registry, not a certificate authority.** It holds no signing key and issues nothing. CH1-CYB-CSRS-0001 makes long-lived private keys non-exportable in a TPM, secure element or hardware token, so a private key arriving at enrolment means that boundary has already failed: it is refused, named as a compromise, and the refusal is audited without ever recording the material.
- **The certificate thumbprint is derived by the platform, never accepted.** There is no field for it in the request. This is the same rule CH1-QMS-FR-0006 forced onto calibration after defect 14 — the platform decides from the artefact, not from what the submitter claims about it.
- **Enrolment attaches a certificate to a device the project already expects.** It does not create device identities, which is how the "allowlist" in the API control column is read. CH1-IAM-FR-0008 keeps human, service and device accounts separate, and a self-service device registration would blur that.
- **A revoked device is never silently restored.** Re-enrolment is refused; CH1-CYB-IAM-0001 makes lost-token response revoke first and issue a replacement, which is a new decision rather than a repeat of the old one. The thumbprint is kept rather than cleared, because a forgotten one could be re-enrolled elsewhere unnoticed.
- **An enrolled manifest narrows the telemetry allowlist and never widens it.** A channel must be in both the baseline catalogue and what the device declared under its own certificate. A device with no enrolled manifest is governed by the catalogue alone, which is where every device stood before enrolment existed.
- **Role is checked before a step-up grant is spent.** A caller who cannot perform the action is told that, rather than told to obtain a grant they could not use, and a single-use grant is not consumed on a request that was always going to be refused.
- **Session revocation deliberately requires no step-up.** api_endpoints.json gives it to the "session owner or Identity Administrator" and lists no step-up among its controls: someone who believes their session is compromised must be able to end it immediately, and a step-up they may be unable to complete would stand between them and doing so.
- **The promotion request extends the Experiment rather than inventing an entity.** The register declares no promotion entity, and CH1 emits one outbound request per experiment, so `0006` adds the change record, impact assessment, verification, author and time as additive columns with a CHECK that they move together.

---

## Remaining work

### 2 gated API operations

Both are the secure document vault, and both are genuinely a declared future controlled
phase rather than work nobody did.

| Operation | Requirement | Why it stays gated |
|---|---|---|
| `GET /api/v1/documents/{documentId}` | CH1-DOC-FR-0002 | the *authorised representation* half needs a unique data-encryption key per document behind a separate key-encryption boundary |
| `POST /api/v1/documents/{documentId}/export-requests` | CH1-DOC-FR-0002 | a named encrypted container with a wrapped key, which is the same boundary |

CH1-DOC-FR-0003 adds that RFID or NFC must never unlock the vault by UID alone and that
access requires a hardware-backed credential with user verification. A vault without those
is not a vault, and an endpoint that returned a representation without them would be the
fake success the deferred list exists to prevent.

**Two operations left this list**, and should never have been on it.
`POST /api/v1/publication-packages` and its approval operation serve CH1-DOC-FR-0004, whose
status in `requirements.json` is **"Baseline P03"** — not "Design target P03" like 0002 and
0003. It asks for a review pipeline and needs no key boundary at all. Both are implemented;
see the CH1-DOC-FR-0004 section above.

`ch1.controlled_documents` is now read and seeded — CH1-DOC-FR-0001, the part of the
document requirement that needs no vault, is what the publication pipeline allowlists its
inputs against. The metadata half of `GET /api/v1/documents/{documentId}` could be served
from that register today; it is not, because splitting one controlled operation into a half
that answers and a half that refuses would make the 501 mean something different depending
on which field you asked for. **Owner's decision** whether the catalogue should carry a
metadata read separate from the representation read.

### ReportForge and Field Companion, verified on a running system

`POST /api/v1/reports` and `POST /api/v1/parts/scan-events` are implemented and exercised.

| Behaviour | Observation |
|---|---|
| **The same inputs return the same report** | second request → `200` not `201`, `alreadyExisted: true`, identical `contentSha256`, and **one row** in `ch1.reports` |
| Determinism is visible in the audit too | two requests produced **one** `ReportGenerated` event |
| Provenance pinned | template revision `1.0.0`, input identifiers round-tripped through `jsonb`, 64-character content and determinism hashes |
| The platform does not approve | `approvalState: Unapproved`, and as `cinerion_app` an `UPDATE … SET approval_state='Approved'` was refused by the append-only trigger |
| Template and inputs are checked | an unheld template → `REPORT_TEMPLATE_UNKNOWN`; no inputs → `REPORT_INPUTS_REQUIRED`; a Viewer → `403 AUTH_REPORT_GENERATION` |
| **A scan without an enrolled session is refused** | `SCAN_DEVICE_SESSION_NOT_ESTABLISHED` before any record is written |
| **Two independent implementations agree on the signature** | the session HMAC computed in Python matched the C# canonical form byte for byte |
| Identity resolved, not asserted | a signed scan resolved the seeded part; the request carries no field for the part |
| **A re-delivery is linked, not dropped** | second identical delivery → `Duplicate` pointing at the first; two rows, one `Resolved` with a part and one `Duplicate` without, as the CHECK constraints require |
| Station scope is in the signature | a scan signed for one station and presented at another → `SCAN_SESSION_SIGNATURE_INVALID` |
| A revoked device delivers nothing | `SCAN_DEVICE_NOT_TRUSTED` |
| Bounded store-and-forward | a scan 30 hours old → `SCAN_TOO_OLD_TO_ACCEPT` |
| Scans are append-only | `UPDATE … SET station_id` refused by the trigger |
| Audit | `ReportGenerated` 1, `PartScanRecorded` 2, `PartScanRejected` 1 |

### Previously gated, now implemented

`POST /auth/totp/enrolments`, `POST /auth/passkey/options`, `POST /auth/passkey/verify`,
`POST /credentials` and `DELETE /credentials/{credentialId}`. See the commit for the
verification performed. The consequence worth repeating: **phishing-resistant step-up is
now reachable**, so independent part release, command preparation and role assignment are
no longer blocked by the OIDC strength cap — a verified passkey assertion supplies the
strength the token cannot.

### Superseded: the original 11-operation list

| Block | Ops | Notes |
|---|---|---|
| Physical credentials | 2 | `POST /credentials`, `DELETE /credentials/{id}`. Needs the cryptographic credential provider CH1-CYB-IAM-0001 describes (smart card / DESFire-class or NFC FIDO token) |
| TOTP enrolment | 1 | `POST /auth/totp/enrolments`. Keycloak supports RFC 6238 and the realm already carries an OTP policy, so this is reachable; the secret-shown-once handling is the work. **Suggested next.** |
| Passkey / WebAuthn | 2 | **hardware-gated**; unblocks phishing-resistant step-up, and with it independent part release and command preparation over OIDC |
| Document vault & publication | 4 | future controlled phase |
| ReportForge | 1 | `POST /reports` |
| Field Companion | 1 | `POST /parts/scan-events` |
| Command state on PostgreSQL | — | not an operation, but `SaveCommandAsync` is fixed and still **unexercised end to end**: `PREPARE` needs a cell reporting live permissives, which needs EdgeLink ingestion of controller state |

### Beyond the API

- Portal has no prepare control — blocked on phishing-resistant step-up
- Sign-in **reloads the page and lands on the portfolio**, whatever screen it was started from, because `makeRedirectUri()` returns the origin. Harmless but mildly disorienting; restoring the originating route would mean persisting it and replaying it after the exchange
- **4 of the 22 declared screens are absent**, and `npm run screens` names them: CH1-UX-SCR-0012, 0015, 0020, 0021. (0022 was on this list and is now built.) **Every one of the five has no controlled operation behind its subject**, so none can be built from the P03 catalogue as it stands, whatever effort is spent — see "The five screens that cannot be built". Every screen that *can* be built has been
- **A passkey cannot be registered from the portal, and the reason is an API gap.** `POST /api/v1/credentials` accepts the COSE key a registration ceremony produces, but the P03 catalogue has no operation that issues a *registration* challenge — `POST /api/v1/auth/passkey/options` issues an **assertion** challenge and is bound to a credential that already exists. A challenge the portal generated for itself would bind an attestation nobody server-side had verified, so CH1-UX-SCR-0013 states the gap instead of offering the control. **Thirteenth conflict: the catalogue needs a registration-options operation, or registration stays an out-of-band act.** Until then the strong step-up route is reachable only for an identity whose passkey was registered through the API directly
- **The first factor cannot be self-enrolled, and that is the design.** TOTP enrolment requires step-up MFA, so an identity holding only a password cannot obtain the grant that would let it enrol its own first second-factor. CH1-CYB-IAM-0001 resolves this: enrolment "verifies the person … through a controlled ceremony", so the first authenticator is registered by a Cybersecurity Administrator through `POST /api/v1/credentials`, and self-service enrolment is for adding a further factor to an identity that already has one. CH1-UX-SCR-0002 states this rather than letting an operator meet an unexplained refusal
- The resource board is **read-only**. Reserving and cancelling are served, but both require a step-up MFA grant and the portal has no step-up flow, so they are not offered rather than offered and certain to fail. CH1-CYB-ACP-0001 asks only for step-up MFA here, so this is reachable over OIDC once a step-up flow exists — it is the smallest remaining piece of genuinely reachable portal function
- Contextual messages are **stored and readable, not pushed**. `deliveryState` has one honest value, `Published`. Per-recipient distribution and delivery receipts belong to CH1-COM-IF-0018 (ContextBridge to the event backbone), which is not enabled
- **RESOLVED for all three retentions that are computable at all — retention is now executed for `TelemetrySample`, `MessageAcknowledgement` and `RoleAssignment`.** Migration `0014` gives the latter two a disposal path: `retain_until` on the row with a CHECK tying it to the register, a retention-aware trigger that refuses every rewrite and refuses a deletion by anyone but the retention role or before the declared period has ended, an attributable `ch1.record_disposals` record that is itself permanent, and a procedure the application role cannot execute. `npm run retention:records`, 31 checks; `npm run retention:attack`, 8 attacks 0 holes. The remaining **seven** finite retentions are not implementable: conflict 25 records that each is relative to a lifecycle end the schema does not record and no controlled operation sets, so a disposal process would have no date to compute from — **owner's decision**, and inventing a date would be worse than leaving it. The original entry follows.
  - *Original:* Retention is **executed for telemetry, expressible for role assignments, and still only declared for everything else.** `ch1.role_assignments` carries its declared seven-year `retain_until` on the row with a CHECK, so a disposal process could act on the data rather than on a reading of a page — but no such process exists for it yet, and conflict 25 records why most of the others cannot have one at all: their retention is relative to a lifecycle end the schema does not record. The original entry follows.
  - *Original:* Retention is **executed for telemetry and still only declared for everything else**. `ch1.telemetry_samples` now has a disposal procedure that is authorised, attributable, logged and proven, and the raw samples that evidence an alarm or an acceptance measurement are retained regardless of age. Every other entity's retention is still a statement on a page: context messages, reports, scan events and the rest have declared policies and no disposal path. CH1-DBA-DD-0001 makes deletion an authorised, logged administrative process for all of them
- Resources are **seeded, not managed**. CH1-MGT-FR-0001 requires resource configuration through revision-controlled operations, and the catalogue contains no operation that creates, updates or withdraws a resource. Capacity changes are therefore an out-of-band database action today, which is how the conflict case above had to be produced. A database seeded before this commit has no resources at all, because the seed deliberately does not overwrite persisted state
- **The portal now performs step-up.** `useStepUp` obtains a purpose-bound single-use grant by either route: re-authentication for an MFA-strength action, or a WebAuthn assertion for a phishing-resistant one. The grant is never persisted — a grant that survived a reload would be a stored elevation, which is the thing step-up exists not to be. Reserve and release on the capacity board are the first consequential mutations the portal issues, and both carry the grant in `X-CH1-Step-Up` and the resource version in `If-Match`
- **An OIDC session still cannot reach `Mfa` strength**, so the re-authenticate route is refused for a password-only sign-in with `AUTH_STRONGER_AUTHENTICATOR_REQUIRED`. This is correct and was observed in the browser. `ResolveAuthenticationStrength` needs `amr` to carry `mfa`, `otp`, `hwk` or `swk`, and the realm emits no `amr` claim; a hardcoded one would be a stored permanent assertion, exactly what the policy check forbids for `ch1_auth_strength`. Two honest ways forward, both owner decisions: configure Keycloak to emit `amr`/`acr` from the authentication flow that actually ran, or enrol a passkey and use the phishing-resistant route — which needs no MFA session at all, because `IssueFromVerifiedPasskey` rests on the assertion the platform verified rather than on the token
- Promotion requests take step-up MFA on the same terms
- ResearchBench has **no simulator behind it**. CH1-COM-IF-0020 puts the simulators behind a provider interface that is not enabled, so runs are recorded with their provenance rather than executed. There is also **no read operation** for experiments or runs in the P03 catalogue — the records are durable and audited but only reachable through the write responses
- The **bench transition** has no controlled operation, so `ControlledBench` stays unreachable and no experiment can command equipment. Enabling it is a separate authorised act that CH1-RND-FR-0003 requires to be explicit
- Promotion **approval** is not implemented. CH1 emits the outbound request; the Project Manager or Configuration Manager approval workflow lives in configuration control, which is a separate system
- Identity administration needs `CINERION_KEYCLOAK_IDENTITY_ADMIN_SECRET`. `cinerion-realm.json` declares the client and its least-privilege role mapping but **no secret**, exactly as migration `0002` declares no password for `cinerion_app`; the deployment assigns it from controlled secret storage. Unset means user administration refuses, which is the fail-closed direction
- The identity endpoints have **no portal screen** and are reachable only over HTTP. `PUT /users/{userId}/roles` additionally requires a phishing-resistant step-up, so under the settled OIDC cap it is exercisable only under the development identity
- Session lookup is **one request per project user**. Fine at this scale; a larger directory would want the identity provider to expose lookup by session identifier directly
- Device enrolment has **no certificate authority behind it**. Certificates are presented, not issued; CH1-CYB-IAM-0001 puts provisioning and rotation in the PKI, and a software-held CA key would contradict its own requirement that root credentials be hardware-backed
- Revocation withdraws **platform** trust only. CH1-COM-IF-0004 puts the MQTT topic ACL in the broker, which is not enabled, so the response says `brokerTopicAclRevoked: false` rather than implying both halves of "certificate/topic revocation" took effect
- Certificate **chain validation is not performed**. Self-signed device certificates are accepted and reported as `selfSigned: true`; a trust list and issuer validation belong with the CA that does not yet exist
- No **CRL or OCSP** is published. Revocation is enforced by this platform refusing the device, not by anything a third party could check independently
- **RESOLVED — `RoleAssignment` has its table.** Migration `0012` adds it, and every role change CH1 makes is now recorded in full: previous, current, granted and withdrawn, the provider it was applied to, and the seven-year retention on the row with a CHECK holding it to the register. Keycloak remains the authority on who holds which role; this is CH1's own permanent record of the changes it made. The original entry follows.
  - *Original:* **`RoleAssignment` is a declared entity with 7-year retention and no table.** Role changes are currently evidenced only by the audit chain, which stores a payload hash rather than the payload — so who held what, when, is verifiable but not readable back. The same class as conflicts 3 and 7, and not resolved here because Keycloak holds the live assignment; whether CH1 should also retain its own history is an owner decision
- Command and work-order screens are read-only
- **EdgeLink now publishes into Control Core over CH1-COM-IF-0003**, so telemetry no longer depends on the in-process simulated source — `npm run grpc:verify` runs the whole demonstration with that source turned off. The in-process source remains for deployments with no gateway in front of them, and every sample it writes is still marked `Simulated`
- **The command-dispatch direction of CH1-COM-IF-0003 is not built**, and the reason is not effort. The register calls the edge bidirectional and the implemented half answers every publication with the domain's decision and a stable reason code; what does not exist is a server-initiated dispatch of a prepared command down to the controller. CH1-AUT-FDS-0001 puts the commit behind a cryptographic credential proof and a physical button edge observed at the cell, so a dispatch path would end at a controller that still cannot execute — and the portal has no prepare control to originate one. The acknowledgement operation exists and refuses a command Control Core never issued, which is the half that can be honest today
- **RESOLVED — both screens now read `permissivesReported` and `deferredCheckCodes`.** CH1-UX-SCR-0016 and CH1-UX-SCR-0008 withhold the interlock count and say `NOT ANSWERED` for a cell whose controller has not reported, name the deferred check codes behind it, and are never toned as good on the strength of the interlocks alone. The rule lives once in `src/api/permissives.ts`. This was recorded here as blocked because "a screen change is verified by driving it in a browser and that needs a person at the keyboard" — which `npm run render:portal` is exactly what removes. Getting there found **defect 47**: both screens had been rendering `6 / 6` for a cell nobody had answered for
- **RESOLVED for OPC UA — three adapters source controller state now** (simulator, Modbus, OPC UA). For the two stand-ins that front the guard, sourcing it is what makes an unanswered permissive *observable* rather than merely absent: the cell is reported as existing, running a known configuration revision, in a named guard state, and NOT having answered its permissives, with `207 PRELIMINARY_PERMISSIVE_INVALID` attached. The original entry follows.
  - *Original:* **Only the simulator adapter sources controller state.** `IControllerStateSource` is optional by design: the OPC UA and Modbus stand-ins front a guard that declares its permissive check deferred (`207 PRELIMINARY_PERMISSIVE_INVALID`), so a gateway in front of them would report "not answered" and the cell would correctly stay not permissive. Implementing it for those two would make that refusal observable end to end rather than only at the probe, and is the natural next increment on this edge
- Alarm activation **limits** are still baseline-wide, in `TelemetryChannelCatalogue`. Device enrolment now records a capability manifest and that manifest narrows which channels a device may publish, but the limits that raise an alarm are not yet per device. A signed manifest carrying its own limits would close this
- Telemetry retention and downsampling are implemented and verified; see the section above. `ch1.telemetry_samples` still has a single DEFAULT partition, deliberately — disposal is row-precise because a dropped partition would take an alarm's evidence with it, so per-period partitions are a performance measure rather than the mechanism. **The CH1-NFR-REL-0001 24-hour gateway buffer is now implemented and verified** (see its section above); CH1-VVT-TC-0093 is no longer `not_executed`. There is also no scheduler, and deliberately not: a job that ran itself would be disposal nobody authorised
- EdgeLink has **four operational adapters** — the simulator, MQTT 5 against a real broker, OPC UA against a real controller stand-in, and Modbus TCP against a controlled zone behind an allowlisted map — all four passing one unchanged conformance suite on one running gateway, with **none gated**. The gated-adapter contract still exists and is still exercised by `Cinerion.EdgeLink.Tests`, because an uncommissioned deployment must still refuse. What is hardware-gated on this subject is the CPU itself — order code, TIA version, block hashes, the S7 runtime's own OPC UA server, and a witnessed PLCSIM run — not protocol coverage
- **PLC logic is executed against a host model**; no HIL and no PLCSIM. The controlled SCL stays authoritative and cannot run here, so the eleven scenarios run against a faithful translation held in step with it by `npm run plc`. What remains is the CPU itself: order code, TIA version, block hashes and a witnessed PLCSIM run. The firmware is no longer one: it speaks the CH1 envelope over both controlled edges, and its encoding is cross-checked against the gateway byte for byte. What remains hardware-gated there is the conditioned I/O driver, the pin map, SNTP, and the MQTT/TLS transport itself
- `./scripts/verify.sh --strict` **is green end to end** (10/10, exit 0). **GitHub Actions
  itself has still never run**, and cannot be run from here: the working copy has no git
  remote, so the pinned action versions in `.github/workflows/ci.yml` cannot even be
  resolved. The steps CI runs *outside* `verify.sh` were reproduced locally instead —
  see "CI steps reproduced locally" under **Environment**
- 7 requirements still carry `implemented_pending_dotnet_ci`, whose scope note is now factually stale — re-classification is the owner's decision and no `implementationStatus` has been changed in any commit
- Portal contract shapes are **complete**: 38 of 38 compared against a captured response, the 39th exempt with its reason declared in the source. An uncaptured shape now fails the gate, so a new portal contract arrives with evidence about the service or it does not arrive
- **Automated interface testing covers every screen that exists** — 18 of the 22 declared; the other four have no controlled operation behind their subject. `npm run render:portal` mounts the shipped screen modules in a DOM, answers their fetches from responses captured from a real service, drives them and reads the rendered text back; CH1-VVT-TC-0102 is `automated` as a result. **CH1-UX-SCR-0001, 0005, 0006, 0007, 0008, 0009, 0016, 0017, 0018 and 0019 are covered**, and extending the harness to the rest is now ordinary work rather than an unknown — what remains is per-screen scenarios, not machinery. The control room is covered end to end, including the acknowledgement form, the empty-comment refusal that sends no request, the receipt, and the out-of-limit reading notice — `PortalContractFixtureTests` was extended so those branches became reachable from real captured responses rather than faked. Part genealogy is the second screen, and its checks include the two that matter most there: a superseded failing measurement stays readable beside the retest, and a part outside scope reads exactly like one that never existed
- **15 controlled cases still have no executable form**, counted from the map rather than carried forward: 5 `not_executed`, 5 hardware-gated, 3 future phase and 2 covered only by a repository gate, and every one of them now needs something this repository cannot supply on its own: hardware (`-0022`, `-0073`, `-0123`, `-0131`…`-0133`), a load or performance rig (`-0090`…`-0092`), an AI service that does not exist (`-0065`, `-0066`), an analysis or inspection activity (`-0071`, `-0080`), a CAN or fabrication-machine adapter (`-0023` in part), or a phase the baseline defers (`-0128`…`-0130`). Backup and restore (`-0081`) left this list in this session — it was the last one that needed only work
- Two cases are covered only by repository gates rather than by a bound harness — `CH1-VVT-TC-0095` (`npm run contracts`) and `CH1-VVT-TC-0126` (the CI SBOM step). Both are recorded as `partially_automated` with the gate named in the note

### What remains, in one place

Nothing below is blocked on effort in this repository. Each item is blocked on a decision, a
piece of hardware, or a cryptographic boundary that does not exist yet.

**Owner decisions, which block more than they used to now that everything around them is
built.**

**Six of these were resolved in the session of 2026-09-08** — 9, 13, 15, 23, 27 and 30 —
and each was resolved by finding what a controlled document already said rather than by
asking the owner to decide something new. The session of 2026-09-16 did not resolve any,
and added one (33) by the same route: reading a controlled diagram the repository had been
treating as a picture. Conflict 13 needed a field on the step-up grant,
not an operation. Conflict 23's role was declared in `stakeholders.json` the whole time.
Conflict 30's transition was drawn in an SVG sitting in the frozen baseline beside the PNG
the document embeds. **The remaining items below are the ones that genuinely need a
controlled DOCUMENT to move**, which cannot happen in this working copy: `npm run baseline`
verifies 74 frozen sources by SHA-256 and refuses any change to them.

| Conflict | Decision needed |
|---|---|
| 24 | `access.json` and `api_endpoints.json` disagree on document export strength. The stronger is taken; the export operation itself is still gated behind the vault, so nothing turns on it yet |
| 25 | Seven of ten declared retentions are relative to a lifecycle end the schema does not record, and no controlled operation closes a project. A disposal process would have no date to compute from. The three that are computable are implemented |
| 16 | The Cybersecurity Administrator may revoke device trust and may not read the device. **Half of this is now moot**: the revoke response carries the thumbprint, trust state, last-seen time and capability manifest, so the act IS reviewable afterwards. The other half — seeing the record BEFORE deciding — would widen a read authority both controlled documents agree on |
| 17 | The Local Confirmer cannot resolve the sequence CH1-UX-SCR-0009 is declared to show them. Both API documents agree on the genealogy's authority, so this is the screen register disagreeing with them |
| 18, 20, 26, 28, 31 | Five obligations with executable evidence and no controlled verification case. **The second branch is taken and recorded** in `traceability/executable-obligations.json`, with what each gate refuses and what it does not establish. Adopting any as a case is a move from that file to the verification map |
| 32 | CH1-AUT-FDS-0001 names a Maintenance mode that nothing can enter. The SAFETY half is now held and tested — a cell reporting Maintenance is distinguishable and cannot be prepared — so what remains is only the authority: how a cell enters and leaves it, and what it then permits. That is a controlled decision and was not invented |
| 33 | **The Local HMI is a controlled component with no behaviour.** `CH1-IO-HMI-0001` is declared in `io.json` with a diagnostic requirement of its own ("No remote-start control"), `firmware/pinmap/esp32s3-r01.json` assigns it five GPIOs, and `conditioned_io.hpp` defines its signal constant. Nothing drives it. Raised by reconciling the repository against the controlled architecture diagram. What a local display must SHOW, and what it must never offer, is a controlled statement rather than a design choice — the diagram's own subtitle is "identity · state · diagnostics" and the I/O table's diagnostic column is a prohibition. **Either the controlled documents state the display's content, or the component is understood as P03 intent — owner's decision.** It stays explicitly unavailable meanwhile, declared `notImplemented` in `traceability/system-architecture-r01.json`, because a plausible idle screen nobody drove would be a fake-success surface at the one place a person stands next to moving equipment |

**Genuinely deferred work.**

- **The secure document vault, 2 gated operations.** CH1-DOC-FR-0002 wants a per-document
  data-encryption key behind a separate key-encryption boundary and CH1-DOC-FR-0003 a
  hardware-backed credential to decrypt. An endpoint returning a representation without those
  would be the fake success the deferred list exists to prevent.
- **A certificate authority.** Device certificates are presented, not issued; no CRL or OCSP
  is published, and revocation is enforced by this platform refusing the device rather than by
  anything a third party could check.
- **CH1-VVT-TC-0065** needs an AI service, and on 2026-09-17 the owner instructed that
  there be no AI service in the product. That instruction agrees with `access.json`’s
  "Approve or command via AI — None — Not applicable — Explicitly prohibited",
  `CH1-AI-FR-0002` and `CH1-SWA-ADR-0010`, so this case is not deferred pending effort:
  **it is not executable while the prohibition holds**, because `CH1-AI-FR-0001` presupposes
  AI output and producing any would mean building what `CH1-VVT-TC-0066` forbids. Recorded
  rather than closed — the case belongs to the baseline and only the owner can retire it.
  **CH1-VVT-TC-0071** is an analysis activity.

### What remains on the hardware side, and why

The firmware layer is built and host-tested. What is left is not effort here; it is hardware
and the review that has to precede it.

| Outstanding | Why it cannot be closed on this workstation |
|---|---|
| **No ESP-IDF build has ever run** | ESP-IDF is not installed. `app_main.cpp` is compiled against `firmware/tests/host-stubs` and `time_sync.cpp` is not compiled at all. The stubs cover four headers; the real ones are not here to disagree with them |
| **No Arduino build has ever run** | No Arduino toolchain. `NodeApplication` is host-tested; the sketch that reads the pins is not written, because it is board-specific and belongs with the frozen pin map |
| **Nothing has been sampled or driven** | Every discrete input is conditioned from a de-energised fixture and no sensor is read. `sample_discrete_inputs` is the one function a board bring-up replaces, and the conditioning above it does not change when it does |
| **The wiring is not frozen** | Every terminal in `io.json` is `TBD`. CH1-HWE-IOL-0001 permits that at P03 and states plainly that it blocks wiring freeze; CH1-HWE-HDS-0001 puts detailed hardware freeze after Prototype 1 and independent review. `npm run io:map` refuses a map that declares the wiring frozen while a terminal is TBD |
| **No actuator output is energisable** | CH1-EMB-FDS-0001's P03 verification boundary defers independent review until before hazardous energisation. Both halves of that are enforced — the policy gate over every firmware source, and the pin map's `energisable` field — and both were attacked |
| **The 5 HIL cases still need a rig** | CH1-VVT-TC-0072's output side and CH1-VVT-TC-0073's timing are executed as DECISIONS on a host. Real wiring, real FreeRTOS timing and a real actuator are the controlled activity |
| **4 hardware-gated cases need the real S7-1200 G2 CPU** | Order code, TIA version, block hashes and a witnessed PLCSIM run. The stand-ins front the same guard and correctly report `207 PRELIMINARY_PERMISSIVE_INVALID`; they are not the CPU |

The one thing a person could do next without any of that is provision a control-zone time
server and put its address in the node's NVS under `ch1_cfg/sntp_server`. Until then the
controller is honestly Unsynchronised and every prepared command is refused as
`CONTROLLER_TIME_NOT_TRUSTED` — which is correct behaviour, not degraded behaviour.

### Open conflicts between code and the controlled documents

1. **`ch1.alarms` has no acknowledgement comment column.** `api_endpoints.json` makes "Comment, identity, timestamp and no control side effect" the control on `POST /api/v1/alarms/{alarmId}/acknowledgements`, and CH1-COL-FR-0002 requires acknowledgement state to be retained. `ch1.audit_events` stores only a payload *hash*, so a comment recorded solely in the audit chain could be verified but never read back — and accepting a required field then discarding it is a fake-success response. Resolved in favour of the API control by migration `0003`, which adds `acknowledgement_comment` and a CHECK that identity, time and comment move together. Additive only. **The P03 data dictionary for `ch1.alarms` should be updated to match, or the API control column relaxed — owner's decision.**
2. **`cause_clear` and `cleared_at` describe the same event.** Both are set together when the activation condition is observed to have gone; neither is ever set by an operator. One of the two is redundant in the controlled schema. Left as the baseline defines it.
3. **`MessageAcknowledgement` is declared as an entity but has no table.** entities.json gives it its own primary identifier (`message_ack_id`), a Controlled classification and its own 7-year retention, shorter than the message it evidences. The foundation schema created `ch1.context_threads` and `ch1.context_messages` but nothing for it, and `ch1.context_messages` carries no acknowledgement columns, so there was nowhere for the evidence to live. Migration `0004` adds `ch1.message_acknowledgements`. Folding it into the message was rejected: separate identifier, separate retention, and one message addressed to a thread scope needs one receipt per recipient. **The P03 data dictionary should gain the table, or the entity register should be corrected — owner's decision.**
4. **No controlled operation issues a context thread identifier.** The catalogue has `GET`/`POST .../context-threads/{threadId}/messages` but nothing that creates a thread or returns its id, while the schema allows exactly one thread per object. Resolved by deriving the identifier from the object and returning it as an additive optional field on object pages, rather than by adding an operation the catalogue does not contain. **A future revision may prefer an explicit thread operation — owner's decision.**
5. **`ch1.resource_allocations` has no cancellation columns.** `api_endpoints.json` makes "Reason, version match and audit" the control on `DELETE /api/v1/reservations/{reservationId}` and CH1-MGT-FR-0003 requires assignment changes to be attributable, but the table carries only `status`, and `ch1.audit_events` stores a payload hash rather than the payload. Migration `0005` adds `cancellation_reason`, `cancelled_by` and `cancelled_at` additively, with a CHECK that they move together with the `Cancelled` status. This is the same disagreement `0003` records for `ch1.alarms`. **Same owner decision: update the data dictionary, or relax the API control column.**
6. **`entities.json` declares no `Resource` entity**, although `ch1.resources` exists and CH1-MGT-FR-0001 requires resource configuration to be managed through revision-controlled operations. Only `ResourceAllocation` is registered. Treated as configuration rather than a controlled record here, and seeded like sites, cells and assets, because the catalogue also contains no operation that creates one. **Worth reconciling: either the entity register gains `Resource`, or the omission is deliberate and should be stated.**
7. **`ExperimentRevision` is declared but has no table.** The register gives it its own identifier, a Controlled R&D classification and *Permanent* retention — longer than the Experiment it belongs to — but `0001` created only `ch1.experiments`, leaving a run nowhere to record the provenance CH1-RND-FR-0002 requires. Migration `0006` adds `ch1.experiment_revisions` with row-level security, the composite project foreign key, `CHECK (production_authority = false)` and the append-only trigger its "Immutable" classification implies. **Same class as conflict 3: the data dictionary should gain the table.**
8. **Promotion requests have no declared entity.** `POST /api/v1/experiments/{experimentId}/promotion-requests` is in the controlled catalogue and CH1-RND-FR-0003 requires it to carry an approved change record, an impact assessment and verification, but the register has no entity for the request. Rather than invent one, the request extends the Experiment additively, which matches CH1-COM-IF-0021 describing promotion as an **outbound request** whose approval lives in configuration control. **If the register should carry a promotion entity, that is an owner decision.**
9. **RESOLVED — `Identity Administrator` is the System Administrator, and the two documents that declare who exists agree on it.** "Identity Administrator" appears only in api_endpoints.json's authority column. `stakeholders.json` — the register of who exists — does not contain it, and access.json assigns "Manage users" to the System Administrator, so the existing mapping was already correct and what was missing was the record of it. `traceability/controlled-authorities.json` now carries that decision and `npm run policy` refuses any authority phrase it does not account for. *The original wording follows.* **`Identity Administrator` is not a declared role.** api_endpoints.json names it as the authority for session revocation and TOTP enrolment, but `CinerionRoles` and cinerion-realm.json have no such role. Mapped to `SystemAdministrator`, which access.json makes responsible for "Manage users". **Either the role register gains it, or the API document should name the existing role.**
10. **access.json and api_endpoints.json disagree on the strength required to change roles.** access.json: "Manage users | System Administrator | **Hardware-backed MFA**". api_endpoints.json: "Step-up **MFA**, segregation check, revision and audit". The stronger is taken — `StepUpPhishingResistant`. **Consequence: role assignment joins part release and command preparation as unreachable over OIDC until WebAuthn enrolment exists.** If the API control column is authoritative, dropping to `Mfa` makes it reachable today; that is an owner decision, and taking the weaker of two controlled requirements is not one to make silently.
11. **`ch1.devices` has no revocation reason or author.** `api_endpoints.json` makes revocation a Cybersecurity Administrator action with audit and CH1-IAM-FR-0006 requires credentials to be attributable, but the table carries only `revoked_at`, and `ch1.audit_events` stores a payload hash. Migration `0007` adds `revocation_reason` and `revoked_by` additively, with a CHECK that they move with `revoked_at`. It also constrains `trust_state` to a closed set, forbids a revoked device from being marked trusted, and makes one certificate belong to one device — none of which `0001` expressed. **Third instance of the same disagreement as conflicts 1 and 5.**
12. **"Execute a bounded experiment run" is implemented as a recording, not an execution.** api_endpoints.json says *execute*; CH1-RND-FR-0002 and CH1-VVT-TC-0111 describe a recording obligation, and Control Core has no simulation engine — CH1-COM-IF-0020 puts the simulators behind a provider interface that is not enabled. The endpoint captures the run with full provenance and says so in the response. **If the baseline intends Control Core to run simulations, this is a scope gap, not a defect in the record.**

13. **RESOLVED — the catalogue needed a field, not an operation.** This conflict was
recorded as "there is no passkey REGISTRATION-challenge operation, so phishing-resistant
step-up is unreachable for a browser-enrolled identity", and was carried for several
sessions as the largest functional blocker. It never had an entry of its own in this list,
only a row in the summary table, which is part of why it went unexamined for so long.

CH1-CYB-IAM-0001 makes enrolment a controlled **ceremony** — "Enrolment verifies the person,
assigns roles separately, records credential serial/public key and issues recovery material
through a controlled ceremony" — and `POST /api/v1/credentials` is that ceremony, with
"**Proof of possession**, unique identity and lifecycle record" as its declared control. The
catalogue was not missing an operation. What was missing was the nonce a proof of possession
is made against, and that is the "**Purpose-bound challenge**, short TTL and audit" that
`POST /api/v1/auth/step-up` was already declared to issue and did not: the grant was an
identifier and nothing an authenticator could sign over.

`StepUpGrant` carries one now, `WebAuthnVerifier.VerifyRegistration` implements the Level 2
registration procedure against it, and the enrolled key comes out of the attestation rather
than out of the request. Phishing-resistant step-up is reachable for a browser-enrolled
identity, which makes role assignment, part release, command preparation and publication
approval reachable with it. Defect 72 records what the enrolment path had actually been
doing, and it is worse than this conflict described.

14. **No controlled operation reads a work order.** `screens.json` declares CH1-UX-SCR-0006, a work-order board for the Project Manager and Engineer showing "revision-controlled release and progress". The catalogue has `POST /api/v1/work-orders` and `POST /api/v1/work-orders/{workOrderId}/release`, both of which answer with the record they wrote, and nothing that lists or fetches one. So a work order can be raised and released from the portal but never enumerated: the board shows the revisions (`GET /api/v1/products`), the order the cell reports as loaded (`GET /api/v1/cells/{cellId}/state`), and the orders the page itself raised. Adding `GET /api/v1/work-orders` was rejected — `scripts/check-repository-policy.mjs` fails the build on any runtime operation the P03 catalogue does not contain, which is the correct behaviour, and inventing the operation silently is exactly what that gate exists to stop. **The screen states the gap on itself rather than rendering an empty board as though it were a complete one. Either the catalogue gains a work-order read operation, or CH1-UX-SCR-0006's scope should be narrowed to what can be read — owner's decision.**

15. **RESOLVED — by an owner-approved READ, which is what that register exists for.** `GET /api/v1/parts?serialNumber=` resolves the identity and mints nothing: no scan event, no history, exact match so the serial space cannot be enumerated, and the same three roles the genealogy itself requires, so it discloses nothing that read would not. The device binding on `POST /api/v1/parts/scan-events` is untouched. *The original wording follows.* **No human-facing operation resolves a scanned identifier to a part.** `screens.json` declares CH1-UX-SCR-0007 as "QR/RFID identity and complete history" for the Engineer and Inspector, but the only operation that turns a scanned code into a part is `POST /api/v1/parts/scan-events`, which requires a signed session from an enrolled Field Companion device. That device binding is correct and deliberate — CH1-IAM-FR-0008 keeps human, service and device accounts separate, and a browser that could mint a scan event would break it. The consequence is that an Engineer holding a printed serial number has no controlled way to reach the genealogy: `GET /api/v1/parts/{partId}/genealogy` takes an identifier, and nothing maps a serial number to one. The screen states this rather than offering a lookup that cannot work. **Either the catalogue gains a human-facing lookup by controlled identity, or CH1-UX-SCR-0007's "QR/RFID identity" is understood as the Field Companion's job with the genealogy view reached from an identifier obtained elsewhere — owner's decision.**

17. **The Local Confirmer cannot resolve the sequence CH1-UX-SCR-0009 is declared to show them.** `screens.json` declares the automatic-procedure screen for "Local Confirmer/Inspector", and the only controlled route from a cell to the sequence its part is being made to runs through `GET /api/v1/parts/{partId}/genealogy`, which resolves the governing revision — the cell names a work order, and conflict 14 records that nothing reads a work order back. `api_endpoints.json` gives the genealogy to "Engineer, Inspector or Auditor" and access.json agrees, so a Local Confirmer holding none of those three is answered `404`, identical to a part that never existed. Confirmed on a running service rather than inferred: `LocalConfirmer` → cell `200`, products `200`, genealogy `404`; Inspector, Engineer and Auditor → `200`. Both API documents agree with each other, so this is a disagreement between the screen register and the API catalogue rather than an implementation error, and it is the same family as conflicts 14, 15 and 16. The screen names it when the identity holds `LocalConfirmer` without one of the three, rather than rendering an empty sequence that would read as "there is no procedure". **Either the genealogy's authority should include the Local Confirmer, or CH1-UX-SCR-0009's declared audience should be narrowed to the Inspector — owner's decision.**

16. **The role that may withdraw device trust cannot read the device.** `api_endpoints.json` gives `GET /api/v1/devices/{deviceId}` to "Engineer or Maintainer" and `POST /api/v1/devices/{deviceId}/revoke` to the Cybersecurity Administrator; access.json separates "Manage device configuration" (Engineer or Maintenance Engineer) from "Enrol/revoke device" (Cybersecurity Administrator) in exactly the same way. Both controlled documents agree, so this is the intended position rather than an implementation error — and it was confirmed on a running service, where a Cybersecurity Administrator receives `404` for the device read. Its effect is that **revocation is performed blind**: the administrator cannot see the certificate thumbprint, trust state or last-seen time of the device whose trust they are withdrawing, and CH1-UXD-DSG-0001 asks a consequential act to be informed. The screen names this when an identity holds the revoke role without the read role, rather than showing an empty page. **Either the read's authority should include the Cybersecurity Administrator, or the revoke response should carry enough of the record for the act to be reviewable afterwards — owner's decision.**

18. **CH1-DBA-DD-0001's retention obligation has no controlled verification case.** The
document states it plainly — "Retention is based on evidence, legal and project needs;
deletion is authorised, logged and compatible with immutable-release obligations" — and the
entity register states `TelemetrySample`'s retention as "Configurable; summary permanent".
Neither has a case in `data/tests.json`: searching it for retention, disposal, downsampling,
archiving or purging returns only CH1-VVT-TC-0126, which is about SBOM and dependency
disposition. The implementation and its executable gate exist and are proven
(`npm run retention:verify`, 22 checks, both evidence protections individually attacked), but
the gate announces no case, because binding this evidence to an unrelated one is exactly the
overstatement the verification map exists to prevent. **Either the case list gains a
retention case, or the obligation is understood as a design constraint rather than a verified
requirement — owner's decision.** The same gap applies to every other entity's declared
retention, none of which is executed at all.

19. **Deleting telemetry was an authority the application role held and nobody had asked
for.** Migration `0002` granted `cinerion_app` `DELETE` on every table in `ch1`, and no code
path in Control Core issues one against `ch1.telemetry_samples` — so the grant did nothing
except make an unlogged, unattributable deletion possible. Migration `0010` revokes it and
moves that authority to `cinerion_retention`, which may delete from that one table and holds
no other destructive grant. Recorded here rather than in the defect list because nothing was
broken: this is the difference between "no code does that" and "the database will not permit
it", which is the difference CH1-DBA-DD-0001 asks for.

20. **CH1-COM-IF-0003 has no controlled verification case of its own.** The interface
register declares it with a transport, a contract, a security control and a named owner, and
CH1-COM-ICD-0001 states the acceptance rule plainly: "The interface register is accepted when
every runtime edge in the architecture appears exactly once with a named owner **and test
path**." Searching `data/tests.json` for gRPC, CommandGuard, ingress or gateway publication
returns nothing. The evidence produced here is bound to CH1-VVT-TC-0025 (communication-loss
recovery) and CH1-VVT-TC-0101 (cross-layer state correlation), which it genuinely serves in
part — but neither is about this edge, and neither would fail if the edge were removed
tomorrow. This is the same shape as conflict 18. **Either the case list gains a case for the
internal gateway interface, or the interface is understood as verified only through the
behaviours it enables — owner's decision.** The same gap applies to CH1-COM-IF-0002,
CH1-COM-IF-0017 and CH1-COM-IF-0019, none of which has a case naming it either.

21. **No controlled operation assigns a device to a cell.** `POST /api/v1/devices/{deviceId}/enrolment` records a certificate and a capability manifest and sets no cell, while the CH1-COM-IF-0003 ingress refuses any device whose `cell_id` does not match the envelope (`INGRESS_DEVICE_CELL_MISMATCH`) — correctly, since a device reporting for a cell it is not assigned to is exactly what that check exists to stop. The consequence is that **a device fleet cannot be established through the controlled catalogue at all**: enrolment leaves every device permanently unable to publish. `scripts/check-baseline-load.sh` therefore inserts its 25 devices directly as the database owner and says so in a `NOTE` line. This is the same shape as conflict 6 (resources are seeded, not managed) and conflict 14 (no work-order read). **Either the catalogue gains an operation that assigns a device to a cell, or enrolment should carry the assignment — owner's decision.**

22. **RESOLVED by scaling the fleet — CH1-NFR-PER-0001's 250 live channels are now carried.** CH1-SYS-ICD-0001 defines exactly four analogue channels (`CH1-IO-AI-0001`…`0004`) and `TelemetryChannelCatalogue` holds the same four, so a fifth would have to be invented and `npm run policy` exists to stop exactly that. The requirement states 25 active devices and 250 live channels as two separate figures, and 25 is a **floor** on the fleet — "shall support 25 active devices" is not violated by supporting more. The device count is therefore **derived** from the channel requirement rather than stated beside it: 250 ÷ 4 rounds up to 63 devices, giving **252 live channels**. Measured, not asserted: `npm run load:verify` reports 63 devices publishing concurrently and 252 device/channel pairs each carrying data. **No channel was invented and no controlled document was changed.** The original wording of this conflict follows, for the record: CH1-NFR-PER-0001 requires 250 live channels and the controlled I/O table defines four.

    **Original:** CH1-SYS-ICD-0001 lists `CH1-IO-AI-0001`…`0004` — temperature, relative humidity, position/distance and motion/vibration — and `TelemetryChannelCatalogue` holds exactly those four; the ingress refuses anything else with `TELEMETRY_CHANNEL_NOT_ALLOWED`. 25 devices × 4 channels is **100 live channels, not 250**. Reaching 250 needs either ~63 devices or six further channels per device that no controlled document defines, and inventing them to hit the number is precisely what the policy gate exists to stop. The load harness states the arithmetic and fails the check rather than passing over it. **Either "250 live channels" is understood as a fleet larger than 25 devices, or the I/O table is incomplete against the performance requirement — owner's decision.**

23. **RESOLVED — a controlled document already declared it.** `stakeholders.json` contains "IR - Project Owner … P03 scope, owner authorisation, confidential/publication boundary and resources … A: P03 owner decisions and authorisation". `CinerionRoles` and the realm now carry `ProjectOwner` and the publication pipeline exercises the owner's capacity through it; the Project Manager is deliberately not retained as a second route. *The original wording follows.* **There is no ProjectOwner role, and CH1-DOC-FR-0004 needs one.**
`api_endpoints.json` names the reviewers of a publication package "IR plus Document Control
review", and `stakeholders.json` makes IR the project owner holding the
"confidential/publication boundary". `CinerionRoles` and `cinerion-realm.json` have no such
role. The owner's capacity is exercised here by the **Project Manager**, the nearest declared
authority over the baseline, and that is a mapping decision rather than a controlled one —
the same shape as conflict 9. **Either the role register gains a project-owner role, or the
API document names an existing one.** The two-person property does not rest on the mapping
and is enforced regardless: two distinct capacities, two distinct identities, neither of them
the author.

24. **`access.json` and `api_endpoints.json` disagree on document export strength**, in the
same way conflict 10 records for role assignment. access.json: "Export confidential document
| Document Controller or IR | **Step-up phishing-resistant MFA**". api_endpoints.json:
"Step-up **MFA**, recipient/purpose, wrapped key and transmittal". The stronger is taken
where the operation exists; the export operation itself is still gated.

25. **Most declared retentions are relative to a lifecycle end the schema does not record.**
`entities.json` gives ten entities a finite retention, and only three of them are computable
from data CH1 holds: `MessageAcknowledgement` and `RoleAssignment` are absolute ("7 years"),
and `TelemetrySample` is configurable and is implemented. The rest are relative — "Project
life + 7 years", "Device life + 5 years", "Credential life + 7 years", "Account life +
policy" — and `ch1.projects` has **no closure column**, nor does any controlled operation
close a project. So the obligation cannot be executed for them: a disposal process would have
no date to compute from. `RoleAssignment` now carries its `retain_until` on the row with a
`CHECK` tying it to the register, which is the shape the others would need. **Either the
schema gains lifecycle-end dates and the catalogue gains operations that set them, or those
retentions are understood as policy statements rather than executable obligations — owner's
decision.** This is the general form of conflict 18, which recorded the same gap for
CH1-DBA-DD-0001's telemetry case alone.

26. **The controlled I/O register has no verification case.** `data/tests.json` contains
none for it: searching it for I/O, wiring, signal, terminal, pin or loop check returns
nothing, while CH1-HWE-IOL-0001 sets out a completion rule in detail — "Each point is checked
against schematic, terminal schedule, software symbol and live state", digital inputs given
open/closed simulation, analogue channels given zero, mid and span, and "The register is
complete only when every physical connection has an I/O or wiring ID and every configured
software point resolves back." The static half of that is implemented and gated
(`npm run io:map`, 17 kinds of drift refused, attacked with 19 attacks and 0 holes), and the
gate **announces no case**, because binding this evidence to an unrelated one is exactly the
overstatement the verification map exists to prevent. The live half is HIL and needs the
hardware. **Either the case list gains an I/O register case, or the obligation is understood
as a design constraint rather than a verified requirement — owner's decision.** Same shape as
conflicts 18 and 20.

27. **RESOLVED — additively, which is what CH1-COM-ICD-0001 prescribes.** "Contracts use additive evolution within a supported major version", so `TelemetryReading`, `ControllerStateReport` and `CommandAcknowledgement` gained `source_time_quality` rather than the gateway taking the worse of two figures and losing both. `ch1.telemetry_samples` gained a nullable column beside it, the gateway declares its own clock from configuration and defaults to `Unknown`, and nothing maps to `Trusted`. Proven on a running system and attacked. Defect 59. *The original wording follows.* **The gateway replaces a device's declared time quality with its own.**
CH1-COM-ICD-0001 requires time quality to travel with a message so that audit decisions are
not silently made on invalid time, and `Ch1MessageEnvelope` duly decodes the `timeQuality`
the device asserted. `ControlCoreIngressClient.NewEnvelope` then sets
`TimeQuality.Qualified` on every publication it forwards, unconditionally, so a controller
reporting `Unsynchronised` — which, since defect 58, is what a controller with no disciplined
clock now honestly reports — arrives at Control Core as qualified, with its `sampled_at`
stored as though it were trustworthy. The `Freshness` enum's own comment forbids exactly this
for readings: "Control Core never upgrades what it was told." The envelope the gateway sends
describes the GATEWAY's clock, which is a defensible thing for it to describe, and
`ch1_edge_link.proto` has no per-device time-quality field on `TelemetryPublication` or
`TelemetryReading` to carry the device's. So the fix is a contract change rather than a line
of code, and it was not made here. **Either the publication gains a source time-quality
field, or the gateway takes the worse of its own and the device's — owner's decision.**

28. **Demonstration data has no controlled verification case.** `npm run demo:data` raises
Control Core on PostgreSQL with the dataset on and refuses an empty answer from any read a
declared screen depends on, plus proves the dataset says what it is — every reading Simulated,
no command executed, off by default, refused in the Production profile. `data/tests.json`
contains no case for demonstration or laboratory data, so the gate announces none. **Either
the case list gains one, or demonstration data is understood as an operational convenience
rather than a verified property — owner's decision.** Same shape as conflicts 18, 20 and 26.

29. **The controlled I/O register has no verification case** — recorded above as conflict 26;
this entry number is deliberately left pointing at it rather than reused, because a conflict
list where a number changes meaning between revisions is worse than one with a gap.

30. **RESOLVED — the controlled diagram says so, and it is not only an image.** The frozen baseline carries `assets/cell-state-machine.svg` beside the PNG CH1-AUT-FDS-0001 embeds, and its geometry is a transition table: the exit from `Complete` is labelled "acknowledge completion / new order" and goes to `Idle`. `npm run cell:map` parses it and reconciles both implementations against it, 18 attacks 0 holes. Reading it also closed defects 69, 70 and 71, none of which had been reported. *The original wording follows.* **`Complete` has no transition back to `Idle` in the cell state machine**, so a controller
accepts exactly one procedure per boot and then answers `StateInvalid` to every subsequent
prepare. CH1-AUT-FDS-0001 lists Complete among the cell's states and describes a cell that
runs successive procedures — "A hold point removes or inhibits configured energy, records
completion and requests a new preparation/confirmation" — and it references
`assets/cell-state-machine.png`, a diagram this repository carries as an image and not as a
transition table. So the intended exit from Complete cannot be read from the controlled
sources with confidence: it might be an operator acknowledgement, a work-order change, a
timeout, or a fresh initialisation.

Adding a transition to a safety-relevant state machine on a guess is exactly what AGENTS.md
forbids, so this is reported rather than fixed, and `simulators/cell-controller` states the
gap in its own run summary rather than scripting around it. **Either the state machine gains
a defined exit from Complete, or the controller is understood as single-transaction per boot
— owner's decision.** Defect 66.

31. **The cell state machine's SHAPE has no verification case.** `data/tests.json` binds
the machine's BEHAVIOUR to CH1-VVT-TC-0011..0019, and those are announced by the host tests
that exercise it. `npm run cell:map` checks a different thing — that the implemented machine
is the one CH1-AUT-FDS-0001's diagram draws — and binding that to a behavioural case would be
the overstatement the verification map exists to prevent, so it announces none. Same shape as
conflicts 18, 20, 26 and 28, and taken the same way: recorded in
`traceability/executable-obligations.json` with what it refuses and what it does not
establish. **Either the case list gains a case for the state machine's shape, or the
obligation is understood as a design constraint — owner's decision.**

32. **CH1-AUT-FDS-0001 names two states the diagram does not draw, and one implementation
realises neither.** The prose lists "Off/Isolated, Initialising, Idle, Prepared,
AwaitCredential, AwaitButton, Executing, Complete, FaultLatched, Maintenance and Recovery"
and then says "Mode and state are distinct". The diagram draws eight of those; Off/Isolated
and Maintenance are modes rather than states and are drawn nowhere, and neither the MCU nor
the S7-1200 guard has any notion of a Maintenance mode. Nothing in the platform can put a
cell into one, and nothing reports one — `ControllerOperatingState` carries
`MAINTENANCE` and no adapter has ever produced it.

That is a gap rather than a defect: a maintenance mode that "changes permitted diagnostic
actions but never removes machine-specific safety" is a real controlled behaviour with no
implementation, and inventing one would be inventing an authority to change what a cell
permits. **Either the controlled documents state how a cell enters and leaves Maintenance,
or the mode is understood as a P03 statement of intent — owner's decision.** Raised here
because reconciling the state machine against its diagram is what made the absence visible.

**The half that CAN be held, now is.** The entry and exit are an authority and stay open;
the safety property is not, and CH1-AUT-FDS-0001 states it outright — Maintenance "never
removes machine-specific safety". The plumbing already carries the mode end to end: the
proto's `CONTROLLER_OPERATING_STATE_MAINTENANCE`, EdgeLink's string mapping, Control Core's
`CellOperatingState.Maintenance`, and the portal's own `MAINTENANCE` glyph. What nothing
asserted was that a cell reporting it cannot then be commanded.
`AMaintenanceCellIsDistinguishableAndCannotBePrepared` does, with every individual
permissive healthy so the refusal is about the state rather than the interlocks:
`CMD_STATE_NOT_IDLE`. If the authority ever arrives, it arrives on top of a state that
already cannot execute rather than one that silently could. **Nothing about how a cell
enters or leaves Maintenance has been invented, and the conflict stands.**

33. **A controlled component with five assigned GPIOs and no behaviour: the Local HMI.**
`assets/system-architecture.svg` draws `Local HMI - identity · state · diagnostics` in the
local guarded execution band. `io.json` declares `CH1-IO-HMI-0001` - a local display over
SPI/UART carrying "Status/prompt", whose diagnostic column reads "No remote-start control".
`firmware/pinmap/esp32s3-r01.json` assigns it GPIO 42, 47, 48, 38 and more.
`conditioned_io.hpp` defines `signals::local_display`. **Nothing references it.** The
component is wired and silent, and no gate could see that until the repository was
reconciled against the architecture diagram - the signal constant existing was enough to
make every grep-shaped check agree that it was there.

This is not a defect to fix by writing a screen. What a local display SHOWS at the cell,
and what it must never offer, is a controlled statement: the I/O table's diagnostic column
is a prohibition rather than a feature, and a display driven by anything other than the
controller's own state machine would be asserting a cell condition nobody measured. It is
declared `notImplemented` in `traceability/system-architecture-r01.json`, with a reason the
gate refuses to accept as absent, so the absence is now visible to the build rather than to
nobody. **Either the controlled documents state the display's content and the conditions
under which it changes, or the component is understood as a P03 statement of intent -
owner's decision.**


34. **Four controlled WRITE operations have no controlled screen to reach them from.**
`api_endpoints.json` contains 39 operations that are not reads. The operator portal issues
**32** of them, and that figure is now MEASURED BY A GATE rather than grepped:
`npm run capabilities` walks every string and template literal in the portal source,
counting braces rather than matching them, and prints the count and the shortfall on every
run. It is worth saying why. A template literal containing a nested `${...}` breaks any
`[^}]*` pattern, and a looser pattern over-counts; this session produced 30 and then 31
with two different greps before the count moved into the gate, and a still earlier one
reported 3 where 18 were wired. A number a gate derives from the source cannot drift away
from the source.

It issued 30 before this session and nine remained. Two of those nine joined it here:
`POST /products/{productId}/revisions` on CH1-UX-SCR-0006, which is an Engineer authoring
the next controlled definition beside the Project Manager's orders, and `POST /reports` on
CH1-UX-SCR-0010, whose three templates are all quality evidence about a part. Both had a
declared screen and a role that owned them, and neither had an interface. Of the seven that
remain: 

* two must never be there and are enforced absent -
  `POST /confirmations/{id}/credential-proofs` and `POST /confirmations/{id}/local-commits`
  are controller-local, and `scripts/check-repository-policy.mjs` refuses either string
  anywhere in the portal source tree;
* one is the gated document vault, `POST /documents/{id}/export-requests`, which answers
  501 until a key-encryption boundary exists;
* and **four have nowhere in the screen register to live**:
  `PUT /product-revisions/{revisionId}/bom`, `PUT /product-revisions/{revisionId}/route`,
  `POST /publication-packages` and `POST /publication-packages/{packageId}/approvals`.

`screens.json` declares 22 screens and none of them is a product-revision authoring screen
or a document publication screen. The nearest, CH1-UX-SCR-0006, is "Work-order board -
revision-controlled release and progress": it READS a revision's bill of materials and
route, and authoring one is a different act. CH1-UX-SCR-0009 names its own read-only scope
in the register itself.

Inventing a screen is not available: `npm run screens` refuses a route that declares no
screen, and the register is controlled. **Either the screen register gains the two screens,
or these four operations are intended to be reached by something other than the operator
portal - a document controller's integration, or configuration control - and that intent
should be stated.** Raised by measuring the portal against the controlled write catalogue
rather than by reading any one screen.



35. **RESOLVED BY IMPLEMENTATION, AND THE OWNER SHOULD SEE IT — the code was NARROWER than
the controlled authority, so an automatic quality-check machine could not put a result into
the system at all.**

`api_endpoints.json` gives `POST /api/v1/test-runs/{testRunId}/measurements` to
"**Bound instrument adapter** or Test Engineer", with "Schema/range validation, **source
identity** and append-only audit" as its control. The implementation sent every measurement
through `AuthoriseInspection`, whose first line is
`Guard.Against(actor.Kind != ActorKind.Human, "AUTH_HUMAN_REQUIRED", ...)`. The adapter half
of the declared authority had no implementation, so the controlled document named a
capability this platform did not have.

This is the direction AGENTS.md resolves in favour of the baseline, and it is implemented —
with one control the document implies and the code had never needed to express.
**A bound instrument adapter may append only readings its own instrument produced.** A
device appending a measurement whose `sourceDeviceId` names a different instrument would be
attributing a result to equipment that did not make it, which is the one failure mode
machine-fed evidence has and hand-entered evidence does not. `AUTH_INSTRUMENT_NOT_ITS_OWN_READING`.

Exactly one thing was widened and everything else holds, each with its own test:

* the calibration record must still cover **that** instrument and still be current, decided
  from the stored certificate rather than from the boolean the caller sends about itself
  (CH1-QMS-FR-0006, defect 14's control);
* a failed mandatory reading still **holds the part**, because the server evaluates the
  value against the limits and a machine decides nothing;
* an adapter cannot raise a nonconformity, decide a disposition or release a part — each of
  those names a human role and only a human role, and a device meets `AUTH_HUMAN_REQUIRED`;
* the test run is still opened by an **Inspector**, because `POST /test-runs` is authorised
  to "Inspector or Test Engineer" and the adapter half belongs to the measurement operation
  alone. A machine appends results to a run a person opened against a controlled procedure
  revision, which is what CH1-QMS-FR-0001 describes;
* the audit record now names which half appended it, so an auditor can tell a witnessed
  result from a reported one. The source device was already carried; a device identity and a
  person using that instrument would otherwise have looked identical in the record.

**The owner's decision, if any, is whether the controlled authority meant this.** It says
"bound instrument adapter" and this is one. If `access.json`'s "Witness test | Inspector |
MFA | Independent record" is intended to govern every value entering a test run rather than
the human act of witnessing one, then the two documents disagree and the narrower reading
should be restored — which is a two-line change to `AuthoriseMeasurement` and a deletion of
one test class. Nothing else depends on it.

36. **There is no controlled operation that creates a physical part.** Raised by the
owner's request to "add parts", and worth recording because the answer is not the one the
request implies.

`api_endpoints.json` has 54 operations. `POST /api/v1/parts/scan-events` records a QR or
RFID identification at a station and `GET /api/v1/parts/{partId}/genealogy` reads one, but
nothing in the catalogue brings a part into existence. In the implementation a part is
created by the manufacturing path — `PartRecord.Create` — from a released work order, which
is CH1-MFG-FR-0002's shape: the permanent identity is issued once, from the order that
authorised the work, and never recomputed from anything that can change.

So "add a part" in this platform is **release a work order against a released revision**,
which the portal already offers on CH1-UX-SCR-0006 to the Project Manager. What it is NOT
is an operator typing a serial number into a form, and a screen that offered one would be
inventing an operation the catalogue does not contain and an identity nothing authorised.

**If parts are meant to be creatable directly — a part received from a supplier, say, or
one recovered from scrap — the catalogue needs an operation for it and `entities.json`
needs to say where its permanent identity comes from. That is an owner decision and cannot
be taken here.** The nearest existing acts are recorded above so the request is not simply
refused: an inspection request is `POST /api/v1/test-runs`, which the quality screen
offers, and adding material to a product definition is
`PUT /api/v1/product-revisions/{revisionId}/bom` — one of conflict 34's four operations with
no controlled screen to live on.

37. **Two Must requirements and a threat are allocated to a component the controlled
architecture does not draw.** Raised by the owner's instruction of 2026-09-17 that there be
no AI service in the product, and worth recording because the instruction turned out to
agree with the baseline while leaving one thing unreconciled.

`requirements.json` allocates `CH1-AI-FR-0001` and `CH1-AI-FR-0002` to an "**Engineering
Assistant**", and `threats.json` allocates `CH1-CYB-THR-0018` ("AI prompt injection through
evidence") to the same. The RTM lists both requirements as "Specified P03 / Not executed".
That allocation column is the same column in which other requirements name real components
— Deployment, Control Core, EdgeLink.

**The controlled architecture diagram draws fourteen components across six bands and the
Engineering Assistant is not one of them.** Measured over
`traceability/system-architecture-r01.json`, which `npm run arch:map` reconciles against
`assets/system-architecture.svg` geometrically. There is no AI operation among
`api_endpoints.json`'s 54, no AI screen among `screens.json`'s 22, and no AI entity.

The coherent reading is that the Engineering Assistant is a **documentation-production
activity rather than a platform component**: all eight rows of `ai_usage.json` are about
drafting and reviewing documents under human verification, `access.json` gives "Approve or
command via AI" the role **None** at strength **Not applicable**, **Explicitly prohibited**,
and `CH1-SWA-ADR-0010` is Accepted with "AI remains advisory and evidence-linked". On that
reading `CH1-AI-FR-0001`'s "AI output shall identify the records used and shall remain
subject to human verification" governs how a document is produced, not what this platform
contains — and it is already satisfied by the AI usage register itself, which names every
use, its reviewer and its verification.

The consequence, either way, is that `CH1-VVT-TC-0065` is **not executable while the
prohibition holds**, because it presupposes AI output and producing any would mean building
what `CH1-VVT-TC-0066` exists to forbid. It is recorded as such rather than closed.

**Either the allocation should say what it is — a documentation activity governed by
`CH1-PMG-AIU-0001`…`0008` rather than a component — or the Engineering Assistant is a
deferred platform component and the architecture diagram should draw it, in which case
`CH1-CYB-THR-0018`'s "read-only isolation" becomes a boundary something has to enforce.
Owner's decision.** This is the same shape as conflict 33, the Local HMI: a controlled
allocation with no drawn component and no behaviour, where inventing either would be
inventing architecture.

### Candidates for re-classification (owner's decision)

`CH1-COL-FR-0001`, `CH1-COL-FR-0002`, `CH1-COL-FR-0003`, `CH1-MON-FR-0001`, `CH1-MON-FR-0002`, `CH1-MGT-FR-0004`, `CH1-RND-FR-0001`, `CH1-RND-FR-0002`, `CH1-RND-FR-0003`, `CH1-IAM-FR-0006` and `CH1-IAM-FR-0008` now carry executable verification at API and domain level against PostgreSQL, not only a schema and a contract. The three R&D requirements are isolation properties and are additionally enforced by CHECK constraints and an append-only trigger, each proven against direct SQL as the application role. CH1-COL-FR-0003 in particular has its security test (CH1-VVT-TC-0109) exercised end to end with both sides present, and its guarantee is enforced by CHECK constraints proven against direct SQL. No `implementationStatus` has been changed; only the evidence paths were extended.

---

## Working method that has held up

1. Read the relevant baseline documents before touching a subsystem.
2. Verify claims against a running system, not by reading code. Most defects above were invisible on inspection.
3. Check the **full** foreign-key closure before assuming an entity can be persisted — twice a narrow check cost a wasted approach.
4. Never commit code that does not build; never report a skipped gate as passed.
5. Report conflicts between the code and the controlled documents rather than working around them.
