# Prototype 1 quick start

> **Superseded for installing and running the lab.** Use [`INSTALL.md`](../../INSTALL.md) at the
> top of the repository — `install.cmd` on Windows, `sh install.sh` elsewhere. It raises the
> full lab (identity provider, PostgreSQL, simulated cell) in one step. This page is kept for
> its developer notes and the authenticated simulator calls further down.

## 1. Diagnose the workstation

```bash
./scripts/doctor.sh
```

This executes every prerequisite instead of only looking for command names. It
therefore detects partial .NET installations and missing Docker Desktop WSL
integration. For repair instructions, use
[`WSL_SETUP.md`](WSL_SETUP.md).

## 2. Verify the repository

```bash
npm ci
./scripts/verify.sh
```

Use `./scripts/verify.sh --strict` on a workstation with Node.js 24.14, the .NET
10 SDK, Docker Compose v2, and a C++20 compiler. Strict mode fails if any
toolchain is unavailable. CI always runs strict mode.

## 3. Start the simulator-safe stack

```bash
./scripts/run-local.sh
```

This starts only Control Core with its in-memory seed, the loopback EdgeLink
adapter, and the static operator portal. Host ports are loopback-bound.

| Surface | Address |
|---|---|
| Operator portal | `http://localhost:8081` |
| API health | `http://localhost:5080/api/v1/system/health` |
| API catalogue | `http://localhost:5080/swagger` |

The portal currently presents controlled representative data. It contains no
virtual local-commit or credential-proof call.

## 4. Exercise the authenticated development boundary

The following identity headers exist only in the Development + Simulation
profile. They cannot be enabled in Production.

```bash
curl --fail --show-error \
  -H 'X-CH1-Actor: IR' \
  -H 'X-CH1-Project: 00000000-0000-4000-8000-000000000101' \
  -H 'X-CH1-Roles: Engineer,Auditor' \
  -H 'X-CH1-Cells: 00000000-0000-4000-8000-000000000103' \
  -H 'X-CH1-Auth-Strength: StepUpPhishingResistant' \
  http://localhost:5080/api/v1/projects
```

Run `./scripts/smoke-api.sh` for health, anonymous-denial, authenticated scope,
cell-state, and audit-chain smoke checks.

## 5. Optional PostgreSQL and identity labs

```bash
./scripts/bootstrap-local.sh
docker compose --env-file infrastructure/.env.local \
  -f infrastructure/compose.yaml \
  --profile data-lab --profile identity-lab up -d
```

This loads the controlled PostgreSQL schema and a Keycloak realm configured for
PKCE, WebAuthn/passkeys, TOTP, step-up roles, brute-force protection, and no
seed user. The Keycloak `start-dev` profile and bootstrap credential are local
laboratory conveniences only. Remove the bootstrap account/password after
initial provisioning.

The application still uses its in-memory repository at this checkpoint. Wiring
the Npgsql repository, migrations, backup/restore evidence, and identity flow
into the executable stack is the next controlled implementation increment.

## 6. Stop without deleting evidence volumes

```bash
./scripts/stop-local.sh
```

The command does not delete named volumes. Volume deletion, credential
rotation, and test-evidence cleanup must be explicit operations.
