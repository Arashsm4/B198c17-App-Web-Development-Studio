# Prototype 1 implementation handover

## Outcome

This repository is the first executable Cinerion checkpoint under the permanent
`CH1` namespace. It turns the P03/IFV document pack into a coherent monorepo,
contract catalogue, guarded domain model, portal, database foundation,
industrial-integration boundary, embedded source structure, PLC source
structure, test harness, and simulator-safe local stack.

It is intentionally a foundation and vertical slice—not a disguised final
product. Every deferred capability remains visible as a controlled gate or an
explicit `501` response instead of returning fabricated success.

## Start here

1. Read the root `README.md` for the authority boundary and repository map.
2. Run `npm ci` and `./scripts/verify.sh`.
3. On a fully provisioned workstation, run `./scripts/verify.sh --strict`.
4. Start the simulator-safe stack with `./scripts/run-local.sh`.
5. Run `./scripts/smoke-api.sh` after the stack becomes healthy.
6. Review `traceability/implementation-map.json` before changing a controlled
   requirement or claiming a feature complete.

## Executable vertical slice

The implemented slice proves the intended separation of authority:

1. A scoped, stepped-up human identity prepares one semantic procedure.
2. Control Core validates scope, revision, idempotency, expiry, expected state,
   and preliminary permissives.
3. A controller-scoped cryptographic credential proof is bound to the command,
   confirmation, cell, controller, user, and expiry.
4. Only a conditioned physical input—or an explicitly marked simulator
   injection in the Simulation profile—can provide the button edge.
5. The controller rechecks boot identity, material cell state, scope, and local
   permissives before issuing local commit.
6. Resulting decisions enter a hash-linked attributable audit chain.
7. Quality records enforce calibration, mandatory limits, hold, NCR, linked
   retest, segregation of duties, and independent release.

The browser has no credential-proof, local-commit, remote-reset, or actuator
route. The ESP32 P03 entry point configures no actuator GPIO.

## What can proceed now

- API/domain refinement and persistence-repository implementation
- Portal integration against read-only and PREPARE endpoints
- deterministic simulator scenarios and automated test expansion
- Keycloak/OIDC laboratory integration without production credentials
- PostgreSQL migration and backup/restore rehearsal
- EdgeLink simulator and protocol conformance harnesses
- controller logic on isolated, controlled extra-low-voltage benches

## What remains blocked

- selection and procurement of the exact Siemens PLC order code and options
- production card/reader, device PKI, HSM/secure-element, and key ceremony
- real MQTT, OPC UA, Modbus, serial, or CAN equipment writes
- final wiring, hazardous outputs, actuator energisation, and machine operation
- safety validation, HIL/FAT acceptance, production deployment, and publication
- independent technical approval, scheduled after Prototype 1

## Evidence interpretation

“Implemented” means source exists and is mapped. “Prototype verified” means an
automated simulator or portable host test executed. It does not confer hardware,
safety, cybersecurity-certification, or production authority. The exact state
for all 87 requirements is recorded in the implementation map.

