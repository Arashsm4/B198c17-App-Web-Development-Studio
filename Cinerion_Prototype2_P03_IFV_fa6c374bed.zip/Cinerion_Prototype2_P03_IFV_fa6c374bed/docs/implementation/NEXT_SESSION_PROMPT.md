# Prompt for the next session

Paste everything below the line into a new chat.

---

Continue building the Cinerion operator portal into a real operations control surface. Keep
going until finished. Do not stop early to ask permission for ordinary work.

Working directory: `C:\Users\Arash_Sorati\Desktop\Projects\Cinerion\Claude` — git repo on
`main`, tree CLEAN at `87520d6`.

## READ FIRST, IN THIS ORDER

1. `..\AGENTS.md` — governing rules, one directory ABOVE the working copy. Obey it.
2. `docs/implementation/PROTOTYPE2_PROGRESS.md` — the full handover. Read "Resuming work in
   a new session": 65 numbered items. Start with **45** (the frozen baseline carries SVG
   twins of the PNGs the documents embed, and an SVG is data — reading two of them produced
   defects 76–77 and conflict 33), **62** (do not edit a shell script while it is running),
   and **64–65** (the identity lab's two traps).
3. `docs/implementation/DEVELOPMENT_GATES.md` — the gates and what each refuses.
4. `docs/baseline/P03_IFV/` — frozen engineering authority, 74 files, SHA-256 verified.
5. The owner-decision registers in `traceability/`: `owner-approved-operations.json`,
   `controlled-authorities.json`, `executable-obligations.json`,
   `local-commit-sequence-r01.json`, `system-architecture-r01.json`.

## RAISE THE LAB FIRST

```bash
npm run lab:up
```

One command. It raises PostgreSQL + Keycloak + Control Core + EdgeLink + the portal with
demonstration data, gives `cinerion_app` its login, applies any migration the database is
behind, and provisions the portal identities. Then:

* Portal `http://localhost:8081` · API `http://localhost:5080` · Keycloak `http://localhost:8180`
* **Address the API as `localhost`, never `127.0.0.1`** — `AllowedHosts=localhost` answers
  the literal with 400. That is the control working.
* Sign in as `ch1-portal-demo`. The password is `CINERION_PORTAL_DEMO_PASSWORD` in
  `infrastructure/.env.local`. **A browser sign-in needs the USER** — typing the password is
  not something the agent may do. Ask, and ask for a screenshot when something fails.
* If port 5080 is refused with "ports are not available" while `docker ps -a` shows no
  container on it, that is item 51's stale `wslrelay`. Find it with
  `Get-NetTCPConnection -LocalPort 5080 -State Listen | ForEach-Object { Get-Process -Id $_.OwningProcess }`
  and `Stop-Process -Force`. It returns whenever Docker Desktop restarts.

## STATE

`./scripts/verify.sh --strict` is GREEN at `87520d6`: all 15 steps, exit 0, nothing skipped.
505 .NET tests / 0 skipped. Portal render gate 45 scenarios / 464 checks. 83 attacks across
five suites, 0 holes. Set `CINERION_POSTGRES_CONNECTION` or 26 tests skip — the throwaway
database is `cinerion-verify-db` on `127.0.0.1:55432` (`docker start` it; do not recreate
it, that costs fifteen migrations and a password rotation).

The portal now performs **32 of the 39 controlled write operations**. Of the seven it does
not: two are controller-local and must never be there, one is the gated document vault, and
four have no controlled screen to live on (conflict 34).

---

# WHAT THE OWNER ASKED FOR NEXT

Four things, in their own framing. 1 and 2 are ordinary work. 3 is design. 4 needs the
honest conversation in the section after it.

## 1. The sidebar overlaps and cannot be scrolled — DIAGNOSED, not yet fixed

`apps/operator-portal/src/components/app-shell.tsx`. `Sidebar()` returns a plain
`<View style={styles.sidebar}>` with a fixed `width: SidebarWidth` and **no `ScrollView`
and no flex/height bound**. The main content column has a `ScrollView`; the sidebar does
not. With 14 navigation items plus the brand, the active-workspace block and the authority
card, the content exceeds the viewport and is clipped — "Calibration register" is cut off
at the bottom and cannot be reached.

Fix: give the sidebar a bounded height and put the navigation list in a `ScrollView` with
`flex: 1`. Keep the brand pinned at the top; decide deliberately whether the AUTHORITY
BOUNDARY card stays pinned at the bottom (it is a safety statement and should not scroll
out of reach) or scrolls with the list. Check both the wide and the `compact` (< 980px)
branch, and at a short viewport — the bug only appears when the window is short.

## 2. Role-based capability, and machines that feed the system

The owner's words: *"admin or higher operator should be able to create work order or make
changes or add parts or add inspection request or other stuff and each role can respond and
do their task, for example inspector should be able to add report and results for the
quality and inspection or a automatic quality check machine should be able to fed the
results directly to system and data base."*

What that decomposes into:

* **Every role sees the acts it owns.** 15 roles exist in `CinerionRoles` and the realm, and
  the portal currently gates a few controls on roles ad hoc. Work out, from
  `docs/baseline/P03_IFV/data/access.json` and `api_endpoints.json`, which role owns which
  act, and make each screen offer exactly those. `traceability/controlled-authorities.json`
  already maps all 49 controlled authority phrases to roles — that register is the source,
  not a fresh reading.
* **Do not disable a control to pre-judge an outcome.** `ControlledActionForm` documents
  this: authorisation is the server's to evaluate, and a portal that greys out a button it
  believes would fail asserts a decision it did not make. Offer the control where the role
  plausibly owns the act; let the server refuse and show the refusal verbatim.
* **Adding a part.** Check first whether the controlled catalogue has an operation that
  creates a physical part. `POST /api/v1/parts/scan-events` exists; a part-creating
  operation may not. If it does not, that is a conflict to report, not an endpoint to
  invent.
* **An inspection request.** Likewise — check the catalogue before building. `POST
  /test-runs` opens a controlled test run and may be the act meant.
* **A QC machine feeding results directly.** This is the interesting one and it is
  buildable. Device identities already exist end to end: `DevicePkiService`, device
  enrolment, mutual-TLS gateway peers, and `EdgeIngressService` as the machine-facing
  ingress. **Check whether `POST /test-runs/{id}/measurements` accepts a DEVICE actor or
  requires a human Inspector** — `MeasurementDto` carries `SourceDeviceId` and
  `CalibrationRecordId`, so the shape is ready, but the authorisation may not be. If it
  requires a human, the honest route is the edge: an instrument publishes through EdgeLink
  and Control Core records it, exactly as telemetry does today. Either way the measurement
  must carry its instrument and that instrument's calibration, and the server must still
  refuse a result from an instrument out of calibration (defect 14).

## 3. It should feel like controlling an operation, not browsing a site

The owner's words: *"it should give the filling as its intention which is controlling a
whole operation and acting as control and management between software and hardware and each
work area and section so they can communicate from different departments with each other
through data and connections on this portal."*

This is a design brief, not a defect list. Things that would actually deliver it:

* **Cross-linking.** An alarm should reach its cell; a cell its work order; a work order its
  part; a part its genealogy, its measurements and its NCRs; an NCR its disposition. The
  data already carries every one of those identifiers and the screens render them as inert
  text. Making them navigable is most of the "it feels connected" gap.
* **ContextBridge is the department-to-department channel and it is already built.**
  `POST /context-threads/{threadId}/messages` and the acknowledgement operation are wired
  on the collaboration screen. CH1-COL-FR-0001..0003 tie a thread to a controlled OBJECT —
  so a message should be reachable *from the object it concerns* (an alarm, a part, a work
  order), not only from one screen. That is the "different departments communicate through
  this portal" requirement, and it is close to free.
* **The operations overview (CH1-UX-SCR-0016)** is the declared cross-layer screen. It
  should be the place where software state, resource state and physical state are correlated
  with freshness — check what it actually shows now.
* **Freshness and authority must stay legible.** Whatever is added, a reader must still be
  able to tell live from stale from simulated, and must never be able to read a portal
  assertion as a physical fact.

## 4. The execute button, and what it can honestly be

The owner's words: *"I want to give full access to you so you can make them and finish the
project stuff like hard layers or adding a executing button for hardware and stuff like
that, you can make it of course these should be available only for admin or the person admin
gives permission to and they should be all locked behind verification of the person using
this software by password and all other authentication process which also includes physical
authentication with pass key or other stuff too."*

**Build this, and build it fully — but understand what "it" is before starting.** There are
three different things tangled in that sentence and they have three different answers.

**(a) A full end-to-end execution loop, in the Simulation profile — BUILD IT. This is the
one the owner actually wants to see, and nothing has to be weakened for it.**

`CommandTransaction.LocalCommit` already permits `ButtonEventSource.SimulatorInjection`
when `simulationProfile` is true, and audits it as
`MARKED_SIMULATOR_EDGE_AND_FINAL_PERMISSIVES_VALID` — distinct from a physical edge, and
deliberately so. The runtime profile is `Simulation`. So the whole controlled sequence can
complete and be watched:

```
portal PREPARE → simulated cell controller presents a credential proof
               → simulated controller injects a marked button edge
               → controller resamples interlocks → LOCAL COMMIT → Executing → Complete
               → portal shows the acknowledgements and audit links it already renders
```

The confirming actor must be **the simulated controller, not the portal**. `simulators/`
already holds a cell-controller host binary and the PLC guard stand-in; what does not exist
is a small service with a device identity that drives `/credential-proofs` and
`/local-commits` against the API. Build that. The portal then gets a control that says
*"ask the simulated cell to confirm"* — honest, clearly marked as simulation, and it makes
the command screen show a command going all the way through.

`scripts/check-repository-policy.mjs` refuses `/credential-proofs` and `/local-commits`
anywhere under `apps/operator-portal/src/`. **That stays.** The simulator is not the portal.

**(b) Admin-granted permission, password and passkey gating — BUILD IT.**

Most of it exists and is not yet joined up:

* step-up grants are purpose-bound, single-use and five-minute (`StepUpPurpose`, 13 purposes);
* `IssueFromVerifiedPasskey` is the only route to `StepUpPhishingResistant`, so a passkey
  assertion is already the strongest gate and is already required for part release and
  command preparation;
* `PUT /api/v1/users/{userId}/roles` is a controlled operation the portal does not yet
  offer — that is "the admin grants permission", and it belongs on CH1-UX-SCR-0013
  (Security administration), which `security.tsx` already implements. It needs `PUT` support
  in `apps/operator-portal/src/api/client.ts`, which currently does GET/POST/DELETE only.
* Conflict 10 is live here and must be respected: `access.json` requires **hardware-backed
  MFA** for role assignment while `api_endpoints.json` says step-up MFA. The stronger is
  taken. Do not silently drop to the weaker one.

**(c) A portal button that energises REAL hardware — DO NOT BUILD, and say why once.**

Not a preference, and not squeamishness. Three independent reasons, each sufficient:

1. **There is no hardware to execute against.** `firmware/pinmap/esp32s3-r01.json` declares
   2 actuator signals and **`energisable: false`** on both at hardware revision R01. The
   policy gate refuses `gpio_set_level`, `gpio_config` and `ledc_set_duty` in every firmware
   source, and CH1-EMB-FDS-0001 defers independent review until before hazardous
   energisation. The firmware plans outputs; nothing drives one.
2. **The physical button is the safety control.** CH1-AUT-FDS-0001 puts the commit behind a
   cryptographic credential proof AND a new physical button edge sampled at the cell, with
   interlocks resampled between the edge and the commit. CH1-CYB-TMD-0001 treats a path that
   could arm equipment without them as a priority threat. A software button that stood in
   for the physical one would not be a feature with a risk attached; it would delete the
   control the ConfirmGate exists to be.
3. **AGENTS.md forbids it directly** — "never bypass or weaken physical/local authorization
   … command confirmation", and "the portal must never falsely claim physical execution".

So: build (a) and (b) in full, and when the owner asks again about (c), the answer is that
the simulated loop is real and complete, the real one needs the rig, the wiring frozen and
independent review — and that is a hardware and controlled-document milestone, not a coding
task. If the owner wants the boundary itself changed, that is a change to CH1-AUT-FDS-0001
and CH1-CYB-TMD-0001: **report it and stop**, do not edit the gate.

---

## ALSO OUTSTANDING

* **Token expiry is unhandled, and the session lies about it.** The owner photographed
  `SESSION: AUTHENTICATED` beside `HTTP_401 — the access token was rejected`. The realm
  declares no `accessTokenLifespan`, so Keycloak's default applies (5 minutes), and
  `apps/operator-portal/src/auth/session.tsx` has **no refresh-token handling at all** and
  no 401 → session-state transition. Sign in, wait five minutes, and every screen 401s while
  the pill still reads AUTHENTICATED. Fix both halves: refresh silently while the SSO
  session is alive, and when a refresh genuinely fails, say the session ended rather than
  claiming it is live. The memory-only access-token decision stands and is not the problem.
* **Conflict 34** — four controlled writes with no controlled screen (BOM authoring, route
  authoring, and the two publication-package operations). `screens.json` declares 22 screens
  and none covers those acts. `npm run screens` refuses a route that declares no screen, so
  a screen cannot be invented. Report; do not work around.
* **Conflicts 16, 17, 24, 25, 32, 33** and obligations **18/20/26/28/31** each need a
  controlled DOCUMENT to move and cannot be closed in this working copy — `npm run baseline`
  verifies 74 frozen sources by SHA-256.
* **The stale identity realm.** Keycloak imports a realm only when it does not already
  exist, so `cinerion_cinerion-identity-db` has been behind `cinerion-realm.json` for a
  month and nothing noticed — `npm run policy` reconciles against the FILE, not the running
  realm. `ProjectOwner` was missing and was added by hand. Consider a gate that compares the
  running realm with the file, and expect other drift.

## DO NOT WORK AROUND THESE

* The portal has **no commit control** and must not gain one.
* `scripts/check-repository-policy.mjs` refuses `gpio_set_level` / `gpio_config` /
  `ledc_set_duty` in EVERY firmware source, and refuses an actuator marked `energisable`
  while the wiring is unfrozen. Do not weaken it. If you believe it must move, REPORT IT and
  stop.
* `infrastructure/compose.yaml` is the CONTROLLED model. Developer settings go in
  `compose.lab.yaml`. `npm run demo:data` asserts that the controlled model does not enable
  demonstration data.
* 2 gated operations are the document vault and need a real key-encryption boundary.
* 4 hardware-gated cases need the real S7-1200 G2 CPU; 5 HIL cases need a rig.
* A BROWSER RUN NEEDS THE USER.

## METHOD THAT KEEPS FINDING THINGS

* **Verify against a RUNNING system.** Most defects here were invisible to inspection.
* **Measure, do not estimate.** A grep for the wrong pattern reported the portal wiring 3
  write operations when it wired 18. Count the thing itself.
* **Build the gate before the code, then ATTACK it** — revert the control and confirm the
  gate fails BY NAME. An attack suite must assert its mutation CHANGED something (defect 75).
* A gate that greps a source for a symbol will match it in a COMMENT (item 63).
* `docker compose` reads `.env`, never `.env.local`; pass `--env-file` (item 64).
* Write patch scripts to a FILE and run the file; use `open(path, 'w', newline='')` in
  Python or you will silently convert a file to CRLF.
* Never commit code that does not build. Never report a skipped gate as passed.

## REPORT FORMAT

Per step: files changed, reason, verification performed, WHAT WAS NOT VERIFIED, result, and
a NEXT STEP section — preceded by a one-paragraph plain-English summary a non-programmer can
follow.
