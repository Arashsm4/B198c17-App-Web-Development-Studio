# Toolchain baseline

- .NET SDK 10 LTS for Control Core and EdgeLink
- Expo SDK 57, React Native 0.86, React 19.2, and strict TypeScript for the
  universal client
- PostgreSQL 18 for controlled transactional and audit records
- MQTT 5 broker with TLS/mTLS profiles
- ESP-IDF C++/FreeRTOS for ESP32-S3 and portable C++ for host verification
- Arduino-compatible C++ only for the secondary I/O node
- IEC 61131-3 Structured Text and TIA Portal/PLCSIM for S7-1200 G2
- Docker Compose for local orchestration; services also remain independently
  runnable for diagnosis

Versions are pinned in tool-specific manifests and lock files. Dependency
updates require tests, vulnerability disposition, and a recorded change.

