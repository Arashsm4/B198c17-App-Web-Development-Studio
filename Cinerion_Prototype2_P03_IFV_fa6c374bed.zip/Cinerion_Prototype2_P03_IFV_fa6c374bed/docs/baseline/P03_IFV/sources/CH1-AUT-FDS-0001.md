---
document_number: CH1-AUT-FDS-0001
title: Automation Functional Design Specification
discipline: Automation
document_type: FDS
document_state: Populated
purpose: Defines automatic sequences, permissives, state machines, local confirmation, alarms and recovery behaviour.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SRS-0001
- CH1-SAF-SCS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Modes, states and control ownership

The cell supports Off/Isolated, Initialising, Idle, Prepared, AwaitCredential, AwaitButton, Executing, Complete, FaultLatched, Maintenance and Recovery. Mode and state are distinct: Maintenance changes permitted diagnostic actions but never removes machine-specific safety. Exactly one controller owns the execution state machine. The portal requests intent; the local controller decides whether a transition is valid.

![Local cell-controller state machine](assets/cell-state-machine.png)

## PREPARE and LOCAL COMMIT

PREPARE carries command ID, procedure/work-order/part IDs, expected controller and equipment state, configuration revision, parameters, expiry and authenticated requester. The controller validates signature/authenticity, sequence, scope, bounds and preliminary permissives, then returns a prepared acknowledgement. ConfirmGate verifies a cryptographic local credential for the assigned cell and transaction. Only while valid is the confirmation lamp energised. A debounced new button edge triggers final permissive resampling and LOCAL COMMIT. A held input, timeout, reboot, revision change or equipment-state change cancels the transaction.

## Sequence execution and hold points

Committed procedures execute automatically through named steps with entry action, steady action, exit condition, timeout, limits, evidence and fault transition. Outputs are bounded by rate, travel and permitted state. A hold point removes or inhibits configured energy, records completion and requests a new preparation/confirmation if human intervention changes risk. A software loop cannot silently skip a mandatory hold or acceptance measurement.

## PLC function-block architecture

The Siemens S7-1200 G2 CPU 1212C class project uses Structured Text and named function blocks for state, command handshake, permissives, alarms, device health and diagnostics. A global command data block is not directly exposed to UI writes. EdgeLink maps semantic requests to a versioned handshake; PLC acknowledgement includes transaction, state, result and reason. PLCSIM is used before hardware. Standard PLC logic is ordinary automation only, not a credited safety function.

## Alarms, faults and recovery

Each alarm has ID, priority, source, activation condition, latching policy, operator guidance, acknowledgement and clear condition. Acknowledgement does not clear the cause. Critical watchdog, permissive, travel, plausibility or communication faults drive the defined non-energising output state and FaultLatched. Recovery verifies cause removed, local authority, reset edge and reconciled work-order state; interrupted execution never resumes automatically.

## Verification

State transitions are model tested, then exercised in PLC/MCU simulation and HIL. Negative cases include wrong cell, expired prepare, duplicate sequence, stuck button, lost credential, changing permissive at confirmation, controller reboot and unauthorised register write. Timing evidence demonstrates input detection and acknowledgement targets.
<!-- PROFESSIONAL_EXPANSION_END -->
