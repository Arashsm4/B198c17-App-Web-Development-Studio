---
document_number: CH1-PMG-DCP-0001
title: Document Control Procedure
discipline: Project Management
document_type: Procedure
document_state: Populated
purpose: Defines numbering, revision, review, approval, issue, supersession and archival rules.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-MDR-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Controlled-document lifecycle

A controlled document begins with a reserved CH1 number, owner, purpose, classification and planned issue status. Content is authored in Markdown/YAML/JSON, reviewed through traceable comments, generated into office formats, validated, authorised for a defined purpose, transmitted, archived and eventually superseded. The source remains the engineering truth; direct DOCX edits are review inputs until reconciled. No current issue is silently overwritten with different content, even when the owner instructs that the visible revision label remain P03; the change log and package checksum preserve the regeneration event.

## Numbering and metadata

The pattern is `CH1-[DISCIPLINE]-[TYPE]-[SEQUENCE]`. Permanent object IDs use the same CH1 namespace. Covers and headers shall display Cinerion while identifiers remain CH1. Required metadata includes number, title, revision, issue status, date, discipline, type, state, classification, preparer, checker status, approver and baseline. `IR` is the only owner name used in this issue. The independent checker field reads `Deferred - after Prototype 1` and shall not be replaced by an invented person.

## Review and approval

Comments identify document, input revision, exact clause, severity, requested change, response, disposition and closure evidence. `Accepted` means incorporated; `Not accepted` requires rationale; `Deferred` requires a target gate and risk owner. IR may authorise P03 for its stated R&D boundary. After Prototype 1, an appropriately competent independent reviewer checks safety-, hardware-, cybersecurity- and release-critical content. Approval applies only to the status shown and never implies certification.

## Revision and status rules

P-revisions are preliminary. IFR requests review; IFA requests approval; IFI supports implementation; IFV supports verification; A-revisions are approved controlled issues; ASB is reserved for verified as-built records. Status and maturity are separate. A template document may be P03/IFV yet remain `Not executed`; a test report shall not be populated with predicted results.

## Visual and navigation standard

Every DOCX uses one branded cover, a compact Part 0 control block, a teal Part A divider for unique engineering content, and a slate Part B reference block. Headings are semantic and tables are reserved for comparable records. Each substantive section states intent, method, control, output and acceptance where applicable. Repeated definitions and legal language remain available without obscuring the document-specific content.

## Issue, storage and archive

The supplied release contains DOCX, Markdown, LaTeX and applicable XLSX; PDFs are intentionally omitted. Checksums, manifests and QA records travel with the issue. Working and issued material is confidential. Later secure-vault implementation adds per-document encryption keys and hardware-backed access; until then, files shall stay only in approved controlled storage. Public extracts are new controlled outputs, never copies of the engineering package.
<!-- PROFESSIONAL_EXPANSION_END -->
