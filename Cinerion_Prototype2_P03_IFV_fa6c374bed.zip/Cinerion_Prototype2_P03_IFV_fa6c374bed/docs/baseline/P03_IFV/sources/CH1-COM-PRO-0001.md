---
document_number: CH1-COM-PRO-0001
title: Communication and Protocol Specification
discipline: Communications
document_type: Specification
document_state: Populated
purpose: Defines the common device model, message envelope, protocol profiles and resilient communication algorithms.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-COM-ICD-0001
- CH1-CYB-CSRS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Common device and message model

Every ESP32, Arduino-compatible node, PLC, instrument and fabrication adapter publishes a capability manifest containing stable device ID, type, firmware/software version, configuration revision, supported commands, telemetry channels, protocol endpoints and security profile. Domain logic addresses semantic capabilities such as `prepareProcedure`, `readMeasurement` or `setMaintenanceMode`, never a vendor register number. Adapter maps are configuration-controlled.

## MQTT 5 profile

MQTT carries telemetry, events, status and guarded command envelopes over TLS with device certificates and topic ACLs. Topics are scoped by environment/project/site/cell/device and message class. QoS is chosen by semantics: telemetry tolerates bounded loss where declared; critical events require confirmed delivery; a QoS acknowledgement is never treated as physical execution. Retained messages are limited to safe state/manifest use and cannot arm equipment.

## OPC UA and Siemens PLC profile

OPC UA uses a dedicated application certificate, trust list, SignAndEncrypt and least-privilege user/service mapping. The information model exposes device state, command handshake, diagnostics and selected measurements. For S7-1200 G2, availability and runtime licence are confirmed before purchase. Server methods or data nodes implement named semantic transactions; browsable nodes are not automatically writable. Certificate renewal and rejection of untrusted endpoints are tested.

## Modbus, serial and CAN profiles

Modbus TCP/RTU is contained behind EdgeLink or the control zone. The map separates read-only telemetry, configuration and command handshake; arbitrary function codes and address ranges are denied. Serial frames define preamble, version, length, source, destination, type, sequence, payload, CRC and timeout. CAN/CANopen uses controlled object dictionaries and heartbeat/error states. Loss of bus sets quality invalid and does not imply command success.

## Reliability algorithms

Duplicate suppression uses message ID and sequence windows. Retries use exponential backoff with jitter and stop at expiry. Store-and-forward applies only to eligible data. Flow control caps memory and disk, preserving newest critical events according to policy. Connection restoration requires reauthentication, capability reconciliation and state synchronisation; prepared commands are cancelled across reboot or material state change.

## Commissioning and diagnostics

Commissioning records endpoint, certificates, firmware, configuration, network parameters, protocol conformance and negative-path results. Diagnostics report latency, error counts, reconnects, queue depth, clock quality and last valid sample. Sensitive protocol logs redact tokens, private values and credentials while retaining correlation.
<!-- PROFESSIONAL_EXPANSION_END -->
