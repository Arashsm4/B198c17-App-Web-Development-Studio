---
document_number: CH1-COM-ICD-0001
title: Interface Control Document
discipline: Communications
document_type: Specification
document_state: Populated
purpose: Defines controlled internal and external interfaces, ownership, direction, transport and versioning.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SAD-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Interface-control principles

An interface is controlled when endpoints, owner, transport, direction, contract, version, security, timing, failure behaviour and verification are explicit. Internal APIs are treated with the same discipline as external protocols. The sender owns semantic correctness and identity; the receiver validates schema, authority, state and bounds. Neither endpoint assumes that a connected peer is trustworthy merely because communication succeeds.

## Contract structure

Messages include schema version, message type, message ID, correlation ID, source and destination identities, project/cell/asset scope, timestamp, time quality, sequence, expiry where relevant, payload and integrity context. Commands additionally include expected state, configuration revision and idempotency key. Telemetry includes engineering unit, quality and source sample time. Errors use stable codes and actionable detail without leaking secrets.

## Compatibility and change

Contracts use additive evolution within a supported major version. Unknown optional fields are ignored safely; unknown mandatory semantics fail closed. Breaking changes require a new major version, migration, dual-read or staged cutover and conformance tests. PLC data blocks and Modbus maps are versioned like software APIs. Interface changes update the ICD, protocol specification, generated contracts, simulators and verification cases together.

## Security and trust boundaries

IP conduits default to TLS 1.3 with mutual identity where supported. OPC UA uses certificate trust and SignAndEncrypt. MQTT uses per-device certificates and topic ACLs. Modbus terminates at EdgeLink or a controlled PLC zone with allowlisted mappings and no general routing. Serial and CAN frames use length, CRC, sequence and timeout; their physical-zone trust does not grant command authority. R&D credentials cannot reach production endpoints.

## Timing, resilience and failure

Every live value has freshness and quality. Heartbeats include firmware and configuration revision. Retry is bounded and jittered; queues have explicit overflow behaviour. Telemetry may be stored and forwarded. Commands expire and are never replayed after reconnect. Partial failure produces a defined degraded state and diagnostic reason. Clock offset and time quality are observable so audit and TOTP decisions are not silently made on invalid time.

## Acceptance

Each interface has schema validation, positive exchange, malformed input, unauthorised peer, replay, timeout, disconnect/reconnect, version compatibility and load tests. The interface register is accepted when every runtime edge in the architecture appears exactly once with a named owner and test path.

{{TABLE:INTERFACES}}
<!-- PROFESSIONAL_EXPANSION_END -->
