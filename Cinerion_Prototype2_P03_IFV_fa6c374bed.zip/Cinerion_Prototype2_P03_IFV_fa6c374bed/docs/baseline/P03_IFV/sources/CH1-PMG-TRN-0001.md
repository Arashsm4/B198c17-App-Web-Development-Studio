---
document_number: CH1-PMG-TRN-0001
title: Documentation Release Transmittal and Open Action Summary
discipline: Project Management
document_type: Transmittal
document_state: Populated
purpose: Transmits the P03/IFV Cinerion baseline, defines its authority and records open actions and owner decisions.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-MDR-0001
- CH1-PMG-DCP-0001
- CH1-PMG-DRL-0001
- CH1-PMG-PCH-0001
- CH1-PMG-PEP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Release purpose and package content

This transmittal authorises the regenerated Cinerion P03/IFV package for engineering, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. It contains 42 separately controlled documents, applicable native registers, modular sources, generated LaTeX, build tools and validation evidence arranged by discipline. PDF files and the former combined binder are intentionally excluded.

## Owner decisions incorporated

Cinerion is confirmed as the name and CH1 remains the permanent namespace. `IR` replaces the full owner name in all current metadata. Independent review is scheduled after Prototype 1, not required as a named person before work starts. Security is raised to a defence-in-depth, zero-trust target with hardware-backed credentials, cryptographic RFID/NFC rather than UID trust, signed artifacts, encrypted-vault design and tamper-evident audit. The reference minimum PLC is Siemens S7-1200 G2 CPU 1212C class using STEP 7 Basic/TIA Portal. The confidential backbone will not be published; approved redacted extracts may be showcased on LinkedIn or other media.

## Authorised start scope

Repository setup, data model, identity, application, API contracts, simulators, documentation tooling, security tests, device SDKs and extra-low-voltage Prototype 1 assembly may begin. Procurement planning may use the reference PLC and security architecture, but exact order codes, PSU, output type, serial module, OPC UA runtime licence, credential reader and protective devices are verified before purchase.

## Deferred gates

After Prototype 1, IR nominates a competent independent reviewer or panel. Critical review comments close before detailed hardware freeze. Machine-specific risk assessment, safety-rated protective functions, final wiring inspection, key ceremony, TRR and FAT remain mandatory before hazardous energisation or production claims. These are timed lifecycle gates, not unanswered owner decisions.

## Handover and reading order

Start with this transmittal and the MDR. For each DOCX, go directly to teal Part A for unique content; return to Part 0 for authority and Part B for definitions/references. Future edits are made in the modular source and regenerated. The secure document vault and per-document encryption are specified for later implementation; this ZIP shall therefore be handled as confidential and stored only in an approved location.

{{TABLE:OPEN_ACTIONS}}

{{TABLE:DECISIONS_REQUIRED}}
<!-- PROFESSIONAL_EXPANSION_END -->
