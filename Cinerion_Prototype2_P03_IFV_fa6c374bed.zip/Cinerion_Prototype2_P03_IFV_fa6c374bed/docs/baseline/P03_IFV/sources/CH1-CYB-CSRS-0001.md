---
document_number: CH1-CYB-CSRS-0001
title: Cybersecurity Requirements Specification
discipline: Cybersecurity
document_type: Specification
document_state: Populated
purpose: Defines cybersecurity requirements for identities, applications, commands, devices, protocols, data and operations.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SRS-0001
- CH1-CYB-TMD-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Security principles and assurance target

Cinerion applies zero implicit trust, least privilege, explicit verification, defence in depth, secure-by-default configuration, recoverability and measurable evidence. Security is evaluated across human identity, device identity, services, commands, industrial conduits, data, software supply chain, documents and operations. The release target is no known unresolved critical vulnerability within tested scope, not an impossible claim of 100% security.

![Cinerion security zones and controlled conduits](assets/security-zones.png)

# Zones, conduits and trust boundaries

The User/Application Zone contains authenticated clients and no controller credentials. The Service/Data Zone contains Control Core, identity, database, broker and policy services with distinct service accounts. The Gateway Zone contains EdgeLink and protocol termination; it is not a general router. The Control/Device Zone contains ESP32-S3, Arduino node, S7-1200 G2 PLC and local HMI. Evidence/Backup and Administration zones are separated from routine users. ResearchBench uses isolated credentials and denied production routes. Conduits are deny-by-default, directional, allowlisted by protocol/identity and negative-tested. Modbus and unauthenticated serial traffic terminate at controlled adapters.

# Identity, authentication and authorisation

Human access supports FIDO2/WebAuthn passkeys or security keys as the preferred phishing-resistant factor, with TOTP as a controlled secondary/recovery method where appropriate. Sensitive security, configuration, release and vault actions require step-up authentication. Physical cell authentication uses a cryptographic smart card/NFC or FIDO-class device with challenge-response; UID is never proof. Service and device identities are unique, scoped, revocable and rotated. Authorization evaluates role, project, object, action, device/session posture and current system state.

# Cryptography and key management

IP services default to TLS 1.3; mTLS is used for devices and sensitive service conduits. OPC UA uses SignAndEncrypt and managed trust lists. Algorithms and formats are versioned for agility. Root and long-lived private keys are non-exportable in TPM, secure element or hardware token where supported. Key generation, enrolment, backup, rotation, revocation, destruction and compromise response are documented. Per-document data keys are independently wrapped by a protected key-encryption key in the future vault. Logs never contain private keys, document passwords or reusable tokens.

# Platform, firmware and supply-chain security

Hosts use secure boot where available, minimal services, patch baselines, endpoint protection, restricted administration and encrypted storage. ESP32 production profiles use signed boot, flash encryption and anti-rollback according to staged fuse procedures. Software releases have pinned dependencies, SBOM, vulnerability scan/disposition, secret scan and signed/checksummed artifacts. CI runners and build credentials are isolated. An unreviewed dependency or artifact cannot enter the release because compilation succeeds.

# Command and industrial-protocol security

Commands are semantic, scoped, unique, expiring and state-bound. PREPARE is insufficient to actuate. Local credential and button cannot be emulated remotely. Reboot, stale state, changed revision, replay or lost permissive cancels. PLC interaction uses versioned handshake data, not arbitrary register writes. Communication acknowledgement proves transport only. The local safety architecture remains independent of network and standard PLC security.

# Detection, response and recovery

Security events retain attributable identity, correlation, qualified time, decision and result in a tamper-evident chain. Alerting covers repeated authentication failure, revoked device use, trust-list change, unexpected protocol write, audit-chain failure, clock degradation and secret exposure. Incident response contains, preserves evidence, rotates credentials, restores from verified backups and tests recurrence prevention. Recovery access is sealed, dual-controlled and audited.
<!-- PROFESSIONAL_EXPANSION_END -->
