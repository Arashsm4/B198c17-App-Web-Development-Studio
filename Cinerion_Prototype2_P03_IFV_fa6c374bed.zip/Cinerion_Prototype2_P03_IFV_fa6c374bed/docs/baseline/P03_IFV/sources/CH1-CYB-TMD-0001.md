---
document_number: CH1-CYB-TMD-0001
title: Threat Model and Security Risk Assessment
discipline: Cybersecurity
document_type: Assessment
document_state: Populated
purpose: Models assets, trust boundaries, misuse cases, threat scenarios and planned mitigations.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SAD-0001
- CH1-CYB-CSRS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Threat-modelling method

The model combines asset/trust-boundary analysis, data-flow review, STRIDE-style threat discovery, industrial zones/conduits, abuse cases and risk scoring. Scope includes users, portal, APIs, identity, broker, database, evidence store, CI, host, EdgeLink, PLC, microcontrollers, credential reader, part reader, document vault, backup and publication workflow. Threats are tied to concrete assets and entry points rather than generic lists.

## Assets and adversaries

Critical assets include command authority, local-confirmation integrity, safety boundary, identities and keys, product/work definitions, PLC/firmware configuration, audit/evidence, controlled documents and unreleased intellectual property. Adversaries include an external attacker, malicious/compromised user, stolen credential holder, compromised dependency, rogue device, mistaken operator and curious public recipient of redacted material. Physical access is considered because the prototype is a bench device.

## High-consequence abuse cases

Priority cases are remote emulation of the local button; replay of a valid command after reconnect; forged PLC acknowledgement; cloned NFC UID accepted as a person; direct Modbus write bypassing CommandGuard; experiment credentials reaching production; audit or evidence substitution; malicious firmware; vault unlock by tag UID; recovery-key misuse; and public screenshots disclosing confidential architecture or credentials. Each case identifies prevention, detection, recovery and retained evidence.

## Scoring and treatment

Likelihood considers exposure, attacker capability, required access and existing controls. Impact considers physical harm potential, command integrity, confidentiality, traceability, availability and recovery. Risk treatment is mapped to requirements and tests. Controls are not credited merely because documented; residual risk is updated after implementation and negative testing. Critical findings block the affected gate.

## Validation programme

Tests include authentication bypass, privilege escalation, wrong-object access, cross-project isolation, replay/duplication, command tampering, stale state, untrusted certificates, malformed protocol frames, unauthorized PLC writes, signed-boot failure, secret scanning, audit-chain mutation, backup restore, vault credential revocation and redacted-publication diff. HIL verifies that cyber failure cannot cause automatic physical execution or resume.

## Maintenance

The threat model is revisited for every new external interface, privilege, credential technology, PLC module, public feature, dependency incident or architecture change and after Prototype 1. Vulnerability reports create linked risks and changes. Details that materially lower attack cost are Restricted and omitted from public showcase output.

{{TABLE:THREATS}}
<!-- PROFESSIONAL_EXPANSION_END -->
