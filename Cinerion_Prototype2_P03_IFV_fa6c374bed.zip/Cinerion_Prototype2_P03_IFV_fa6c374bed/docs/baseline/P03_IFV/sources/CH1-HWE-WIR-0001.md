---
document_number: CH1-HWE-WIR-0001
title: Wiring and Connection Schedule
discipline: Hardware Engineering
document_type: Schedule
document_state: Preliminary schedule
purpose: Defines preliminary point-to-point connections and reserves final terminal, cable and conductor assignments.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-HWE-IOL-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Wiring-control principles

The connection schedule controls point-to-point intent from source terminal to destination terminal, including signal ID, conductor/cable, voltage class, shield/earth treatment and installation status. It complements but does not replace the schematic. Connection IDs remain stable through routing changes. Terminal numbers are frozen only after component selection and enclosure layout; P03 placeholders shall not be interpreted as shop-ready wiring.

## Segregation and conductor selection

Extra-low-voltage logic, mains, actuator power, analogue/instrument, network and safety circuits use defined separation and routing. Conductor cross-section is selected from current, voltage drop, fault protection, terminal capability, ambient and flexibility. Wire colour and ferrule/marker follow the project convention and applicable installation rules. Multi-core cable pairs and shields are identified consistently at both ends.

## Earthing, shielding and EMC

Protective bonding is short, mechanically secure and independently verifiable. Functional earth and cable shield termination are recorded separately. Sensitive signals avoid shared returns with switched loads. Inductive suppression is located at the load where practical. RS-485 topology, termination and bias are shown. Ethernet shield/chassis treatment follows selected industrial components. No shield drain or chassis path is improvised during commissioning without drawing update.

## Controller interfaces

Microcontroller I/O passes through industrial conditioning appropriate to 24 V signals. PLC PROFINET and Ethernet links use managed/controlled ports where required. Modbus RTU uses the selected CB/CM module and isolated transceiver topology. The credential reader wiring includes power, communications, tamper if available and physical separation from the part-identification reader. Confirmation button and lamp are separately wired so lamp failure cannot simulate a press.

## Installation and verification

Installation records cable ID, endpoints, routing exceptions and installer. Verification includes visual workmanship, conductor identity, terminal torque or push-in seating, continuity, absence of shorts, polarity, shield/earth, supply insulation where applicable and functional point test. Test equipment and results are recorded. Redlines are reconciled before as-built issue. Any discrepancy between schedule, I/O list and actual panel blocks energisation of the affected circuit.

{{TABLE:WIRING}}
<!-- PROFESSIONAL_EXPANSION_END -->
