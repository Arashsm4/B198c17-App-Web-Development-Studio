---
document_number: CH1-SWA-SDP-0001
title: Software Development and Coding Plan
discipline: Software Architecture
document_type: Plan
document_state: Populated
purpose: Defines repository, languages, coding rules, reviews, CI, dependency control, testing and release conventions.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-CMP-0001
- CH1-SYS-SAD-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Repository and component structure

The repository is organised by applications, core services, identity, firmware, PLC logic, shared packages, infrastructure, simulators, tests and controlled documents. Boundaries follow domain authority rather than deployment fashion. The first release is a modular monolith where practical, with adapters isolated so measured performance or security needs can later justify extraction without rewriting domain rules.

## Language and coding baseline

The universal client uses strict TypeScript, generated API types and React Native/Expo-compatible structure. C#/.NET 10 LTS services use nullable references, analysers, explicit cancellation, structured logging and dependency injection. ESP-IDF C++/FreeRTOS uses bounded memory/queues and explicit tasks; Arduino-compatible C++ is limited to secondary I/O. PLC code uses IEC 61131-3 Structured Text, named function blocks, symbolic tags and PLCSIM tests. Python runs in isolated analysis/report services outside authentication, approval and command paths.

## Branch, review and CI

Protected main and release branches reject direct unverified changes. Work links to a requirement, defect, risk or ADR. CI builds, formats, lints, runs unit/integration/contract/security tests, scans secrets/dependencies, generates SBOM and verifies documentation consistency. Command, identity, cryptography, migration, firmware and PLC changes require elevated review; after Prototype 1, critical areas require independent reviewer participation.

## Secure development lifecycle

Threat modelling precedes exposed features. APIs validate all input and enforce server-side policy. Secrets are injected from controlled storage. Dependencies are pinned and reviewed; vulnerabilities have severity, exploitability, exposure, owner and remediation. Builds retain provenance and artifact hashes/signatures. Security logs avoid sensitive payloads. Fuzzing targets parsers and protocol boundaries. No debug bypass enters a production profile.

## Test strategy

Unit tests cover domain invariants and state transitions. Contract tests protect API/device schemas. Integration tests exercise database, broker and identity. Simulator tests cover PLC/MCU behaviour. HIL tests exercise electrical timing and failure. End-to-end tests prove digital thread and guarded command. Property/negative tests challenge replay, idempotency, authorization and stale state. Performance tests use defined workloads and percentiles.

## Release and maintenance

Semantic versions identify software; configuration and database migrations are compatible and reversible. A release contains source commit, build environment, SBOM, images/packages, migrations, firmware/PLC archives, known issues and rollback. Supported LTS/security patch windows are monitored. Deprecated interfaces publish migration and removal dates. AI-assisted code is reviewed and tested exactly like any other contribution.
<!-- PROFESSIONAL_EXPANSION_END -->
