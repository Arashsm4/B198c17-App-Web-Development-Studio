---
document_number: CH1-OPS-OMM-0001
title: Operation and Maintenance Manual
discipline: Operations
document_type: Manual
document_state: Preliminary manual
purpose: Defines normal operation, local confirmation, alarms, maintenance, calibration and controlled recovery.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-CON-0001
- CH1-SAF-SCS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Operational roles and readiness

Only trained, authorised users operate within their assigned role and scope. Before starting, verify correct project/site/cell, released procedure and part, active baseline, device health, live/fresh data, calibration, resource reservation and safe physical condition. Maintenance and simulation modes are conspicuous. Unknown or stale state is treated as unavailable, not assumed healthy.

## Startup and shutdown

Startup energises infrastructure and controllers in a defined order with outputs inhibited, self-tests and state reconciliation. The cell reaches Idle only after configuration, identity, communications and permissives are valid. Controlled shutdown completes or aborts work safely, persists evidence, removes configured enables and verifies terminal state. Emergency isolation follows machine-specific instructions and is independent of the portal.

## Running a procedure

The Engineer or authorised user selects the released work order and prepares semantic intent. The Local Confirmer authenticates at the correct cell using the cryptographic credential and checks physical readiness. The illuminated button is pressed once within the window. The automatic sequence is observed; users do not click through hidden steps. Any unexpected condition uses stop/isolation appropriate to the machine and is recorded.

## Alarms, faults and recovery

Alarm acknowledgement confirms awareness only. Clear occurs when the condition is removed according to design. FaultLatched requires diagnosis, corrected cause, local authorised reset and state reconciliation; a reset never commands motion. Repeated faults are escalated. Network or application loss does not stop local safety and does not cause automatic resume after recovery.

## Maintenance, calibration and change

Maintenance uses controlled work instructions, lockout/isolation where applicable, tools and evidence. Device replacement requires identity/configuration enrolment and tests. Calibration-expired instruments are blocked from acceptance work. PLC/firmware/configuration changes use approved baselines and rollback. Temporary forces/bypasses are time limited, visible and removed/verified before return.

## Security and document handling

Report lost credentials immediately; revocation precedes replacement. Do not share tokens, PINs or document passwords. Confidential files stay in approved storage. Public screenshots/extracts use the redaction workflow. Security incidents preserve logs and avoid destructive investigation. Backups and restore tests are reviewed.

## Troubleshooting principle

Diagnose from power and physical state through controller, network, services and application, using correlation IDs and quality/freshness. Never bypass an interlock or write raw PLC registers to make a symptom disappear. Escalate when the controlled recovery path does not resolve the condition.
<!-- PROFESSIONAL_EXPANSION_END -->
