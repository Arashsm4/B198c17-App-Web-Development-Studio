---
document_number: CH1-CYB-IAM-0001
title: Identity, MFA and Physical Credential Design
discipline: Cybersecurity
document_type: Design
document_state: Populated
purpose: Defines login, passkey, TOTP, smart-card, local-presence and credential lifecycle controls.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-CYB-CSRS-0001
- CH1-AUT-FDS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Identity classes and assurance

Cinerion distinguishes human users, service workloads, physical devices, external instruments and recovery identities. Each identity has a stable ID, owner, assurance level, permitted authenticators, lifecycle status and scope. Shared human accounts are prohibited. Device identity is not inferred from IP or MAC address. Authentication establishes an identity; authorization separately evaluates whether that identity may perform the requested action on the current object and state.

## Human authentication

Phishing-resistant FIDO2/WebAuthn passkeys and hardware security keys are preferred for normal and privileged access. TOTP follows RFC 6238 and is used only within the approved assurance/recovery policy. Passwords, where retained for bootstrap or recovery, are rate limited, stored with a current memory-hard password hash, checked against compromise policy and never used alone for sensitive actions. Step-up is required for credentials, roles, security policy, device trust, release, publication and physical-effect preparation.

## Physical credential design

Local presence uses a cryptographic credential and reader capable of challenge-response, not a cloneable RFID UID. The provider abstraction supports a secure smart card/DESFire-class implementation or an NFC-enabled FIDO/security token. The controller receives a signed/verified proof bound to user, cell, transaction, nonce and short validity window. PIN/user verification is required according to credential capability and risk. RC522-class readers are restricted to part identification.

## Enrolment and lifecycle

Enrolment verifies the person, assigns roles separately, records credential serial/public key and issues recovery material through a controlled ceremony. Credentials can be suspended, revoked, replaced and expired without deleting history. Lost-token response revokes first, then issues replacement. Device certificates are provisioned uniquely and rotated before expiry. Service identities use workload-bound secrets with no interactive login.

## Sessions and policy

Sessions have inactivity and absolute limits, secure cookies/tokens, audience and device context. High-risk actions require recent authentication. Project, site, cell, asset and object scopes are enforced server-side. Local Confirmer assignment is checked at confirmation time. A wrong-cell credential, revoked token, stale session or reduced device trust fails closed. Reauthentication never replays a pending command.

## Recovery and break-glass

Recovery avoids weakening the primary model. Offline codes or administrative recovery keys are sealed, split or dual-controlled, time bounded and rotated after use. Break-glass access cannot bypass physical confirmation or safety. Every recovery action alerts, records reason and creates a mandatory review. The secure document vault uses hardware-backed unlock plus PIN/passkey; an RFID tap alone is never sufficient.

## Audit and privacy

Authentication logs record identity, authenticator class, result, policy reason, device/session, target scope and qualified time without sensitive biometric, PIN, private-key or reusable-token content. Retention supports investigation and credential review while minimising personal data.
<!-- PROFESSIONAL_EXPANSION_END -->
