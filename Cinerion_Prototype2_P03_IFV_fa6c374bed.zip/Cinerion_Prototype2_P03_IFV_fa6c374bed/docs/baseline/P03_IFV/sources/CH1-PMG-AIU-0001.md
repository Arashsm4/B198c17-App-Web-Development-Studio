---
document_number: CH1-PMG-AIU-0001
title: AI Usage and Verification Register
discipline: Project Management
document_type: Register
document_state: Populated
purpose: Records AI-assisted work, human verification, evidence and prohibited decision boundaries.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-PEP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# AI-assistance governance

AI may accelerate research discovery, first-draft text, code suggestions, test-idea generation, consistency checks and report composition. It does not become an engineering authority. Every material output is attributable to a named human role, linked to the records used, reviewed for technical correctness and accepted through the same configuration process as human-created work.

## Permitted and prohibited uses

Permitted uses include restructuring owner instructions, detecting cross-document discrepancies, producing non-executable examples, proposing threat cases and drafting prose for human verification. Prohibited uses include authenticating a user, approving a change, selecting a safety function without competent review, fabricating a test result, releasing a part, clearing an alarm, locally confirming a command, generating production secrets or controlling equipment. AI-generated confidence language is not evidence.

## Data-handling controls

Private keys, passwords, recovery codes, personal data, customer secrets, exact vault credentials and restricted unredacted material shall not be sent to an external AI service. Inputs are minimised and redacted. Outputs are scanned for leakage, insecure code patterns, invented sources and copied licensed-standard text. Public sources are cited by URL; licensed standards are referenced but not reproduced.

## Verification method

Technical claims are checked against controlled Cinerion records, authoritative vendor documentation, official standards pages, executable tests or direct inspection. Code proposals pass linting, static analysis, unit/integration tests and human review. Security designs receive threat-model review. Text that cannot be verified is labelled assumption, proposal or open action rather than written as fact.

## Publication and accountability

AI assistance does not change copyright ownership or publication restrictions. Redacted showcase material undergoes the same clean-room publication workflow as any other output. The register records activity, contribution, human authority, verification and status; it need not reproduce raw prompts when those prompts contain confidential project context. The goal is transparent assistance with accountable human engineering—not concealment and not false claims of independent authorship.

{{TABLE:AI_USAGE}}
<!-- PROFESSIONAL_EXPANSION_END -->
