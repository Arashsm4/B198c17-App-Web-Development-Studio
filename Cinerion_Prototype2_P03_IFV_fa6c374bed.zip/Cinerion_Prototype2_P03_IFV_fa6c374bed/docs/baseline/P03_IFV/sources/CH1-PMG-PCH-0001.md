---
document_number: CH1-PMG-PCH-0001
title: Project Charter and Business Case
discipline: Project Management
document_type: Charter
document_state: Populated
purpose: Authorises the project and fixes its mission, value proposition, scope, constraints and success criteria.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents: []
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Authorised mission and business case

Cinerion is authorised as a modular, local-first platform that connects engineering definition, controlled work, heterogeneous controllers, inspection evidence and physical-part genealogy. Its value is not a single dashboard or device driver; it is the ability to prove how an authorised intent became a locally committed physical action and how that action produced traceable evidence. The first demonstrator is ReFab MicroStation, while the architecture remains reusable for research cells, test rigs, pilot manufacturing and inspection systems.

## Objectives

The project shall demonstrate secure identity, guarded semantic commands, cryptographic proof of local presence, deliberate physical confirmation, deterministic controller behaviour, ESP32/Arduino/PLC interoperability, revision-controlled manufacture, measurable acceptance limits, NCR/rework/retest and report generation. It shall also provide cross-layer monitoring, resource coordination, contextual communication and isolated R&D workspaces without giving those functions an ungoverned path to equipment.

## Scope boundaries

In scope are the universal application, Control Core, FortressGate, CommandGuard, ConfirmGate, EdgeLink, ProtocolFabric, data and audit services, ESP32-S3 controller, secondary Arduino I/O node, Siemens S7-1200 G2 PLC integration profile, simulators, hardware demonstration cell, controlled documents and verification assets. Out of scope for P03 are machinery certification, production deployment, safety-system replacement, remote manual jogging as a principal workflow, and disclosure of the confidential backbone. A future secure transport platform may connect only below the stable provider boundary.

## Constraints and assumptions

The solution is budget-aware, locally operable without public internet, implementable by a small engineering team and designed for staged procurement. Standard non-safety hardware is used for Prototype 1 at extra-low voltage. Standards guide the design, but P03 makes no certification claim. No credential UID, network location, AI output or portal role is accepted as independent proof of safety or local presence.

## Value and success measures

Success is achieved when a reviewer can select one physical part and reconstruct the active product revision, work order, resource reservation, authenticating identity, prepared command, local credential proof, button edge, permissive sample, PLC/ESP32/Arduino execution, measurements, inspection result, deviation history and release authority. The same reviewer must be able to verify that replay, stale state, cloned identifiers, communication loss, wrong-cell credentials and unauthorised direct writes are rejected.

## Authorisation

IR authorises P03 engineering, software, simulation and controlled Prototype 1 work. Independent review is a planned post-Prototype-1 gate. Publication authority is limited to separately generated redacted extracts; the complete source, detailed security architecture, credentials, configuration and proprietary backbone remain confidential.
<!-- PROFESSIONAL_EXPANSION_END -->
