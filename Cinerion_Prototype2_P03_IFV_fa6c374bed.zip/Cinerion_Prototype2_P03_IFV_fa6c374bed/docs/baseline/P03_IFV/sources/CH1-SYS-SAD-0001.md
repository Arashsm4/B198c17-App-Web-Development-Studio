---
document_number: CH1-SYS-SAD-0001
title: System Architecture Description
discipline: Systems Engineering
document_type: Architecture
document_state: Populated
purpose: Defines system context, logical, deployment, data, security and runtime architecture viewpoints.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-BOD-0001
- CH1-SYS-SRS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Architecture viewpoints and rationale

The architecture is described through context, logical component, deployment, data, interface, security and runtime viewpoints because no single diagram can express both authority and implementation. Each viewpoint names concerns and stakeholders. Cross-view consistency is enforced by stable identities and interfaces: a logical service must have a deployment location, data ownership, security zone and test allocation.

![Cinerion deployment topology](assets/deployment-topology.png)

![PREPARE and LOCAL COMMIT runtime sequence](assets/prepare-local-commit.png)

## Logical decomposition

The Universal Application presents operations, engineering, inspection and field workflows. Control Core owns domain invariants. FortressGate owns identity and policy context. CommandGuard owns semantic intent and prepare transactions. ConfirmGate owns local credential proof and deliberate button confirmation. EdgeLink and ProtocolFabric own replaceable industrial adapters. ForgeFlow owns product/work definition, TraceCore owns genealogy and release state, OpenInspect owns tests, AssetVault owns devices/instruments, ContextBridge owns contextual communication, ResourceOrchestrator owns allocation, ResearchBench owns isolated experiments, ReportForge owns deterministic reports and Audit Service owns append-only critical events.

## Deployment and trust boundaries

Reference services run as a local modular monolith plus isolated infrastructure containers on a hardened host. PostgreSQL, broker, identity, evidence and backup functions have distinct service identities and storage permissions. EdgeLink is dual-homed only where necessary and has no general routing function. ESP32-S3, Arduino node and S7-1200 G2 PLC occupy the control/device zone. Administration uses a separate path. Public internet is not required for principal workflows.

## PLC integration

The CPU 1212C class exposes a versioned capability manifest and named handshake data blocks. EdgeLink communicates through secured OPC UA where licensed or an allowlisted Modbus/PROFINET profile. Commands carry ID, sequence, expected state and expiry; acknowledgements return accepted state and reason. Direct UI register writes are prohibited. STEP 7 Basic/TIA Portal archives, compiled block hashes and hardware configuration join the release baseline.

## Data and runtime integrity

Transactional work, identity, configuration and inspection data reside in PostgreSQL. High-rate telemetry uses bounded ingestion and retained summaries; immutable evidence binaries are content addressed. Runtime physical action follows request, policy, PREPARE, controller precheck, credential proof, button edge, final permissive sample, LOCAL COMMIT, execution, result and audit. Any restart reconciles persisted and controller state without replay.

## Quality attributes

Module boundaries support maintainability and later extraction without premature distribution. Simulators support early testing. Store-and-forward supports telemetry resilience while excluding commands. Observability includes freshness and quality. Zero-trust policy and zone isolation reduce lateral movement. The architecture deliberately prefers explicit failure and operator guidance over hidden automatic recovery.
<!-- PROFESSIONAL_EXPANSION_END -->
