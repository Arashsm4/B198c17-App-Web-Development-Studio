---
document_number: CH1-REL-RLN-0001
title: Release Notes and As-Built Configuration
discipline: Release Engineering
document_type: Release Record
document_state: Controlled release template
purpose: Defines release identity, included components, as-built configuration, evidence, known limitations and rollback.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-CMP-0001
- CH1-VVT-STR-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Release-record purpose

This document records what was actually released, not what was planned. P03 therefore provides the structure and preliminary configuration rules but does not invent an as-built state. Each future release receives software version, baseline, date, authority, compatibility, security status and immutable manifest. Superseded releases remain recoverable according to retention.

## Release content

Record application/service packages and hashes, container digests, database schema/migrations, API/message versions, firmware binaries and source reference, STEP 7 PLC archive and compiled-block/hardware-configuration hash, device manifests, BOM/serials, wiring/I/O revision, credential technology, certificates/trust profile, procedures, evidence, SBOM, vulnerability disposition, known issues and documentation revisions.

## As-built configuration

As-built means the running/connected system has been reconciled to the record by inspection and automated inventory. Substituted components, configuration values and wiring redlines are incorporated. Device serial/credential IDs are stored at appropriate classification. A standard S7-1200 CPU is identified without any false safety credit. The document-vault configuration records encryption/key architecture and recovery test but not passwords or private keys.

## Compatibility and upgrade

State supported previous versions, database migration path, device/PLC firmware compatibility and client minimums. Upgrade steps include safe equipment state, backup, verification, migration, health checks and controlled promotion. Rollback or forward repair is tested. Pending or prepared commands are cancelled across incompatible transitions.

## Security and known issues

Record SBOM, critical/high vulnerability disposition, signing/checksum verification, certificate/credential changes, penetration/HIL results and accepted residual risks. Known issues state impact, workaround/control, owner and target. Sensitive exploit detail may be in a Restricted annex, but the existence and release effect are not concealed.

## Release authority

IR may authorise P03 engineering artifacts within the stated boundary. Production/customer/as-built release requires completed Prototype 1 review, hardware/safety gates, mandatory test evidence and the later competent independent authority. Until those exist, the release record remains explicitly preliminary and `Not executed` for as-built acceptance.
<!-- PROFESSIONAL_EXPANSION_END -->
