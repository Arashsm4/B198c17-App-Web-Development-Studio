---
document_number: CH1-PMG-ICP-0001
title: Information Classification, Confidentiality and Copyright Procedure
discipline: Project Management
document_type: Procedure
document_state: Populated
purpose: Defines information classification, authorised use, confidentiality marking, copyright ownership, controlled disclosure,
  reproduction and disposal requirements.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-DCP-0001
- CH1-CYB-ACP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Information-classification model

Cinerion uses four handling classes: Public Redacted, Project Internal, Confidential Project, and Restricted Security/Secrets. P03 engineering documents default to `CONFIDENTIAL - PROJECT INTERNAL`; credential material, private keys, recovery codes, exact hardening values and unredacted threat details are Restricted even when referenced by a confidential document. Classification is determined from content and impact, not from convenience. A lower-class extract is a separately reviewed derivative with its own checksum and release record.

![Controlled document protection and publication lifecycle](assets/document-security-lifecycle.png)

## Defence-in-depth document vault

The target vault uses full-volume encryption for the storage device and envelope encryption for individual controlled documents or distribution containers. Each item receives a unique randomly generated data-encryption key. A separate key-encryption key, protected by TPM/secure element or hardware token, wraps those keys. Compromise of one document password shall not expose another document or the volume. Passwords are generated, never reused, and stored only in an approved password manager or hardware-backed secrets service; they are not embedded in filenames, manifests, emails or source control.

## Physical and software authentication

RFID/NFC UID alone is prohibited. Vault access requires cryptographic challenge-response from an approved smart card, FIDO2 security key or equivalent hardware credential plus user verification such as PIN or passkey. The reader, host and credential are mutually bound to an authenticated session. Lost, replaced, expired and revoked credentials are denied immediately. A break-glass path uses sealed offline recovery material, dual control and mandatory post-use rotation; it is not a standing bypass.

## Access, logging and distribution

Access is least-privilege, time-bounded and document-scope aware. Read, export, decrypt, redact, approve and publish are distinct permissions. Logs record subject, credential class, document ID, action, result, source device, qualified time and correlation ID without storing document passwords or reusable authentication secrets. External distribution uses uniquely encrypted containers, named recipients, expiry where supported, and a transmittal. Printed copies are watermarked and recorded or treated as uncontrolled.

## Redacted publication workflow

LinkedIn and other showcase publications may display architecture concepts, non-sensitive screenshots, test methods and selected results, but not the complete backbone, keys, network details, exploit-enabling configuration, proprietary algorithms or confidential evidence. Publication occurs in a clean export workspace: select approved source blocks; apply the redaction profile; flatten or remove comments and tracked changes; scrub authoring metadata and hidden XML; scan secrets and identifiers; compare the output against the source allowlist; add copyright and provenance; approve; checksum; then publish. A screenshot is treated as data and reviewed for visible tabs, filenames, serials, QR codes and background information.

## Assurance statement

The project targets the strongest practicable security and zero known critical weaknesses at release, but it shall never claim literal 100% security. Residual risk, cryptographic assumptions, recovery dependence and test coverage are stated honestly. The secure vault is a planned implementation control, not a claim that this unencrypted P03 handover ZIP already enforces those mechanisms.
<!-- PROFESSIONAL_EXPANSION_END -->
