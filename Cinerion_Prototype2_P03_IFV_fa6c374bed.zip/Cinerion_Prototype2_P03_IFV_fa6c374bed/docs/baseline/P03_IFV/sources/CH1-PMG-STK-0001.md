---
document_number: CH1-PMG-STK-0001
title: Stakeholder, Role and RACI Register
discipline: Project Management
document_type: Register
document_state: Populated
purpose: Identifies stakeholders, authorities, responsibilities and segregation-of-duty constraints.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-PCH-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Authority and segregation model

Roles are defined by decisions they may make, not by job titles alone. IR is project owner, preparer and P03 authorising authority. This concentration is transparently recorded for the early R&D stage. It does not satisfy later independent assurance. After Prototype 1, a competent reviewer or review panel is appointed for safety, hardware, cybersecurity and release-critical material before detailed hardware freeze and hazardous energisation.

## Core responsibilities

The Systems Architect owns system boundaries and cross-discipline consistency. Software, Embedded, Automation, Hardware, Cybersecurity, Data, UX and Verification leads own their discipline outputs and evidence. The Inspector witnesses or evaluates controlled acceptance results and is independent of the person who performed the operation for final release. The Configuration Manager controls baselines and changes. The Document Controller controls identity, issue and archive. The Local Confirmer proves deliberate presence but does not approve engineering or bypass safety.

## RACI application

Each controlled activity has one accountable authority, clearly identified responsible contributors, consulted specialists and informed stakeholders. `A` is not duplicated to avoid ambiguous approval. A person may hold multiple early-stage roles, but incompatible decisions are separated by workflow: the command requester cannot generate local credential proof; the operator cannot independently release their own failed/reworked part; the AI service cannot be responsible or accountable; and contextual-message acknowledgement cannot perform alarm or command authority.

## Competence and delegation

Delegation identifies scope, duration, prerequisites and revocation. Safety or cybersecurity review requires demonstrable competence for the subject. Access permissions do not prove competence. Contractors and temporary reviewers receive least-privilege access to the necessary document subset. Device and service accounts are stakeholders only for ownership and control purposes; they are never treated as human approvers.

## Review-panel trigger

Prototype 1 completion triggers the independent-review work package: provide the P03 baseline, implementation commit, as-built bench configuration, threat and hazard evidence, HIL results, open deviations and questions requiring specialist judgement. The reviewer records comments in the DRL. Critical comments block hardware freeze; major comments require disposition before TRR; minor editorial comments may be carried with an owner and due issue.

{{TABLE:STAKEHOLDERS}}
<!-- PROFESSIONAL_EXPANSION_END -->
