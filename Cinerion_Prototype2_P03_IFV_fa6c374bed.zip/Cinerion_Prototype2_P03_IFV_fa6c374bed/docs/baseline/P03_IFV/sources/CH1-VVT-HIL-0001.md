---
document_number: CH1-VVT-HIL-0001
title: Hardware-in-the-Loop Test Procedure
discipline: Verification
document_type: Procedure
document_state: Populated procedure
purpose: Defines the HIL configuration, prerequisites, execution steps, failure injection and evidence requirements.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-VVT-VMP-0001
- CH1-HWE-HDS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# HIL purpose and configuration

HIL verifies behaviour that software-only tests cannot prove: electrical signal polarity and timing, controller restart, watchdog, credential reader, physical button, PLC/MCU handshake, network loss and limited-energy actuator response. The setup uses safe dummy loads or guarded low-energy mechanisms, current-limited supplies and documented test points. The machine-specific safety system is not simulated as proof of certification.

## Preconditions and readiness

The active software/firmware/PLC/document baseline is recorded. Wiring and I/O are checked, instruments are in calibration, power limits are set, emergency isolation is accessible and hazards are briefed. Device certificates and test credentials are unique and revocable. The test operator identifies which inputs are physical, simulated or forced. Any unknown wiring, unexpected energisation or uncontrolled motion stops testing.

## Core execution groups

Tests prove startup non-energising state, capability discovery, valid PREPARE, wrong state/scope rejection, credential challenge-response, wrong-cell/revoked/clone attempt rejection, armed-lamp behaviour, button edge and stuck-input rejection, final permissive resample, local commit, automatic sequence and measured result. PLC tests load the controlled STEP 7 project, verify symbolic handshake and challenge direct/expired/duplicate writes. ESP32/Arduino tests challenge malformed frames and watchdogs.

## Fault injection and recovery

Faults include broker loss, Ethernet/WLAN disconnect, serial CRC error, OPC UA trust failure, Modbus timeout, controller reboot, brownout, clock degradation, sensor out-of-range, actuator limit, button held, credential removed and database/service restart. The expected response is defined per fault. No reconnect or restart may replay or resume a command. Recovery requires state reconciliation and local authorization where specified.

## Evidence and acceptance

Evidence includes setup image/diagram, device and instrument IDs, raw logs, captures, measured timing, controller diagnostics, results and deviations. A transport acknowledgement does not count as execution. Cases pass only against predeclared criteria. Failed cases remain open through defect correction and new retest execution. HIL completion supports Prototype 1 review; it does not bypass independent safety review.

{{TABLE:HIL_TESTS}}
<!-- PROFESSIONAL_EXPANSION_END -->
