---
document_number: CH1-DBA-DD-0001
title: Database Design and Data Dictionary
discipline: Data Architecture
document_type: Specification
document_state: Populated
purpose: Defines entities, identifiers, relationships, retention, integrity, audit and data-classification rules.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SAD-0001
- CH1-SYS-SRS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Data architecture and ownership

Data is divided into identity, physical system, engineering/production, execution/quality, collaboration, R&D and audit domains. Each entity has one system of record and owner. Stable IDs survive name and location changes. Referential integrity is enforced for controlled relationships; JSON is used only where variability is intentional and validated, not to avoid schema design.

## Temporal and provenance model

Records distinguish business-effective time, recorded time and qualified source sample time. Mutable master data uses revision or version fields; critical state transitions are append-only events. Measurements retain unit, quality, source device/channel, calibration context and transaction. Evidence binaries are content addressed with checksum, media type, classification and immutable link. Corrections add superseding records rather than rewriting history.

## Command, audit and genealogy integrity

Command transactions link requester, policy decision, work order, part, cell, device, prepare, credential proof reference, button event, local commit, state transitions and result. The audit chain is append-only under restricted privileges and hash linked so tampering is detectable. Part genealogy links product revision, BOM, route, consumed components, fabrication artifacts, tests, NCR/rework and release.

## Security and classification

Row/object policies enforce project scope. Sensitive identity, credential metadata and Restricted records are minimised and separately protected. Private keys and document passwords are not database values. Encryption at rest and in transit complements—not replaces—authorization. Backups inherit classification and are encrypted, access controlled and restore tested. Public-redacted exports use allowlisted views rather than filtering a full confidential dump after extraction.

## Telemetry and retention

High-rate telemetry enters a bounded pipeline with freshness and quality, then is retained raw or aggregated according to declared need. Critical events and acceptance measurements are never lost through telemetry downsampling. Retention is based on evidence, legal and project needs; deletion is authorised, logged and compatible with immutable-release obligations. Contextual messages cannot be allowed to become an uncontrolled permanent engineering decision record.

## Migrations and recovery

Schema migrations are ordered, tested on representative data, backward compatible during staged deployment and paired with rollback or forward-repair. Constraints and indexes are verified. Restore tests reconcile database, evidence store and audit-chain anchors. Any unreconciled restore blocks return to controlled operation.

{{TABLE:ENTITIES}}
<!-- PROFESSIONAL_EXPANSION_END -->
