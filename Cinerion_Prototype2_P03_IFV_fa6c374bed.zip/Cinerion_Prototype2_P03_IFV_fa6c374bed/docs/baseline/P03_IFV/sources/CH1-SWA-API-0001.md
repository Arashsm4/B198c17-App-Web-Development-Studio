---
document_number: CH1-SWA-API-0001
title: API Specification
discipline: Software Architecture
document_type: Specification
document_state: Populated
purpose: Defines service API conventions, endpoint catalogue, authentication, idempotency, errors and compatibility.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SAD-0001
- CH1-CYB-CSRS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# API design rules

APIs expose domain operations, not database tables or controller registers. Resource names are stable, nouns are plural where appropriate, commands are explicit actions only when state transition semantics cannot be represented safely as resource creation. OpenAPI and generated clients are built from the same contract. Every mutation has authority, validation, idempotency, concurrency and audit rules.

## Authentication and authorization

Interactive clients use OIDC/OAuth-style tokens bound to audience and scope. Service/device APIs use mTLS and workload/device identity. Authorization is server-side and evaluates role, project/object scope, authentication strength, session recency and state. Sensitive operations require step-up context. Errors do not reveal whether an inaccessible object exists.

## Versioning and compatibility

The path or media contract identifies a major version. Additive optional fields are backward compatible; changed semantics, removed required fields or enum reinterpretation require a new version. Clients send schema version and tolerate unknown optional fields. Deprecation includes telemetry of use, migration guide and removal gate. PLC and device adapters follow the same compatibility policy.

## Mutation controls

Clients provide idempotency keys for retriable creation. Optimistic concurrency uses entity version/ETag so stale updates fail explicitly. Physical-effect operations create semantic command transactions with expected state and expiry; they never expose `write register`. Configuration changes create proposals/revisions and do not directly start equipment. Message acknowledgement endpoints are separate from alarm/fault acknowledgement.

## Errors, query and realtime

Errors include stable code, human message, correlation ID and safe field details. Pagination uses bounded cursor queries. Filters are allowlisted and index supported. Realtime updates use WebSocket/event streams with sequence, snapshot version, freshness and reconnect reconciliation. Clients display disconnected/stale state instead of assuming continuity.

## Security and observability

Input has size, type, rate and semantic bounds. Uploads are scanned and content addressed. Logs record route, identity, scope, result, latency and correlation without tokens or secret payload. Rate limits protect identity, commands, exports and expensive queries. Negative tests cover broken-object authorization, injection, mass assignment, replay and cross-project leakage.

{{TABLE:API}}
<!-- PROFESSIONAL_EXPANSION_END -->
