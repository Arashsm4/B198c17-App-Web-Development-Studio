---
document_number: CH1-SYS-CON-0001
title: Concept of Operations
discipline: Systems Engineering
document_type: CONOPS
document_state: Populated
purpose: Describes actors, operating scenarios, equipment states, degraded modes and lifecycle use.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-BOD-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Actors, goals and operating context

The principal actors are Project Owner, Engineer, Local Confirmer, Inspector, Maintenance Engineer, Cybersecurity Administrator, Project Manager, Auditor and Viewer. Device and service accounts act only within machine scopes. An Engineer prepares a controlled procedure; CommandGuard validates authority and expected state; a Local Confirmer authenticates at the correct cell and presses the armed button after checking the physical situation; controllers execute automatically; an Inspector evaluates evidence and later releases independently.

## Normal operating scenario

An authorised user selects a released work order and identified physical part. Cinerion resolves product revision, route, required equipment, resource reservation and configuration. A semantic PREPARE request is created with unique transaction ID, expiry and expected state. The local controller validates authenticity and permissives, then arms ConfirmGate. The local credential is cryptographically verified and bound to the transaction. Only then is the button illuminated. A deliberate new edge causes final permissive resampling and local commit. Execution, telemetry, measurement and state transitions link to the same correlation chain.

## Inspection and nonconformity scenario

OpenInspect presents the controlled procedure, instruments, calibration status, steps and acceptance limits. Measurements retain unit, source, quality and time. Failed mandatory results place the part on hold and create or link an NCR. Rework requires an approved instruction and a new execution record; original evidence remains immutable. Retest is distinguishable from the first run. Final release is prohibited until all mandatory results pass and independent inspector authority is available.

## Degraded and recovery modes

Stale, disconnected, simulated, maintenance and unknown states are explicit. Loss of application or network never starts or resumes equipment. Telemetry may buffer, but commands are not stored for future execution. Controller reboot cancels every uncommitted prepare. Critical faults enter FaultLatched, remove configured enables and require local authorised recovery. Restoration reconciles controller state, persisted transaction and work-order status before returning to Idle.

## R&D and management scenarios

ResearchBench creates an isolated experiment revision with simulator targets, inputs, environment and evidence. It has no production route by default. Promotion requires change control and verification. ResourceOrchestrator may reserve a cell or propose configuration but cannot write outputs. ContextBridge may discuss an alarm or work order but cannot acknowledge the alarm or confirm a command. OperationsView shows source time and quality so a human can judge whether information is current.

## Lifecycle and post-prototype review

Prototype 1 demonstrates the complete low-energy flow with simulators and selected hardware. Its as-built evidence then becomes the input to independent review. Only after critical comments close may detailed hardware freeze, machine-specific safety design and hazardous energisation be considered.
<!-- PROFESSIONAL_EXPANSION_END -->
