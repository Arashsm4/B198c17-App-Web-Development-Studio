---
document_number: CH1-OPS-DPL-0001
title: Deployment, Backup and Recovery Manual
discipline: Operations
document_type: Manual
document_state: Preliminary manual
purpose: Defines repeatable installation, configuration, backup, restore, rollback and disaster-recovery actions.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SAD-0001
- CH1-CYB-CSRS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Deployment architecture and prerequisites

The reference deployment is local-first: hardened host, containerised Cinerion services, PostgreSQL, MQTT broker, identity/policy, evidence storage and EdgeLink, with segmented application, service/data, gateway, control/device, administration and backup zones. Prerequisites include supported OS, secure boot/TPM where available, time source, DNS/hostnames, certificates, storage capacity, backup target and current baseline manifest.

## Hardened installation

Install from verified artifacts and compare checksums/signatures before execution. Use dedicated non-root service identities, minimal capabilities, read-only filesystems where practical, explicit network rules, resource limits and no default credentials. Administrative interfaces bind only to the administration path. Database/broker ports are not exposed generally. Secrets come from a protected store and never from repository files or images.

## Certificates and key operations

Create a controlled trust hierarchy appropriate to the deployment, inventory certificates and define renewal/revocation. Device enrolment is unique. Hardware-backed key storage is preferred. The future secure document vault uses encrypted volume, per-document/container data keys and hardware-authenticated unlock; deployment includes recovery material and a tested key-loss procedure. No RFID UID-only unlock is permitted.

## Backup, restore and disaster recovery

Back up database, identity configuration, evidence, document source, manifests, certificate metadata and required encrypted key material according to classification. Use encrypted offline or separated copies and retention. Restore is tested to an isolated environment, validates checksums/audit chain, reconciles evidence references and confirms no pending command resumes. Recovery point/time objectives are measured and recorded.

## Update and rollback

Updates are staged through simulation/integration, migrate data compatibly, preserve rollback or forward-repair and verify health before promotion. Firmware/PLC updates require safe equipment state and controlled archives. Certificate or key rotations are rehearsed. A rollback cannot revive expired commands or superseded unsafe configuration.

## Monitoring and incident recovery

Monitor service/device health, capacity, queue depth, certificate expiry, backup success, audit-chain verification, clock quality and unauthorized attempts. Incidents preserve evidence, isolate affected identity/device, rotate secrets, restore trusted configuration and retest. Return to operation requires reconciled state and authorised decision.
<!-- PROFESSIONAL_EXPANSION_END -->
