---
document_number: CH1-SYS-BOD-0001
title: Basis of Design
discipline: Systems Engineering
document_type: Design Basis
document_state: Populated
purpose: Defines the authoritative design basis, boundaries, principles, assumptions, standards and engineering targets.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-PCH-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Design drivers and system boundary

Cinerion is designed around one governing question: can every consequential action and result be reconstructed from controlled intent to physical evidence without creating a remote bypass around local control? This drives local-first operation, semantic commands, explicit state, immutable identities, qualified telemetry, configuration control and layered security. The system of interest includes the application, services, gateway, controllers, demonstration hardware and controlled evidence. Machine-specific protective equipment remains a separate safety boundary.

![Cinerion logical and physical architecture](assets/system-architecture.png)

## Operating environment and constraints

The reference deployment is a local engineering workstation or edge host, one isolated demonstration cell, an ESP32-S3 principal controller, an Arduino-compatible secondary node and a Siemens PLC or simulator. Prototype 1 uses extra-low-voltage loads and simulated interlocks. Principal workflows function without public internet. Hardware is sourced incrementally, so interface profiles and simulators precede procurement. The system targets ten local users, twenty-five devices, 250 live channels and 100 sustained messages per second while keeping dashboards fresh and command acknowledgement bounded.

## Technology allocation

The universal application uses strict TypeScript with React Native/Expo-compatible patterns for web and field clients. Control Core, EdgeLink and deterministic service logic use C# on the supported .NET 10 LTS baseline with nullable references, analysers and cancellation. PostgreSQL owns transactional data and referential integrity. MQTT 5 carries events/telemetry; OPC UA, Modbus TCP/RTU, serial, CAN/CANopen and fabrication adapters map to versioned domain contracts. ESP-IDF C++/FreeRTOS runs the primary controller; restricted C++ supports secondary Arduino-compatible nodes. Python is isolated to analysis, tooling and report assistance with no command authority.

## Reference PLC and power posture

The reference minimum PLC is the Siemens SIMATIC S7-1200 G2 CPU 1212C class because it is the entry controller in the selected family while supporting expansion, integrated PROFINET, STEP 7 Basic/TIA Portal engineering and the required industrial integration path. The exact DC/DC/DC or DC/DC/relay order code, 24 VDC power supply, communication board/module and OPC UA runtime licence are confirmed before purchase. Modbus TCP is supported through the controlled PLC profile; Modbus RTU requires the selected serial interface. A standard CPU receives no machinery-safety credit.

## Security, information and publication posture

Trust is evaluated for user, device, service and request; a local IP address creates no implicit trust. Authentication uses passkeys/FIDO2 and step-up methods, while physical confirmation uses cryptographic credentials rather than cloneable UIDs. Keys are hardware-backed where practicable, conduits are deny-by-default, software/firmware is signed, and audit evidence is hash linked. The complete architecture and document set remain confidential. Public material is generated as a separate redacted derivative.

## Design acceptance

The basis is accepted for Prototype 1 when all technologies have an owner, interface contract and simulator; every physical-effect request crosses CommandGuard and local commitment; no portal or communication acknowledgement can satisfy a safety/interlock condition; performance targets have defined test methods; and unresolved procurement choices are explicitly gated rather than disguised as final design.
<!-- PROFESSIONAL_EXPANSION_END -->
