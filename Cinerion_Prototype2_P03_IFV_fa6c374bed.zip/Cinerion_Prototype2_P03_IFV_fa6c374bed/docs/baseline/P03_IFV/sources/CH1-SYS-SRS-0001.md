---
document_number: CH1-SYS-SRS-0001
title: System Requirements Specification
discipline: Systems Engineering
document_type: Specification
document_state: Populated
purpose: Establishes the uniquely identified functional, quality, security, safety and operational requirements.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-BOD-0001
- CH1-SYS-CON-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Requirements engineering rules

Every normative requirement uses `shall`, expresses one verifiable obligation, has a permanent ID, priority, allocation, verification method and test case, and avoids prescribing implementation unless the design decision is intentional. Explanatory text, goals and examples are not requirements unless separately identified. Ambiguous terms such as secure, fast, appropriate or user-friendly require a measurable criterion or referenced profile.

## Requirement classes

Functional classes cover identity, commands, communications, manufacturing, quality, traceability, monitoring, management, collaboration, R&D, reporting, operations, document security and PLC integration. Non-functional requirements cover performance, availability, recoverability, maintainability, audit, accessibility and security assurance. Safety-boundary requirements state what the general platform must not claim or bypass. Interface-specific details remain in the ICD and protocol specification but trace to system obligations.

## Security and physical-control interpretation

The highest security target is implemented as defence in depth and demonstrable assurance, not a promise of literal invulnerability. Requirements demand zero implicit network trust, cryptographic identity, hardware-backed keys where practicable, signed boot/release artifacts, deny-by-default zones, protected logs and controlled recovery. The local button is a readiness confirmation, not an emergency stop. The standard S7-1200 G2 PLC is not safety rated for this project. No remote path, AI function, notification or cloneable RFID UID may satisfy local physical confirmation.

## Verification and acceptance

Each requirement maps one-to-one to a primary test case in P03; supporting inspections and analyses may add evidence. Test methods define preconditions, stimuli, expected output, objective acceptance and retained evidence. Requirements whose physical verification awaits procurement retain a specified design status and `Not executed` evidence state. A requirement is not considered verified because its document is approved.

## Change and quality control

Changes are assessed for upstream objective, dependent interfaces, data, firmware, PLC, hardware, operations, threat/hazard controls and tests. Duplicate or conflicting statements are rejected by automated and human review. The RTM shall have no orphan requirement or test. Priority `Must` means the stated baseline cannot be released without compliance or an explicit approved deviation; it is not a schedule preference.

## Baseline interpretation

The P03 table is the implementation contract for Prototype 1 and subsequent verification within the release boundary. The Siemens CPU 1212C class requirement is a reference minimum, not a final order code. Document-vault encryption requirements describe the planned secure storage implementation and are tested when that subsystem exists; they do not falsely claim that the current ZIP is encrypted.

{{TABLE:REQUIREMENTS}}
<!-- PROFESSIONAL_EXPANSION_END -->
