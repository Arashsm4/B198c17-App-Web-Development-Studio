---
document_number: CH1-PMG-RSK-0001
title: Project Risk Register and Management Plan
discipline: Project Management
document_type: Register
document_state: Populated
purpose: Defines the risk method and records initial delivery, technical, security, safety and evidence risks.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-PEP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Risk-management method

Risks are recorded as uncertain events with cause, event, consequence, likelihood, impact, response, owner, due gate and residual exposure. Likelihood and impact are scored from 1 to 5; impact considers safety, security, confidentiality, integrity, availability, technical performance, evidence, cost and schedule. Exposure guides priority but does not replace professional judgement: a low-likelihood catastrophic hazard can still impose a stop condition.

## Response and acceptance

`Avoid` removes the initiating condition, `Reduce` lowers likelihood or consequence, `Transfer` allocates contractual or specialist responsibility, and `Accept` requires named authority and rationale. Critical safety, unauthorised physical command, unrecoverable data loss and confidential-backbone disclosure risks are not accepted informally. Treatment actions must be testable. A mitigation is not credited until evidence demonstrates implementation and effectiveness.

## Review rhythm

The register is reviewed at weekly engineering control, every architecture or interface change, before procurement, after a security finding or incident, before Prototype 1, immediately after Prototype 1, at independent review, TRR, FAT and release. Owners update trend and next action. Closed risks remain visible with closure evidence; realised risks create issues, NCRs or incident records while the original risk history is retained.

## Escalation and stop conditions

Any uncontrolled path from portal to actuator, cloneable credential treated as authentication, stale data shown as live, unknown wiring revision, missing protective function, unreviewed production key handling or absent restore evidence is escalated immediately. Hazardous energisation stops until machine-specific risk assessment, verified protective functions, controlled wiring, independent review and test readiness are complete. Publication stops when redaction or metadata assurance is incomplete.

## Residual-risk reporting

Residual risk is stated after treatment, with assumptions and verification evidence. `Secure`, `safe` and `complete` are never used as unsupported absolutes. The P03 package records design controls and planned tests; risks whose mitigation depends on Prototype 1 execution remain open or planned. IR may accept R&D residual risk within the P03 boundary but cannot convert a non-safety system into a certified safety function by approval.

{{TABLE:RISKS}}
<!-- PROFESSIONAL_EXPANSION_END -->
