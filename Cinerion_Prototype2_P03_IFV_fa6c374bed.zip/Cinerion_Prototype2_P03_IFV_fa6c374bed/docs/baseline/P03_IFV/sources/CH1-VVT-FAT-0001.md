---
document_number: CH1-VVT-FAT-0001
title: Factory Acceptance Test Procedure
discipline: Verification
document_type: Procedure
document_state: Populated procedure
purpose: Defines formal FAT prerequisites, test sequence, witnessing, recording, punch-list and acceptance rules.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-VVT-VMP-0001
- CH1-SYS-RTM-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# FAT scope and readiness

FAT demonstrates the integrated Cinerion baseline against controlled requirements in a stable test environment. It is entered only after TRR confirms configuration, procedures, instruments, test data, evidence storage, safety arrangements and defect status. The P03 FAT document is a procedure; results belong in uniquely identified execution records and the System Test Report.

## Roles and witnessing

The Test Lead controls sequence and evidence. Discipline engineers support. The Cybersecurity role witnesses critical attack/recovery cases. The Inspector determines acceptance results within assigned authority. IR authorises the P03 engineering event. Later production release requires the independent authority defined after Prototype 1. Witness absence or remote observation is recorded per case; it is never implied.

## Test stages

Stage 1 reviews MDR, baseline, drawings, BOM, software/firmware/PLC hashes and open deviations. Stage 2 proves identity, passkey/TOTP, credential lifecycle and role separation. Stage 3 proves PREPARE/LOCAL COMMIT and attack rejection. Stage 4 proves MQTT, OPC UA, Modbus, serial and PLC/MCU interoperability. Stage 5 proves product/work/part genealogy and resource management. Stage 6 proves inspection, calibration, NCR/rework/retest and report provenance. Stage 7 proves OperationsView freshness, ContextBridge separation and R&D isolation. Stage 8 proves performance, backup/restore and selected failure recovery.

## Execution and deviations

Each case is performed from the controlled step and records actual result, evidence and witness. Unexpected behaviour is not negotiated into the acceptance criterion during execution. A deviation identifies requirement, rationale, risk, compensating control, owner, expiry and approval. A failed mandatory case prevents overall pass until corrected and retested. Not performed and not applicable are distinct.

## Security and publication controls

FAT includes negative-path security, signed-artifact/SBOM inspection, audit-chain mutation detection, backup restore and a clean-room redacted-publication dry run. Restricted evidence stays confidential. Demonstration media is separately approved and cannot reveal keys, exact security configuration, personal data or proprietary backbone details.

## Acceptance statement

The overall conclusion states configuration, scope, passed/failed/not-performed counts, deviations, residual risks and release authority. It never states certified, production-ready or as-built unless the corresponding later evidence and approval exist.

{{TABLE:FAT_TESTS}}
<!-- PROFESSIONAL_EXPANSION_END -->
