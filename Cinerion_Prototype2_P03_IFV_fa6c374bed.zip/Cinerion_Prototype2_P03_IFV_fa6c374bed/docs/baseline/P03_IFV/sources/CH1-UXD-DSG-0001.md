---
document_number: CH1-UXD-DSG-0001
title: UI/UX and Design-System Specification
discipline: User Experience
document_type: Specification
document_state: Populated
purpose: Defines application information architecture, screen catalogue, interaction states and design tokens.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-CON-0001
- CH1-CYB-ACP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Experience principles

The interface makes authority, state, freshness and consequence visible. It optimises safe comprehension rather than visual spectacle: users can see what object they are acting on, which revision is active, whether data is live, what will happen, which local step remains and why an action is blocked. Colour supports meaning but is never the only cue. Critical controls are spatially and semantically distinct from navigation and communication.

## Information architecture

Primary areas are portfolio, site/cell hierarchy, OperationsView, assets/devices, products/revisions/work orders, fabrication, part genealogy, procedures/inspection, NCR/rework, resources, contextual collaboration, ResearchBench, reports/evidence, security, audit and mobile field tools. Object pages expose identity, status, relationships, evidence and permitted actions. Deep technical settings are separated from routine operation.

## Physical-action experience

The portal displays a semantic summary, target cell/asset/part, procedure revision, prerequisites and prepare expiry. It states clearly that execution still requires cryptographic local authentication and a physical button. The UI cannot render a virtual button that resembles local confirmation. Prepared, awaiting credential, awaiting button, executing, fault-latched and cancelled states have unambiguous labels and timestamps. A stale screen disables consequential mutations and offers reconciliation.

## Alarm, fault and message separation

Alarms show priority, source, activation, condition, acknowledgement and clear state. Fault recovery has its own workflow. Contextual messages show author/service origin, object scope, priority, delivery and acknowledgement, but use different iconography and verbs so users cannot mistake `read` for `alarm acknowledged` or `fault cleared`. Notification escalation is observable.

## Design system and accessibility

Components use documented tokens for spacing, typography, contrast, focus, state and density. Tables support keyboard use, sorting/filtering and retained column meaning. Forms validate inline and preserve entered work on recoverable failure. Accessibility targets WCAG-aligned keyboard navigation, focus visibility, semantics, text alternatives and non-colour status cues. Responsive field screens prioritise scanning, evidence capture and offline/degraded indicators.

## Security and usability testing

Authentication guides users toward passkeys/security keys and explains step-up without exposing policy internals. Sensitive values are masked and clipboard/export is controlled. Usability tests cover normal tasks, wrong-object prevention, stale state, loss of network, alarm/message distinction and recovery. Prototype 1 observation informs the post-prototype review and later visual refinement.

{{TABLE:SCREENS}}
<!-- PROFESSIONAL_EXPANSION_END -->
