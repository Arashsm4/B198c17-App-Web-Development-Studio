---
document_number: CH1-SYS-RTM-0001
title: Requirements Traceability Matrix
discipline: Systems Engineering
document_type: Register
document_state: Populated
purpose: Links every requirement to its design allocation, verification method, test case and evidence state.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SRS-0001
- CH1-VVT-VMP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Traceability model

The RTM connects stakeholder intent to a uniquely identified requirement, responsible design element, verification method, primary test case and evidence status. Traceability is bidirectional: every requirement must have design and test coverage, and every test must justify one baseline requirement. Supporting tests may exist, but one-to-one primary mapping prevents ambiguous closure and makes coverage measurable.

## Status definitions

`Specified P03` means the requirement is controlled in the current baseline. Design status advances through allocated, implemented and configuration verified. Evidence status begins `Not executed`, then may become pass, fail, blocked, not applicable by approved rationale, or superseded. A document’s IFV status does not automatically change evidence. Failed tests remain linked and visible even after rework; retest receives new execution evidence.

## Coverage controls

Automated validation checks duplicate IDs, invalid patterns, missing allocations, undefined test IDs, tests not referenced by requirements and MDR/source mismatch. Human review checks semantic coverage: a test must actually challenge the obligation, including negative and failure cases. Security requirements receive attack or misuse tests rather than only happy-path inspection. Performance requirements define workload, network and percentile calculation. Safety-boundary requirements are inspected against the actual bench architecture.

## Evidence binding

Evidence records identify test execution, baseline, software commit, firmware and PLC hash, device identities, instruments, operator/witness, time quality, inputs, raw output, result and deviations. Screenshots are supporting evidence only when their source and context are retained. Generated reports reference evidence IDs rather than copying untraceable values. A checksum protects exported evidence files.

## Review and release use

At Prototype 1, the matrix distinguishes implemented-and-tested items from design-only items. The independent reviewer uses it to select critical command, security, PLC, hardware and recovery evidence. TRR requires complete planned coverage and resolved blockers. FAT requires executed mandatory cases or an authorised deviation. Release requires no orphaned critical requirement, unresolved failed mandatory case or unexplained evidence gap.

{{TABLE:RTM}}
<!-- PROFESSIONAL_EXPANSION_END -->
