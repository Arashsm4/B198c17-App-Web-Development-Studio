---
document_number: CH1-PMG-MDR-0001
title: Master Document Register
discipline: Project Management
document_type: Register
document_state: Populated
purpose: Controls the identity, revision, status, ownership and planned issue of every project document.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents: []
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Register authority and operating rules

The MDR is the authoritative catalogue of controlled document identity, not merely a file list. A row exists once a number has been reserved and remains present through preparation, review, verification, approval, supersession and archive. The document number is immutable. A title may be clarified only through a change record; revision and issue status may advance, but neither a filename nor a folder location changes the underlying identity. If a generated index, local copy or archive disagrees with this register, the MDR and the controlled source package govern.

## Field semantics

`Revision` identifies the content issue. `Issue status` identifies its authorised purpose. `State` identifies whether the content is populated, a controlled template, awaiting execution evidence, or an as-built record. These three fields shall not be collapsed into a single maturity label. `P03/IFV` permits the verification work stated in the release boundary; it does not mean approved-for-production. The discipline owns technical content, the document controller owns identity and issue integrity, IR owns current P03 authorisation, and the independent checker field remains deliberately deferred until after Prototype 1.

## Registration and reconciliation

Before issue, the source front matter, MDR row, DOCX cover, running header, generated LaTeX metadata and any XLSX control line shall agree exactly on number, title, revision, status, date, classification and named authority. The build shall reject duplicate identifiers, missing sources, orphan references, stale P02 current-row values and uncontrolled documents absent from the MDR. Historical P01 and P02 data remain in revision history; they are never copied into the current-revision column.

## Retrieval and navigation

Each item is stored beneath its discipline and its own named folder. Part A of the DOCX is the document-specific material; Part 0 and Part B retain control and reference content. The opening sequence is the controlled cover, one compact navigation page and then Part A; revision history, approval records, references and definitions follow the unique material in Part B. Search should begin by document number because titles and public branding may evolve. The `00_START_HERE` index duplicates only the MDR and transmittal for navigation and does not create new authorities.

## Audit acceptance

The MDR is acceptable when every registered item has exactly one controlled source, one current DOCX, one current LaTeX representation and, where applicable, one XLSX register; all checksums resolve; every cross-reference targets an existing identifier; and the release archive contains no PDF files. Any mismatch is a release-blocking configuration discrepancy.

{{TABLE:MDR}}
<!-- PROFESSIONAL_EXPANSION_END -->
