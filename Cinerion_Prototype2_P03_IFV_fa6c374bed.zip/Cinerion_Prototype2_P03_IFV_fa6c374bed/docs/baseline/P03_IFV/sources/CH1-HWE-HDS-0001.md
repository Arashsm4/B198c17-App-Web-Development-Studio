---
document_number: CH1-HWE-HDS-0001
title: Hardware Design Specification
discipline: Hardware Engineering
document_type: Specification
document_state: Populated
purpose: Defines the physical demonstration cell, electrical design principles, component boundaries and build constraints.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SAF-SCS-0001
- CH1-EMB-FDS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Reference cell hardware architecture

Prototype 1 contains a hardened host, ESP32-S3 principal controller, Arduino-compatible secondary I/O node, Siemens S7-1200 G2 CPU 1212C class PLC or PLCSIM, local display, cryptographic credential reader, illuminated confirmation button, reset/control inputs, sensors, limited-energy actuator, status indicators, QR/RFID part reader and isolated communication interfaces. The bench is modular so each controller can be disconnected, simulated or replaced without rewiring unrelated subsystems.

## Power and protection

The baseline uses a documented 24 VDC control supply with branch protection, emergency isolation and separate regulated rails for 5 V/3.3 V electronics. The exact PSU is sized from normal, inrush and fault loads with reserve. Relay versus transistor PLC output variant is selected from actual loads before purchase. Logic, noisy actuator and external-interface supplies are segregated where needed. Reverse polarity, overcurrent, transient and inductive-load suppression are designed and verified. Protective earth and functional/shield earth are intentionally distinguished.

## Signal integrity and isolation

24 V inputs to microcontrollers use suitable isolation or industrial input conditioning. Outputs use drivers rated for load and fault energy. Analog and low-level sensor wiring is separated from switching and motor conductors. Cable shields are terminated according to frequency/noise strategy, not automatically at both ends. RS-485 includes controlled topology, bias and termination. Ethernet maintains galvanic isolation through approved interfaces. Unused pins and debug connectors cannot create an unrecorded control path.

## PLC and credential hardware

The entry reference is CPU 1212C G2; exact order code, memory card, OPC UA licence and CB/CM serial module are procurement-line items. Where an independent safety function is required, a standard CPU is insufficient. Human authentication uses a cryptographic smart-card/NFC or FIDO-class reader; RC522-type UID readers are permitted only for part identification. Credential-reader communications and tamper/open conditions are monitored.

## Enclosure, EMC and maintainability

DIN-rail layout preserves wiring duct fill, bend radius, heat clearance and service access. Terminals have permanent IDs and test points. Components are labelled with device ID, supply, fuse and revision. Thermal assessment covers worst-case ambient and simultaneous load. The enclosure provides appropriate touch protection and strain relief. A removable demonstration panel exposes only safe test interfaces.

## Inspection and freeze

Before procurement, the BOM records manufacturer, order code, rating, lifecycle status and approved substitute rule. Before energisation, visual inspection, continuity, polarity, insulation where applicable, protective bonding, point-to-point wiring, supply current limit and fail-state tests are recorded. Detailed hardware freeze follows Prototype 1 and independent review.
<!-- PROFESSIONAL_EXPANSION_END -->
