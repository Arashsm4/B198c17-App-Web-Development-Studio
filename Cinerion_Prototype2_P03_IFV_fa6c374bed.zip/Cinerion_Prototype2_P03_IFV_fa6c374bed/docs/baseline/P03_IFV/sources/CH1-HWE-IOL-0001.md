---
document_number: CH1-HWE-IOL-0001
title: I/O and Signal List
discipline: Hardware Engineering
document_type: Register
document_state: Populated
purpose: Controls logical I/O identity, source, destination, signal type, normal state and diagnostic behaviour.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-HWE-HDS-0001
- CH1-AUT-FDS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Signal-register governance

The I/O list is the authoritative logical signal register. Each signal has a permanent ID independent of terminal or PLC address, clear description, owning controller, direction/type, range or protocol, normal and de-energised state, diagnostic behaviour, terminal/address and source drawing. A change to controller allocation, electrical type, scaling, fail state or diagnostic action requires impact assessment; moving a terminal does not create a new signal ID.

## Naming, ownership and quality

Names describe physical meaning rather than implementation, for example `ConfirmationButton` rather than `GPIO17`. Exactly one component owns each output. Multi-source status is resolved in domain logic, not electrically paralleled. Analog values define engineering unit, raw range, scaling, valid range, rate-of-change, sample period, timeout and bad-quality substitution. Network values always expose freshness and quality.

## Normal, fault and maintenance behaviour

The `Normal` column states the non-commanded or healthy condition and is not assumed safe without hazard analysis. Outputs are designed to the non-energising state on startup, watchdog and lost control power. Inputs that use normally closed circuits identify this explicitly. Diagnostic action distinguishes warning, inhibit, fault latch and maintenance-only indication. Bypass/force is time-bounded, authorised, visible and prohibited for credited safety functions.

## PLC addressing and microcontroller mapping

The S7-1200 G2 project maps stable signal IDs to symbolic tags; absolute addresses are generated/recorded but not used as application contracts. EdgeLink addresses semantic data structures, not raw I/O. ESP32/Arduino pin maps are hardware-revision controlled and include level/isolation. Part RFID and human credential channels are separate: UID/application data identifies parts; cryptographic challenge-response authenticates people.

## Verification and completion

Each point is checked against schematic, terminal schedule, software symbol and live state. Digital inputs receive open/closed simulation; outputs are measured with safe dummy loads; analog channels receive at least zero, mid and span; communication points test valid, stale, disconnected and malformed states. Terminal `TBD` is acceptable at P03 design stage but blocks wiring freeze. The register is complete only when every physical connection has an I/O or wiring ID and every configured software point resolves back.

{{TABLE:IO}}
<!-- PROFESSIONAL_EXPANSION_END -->
