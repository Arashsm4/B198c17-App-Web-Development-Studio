---
document_number: CH1-SAF-SCS-0001
title: Machine Safety Concept and Hazard Log
discipline: Safety Engineering
document_type: Safety Concept
document_state: Populated
purpose: Defines the safety boundary, preliminary hazards, risk controls and limitations of the demonstration platform.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-CON-0001
- CH1-AUT-FDS-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Safety scope and limitation

This is a preliminary machine-safety concept for the Cinerion demonstration cell; it is not a completed risk assessment or certificate. Safety-related protective functions belong to the physical machine and shall remain effective without the web application, general network, database, MQTT broker, standard PLC or AI service. Prototype 1 is restricted to extra-low-voltage, limited-energy loads and controlled access until machine-specific hazards are assessed.

## Risk-reduction hierarchy

Hazards are reduced first through inherently safe design: low voltage/energy, limited force, speed, travel and accessible pinch energy; then by guards, interlocks, safety relays or failsafe controllers selected from a risk assessment; then by information, procedures and PPE. Administrative controls never substitute for a reasonably practicable engineered control. The portal and confirmation button provide operational discipline but are not credited as safety functions.

## Control-system boundary

The ESP32-S3 and standard S7-1200 G2 CPU 1212C may execute ordinary control and diagnostics. They default outputs to non-energising states, use watchdogs, detect implausible inputs and latch faults, but these measures do not create a claimed PL or SIL. A required emergency stop, guard locking, safe torque off or other protective function uses an independently designed safety-rated circuit. Reset does not initiate motion. Loss and restoration of power do not resume an interrupted sequence.

## Hazard analysis and validation

Each hazard records hazardous situation, foreseeable sequence, harm, persons exposed, existing controls, additional measures and status. The later machine-specific assessment estimates risk and determines required performance for safety functions. Validation includes schematic review, component suitability, fault analysis, wiring inspection, response-time measurement and functional testing, performed with suitable independence. A simulated guard input in Prototype 1 is not evidence of a validated guard function.

## Human interaction

The Local Confirmer checks cell identity, part, tooling, clearance and displayed procedure before pressing the armed button. The button must require a new edge and time out; a stuck input is rejected. This action confirms readiness only. Alarm acknowledgement records awareness but does not remove the cause. Fault reset is local, authorised and separated from automatic restart.

## Energisation gate

Hazardous energisation is prohibited until the hardware is frozen, wiring matches controlled drawings, protective functions are defined and independently reviewed, residual risk is accepted by competent authority, TRR is passed and emergency arrangements are available. These stop conditions remain even if all software tests pass.

{{TABLE:HAZARDS}}
<!-- PROFESSIONAL_EXPANSION_END -->
