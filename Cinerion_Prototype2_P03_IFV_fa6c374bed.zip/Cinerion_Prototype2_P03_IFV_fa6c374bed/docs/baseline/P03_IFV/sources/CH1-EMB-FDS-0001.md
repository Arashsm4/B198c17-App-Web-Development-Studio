---
document_number: CH1-EMB-FDS-0001
title: Embedded Firmware Design Specification
discipline: Embedded Systems
document_type: FDS
document_state: Populated
purpose: Defines ESP32 and Arduino firmware architecture, tasks, device contracts, watchdogs and secure lifecycle.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-AUT-FDS-0001
- CH1-COM-PRO-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Controller allocation

The ESP32-S3 is the principal Cinerion cell controller for Prototype 1. It owns the local state machine, ConfirmGate integration, button edge detection, permissive resampling, bounded actuator commands, watchdog response, local HMI state and signed device telemetry. Arduino-compatible boards are restricted to secondary, replaceable I/O nodes with no independent authority to start a procedure. PLC logic remains a separate adapter-controlled peer.

## Firmware architecture and tasks

ESP-IDF C++ components are separated into boot/security, device identity, configuration, protocol, state machine, credential reader, discrete I/O, sensors, actuator abstraction, local UI, diagnostics and audit journal. FreeRTOS tasks have explicit priorities, periods, watchdog participation and bounded queues. Interrupts capture time-critical edges and defer processing. Heap use is bounded in control tasks; blocking network calls cannot run in the physical command path.

## State, persistence and recovery

The controller persists device/configuration identity, monotonic command sequence, last terminal transaction and fault reason using an integrity-protected record. Uncommitted prepares are intentionally not restored. Startup holds outputs disabled, validates configuration and security state, performs self-tests, reconciles with Control Core and enters Idle only when permissives are valid. Brownout, watchdog and reset cause are reported.

## Security profile

Development and production security profiles are separate. Production targets secure boot, signed firmware, flash encryption, protected device keys, anti-rollback and disabled debug pathways as supported. Fuse changes follow a staged checklist on dedicated hardware because errors can be irreversible. TLS client identity is per device. Secrets never appear in logs or source. OTA update validates signature, compatibility, rollback policy and safe equipment state before activation.

## I/O and diagnostics

Discrete 24 V signals use designed isolation and conditioning. Confirmation input implements debounce, edge-only acceptance and stuck detection. Sensors carry range, plausibility, freshness and quality. Outputs default off and are commanded through bounded drivers. Diagnostics include loop timing, queue high-water marks, communication errors, certificate status, time quality, reset cause and firmware/configuration hashes.

## Coding and verification

The firmware uses warnings-as-errors, static analysis, unit tests for parsers/state transitions, fuzzing for untrusted frames, simulator tests and HIL fault injection. Hardware abstraction permits deterministic test doubles. Acceptance includes long-run watchdog/queue testing, network loss, corrupted frame, invalid certificate, replay, power-cycle reconciliation and measured button-detection latency.
<!-- PROFESSIONAL_EXPANSION_END -->
