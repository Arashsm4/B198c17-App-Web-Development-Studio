---
document_number: CH1-PMG-CMP-0001
title: Configuration Management Plan
discipline: Project Management
document_type: Plan
document_state: Populated
purpose: Controls requirements, source code, firmware, PLC logic, schemas, hardware configuration and released evidence.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-DCP-0001
- CH1-SYS-RTM-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Configuration-item model

Configuration items include requirements, controlled documents, ADRs, source code, generated API clients, database migrations, container definitions, firmware, PLC projects and blocks, device manifests, wiring/I/O schedules, CAD files, test procedures, datasets, evidence, toolchain versions and released hardware selections. Each item has an owner, stable ID or repository path, version scheme, review rule and restoration method. Generated files are traceable to their source and generator version rather than edited independently.

## Baselines

BL-01/v1.0 is the P03 engineering baseline. Future baselines define Prototype 1, post-review design freeze, TRR, FAT and as-built configurations. A baseline record contains commit identifiers, document revisions, schema version, dependency lockfiles, container digests, firmware and PLC hashes, hardware BOM revision, wiring revision and test-data set. The baseline is immutable after issue; changes create a new baseline or a documented controlled patch.

## Change and branch control

Feature branches are short-lived and linked to a requirement, defect or change record. Protected branches require automated tests and review. Security-, command-, identity-, migration-, firmware- and PLC-related changes receive elevated review. Emergency changes are allowed only to contain an active risk, have a named owner and rollback, and are retrospectively reviewed before the next controlled issue.

## Build and provenance

The build records the source commit, clean/dirty state, tool versions, input hashes and output hashes. Software releases include an SBOM and vulnerability disposition. Container images, packages, firmware and PLC archives are signed or checksummed and stored immutably. Reproducibility is demonstrated by rebuilding a representative release from its retained inputs. Secret values and private keys are external to the configuration baseline; only references, policies and public certificates are retained.

## Hardware and site configuration

The reference PLC family is Siemens S7-1200 G2 CPU 1212C, but the exact power/output variant and order code are selected before procurement and recorded in the BOM. The same rule applies to power supply, isolation, protective devices, credential reader, terminals and enclosure. Substitution requires interface, electrical, security, software and verification impact assessment. A bench label and device manifest connect each physical item to its controlled configuration.

## Status accounting and audit

At any gate, status accounting shall answer which baseline is active, which changes are incorporated, which deviations remain, which artifacts are reproducible and which physical devices match. Configuration audits compare source, generated files, running software, connected-device manifests and evidence. Any unexplained difference is a release discrepancy, not a documentation-only issue.
<!-- PROFESSIONAL_EXPANSION_END -->
