---
document_number: CH1-VVT-STR-0001
title: System Test Report
discipline: Verification
document_type: Report
document_state: Controlled result template
purpose: Provides the controlled structure for reporting executed tests without pre-populating unearned pass results.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-VVT-VMP-0001
- CH1-VVT-FAT-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Controlled result-record instructions

This document is a result template and shall remain visibly `Not executed` until real tests occur. The executor shall not copy expected results into the actual-result field. Each execution receives an ID, date, location, baseline, responsible persons and evidence repository. If testing spans configurations, separate runs or a controlled configuration transition are recorded.

## Configuration under test

Record software release/commit, container digests, database schema, identity configuration, API/schema versions, firmware and PLC archives/hashes, device serials and manifests, hardware/BOM, wiring revision, credential technology, certificates/trust configuration, test dataset, instrument/calibration and document baseline. Any deviation from the approved setup is assessed before continuing.

## Results presentation

Summaries report passed, failed, blocked, not executed and not applicable counts without hiding severity. Detailed rows link requirement, case, actual observation, measured values, evidence IDs, deviation/NCR and witness. Graphs identify raw data and calculation. Screenshots are supporting evidence and must show source context without exposing secrets.

## Defects, rework and retest

Failed cases create a linked defect or NCR with containment and impact. A correction identifies change and new baseline. Retest is a new execution linked to the original failure; the first record remains. Regression scope is justified from impact analysis. A test may pass after correction while the overall release remains blocked by another critical issue.

## Security and performance results

Security results state attack precondition, attempted technique, observed enforcement, log/evidence and residual risk; sensitive exploit detail is Restricted. Performance results state workload, duration, hardware/network, percentile method, resource saturation and variability. Safety-related results distinguish ordinary control fail-state tests from later safety-function validation.

## Conclusion and authority

The conclusion states only what the evidence supports. IR may accept Prototype 1 verification within P03. Independent review after Prototype 1 evaluates critical evidence. Certification, hazardous use, production delivery and final release require the later authority and as-built configuration; this template shall not imply them.

{{TABLE:RESULT_TEMPLATE}}
<!-- PROFESSIONAL_EXPANSION_END -->
