---
document_number: CH1-CYB-ACP-0001
title: Access-Control and Role Matrix
discipline: Cybersecurity
document_type: Register
document_state: Populated
purpose: Defines roles, permissions, step-up requirements, segregation of duties and device-account restrictions.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-CYB-IAM-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Policy model

Access decisions combine role-based authority with project/object scope, action sensitivity, authenticator strength, session recency, device trust, cell assignment and equipment state. Roles provide a comprehensible baseline; attributes prevent over-broad standing access. Authorization is enforced in Control Core and relevant local controllers, not only hidden or disabled in the UI.

## Role boundaries

System Administrator manages general configuration but not root cybersecurity policy by default. Cybersecurity Administrator manages credentials, certificates, trust and revocation but cannot release parts. Engineer authors requirements, procedures and configuration proposals. Project Manager controls schedules and resource authority. Local Confirmer can provide local presence proof only for assigned cells. Inspector records/witnesses results and later releases independently. Maintenance Engineer diagnoses and performs controlled recovery. Auditor and Viewer are read only. Device accounts are limited to their protocol and topic scopes.

## Sensitive actions

Role/credential changes, device trust, security policy, configuration promotion, report release, public redaction approval, vault export and recovery require step-up authentication. Physical actions additionally require semantic command policy and local commit. No role may remotely generate button state or cryptographic local proof. Message acknowledgement cannot clear an alarm. ResearchBench roles cannot reach production routes unless an approved promotion and bench-mode transition exist.

## Segregation of duties

The requester and local confirmer are distinct authorities in the transaction even if one person holds both roles during controlled Prototype 1; the audit records each act separately. A person who performed an operation cannot independently provide final inspection release. Security administrators cannot erase their own audit events. Document preparer and independent checker are separate after Prototype 1. AI is neither a role nor an approver.

## Emergency and temporary access

Temporary grants have owner, reason, scope and expiry. Maintenance elevation requires equipment state and is visibly indicated. Break-glass access is dual-controlled, alerts immediately, cannot bypass local physical/safety controls and triggers credential rotation/review. Dormant, departed or compromised identities are revoked rather than merely hidden.

## Review and testing

Access is reviewed after role change, credential incident, Prototype 1, quarterly during active development and before release. Negative tests cover every prohibited role/action and cross-project access. Audit reconciles policy definitions with identity assignments and actual endpoint enforcement.

{{TABLE:ACCESS}}
<!-- PROFESSIONAL_EXPANSION_END -->
