---
document_number: CH1-PMG-CRL-0001
title: Change Request and Baseline Log
discipline: Project Management
document_type: Register
document_state: Populated
purpose: Records controlled changes and their impact on requirements, architecture, tests, cost and schedule.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-PMG-CMP-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Change-control workflow

A change begins with a uniquely identified request describing the problem, proposed outcome, originator, urgency and affected configuration items. Triage confirms whether it is a defect correction, requirement change, architecture decision, security remediation, hardware substitution, documentation correction or emergency containment. The change is not implemented merely because it appears small; impact is assessed before authorisation unless immediate containment is required.

## Impact assessment

Assessment covers requirements and RTM, safety and threat models, interfaces and schemas, data migration, compatibility, firmware/PLC behaviour, hardware and wiring, verification evidence, operations, training, documentation, publication exposure, cost and schedule. A change that can create physical effect is analysed through CommandGuard and local-control boundaries. A change to classification or redaction is reviewed for both content and hidden metadata.

## Classes and authority

Class 1 affects safety, security root, command path, released data integrity or certification claims and requires independent review after that function is established. Class 2 affects architecture, interfaces or acceptance criteria and requires cross-discipline approval. Class 3 is local and non-functional but still receives normal review. Editorial corrections that cannot change interpretation may be bundled, but number, revision and checksum remain controlled.

## Implementation, rollback and closure

Approved changes identify implementation owner, target baseline, migration, tests, rollback and evidence. Software and documentation changes are linked to commits; firmware and PLC changes include archive hashes; hardware changes include BOM, drawing and inspection updates. Closure requires incorporated output, passed planned verification, updated dependent documents and an accepted residual-risk statement. A deployed but unverified change remains open.

## P03 reconciliation record

This P03 regeneration records the owner decisions without advancing to P04: Cinerion/CH1 naming, IR identity, post-Prototype-1 independent review, S7-1200 G2 CPU 1212C reference minimum, enhanced zero-trust/document security, confidential-backbone redacted-publication model, PDF removal, redesigned document navigation and detailed unique content. The change record and checksums distinguish this regeneration from the earlier P03 package.

{{TABLE:CHANGES}}
<!-- PROFESSIONAL_EXPANSION_END -->
