---
document_number: CH1-SWA-ADR-0001
title: Engineering Decision Register
discipline: Software Architecture
document_type: Register
document_state: Populated
purpose: Records architecture decisions, their context, consequences and supersession status.
revision: P03
issue_status: IFV
issue_date: '2026-08-06'
classification: CONFIDENTIAL - PROJECT INTERNAL
prepared_by: IR
checked_by: Deferred - after Prototype 1
approved_by: IR
referenced_documents:
- CH1-SYS-SAD-0001
schema_version: 1.2.0
---

> **P03 verification boundary.** This P03/IFV issue is authorised by IR for engineering, research and development, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is intentionally scheduled after Prototype 1 and shall be completed before detailed hardware freeze, hazardous energisation, certification claims, customer delivery or production release. IR is the preparer, project owner and P03 authorising authority. This issue records owner verification, not independent assurance. The deferred-review plan is a governed lifecycle decision and is not a claim that later independent checking is unnecessary.

<!-- PROFESSIONAL_EXPANSION_BEGIN -->
# Decision-recording discipline

An ADR captures a decision whose rationale and consequences must survive staff, technology or vendor change. Each record states context, considered alternatives, decision, status, rationale, consequences, controls, affected requirements/interfaces and review triggers. Options are assessed against security, safety boundary, maintainability, cost, skills, offline operation, interoperability, evidence quality and migration effort.

## Status and supersession

`Proposed` invites analysis; `Accepted` governs implementation; `Deprecated` remains valid only for existing scope; `Superseded` points to the replacement; `Rejected` preserves why an option was not chosen. A new decision never edits history to make the former choice disappear. Changes to an accepted ADR require an impact record and corresponding updates to requirements, architecture, tests and operations.

## P03 fixed decisions

The visible name is Cinerion while CH1 identifiers remain permanent. The first software release is a modular monolith in C#/.NET LTS with strict TypeScript clients and isolated Python analysis. ESP-IDF C++/FreeRTOS owns the principal cell controller; Arduino-compatible nodes remain secondary. PostgreSQL provides transactional integrity; MQTT 5 is the event backbone; OPC UA and Modbus are adapter profiles. Physical actions use PREPARE/LOCAL COMMIT. The Siemens S7-1200 G2 CPU 1212C class is the lowest-cost reference minimum PLC and is programmed with STEP 7 Basic/TIA Portal. Standard PLC logic receives no safety credit.

## Security and publication decisions

Security follows zero implicit trust, hardware-backed identity where practicable, deny-by-default conduits, signed artifacts, tamper-evident evidence and recoverable key management. Physical document-vault access requires a cryptographic credential plus user verification; an RFID UID is never sufficient. The engineering backbone remains confidential. Public output is a separately generated, approved redacted showcase—not an open copy of the repository.

## Review triggers

ADRs are reconsidered when performance targets are missed, the PLC or credential hardware is unavailable, a critical vulnerability changes the threat model, Prototype 1 reveals unacceptable complexity, legal/publication needs change, or an interface provider cannot pass conformance tests. Cost alone does not override command safety or security boundaries; a cheaper substitute must meet the controlled acceptance criteria.

{{TABLE:ADRS}}
<!-- PROFESSIONAL_EXPANSION_END -->
