# Cinerion controlled documentation system

This repository generates the `P03/IFV` Cinerion engineering-verification baseline from one controlled source model. Shared YAML metadata and JSON engineering records feed 42 separately controlled Markdown documents, editable DOCX editions, generated LaTeX representations and native XLSX registers.

The project and public-facing name is **Cinerion**. The established `CH1` prefix remains the permanent document and object namespace so revisions, links and evidence retain stable identities. The owner identity used in this issue is **IR**.

The package is classified `CONFIDENTIAL - PROJECT INTERNAL`. Copyright © 2026 IR. All rights reserved. The confidential engineering backbone shall not be published. Only separately created, reviewed and checksum-controlled redacted extracts may be used on LinkedIn or other media.

## Authority of each format

- `config/*.yml`, `data/*.json` and `sources/*.md` form the controlled modular source.
- `output/docx/*.docx` are the editable controlled review editions.
- `output/latex/*.tex` are generated portable source representations.
- `output/xlsx/*.xlsx` are native register editions generated from the same records.
- `Cinerion_Documentation_P03_IFV.zip` is the organised handover package.
- PDF files and a combined binder are intentionally excluded from this release.

P03/IFV is authorised by IR for engineering, R&D, software implementation, simulation and controlled extra-low-voltage Prototype 1 work. Independent technical review is deliberately scheduled after Prototype 1 and is mandatory before detailed hardware freeze, hazardous energisation, certification, customer delivery or production release.

## Source structure

```text
controlhub-one-docs/
├── config/                 project metadata and master document manifest
├── data/                   requirements, tests, risks, interfaces and shared registers
├── sources/                one controlled Markdown source per document
├── assets/                 controlled diagrams and document assets
├── tools/                  finalisation, validation, build, QA and packaging programs
├── output/
│   ├── docx/               editable controlled documents
│   ├── latex/              generated LaTeX representations
│   └── xlsx/               native controlled registers
├── qa/                     structural and render-verification evidence
└── release/                discipline-organised issue folder before ZIP packaging
```

## Document reading model

Every DOCX uses the same unmistakable navigation convention:

1. **Part 0 — Controlled Front Matter**: compact purpose, content map, revision, approval and references.
2. **Part A — Document-Specific Engineering Content**: the unique technical, procedural or register material; substantive review starts here.
3. **Part B — Controlled Reference Material**: definitions, standards, distribution and authority controls.

Part A is visually identified by a teal divider and lead block. Part 0 and Part B use a slate control style so repeated governance content remains present without obscuring the unique content.

## Controlled build

Python 3.11+, Pandoc, LibreOffice for internal render verification, and the dependencies in `requirements.txt` are required.

```bash
python3 tools/finalize_p03_professional.py
python3 tools/validate.py
python3 tools/build_docs.py --no-pdf
bash tools/build_registers.sh
python3 tools/audit_consistency.py
python3 tools/audit_outputs.py
python3 tools/audit_xlsx.py
python3 tools/finalize_manifest.py
python3 tools/qa_render.py
python3 tools/package_release.py
```

Do not rerun a historical reconciliation script over this final P03 baseline. Future changes shall be made in the controlled sources and data, impact-assessed, and issued under the next authorised revision.

## Review and change workflow

1. Read `CH1-PMG-TRN-0001`, then use `CH1-PMG-MDR-0001` to navigate.
2. Review Part A of the applicable individual DOCX and the corresponding XLSX register where present.
3. Record comments in `CH1-PMG-DRL-0001` or use tracked changes in a working copy.
4. Reconcile accepted intent into Markdown and shared JSON rather than editing only a generated file.
5. Impact-assess requirements, architecture, interfaces, risks, tests and operations.
6. Validate, rebuild, render, visually inspect and checksum the complete release.
7. Preserve the prior issue as superseded evidence; never silently overwrite history.

## Security and safety boundary

The security goal is the highest practicable, evidence-backed defence in depth—not a literal claim of 100% security. The future document vault uses encrypted storage, unique document/container keys, a separately protected key hierarchy, cryptographic physical authentication, user verification, audit and tested recovery. Cloneable RFID/NFC UIDs never grant authority.

Cinerion is not a safety PLC. Portal monitoring, communication and management never create a direct physical-control path. Physical effects remain subject to semantic command policy, the local controller, machine-specific permissives and local confirmation where required. The confirmation button is a deliberate readiness gate, not an emergency stop or safety-rated protective function.
