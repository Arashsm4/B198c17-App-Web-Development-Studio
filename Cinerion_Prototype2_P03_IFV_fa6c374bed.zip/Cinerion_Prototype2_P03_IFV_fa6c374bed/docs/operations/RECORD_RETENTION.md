# Record retention — the registers with an absolute period

Governing document: **CH1-DBA-DD-0001**.
Entity register: `docs/baseline/P03_IFV/data/entities.json`.
Gate: `npm run retention:records`. Attack suite: `npm run retention:attack`.
Companion: [TELEMETRY_RETENTION.md](TELEMETRY_RETENTION.md), which covers the third.

> "Retention is based on evidence, legal and project needs; deletion is authorised, logged
> and compatible with immutable-release obligations."

## Which entities this covers, and why only these

`entities.json` gives **ten** entities a finite retention. Only **three** are computable
from data CH1 actually holds:

| Entity | Declared retention | Status |
|---|---|---|
| `TelemetrySample` | Configurable; summary permanent | Implemented — migrations `0010`/`0011` |
| `MessageAcknowledgement` | 7 years | **Implemented here** — migration `0014` |
| `RoleAssignment` | 7 years | **Implemented here** — migration `0014` |

The other seven are relative to a lifecycle end the schema does not record and no controlled
operation sets — "Project life + 7 years", "Device life + 5 years", "Credential life + 7
years", "Account life + policy". `ch1.projects` has no closure column. A disposal process for
those would have no date to compute from, so they are **not implemented and not pretended
to be**. That is [conflict 25](../implementation/PROTOTYPE2_PROGRESS.md), and it is an
owner's decision: either the schema gains lifecycle-end dates and the catalogue gains
operations that set them, or those retentions are understood as policy statements rather
than executable obligations.

## The design point: immutable *within* the retention

Both registers are permanent evidence while their period runs, and disposable after it. That
is not two rules bolted together — it is one rule, and the place it is expressed is the
database.

Migration `0012` had put a `BEFORE UPDATE OR DELETE` trigger on `ch1.role_assignments` that
refused **every** deletion. Correct for immutability, and it also meant the declared seven
years could never actually end: a retention period that cannot be executed is a policy
statement, not an obligation.

So `0014` makes the trigger retention-aware rather than removing it:

- **`UPDATE` is refused for everyone, always.** There is deliberately no path through that
  branch. A record that could be rewritten before disposal could be given any retention its
  holder liked.
- **`DELETE` is refused for everyone, always, except** the retention role acting on a row
  whose own `retain_until` has passed.

Both halves are checked in the database, so neither the application nor a mistake in a
procedure can widen them.

`retain_until` is carried **on the row**, with a `CHECK` tying it to the register's declared
period:

```sql
retain_until timestamptz NOT NULL,
CHECK (retain_until = acknowledged_at + interval '7 years')
```

A disposal process then acts on data rather than on a reading of a page, and a row cannot be
written with a retention that disagrees with `entities.json`.

## Running a disposal

The procedure is `ch1.dispose_expired_records(project, register, authorised_by, reason)`,
`SECURITY INVOKER`, executable only by `cinerion_retention`:

```sql
SET ch1.project_id = '<project uuid>';
SELECT ch1.dispose_expired_records(
    '<project uuid>', 'message_acknowledgements',
    'USR-ADMIN', 'declared seven-year period elapsed');
```

It refuses a missing authoriser or reason, a register outside the closed set of two, and any
project other than the session's. It writes one row to `ch1.record_disposals` naming the
authoriser, the reason, the declared retention, the cutoff, how many rows it removed and how
many remain — and that row can itself be neither rewritten nor removed.

`cinerion_app` is granted neither `EXECUTE` on the procedure nor `UPDATE`/`DELETE` on either
register. **The `REVOKE` is the load-bearing half:** migration `0002` sets
`ALTER DEFAULT PRIVILEGES IN SCHEMA ch1 GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES`, so
the application role receives all four on every table created afterwards and a `GRANT` here
would be a comment rather than a control. That is defect 53's exact shape.

`ch1.message_acknowledgements` previously had **no** immutability trigger and the application
role held all four privileges, so a delivery receipt — a Controlled record whose entire
purpose is to evidence that a named recipient saw a message — could be silently rewritten or
deleted. Same shape as conflict 19: an authority nobody had asked for, doing nothing except
making an unattributable change possible.

## What the gate proves, and what attacking it proved

`npm run retention:records` is SQL end to end, deliberately. An application that happens not
to issue a `DELETE` proves nothing; CH1-DBA-DD-0001 asks for the difference between "no code
does that" and "the database will not permit it".

31 checks. Two of them exist because the privilege layer refuses **before** the trigger is
reached: the retention role holds no `UPDATE`, so the trigger's `UPDATE` branch and its role
branch would otherwise be claims nothing had exercised. The gate therefore widens the grant
for exactly one check each, shows the trigger refuses anyway, takes the grant back, and then
**asserts it was taken back** — a gate that widens a grant and fails to narrow it again has
left the deployment worse than it found it.

`npm run retention:attack` removes each control in turn and requires a refusal by name.
**Eight attacks, 0 holes.** The first is worth reading: removing the procedure's
`retain_until` predicate deletes **nothing** rather than too much, because the trigger
refuses the unexpired row and aborts the whole transaction. The procedure's predicate is a
convenience; the trigger is the control. That is recorded rather than tidied away, and a
second attack removes both halves so the predicate is tested on its own.

## What this does not do

- It announces **no controlled verification case**. `data/tests.json` contains none for
  retention or disposal — searching it returns only CH1-VVT-TC-0126, which is about SBOM and
  dependency disposition. Binding this evidence to an unrelated case is the overstatement the
  verification map exists to prevent. Recorded as conflict 18.
- It is not scheduled. Disposal is an administrative act with a named authoriser, not a cron
  job, and no controlled operation performs one.
- It does not cover the seven entities whose retention is relative to a lifecycle end the
  schema does not record.
