# Backup, integrity verification, restore and rollback

**Controlled requirement:** CH1-OPS-FR-0002 — *"The deployment shall provide documented
backup, integrity verification, restore and rollback procedures."*
**Verification case:** CH1-VVT-TC-0081 — *"Restored system passes integrity and functional
smoke tests."*
**Governing manual:** CH1-OPS-OMM-0001, which requires backups and restore tests to be
reviewed.

This procedure is executed end to end by `scripts/check-backup-restore.sh`. That is
deliberate: a documented procedure nobody has run is a document, not a procedure, and the
one thing a backup must never do is look like it worked.

---

## What is in scope, and what is not

| Held | Where it lives | Covered here |
|---|---|---|
| Controlled operational records — projects, sites, cells, parts, measurements, NCRs, releases, alarms, telemetry, resources, allocations, experiments, devices, credentials, reports, scan events, **and the audit chain** | `ch1` schema in PostgreSQL | **Yes** |
| The application role `cinerion_app` and its grants | PostgreSQL cluster + `ch1` schema | Re-asserted on restore from migration `0002`, not carried in the artefact |
| Identities, passwords, sessions, realm policy | FortressGate (Keycloak) | **No** — backed up with the realm, by its own procedure |
| Step-up grants | Nowhere; deliberately never persisted | **No** — a restart forces re-authentication, which is the safe direction |
| Database credentials | Controlled secret storage | **No** — a password must never travel inside a backup artefact |

Row-level security is enforced against `cinerion_app`. Defect 13 in this repository was
that role not existing, which left every isolation policy inert while appearing to be in
force — so a restore that does not end with a controlled, non-superuser `cinerion_app` is
reported as a failure, not a success.

---

## Backup

```bash
scripts/backup.sh --container cinerion-postgres-1
```

or, where the database is reachable directly:

```bash
scripts/backup.sh --dsn "postgresql://cinerion_owner@host:5432/cinerion"
```

The `--container` form runs `pg_dump` inside the database container, which is how the
controlled data zone is reached: it sits on an internal network with no published host
port, deliberately.

Two artefacts are written to `artifacts/backups/`:

| File | What it is |
|---|---|
| `cinerion-<label>.sql` | the `ch1` schema and its data, taken with `--clean --if-exists` so a restore is a replacement and never a merge |
| `cinerion-<label>.manifest.json` | the integrity evidence: SHA-256 of the dump, a fingerprint of the controlled tables it came from, the table count, the byte size and the time taken |

A dump that produced no controlled tables is refused rather than written. An empty backup
that restores cleanly is the most dangerous artefact this procedure could produce.

There is deliberately no version number in the manifest. This schema has no migrations
table, and inventing one would be a second declaration of the schema level to keep in step
with `scripts/check-database-migrations.mjs` and the startup probe. Control Core refuses at
start to run against a database behind its own build and names the missing migration,
which is the guard that matters after a restore.

---

## Integrity verification

Performed automatically by `scripts/restore.sh` before anything is written, and refusing in
three ways:

| Condition | Outcome |
|---|---|
| The dump's SHA-256 does not match its manifest | `INTEGRITY CHECK FAILED`, naming both values. Nothing is written |
| The manifest is absent | Refused. An unaccompanied dump cannot be checked at all, and "it looked like a database" is not integrity verification |
| The target already holds controlled tables | Refused unless `--replace` is passed, because a restore replaces controlled state rather than merging into it |

To verify a held backup without restoring it, compare it yourself:

```bash
sha256sum artifacts/backups/cinerion-<label>.sql
grep sha256 artifacts/backups/cinerion-<label>.manifest.json
```

---

## Restore

```bash
scripts/restore.sh --backup artifacts/backups/cinerion-<label>.sql --container <db-container>
```

The script then, in order:

1. verifies the manifest checksum and refuses on mismatch;
2. restores the `ch1` schema and data;
3. re-asserts the controlled application role and its grants from
   `0002_application_role.sql` — which runs *after* the restore because it grants on a
   schema the restore has just created;
4. confirms `cinerion_app` is `NOSUPERUSER` and `NOBYPASSRLS`, and **refuses to report
   success if it is not**.

Two steps remain, and only the deployment can perform them:

```sql
ALTER ROLE cinerion_app LOGIN PASSWORD '<from controlled secret storage>';
```

then start Control Core against the restored database and verify the chain:

```bash
curl -X POST .../api/v1/audit/chain-verifications -H 'X-CH1-Roles: Auditor' …
```

A chain that no longer verifies means the restored evidence is not the evidence that was
recorded. That is the acceptance criterion, not a formality.

---

## Rollback

Rollback is a restore naming an earlier artefact. List what is held:

```bash
scripts/restore.sh --list
```

then restore the chosen one with `--replace`. Rolling back discards every controlled record
written after that backup was taken; the audit chain of the restored artefact is complete
and verifiable in itself, but the discarded events are gone, so a rollback is an authorised
decision and not a recovery convenience.

---

## Verification

```bash
npm run backup:verify
```

`scripts/check-backup-restore.sh` performs the whole procedure against real databases and
asserts what actually matters afterwards:

| Step | Assertion |
|---|---|
| Source | controlled records are produced **through the ordinary API** against PostgreSQL, and the chain verifies |
| Source content | the records are genuinely in the database, not only in the service |
| Backup | the artefact and its manifest are written |
| Attack | a backup with one byte appended is **refused**, and the target is still empty afterwards |
| Restore | into a database that held 0 controlled tables |
| Isolation | the restored `cinerion_app` exists and is `NOSUPERUSER`/`NOBYPASSRLS` |
| Integrity | the restored audit chain **verifies** — the hash linkage survived the dump and reload |
| Completeness | audit events and measurements match the counts recorded before the backup |
| Functional | the part's genealogy is readable, and a **new** controlled record is accepted and chains onto the restored chain |
| Attack | an altered event in the restored chain **breaks** verification, at the position reported |

Only after all of those hold does it print `VERIFICATION-CASE CH1-VVT-TC-0081`, which
`scripts/check-verification.mjs` reads from a real run and reconciles against
`traceability/verification-map.json`. Both directions were attacked while it was written:
removing the announcement fails the reconciliation, and neutering the tamper attack fails
the harness — the check is proven able to fail, which is the only reason to believe it
when it passes.

It needs Docker. It is skippable while working and mandatory in CI, on the same terms as
every other harness in that gate.

---

## Review

CH1-OPS-OMM-0001 requires backups and restore tests to be **reviewed**. This procedure is
executed automatically; the review it asks for is a human one, over the artefacts retained
and the evidence produced, and belongs with the deployment's own operating record.
