# Telemetry retention and authorised disposal

**Controlling document:** CH1-DBA-DD-0001, *Telemetry and retention*, and the entity
register's retention for `TelemetrySample`: **Operational — "Configurable; summary
permanent"**.

> High-rate telemetry enters a bounded pipeline with freshness and quality, then is retained
> raw or aggregated according to declared need. Critical events and acceptance measurements
> are never lost through telemetry downsampling. Retention is based on evidence, legal and
> project needs; deletion is authorised, logged and compatible with immutable-release
> obligations.

## What this is, and what it deliberately is not

Disposal is an **administrative act**, not a service function. The P03 catalogue contains no
operation for it, `scripts/check-repository-policy.mjs` would fail the build on one that was
invented, and CH1-DBA-DD-0001 describes deletion as authorised and logged rather than as
something a running service does to itself. So it is run by a person, as a distinct database
role, with a name and a reason on the record.

Migration `0001` already said this, beside the immutability triggers: *"Retention is a
separate controlled administrative process with independent evidence."* Nothing implemented
it until migration `0010`.

## The four pieces

| Piece | What it is |
|---|---|
| `ch1.telemetry_summaries` | The permanent half of "configurable; summary permanent". One immutable hourly aggregate per project, cell, device and channel: count, minimum, maximum, average, first and last sample time, and the **worst** quality and freshness in the bucket |
| `ch1.telemetry_disposals` | The "authorised, logged" half. Who, why, what window, what cutoff, and what it actually did — counted, not estimated. Append-only |
| `cinerion_retention` (migration `0011`) | A role that may `DELETE` from exactly one table and read the rest. `NOSUPERUSER`, `NOBYPASSRLS`, and subject to the same project isolation as everything else |
| `ch1.dispose_telemetry(...)` | `SECURITY INVOKER`, so its safety is the caller's grants rather than a promise about its body |

## Running it

```bash
CINERION_RETENTION_CONNECTION='postgres://cinerion_retention:…@host:5432/cinerion' \
  scripts/retain-telemetry.sh \
    --project 00000000-0000-4000-8000-000000000101 \
    --days 90 \
    --by 'A. Operator' \
    --reason 'CH1-DBA-DD-0001 scheduled quarterly disposal'
```

`--dry-run` reports how many samples are older than the cutoff and how many of those are
protected, and writes nothing.

The script refuses before it connects if the authoriser or reason is missing, and refuses
after connecting if the session is not `cinerion_retention` or if that role turns out to be
a superuser or to bypass row-level security. The connection string names the retention role
and is supplied by the deployment from controlled secret storage; the migration creates the
role `NOLOGIN` with no password, exactly as `cinerion_app` is created.

## What it will not do

| Refusal | Why |
|---|---|
| No named authoriser, or no reason | An authorisation with nobody's name on it is not one. Enforced in the script, in the function, and by `CHECK` constraints on the table |
| A retention window under **7 days** | "Delete everything" is a mistake, not a policy. The floor is in the database, not in the script |
| A project other than the session's | Disposal is scoped by the same mechanism that scopes a read |
| Anything but raw telemetry | The role holds `DELETE` on `ch1.telemetry_samples` and on nothing else. Alarms, measurements, release records and the audit chain are out of reach whatever the procedure asks for |
| A sample that evidences a permanent record | Samples inside an alarm's activation window on the device that raised it, and the sample a controlled measurement names as its source, are retained **regardless of age** |
| A sample with no summary behind it | The delete joins the summary table, so nothing disappears without an aggregate standing in for it |

## What the application can no longer do

`0002` granted `cinerion_app` `DELETE` on every table, which included telemetry. No code path
in Control Core issues one — so it was authority nobody had asked for, and nothing would have
recorded its use. `0011` revokes it. Deletion of telemetry is now possible only through the
retention role, and only through a procedure that writes its own evidence.

The role, its grants and that revoke live in `0011` rather than `0010`, for the reason
`cinerion_app` lives in `0002` rather than `0001`: a schema dump carries neither a role nor
its grants, so `scripts/restore.sh` re-asserts both files after every restore and refuses to
report success if `cinerion_app` comes back holding `DELETE` on `ch1.telemetry_samples`.

## Verification

`npm run retention:verify` (`scripts/check-telemetry-retention.sh`) raises a throwaway
database, applies every controlled migration, runs Control Core with the simulated cell
feeding the **ordinary** ingestion path, produces a controlled measurement through the API,
and then disposes for real. It checks the counts against the database rather than believing
the procedure, and attacks the retention role directly.

It **announces no controlled verification case**, because `data/tests.json` contains none for
retention or disposal. That is recorded as an open conflict rather than resolved by binding
this evidence to a case about something else.

## What is still open

* **Partitioning.** `ch1.telemetry_samples` is partitioned by `sampled_at` with a single
  `DEFAULT` partition. Disposal is row-precise rather than partition-dropping, and has to be:
  a dropped partition would take an alarm's evidence with it. Per-period partitions remain
  available as a performance measure and would not change what is deleted.
* **Scheduling.** There is no timer. CH1-DBA-DD-0001 makes disposal authorised, and a job
  that ran itself would be disposal nobody authorised. The schedule is an operational
  decision that names a person each time.
* **The gateway buffer.** CH1-NFR-REL-0001 and CH1-VVT-TC-0093 require EdgeLink to buffer at
  least 24 hours of telemetry without overwriting newer critical events. That is a property
  of the gateway, not of this database, and is untouched here.
